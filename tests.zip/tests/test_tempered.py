"""Numerical verification of the tempered fractional calculus core (src/tfso/tempered.py).

Run from the project root:  python -m pytest tests/test_tempered.py -q
Every test checks a statement of the manuscript blocks M1-M4b with numbers; the
results are summarised in reports/math_numerical_verification.md.
"""
import math
import sys
from pathlib import Path

import numpy as np
import pytest
from scipy.integrate import solve_ivp
from scipy.special import binom, gammaln

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import tempered as T  # noqa: E402

ALPHAS = [0.3, 0.5, 0.7, 0.9]


# ---------------------------------------------------------------- weights
@pytest.mark.parametrize("alpha", ALPHAS + [0.6])
def test_recursion_vs_binomial(alpha):
    """lem:m1:glweights (i),(iii): recursion = (-1)^j binom(alpha, j) = gamma form, N = 2000."""
    N = 2000
    w = T.gl_weights_untempered(alpha, N)
    j = np.arange(N + 1)
    wb = (-1.0) ** j * binom(alpha, j)
    wg = np.empty(N + 1)
    wg[0] = 1.0
    jj = j[1:].astype(float)
    wg[1:] = -alpha * np.exp(gammaln(jj - alpha) - gammaln(1 - alpha) - gammaln(jj + 1))
    assert np.max(np.abs(w - wb) / np.abs(wb)) < 1e-11
    assert np.max(np.abs(w - wg) / np.abs(wg)) < 1e-11
    # tempered weights and the tempered sum identity (lem:m1:glweights (v))
    lam, h = 0.01, 0.5
    wt = T.gl_weights(alpha, lam, h, N)
    assert np.allclose(wt, w * np.exp(-lam * h * j), rtol=1e-12, atol=0)
    assert np.all(wt[1:] < 0)
    # partial sums W_n (lem:m2:weights (iii))
    W = T.partial_sums_W(alpha, N)
    assert np.allclose(W, np.cumsum(w), rtol=1e-10, atol=1e-15)
    n = np.arange(1, N + 1)
    Wg = np.exp(gammaln(n + 1 - alpha) - gammaln(1 - alpha) - gammaln(n + 1.0))
    assert np.max(np.abs(W[1:] - Wg) / Wg) < 1e-11


def test_tempered_weight_sum_identity():
    for alpha in ALPHAS:
        for lam, h in [(0.005, 1.0), (0.02, 2.0), (0.1, 0.5)]:
            N = int(60 / (lam * h))
            wt = T.gl_weights(alpha, lam, h, N)
            assert abs(np.sum(-wt[1:]) - (1 - (1 - math.exp(-lam * h)) ** alpha)) < 1e-12


@pytest.mark.parametrize("alpha", ALPHAS)
def test_weight_bound(alpha):
    """Two-sided Gautschi bound for 1 <= j <= 1e5 (lem:m1:glweights (iv), eq:m2:weight-bound)."""
    N = 100_000
    w = np.abs(T.gl_weights_untempered(alpha, N)[1:])
    j = np.arange(1, N + 1)
    lo, up = T.weight_bound(alpha, j)
    assert np.all(w > lo)
    # strict for every j >= 1, also j = 1: |omega_1| = alpha < C_alpha = alpha/Gamma(2-alpha)
    # (the "equality only at j = 1" of M2 concerns the intermediate step j/(j-alpha) <= 1/(1-alpha))
    assert np.all(w < up)
    assert abs(w[0] - alpha) < 1e-15
    assert np.all(np.diff(w) < 0)                # strictly decreasing
    # sum_{j<=n} |omega_j| = 1 - W_n
    W = T.partial_sums_W(alpha, N)
    assert abs(np.sum(w) - (1 - W[-1])) < 1e-12


# ---------------------------------------------------------------- incomplete gamma, truncation
@pytest.mark.parametrize("alpha", ALPHAS + [0.6])
def test_upper_gamma_neg_vs_mpmath(alpha):
    xs = [1e-6, 1e-3, 0.05, 0.5, 1.0, 1.999, 2.0, 2.001, 5.0, 20.0, 64.0, 300.0]
    for x in xs:
        ref = T.upper_gamma_neg_mp(alpha, x)
        assert abs(T.upper_gamma_neg(alpha, x) - ref) <= 1e-13 * abs(ref), (alpha, x)


LAMS = [1e-4, 1e-3, 5e-3, 2e-2]
LS = [50, 200, 800, 3200]
HS = [0.5, 1.0, 2.0]


def _worst(alpha, lam, h, L):
    return T.worst_case_remainder(alpha, lam, h, int(round(L / h)), 1.0)


@pytest.mark.parametrize("alpha", ALPHAS)
def test_truncation_bounds_dominate(alpha):
    """thm:m2:truncation: every bound >= exact worst-case tail (constant f), all (lam, L, h)."""
    worst_ratio = {f: 0.0 for f in ("gamma", "a", "b", "sharp")}
    for lam in LAMS:
        for L in LS:
            for h in HS:
                ex = _worst(alpha, lam, h, L)
                assert ex > 0
                for f in worst_ratio:
                    bd = float(T.truncation_bound(alpha, lam, L, 1.0, f, h=h))
                    worst_ratio[f] = max(worst_ratio[f], ex / bd)
                    assert ex <= bd * (1 + 1e-12), (alpha, lam, L, h, f, ex, bd)
                # ordering Gamma bound <= min(a, b) (eq:m2:trunc-tempered)
                g = float(T.truncation_bound(alpha, lam, L, 1.0, "gamma"))
                assert g <= min(float(T.truncation_bound(alpha, lam, L, 1.0, "a")),
                                float(T.truncation_bound(alpha, lam, L, 1.0, "b"))) * (1 + 1e-12)
                # untempered bound dominates the tempered one; ratio = rho_alpha(lam L)
                u = float(T.untempered_truncation_bound(alpha, L, 1.0))
                assert abs(g / u - float(T.rho_alpha(alpha, lam * L))) < 1e-12
    assert worst_ratio["sharp"] < 1.0


@pytest.mark.parametrize("alpha", ALPHAS)
def test_truncation_h_independence(alpha):
    """The bounds do not depend on h; the exact worst case varies by < 5 % over h in {0.5,1,2} and
    tends (h -> 0) to (alpha/Gamma(1-alpha)) int_L^inf x^{-1-alpha} e^{-lam x} dx (prop:num:hlimit)."""
    for lam in LAMS:
        for L in LS:
            ex = np.array([_worst(alpha, lam, h, L) for h in HS])
            assert (ex.max() - ex.min()) / ex.max() < 0.05
            lim = alpha / math.gamma(1 - alpha) * float(T.tail_integral(alpha, lam, L))
            e_fine = _worst(alpha, lam, 0.25, L)
            assert abs(e_fine - lim) <= abs(ex[0] - lim) + 1e-15   # closer at smaller h
            assert abs(e_fine - lim) / lim < 5e-3
            b = [float(T.truncation_bound(alpha, lam, L, 1.0, "gamma")) for _ in HS]
            assert b[0] == b[1] == b[2]


def test_two_sided_worst_case_tail():
    """prop:num:hlimit: (alpha/Gamma(1-alpha)) I(L+2h) <= R*_h(L) <= C^sharp(N_L) I(L), I = tail integral."""
    for alpha in ALPHAS:
        for lam in [0.0] + LAMS:
            for L in LS:
                for h in [0.25] + HS:
                    NL = int(round(L / h))
                    ex = T.worst_case_remainder(alpha, lam, h, NL)
                    lo = alpha / math.gamma(1 - alpha) * float(T.tail_integral(alpha, lam, L + 2 * h))
                    up = float(T.C_alpha_sharp(alpha, NL)) * float(T.tail_integral(alpha, lam, L))
                    assert lo <= ex * (1 + 1e-12) and ex <= up * (1 + 1e-12), (alpha, lam, L, h)


def test_untempered_worst_case_is_W():
    for alpha in ALPHAS:
        for h in HS:
            for L in LS:
                NL = int(L / h)
                ex = T.worst_case_remainder(alpha, 0.0, h, NL)
                assert ex <= float(T.untempered_truncation_bound(alpha, L, 1.0))
                assert ex <= float(T.truncation_bound(alpha, 0.0, L, 1.0, "gamma")) * (1 + 1e-12)


def test_m2_worked_example():
    """rem:m2:example: alpha 0.6, lambda 0.005, B 0.2, eps 1e-4, h 1."""
    r = T.memory_rule(0.6, 0.005, 0.2, 1e-4, h=1.0)
    assert round(r["L_star"], 1) == 507.9
    assert round(r["L_b_star"], 1) == 749.7
    assert round(r["L_Gamma_star"], 1) == 454.1
    assert abs(r["L_0_star"] / 3.8752e5 - 1) < 1e-4
    assert r["N_L"] == 508
    assert round(r["L_sharp_star"], 1) == 342.4
    # Lambert closed forms agree with bisection
    assert abs(r["L_star"] - r["L_star_bisect"]) < 1e-9 * r["L_star"]
    assert abs(r["L_b_star"] - r["L_b_star_bisect"]) < 1e-9 * r["L_b_star"]
    assert r["L_Gamma_star"] <= min(r["L_star"], r["L_b_star"])
    # remainders at N_L = 508
    ex = T.worst_case_remainder(0.6, 0.005, 1.0, 508, 0.2)
    assert abs(ex / 2.634e-5 - 1) < 5e-4
    assert abs(float(T.truncation_bound(0.6, 0.005, 508, 0.2, "sharp", h=1.0)) / 2.645e-5 - 1) < 5e-4
    assert abs(float(T.truncation_bound(0.6, 0.005, 508, 0.2, "gamma")) / 6.605e-5 - 1) < 5e-4
    assert abs(float(T.truncation_bound(0.6, 0.005, 508, 0.2, "a")) / 9.99e-5 - 1) < 1e-3
    # untempered, same 508-sample window: exact value B W_508 = 2.1449e-3 (M2.tex: "2.1e-3, eighty
    # times larger"); M2_summary.md quotes 2.086e-3 / ratio 79, which is the tail cut at j = 2e5.
    unt = T.worst_case_remainder(0.6, 0.0, 1.0, 508, 0.2)
    assert abs(unt / 2.14495e-3 - 1) < 1e-4 and round(unt, 4) == 2.1e-3
    assert abs(unt / ex / (1 / float(T.rho_alpha(0.6, 0.005 * r["L_star"]))) - 1) < 0.01
    rho = [float(T.rho_alpha(0.6, x)) for x in (0.01, 0.1, 1, 2.54, 5)]
    assert np.allclose(rho, [0.8750, 0.5907, 0.1029, 0.01232, 6.32e-4], rtol=2e-3)
    for lam, ref in [(1e-3, 0.06212), (1e-4, 0.09202), (1e-6, 0.10425)]:
        assert abs(float(T.tail_integral(0.6, lam, 100.0)) / ref - 1) < 2e-4


# ---------------------------------------------------------------- Mittag-Leffler, kernels
@pytest.mark.parametrize("alpha", [0.3, 0.6, 0.9, 0.999])
def test_mittag_leffler_cross_check(alpha):
    for beta in (1.0, alpha, alpha + 0.5, 2.0):
        xs = np.array([1e-3, 0.5, 2.0, 5.0, 20.0, 100.0])
        xs = xs[xs ** (1 / alpha) <= 1000]
        auto = T.mittag_leffler(alpha, beta, -xs)
        ref = T.mittag_leffler(alpha, beta, -xs, method="mpmath")
        tol = 1e-11 if alpha < 0.99 else 1e-10
        assert np.max(np.abs(auto - ref) / np.abs(ref)) < tol, beta
        if 0 < beta < 1 + alpha:
            spec = T.mittag_leffler(alpha, beta, -xs[xs > 0.4], method="spectral")
            assert np.max(np.abs(spec - ref[xs > 0.4]) / np.abs(ref[xs > 0.4])) < tol


@pytest.mark.parametrize("alpha", [0.3, 0.6, 0.9])
def test_mittag_leffler_asymptotics(alpha):
    """eq:m1:mlasym: two-term asymptotics, error O(x^-3)."""
    xs = np.array([1e2, 1e3, 1e4])
    E = T.mittag_leffler(alpha, 1.0, -xs)
    A = T.mittag_leffler_asymptotic(alpha, 1.0, -xs, nterms=2)
    rel = np.abs(E - A) / np.abs(E)
    assert np.all(rel < 5.0 / xs ** 2)
    assert np.all(E > 0) and np.all(E <= 1)


@pytest.mark.parametrize("alpha,lam,a", [(0.6, 0.05, 0.5), (0.3, 0.0, 0.2), (0.9, 0.01, 2.0),
                                         (0.6, 0.005, 0.05), (0.5, 0.02, 1.0)])
def test_kernel_l1_norm(alpha, lam, a):
    """lem:m1:solution (iii): ||g_lambda||_1 = 1/(a + lambda^alpha), time-domain and spectral quadrature."""
    closed, tq, sq = T.kernel_l1_norm(alpha, lam, a, quad=True)
    assert abs(tq / closed - 1) < 1e-4
    assert abs(sq / closed - 1) < 1e-4
    # kernel ranges: 0 < e_lambda <= e^{-lambda t}, g_lambda > 0
    t = np.array([0.01, 1, 10, 100, 1000.0])
    e, g = T.tempered_kernel(alpha, lam, a, t)
    assert np.all(e > 0) and np.all(e <= np.exp(-lam * t) * (1 + 1e-14)) and np.all(g > 0)


def test_step_integral_lambda0_and_limit():
    alpha, a = 0.6, 0.5
    t = np.array([0.1, 1, 10, 100, 1e4])
    S = T.tempered_step_integral(alpha, 0.0, a, t)
    ref = (1 - T.mittag_leffler(alpha, 1.0, -a * t ** alpha)) / a
    assert np.max(np.abs(S - ref)) < 1e-12
    assert abs(T.tempered_step_integral(alpha, 0.05, a, [1e5])[0] * (a + 0.05 ** alpha) - 1) < 1e-12


# ---------------------------------------------------------------- GL scheme
def test_gl_first_order_convergence():
    """Implicit corrected GL recursion -> exact step response, first order (prop:m1:consistency)."""
    alpha, lam, a, b, I0, x0, Tend = 0.6, 0.05, 0.5, 0.15, 1.0, 0.02, 20.0
    hs = [0.4, 0.2, 0.1, 0.05, 0.025]
    errs = []
    for h in hs:
        N = int(round(Tend / h))
        x = T.simulate_tempered_element(alpha, lam, a, b, np.full(N + 1, I0), h, x0=x0)
        t = h * np.arange(N + 1)
        m = t >= 1.0
        errs.append(np.max(np.abs(x[m] - T.exact_step_response(alpha, lam, a, b, I0, t[m], x0=x0))))
    slope = np.polyfit(np.log(hs), np.log(errs), 1)[0]
    assert slope > 0.85, (slope, errs)


def test_ring_buffer_and_scheme_identity():
    """Ring-buffer recursion = direct finite-memory formula; D_{h,L} x = -a x + b I holds exactly."""
    alpha, lam, a, b, h, N, NL, x0 = 0.6, 0.05, 0.5, 0.15, 0.5, 400, 50, 0.01
    I = np.sin(0.1 * np.arange(N + 1))
    x1 = T.simulate_tempered_element(alpha, lam, a, b, I, h, x0=x0, N_L=NL)
    om = T.gl_weights(alpha, lam, h, NL)
    W = T.partial_sums_W(alpha, N)
    x = np.zeros(N + 1)
    x[0] = x0
    for n in range(1, N + 1):
        m = min(n, NL)
        x[n] = (h ** alpha * b * I[n] - np.dot(om[1:m + 1], x[n - 1::-1][:m])
                + x0 * math.exp(-lam * n * h) * W[n]) / (1 + h ** alpha * a)
    assert np.max(np.abs(x - x1)) < 1e-15
    D = T.gl_derivative(x1, alpha, lam, h, N_L=NL)
    assert np.max(np.abs(D[1:] + a * x1[1:] - b * I[1:])) < 1e-14
    # a priori bound lem:m2:apriori
    assert np.max(np.abs(x1)) <= max(abs(x0), b * np.max(np.abs(I)) / a) + 1e-15
    # full memory limit: N_L >= N equals N_L = None
    assert np.array_equal(T.simulate_tempered_element(alpha, lam, a, b, I, h, x0=x0, N_L=N),
                          T.simulate_tempered_element(alpha, lam, a, b, I, h, x0=x0))


def test_constant_scheme_limit():
    """lem:m1:schemeidentity: D_h c -> c h^-a (1-e^{-lam h})^a -> c lam^a."""
    alpha, lam, h, N = 0.6, 0.05, 0.5, 6000
    D = T.gl_derivative(np.ones(N + 1), alpha, lam, h)
    assert abs(D[-1] - T.mu_h(alpha, lam, 0.0, h)) < 1e-12
    assert abs(T.mu_h(alpha, lam, 0.0, 1e-6) - lam ** alpha) < 1e-6


def test_limit_lambda0():
    """lambda = 0: Cole-Cole element, exact (1 - E_alpha(-a t^alpha))/a, first-order convergence."""
    alpha, a = 0.6, 0.5
    errs = []
    hs = [0.2, 0.1, 0.05]
    for h in hs:
        N = int(round(50 / h))
        t = h * np.arange(N + 1)
        x = T.simulate_tempered_element(alpha, 0.0, a, 1.0, np.ones(N + 1), h)
        ex = (1 - T.mittag_leffler(alpha, 1.0, -a * t ** alpha)) / a
        errs.append(np.max(np.abs(x - ex)[t >= 1]))
    assert np.polyfit(np.log(hs), np.log(errs), 1)[0] > 0.85
    assert errs[-1] < 1e-2


def test_limit_alpha_to_one():
    """alpha -> 1 (prop:m1:constant (iii), rem:m1:limits): V' = -(a+lambda)V + b I (RC with leakage)."""
    lam, a, b, Tend, x0 = 0.02, 0.1, 0.05, 200.0, 0.03
    Ifun = lambda s: 2.0 if (s % 40) < 20 else -1.0
    res = {}
    for h in (0.05, 0.025):
        N = int(round(Tend / h))
        t = h * np.arange(N + 1)
        I = np.array([Ifun(s - 1e-12) if s > 0 else Ifun(0.0) for s in t])
        sol = solve_ivp(lambda s, y: -(a + lam) * y + b * Ifun(s), (0, Tend), [x0], t_eval=t,
                        max_step=0.01, rtol=1e-11, atol=1e-13)
        for alpha in (0.999, 0.9999):
            x = T.simulate_tempered_element(alpha, lam, a, b, I, h, x0=x0)
            res[(h, alpha)] = np.max(np.abs(x - sol.y[0])) / np.max(np.abs(sol.y[0]))
    assert res[(0.05, 0.999)] < 5e-3
    assert res[(0.025, 0.9999)] < res[(0.05, 0.999)]   # error -> 0 as h -> 0, alpha -> 1
    assert res[(0.025, 0.9999)] < 1e-3


# ---------------------------------------------------------------- certificates
def test_certify_agrees_with_explicit_inequalities():
    """prop:m3c:equivalence / lem:m3a:certificate: LP (linprog) <=> explicit inequalities <=> Hurwitz."""
    rng = np.random.default_rng(1)
    n_cert = 0
    for _ in range(600):
        alpha = rng.uniform(0.1, 0.95)
        lam = 10 ** rng.uniform(-4, -1)
        ap = 10 ** rng.uniform(-2, 0)
        k1 = 10 ** rng.uniform(-1.5, 0)
        k2 = k1 * 10 ** rng.uniform(0, 1.3)
        l1 = 10 ** rng.uniform(-3, 0)
        l2 = 0.0 if rng.random() < 0.1 else 10 ** rng.uniform(-4, 0)
        sig = rng.uniform(0, lam)
        c = T.certify_gains_continuous(alpha, lam, ap, k1, k2, l1, l2, sig)
        m1, m2 = l1 * k1 - sig, ap + l2 + (lam - sig) ** alpha
        expl = m1 > 0 and m1 * m2 > l1 * l2 * k2
        assert c.explicit == expl
        if abs(m1 * m2 - l1 * l2 * k2) > 1e-9 * m1 * m2:        # skip numerically degenerate cases
            assert c.lp == expl
            assert (np.max(np.linalg.eigvals(c.M).real) < 0) == expl
        if expl:
            n_cert += 1
            assert np.all(c.M.T @ c.d < 0) and np.all(c.M @ c.xi < 0)
            assert np.max(np.linalg.eigvalsh(c.P @ c.M + c.M.T @ c.P)) < 0
        # discrete version
        h = rng.choice([0.5, 1.0, 2.0])
        NL = int(rng.choice([20, 100, 500]))
        sd = sig * rng.uniform(0.5, 3.0)
        cd = T.certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, sd, h, NL)
        S = (1 - math.exp(-sd * h)) / h
        mu = h ** -alpha * (1 - np.sum(-T.gl_weights_untempered(alpha, NL)[1:]
                                       * np.exp(-(lam - sd) * h * np.arange(1, NL + 1))))
        e = (l1 * k1 - S > 0) and (l1 * k1 - S) * (ap + l2 + mu) > l1 * l2 * k2
        assert cd.explicit == e
        assert cd.certified == (e and h * l1 * k2 <= 1)
        if abs((l1 * k1 - S) * (ap + l2 + mu) - l1 * l2 * k2) > 1e-9 * abs(l1 * l2 * k2 + 1e-300):
            assert cd.lp == e
    assert n_cert > 100


def test_sigma_bar_and_design_gains():
    """prop:m3c:rates-discrete and alg:m3c:design (CVXPY + Clarabel) on the M3c example."""
    alpha, lam, ap, k1, k2, h = 0.6, 0.005, 0.05, 0.1, 1.5, 1.0
    assert abs(T.sigma_bar_L(alpha, lam, ap, h, 508) - 9.65725e-3) < 2e-8
    assert abs(T.sigma_bar_L(alpha, 0.0, ap, h, 508) - 4.65725e-3) < 2e-8
    dc = T.design_gains(alpha, lam, ap, k1, k2)
    assert abs(dc["sigma_cert"] - lam) < 1e-12
    assert T.certify_gains_continuous(alpha, lam, ap, k1, k2, dc["l1"], dc["l2"], dc["sigma_d"]).certified
    dd = T.design_gains(alpha, lam, ap, k1, k2, h=h, N_L=508)
    assert abs(dd["sigma_cert"] - 9.6572e-3) < 1e-6
    assert T.certify_gains_discrete(alpha, lam, ap, k1, k2, dd["l1"], dd["l2"], dd["sigma_d"], h, 508).certified
    df = T.design_gains(alpha, lam, ap, k1, k2, h=h)
    assert abs(df["sigma_cert"] - lam) < 1e-12
    # sigma* by bisection agrees with the design program for pinned gains
    assert abs(T.sigma_star(alpha, lam, ap, k1, k2, dd["l1"], dd["l2"], h=h, N_L=508) - dd["sigma_cert"]) < 1e-6


# ---------------------------------------------------------------- error system
AL, LAM, AP, K1, K2, H = 0.6, 0.005, 0.1, 0.3, 1.2, 1.0


def _switching_kappa(N, seed=0, dwell=20):
    rng = np.random.default_rng(seed)
    return np.repeat(rng.choice([K1, K2], size=N // dwell + 2), dwell)[:N + 1]


@pytest.mark.parametrize("N_L", [None, 500])
def test_certified_gains_bounded_weighted_error(N_L):
    """thm:m4b:certificate (i) with switching kappa over 5000 s; a violating l1 fails."""
    N = 5000
    l1, l2 = 0.05, 0.02
    sstar = T.sigma_star(AL, LAM, AP, K1, K2, l1, l2, h=H, N_L=N_L)
    assert sstar is not None and sstar >= (LAM if N_L is None else LAM) - 1e-12
    sig = 0.9 * min(sstar, LAM)
    kap = _switching_kappa(N)
    t = H * np.arange(N + 1)
    for ez0, ep0 in [(0.3, 0.0), (0.3, 0.02), (-0.2, 0.05), (0.0, 0.02)]:
        r = T.simulate_error_system(AL, LAM, AP, l1, l2, kap, H, N, ez0, ep0, N_L=N_L)
        bz, bp = T.discrete_transient_bound(AL, LAM, AP, K1, K2, l1, l2, sig, H, N_L, ez0, ep0, np.arange(N + 1))
        assert np.all(np.abs(r["ez"]) <= bz * (1 + 1e-12))
        assert np.all(np.abs(r["ep"]) <= bp * (1 + 1e-12))
        w = np.exp(sig * t) * (np.abs(r["ez"]) + np.abs(r["ep"]))
        assert np.max(w) <= 1.5 * (abs(ez0) + abs(ep0)) + 1e-12
        assert w[-1] < 0.01 * max(w[0], 1e-12) or w[-1] < 1e-3
    # violating gain: l1 k2 < sigma -> not certified, weighted error grows
    l1v = 0.003
    assert not T.certify_gains_discrete(AL, LAM, AP, K1, K2, l1v, l2, sig, H, N_L).certified
    r = T.simulate_error_system(AL, LAM, AP, l1v, l2, kap, H, N, 0.3, 0.02, N_L=N_L)
    w = np.exp(sig * t) * (np.abs(r["ez"]) + np.abs(r["ep"]))
    assert w[-1] > 100 * w[0]


def test_continuous_limit_weighted_bound():
    """thm:m3a:convergence (i) at sigma = lambda: |e(t)|_v <= C e^{-sigma t}|e(0)|_v, switching kappa."""
    alpha, lam, ap, k1, k2, l1, l2 = 0.6, 0.05, 0.5, 0.3, 1.2, 1.0, 0.08
    assert T.certify_gains_continuous(alpha, lam, ap, k1, k2, l1, l2, lam).certified
    # geometric weights: C = 1 + q2 max(1, q1/(1-theta)) = max(1 + q2, 1/(1-theta)) (eq:m3a:constC)
    Cg, vg, theta = T.continuous_transient_constant(alpha, lam, ap, k1, k2, l1, l2, lam, use_cone=False)
    assert abs(Cg - 2.959) < 1e-3 and abs(theta - 0.662) < 1e-3
    q2 = l2 * k2 / ((ap + l2) * vg[1])
    assert abs(Cg - max(1 + q2, 1 / (1 - theta))) < 1e-12
    # prop:m3a:Cone: at sigma = lambda the constant is C = 1 (weights in the Cone interval)
    C, v, _ = T.continuous_transient_constant(alpha, lam, ap, k1, k2, l1, l2, lam)
    assert C == 1.0 and l2 * k2 / (ap + l2) < v[1] < (l1 * k1 - lam) / l1
    kap = lambda s: k1 if int(s / 0.5) % 2 == 0 else k2
    for e0 in [(0.0, 1.0), (1.0, 0.0), (0.5, -0.5)]:
        r = T.simulate_error_system(alpha, lam, ap, l1, l2, kap, 1.0, 300, e0[0], e0[1],
                                    mode="continuous", refine=20)
        for CC, vv in ((Cg, vg), (C, v)):
            nv = np.maximum(np.abs(r["ez"]) / vv[0], np.abs(r["ep"]) / vv[1])
            ratio = np.exp(lam * r["t"]) * nv / nv[0]
            assert np.max(ratio) <= CC * (1 + 1e-3)   # 1e-3: first-order GL approximation
            assert ratio[-1] < 0.2              # e^{lambda t} e -> 0 (part (ii))


def test_plant_bound_and_soc_gains():
    """eq:m1:plantbound = eq:m3a:Bp and the gains eq:m2:gain-zp / eq:m2:gain-zp-h, eq:m4b:gains."""
    alpha, lam, ap, bp, Imax, k1, k2, l1, l2, h, NL = 0.6, 0.005, 0.1, 1.5e-3, 3.0, 0.3, 1.2, 0.02, 0.01, 1.0, 300
    Bp = T.plant_bound(ap, bp, lam, alpha, Imax, Vp0_bar=0.01)
    assert abs(Bp - (0.01 + bp * Imax / (ap + lam ** alpha))) < 1e-15
    x = T.simulate_tempered_element(alpha, lam, ap, bp, np.full(3001, Imax), h, x0=0.01)
    assert np.max(np.abs(x)) <= T.plant_bound(ap, bp, lam, alpha, Imax, 0.01) * (1 + 1e-12) \
        or np.max(np.abs(x)) <= 0.01 + bp * Imax / (ap + T.mu_h(alpha, lam, 0.0, h))   # discrete DC gain
    g = T.soc_gain(alpha, lam, ap, k1, k2, l2)
    M0 = T.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, 0.0)
    assert abs(g - np.linalg.inv(-M0)[0, 1]) < 1e-9 * g           # gamma_zp = [-M_0^{-1}]_12
    gh = T.soc_gain(alpha, lam, ap, k1, k2, l2, h=h)
    ghL = T.soc_gain(alpha, lam, ap, k1, k2, l2, h=h, N_L=NL)
    MhL = T.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, 0.0, h=h, N_L=NL)
    assert abs(ghL - np.linalg.inv(-MhL)[0, 1]) < 1e-9 * ghL      # entry of eq:m4b:gains
    assert ghL <= gh and gh > g                                     # cor:m2:soc (iv)
    assert abs(T.soc_gain(alpha, lam, ap, k1, k2, l2, h=1e-4) / g - 1) < 1e-3   # h -> 0 limit


def test_bias_steady_state_with_current():
    """eq:m3c:bias = eq:m4b:steady: implemented finite-memory observer with constant I and bias,
    plant residual r_n and truncation residual R_L included; offset nonzero even for dI = 0."""
    alpha, lam, ap, bp, R0, Qn, eta, h = 0.6, 0.005, 0.05, 1.5e-3, 0.05, 2.5, 1.0, 1.0
    l1, l2, kap, I, N, NL = 0.2, 0.004, 0.5, 2.0, 6000, 200
    beta = eta / (3600 * Qn)
    t = h * np.arange(N + 1)
    Vss = bp * I / (ap + lam ** alpha)
    Vp = Vss * (1.0 - np.exp(-t / 40.0))                 # any plant sequence with limit V_ss
    r = T.gl_derivative(Vp, alpha, lam, h) + ap * Vp - bp * I
    RL = T.gl_derivative(Vp, alpha, lam, h) - T.gl_derivative(Vp, alpha, lam, h, N_L=NL)
    for dI in (0.05, 0.0):
        wz = (l1 * R0 - beta) * dI
        wp = (l2 * R0 - bp) * dI + r - RL
        sim = T.simulate_error_system(alpha, lam, ap, l1, l2, kap, h, N, 0.0, 0.0, wz, wp, N_L=NL)
        ss = T.bias_steady_state(dI, kap, R0, ap, bp, l1, l2, eta, Qn, lam, alpha, h=h, N_L=NL, I=I)
        assert abs(sim["ez"][-1] - ss) < 1e-6 * max(abs(ss), 1e-3)
    assert abs(ss) > 0                                   # dI = 0: current-proportional offset


def test_error_recursion_matches_observer():
    """prop:m4b:errorrec: implemented observer vs plant (affine OCV) -> error recursion to 1e-12."""
    alpha, lam, ap, bp, R0, Qn, eta, h, N, NL = 0.6, 0.005, 0.1, 1.5e-3, 0.05, 2.0, 1.0, 1.0, 1500, 300
    l1, l2 = 0.02, 0.01
    kap = 0.5
    U = lambda z: 3.3 + kap * z
    rng = np.random.default_rng(3)
    I = np.repeat(rng.uniform(-3, 3, N // 50 + 2), 50)[:N + 1]
    dI, v = 0.05, 1e-3 * rng.uniform(-1, 1, N + 1)
    beta = eta / (3600 * Qn)
    Vp = T.simulate_tempered_element(alpha, lam, ap, bp, I, h, x0=0.01)   # plant samples (exact recursion)
    z = 0.5 + h * beta * np.concatenate([[0.0], np.cumsum(I[:-1])])
    Vt = U(z) + R0 * I + Vp + v
    Im = I + dI
    om = T.gl_weights(alpha, lam, h, NL)
    zh = np.empty(N + 1)
    Vph = np.zeros(N + 1)
    Vth = np.empty(N + 1)
    zh[0] = 0.8
    Vth[0] = U(zh[0]) + R0 * Im[0]
    for n in range(1, N + 1):
        zh[n] = zh[n - 1] + h * (beta * Im[n - 1] + l1 * (Vt[n - 1] - Vth[n - 1]))
        m = min(n, NL)
        Vph[n] = (h ** alpha * (bp * Im[n] + l2 * (Vt[n] - U(zh[n]) - R0 * Im[n]))
                  - np.dot(om[1:m + 1], Vph[n - 1::-1][:m])) / (1 + h ** alpha * (ap + l2))
        Vth[n] = U(zh[n]) + R0 * Im[n] + Vph[n]
    # plant: D_h Vp = -ap Vp + bp I exactly (r = 0), R_L = D_h - D_{h,L}
    RL = T.gl_derivative(Vp, alpha, lam, h) - T.gl_derivative(Vp, alpha, lam, h, N_L=NL)
    wz = (l1 * R0 - beta) * dI - l1 * v
    wp = (l2 * R0 - bp) * dI - l2 * v - RL
    r = T.simulate_error_system(alpha, lam, ap, l1, l2, kap, h, N, z[0] - zh[0], Vp[0], wz, wp, N_L=NL)
    assert np.max(np.abs(r["ez"] - (z - zh))) < 1e-12
    assert np.max(np.abs(r["ep"] - (Vp - Vph))) < 1e-12
    # truncation residual within thm:m2:truncation with the physical bound B_p
    Bp = 0.01 + bp * 3 / (ap + lam ** alpha)
    assert np.max(np.abs(Vp)) <= Bp
    assert np.max(np.abs(RL)) <= float(T.truncation_bound(alpha, lam, NL * h, Bp, "gamma"))


def test_bias_steady_state_formula():
    """rem:m3c:bias / cor:m4a:bias: simulated constant-bias limit of the implemented error recursion
    equals the mu_h(0) formula; Coulomb drift eta dI t/(3600 Qn) is larger."""
    alpha, lam, ap, bp, R0, Qn, eta, h = 0.6, 0.005, 0.05, 1.5e-3, 0.05, 2.5, 1.0, 1.0
    l1, l2, kap, dI, N = 0.2, 0.004, 0.5, 0.05, 12000
    beta = eta / (3600 * Qn)
    wz = (l1 * R0 - beta) * dI
    # the plant polarisation reacts to I (not to I_m): the bias enters as -bp dI in w_p
    wp = (l2 * R0 - bp) * dI
    r = T.simulate_error_system(alpha, lam, ap, l1, l2, kap, h, N, 0.0, 0.0, wz, wp)
    ss = T.bias_steady_state(dI, kap, R0, ap, bp, l1, l2, eta, Qn, lam, alpha, h=h)
    assert abs(r["ez"][-1] / ss - 1) < 1e-6
    ssc = T.bias_steady_state(dI, kap, R0, ap, bp, l1, l2, eta, Qn, lam, alpha)
    assert abs(ssc / ss - 1) < 1e-3
    assert eta * dI * N * h / (3600 * Qn) > 5 * abs(ss)


def test_cost_per_sample():
    c = T.cost_per_sample(508)
    assert c["macs"] == 520 and c["bytes"] == 8 * (3 * 508 + 8) and c["bytes_min"] == 8 * 516
