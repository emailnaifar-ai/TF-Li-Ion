"""Adversarial tests of the canonical data layer (src/tfso/data.py).

Run from the project root:  python -m pytest tests/test_data.py -q
Requires the CALCE records listed in data_manifest.json (data_raw/, data_processed/; not redistributed) and
results/capacity.json (scripts/01_audit.py); skipped with a reason when the records are absent.
The expected capacities below are regression values of the current method (median CV-end-to-cutoff
throughput of the SP2 dynamic files); the tests recompute them from the raw files as well.
"""
import json
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import data as D  # noqa: E402



def _calce_data_available() -> bool:
    """True when every workbook and processed CSV listed in data_manifest.json is present. The public repository
    ships the manifest but not the CALCE records (README, data acquisition), so these tests skip on a clean clone."""
    if not D.MANIFEST_PATH.exists():
        return False
    try:
        files = json.loads(D.MANIFEST_PATH.read_text(encoding="utf-8"))["files"]
    except (OSError, ValueError, KeyError):
        return False
    return bool(files) and all((ROOT / "data_raw" / e["source_folder"] / e["source_workbook"]).exists()
                               and (ROOT / e["processed_csv"]).exists() for e in files.values())


pytestmark = pytest.mark.skipif(
    not _calce_data_available(),
    reason="CALCE records not found: place the 21 archives in dataset/, then run "
           "'python scripts/reproduce_all.py --extract --dry-run' and 'python scripts/00_convert_raw.py'")

CAP_PATH = ROOT / "results" / "capacity.json"
ID_FILE = "SP2_25C_DST_80SOC"
RESAMPLE_FILES = ["SP2_25C_DST_80SOC", "SP2_0C_US06_50SOC", "SP2_45C_FUDS_80SOC"]
OCV_IDS = D.ids_by(test_type="incremental_ocv")


@lru_cache(maxsize=None)
def _raw(lid: str) -> pd.DataFrame:
    return D.load_raw(lid)


def raw(lid: str) -> pd.DataFrame:
    return _raw(lid).copy()


@lru_cache(maxsize=None)
def _profile(lid: str) -> dict:
    return D.get_dynamic_profile(lid, df=_raw(lid))


@lru_cache(maxsize=1)
def cap() -> dict:
    with open(CAP_PATH, "r", encoding="utf-8") as fh:
        return json.load(fh)


# ------------------------------------------------------------------------------------------ catalog / verify
def test_catalog_complete_and_splits_disjoint():
    assert len(D.CATALOG) == 33
    assert len(D.ids_by(test_type="dynamic")) == 24
    assert len(D.ids_by(test_type="incremental_ocv")) == 6
    assert len(D.ids_by(test_type="initial_capacity")) == 3
    assert all(v["split"] != "unassigned" for v in D.CATALOG.values())
    assert sorted(D.ids_by(split="identification")) == ["SP2_0C_DST_80SOC", "SP2_25C_DST_80SOC", "SP2_45C_DST_80SOC"]
    assert sorted(D.ids_by(split="validation")) == ["SP2_0C_DST_50SOC", "SP2_25C_DST_50SOC", "SP2_45C_DST_50SOC"]
    assert len(D.ids_by(split="test")) == 18


@pytest.mark.parametrize("lid", D.LOGICAL_IDS)
def test_every_file_passes_verification(lid):
    chk = D.verify_file(lid, raw(lid))
    assert chk["passed"] and chk["failed_checks"] == []
    assert chk["data_point_strictly_increasing"]


def test_sign_flip_is_detected_numerically():
    df = raw(ID_FILE)
    df["Current(A)"] = -df["Current(A)"]
    chk = D.verify_file(ID_FILE, df, raise_on_fail=False)
    assert chk["failed_checks"] == ["sign_convention_verified"]  # the ONLY failing check is the numerical one
    sc = chk["sign_convention"]
    assert sc["frac_charge_capacity_increasing_when_I_positive"] < 0.05
    with pytest.raises(D.DataVerificationError):
        D.verify_file(ID_FILE, df)


def test_sign_flip_in_temp_csv_copy_raises(tmp_path, monkeypatch):
    df = raw(ID_FILE)
    df["Current(A)"] = -df["Current(A)"]
    p = tmp_path / "flipped.csv"
    df.to_csv(p, index=False)
    monkeypatch.setitem(D.CATALOG, ID_FILE, {**D.CATALOG[ID_FILE], "processed_csv": str(p)})
    with pytest.raises(D.DataVerificationError) as ei:
        D.verify_file(ID_FILE)
    assert "sign_convention_verified" in str(ei.value)


@pytest.mark.parametrize("col", ["Current(A)", "Charge_Capacity(Ah)", "Step_Index", "Data_Point", "Test_Time(s)"])
def test_missing_column_in_temp_csv_copy_raises(tmp_path, monkeypatch, col):
    df = raw(ID_FILE).drop(columns=[col])
    p = tmp_path / "missing.csv"
    df.to_csv(p, index=False)
    monkeypatch.setitem(D.CATALOG, ID_FILE, {**D.CATALOG[ID_FILE], "processed_csv": str(p)})
    with pytest.raises(D.DataVerificationError) as ei:
        D.verify_file(ID_FILE, df)  # in-memory frame
    assert "all_17_columns_present" in str(ei.value)
    with pytest.raises(D.DataVerificationError):
        D.verify_file(ID_FILE)  # read back from the temp copy (was a bare KeyError for Data_Point / Test_Time)


def test_duplicated_row_fails_verification():
    df = raw(ID_FILE)
    k = int(np.where(df["Step_Index"].to_numpy() == 7)[0][100])
    dup = pd.concat([df.iloc[: k + 1], df.iloc[[k]], df.iloc[k + 1:]], ignore_index=True)
    chk = D.verify_file(ID_FILE, dup, raise_on_fail=False)
    assert "data_point_strictly_increasing" in chk["failed_checks"]


# ------------------------------------------------------------------------------------------ resampling
@pytest.mark.parametrize("lid", RESAMPLE_FILES)
def test_resampling_preserves_step7_charge(lid):
    p = _profile(lid)
    m = p["meta"]
    h = m["h_s"]
    assert p["t"][0] == 0.0 and np.allclose(np.diff(p["t"]), h)
    # net Ah through step 7: grid vs trapezoid of the irregular record, and vs the Arbin columns
    assert abs(m["net_Ah_grid"] / m["net_Ah_trapz"] - 1) < 1e-3
    assert abs(m["net_Ah_grid"] / m["net_Ah_arbin"] - 1) < 5e-3
    # cumulative charge is conserved at EVERY grid point, not just at the end
    q_raw = np.concatenate([[0.0], np.cumsum(0.5 * (p["I_raw"][1:] + p["I_raw"][:-1]) * np.diff(p["t_raw"]))])
    q_grid = np.concatenate([[0.0], np.cumsum(p["I"][:-1] * h)])
    assert np.max(np.abs(q_grid - np.interp(p["t"], p["t_raw"], q_raw))) < 1e-6
    # |I| throughput on grid intervals without a current sign reversal
    th = m["throughput"]
    assert abs(th["grid_reversal_free_Ah"] / th["raw_reversal_free_Ah"] - 1) < 1e-3
    # documented limitation: gross per-direction Ah is lower on the grid (mean current in reversal intervals)
    assert th["grid_charge_Ah"] <= th["raw_charge_Ah_trapz"] + 1e-9
    assert th["grid_discharge_Ah"] <= th["raw_discharge_Ah_trapz"] + 1e-9
    assert abs(th["grid_discharge_Ah"] / th["raw_discharge_Ah_trapz"] - 1) < 0.02


@pytest.mark.parametrize("lid", RESAMPLE_FILES)
def test_voltage_interpolation_stays_between_neighbours(lid):
    p = _profile(lid)
    tr, Vr, tu, Vu = p["t_raw"], p["V_raw"], p["t"], p["V"]
    j = np.clip(np.searchsorted(tr, tu, side="right") - 1, 0, len(tr) - 1)
    j1 = np.clip(j + 1, 0, len(tr) - 1)
    lo = np.minimum(Vr[j], Vr[j1]) - 1e-12
    hi = np.maximum(Vr[j], Vr[j1]) + 1e-12
    assert np.all((Vu >= lo) & (Vu <= hi))
    exact = np.isin(tu, tr)
    assert np.allclose(Vu[exact], Vr[np.searchsorted(tr, tu[exact])])


def test_step8_rows_are_dropped_and_cannot_leak():
    df = raw(ID_FILE)
    st = df["Step_Index"].to_numpy()
    p0 = _profile(ID_FILE)
    assert p0["meta"]["n_raw_step7"] == int((st == 7).sum())
    assert p0["meta"]["logger_rows"]["n_dropped"] == int((st == 8).sum()) > 0
    # poison the step-8 rows: huge current / voltage; the profile and the reference SOC must not change
    bad = df.copy()
    m8 = bad["Step_Index"] == 8
    bad.loc[m8, "Current(A)"] = -99.0
    bad.loc[m8, "Voltage(V)"] = 9.9
    p1 = D.get_dynamic_profile(ID_FILE, df=bad)
    assert np.array_equal(p0["I"], p1["I"]) and np.array_equal(p0["V"], p1["V"])
    r0 = D.reference_soc(ID_FILE, df=df, profile=p0)
    r1 = D.reference_soc(ID_FILE, df=bad, profile=p1)
    assert np.array_equal(r0["soc_ref"], r1["soc_ref"])


def test_duplicate_timestamps_handled_deterministically():
    df = raw(ID_FILE)
    k = int(np.where(df["Step_Index"].to_numpy() == 7)[0][500])
    extra = df.iloc[[k]].copy()
    extra["Current(A)"] = 3.3
    extra["Voltage(V)"] = 3.3
    dup = pd.concat([df.iloc[: k + 1], extra, df.iloc[k + 1:]], ignore_index=True)  # duplicate AFTER the original
    pa = D.get_dynamic_profile(ID_FILE, df=dup)
    pb = D.get_dynamic_profile(ID_FILE, df=dup)
    p0 = _profile(ID_FILE)
    assert pa["meta"]["n_duplicate_timestamps_removed"] == 1
    assert np.array_equal(pa["I"], pb["I"]) and np.array_equal(pa["V"], pb["V"])  # deterministic
    assert np.array_equal(pa["I"], p0["I"]) and np.array_equal(pa["V"], p0["V"])  # first occurrence kept
    ra = D.reference_soc(ID_FILE, df=dup, profile=pa)
    assert np.allclose(ra["soc_ref"], D.reference_soc(ID_FILE, df=df, profile=p0)["soc_ref"])
    # when the conflicting sample comes first in file order, it is the one kept (documented rule: keep first)
    dup2 = pd.concat([df.iloc[:k], extra, df.iloc[k:]], ignore_index=True)
    pc = D.get_dynamic_profile(ID_FILE, df=dup2)
    t0 = pc["meta"]["t0_abs_s"]
    i = int(np.searchsorted(pc["t_raw"], df["Test_Time(s)"].iloc[k] - t0))
    assert pc["I_raw"][i] == 3.3


# ------------------------------------------------------------------------------------------ reference SOC
@pytest.mark.parametrize("lid", ["SP2_0C_DST_80SOC", "SP2_25C_DST_80SOC", "SP2_45C_DST_80SOC", "SP2_25C_DST_50SOC"])
def test_reference_soc_anchor_and_pre_profile_discharge(lid):
    df = raw(lid)
    st = df["Step_Index"].to_numpy()
    r = D.reference_soc(lid, df=df, profile=_profile(lid))
    a = r["anchor"]
    ia = int(np.where(st == 3)[0][-1])
    assert a["row"] == ia and st[ia + 1] == 4  # last CV sample, followed by the rest
    assert abs(a["V"] - 4.2) < 0.005 and 0 < a["I_A"] < 0.05  # CV end: 4.2 V, ~0.02 A taper
    # SOC = 1 at the anchor: q is measured from the anchor, so SOC(anchor) = 1 + 0 / Q_ref
    # the pre-profile 1 A discharge (step 5) is inside the Coulomb count
    seg = D.segments(lid, df)
    s5 = seg[seg.step == 5].iloc[0]
    assert abs(r["net_Ah_pre_profile"] + s5.Ah_discharge_arbin) < 2e-3
    frac = 1.0 - D.CATALOG[lid]["start_soc_label"] / 100.0
    sched = 1.8 if D.CATALOG[lid]["temperature_C"] == 0 else 2.0  # schedule capacity (0 C schedules use 1.8 Ah)
    assert abs(s5.Ah_discharge_arbin - frac * sched) < 5e-3
    assert abs(r["soc_profile_start"] - (1.0 + r["net_Ah_pre_profile"] / r["Q_ref_Ah"])) < 1e-4
    assert abs(r["soc_profile_start"] - D.CATALOG[lid]["start_soc_label"] / 100.0) < 0.03


@pytest.mark.parametrize("lid", D.ids_by(test_type="dynamic"))
def test_reference_soc_agrees_with_arbin_columns(lid):
    r = D.reference_soc(lid, df=raw(lid))
    q_end = abs(r["net_Ah_from_full"][-1])
    assert r["cross_check"]["max_abs_diff_Ah_trapz_vs_arbin"] / q_end < 5e-3
    assert np.max(np.abs(r["soc_ref"] - r["soc_arbin"])) < 5e-3


def test_reference_soc_band_formula():
    lid = ID_FILE
    df = raw(lid)
    r = D.reference_soc(lid, df=df, profile=_profile(lid))
    c = cap()["Q_ref_T_SP2"]["25"]
    Q, u = c["Q_ref_Ah"], c["u_Q_Ah"]
    assert r["Q_ref_Ah"] == pytest.approx(Q) and r["u_Q_Ah"] == pytest.approx(u)
    assert r["q_ref_rel_unc"] == pytest.approx(u / Q) and r["current_offset_A"] == pytest.approx(0.005)
    t_abs = _profile(lid)["meta"]["t0_abs_s"] + r["t"]
    band = np.abs(r["net_Ah_from_full"]) / Q * (u / Q) + 0.005 * (t_abs - r["anchor"]["t_s"]) / (3600.0 * Q)
    assert np.allclose(r["unc_total_linear"], band, rtol=1e-12, atol=1e-15)
    assert np.allclose(r["soc_hi"] - r["soc_ref"], band) and np.allclose(r["soc_ref"] - r["soc_lo"], band)
    # an explicit Q_ref without an explicit relative uncertainty falls back to the config value
    r2 = D.reference_soc(lid, Q_ref_Ah=2.0, df=df, profile=_profile(lid))
    assert r2["q_ref_rel_unc"] == pytest.approx(D.load_config()["dataset"]["reference_soc_band"]["fallback_q_ref_rel_unc"])


# ------------------------------------------------------------------------------------------ capacities
def test_Q_ref_Q_id_values_and_recomputation():
    c = cap()
    assert c["method"] == D.load_config()["dataset"]["reference_capacity"]["method"] == "sp2_dynamic_cv_end_to_cutoff_throughput_median"
    expected = {"0": (1.8138, 1.7529, 1.8934), "25": (2.0233, 1.9964, 2.0577), "45": (2.0812, 2.0611, 2.0889)}
    for T, (med, lo, hi) in expected.items():
        e = c["Q_ref_T_SP2"][T]
        assert e["n_files"] == 8 and len(e["files"]) == 8 and e["all_end_at_cutoff"]
        assert round(e["Q_ref_Ah"], 4) == med and round(e["Q_min_Ah"], 4) == lo and round(e["Q_max_Ah"], 4) == hi
        assert e["u_Q_Ah"] == pytest.approx(0.5 * (e["Q_max_Ah"] - e["Q_min_Ah"]))
        assert abs(e["Q_ref_trapz_Ah"] / e["Q_ref_Ah"] - 1) < 5e-3  # trapezoid cross-check
        # recompute from the raw files (not from the JSON)
        q = [D.cv_to_cutoff_throughput(k, raw(k))["Q_arbin_Ah"] for k in e["files"]]
        assert e["Q_ref_Ah"] == pytest.approx(float(np.median(q)), abs=1e-12)
        idf = f"SP2_{T}C_DST_80SOC"
        assert c["Q_id_T_SP2"][T]["logical_id"] == idf and D.CATALOG[idf]["split"] == "identification"
        assert c["Q_id_T_SP2"][T]["Q_id_Ah"] == pytest.approx(D.cv_to_cutoff_throughput(idf, raw(idf))["Q_arbin_Ah"], abs=1e-12)
    cc = c["cell_capacity_25C_initial_Ah"]
    assert round(cc["SP1"]["Q_Ah"], 4) == 2.0094 and round(cc["SP3"]["Q_Ah"], 4) == 1.9775
    assert round(cc["SP2"]["Q_Ah"], 4) == 2.0283 and round(cc["SP2"]["Q_before_unlogged_pause_Ah"], 4) == 2.0048
    assert "never" in c["leakage_statement"].lower()


def test_throughput_ends_at_cutoff_and_matches_arbin():
    for lid in D.ids_by(test_type="dynamic"):
        e = D.cv_to_cutoff_throughput(lid, raw(lid))
        assert e["ends_at_cutoff"] and e["n_rows_after_end"] == 0
        assert abs(e["Q_arbin_Ah"] / e["Q_trapz_Ah"] - 1) < 5e-3


# ------------------------------------------------------------------------------------------ relaxations / OCV
@pytest.mark.parametrize("lid", OCV_IDS)
def test_relaxation_time_origin_and_soc_labels(lid):
    df = raw(lid)
    I = df["Current(A)"].to_numpy()
    t = df["Test_Time(s)"].to_numpy()
    Qc, Qd = df["Charge_Capacity(Ah)"].to_numpy(), df["Discharge_Capacity(Ah)"].to_numpy()
    rel = D.get_relaxations(lid, df)
    cap_ = D.own_capacity(lid, df)
    ia, Qtot = cap_["anchor_row"], cap_["Q_total_discharge_arbin_Ah"]
    assert len(rel) >= 18
    for r in rel:
        i0 = r["i_start"]
        assert I[i0] == 0.0 and abs(I[i0 - 1]) > 0.9  # first I = 0 sample; previous sample under 1 A
        assert np.all(I[i0: r["i_end"] + 1] == 0.0)
        assert r["t_interruption_abs_s"] == t[i0 - 1]  # t measured from the last nonzero-current sample
        assert r["t"][0] == pytest.approx(t[i0] - t[i0 - 1]) and 0 < r["t"][0] < 1.1
        assert np.all(np.diff(r["t"]) > 0)
        net = (Qd[i0] - Qd[ia]) - (Qc[i0] - Qc[ia])
        assert r["soc_label"] == pytest.approx(1.0 - net / Qtot, abs=1e-12)
    dis = [r for r in rel if r["pulse"]["direction"] == "discharge"]
    for a, b in zip(dis[:-1], dis[1:]):  # cumulative Ah steps by the pulse charge (a few uAh may sit in 1-sample
        # transition segments between a rest and the next pulse, e.g. 4.3 uAh once in SP1_IC_OCV_0C)
        assert b["net_discharged_Ah_from_full"] - a["net_discharged_Ah_from_full"] == pytest.approx(b["pulse"]["Ah_arbin"], abs=2e-5)
    assert min(r["soc_label"] for r in dis) == pytest.approx(0.0, abs=1e-6)


@pytest.mark.parametrize("lid", OCV_IDS)
def test_ocv_points_both_branches_in_order(lid):
    pts = D.get_ocv_points(lid, raw(lid))
    d, c = pts[pts.direction == "discharge"], pts[pts.direction == "charge"]
    assert len(d) == 10 and len(c) >= 8
    assert np.all(np.diff(d.soc.to_numpy()) < 0) and np.all(np.diff(d.V_relaxed.to_numpy()) < 0)
    assert np.all(np.diff(c.soc.to_numpy()) > 0) and np.all(np.diff(c.V_relaxed.to_numpy()) > 0)
    assert d.index.max() < c.index.min()  # discharge branch first, then charge branch
    assert pts.direction.iloc[0] == "full_after_cv" and pts.soc.iloc[0] == pytest.approx(1.0, abs=1e-6)
    assert (d.soc.min() == pytest.approx(0.0, abs=1e-6))


@pytest.mark.parametrize("lid", ["SP1_IC_OCV_0C", "SP3_IC_OCV_0C"])
def test_0C_pulses_of_0p18Ah_without_hard_coding(lid):
    df = raw(lid)
    rel = D.get_relaxations(lid, df)
    dis = [r for r in rel if r["pulse"]["direction"] == "discharge"]
    full = [r["pulse"]["Ah_arbin"] for r in dis if r["pulse"]["V_end_under_load"] > 2.6]
    assert len(dis) == 10 and 0.17 < np.median(full) < 0.19
    Qtot = D.own_capacity(lid, df)["Q_total_discharge_arbin_Ah"]
    assert Qtot == pytest.approx(sum(r["pulse"]["Ah_arbin"] for r in dis), abs=1e-3)
    steps = -np.diff([1.0] + [r["soc_label"] for r in dis])
    assert np.allclose(steps, [r["pulse"]["Ah_arbin"] / Qtot for r in dis], atol=5e-5)


def test_sp1_25C_truncated_file_handled():
    lid = "SP1_IC_OCV_25C"
    df = raw(lid)
    seg = D.segments(lid, df)
    last = seg.iloc[-1]
    assert int(last.cycle) == 18 and not (last.type == "rest" and last.duration_s > 3600)
    rel = D.get_relaxations(lid, df)
    assert sum(r["pulse"]["direction"] == "discharge" for r in rel) == 10
    assert sum(r["pulse"]["direction"] == "charge" for r in rel) == 8
    pts = D.get_ocv_points(lid, df)
    assert "full_after_cv" not in set(pts.direction.iloc[1:])  # no final CV point: the file is truncated
    inv = D.audit_file(lid, df)
    assert any("truncated" in a for a in inv["anomalies"])


def test_cutoff_flags_of_ocv_files():
    exp = {"SP1_IC_OCV_0C": False, "SP1_IC_OCV_25C": True, "SP1_IC_OCV_45C": False,
           "SP3_IC_OCV_0C": True, "SP3_IC_OCV_25C": True, "SP3_IC_OCV_45C": False}
    for lid, reached in exp.items():
        c = D.own_capacity(lid, raw(lid))
        assert c["cutoff_2p5V_reached"] is reached, lid
    assert D.own_capacity("SP1_IC_OCV_45C", raw("SP1_IC_OCV_45C"))["last_discharge_end_V"] == pytest.approx(3.03, abs=0.01)
    assert D.own_capacity("SP3_IC_OCV_45C", raw("SP3_IC_OCV_45C"))["last_discharge_end_V"] == pytest.approx(3.20, abs=0.01)
    assert D.own_capacity("SP1_IC_OCV_0C", raw("SP1_IC_OCV_0C"))["last_discharge_end_V"] == pytest.approx(2.577, abs=0.001)
    notes = " ".join(cap()["notes"])
    for lid in ("SP1_IC_OCV_45C", "SP3_IC_OCV_45C", "SP1_IC_OCV_0C"):
        assert lid in notes and "lower bound" in notes
    sup = cap()["superseded_ocv_ratio_method"]
    assert "SUPERSEDED" in sup["status"]
