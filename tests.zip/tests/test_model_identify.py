"""Synthetic checks of src/tfso/model.py (input timing, FFT simulation, step response) and src/tfso/identify.py
(coordinates, HAC effective sample size, profile-interval inversion, block resampling).  No data files needed."""
import math
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from tfso import identify as ID  # noqa: E402
from tfso import model as MD  # noqa: E402


def _current(n=3000, seed=1):
    rng = np.random.default_rng(seed)
    return np.repeat(rng.uniform(-3, 2, n // 20 + 1), 20)[:n]


@pytest.mark.parametrize("lag", [0, 1])
@pytest.mark.parametrize("alpha,lam,NL", [(0.4, 0.0, None), (0.6, 2e-3, None), (0.3, 1e-4, 500), (1.0, 1e-3, None)])
def test_fft_matches_direct_with_lag(alpha, lam, NL, lag):
    I = _current()
    u = MD.drive(I, lag)
    a, b = 1.0 / (0.05 * 800.0), 1.0 / 800.0
    vd = MD.polarisation_direct(alpha, lam, a, b, u, 1.0, NL)
    vf = MD.polarisation_fft(alpha, lam, a, b, u, 1.0, NL)
    assert np.max(np.abs(vd - vf)) < 1e-9


def test_drive_is_a_pure_delay():
    I = _current(50)
    u1 = MD.drive(I, 1)
    assert u1[0] == 0.0 and np.array_equal(u1[1:], I[:-1])
    u0 = MD.drive(I, 0)
    assert u0[0] == 0.0 and np.array_equal(u0[1:], I[1:])


def test_2rc_causal_is_exact_zoh():
    # constant current from t_1 on: exact ZOH response R (1 - e^{-(t - t_1)/tau}) at t_n
    R, tau = 0.03, 20.0
    I = np.zeros(200); I[1:] = 1.0
    v = MD.polarisation_2rc(R, tau, MD.drive(I, 1), 1.0)
    t = np.arange(200) - 1.0
    exact = np.where(t > 0, R * (1 - np.exp(-t / tau)), 0.0)
    assert np.max(np.abs(v - exact)) < 1e-15


def test_step_response_same_lag_for_all_families():
    p = MD.TFOParams(0.5, 0.0, 0.02, 0.05, 500.0)
    r_c = MD.step_response(p, "causal")
    r_f = MD.step_response(p, "implicit_forward")
    g = p.b_p / (1 + p.a_p)                     # h = 1: h^alpha b/(1 + h^alpha a)
    assert r_c["R_0s_Ohm"] == pytest.approx(p.R0) and r_c["R_1s_Ohm"] == pytest.approx(p.R0 + g)
    assert r_f["R_0s_Ohm"] == pytest.approx(p.R0 + g)     # anticipating convention: feed-through at the onset
    q = MD.TwoRCParams(0.02, 0.01, 5.0, 0.02, 100.0)
    rq = MD.step_response(q, "causal")
    assert rq["R_0s_Ohm"] == pytest.approx(0.02)
    assert rq["R_1s_Ohm"] == pytest.approx(0.02 + 0.01 * (1 - math.exp(-0.2)) + 0.02 * (1 - math.exp(-0.01)))


def test_lambda_coordinate_roundtrip_and_nonzero_slope():
    for v in (0.0, 1e-7, 1e-4, 0.05):
        assert ID.g_inv("lam", ID.g_coord("lam", v)) == pytest.approx(v, abs=1e-15)
    B = {"lambda": [0.0, 0.05]}
    du = ID.unit_position("lam", 1e-8, B) - ID.unit_position("lam", 0.0, B)
    assert du > 1e-5          # linear near 0 (log10(lambda + 1e-7) gave ~1e-2 of this)


def test_neff_hac_white_and_ar1():
    rng = np.random.default_rng(0)
    e = rng.standard_normal(20000)
    assert ID.neff_hac(e, 200)["tau"] == pytest.approx(1.0, abs=0.3)
    x = np.zeros_like(e)
    for k in range(1, e.size):
        x[k] = 0.8 * x[k - 1] + e[k]
    assert ID.neff_hac(x, 400)["tau"] == pytest.approx((1 + 0.8) / (1 - 0.8), rel=0.2)


def test_profile_interval_interpolation():
    v = [0.0, 1e-4, 1e-3, 1e-2]
    L = [5.0, 2.0, 0.0, 7.84]
    ci = ID.profile_interval(v, L, 3.84, log=True, zero_crit=2.71)
    assert not ci["contains_zero"] and ci["lo_at_grid_edge"]           # 0 rejected, crossing below 1e-4 not interpolated
    assert ci["hi"] == pytest.approx(10 ** (-3 + 3.84 / 7.84))
    ci2 = ID.profile_interval([0.1, 0.2, 0.3], [4.84, 0.0, 1.0], 3.84)
    assert ci2["lo"] == pytest.approx(0.1 + (3.84 - 4.84) * 0.1 / (0 - 4.84)) and ci2["hi"] == 0.3 and ci2["hi_at_grid_edge"]


def test_wild_block_keeps_local_scale():
    rng = np.random.default_rng(3)
    z = np.linspace(1, 0, 6000)
    sig = np.where(z < 0.1, 10.0, 1.0)
    e = sig * rng.standard_normal(z.size)
    s_hat, _ = ID.local_scale(e, z, 20)
    r = ID.wild_block_resample(e, s_hat, 300, rng)
    assert np.sqrt(np.mean(r[z < 0.1] ** 2)) > 5 * np.sqrt(np.mean(r[z > 0.2] ** 2))
