"""Parameter identification of the TFSO voltage models (src/tfso/model.py).

Objective: voltage RMSE over the profile window (step 7) of the identification file on the 1 s grid; the warm-start
history (end of CV -> profile start) is simulated but not scored.  An optional scoring MASK restricts the window
(knee-excluded sensitivity: samples with Coulomb-counting SOC z >= z_min only; the mask depends on the data only).
Every simulation uses one input-timing convention for all branches (model.TIMING, `timing`; primary 'causal').

Coordinates: every optimiser works in the unit box u in [0, 1]^p, u_i = (g_i(theta_i) - g_i(lo_i)) / (g_i(hi_i) - g_i(lo_i))
with g = log for strictly positive parameters (R0, Rp, Cp, R1, R2, tau1, tau2), g = asinh(lambda / lambda_s) for
lambda (lambda_s = config identification_study.lambda_asinh_scale = 1e-5 1/s: linear near 0 with a NON-vanishing
derivative at lambda = 0, logarithmic for lambda >> lambda_s; review 2026-09-27 replaced log10(lambda + 1e-7), whose
derivative at 0 is ~70x smaller and let refits stall at lambda = 0) and g = identity for alpha, s, dq.
Bounds: config identification_study.bounds (physical justification there).

Optimisers (same bounds, same objective):
  tfgd   tempered fractional gradient descent (naifar2025theoretical, naifar2026tempered) as recorded in
         reports/notes_tfgd_definition.md: finite window N_g = ceil(8/lambda_g) of stored gradients with weights
         |binom(nu, j)| e^{-lambda_g j}, normalised by their actual sum (numerical alignment coefficient), projection
         on the box, Armijo backtracking, central finite differences in u, stop on relative decrease < tol over
         10 iterations or max_iter / evaluation budget.
         MODIFICATION of the published algorithm (disclosed): when the Armijo search fails along the tempered
         direction, the gradient memory is cleared (restart) and the plain gradient is tried; a failure along the
         plain gradient stops the run.  The objective is in mV and eta is a step in unit-box coordinates per mV of
         gradient, so the objective unit fixes the effective step scale (an a-priori, untuned choice).
         Cost per iteration: 2p objective evaluations for the central-difference gradient (p + 1 one-sided at a
         bound) + 1 per Armijo trial (counted: armijo_trials), O(N_g p) memory and flops for the weighted sum.
  trf    scipy.optimize.least_squares(method='trf') (coleman1996interior), 2-point Jacobian in u.
  de     scipy.optimize.differential_evolution (storn1997differential), own LHS population, polish=False.
  cmaes  pycma CMA-ES (hansen2001completely), x0 = the LHS start, sigma0 in u, box handled by BoundTransform.
"""
from __future__ import annotations

import math
import time

import numpy as np
from scipy.optimize import differential_evolution, least_squares
from scipy.special import binom

from . import model as MD

FAMILY_FREE = {
    "TFO": ["alpha", "lam", "R0", "Rp", "Cp", "s", "dq"],
    "FO": ["alpha", "R0", "Rp", "Cp", "s", "dq"],
    "FO_alphaTFO": ["R0", "Rp", "Cp", "s", "dq"],
    "RCL": ["lam", "R0", "Rp", "Cp", "s", "dq"],
    "2RC": ["R0", "R1", "tau1", "R2", "tau2", "s", "dq"],
}
FAMILY_FIXED = {"TFO": {}, "FO": {"lam": 0.0}, "FO_alphaTFO": {"lam": 0.0}, "RCL": {"alpha": 1.0}, "2RC": {}}
KIND = {"alpha": "lin", "lam": "asinhlam", "R0": "log", "Rp": "log", "Cp": "log", "R1": "log", "R2": "log",
        "tau1": "log", "tau2": "log", "s": "lin", "dq": "lin"}
BOUND_KEY = {"alpha": "alpha", "lam": "lambda", "R0": "R0", "Rp": "Rp", "Cp": "Cp", "R1": "R_2rc", "R2": "R_2rc",
             "tau1": "tau_2rc", "tau2": "tau_2rc", "s": "align_s", "dq": "align_dq_Ah"}


class BudgetExceeded(RuntimeError):
    pass


def bounds_of(name: str, cfg_bounds: dict) -> tuple[float, float]:
    lo, hi = cfg_bounds[BOUND_KEY[name]]
    return float(lo), float(hi)


def g_coord(name: str, v: float, lam_scale: float = 1e-5) -> float:
    k = KIND[name]
    if k == "log":
        return math.log(v)
    if k == "asinhlam":
        return math.asinh(v / lam_scale)
    return float(v)


def g_inv(name: str, g: float, lam_scale: float = 1e-5) -> float:
    k = KIND[name]
    if k == "log":
        return math.exp(g)
    if k == "asinhlam":
        return max(lam_scale * math.sinh(g), 0.0)
    return float(g)


def unit_position(name: str, v: float, cfg_bounds: dict, lam_scale: float = 1e-5) -> float:
    """Position of v in the optimiser box (0 = lower bound, 1 = upper bound)."""
    lo, hi = bounds_of(name, cfg_bounds)
    a, b = g_coord(name, lo, lam_scale), g_coord(name, hi, lam_scale)
    return (g_coord(name, min(max(v, lo), hi), lam_scale) - a) / (b - a)


class Problem:
    """Objective of one model family on one history (target = measured V unless V_target is given).
    mask: boolean array over the profile window (None = all samples scored)."""

    def __init__(self, family: str, hist: MD.History, ocv: MD.AlignedOCV, cfg_bounds: dict, fixed: dict | None = None,
                 free: list[str] | None = None, lam_scale: float = 1e-5, V_target: np.ndarray | None = None,
                 grid: MD.FFTGrid | None = None, budget: int | None = None, timing: str = "causal",
                 mask: np.ndarray | None = None):
        self.family, self.hist, self.ocv, self.lam_scale = family, hist, ocv, float(lam_scale)
        self.timing = timing
        self.mask = None if mask is None else np.asarray(mask, bool)
        self.fixed = dict(FAMILY_FIXED[family]); self.fixed.update(fixed or {})
        self.free = list(free) if free is not None else [n for n in FAMILY_FREE[family] if n not in self.fixed]
        self.p = len(self.free)
        self.lo = np.array([bounds_of(n, cfg_bounds)[0] for n in self.free])
        self.hi = np.array([bounds_of(n, cfg_bounds)[1] for n in self.free])
        self.glo = np.array([self._g(n, v) for n, v in zip(self.free, self.lo)])
        self.ghi = np.array([self._g(n, v) for n, v in zip(self.free, self.hi)])
        Vp = hist.V[hist.prof]
        if V_target is not None:
            self.target = np.asarray(V_target, float)
        else:
            self.target = Vp if self.mask is None else Vp[self.mask]
        self.n = self.target.size
        self.grid = grid if grid is not None else (None if family == "2RC" else MD.FFTGrid(hist.I.size))
        self.budget = budget
        self.reset_counter()

    # ---- coordinates -------------------------------------------------------------
    def _g(self, name, v):
        return g_coord(name, v, self.lam_scale)

    def _ginv(self, name, g):
        return g_inv(name, g, self.lam_scale)

    def theta(self, u) -> dict:
        u = np.clip(np.asarray(u, float), 0.0, 1.0)
        g = self.glo + u * (self.ghi - self.glo)
        th = {n: self._ginv(n, gi) for n, gi in zip(self.free, g)}
        th.update(self.fixed)
        return th

    def to_u(self, theta: dict) -> np.ndarray:
        g = np.array([self._g(n, min(max(theta[n], lo), hi)) for n, lo, hi in zip(self.free, self.lo, self.hi)])
        return np.clip((g - self.glo) / (self.ghi - self.glo), 0.0, 1.0)

    def params(self, th: dict):
        if self.family == "2RC":
            return MD.TwoRCParams(th["R0"], th["R1"], th["tau1"], th["R2"], th["tau2"], th["s"], th["dq"])
        return MD.TFOParams(th["alpha"], th["lam"], th["R0"], th["Rp"], th["Cp"], th["s"], th["dq"])

    # ---- objective ---------------------------------------------------------------
    def reset_counter(self):
        self.nfev, self.best_f, self.best_u, self.trace = 0, np.inf, None, []

    def model_V_profile(self, th: dict) -> np.ndarray:
        """Modelled V_t on the whole profile window (unmasked)."""
        return MD.simulate(self.params(th), self.hist, self.ocv, grid=self.grid, window=self.hist.prof,
                           timing=self.timing)["Vt"]

    def model_V(self, th: dict) -> np.ndarray:
        V = self.model_V_profile(th)
        return V if self.mask is None else V[self.mask]

    def residuals(self, u) -> np.ndarray:
        if self.budget is not None and self.nfev >= self.budget:
            raise BudgetExceeded
        u = np.clip(np.asarray(u, float), 0.0, 1.0)
        r = self.model_V(self.theta(u)) - self.target
        self.nfev += 1
        f = float(np.sqrt(np.mean(r * r))) * 1e3
        if not np.isfinite(f):
            r = np.full_like(r, 10.0)
            f = 1e4
        if f < self.best_f:
            self.best_f, self.best_u = f, u.copy()
            self.trace.append((self.nfev, f))
        return r

    def rmse_mV(self, u) -> float:
        r = self.residuals(u)
        return float(np.sqrt(np.mean(r * r))) * 1e3


def lhs_starts(p: int, n: int, seed: int) -> np.ndarray:
    from scipy.stats import qmc
    return qmc.LatinHypercube(d=p, seed=seed).random(n)


def _record(prob: Problem, u, t0w, t0c, converged: bool, message: str, extra: dict | None = None) -> dict:
    u = prob.best_u if prob.best_u is not None else np.asarray(u)
    th = prob.theta(u)
    out = dict(rmse_mV=float(prob.best_f), theta=th, u=[float(x) for x in u], nfev=int(prob.nfev),
               wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c, converged=bool(converged),
               message=str(message), trace=[[int(a), float(b)] for a, b in prob.trace])
    if extra:
        out.update(extra)
    return out


# --------------------------------------------------------------------------------------
# Optimisers
# --------------------------------------------------------------------------------------
def run_trf(prob: Problem, u0, max_nfev: int = 2000, diff_step: float = 1e-6, xtol: float = 1e-10,
            ftol: float = 1e-10, gtol: float = 1e-10) -> dict:
    prob.reset_counter(); prob.budget = int(max_nfev)
    t0w, t0c = time.perf_counter(), time.process_time()
    sq = 1.0 / math.sqrt(prob.n)
    try:
        res = least_squares(lambda u: prob.residuals(u) * sq, np.clip(u0, 0, 1), bounds=(0.0, 1.0), method="trf",
                            x_scale=1.0, diff_step=diff_step, max_nfev=max_nfev, xtol=xtol, ftol=ftol, gtol=gtol)
        conv, msg, u = bool(res.status > 0), f"status {res.status}: {res.message}", res.x
    except BudgetExceeded:
        conv, msg, u = False, "evaluation budget (incl. finite-difference Jacobian calls) exhausted", prob.best_u
    prob.budget = None
    return _record(prob, u, t0w, t0c, conv, msg)


def run_trf_multi(prob: Problem, starts, max_nfev: int = 2000, diff_step: float = 1e-6) -> dict:
    """Best of several TRF runs (by final RMSE); records every start's RMSE/convergence."""
    best, allr = None, []
    for u0 in starts:
        r = run_trf(prob, u0, max_nfev=max_nfev, diff_step=diff_step)
        allr.append(dict(rmse_mV=r["rmse_mV"], converged=r["converged"], nfev=r["nfev"]))
        if best is None or r["rmse_mV"] < best["rmse_mV"]:
            best = r
    best = dict(best)
    best["starts"] = allr
    return best


def tfgd_weights(nu: float, lam_g: float, N_g: int) -> np.ndarray:
    j = np.arange(N_g)
    return np.abs(binom(nu, j)) * np.exp(-lam_g * j)


def run_tfgd(prob: Problem, u0, nu: float, lam_g: float, eta: float, max_iter: int, tol_rel: float, budget: int,
             armijo_c: float = 1e-4, backtrack: float = 0.5, max_backtracks: int = 20, fd_step: float = 1e-5,
             stall_window: int = 10) -> dict:
    """TFGD (see module doc).  Objective in mV (config identification_study.tfgd.objective_unit).
    'converged' = stopped by the relative-decrease tolerance (not a certificate of optimality)."""
    prob.reset_counter(); prob.budget = int(budget)
    t0w, t0c = time.perf_counter(), time.process_time()
    N_g = int(math.ceil(8.0 / lam_g))
    wabs = tfgd_weights(nu, lam_g, N_g)
    u = np.clip(np.asarray(u0, float), 0, 1)
    p = u.size
    G: list[np.ndarray] = []
    f_hist, n_restart, it, reason, conv = [], 0, 0, "max_iter", False
    align = []
    cnt = dict(armijo=0, grad=0, iters_done=0)

    def grad(u, f0):
        g = np.empty(p)
        for i in range(p):
            e = np.zeros(p)
            if u[i] + fd_step <= 1.0 and u[i] - fd_step >= 0.0:
                e[i] = fd_step
                g[i] = (prob.rmse_mV(u + e) - prob.rmse_mV(u - e)) / (2 * fd_step)
                cnt["grad"] += 2
            elif u[i] + fd_step <= 1.0:
                e[i] = fd_step
                g[i] = (prob.rmse_mV(u + e) - f0) / fd_step
                cnt["grad"] += 1
            else:
                e[i] = fd_step
                g[i] = (f0 - prob.rmse_mV(u - e)) / fd_step
                cnt["grad"] += 1
        return g

    def armijo(u, f, g, d):
        step = eta
        for _ in range(max_backtracks + 1):
            un = np.clip(u - step * d, 0.0, 1.0)
            du = un - u
            slope = float(g @ du)
            if slope >= 0.0 or not np.any(du):
                return None
            cnt["armijo"] += 1
            fn = prob.rmse_mV(un)
            if fn <= f + armijo_c * slope:
                return un, fn
            step *= backtrack
        return None

    try:
        f = prob.rmse_mV(u)
        f_hist.append(f)
        for it in range(1, int(max_iter) + 1):
            g = grad(u, f)
            G.insert(0, g)
            del G[N_g:]
            c = wabs[:len(G)]
            d = np.tensordot(c, np.array(G), axes=1) / c.sum()      # normalised tempered sum (alignment coefficient)
            align.append(float(c.sum()))
            acc = armijo(u, f, g, d)
            if acc is None:
                n_restart += 1
                G = [g]
                acc = armijo(u, f, g, g)
                if acc is None:
                    reason = "line_search_failure_plain_gradient"
                    break
            u, f = acc
            f_hist.append(f)
            cnt["iters_done"] += 1
            if len(f_hist) > stall_window:
                fo = f_hist[-1 - stall_window]
                if (fo - f) / max(abs(fo), 1e-300) < tol_rel:
                    reason, conv = "relative_decrease_below_tol", True
                    break
    except BudgetExceeded:
        reason = "evaluation_budget"
    prob.budget = None
    nit = max(cnt["iters_done"], 1)
    return _record(prob, u, t0w, t0c, conv, reason,
                   dict(iterations=int(it), iterations_completed=int(cnt["iters_done"]), restarts=int(n_restart), N_g=N_g,
                        armijo_trials=int(cnt["armijo"]), gradient_evals=int(cnt["grad"]),
                        mean_armijo_trials_per_iter=cnt["armijo"] / nit, mean_evals_per_iter=(cnt["armijo"] + cnt["grad"]) / nit,
                        alignment_coefficient_final=align[-1] if align else None,
                        alignment_coefficient_asymptotic=float((1 - math.exp(-lam_g)) ** (-nu)) if nu > 0 else 1.0))


def run_de(prob: Problem, seed: int, budget: int, popsize: int = 15, tol: float = 1e-8, strategy: str = "best1bin") -> dict:
    prob.reset_counter(); prob.budget = int(budget)
    t0w, t0c = time.perf_counter(), time.process_time()
    npop = popsize * prob.p
    maxiter = max(budget // npop - 1, 1)
    try:
        res = differential_evolution(prob.rmse_mV, [(0.0, 1.0)] * prob.p, strategy=strategy, popsize=popsize,
                                     maxiter=maxiter, tol=tol, seed=seed, polish=False, init="latinhypercube",
                                     updating="immediate")
        conv, msg, u = bool(res.success), str(res.message), res.x
    except BudgetExceeded:
        conv, msg, u = False, "evaluation budget", prob.best_u
    prob.budget = None
    return _record(prob, u, t0w, t0c, conv, msg, dict(seed=int(seed), maxiter=int(maxiter), population=int(npop)))


def run_cmaes(prob: Problem, u0, seed: int, budget: int, sigma0: float = 0.3, popsize: int = 12) -> dict:
    import cma
    prob.reset_counter(); prob.budget = int(budget)
    t0w, t0c = time.perf_counter(), time.process_time()
    opts = {"bounds": [0.0, 1.0], "popsize": int(popsize), "maxfevals": int(budget), "seed": int(seed),
            "verbose": -9, "tolfun": 1e-11, "tolx": 1e-11, "tolfunhist": 1e-12}
    es = cma.CMAEvolutionStrategy(list(np.clip(u0, 0, 1)), sigma0, opts)
    stop = {}
    try:
        while not es.stop():
            X = es.ask()
            if prob.nfev + len(X) > budget:
                stop = {"evaluation_budget": budget}
                break
            es.tell(X, [prob.rmse_mV(x) for x in X])
        stop = stop or dict(es.stop())
    except BudgetExceeded:
        stop = {"evaluation_budget": budget}
    conv = not any(k in stop for k in ("maxfevals", "maxiter", "evaluation_budget"))
    prob.budget = None
    return _record(prob, es.result.xbest if es.result.xbest is not None else u0, t0w, t0c, conv,
                   ",".join(f"{k}" for k in stop), dict(seed=int(seed), popsize=int(popsize), sigma0=sigma0))


# --------------------------------------------------------------------------------------
# Residual dependence: effective sample size
# --------------------------------------------------------------------------------------
def acf(x: np.ndarray, max_lag: int) -> np.ndarray:
    x = np.asarray(x, float) - np.mean(x)
    n = x.size
    f = np.fft.rfft(x, n=1 << int(math.ceil(math.log2(2 * n))))
    a = np.fft.irfft(f * np.conj(f))[:max_lag + 1]
    return a / a[0]


def neff_ar1(res: np.ndarray) -> dict:
    rho1 = float(acf(res, 2)[1])
    n = int(np.asarray(res).size)
    return dict(rho1=rho1, tau_s_units=(1 + rho1) / (1 - rho1), n_eff=n * (1 - rho1) / (1 + rho1))


def neff_hac(res: np.ndarray, bandwidth: int) -> dict:
    """Newey-West (Bartlett-kernel) long-run variance of the residuals:  tau = 1 + 2 sum_{k=1}^{K} (1 - k/(K+1)) rho_k,
    n_eff = n / tau  (integrated autocorrelation time with Bartlett weights; captures the periodic ACF component that
    the AR(1) rule misses)."""
    n = int(np.asarray(res).size)
    K = int(min(bandwidth, n - 1))
    a = acf(res, K)
    w = 1.0 - np.arange(1, K + 1) / (K + 1.0)
    tau = float(1.0 + 2.0 * np.sum(w * a[1:K + 1]))
    tau = max(tau, 1.0)
    return dict(bandwidth=K, tau=tau, n_eff=n / tau)


# --------------------------------------------------------------------------------------
# Bootstrap (local-scale circular block bootstrap of the residuals)
# --------------------------------------------------------------------------------------
def local_scale(res: np.ndarray, z: np.ndarray, n_bins: int) -> tuple[np.ndarray, dict]:
    """z-dependent local RMS sigma(z) of the residuals: RMS in n_bins equal-count bins of z, assigned to each sample
    by its bin (piecewise constant).  Returns sigma_t and the bin table."""
    r, z = np.asarray(res, float), np.asarray(z, float)
    edges = np.quantile(z, np.linspace(0, 1, n_bins + 1))
    edges[0], edges[-1] = -np.inf, np.inf
    idx = np.clip(np.searchsorted(edges, z, side="right") - 1, 0, n_bins - 1)
    sig = np.array([np.sqrt(np.mean(r[idx == k] ** 2)) if np.any(idx == k) else np.nan for k in range(n_bins)])
    sig = np.where(np.isfinite(sig) & (sig > 0), sig, np.nanmedian(sig))
    zc = np.array([np.median(z[idx == k]) if np.any(idx == k) else np.nan for k in range(n_bins)])
    return sig[idx], dict(z_center=zc, sigma_mV=sig * 1e3)


def circular_block_resample(x: np.ndarray, L: int, rng: np.random.Generator) -> np.ndarray:
    """Circular block bootstrap (Politis & Romano 1992): blocks of length L from the wrapped series."""
    n = x.size
    k = int(math.ceil(n / L))
    starts = rng.integers(0, n, size=k)
    xx = np.concatenate([x, x[:L]])
    return np.concatenate([xx[s:s + L] for s in starts])[:n]


def wild_block_resample(res: np.ndarray, sigma: np.ndarray, L: int, rng: np.random.Generator) -> np.ndarray:
    """Local-scale block bootstrap: standardise e_t / sigma_t, resample circular blocks of the standardised series,
    rescale by sigma_t at the TARGET position (keeps the large end-of-discharge residuals where they occur)."""
    eps = res / sigma
    eps = eps - eps.mean()
    return sigma * circular_block_resample(eps, L, rng)


def moving_block_resample(res: np.ndarray, L: int, rng: np.random.Generator) -> np.ndarray:
    """Plain moving-block resampling (first run; superseded by wild_block_resample, kept for reference)."""
    n = res.size
    k = int(math.ceil(n / L))
    starts = rng.integers(0, n - L + 1, size=k)
    return np.concatenate([res[s:s + L] for s in starts])[:n]


# --------------------------------------------------------------------------------------
# Profiles, intervals, Jacobian
# --------------------------------------------------------------------------------------
def _fixed_for(family, pname, v, theta_hat):
    fixed = {pname: v}
    if family == "FO_alphaTFO":
        fixed["alpha"] = theta_hat["alpha"]
    if family == "FO":
        fixed["lam"] = 0.0
    return fixed


def profile_likelihood(family, hist, ocv, cfg_bounds, theta_hat: dict, pname: str, grid_vals, lam_scale=1e-5,
                       fft_grid=None, max_nfev=3000, diff_step=1e-6, timing="causal", mask=None,
                       extra_starts: list[dict] | None = None) -> list[dict]:
    """Refit all other parameters with pname fixed at each grid value.  At each point the best of: the warm start
    (previous grid point, marching outwards from the optimum), the optimum theta_hat itself, and the extra cold starts
    (dicts of parameter overrides of theta_hat, e.g. {'lam': 2e-3}) is kept.  Every start is TRF (max_nfev)."""
    vals = sorted(set(float(v) for v in grid_vals) | {float(theta_hat[pname])})
    v0 = float(theta_hat[pname])
    up = [v for v in vals if v >= v0]
    dn = [v for v in vals if v < v0][::-1]
    out = {}
    for seq in (up, dn):
        th_warm = dict(theta_hat)
        for v in seq:
            fixed = _fixed_for(family, pname, v, theta_hat)
            prob = Problem(family, hist, ocv, cfg_bounds, fixed=fixed, lam_scale=lam_scale, grid=fft_grid,
                           timing=timing, mask=mask)
            cands = [("warm", th_warm), ("optimum", dict(theta_hat))]
            for k, ov in enumerate(extra_starts or []):
                cands.append((f"cold{k}", dict(theta_hat, **ov)))
            best, tried = None, []
            for lab, th0 in cands:
                r = run_trf(prob, prob.to_u(th0), max_nfev=max_nfev, diff_step=diff_step)
                tried.append(dict(start=lab, rmse_mV=r["rmse_mV"], converged=r["converged"], nfev=r["nfev"]))
                if best is None or r["rmse_mV"] < best["rmse_mV"] - 1e-9:
                    best, blab = r, lab
            th_warm = dict(best["theta"])
            out[v] = dict(value=v, rmse_mV=best["rmse_mV"], theta=best["theta"], nfev=best["nfev"],
                          converged=best["converged"], best_start=blab, starts=tried)
    return [out[v] for v in vals]


def _cross(x0, y0, x1, y1, c, log):
    """x where the segment (x0, y0)-(x1, y1) crosses y = c (linear in log10 x when log)."""
    if log:
        a0, a1 = math.log10(x0), math.log10(x1)
        return 10 ** (a0 + (c - y0) * (a1 - a0) / (y1 - y0))
    return x0 + (c - y0) * (x1 - x0) / (y1 - y0)


def profile_interval(values, LR, crit: float, log: bool = False, zero_crit: float | None = None) -> dict:
    """Interpolated profile-likelihood interval {v: LR(v) <= crit}.
    log: interpolate on log10(v) between positive grid points.  zero_crit: if the grid contains v = 0 (a boundary
    value, lambda), 0 belongs to the set iff LR(0) <= zero_crit (chi-bar-square boundary value) and crossings between
    0 and the first positive grid point are not interpolated (reported as that grid point, flagged).
    Returns lo, hi, flags lo_open/hi_open (the set reaches the first/last grid value, so the true end may lie beyond)
    and 'contains_zero'."""
    v = np.asarray(values, float); L = np.asarray(LR, float)
    o = np.argsort(v); v, L = v[o], L[o]
    has0 = v.size > 0 and v[0] == 0.0 and zero_crit is not None
    inside = L <= crit
    if has0:
        inside[0] = L[0] <= zero_crit
    if not inside.any():
        return dict(lo=None, hi=None, empty=True, contains_zero=False)
    k = int(np.argmin(L))
    if not inside[k]:
        ks = np.where(inside)[0]; k = int(ks[0])
    i = k
    while i - 1 >= 0 and inside[i - 1]:
        i -= 1
    j = k
    while j + 1 < v.size and inside[j + 1]:
        j += 1
    lo_open, hi_open = i == 0, j == v.size - 1
    if i == 0:
        lo = float(v[0])
    elif has0 and i == 1:
        lo, lo_open = float(v[1]), True      # between 0 (excluded) and the first positive grid value: not interpolated
    else:
        lo = float(_cross(v[i - 1], L[i - 1], v[i], L[i], crit, log and v[i - 1] > 0))
    if j == v.size - 1:
        hi = float(v[-1])
    else:
        hi = float(_cross(v[j], L[j], v[j + 1], L[j + 1], crit, log and v[j] > 0))
    return dict(lo=lo, hi=hi, empty=False, lo_at_grid_edge=bool(lo_open), hi_at_grid_edge=bool(hi_open),
                contains_zero=bool(has0 and inside[0] and i == 0))


def jacobian_natural(family, hist, ocv, cfg_bounds, theta: dict, names: list[str], lam_scale=1e-5, grid=None,
                     rel: float = 1e-4, lam_abs: float = 1e-7, timing="causal", mask=None) -> np.ndarray:
    """dV_t/dtheta (scored window) in natural units by central differences (one-sided at a bound)."""
    prob = Problem(family, hist, ocv, cfg_bounds, lam_scale=lam_scale, grid=grid, timing=timing, mask=mask)
    base = prob.model_V(theta)
    J = np.empty((base.size, len(names)))
    for k, n in enumerate(names):
        lo, hi = bounds_of(n, cfg_bounds)
        v = theta[n]
        dv = lam_abs if n == "lam" else (rel * max(abs(v), 1e-3) if n in ("dq",) else rel * abs(v) if v != 0 else rel)
        tp, tm = dict(theta), dict(theta)
        if v + dv <= hi and v - dv >= lo:
            tp[n], tm[n] = v + dv, v - dv
            J[:, k] = (prob.model_V(tp) - prob.model_V(tm)) / (2 * dv)
        elif v + dv <= hi:
            tp[n] = v + dv
            J[:, k] = (prob.model_V(tp) - base) / dv
        else:
            tm[n] = v - dv
            J[:, k] = (base - prob.model_V(tm)) / dv
    return J


def correlation_from_J(J: np.ndarray) -> dict:
    s = np.linalg.norm(J, axis=0)
    Js = J / np.where(s > 0, s, 1.0)
    sv = np.linalg.svd(Js, compute_uv=True, full_matrices=False)
    C = np.linalg.pinv(Js.T @ Js)
    d = np.sqrt(np.clip(np.diag(C), 1e-300, None))
    R = C / np.outer(d, d)
    return dict(corr=R, cond_scaled=float(sv[1][0] / sv[1][-1]), singular_values_scaled=sv[1],
                weakest_direction=sv[2][-1], cov_unscaled_diag=np.diag(C) / s**2)


def residual_stats(res: np.ndarray, lb_lags: int, quantiles, max_lag: int) -> dict:
    from statsmodels.stats.diagnostic import acorr_ljungbox
    r = np.asarray(res, float)
    a = acf(r, max_lag)
    lb = acorr_ljungbox(r, lags=[lb_lags], return_df=True)
    return dict(n=int(r.size), rmse_mV=float(np.sqrt(np.mean(r**2)) * 1e3), mae_mV=float(np.mean(np.abs(r)) * 1e3),
                max_abs_mV=float(np.max(np.abs(r)) * 1e3), mean_mV=float(np.mean(r) * 1e3),
                acf_lag1=float(a[1]), ljung_box_lags=int(lb_lags), ljung_box_Q=float(lb["lb_stat"].iloc[0]),
                ljung_box_p=float(lb["lb_pvalue"].iloc[0]),
                quantiles_mV={f"{q:g}": float(np.quantile(r, q) * 1e3) for q in quantiles}), a


# ======================================================================================
# Additions (P1, 2026-09-27): finite-memory objective, profile with extra fixed parameters, current-edge resistance.
# Existing functions above are unchanged.
# ======================================================================================
class ProblemNL(Problem):
    """Problem whose fractional branch uses the FINITE-memory implicit GL recursion with N_L samples (model.simulate
    N_L; the same truncated scheme as the observers, observer._run_tfo / tempered.simulate_tempered_element).
    N_L = None is full memory (identical to Problem).  Not used for 2RC."""

    def __init__(self, *a, N_L: int | None = None, **kw):
        super().__init__(*a, **kw)
        self.N_L = None if N_L is None else int(N_L)

    def model_V_profile(self, th: dict) -> np.ndarray:
        return MD.simulate(self.params(th), self.hist, self.ocv, grid=self.grid, window=self.hist.prof,
                           timing=self.timing, N_L=self.N_L)["Vt"]


def profile_likelihood_fixed(family, hist, ocv, cfg_bounds, theta_hat: dict, pname: str, grid_vals, base_fixed: dict,
                             lam_scale=1e-5, fft_grid=None, max_nfev=3000, diff_step=1e-6, timing="causal", mask=None,
                             extra_starts: list[dict] | None = None, N_L: int | None = None) -> list[dict]:
    """profile_likelihood with additional parameters held fixed at every profile point (base_fixed, e.g. {'R0': x})
    and an optional finite memory N_L.  Same start protocol: warm (marching outwards), optimum, extra cold starts."""
    vals = sorted(set(float(v) for v in grid_vals) | {float(theta_hat[pname])})
    v0 = float(theta_hat[pname])
    up = [v for v in vals if v >= v0]
    dn = [v for v in vals if v < v0][::-1]
    out = {}
    for seq in (up, dn):
        th_warm = dict(theta_hat)
        for v in seq:
            fixed = dict(_fixed_for(family, pname, v, theta_hat), **base_fixed)
            prob = ProblemNL(family, hist, ocv, cfg_bounds, fixed=fixed, lam_scale=lam_scale, grid=fft_grid,
                             timing=timing, mask=mask, N_L=N_L)
            cands = [("warm", th_warm), ("optimum", dict(theta_hat))]
            for k, ov in enumerate(extra_starts or []):
                cands.append((f"cold{k}", dict(theta_hat, **ov)))
            best, tried, blab = None, [], None
            for lab, th0 in cands:
                r = run_trf(prob, prob.to_u(th0), max_nfev=max_nfev, diff_step=diff_step)
                tried.append(dict(start=lab, rmse_mV=r["rmse_mV"], converged=r["converged"], nfev=r["nfev"]))
                if best is None or r["rmse_mV"] < best["rmse_mV"] - 1e-9:
                    best, blab = r, lab
            th_warm = dict(best["theta"])
            out[v] = dict(value=v, rmse_mV=best["rmse_mV"], theta=best["theta"], nfev=best["nfev"],
                          converged=best["converged"], best_start=blab, starts=tried)
    return [out[v] for v in vals]


def current_edges(step_time: np.ndarray, I: np.ndarray, period: np.ndarray, dI_min: float) -> dict:
    """Current transitions of a piecewise-constant profile logged at irregular instants.
    step_time: Arbin Step_Time [s] (the schedule clock, restarted at every period); period: period label per sample.
    An edge is a pair of consecutive samples (a, b = a + 1) of the same period with |I_b - I_a| >= dI_min.
    Returns indices a, b, the bracketing step times lo = st_a < c < hi = st_b of the (unlogged) switching instant c,
    and the order j of the edge within its period (the same schedule transition has the same j in every period)."""
    a_l, j_l = [], []
    for p in np.unique(period):
        k = np.where(period == p)[0]
        d = np.where(np.abs(np.diff(I[k])) >= dI_min)[0]
        a_l += list(k[d]); j_l += list(range(d.size))
    a = np.array(a_l, int)
    return dict(a=a, b=a + 1, lo=step_time[a], hi=step_time[a + 1], j=np.array(j_l, int))


def schedule_offset(lo: np.ndarray, hi: np.ndarray, j: np.ndarray, grid_step: float = 1e-3, eps: float = 1e-9,
                    tol: float = 0.0) -> dict:
    """Switching instants of a schedule defined on whole seconds of the step clock plus an unknown common offset d:
    c = k_j + d, k_j integer, the same k_j for every edge of order j.  For each d on a grid in [0, 1) the edges of
    order j are consistent if one integer k satisfies lo < k + d < hi for all of them.  Returns the set of d for which
    every order is consistent with a UNIQUE k (d_lo, d_hi, its midpoint d), the k per edge and the edge instant
    c = k + d; 'n_orders_consistent' is reported for the best d (== n_orders when the hypothesis holds).
    tol [s]: switching-instant jitter allowed around k + d (lo - tol < k + d < hi + tol).  An order for which two
    integers remain feasible for every edge is 'ambiguous' (k = NaN; its edges get no instant)."""
    ds = np.arange(0.0, 1.0, grid_step)
    orders = np.unique(j)
    ok, K = [], []
    for d in ds:
        kmin = np.ceil(lo - tol - d + eps)
        kmax = np.floor(hi + tol - d - eps)
        good, kk = 0, np.full(lo.size, np.nan)
        for o in orders:
            m = j == o
            klo, khi = kmin[m].max(), kmax[m].min()
            if klo <= khi:
                good += 1
                if klo == khi:
                    kk[m] = klo
        ok.append(good); K.append(kk)
    ok = np.array(ok)
    best = ok.max()
    sel = np.where(ok == best)[0]
    # contiguous run containing the first best index
    run = [sel[0]]
    for i in sel[1:]:
        if i == run[-1] + 1:
            run.append(i)
    d_lo, d_hi = float(ds[run[0]]), float(ds[run[-1]])
    d = 0.5 * (d_lo + d_hi)
    kk = K[run[len(run) // 2]]
    n_amb = int(sum(np.all(np.isnan(kk[j == o])) for o in orders))
    return dict(d=d, d_lo=d_lo, d_hi=d_hi, n_orders=int(orders.size), n_orders_consistent=int(best),
                n_orders_ambiguous=n_amb, n_disjoint_best_sets=int(1 + np.sum(np.diff(sel) > 1)), k=kk, c=kk + d,
                grid_step=grid_step, tol=tol)


def edge_resistance(step_time, I, V, edges: dict, c: np.ndarray, period: np.ndarray, settle_tol_A: float,
                    settle_tol_rel: float) -> dict:
    """R = (V_b - V_pre(c)) / (I_b - I_a) per edge [Ohm] (Arbin sign: I > 0 charge, so R > 0).
    V_pre(c): the pre-edge voltage extrapolated linearly to the switching instant c from the last two pre-edge samples
    (a-1, a) of the same current level; also returned without extrapolation (R_raw = (V_b - V_a)/dI).
    delta_post = st_b - c (delay of the post-edge sample after the switch), delta_pre = c - st_a.
    clean: a-1, a, b, b+1 in the same period; |I_{a-1} - I_a| and |I_{b+1} - I_b| <= max(settle_tol_A,
    settle_tol_rel |dI|) (pre level held, post level settled)."""
    a, b = edges["a"], edges["b"]
    n = I.size
    am1 = np.clip(a - 1, 0, n - 1); bp1 = np.clip(b + 1, 0, n - 1)
    dI = I[b] - I[a]
    tol = np.maximum(settle_tol_A, settle_tol_rel * np.abs(dI))
    same = (period[am1] == period[a]) & (period[bp1] == period[b]) & (a >= 1) & (b + 1 < n)
    clean = same & (np.abs(I[am1] - I[a]) <= tol) & (np.abs(I[bp1] - I[b]) <= tol)
    dpre = c - step_time[a]
    dpost = step_time[b] - c
    dt_pre = step_time[a] - step_time[am1]
    slope = np.where(dt_pre > 0, (V[a] - V[am1]) / np.where(dt_pre > 0, dt_pre, 1.0), 0.0)
    Vpre = V[a] + slope * dpre
    return dict(R=(V[b] - Vpre) / dI, R_raw=(V[b] - V[a]) / dI, dI=dI, I_pre=I[a], I_post=I[b], delta_post=dpost,
                delta_pre=dpre, clean=clean, pre_slope_V_s=slope, V_post=V[b])
