"""Journal figure style shared by every figure script of the manuscript (Journal of Energy Storage).

Use
---
    from tfso import plotstyle as ps
    plt = ps.setup()                                   # rcParams + Agg backend, returns pyplot
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("double", 110), layout="constrained")
    ax.plot(t, y, **ps.line("TPL"))                    # colour + dash + marker of a named series
    ps.panel_label(ax, 0)                              # "(a)"
    ps.save(fig, "figures/fig_name.pdf")               # vector PDF (TrueType fonts embedded)
    ps.preview_png("figures/fig_name.pdf")             # 200 dpi PNG next to the PDF for visual checks

Conventions
-----------
* Widths: single column 90 mm, double column 190 mm (Elsevier final sizes), and 'text' = 169.3 mm, the text width
  of the submitted manuscript (A4, 0.8 in margins). Figures included with width=\\textwidth in the manuscript are
  built at 'text' width, so LaTeX does not rescale them and the font sizes below are the printed sizes: 8 pt tick
  labels, legends and annotations, 8.5 pt axis labels, 9 pt panel labels. For the final two-column Elsevier layout,
  rebuild at 'double' (full width) or 'single' (one column) and include at natural size.
* Serif text (Times New Roman, falling back to STIX/DejaVu Serif) and STIX mathtext, matching the manuscript.
* Colour: the categorical slots of the dataviz reference palette (light mode), assigned in FIXED order and never
  cycled. The first three slots (blue, orange, aqua) are the only ones validated for all-pairs use (scatter, small
  multiples); line charts may use up to the eight slots in order (adjacent-pair validated). For print, identity is
  never carried by colour alone: every named series also has its own dash pattern and marker, so figures survive
  greyscale printing and colour-vision deficiency. Slots 3-5 (aqua, yellow, magenta) sit below 3:1 contrast on white,
  so they are always used with a legend or a direct label (relief rule).
* Text uses ink colours (INK, INK2), never a series colour. Grid and axes are recessive (light grey, thin).
* Marks: data lines 1.2 pt, reference lines 0.7 pt, markers 3.5-4 pt with a white edge ring where they overlap.
"""
from __future__ import annotations

from pathlib import Path

MM = 1.0 / 25.4
WIDTH_MM = {"single": 90.0, "double": 190.0, "onehalf": 140.0,
            "text": 169.3}   # manuscript text width: A4 (210 mm) minus 2 x 0.8 in margins (geometry in manuscript.tex)

# ---- colours (dataviz reference palette, light mode; fixed slot order) -------------------------------------------
SLOTS = ["#2a78d6",   # 1 blue
         "#eb6834",   # 2 orange
         "#1baf7a",   # 3 aqua
         "#eda100",   # 4 yellow
         "#e87ba4",   # 5 magenta
         "#008300",   # 6 green
         "#4a3aa7",   # 7 violet
         "#e34948"]   # 8 red
INK = "#0b0b0b"       # primary text / measured data
INK2 = "#52514e"      # secondary text, axes, reference lines
MUTED = "#8c8b86"     # de-emphasised context curves
GRID = "#e4e3df"      # grid lines
SHADE = "#f0efec"     # neutral band (admissible intervals, windows)
SHADE2 = "#cde2fb"    # light blue band (step 100 of the sequential blue ramp)

# Named series used across the manuscript. Each has a fixed slot, dash pattern and marker (secondary encoding).
SERIES = {
    # relaxation tail laws
    "PL":   dict(color=SLOTS[0], ls="--", marker="s"),
    "EXP":  dict(color=SLOTS[1], ls=":", marker="v"),
    "TPL":  dict(color=SLOTS[2], ls="-", marker="o"),
    "2EXP": dict(color=SLOTS[3], ls="-.", marker="^"),
    "SEXP": dict(color=SLOTS[4], ls=(0, (5, 1.5, 1, 1.5, 1, 1.5)), marker="D"),
    # temperatures (three levels -> first three slots, all-pairs safe)
    "T0":   dict(color=SLOTS[0], ls="-", marker="o"),
    "T25":  dict(color=SLOTS[1], ls="--", marker="s"),
    "T45":  dict(color=SLOTS[2], ls="-.", marker="^"),
    # OCV branches (two levels)
    "discharge": dict(color=SLOTS[0], ls="-", marker="o"),
    "charge":    dict(color=SLOTS[1], ls="--", marker="s"),
    # estimators (order fixed for all validation figures)
    "TFO":   dict(color=SLOTS[0], ls="-", marker="o"),
    "FOO":   dict(color=SLOTS[1], ls="--", marker="s"),
    "FOEKF": dict(color=SLOTS[2], ls="-.", marker="^"),
    "EKF2RC": dict(color=SLOTS[3], ls=":", marker="v"),
    "AEKF2RC": dict(color=SLOTS[4], ls=(0, (5, 1.5, 1, 1.5)), marker="D"),
    "CC":    dict(color=SLOTS[6], ls=(0, (1, 1)), marker="x"),
    # voltage-model families: same colour as the estimator built on that model (TF -> TFO, FO -> FOO,
    # 2RC -> EKF-2RC), so a colour means one model family in every figure; the 2RC model uses a denser dash than the
    # dotted EKF-2RC line so that the low-contrast yellow stays visible in fast voltage transients
    "M_TF":  dict(color=SLOTS[0], ls="-", marker="o"),
    "M_FO":  dict(color=SLOTS[1], ls="--", marker="s"),
    "M_2RC": dict(color=SLOTS[3], ls=(0, (4, 1.5, 1, 1.5)), marker="v"),
    # identification optimisers (only fig:optimizers; first four slots, all-pairs/adjacent validated)
    "TFGD":  dict(color=SLOTS[0], ls="-", marker="o"),
    "TRF":   dict(color=SLOTS[1], ls="--", marker="s"),
    "DE":    dict(color=SLOTS[2], ls="-.", marker="^"),
    "CMAES": dict(color=SLOTS[3], ls=":", marker="D"),
}
# display names used in every legend, tick label and table head
LABEL = {"TFO": "TFO", "FOO": "FOO", "FOEKF": "FOEKF", "EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC", "CC": "CC",
         "TFO_full": "TFO (full)", "FOO_full": "FOO (full)", "M_TF": "tempered fractional model",
         "M_FO": r"fractional ($\lambda=0$) model", "M_2RC": "2RC model", "TFGD": "TFGD", "TRF": "TRF", "DE": "DE",
         "CMAES": "CMA-ES"}
# neutral styles for external reference estimates that are not a method of the comparison
REF_MARK = {"relaxation": dict(color=INK2, marker="D"), "edge": dict(color=INK2, marker="P")}
CELL_MARKER = {"SP1": "o", "SP3": "s", "SP20-1": "o", "SP20-3": "s"}
CELL_FILLED = {"SP1": True, "SP3": False, "SP20-1": True, "SP20-3": False}

FONT_PT = dict(base=8.0, label=8.5, tick=8.0, legend=8.0, panel=9.0)
LW = dict(data=1.2, ref=0.7, thin=0.6)


def setup():
    """Apply the journal rcParams (Agg backend) and return matplotlib.pyplot."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": FONT_PT["base"],
        "axes.labelsize": FONT_PT["label"],
        "axes.titlesize": FONT_PT["label"],
        "xtick.labelsize": FONT_PT["tick"],
        "ytick.labelsize": FONT_PT["tick"],
        "legend.fontsize": FONT_PT["legend"],
        "legend.frameon": False,
        "legend.handlelength": 2.6,
        "legend.borderaxespad": 0.3,
        "legend.columnspacing": 1.2,
        "axes.edgecolor": INK2,
        "axes.labelcolor": INK,
        "axes.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "axes.axisbelow": True,
        "grid.color": GRID,
        "grid.linewidth": 0.5,
        "xtick.color": INK2,
        "ytick.color": INK2,
        "xtick.labelcolor": INK,
        "ytick.labelcolor": INK,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.minor.width": 0.4,
        "ytick.minor.width": 0.4,
        "xtick.major.size": 3.0,
        "ytick.major.size": 3.0,
        "lines.linewidth": LW["data"],
        "lines.markersize": 3.8,
        "lines.markeredgewidth": 0.7,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
        "figure.dpi": 150,
        "savefig.dpi": 600,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.formatter.use_mathtext": True,
        "figure.constrained_layout.h_pad": 0.03,
        "figure.constrained_layout.w_pad": 0.03,
    })
    return plt


def figsize(width: str | float = "single", height_mm: float = 70.0) -> tuple:
    """Figure size in inches for a column width ('single' 90 mm, 'double' 190 mm, 'onehalf' 140 mm, 'text' 169.3 mm, or mm)."""
    w = WIDTH_MM[width] if isinstance(width, str) else float(width)
    return (w * MM, height_mm * MM)


def line(name: str, marker: bool = False, **kw) -> dict:
    """Keyword arguments for ax.plot of a named series (colour, dash; marker if requested)."""
    s = SERIES[name]
    out = dict(color=s["color"], ls=s["ls"], lw=LW["data"])
    if marker:
        out.update(marker=s["marker"], mec="white", mew=0.5)
    out.update(kw)
    return out


def points(name: str | None = None, color: str | None = None, marker: str = "o", filled: bool = True, **kw) -> dict:
    """Keyword arguments for measured points: filled or open marker, thin edge (white ring when filled)."""
    c = color if color is not None else (SERIES[name]["color"] if name else INK)
    out = dict(ls="none", marker=marker, ms=4.0, mfc=c if filled else "white", mec=c if not filled else "white",
               mew=0.9 if not filled else 0.4)
    out.update(kw)
    return out


def panel_label(ax, k: int, x: float = -0.02, y: float = 1.05, ha: str = "right") -> None:
    """Bold-free '(a)', '(b)' ... label at the top-left corner outside the axes."""
    ax.text(x, y, f"({chr(97 + k)})", transform=ax.transAxes, ha=ha, va="bottom",
            fontsize=FONT_PT["panel"], color=INK)


def note(ax, text: str, x: float = 0.98, y: float = 0.96, ha: str = "right", va: str = "top", **kw) -> None:
    """Annotation in axes coordinates in secondary ink with a white backing box."""
    ax.text(x, y, text, transform=ax.transAxes, ha=ha, va=va, fontsize=FONT_PT["base"], color=INK2,
            bbox=dict(facecolor="white", edgecolor="none", pad=0.8, alpha=0.85), **kw)


def plain_log_ticks(ax, axis: str = "y", ticks=None) -> None:
    """Plain decimal tick labels (10, 20, 30 instead of 1e1, 2e1, 3e1) on a log axis with a narrow range."""
    from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter, NullLocator
    a = ax.yaxis if axis == "y" else ax.xaxis
    if ticks is not None:
        a.set_major_locator(FixedLocator(ticks))
        a.set_minor_locator(NullLocator())
    a.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    a.set_minor_formatter(NullFormatter())


def save(fig, path: str | Path) -> Path:
    """Save as vector PDF at the figure's own size (no tight bbox, so the printed width is exact)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(p, format="pdf")
    return p


def preview_png(pdf_path: str | Path, dpi: int = 200, out: str | Path | None = None) -> Path:
    """Rasterise page 1 of a PDF to PNG (PyMuPDF) for visual inspection; returns the PNG path."""
    import fitz  # PyMuPDF
    pdf_path = Path(pdf_path)
    out = Path(out) if out is not None else pdf_path.with_suffix(".png")
    doc = fitz.open(pdf_path)
    pix = doc[0].get_pixmap(dpi=dpi)
    pix.save(out)
    doc.close()
    return out
