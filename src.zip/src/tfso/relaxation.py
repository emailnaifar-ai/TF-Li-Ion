"""Relaxation-tail study: is the voltage relaxation after a 1 A current interruption a TEMPERED
power-law memory?

Two analyses, both on the six incremental-OCV files of cells SP1/SP3 (config splits.ocv_and_relaxation):

A. Phenomenological tail laws, one fit per 2 h rest segment on a declared window [t0, t_end] (t0 from
   config relaxation.fit_window_s[0], t_end = end of the rest), log-spaced subsample:
       PL   V_inf + A t^-beta
       EXP  V_inf + A exp(-t/tau)
       TPL  V_inf + A t^-beta exp(-lambda t)
       2EXP V_inf + A1 exp(-t/tau1) + A2 exp(-t/tau2)
       SEXP V_inf + A exp(-(t/tau)^beta)          (Kohlrausch-Williams-Watts)
   Variable projection (linear amplitudes eliminated by least squares), bounded nonlinear least squares
   (scipy.optimize.least_squares, trf) started from the best points of a dense grid plus seeded random
   starts.  Gaussian iid likelihood for AICc/BIC (caveat: residuals are autocorrelated and quantised at
   the ADC step (about 0.16 mV), so the information criteria rank models but their absolute p-value
   interpretation is optimistic).  TPL lambda: profile-likelihood interval and a residual moving-block
   bootstrap on the full-resolution segment.

B. Mechanistic tempered fractional polarisation element D^{alpha,lambda} V_p = -a V_p + b I, with
   impulse response g_lambda(tau) = e^{-lambda tau} tau^{alpha-1} E_{alpha,alpha}(-a tau^alpha)
   = (1/a) int_0^inf r K_a(r) e^{-(r+lambda) tau} dr (spectral representation, Gorenflo et al. 2020),
   implemented as a bank of first-order modes (trapezoid quadrature in u = ln r) driven by the full
   measured current of the file (zero-order hold, exact exponential integrator per mode).  Shared
   (alpha, lambda, a, b) per file, one free OCV level per rest window.

Sign convention: I > 0 charge (data layer).  All voltages in V inside the fits, reported in mV.
"""
from __future__ import annotations

import math
import os
import warnings

import numpy as np
from scipy import optimize, stats

from . import data as D

MODELS = ("PL", "EXP", "TPL", "2EXP", "SEXP")
N_NONLIN = {"PL": 1, "EXP": 1, "TPL": 2, "2EXP": 2, "SEXP": 2}
N_LIN = {"PL": 2, "EXP": 2, "TPL": 2, "2EXP": 3, "SEXP": 2}


def settings() -> dict:
    cfg = D.load_config()
    s = dict(cfg["relaxation_study"])
    s["t0_s"] = float(cfg["relaxation"]["fit_window_s"][0])
    s["n_boot"] = int(cfg["relaxation"]["bootstrap"]["n_boot"])
    s["block_len_s"] = float(cfg["relaxation"]["bootstrap"]["block_len_s"])   # superseded by block_bootstrap (review 1)
    s["lambda_bounds"] = [float(x) for x in cfg["bounds"]["lambda"]]
    s["profile_crit"] = float(s.get("profile_crit", 3.841458820694124))
    if os.environ.get("TFSO_RELAX_SMOKE"):      # fast code-path test only (outputs go to a scratch directory)
        s["n_boot"] = 4
        s["null_calibration"] = dict(n_null=4)
        m = dict(s["mechanistic"])
        m.update(n_boot=4, alpha_grid_n=5, log10_a_grid_n=5, rc_grid_n=30, lambda_grid=dict(zero=True, min=1e-7, max=0.05, n=8))
        s["mechanistic"] = m
        sc = dict(s["synthetic_control"])
        sc.update(lambdas_s_inv=[0.0], fitted_lambdas_s_inv=[0.0])
        s["synthetic_control"] = sc
        s["smoke_test"] = True
    return s


def acf_fft(x: np.ndarray) -> np.ndarray:
    """Full-length sample autocorrelation (biased estimator) by FFT."""
    x = np.asarray(x, float) - np.mean(x)
    n = len(x)
    f = np.fft.rfft(x, 2 * n)
    a = np.fft.irfft(f * np.conj(f))[:n]
    return a / a[0] if a[0] > 0 else np.zeros(n)


def acf_block_len(res: np.ndarray, dt: float, window_s: float, s: dict) -> dict:
    """Block length for the moving-block bootstrap chosen from the residual ACF (review 1): the first lag at
    which the full-resolution ACF falls below block_bootstrap.acf_threshold, but at least min_block_s and at
    most max_block_frac_window x window length."""
    bb = s["block_bootstrap"]
    a_raw = acf_fft(res)
    m = max(1, int(round(float(bb.get("smooth_s", 0.0)) / dt)))
    # the white quantisation component lowers the raw ACF at every lag; the decorrelation lag is read from
    # the ACF of the residual smoothed over smooth_s (moving average), which isolates the slow structure
    a = acf_fft(np.convolve(res, np.ones(m) / m, mode="valid")) if m > 1 and len(res) > 3 * m else a_raw
    below = np.flatnonzero(a < float(bb["acf_threshold"]))
    lag_s = float(below[0] * dt) if len(below) else float(len(a) * dt)
    blk = min(max(lag_s, float(bb["min_block_s"])), float(bb["max_block_frac_window"]) * window_s)
    lag120 = int(round(120.0 / dt))
    return dict(decorrelation_lag_s=lag_s, block_s=blk, block_samples=max(1, int(round(blk / dt))),
                acf_at_120s=float(a_raw[lag120]) if lag120 < len(a_raw) else None,
                acf_smoothed_at_120s=float(a[lag120]) if lag120 < len(a) else None)


# ======================================================================================================
# Rest selection
# ======================================================================================================
def collect_rests(logical_id: str, df, s: dict | None = None) -> list[dict]:
    """All rests after 1 A pulses (data.get_relaxations) with flags.  Exclusion rule (config
    relaxation_study.exclusion_rule): 'final_discharge' = rest after the last discharge pulse of the
    file; 'short_pulse' = preceding pulse charge < short_pulse_frac x median pulse charge of the file
    (voltage-limited pulses).  primary = no flag."""
    s = s or settings()
    rel = D.get_relaxations(logical_id, df)
    ah = np.array([r["pulse"]["Ah_trapz"] for r in rel])
    med = float(np.median(ah))
    dis_idx = [k for k, r in enumerate(rel) if r["pulse"]["direction"] == "discharge"]
    last_dis = max(dis_idx) if dis_idx else -1
    out = []
    for k, r in enumerate(rel):
        flags = []
        if k == last_dis:
            flags.append("final_discharge")
        if r["pulse"]["Ah_trapz"] < s["short_pulse_frac"] * med:
            flags.append("short_pulse")
        r = dict(r)
        r["flags"] = flags
        r["primary"] = not flags
        r["seg_index"] = k
        r["branch"] = r["pulse"]["direction"]
        out.append(r)
    return out


def log_subsample(t: np.ndarray, t0: float, t_end: float, n: int) -> np.ndarray:
    """Indices of the measured samples nearest to n log-spaced target times in [t0, t_end]
    (duplicates removed, so fewer than n indices are possible where the sampling is coarse)."""
    tg = np.geomspace(t0, t_end, n)
    idx = np.clip(np.searchsorted(t, tg), 1, len(t) - 1)
    left = t[idx - 1]
    idx = np.where(np.abs(tg - left) <= np.abs(t[idx] - tg), idx - 1, idx)
    idx = np.unique(idx)
    return idx[(t[idx] >= t0 - 1.0) & (t[idx] <= t_end + 1e-9)]


def design_subsample(t: np.ndarray, t0: float, t_end: float, design: str) -> np.ndarray:
    """Subsample design 'log<n>' (log-spaced, as log_subsample) or 'uniform<n>' (uniformly spaced targets)."""
    if design.startswith("log"):
        return log_subsample(t, t0, t_end, int(design[3:]))
    n = int(design[7:])
    tg = np.linspace(t0, t_end, n)
    idx = np.clip(np.searchsorted(t, tg), 1, len(t) - 1)
    idx = np.where(np.abs(tg - t[idx - 1]) <= np.abs(t[idx] - tg), idx - 1, idx)
    idx = np.unique(idx)
    return idx[(t[idx] >= t0 - 1.0) & (t[idx] <= t_end + 1e-9)]


# ======================================================================================================
# Information criteria and residual diagnostics
# ======================================================================================================
def gauss_ll(sse: float, n: int) -> float:
    return -0.5 * n * (math.log(2 * math.pi * max(sse, 1e-300) / n) + 1.0)


def aicc(ll: float, k: int, n: int) -> float:
    return -2 * ll + 2 * k + (2 * k * (k + 1) / (n - k - 1) if n - k - 1 > 0 else np.inf)


def bic(ll: float, k: int, n: int) -> float:
    return -2 * ll + k * math.log(n)


def ic_weights(v: np.ndarray) -> np.ndarray:
    d = v - np.nanmin(v)
    w = np.exp(-0.5 * d)
    return w / np.nansum(w)


def acf(x: np.ndarray, max_lag: int) -> np.ndarray:
    x = np.asarray(x, float) - np.mean(x)
    den = float(np.dot(x, x))
    return np.array([1.0] + [float(np.dot(x[:-k], x[k:]) / den) for k in range(1, max_lag + 1)])


def ljung_box(x: np.ndarray, lags: int) -> tuple[float, float]:
    n = len(x)
    r = acf(x, lags)[1:]
    q = n * (n + 2) * float(np.sum(r ** 2 / (n - np.arange(1, lags + 1))))
    return q, float(stats.chi2.sf(q, lags))


# ======================================================================================================
# Analysis A: tail laws by variable projection
# ======================================================================================================
def _bounds(s: dict) -> dict:
    b = s["phenomenological_bounds"]
    return {"PL": ([b["beta"][0]], [b["beta"][1]]),
            "EXP": ([b["log10_tau"][0]], [b["log10_tau"][1]]),
            "TPL": ([b["beta"][0], 1e3 * b["lambda"][0]], [b["beta"][1], 1e3 * b["lambda"][1]]),
            "2EXP": ([b["log10_tau"][0]] * 2, [b["log10_tau"][1]] * 2),
            "SEXP": ([b["sexp_log10_tau"][0], b["sexp_beta"][0]], [b["sexp_log10_tau"][1], b["sexp_beta"][1]])}


def basis(model: str, th: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Nonlinear basis columns (without the constant).  Internal parameters:
    PL (beta); EXP (log10 tau); TPL (beta, 1e3*lambda); 2EXP (log10 tau1, log10 tau2); SEXP (log10 tau, beta)."""
    if model == "PL":
        return (t ** -th[0])[:, None]
    if model == "EXP":
        return np.exp(-t / 10 ** th[0])[:, None]
    if model == "TPL":
        return (t ** -th[0] * np.exp(-1e-3 * th[1] * t))[:, None]
    if model == "2EXP":
        return np.column_stack([np.exp(-t / 10 ** th[0]), np.exp(-t / 10 ** th[1])])
    if model == "SEXP":
        return np.exp(-(t / 10 ** th[0]) ** th[1])[:, None]
    raise KeyError(model)


def lin_solve(B: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Least squares y ~ [1, B] c with column scaling; returns (c, residual)."""
    X = np.column_stack([np.ones(len(y)), B])
    sc = np.maximum(np.abs(X).max(axis=0), 1e-300)
    c, *_ = np.linalg.lstsq(X / sc, y, rcond=None)
    c = c / sc
    return c, y - X @ c


def _grid(model: str, s: dict) -> np.ndarray:
    lo, hi = _bounds(s)[model]
    if model == "PL":
        return np.geomspace(max(lo[0], 1e-4), hi[0], 160)[:, None]
    if model == "EXP":
        return np.linspace(lo[0], hi[0], 241)[:, None]
    if model == "TPL":
        B, L = np.meshgrid(np.geomspace(max(lo[0], 1e-4), hi[0], 90),
                           np.concatenate([[0.0], np.geomspace(1e-4, hi[1], 50)]), indexing="ij")
        return np.column_stack([B.ravel(), L.ravel()])
    if model == "2EXP":
        g = np.linspace(lo[0], hi[0], 61)
        A, Bq = np.meshgrid(g, g, indexing="ij")
        m = A < Bq
        return np.column_stack([A[m], Bq[m]])
    if model == "SEXP":
        A, Bq = np.meshgrid(np.linspace(lo[0], hi[0], 71), np.linspace(lo[1], hi[1], 39), indexing="ij")
        return np.column_stack([A.ravel(), Bq.ravel()])
    raise KeyError(model)


def _grid_sse(model: str, G: np.ndarray, t: np.ndarray, y: np.ndarray) -> np.ndarray:
    """SSE of the variable-projection problem at every grid point (vectorised)."""
    yc = y - y.mean()
    syy = float(yc @ yc)
    if model != "2EXP":
        if model == "PL":
            cols = t[:, None] ** -G[None, :, 0]
        elif model == "EXP":
            cols = np.exp(-t[:, None] / 10 ** G[None, :, 0])
        elif model == "TPL":
            cols = t[:, None] ** -G[None, :, 0] * np.exp(-1e-3 * G[None, :, 1] * t[:, None])
        elif model == "SEXP":
            cols = np.exp(-(t[:, None] / 10 ** G[None, :, 0]) ** G[None, :, 1])
        fc = cols - cols.mean(axis=0)
        sxx = np.einsum("ij,ij->j", fc, fc)
        sxy = fc.T @ yc
        with np.errstate(divide="ignore", invalid="ignore"):
            sse = syy - np.where(sxx > 1e-30 * syy, sxy ** 2 / sxx, 0.0)
        return sse
    taus = np.unique(G.ravel())
    E = np.exp(-t[:, None] / 10 ** taus[None, :])
    Ec = E - E.mean(axis=0)
    Gm = Ec.T @ Ec
    gy = Ec.T @ yc
    i = np.searchsorted(taus, G[:, 0]); j = np.searchsorted(taus, G[:, 1])
    a11, a22, a12 = Gm[i, i], Gm[j, j], Gm[i, j]
    det = a11 * a22 - a12 ** 2
    ok = det > 1e-12 * a11 * a22
    c1 = np.where(ok, (a22 * gy[i] - a12 * gy[j]) / np.where(ok, det, 1), 0)
    c2 = np.where(ok, (a11 * gy[j] - a12 * gy[i]) / np.where(ok, det, 1), 0)
    return np.where(ok, syy - (c1 * gy[i] + c2 * gy[j]), syy)


def fit_model(model: str, t: np.ndarray, y: np.ndarray, s: dict, rng: np.random.Generator,
              extra_starts: list | None = None) -> dict:
    """Bounded VP least squares with multi-start.  Returns internal params, amplitudes, SSE."""
    lo, hi = (np.array(v, float) for v in _bounds(s)[model])
    G = _grid(model, s)
    sse_g = _grid_sse(model, G, t, y)
    order = np.argsort(sse_g)
    starts = [G[order[0]]]
    for k in order[1:]:
        if len(starts) >= s["n_grid_starts"]:
            break
        if np.all(np.abs(G[k] - np.array(starts)).max(axis=1) > 0.05 * (hi - lo).max()):
            starts.append(G[k])
    starts += [lo + (hi - lo) * rng.random(len(lo)) for _ in range(s["n_random_starts"])]
    if extra_starts:
        starts = list(extra_starts) + starts

    def res(th):
        return lin_solve(basis(model, th, t), y)[1]

    best = None
    for x0 in starts:
        x0 = np.clip(np.asarray(x0, float), lo, hi)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                r = optimize.least_squares(res, x0, bounds=(lo, hi), method="trf", x_scale="jac",
                                           xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=400)
            sse = float(r.fun @ r.fun)
            th = r.x
        except Exception:  # pragma: no cover - defensive
            continue
        if best is None or sse < best[0]:
            best = (sse, th)
    gi = int(order[0])
    if best is None or sse_g[gi] < best[0]:
        best = (float(sse_g[gi]), G[gi])
    th = np.asarray(best[1], float)
    if model == "2EXP" and th[0] > th[1]:
        th = th[::-1].copy()
    c, r = lin_solve(basis(model, th, t), y)
    return dict(model=model, theta=th, c=c, sse=float(r @ r), resid=r)


def predict(model: str, th: np.ndarray, c: np.ndarray, t: np.ndarray) -> np.ndarray:
    return c[0] + basis(model, th, t) @ c[1:]


def _refit_at(model: str, th, t, y) -> dict:
    th = np.asarray(th, float)
    c, r = lin_solve(basis(model, th, t), y)
    return dict(model=model, theta=th, c=c, sse=float(r @ r), resid=r)


def fit_all(t: np.ndarray, y: np.ndarray, s: dict, rng: np.random.Generator, models=MODELS) -> dict:
    """All tail laws with the nesting enforced (review 1): TPL is started from the PL optimum (beta_PL,
    lambda = 0) and 2EXP from the EXP optimum (tau_EXP, tau2 at the upper bound: second column ~ constant),
    and SSE_TPL <= SSE_PL, SSE_2EXP <= SSE_EXP are guaranteed by falling back to these nested points."""
    fits = {}
    for m in ("PL", "EXP"):
        if m in models or {"PL": "TPL", "EXP": "2EXP"}[m] in models:
            fits[m] = fit_model(m, t, y, s, rng)
    if "TPL" in models:
        nest = [fits["PL"]["theta"][0], 0.0]
        f = fit_model("TPL", t, y, s, rng, extra_starts=[nest])
        if f["sse"] > fits["PL"]["sse"]:
            f = _refit_at("TPL", nest, t, y)
        f["nest_fallback"] = bool(np.allclose(f["theta"], nest))
        fits["TPL"] = f
    if "2EXP" in models:
        hi = _bounds(s)["2EXP"][1][0]
        le = float(fits["EXP"]["theta"][0])
        nest = [le, hi]
        f = fit_model("2EXP", t, y, s, rng, extra_starts=[nest, [max(le - 0.5, 0.0), min(le + 0.5, hi)]])
        if f["sse"] > fits["EXP"]["sse"]:
            f = _refit_at("2EXP", nest, t, y)
        fits["2EXP"] = f
    if "SEXP" in models:
        fits["SEXP"] = fit_model("SEXP", t, y, s, rng)
    return {m: fits[m] for m in models}


def tpl_vinf_lambda_corr(t: np.ndarray, th: np.ndarray, c: np.ndarray) -> float | None:
    """Gauss-Newton correlation of (V_inf, lambda) in the TPL fit V_inf + A t^-beta exp(-lambda t)."""
    beta, lam, A = float(th[0]), 1e-3 * float(th[1]), float(c[1])
    g = t ** -beta * np.exp(-lam * t)
    J = np.column_stack([np.ones_like(t), g, -A * np.log(t) * g, -A * t * g])
    sc = np.maximum(np.abs(J).max(axis=0), 1e-300)
    try:
        C = np.linalg.pinv((J / sc).T @ (J / sc))
    except np.linalg.LinAlgError:
        return None
    d = np.sqrt(np.maximum(np.diag(C), 1e-300))
    return float(C[0, 3] / (d[0] * d[3]))


def design_fit(t_all: np.ndarray, V_all: np.ndarray, t0: float, design: str, s: dict,
               rng: np.random.Generator) -> dict:
    """Light refit of one rest under an alternative window start / subsample design (review 1): BIC ranking,
    Delta-BIC TPL - reference, TPL lambda and corr(V_inf, lambda).  No profile, no bootstrap."""
    w = t_all >= t0 - 1e-9
    t_full, V_full = t_all[w], V_all[w]
    y_full = (V_full - float(V_full[-1])) * 1e3
    sub = design_subsample(t_full, t0, float(t_full[-1]), design)
    t, y = t_full[sub], y_full[sub]
    n = len(t)
    fits = fit_all(t, y, s, rng)
    b = {m: bic(gauss_ll(fits[m]["sse"], n), N_NONLIN[m] + N_LIN[m] + 1, n) for m in MODELS}
    return dict(n_sub=int(n), best_bic=min(b, key=b.get), bic=b,
                dbic_TPL_minus={m: b["TPL"] - b[m] for m in MODELS if m != "TPL"},
                tpl_lambda_s_inv=1e-3 * float(fits["TPL"]["theta"][1]),
                corr_vinf_lambda=tpl_vinf_lambda_corr(t, fits["TPL"]["theta"], fits["TPL"]["c"]),
                nesting_ok=bool(fits["TPL"]["sse"] <= fits["PL"]["sse"] * (1 + 1e-9)
                                and fits["2EXP"]["sse"] <= fits["EXP"]["sse"] * (1 + 1e-9)))


def public_params(model: str, th: np.ndarray, c: np.ndarray, v_ref: float = 0.0, scale: float = 1e3) -> dict:
    """Physical parameter names/units.  The fits run on y = (V - v_ref) * scale (mV); V_inf and
    amplitudes are returned in V."""
    c = np.array(c, float) / scale
    d = dict(V_inf_V=float(v_ref + c[0]))
    if model == "PL":
        d.update(A_V=float(c[1]), beta=float(th[0]))
    elif model == "EXP":
        d.update(A_V=float(c[1]), tau_s=float(10 ** th[0]))
    elif model == "TPL":
        d.update(A_V=float(c[1]), beta=float(th[0]), lambda_s_inv=float(1e-3 * th[1]))
    elif model == "2EXP":
        d.update(A1_V=float(c[1]), tau1_s=float(10 ** th[0]), A2_V=float(c[2]), tau2_s=float(10 ** th[1]))
    elif model == "SEXP":
        d.update(A_V=float(c[1]), tau_s=float(10 ** th[0]), beta=float(th[1]))
    return d


# ------------------------------------------------------------------------------------------------------
# TPL: profile likelihood in lambda and residual block bootstrap
# ------------------------------------------------------------------------------------------------------
def lambda_profile_grid(s: dict, n: int = 150) -> np.ndarray:
    hi = s["phenomenological_bounds"]["lambda"][1]
    return np.concatenate([[0.0], np.geomspace(s["lambda_zero_threshold_s_inv"], hi, n)])


def tpl_profile(t: np.ndarray, y: np.ndarray, s: dict, lam_grid: np.ndarray) -> np.ndarray:
    """Minimum SSE over (beta, V_inf, A) at each fixed lambda."""
    lo, hi = s["phenomenological_bounds"]["beta"]
    bg = np.geomspace(max(lo, 1e-4), hi, 240)
    yc = y - y.mean()
    syy = float(yc @ yc)
    tb = t[:, None] ** -bg[None, :]
    out = np.empty(len(lam_grid))
    for i, lam in enumerate(lam_grid):
        cols = tb * np.exp(-lam * t)[:, None]
        fc = cols - cols.mean(axis=0)
        sxx = np.einsum("ij,ij->j", fc, fc)
        sse = syy - np.where(sxx > 1e-30 * syy, (fc.T @ yc) ** 2 / np.where(sxx > 0, sxx, 1), 0.0)
        k = int(np.argmin(sse))
        a, b = bg[max(k - 1, 0)], bg[min(k + 1, len(bg) - 1)]

        def f(beta, lam=lam):
            return float(np.sum(lin_solve((t ** -beta * np.exp(-lam * t))[:, None], y)[1] ** 2))
        if b > a:
            r = optimize.minimize_scalar(f, bounds=(a, b), method="bounded", options=dict(xatol=1e-7))
            out[i] = min(float(r.fun), float(sse[k]))
        else:
            out[i] = float(sse[k])
    return out


def profile_interval(grid: np.ndarray, sse: np.ndarray, sse_hat: float, n: int,
                     crit: float = 2.705543454095404) -> dict:
    """Profile-likelihood confidence SET {lambda: dev(lambda) = n ln(SSE(lambda)/SSE_hat) <= crit} (Gaussian iid).

    Review 1: the set is returned as a UNION of intervals ('intervals'; a multimodal profile gives several),
    'lower'/'upper' are the ends of its hull, and 'excludes_zero' is dev(0) > crit, so the zero test is the
    chi-bar-square LR test at the same critical value (default 2.71 = boundary-consistent 95 %).  Interval ends
    are interpolated in log(lambda) between grid nodes.  The connected component around lambda-hat at the
    two-sided chi2_1 value 3.84 (the pre-review definition) is kept as 'cc384_lower'/'cc384_upper'."""
    dev = np.maximum(n * np.log(np.maximum(sse, 1e-300) / sse_hat), 0.0)
    inside = dev <= crit
    ivs = []
    i = 0
    N = len(grid)
    while i < N:
        if not inside[i]:
            i += 1
            continue
        j = i
        while j + 1 < N and inside[j + 1]:
            j += 1
        lo_ = float(grid[i]) if (i == 0 or grid[i] == 0.0) else _cross(grid, dev, crit, i, i - 1)
        hi_ = float(grid[-1]) if j == N - 1 else _cross(grid, dev, crit, j, j + 1)
        ivs.append([lo_, hi_])
        i = j + 1
    cc = _profile_cc(grid, dev, 3.841458820694124)
    dev0 = float(dev[0]) if grid[0] == 0.0 else None
    return dict(lower=ivs[0][0] if ivs else float("nan"), upper=ivs[-1][1] if ivs else float("nan"),
                intervals=ivs, n_intervals=len(ivs), crit=float(crit),
                upper_censored_at_bound=bool(inside[-1]), lower_at_zero=bool(grid[0] == 0.0 and inside[0]),
                excludes_zero=bool(dev0 is not None and dev0 > crit),
                dev_at_zero=dev0, n_grid_inside=int(np.sum(inside)),
                cc384_lower=cc["lower"], cc384_upper=cc["upper"], dev=dev.tolist())


def _cross(grid, dev, crit, i_in, i_out) -> float:
    if grid[i_out] == 0.0:
        return 0.0
    if grid[i_in] == 0.0:            # between the zero node and the first positive node: report the node
        return float(grid[i_out])
    f = (crit - dev[i_in]) / (dev[i_out] - dev[i_in])
    return float(np.exp(np.log(grid[i_in]) + f * (np.log(grid[i_out]) - np.log(grid[i_in]))))


def _profile_cc(grid: np.ndarray, dev: np.ndarray, crit: float) -> dict:
    """Pre-review definition: connected component of {dev <= crit} around the profile minimum."""
    k = int(np.argmin(dev))

    def cross(i_in, i_out):
        if grid[i_out] == 0.0:
            return 0.0
        if grid[i_in] == 0.0:        # between the zero node and the first positive node: report the node
            return float(grid[i_out])
        f = (crit - dev[i_in]) / (dev[i_out] - dev[i_in])
        return float(np.exp(np.log(grid[i_in]) + f * (np.log(grid[i_out]) - np.log(grid[i_in]))))
    i = k
    while i - 1 >= 0 and dev[i - 1] <= crit:
        i -= 1
    if i == 0:
        lower = float(grid[0])
    else:
        lower = cross(i, i - 1)
    j = k
    while j + 1 < len(grid) and dev[j + 1] <= crit:
        j += 1
    upper = float(grid[-1]) if j == len(grid) - 1 else cross(j, j + 1)
    return dict(lower=lower, upper=upper)


def merge_profile(grid: np.ndarray, sse: np.ndarray, lam_extra, sse_extra) -> tuple[np.ndarray, np.ndarray]:
    """Add refinement points (lambda, SSE) to a profile and sort (duplicates: keep the lower SSE)."""
    g = np.concatenate([grid, np.atleast_1d(lam_extra)])
    v = np.concatenate([sse, np.atleast_1d(sse_extra)])
    o = np.lexsort((v, g))
    g, v = g[o], v[o]
    keep = np.concatenate([[True], np.diff(g) > 0])
    return g[keep], v[keep]


REFINE_STEPS = np.array([-0.2, -0.1, -0.05, -0.02, 0.02, 0.05, 0.1, 0.2])   # ln-lambda offsets around lambda-hat


def _ls(model: str, x0, tt, ys, lo, hi, tol=1e-10, nfev=200):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        r = optimize.least_squares(lambda th: lin_solve(basis(model, th, tt), ys)[1], np.clip(np.asarray(x0, float), lo, hi),
                                   bounds=(lo, hi), method="trf", x_scale="jac", xtol=tol, ftol=tol, max_nfev=nfev)
    return float(r.fun @ r.fun), r.x


def _fit_pl_tpl_fast(tt, ys, s, x_pl, x_tpl, G_pl, G_tpl) -> tuple[float, np.ndarray, float, np.ndarray]:
    """PL and TPL refits of one bootstrap replicate (grid best + supplied starts; nesting enforced)."""
    lo1, hi1 = (np.array(v, float) for v in _bounds(s)["PL"])
    lo2, hi2 = (np.array(v, float) for v in _bounds(s)["TPL"])
    best1 = None
    for x0 in (x_pl, G_pl[int(np.argmin(_grid_sse("PL", G_pl, tt, ys)))]):
        r = _ls("PL", x0, tt, ys, lo1, hi1)
        if best1 is None or r[0] < best1[0]:
            best1 = r
    best2 = None
    for x0 in (x_tpl, G_tpl[int(np.argmin(_grid_sse("TPL", G_tpl, tt, ys)))], [best1[1][0], 0.0]):
        r = _ls("TPL", x0, tt, ys, lo2, hi2)
        if best2 is None or r[0] < best2[0]:
            best2 = r
    if best2[0] > best1[0]:
        best2 = (best1[0], np.array([best1[1][0], 0.0]))
    return best1[0], best1[1], best2[0], best2[1]


def block_bootstrap(t_full: np.ndarray, y_full: np.ndarray, sub: np.ndarray, gen: str, th_gen: np.ndarray,
                    c_gen: np.ndarray, block_samples: int, n_rep: int, s: dict, rng: np.random.Generator,
                    th_pl: np.ndarray, th_tpl: np.ndarray) -> np.ndarray:
    """Circular moving-block bootstrap of the full-resolution residuals of the generating model gen
    ('TPL': percentile intervals and TPL-true detection rate; 'PL': null-constrained calibration of the
    TPL-vs-PL LR statistic), refit on the same subsample.  Returns (n_rep, 4): beta_TPL, lambda_TPL [1/s],
    SSE_PL, SSE_TPL."""
    pred = predict(gen, th_gen, c_gen, t_full)
    res = y_full - pred
    N = len(res)
    L = int(block_samples)
    nb = int(np.ceil(N / L))
    G_pl, G_tpl = _grid("PL", s), _grid("TPL", s)
    tt = t_full[sub]
    out = np.empty((n_rep, 4))
    for b in range(n_rep):
        st = rng.integers(0, N, nb)
        idx = ((st[:, None] + np.arange(L)[None, :]) % N).ravel()[:N]
        ys = (pred + res[idx])[sub]
        s1, x1, s2, x2 = _fit_pl_tpl_fast(tt, ys, s, th_pl, th_tpl, G_pl, G_tpl)
        out[b] = (x2[0], 1e-3 * x2[1], s1, s2)
    return out


# ------------------------------------------------------------------------------------------------------
# One rest segment, all models
# ------------------------------------------------------------------------------------------------------
def fit_segment(r: dict, t0: float, s: dict, rng: np.random.Generator, do_bootstrap: bool,
                keep_curves: bool = False, do_profile: bool = True) -> dict:
    t_all, V_all = np.asarray(r["t"], float), np.asarray(r["V"], float)
    t_end = float(t_all[-1])
    w = (t_all >= t0 - 1e-9) & (t_all <= t_end)
    t_full, V_full = t_all[w], V_all[w]
    v_ref = float(V_full[-1])
    y_full = (V_full - v_ref) * 1e3                       # mV relative to the last sample of the rest
    sub = log_subsample(t_full, t0, t_end, int(s["n_subsample"]))
    t, y = t_full[sub], y_full[sub]
    n = len(t)
    out = dict(t0_s=t0, t_end_s=t_end, n_sub=int(n), n_full=int(len(t_full)), v_ref_V=v_ref, models={})
    fits = fit_all(t, y, s, rng)
    for m in MODELS:
        f = fits[m]
        k = N_NONLIN[m] + N_LIN[m] + 1
        ll = gauss_ll(f["sse"], n)
        res_full = y_full - predict(m, f["theta"], f["c"], t_full)
        q, p = ljung_box(f["resid"], int(s["ljung_box_lags"]))
        a = acf(f["resid"], int(s["acf_max_lag"]))
        out["models"][m] = dict(params=public_params(m, f["theta"], f["c"], v_ref), k=k, sse_mV2=f["sse"],
                                rmse_mV=float(np.sqrt(f["sse"] / n)),
                                max_abs_err_mV=float(np.max(np.abs(f["resid"]))),
                                rmse_full_mV=float(np.sqrt(np.mean(res_full ** 2))),
                                max_abs_err_full_mV=float(np.max(np.abs(res_full))),
                                vinf_minus_last_mV=float(f["c"][0]),
                                loglik=ll, aicc=aicc(ll, k, n), bic=bic(ll, k, n),
                                acf_lag1=float(a[1]), ljung_box_Q=q, ljung_box_p=p, acf=a.tolist())
    for key, fn in (("aicc", "akaike_weight"), ("bic", "bic_weight")):
        v = np.array([out["models"][m][key] for m in MODELS])
        for m, wv in zip(MODELS, ic_weights(v)):
            out["models"][m][fn] = float(wv)
    out["best_aicc"] = min(MODELS, key=lambda m: out["models"][m]["aicc"])
    out["best_bic"] = min(MODELS, key=lambda m: out["models"][m]["bic"])
    out["nesting"] = dict(tpl_le_pl=bool(fits["TPL"]["sse"] <= fits["PL"]["sse"] * (1 + 1e-12)),
                          twoexp_le_exp=bool(fits["2EXP"]["sse"] <= fits["EXP"]["sse"] * (1 + 1e-12)),
                          tpl_nest_fallback=bool(fits["TPL"].get("nest_fallback", False)))
    lam_hat = out["models"]["TPL"]["params"]["lambda_s_inv"]
    thr = s["lambda_zero_threshold_s_inv"]
    lr_fit = max(0.0, n * math.log(fits["PL"]["sse"] / fits["TPL"]["sse"]))
    out["tpl_lambda"] = dict(lambda_hat_s_inv=lam_hat, lambda_hat_reported=lam_hat if lam_hat >= thr else 0.0,
                             lambda_t_end=lam_hat * t_end, lr_vs_pl_fit=lr_fit,
                             corr_vinf_lambda=tpl_vinf_lambda_corr(t, fits["TPL"]["theta"], fits["TPL"]["c"]))
    if do_profile:
        # TPL lambda: profile likelihood (grid in lambda, beta and the amplitudes profiled out)
        grid = lambda_profile_grid(s)
        prof = tpl_profile(t, y, s, grid)
        sse_hat = min(fits["TPL"]["sse"], float(prof.min()))
        if lam_hat > 0:
            ex = lam_hat * np.exp(REFINE_STEPS)
            ex = ex[ex <= grid[-1]]
            grid, prof = merge_profile(grid, prof, np.concatenate([[lam_hat], ex]),
                                       np.concatenate([[fits["TPL"]["sse"]], tpl_profile(t, y, s, ex)]))
        ci = profile_interval(grid, prof, sse_hat, n, s["profile_crit"])
        lr = max(0.0, n * math.log(fits["PL"]["sse"] / sse_hat))
        out["tpl_lambda"].update(profile_ci95={k_: v_ for k_, v_ in ci.items() if k_ != "dev"},
                                 lr_vs_pl=lr, lr_p_chibar=float(0.5 * stats.chi2.sf(lr, 1)) if lr > 0 else 0.5,
                                 profile_excludes_zero=ci["excludes_zero"],
                                 profile_excludes_zero_cc384=bool(ci["cc384_lower"] >= thr))
    if keep_curves:
        out["_curves"] = dict(t_full=t_full, y_full=y_full, t_sub=t, y_sub=y, lam_grid=grid,
                              lam_profile_dev=np.array(ci["dev"]),
                              theta={m: fits[m]["theta"] for m in MODELS}, c={m: fits[m]["c"] for m in MODELS})
    if do_bootstrap:
        dt = float(np.median(np.diff(t_full)))
        win = float(t_full[-1] - t_full[0])
        th_pl, th_tpl = fits["PL"]["theta"], fits["TPL"]["theta"]
        # (i) TPL-generated replicates: percentile intervals of lambda and the TPL-true detection rate
        blk = acf_block_len(y_full - predict("TPL", th_tpl, fits["TPL"]["c"], t_full), dt, win, s)
        bs = block_bootstrap(t_full, y_full, sub, "TPL", th_tpl, fits["TPL"]["c"], blk["block_samples"],
                             int(s["n_boot"]), s, rng, th_pl, th_tpl)
        lam_b = bs[:, 1]
        dbic_b = -n * np.log(bs[:, 2] / bs[:, 3]) + math.log(n)
        lo_b, hi_b = np.percentile(lam_b, [2.5, 97.5])
        out["tpl_lambda"]["bootstrap"] = dict(
            n_boot=int(len(lam_b)), lambda_ci95=[float(lo_b), float(hi_b)], lambda_median=float(np.median(lam_b)),
            frac_lambda_below_threshold=float(np.mean(lam_b < thr)),
            beta_ci95=[float(x) for x in np.percentile(bs[:, 0], [2.5, 97.5])], excludes_zero=bool(lo_b >= thr),
            block=blk, tpl_true_dbic_median=float(np.median(dbic_b)),
            tpl_true_frac_dbic_below_strong=float(np.mean(dbic_b < -float(s["decision_rules"]["strong_delta_bic"]))))
        # (ii) PL-null (lambda = 0) parametric block bootstrap of the TPL-vs-PL LR statistic
        blk0 = acf_block_len(y_full - predict("PL", th_pl, fits["PL"]["c"], t_full), dt, win, s)
        nb0 = block_bootstrap(t_full, y_full, sub, "PL", th_pl, fits["PL"]["c"], blk0["block_samples"],
                              int(s["null_calibration"]["n_null"]), s, rng, th_pl, np.array([th_pl[0], 0.0]))
        lr0 = np.maximum(n * np.log(nb0[:, 2] / nb0[:, 3]), 0.0)
        dbic0 = -lr0 + math.log(n)
        out["tpl_lambda"]["null_pl"] = dict(
            n_null=int(len(lr0)), block=blk0, lr_obs=lr_fit, p_calibrated=float((1 + np.sum(lr0 >= lr_fit)) / (1 + len(lr0))),
            lr_null_q95=float(np.percentile(lr0, 95)), dbic_null_q05=float(np.percentile(dbic0, 5)),
            frac_null_dbic_below_strong=float(np.mean(dbic0 < -float(s["decision_rules"]["strong_delta_bic"]))),
            frac_null_dbic_negative=float(np.mean(dbic0 < 0)))
    return out


# ======================================================================================================
# Analysis B: tempered fractional polarisation element as a bank of first-order modes
# ======================================================================================================
def quad_nodes(s: dict) -> tuple[np.ndarray, np.ndarray]:
    """Trapezoid nodes r_j = exp(u_j) and weights q_j (in u) on [ln r_min, ln r_max], preceded by one
    lumped node r = 0 that carries the whole spectral mass below r_min (see mode_weights)."""
    m = s["mechanistic"]
    u0, u1 = m["quad_log_r"]
    n = int(round((u1 - u0) / m["quad_du"])) + 1
    u = np.linspace(u0, u1, n)
    q = np.full(n, u[1] - u[0])
    q[0] *= 0.5
    q[-1] *= 0.5
    return np.concatenate([[0.0], np.exp(u)]), np.concatenate([[np.nan], q])


def _low_tail_nodes(s: dict) -> tuple[np.ndarray, np.ndarray]:
    m = s["mechanistic"]
    u0 = m["quad_log_r"][0]
    u = np.arange(-100.0, u0 + 1e-12, m["quad_du"])
    u = np.linspace(-100.0, u0, len(u))
    q = np.full(len(u), u[1] - u[0]); q[0] *= 0.5; q[-1] *= 0.5
    return np.exp(u), q


def spectral_density(r: np.ndarray, alpha, a) -> np.ndarray:
    """K_a(r) = (1/pi) a r^(alpha-1) sin(alpha pi) / (r^(2alpha) + 2 a r^alpha cos(alpha pi) + a^2).
    alpha and a broadcast against r (use column vectors for grids)."""
    ra = r ** alpha
    return a * (ra / r) * np.sin(alpha * np.pi) / (np.pi * (ra * ra + 2 * a * ra * np.cos(alpha * np.pi) + a * a))


_TAIL_CACHE: dict = {}


def mode_weights(r: np.ndarray, q: np.ndarray, alpha, a, s: dict | None = None) -> np.ndarray:
    """w_j with g_lambda(tau) ~= sum_j w_j exp(-(r_j + lambda) tau): w = (1/a) r K_a(r) * r du on the bank
    nodes; the lumped node r = 0 gets W_low = (1/a) int_0^{r_min} r K_a(r) dr (trapezoid in ln r from
    r = e^-100).  Modes with r < r_min = 1e-8 1/s change by less than r_min * 1.7e5 s = 0.2 % over a whole
    file, so they are lumped at rate lambda (they are NOT constant within a rest when lambda > 0)."""
    s = s or settings()
    key = id(s)
    if key not in _TAIL_CACHE:
        _TAIL_CACHE.clear()
        _TAIL_CACHE[key] = _low_tail_nodes(s)
    rt, qt = _TAIL_CACHE[key]
    alpha = np.asarray(alpha, float)
    a = np.asarray(a, float)
    wb = spectral_density(r[1:], alpha, a) * r[1:] * r[1:] * q[1:] / a
    wl = np.sum(spectral_density(rt, alpha, a) * rt * rt * qt / a, axis=-1, keepdims=True)
    return np.concatenate([np.broadcast_to(wl, wb.shape[:-1] + (1,)), wb], axis=-1)


def ml_kernel_mpmath(tau: float, alpha: float, a: float, lam: float, method: str = "series") -> float:
    """Direct g_lambda(tau) = e^{-lambda tau} tau^{alpha-1} E_{alpha,alpha}(-a tau^alpha) in mpmath.
    'series': Mittag-Leffler power series at adaptive precision; 'talbot': numerical inverse Laplace
    transform of 1/((s+lambda)^alpha + a) (independent route)."""
    import mpmath as mp
    if method == "series":
        big = float(a * tau ** alpha) ** (1.0 / alpha)
        with mp.workdps(int(40 + big / 2.0)):
            al, z = mp.mpf(alpha), -mp.mpf(a) * mp.mpf(tau) ** mp.mpf(alpha)
            term_sum = mp.mpf(0)
            k = 0
            while True:
                term = z ** k / mp.gamma(al * k + al)
                term_sum += term
                if k > 10 and abs(term) < mp.mpf(10) ** (-30) * max(abs(term_sum), mp.mpf(10) ** (-300)):
                    break
                k += 1
                if k > 200000:
                    raise RuntimeError("series did not converge")
            val = mp.exp(-mp.mpf(lam) * tau) * mp.mpf(tau) ** (al - 1) * term_sum
        return float(val)
    with mp.workdps(30):
        f = lambda sv: 1 / ((sv + lam) ** alpha + a)  # noqa: E731
        return float(mp.invertlaplace(f, tau, method="talbot"))


def verify_kernel(s: dict, param_sets: list[tuple[float, float, float]], taus: np.ndarray) -> dict:
    """Compare the mode bank with direct Mittag-Leffler evaluation, and its L1 norm with 1/(a+lambda^alpha)."""
    import mpmath as mp
    r, q = quad_nodes(s)
    out = []
    for alpha, a, lam in param_sets:
        w = mode_weights(r, q, alpha, a, s)
        bank = np.array([np.sum(w * np.exp(-(r + lam) * tt)) for tt in taus])
        direct, meth = [], []
        for tt in taus:
            big = (a * tt ** alpha) ** (1 / alpha)
            mth = "series" if big < 600 else "talbot"
            direct.append(ml_kernel_mpmath(tt, alpha, a, lam, mth)); meth.append(mth)
        direct = np.array(direct)
        tmin = float(s["mechanistic"].get("kernel_valid_tau_min_s", 0.0))
        ok = (np.abs(direct) > 1e-12 * np.abs(direct).max()) & (taus >= tmin)   # vanished kernel / below valid tau ignored
        rel = np.abs(bank - direct)[ok] / np.abs(direct[ok])
        bad = taus < tmin
        rel_below = (np.abs(bank - direct)[bad] / np.abs(direct[bad])) if bad.any() else np.array([np.nan])
        # L1 norm: bank part + analytic tails outside [r_min, r_max] (computed by mpmath quadrature)
        l1_bank = float(np.sum(w[1:] / (r[1:] + lam)))   # bank nodes only; tails below exact
        with mp.workdps(30):
            K = lambda x: (a * x ** (alpha - 1) * mp.sin(alpha * mp.pi) / mp.pi  # noqa: E731
                           / (x ** (2 * alpha) + 2 * a * x ** alpha * mp.cos(alpha * mp.pi) + a * a))
            g = lambda x: x * K(x) / (x + lam) / a  # noqa: E731
            lo_tail = float(mp.quad(g, [0, 1e-20, 1e-14, r[1]]))
            hi_tail = float(mp.quad(g, [r[-1], 10 * r[-1], mp.inf]))
            spectral_total = float(mp.quad(g, [0, 1e-12, 1e-6, 1e-2, 1, 100, mp.inf]))
        exact = 1.0 / (a + lam ** alpha)
        out.append(dict(alpha=alpha, a=a, lam=lam, tau_s=taus.tolist(), max_rel_err_kernel=float(rel.max()),
                        max_rel_err_kernel_below_valid_tau=float(np.nanmax(rel_below)),
                        n_tau_compared=int(ok.sum()), rel_err_by_tau=[float(v) for v in np.abs(bank - direct) / np.abs(direct)],
                        methods=sorted(set(meth)), l1_exact=exact, l1_bank_only=l1_bank,
                        l1_bank_plus_tails=l1_bank + lo_tail + hi_tail, l1_spectral_integral=spectral_total,
                        rel_err_l1_bank_plus_tails=abs(l1_bank + lo_tail + hi_tail - exact) / exact,
                        rel_err_l1_spectral_integral=abs(spectral_total - exact) / exact,
                        frac_l1_outside_bank=(lo_tail + hi_tail) / exact))
    return dict(n_nodes=int(len(r) - 1), n_lumped_nodes=1, r_min=float(r[1]), r_max=float(r[-1]), du=float(s["mechanistic"]["quad_du"]),
                checks=out, max_rel_err_kernel=max(c["max_rel_err_kernel"] for c in out),
                valid_tau_min_s=float(s["mechanistic"].get("kernel_valid_tau_min_s", 0.0)),
                max_rel_err_kernel_below_valid_tau=max(c["max_rel_err_kernel_below_valid_tau"] for c in out),
                max_frac_l1_outside_bank=max(c["frac_l1_outside_bank"] for c in out),
                max_rel_err_l1=max(c["rel_err_l1_bank_plus_tails"] for c in out),
                tol=float(s["mechanistic"]["kernel_check_tol_rel"]))


class Drive:
    """Full measured current history of one file under zero-order hold, and the rest windows used as data."""

    def __init__(self, df, rests: list[dict], t0: float, n_sub: int):
        self.t = df[D.COL["t"]].to_numpy().astype(float)
        self.I = df[D.COL["I"]].to_numpy().astype(float)
        dt = np.diff(self.t)
        In = self.I[:-1]
        active = In != 0.0
        self.rests = rests
        self.i0 = np.array([int(r["i_start"]) for r in rests])
        # runs of equal activity, split additionally at every rest start
        cuts = set(np.flatnonzero(np.diff(active.astype(int)) != 0) + 1) | set(self.i0.tolist()) | {0, len(In)}
        cuts = sorted(c for c in cuts if 0 <= c <= len(In))
        self.runs = [(a_, b_, bool(active[a_])) for a_, b_ in zip(cuts[:-1], cuts[1:]) if b_ > a_]
        self.dt, self.In = dt, In
        # observations: log-spaced subsample of each rest window [t0, end of rest]
        tt, yy, seg, ta = [], [], [], []
        for k, r in enumerate(rests):
            trel = np.asarray(r["t"], float)
            w = trel >= t0 - 1e-9
            sub = log_subsample(trel[w], t0, float(trel[-1]), n_sub)
            ti = trel[w][sub]
            V = np.asarray(r["V"], float)[w][sub]
            tt.append(ti + r["t_interruption_abs_s"] - self.t[r["i_start"]])   # time since first rest sample
            yy.append((V - float(r["V_last"])) * 1e3)                          # mV (offset absorbed by OCV_s)
            seg.append(np.full(len(ti), k))
            ta.append(ti)
        self.tau = np.concatenate(tt)
        self.t_since_interrupt = np.concatenate(ta)
        self.y = np.concatenate(yy)
        self.seg = np.concatenate(seg)
        self.ptr = np.concatenate([[0], np.cumsum([len(x) for x in tt])])
        self.n_seg = len(rests)

    def states(self, k: np.ndarray) -> np.ndarray:
        """Mode states x_j (x' = -k_j x + I) at the first sample of every rest: shape (n_rests, J)."""
        k = np.asarray(k, float)
        x = np.zeros_like(k)
        want = {int(i): n for n, i in enumerate(self.i0)}
        X = np.zeros((len(self.i0), len(k)))
        t = self.t
        for a_, b_, act in self.runs:
            if a_ in want:
                X[want[a_]] = x
            T = t[b_]
            if not act:
                x = x * np.exp(-k * (T - t[a_]))
            else:
                n = np.arange(a_, b_)
                kd = np.outer(k, self.dt[n])
                phi1 = np.where(kd > 0, -np.expm1(-kd) / np.where(k[:, None] > 0, k[:, None], 1.0), self.dt[n][None, :])
                E = np.exp(-np.outer(k, T - t[n + 1])) * phi1
                x = x * np.exp(-k * (T - t[a_])) + E @ self.In[n]
        if len(self.In) in want:
            X[want[len(self.In)]] = x
        return X

    def basis(self, k: np.ndarray) -> np.ndarray:
        """Phi[obs, j] = x_j(rest start) exp(-k_j tau_obs) (current is exactly 0 during the rests)."""
        X = self.states(k)
        return X[self.seg] * np.exp(-np.outer(self.tau, k))

    def seg_stats(self, S: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Per-segment centred sufficient statistics Sxx (n_seg, G), Sxy (n_seg, G), Syy (n_seg,)."""
        cnt = np.diff(self.ptr).astype(float)
        st = self.ptr[:-1]
        sS = np.add.reduceat(S, st, axis=0)
        sy = np.add.reduceat(self.y, st)
        Sxx = np.add.reduceat(S * S, st, axis=0) - sS ** 2 / cnt[:, None]
        Sxy = np.add.reduceat(S * self.y[:, None], st, axis=0) - sS * sy[:, None] / cnt[:, None]
        Syy = np.add.reduceat(self.y ** 2, st) - sy ** 2 / cnt
        return Sxx, Sxy, Syy


def sse_from_stats(wts: np.ndarray, Sxx, Sxy, Syy) -> tuple[np.ndarray, np.ndarray]:
    """SSE and gain b >= 0 for segment weights wts (n_w, n_seg) (multiplicities or 0/1 subset masks)."""
    xx, xy, yy = wts @ Sxx, wts @ Sxy, wts @ Syy
    b = np.where(xy > 0, xy / np.where(xx > 0, xx, 1), 0.0)
    return yy[..., None] - b * xy, b


def sse_free_gain(wts: np.ndarray, Sxx, Sxy, Syy) -> tuple[np.ndarray, np.ndarray]:
    """Shape-only variant: a separate gain b_s >= 0 for every rest (amplitude nuisance).  Returns the
    weighted SSE and the weighted mean of the per-rest gains."""
    bs = np.where(Sxy > 0, Sxy / np.where(Sxx > 0, Sxx, 1), 0.0)
    sse_s = Syy[:, None] - bs * Sxy
    wsum = np.maximum(wts.sum(axis=-1, keepdims=True), 1e-300)
    return wts @ sse_s, (wts @ bs) / wsum


# ------------------------------------------------------------------------------------------------------
# Mechanistic fits (per file and per subset of rest windows)
# ------------------------------------------------------------------------------------------------------
def mech_lambda_grid(s: dict) -> np.ndarray:
    g = s["mechanistic"]["lambda_grid"]
    pos = np.geomspace(g["min"], g["max"], int(g["n"]))
    return np.concatenate([[0.0], pos]) if g.get("zero", True) else pos


def _nm(fun, x0, lo, hi, maxiter=300):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        r = optimize.minimize(fun, np.clip(x0, lo, hi), method="Nelder-Mead", bounds=list(zip(lo, hi)),
                              options=dict(xatol=1e-5, fatol=1e-10, maxiter=maxiter))
    return r


class MechFile:
    """Tempered fractional element (and reference models) fitted to the rest windows of one file."""

    def __init__(self, drive: Drive, s: dict, free_gain: bool = False, alpha_bounds=None):
        self.d, self.s = drive, s
        self.free_gain = free_gain
        self._sse = sse_free_gain if free_gain else sse_from_stats
        m = s["mechanistic"]
        self.r, self.q = quad_nodes(s)
        self.alo, self.ahi = alpha_bounds if alpha_bounds is not None else m["alpha"]
        self.llo, self.lhi = m["log10_a"]
        ag = np.linspace(self.alo, self.ahi, int(m["alpha_grid_n"]))
        lg = np.linspace(self.llo, self.lhi, int(m["log10_a_grid_n"]))
        A, L = np.meshgrid(ag, lg, indexing="ij")
        self.grid = np.column_stack([A.ravel(), L.ravel()])
        self.Wg = mode_weights(self.r, self.q, self.grid[:, :1], 10 ** self.grid[:, 1:], s)   # (G, J+1)
        self.lam_grid = mech_lambda_grid(s)

    # ---- tempered fractional element ------------------------------------------------------------
    def phi(self, lam: float) -> np.ndarray:
        return self.d.basis(self.r + lam)

    def sse_point(self, Phi: np.ndarray, p: np.ndarray, mask: np.ndarray) -> tuple[float, float]:
        w = mode_weights(self.r, self.q, p[0], 10 ** p[1], self.s)
        Sxx, Sxy, Syy = self.d.seg_stats((Phi @ w)[:, None])
        sse, b = self._sse(mask[None, :], Sxx, Sxy, Syy)
        return float(sse[0, 0]), float(b[0, 0])

    def refine(self, Phi, mask, p0) -> dict:
        lo, hi = np.array([self.alo, self.llo]), np.array([self.ahi, self.lhi])
        r = _nm(lambda p: self.sse_point(Phi, p, mask)[0], np.asarray(p0, float), lo, hi)
        sse, b = self.sse_point(Phi, r.x, mask)
        return dict(alpha=float(r.x[0]), log10_a=float(r.x[1]), b_mV=b, sse=sse)

    def fit_tfo(self, masks: dict, boot_w: np.ndarray | None = None) -> dict:
        """Profile over the lambda grid (alpha, a refined at every node) for every subset mask; lambda-hat by
        a parabola in ln(lambda) through the best node and its neighbours, then a final refit at lambda-hat.
        With boot_w (n_boot, n_seg) multiplicities the same is done for the cluster-bootstrap replicates."""
        names = list(masks)
        M = np.array([masks[k] for k in names], float)
        nl = len(self.lam_grid)
        prof = {k: [] for k in names}
        if boot_w is not None:
            nb = boot_w.shape[0]
            bprof = np.full((nb, nl), np.inf)
            bgrid = np.zeros((nb, nl), int)
        for i, lam in enumerate(self.lam_grid):
            Phi = self.phi(lam)
            Sxx, Sxy, Syy = self.d.seg_stats(Phi @ self.Wg.T)
            sse, _ = self._sse(M, Sxx, Sxy, Syy)
            for j, k in enumerate(names):
                g = int(np.argmin(sse[j]))
                prof[k].append(self.refine(Phi, M[j], self.grid[g]) | dict(lam=float(lam)))
            if boot_w is not None:
                sb, _ = self._sse(boot_w, Sxx, Sxy, Syy)
                bgrid[:, i] = np.argmin(sb, axis=1)
                bprof[:, i] = sb[np.arange(nb), bgrid[:, i]]
        out = {}
        for j, k in enumerate(names):
            out[k] = self._finish(prof[k], M[j])
        if boot_w is not None:
            out["_boot"] = self._boot(boot_w, bprof, bgrid)
        return out

    def _lam_hat(self, sse_nodes: np.ndarray) -> float:
        g = self.lam_grid
        i = int(np.argmin(sse_nodes))
        if g[i] == 0.0 or i == len(g) - 1 or g[i - 1] == 0.0:
            return float(g[i])
        x = np.log(g[i - 1:i + 2]); y = sse_nodes[i - 1:i + 2]
        if not np.all(np.isfinite(y)):
            return float(g[i])
        den = (x[0] - x[1]) * (x[0] - x[2]) * (x[1] - x[2])
        A = (x[2] * (y[1] - y[0]) + x[1] * (y[0] - y[2]) + x[0] * (y[2] - y[1])) / den
        B = (x[2] ** 2 * (y[0] - y[1]) + x[1] ** 2 * (y[2] - y[0]) + x[0] ** 2 * (y[1] - y[2])) / den
        if not np.isfinite(A) or A <= 0:
            return float(g[i])
        return float(np.exp(np.clip(-B / (2 * A), x[0], x[2])))

    def _refine_lambda(self, prof: list, mask: np.ndarray, i: int) -> dict | None:
        """Review 2: bounded 1-D minimisation of the profile SSE in ln(lambda) between the neighbours of the
        best grid node (alpha, a re-optimised at every evaluation), instead of a parabola through 3 nodes."""
        g = self.lam_grid
        if g[i] == 0.0:
            return None
        step = (g[i + 1] / g[i]) if i + 1 < len(g) else (g[i] / g[i - 1])
        lo_ = g[i - 1] if (i > 0 and g[i - 1] > 0) else g[i] / step
        hi_ = g[i + 1] if i + 1 < len(g) else g[i]
        seen = []

        def f(x):
            fr = self.refine(self.phi(float(np.exp(x))), mask, [prof[i]["alpha"], prof[i]["log10_a"]]) | dict(lam=float(np.exp(x)))
            seen.append(fr)
            return fr["sse"]
        optimize.minimize_scalar(f, bounds=(math.log(lo_), math.log(hi_)), method="bounded",
                                 options=dict(xatol=float(self.s["mechanistic"].get("lambda_refine_xatol", 0.01))))
        return min(seen, key=lambda d: d["sse"]) if seen else None

    def _finish(self, prof: list, mask: np.ndarray) -> dict:
        sse_nodes = np.array([p["sse"] for p in prof])
        i = int(np.argmin(sse_nodes))
        fin = self._refine_lambda(prof, mask, i)
        if fin is None or fin["sse"] > sse_nodes[i]:
            fin = dict(prof[i])
            fin["lambda_refined"] = False
        else:
            fin["lambda_refined"] = True
        lam = fin["lam"]
        extra = []
        if lam > 0:           # resolve the profile around lambda-hat (grid nodes are ~0.3 apart in ln lambda)
            for lx in lam * np.exp(REFINE_STEPS):
                if self.lam_grid[1] <= lx <= self.lam_grid[-1]:
                    extra.append(self.refine(self.phi(lx), mask, [fin["alpha"], fin["log10_a"]]) | dict(lam=float(lx)))
        g, v = merge_profile(self.lam_grid, sse_nodes, [lam] + [e["lam"] for e in extra], [fin["sse"]] + [e["sse"] for e in extra])
        n = int(np.sum(np.diff(self.d.ptr) * mask))
        ci = profile_interval(g, v, min(fin["sse"], v.min()), n, self.s["profile_crit"])
        return dict(fit=fin, profile=prof + extra, ci=ci, n_obs=n, n_seg=int(mask.sum()),
                    profile_lam=g.tolist(), profile_sse=v.tolist())

    def _boot(self, boot_w, bprof, bgrid) -> dict:
        """Refine each replicate at its best lambda node and neighbours, parabola, final refit."""
        nb, nl = bprof.shape
        best = np.argmin(bprof, axis=1)
        need = {i: [] for i in range(nl)}
        for b in range(nb):
            for i in (best[b] - 1, best[b], best[b] + 1):
                if 0 <= i < nl:
                    need[i].append(b)
        ref = np.full((nb, nl), np.inf)
        refp = {}
        for i in range(nl):
            if not need[i]:
                continue
            Phi = self.phi(self.lam_grid[i])
            for b in need[i]:
                f = self.refine(Phi, boot_w[b], self.grid[bgrid[b, i]])
                ref[b, i] = f["sse"]; refp[(b, i)] = f
        rows = []
        for b in range(nb):
            lam = self._lam_hat(ref[b])
            i = int(np.argmin(ref[b]))
            f0 = refp[(b, i)]
            f = self.refine(self.phi(lam), boot_w[b], [f0["alpha"], f0["log10_a"]])
            if f["sse"] > f0["sse"]:
                f, lam = f0, float(self.lam_grid[i])
            rows.append([f["alpha"], lam, f["log10_a"], f["b_mV"]])
        return dict(samples=np.array(rows))

    # ---- reference models: alpha = 1 (single RC with leakage) and 2RC ---------------------------------
    def _gram(self, Psi: np.ndarray):
        """Per-rest centred Gram statistics of the columns of Psi: G (S, K, K), gy (S, K), syy (S,)."""
        st, cnt = self.d.ptr[:-1], np.diff(self.d.ptr).astype(float)
        mP = np.add.reduceat(Psi, st, axis=0) / cnt[:, None]
        my = np.add.reduceat(self.d.y, st) / cnt
        Pc = Psi - mP[self.d.seg]
        yc = self.d.y - my[self.d.seg]
        G = np.stack([Pc[a_:b_].T @ Pc[a_:b_] for a_, b_ in zip(self.d.ptr[:-1], self.d.ptr[1:])])
        gy = np.stack([Pc[a_:b_].T @ yc[a_:b_] for a_, b_ in zip(self.d.ptr[:-1], self.d.ptr[1:])])
        syy = np.array([yc[a_:b_] @ yc[a_:b_] for a_, b_ in zip(self.d.ptr[:-1], self.d.ptr[1:])])
        return G, gy, syy

    @staticmethod
    def _nnls1(a11, g1, syy):
        c = np.where(g1 > 0, g1 / np.where(a11 > 0, a11, 1), 0.0)
        return syy - c * g1, c

    @staticmethod
    def _nnls2(a11, a22, a12, g1, g2, syy):
        """Exact two-variable NNLS by enumeration of the faces (vectorised)."""
        det = a11 * a22 - a12 ** 2
        ok = det > 1e-12 * a11 * a22
        c1 = np.where(ok, (a22 * g1 - a12 * g2) / np.where(ok, det, 1), -1.0)
        c2 = np.where(ok, (a11 * g2 - a12 * g1) / np.where(ok, det, 1), -1.0)
        both = np.where(ok & (c1 >= 0) & (c2 >= 0), syy - c1 * g1 - c2 * g2, np.inf)
        s1, d1 = MechFile._nnls1(a11, g1, syy)
        s2, d2 = MechFile._nnls1(a22, g2, syy)
        cand = np.stack([both, s1, s2])
        k = np.argmin(cand, axis=0)
        sse = np.take_along_axis(cand, k[None], 0)[0]
        C1 = np.choose(k, [np.maximum(c1, 0), d1, np.zeros_like(d1)])
        C2 = np.choose(k, [np.maximum(c2, 0), np.zeros_like(d2), d2])
        return sse, C1, C2

    def _rc_sse(self, G, gy, syy, mask, i, j=None):
        """SSE (and gains) of one (i) or two (i, j) modes with shared or per-rest gains."""
        if self.free_gain:
            if j is None:
                sse, c = self._nnls1(G[:, i, i], gy[:, i], syy)
                return mask @ sse, (mask @ c) / mask.sum(), None
            sse, c1, c2 = self._nnls2(G[:, i, i], G[:, j, j], G[:, i, j], gy[:, i], gy[:, j], syy[:, None] if np.ndim(i) else syy)
            return mask @ sse, (mask @ c1) / mask.sum(), (mask @ c2) / mask.sum()
        Gt, gt, st = np.tensordot(mask, G, 1), mask @ gy, float(mask @ syy)
        if j is None:
            sse, c = self._nnls1(Gt[i, i], gt[i], st)
            return sse, c, None
        return self._nnls2(Gt[i, i], Gt[j, j], Gt[i, j], gt[i], gt[j], st)

    def fit_rc(self, mask: np.ndarray) -> dict:
        lo, hi = self.s["mechanistic"]["rc_log10_k"]
        kg = np.logspace(lo, hi, int(self.s["mechanistic"]["rc_grid_n"]))
        G, gy, syy = self._gram(self.d.basis(kg))
        K = len(kg)
        s1 = np.array([self._rc_sse(G, gy, syy, mask, i)[0] for i in range(K)]).ravel()
        i = int(np.argmin(s1))

        def f1(lk):
            G_, g_, y_ = self._gram(self.d.basis(np.array([10 ** lk])))
            return float(np.ravel(self._rc_sse(G_, g_, y_, mask, 0)[0])[0])
        a_, b_ = np.log10(kg[max(i - 1, 0)]), np.log10(kg[min(i + 1, K - 1)])
        r = optimize.minimize_scalar(f1, bounds=(a_, b_), method="bounded", options=dict(xatol=1e-6))
        lk = float(r.x) if r.fun <= s1[i] else float(np.log10(kg[i]))
        G_, g_, y_ = self._gram(self.d.basis(np.array([10 ** lk])))
        sse1, c1, _ = self._rc_sse(G_, g_, y_, mask, 0)
        ii, jj = np.triu_indices(K, 1)
        if self.free_gain:
            sp, _, _ = self._nnls2(G[:, ii, ii], G[:, jj, jj], G[:, ii, jj], gy[:, ii], gy[:, jj], syy[:, None])
            sse2 = mask @ sp
        else:
            sse2 = self._rc_sse(G, gy, syy, mask, ii, jj)[0]
        best2 = int(np.argmin(sse2))
        x0 = np.log10([kg[ii[best2]], kg[jj[best2]]])

        def f2(x):
            G2, g2, y2 = self._gram(self.d.basis(10 ** np.sort(np.asarray(x))))
            if self.free_gain:
                sp_, _, _ = self._nnls2(G2[:, 0, 0], G2[:, 1, 1], G2[:, 0, 1], g2[:, 0], g2[:, 1], y2)
                return float(mask @ sp_)
            return float(np.ravel(self._rc_sse(G2, g2, y2, mask, 0, 1)[0])[0])
        r2 = _nm(f2, x0, np.array([lo, lo]), np.array([hi, hi]), maxiter=200)
        x = np.sort(r2.x) if r2.fun <= sse2[best2] else np.sort(x0)
        G2, g2, y2 = self._gram(self.d.basis(10 ** x))
        if self.free_gain:
            sp_, q1, q2 = self._nnls2(G2[:, 0, 0], G2[:, 1, 1], G2[:, 0, 1], g2[:, 0], g2[:, 1], y2)
            sse2f, b1, b2 = float(mask @ sp_), float(mask @ q1 / mask.sum()), float(mask @ q2 / mask.sum())
        else:
            s_, q1, q2 = self._rc_sse(G2, g2, y2, mask, 0, 1)
            sse2f, b1, b2 = float(np.ravel(s_)[0]), float(np.ravel(q1)[0]), float(np.ravel(q2)[0])
        return dict(rc=dict(k_s_inv=10 ** lk, b_mV=float(np.ravel(c1)[0]), sse=float(np.ravel(sse1)[0])),
                    two_rc=dict(k1_s_inv=float(10 ** x[0]), k2_s_inv=float(10 ** x[1]), b1_mV=b1, b2_mV=b2, sse=sse2f))

    # ---- local sensitivities ------------------------------------------------------------------------
    def jacobian_corr(self, fit: dict, mask: np.ndarray) -> dict:
        """Correlation matrix of (alpha, lambda, R_p, C_p, OCV_1..S) from the Gauss-Newton Jacobian."""
        keep = mask[self.d.seg] > 0
        seg_ids = np.flatnonzero(mask > 0)
        al, lam, la = fit["alpha"], fit["lam"], fit["log10_a"]
        bSI = fit["b_mV"] * 1e-3
        a = 10 ** la
        Rp, Cp = bSI / a, 1.0 / bSI

        def S_of(alpha, lam_, Rp_, Cp_):
            a_ = 1.0 / (Rp_ * Cp_); b_ = 1e3 / Cp_
            return b_ * (self.phi(lam_) @ mode_weights(self.r, self.q, alpha, a_, self.s))
        base = S_of(al, lam, Rp, Cp)
        cols = []
        for j, (name, h) in enumerate((("alpha", 1e-4), ("lambda", max(1e-3 * lam, 1e-8)), ("R_p", 1e-4 * Rp), ("C_p", 1e-4 * Cp))):
            p = [al, lam, Rp, Cp]
            if name == "lambda" and lam - h < 0:
                p[1] = lam + h
                cols.append((S_of(*p) - base) / h)
                continue
            pp, pm = list(p), list(p)
            pp[j] += h; pm[j] -= h
            cols.append((S_of(*pp) - S_of(*pm)) / (2 * h))
        J = np.column_stack(cols + [(self.d.seg == s_).astype(float) for s_ in seg_ids])[keep]
        n, pdim = J.shape
        sig2 = fit["sse"] / max(n - pdim, 1)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cov = sig2 * np.linalg.pinv(J.T @ J)
        sd = np.sqrt(np.maximum(np.diag(cov), 0))
        corr = cov / np.outer(sd, sd)
        names = ["alpha", "lambda", "R_p", "C_p"]
        return dict(names=names, corr_core=corr[:4, :4].tolist(), se_wald=dict(zip(names, sd[:4].tolist())),
                    max_abs_corr_with_ocv_nuisance=dict(zip(names, np.abs(corr[:4, 4:]).max(axis=1).tolist())),
                    cond_JtJ=float(np.linalg.cond(J.T @ J)), R_p_Ohm=Rp, C_p=Cp)


# ======================================================================================================
# Per-file driver (run in a worker process by scripts/03_relaxation.py)
# ======================================================================================================
def _seq(s: dict, *key) -> np.random.Generator:
    return np.random.default_rng(np.random.SeedSequence(int(s["seed"]), spawn_key=tuple(int(k) for k in key)))


def seg_meta(r: dict) -> dict:
    return dict(seg_index=r["seg_index"], cycle=r["cycle"], step=r["step"], branch=r["branch"],
                soc_label=float(r["soc_label"]), flags=r["flags"], primary=r["primary"],
                pulse_Ah=float(r["pulse"]["Ah_trapz"]), pulse_duration_s=float(r["pulse"]["duration_s"]),
                pulse_I_mean_A=float(r["pulse"]["I_mean"]), pulse_V_end_under_load=float(r["pulse"]["V_end_under_load"]),
                rest_duration_s=float(r["duration_s"]), dV_rest_mV=1e3 * float(r["dV_rest"]))


def masks_for(rests: list[dict], s: dict) -> dict:
    socs = np.array([r["soc_label"] for r in rests])
    br = np.array([r["branch"] for r in rests])
    m = {"all": np.ones(len(rests)), "branch_discharge": (br == "discharge").astype(float),
         "branch_charge": (br == "charge").astype(float)}
    for name, (lo, hi) in s["mechanistic"]["soc_bands"].items():
        m[f"soc_{name}"] = ((socs >= lo) & (socs < hi)).astype(float)
    return {k: v for k, v in m.items() if v.sum() >= 2}


def _mech_summary(mf: MechFile, res: dict, free_gain: bool) -> dict:
    out = {}
    for k, v in res.items():
        if k.startswith("_"):
            continue
        f = v["fit"]
        n, S = v["n_obs"], v["n_seg"]
        kpar = (3 if free_gain else 4) + (S if free_gain else 0) + S + 1   # free gain: b_s per rest replaces b
        ll = gauss_ll(f["sse"], n)
        d = dict(alpha=f["alpha"], lambda_s_inv=f["lam"], log10_a=f["log10_a"], b_mV_per_A=f["b_mV"],
                 sse_mV2=f["sse"], rmse_mV=math.sqrt(f["sse"] / n), n_obs=n, n_seg=S, k=kpar, loglik=ll,
                 aicc=aicc(ll, kpar, n), bic=bic(ll, kpar, n),
                 lambda_profile_ci95={k_: v_ for k_, v_ in v["ci"].items() if k_ != "dev"},
                 b_units="mV A^-1 s^-alpha", lambda_refined=bool(f.get("lambda_refined", False)),
                 alpha_at_bound=bool(min(abs(f["alpha"] - mf.alo), abs(f["alpha"] - mf.ahi)) < 2e-3),
                 log10_a_at_bound=bool(min(abs(f["log10_a"] - mf.llo), abs(f["log10_a"] - mf.lhi)) < 1e-2),
                 profile_lam=v["profile_lam"], profile_sse=v["profile_sse"])
        if not free_gain:
            bSI = f["b_mV"] * 1e-3
            a_ = 10 ** f["log10_a"]
            # R_p = b/a is the DC gain of the UNtempered element; the tempered DC gain is b/(a + lambda^alpha)
            d.update(R_p_Ohm=bSI / a_ if bSI > 0 else float("nan"),
                     R_dc_Ohm=bSI / (a_ + f["lam"] ** f["alpha"]) if bSI > 0 else float("nan"),
                     R_p_identified=not d["log10_a_at_bound"],
                     char_time_s=a_ ** (-1.0 / f["alpha"]),
                     C_p=1.0 / bSI if bSI > 0 else float("nan"))
        # lambda = 0 (untempered) = profile node 0, refined
        p0 = v["profile"][0]
        k0 = kpar - 1
        ll0 = gauss_ll(p0["sse"], n)
        d["untempered"] = dict(alpha=p0["alpha"], log10_a=p0["log10_a"], sse_mV2=p0["sse"], k=k0, loglik=ll0,
                               aicc=aicc(ll0, k0, n), bic=bic(ll0, k0, n))
        lr = max(0.0, n * math.log(p0["sse"] / f["sse"]))
        d["lr_tempered_vs_untempered"] = dict(LR=lr, p_chibar=float(0.5 * stats.chi2.sf(lr, 1)) if lr > 0 else 0.5)
        out[k] = d
    return out


def _boot_summary(samples: np.ndarray, free_gain: bool, thr: float, la_bounds=None) -> dict:
    al, lam, la, b = samples.T
    q = lambda x: [float(v) for v in np.nanpercentile(x, [2.5, 50, 97.5])]  # noqa: E731
    d = dict(n_boot=int(len(al)), alpha=q(al), lambda_s_inv=q(lam), log10_a=q(la),
             frac_lambda_below_threshold=float(np.mean(lam < thr)), samples_alpha=al.tolist(),
             samples_lambda=lam.tolist(), samples_log10_a=la.tolist())
    if la_bounds is not None:
        d["frac_log10_a_at_bound"] = float(np.mean(np.minimum(np.abs(la - la_bounds[0]), np.abs(la - la_bounds[1])) < 1e-2))
    if not free_gain:
        bSI = b * 1e-3
        with np.errstate(divide="ignore", invalid="ignore"):
            Rp, Cp = np.where(bSI > 0, bSI / 10 ** la, np.nan), np.where(bSI > 0, 1 / bSI, np.nan)
            Rdc = np.where(bSI > 0, bSI / (10 ** la + lam ** al), np.nan)
        d.update(R_p_Ohm=q(Rp), R_dc_Ohm=q(Rdc), C_p=q(Cp), samples_R_p=Rp.tolist(), samples_R_dc=Rdc.tolist(),
                 samples_C_p=Cp.tolist())
    return d


def _mech_residual_acf(mf: MechFile, fit: dict, max_lag: int) -> dict:
    Phi = mf.phi(fit["lam"])
    S = Phi @ mode_weights(mf.r, mf.q, fit["alpha"], 10 ** fit["log10_a"], mf.s)
    lag1, acfs = [], []
    for a_, b_ in zip(mf.d.ptr[:-1], mf.d.ptr[1:]):
        Ss, ys = S[a_:b_] - S[a_:b_].mean(), mf.d.y[a_:b_] - mf.d.y[a_:b_].mean()
        if mf.free_gain:
            bb = max(float(Ss @ ys) / float(Ss @ Ss), 0.0) if float(Ss @ Ss) > 0 else 0.0
        else:
            bb = fit["b_mV"]
        res = ys - bb * Ss
        a = acf(res, max_lag)
        lag1.append(float(a[1])); acfs.append(a)
    return dict(lag1_per_rest=lag1, median_lag1=float(np.median(lag1)), acf_median=np.median(acfs, axis=0).tolist())


def run_mechanistic(lid: str, df, rests: list[dict], s: dict, file_idx: int) -> tuple[dict, dict]:
    prim = [r for r in rests if r["primary"]]
    drive = Drive(df, prim, s["t0_s"], int(s["n_subsample"]))
    masks = masks_for(prim, s)
    thr = s["lambda_zero_threshold_s_inv"]
    out, curves = dict(n_rests=len(prim), n_obs=int(len(drive.y)), masks={k: v.tolist() for k, v in masks.items()},
                       rest_seg_index=[r["seg_index"] for r in prim]), {}
    nb = int(s["mechanistic"]["n_boot"])
    for vi, (vname, fg) in enumerate((("shared_gain", False), ("free_gain", True))):
        mf = MechFile(drive, s, free_gain=fg)
        rng = _seq(s, file_idx, 900 + vi)
        idx = rng.integers(0, drive.n_seg, (nb, drive.n_seg))
        boot_w = np.stack([np.bincount(row, minlength=drive.n_seg) for row in idx]).astype(float)
        res = mf.fit_tfo(masks, boot_w=boot_w)
        v = dict(tfo=_mech_summary(mf, res, fg), bootstrap=_boot_summary(res["_boot"]["samples"], fg, thr, (mf.llo, mf.lhi)))
        # review 1/2: is the fit flat in a below the lower bound (element = tempered CPE, a not identified)?
        fa = res["all"]["fit"]
        off = float(s["mechanistic"]["a_flatness_offset"])
        sse_lo = mf.sse_point(mf.phi(fa["lam"]), np.array([fa["alpha"], fa["log10_a"] - off]), masks["all"])[0]
        v["a_flatness"] = dict(log10_a_probe=fa["log10_a"] - off, sse_at_fit=fa["sse"], sse_at_probe=sse_lo,
                               rel_sse_change=(sse_lo - fa["sse"]) / fa["sse"])
        rc = mf.fit_rc(masks["all"])
        n = res["all"]["n_obs"]; S = res["all"]["n_seg"]
        for key, kp in (("rc", (1 + S) if fg else 2), ("two_rc", (2 + 2 * S) if fg else 4)):
            kk = kp + S + 1                     # + one OCV level per rest + noise variance
            ll = gauss_ll(rc[key]["sse"], n)
            rc[key].update(k=kk, loglik=ll, aicc=aicc(ll, kk, n), bic=bic(ll, kk, n),
                           rmse_mV=math.sqrt(rc[key]["sse"] / n))
        v["reference"] = rc
        if not fg:
            v["jacobian"] = mf.jacobian_corr(res["all"]["fit"], masks["all"])
        v["residual_acf"] = _mech_residual_acf(mf, res["all"]["fit"], int(s["acf_max_lag"]))
        # alpha-bound sensitivity (full set only, no bootstrap)
        mfs = MechFile(drive, s, free_gain=fg, alpha_bounds=s["mechanistic"]["alpha_sensitivity"])
        rs_ = mfs.fit_tfo({"all": masks["all"]})
        fs_ = rs_["all"]["fit"]
        sse_lo2 = mfs.sse_point(mfs.phi(fs_["lam"]), np.array([fs_["alpha"], fs_["log10_a"] - off]), masks["all"])[0]
        v["alpha_bound_sensitivity"] = dict(alpha_bounds=list(s["mechanistic"]["alpha_sensitivity"]),
                                            a_flatness_rel_sse_change=(sse_lo2 - fs_["sse"]) / fs_["sse"],
                                            **{k_: v_ for k_, v_ in _mech_summary(mfs, rs_, fg)["all"].items()
                                               if k_ not in ("profile_lam", "profile_sse")})
        out[vname] = v
        curves[f"{vname}_profile_lam"] = np.array(res["all"]["profile_lam"])
        curves[f"{vname}_profile_sse"] = np.array(res["all"]["profile_sse"])
    return out, curves


def run_file(lid: str, file_idx: int) -> tuple[dict, dict]:
    """Everything for one incremental-OCV file.  Returns (json-able dict, dict of numpy arrays)."""
    import time
    t_start = time.time()
    s = settings()
    df = D.load_raw(lid)
    ver = D.verify_file(lid, df)
    rests = collect_rests(lid, df, s)
    ent = D.CATALOG[lid]
    prim = [r for r in rests if r["primary"] and r["branch"] == "discharge"]
    rep = min(prim, key=lambda r: abs(r["soc_label"] - 0.5))["seg_index"] if prim else rests[0]["seg_index"]
    phen, curves = [], {}
    t0s = [s["t0_s"]] + [float(x) for x in s["t0_sensitivity_s"]]
    for r in rests:
        e = dict(meta=seg_meta(r), fits={})
        for j, t0 in enumerate(t0s):
            main = j == 0
            o = fit_segment(r, t0, s, _seq(s, file_idx, r["seg_index"], j), do_bootstrap=main,
                            keep_curves=main and r["seg_index"] == rep, do_profile=main)
            if "_curves" in o:
                for k, v in o.pop("_curves").items():
                    if isinstance(v, dict):
                        for m, arr in v.items():
                            curves[f"rep_{k}_{m}"] = np.asarray(arr)
                    else:
                        curves[f"rep_{k}"] = np.asarray(v)
                curves["rep_seg_index"] = np.array(rep)
            if not main:
                for m in o["models"]:
                    o["models"][m].pop("acf", None)
            e["fits"][str(int(t0))] = o
        # review 1: alternative subsample designs at the main window start (BIC ranking, lambda, corr(V_inf, lambda))
        ta, Va = np.asarray(r["t"], float), np.asarray(r["V"], float)
        e["designs"] = {dz: design_fit(ta, Va, s["t0_s"], dz, s, _seq(s, file_idx, r["seg_index"], 50 + k))
                        for k, dz in enumerate(s["design_sensitivity"])}
        phen.append(e)
    t_phen = time.time() - t_start
    mech, mcurves = run_mechanistic(lid, df, rests, s, file_idx)
    curves.update({f"mech_{k}": v for k, v in mcurves.items()})
    return dict(logical_id=lid, cell=ent.get("cell"), temperature_C=ent.get("temperature_C"),
                verification_passed=bool(ver["passed"]), n_rests=len(rests),
                n_primary=int(sum(r["primary"] for r in rests)), representative_seg_index=int(rep),
                phenomenological=phen, mechanistic=mech,
                runtime_s=dict(phenomenological=t_phen, total=time.time() - t_start)), curves


def voltage_step_mV(df) -> float:
    """Smallest positive voltage increment in a file (ADC quantisation step), mV."""
    v = np.unique(np.round(df[D.COL["V"]].to_numpy().astype(float), 7))
    d = np.diff(v)
    return float(1e3 * d[d > 1e-7].min())


def synthetic_control(lid: str, s: dict, params: dict | None = None, tag: str = "declared") -> dict:
    """Calibration of the phenomenological laws: rests simulated with the mechanistic element driven by the
    measured current of `lid`, plus iid Gaussian noise (and optionally quantised at the file's ADC step), then
    fitted exactly like the measured rests.  params = dict(alpha, log10_a, b_mV_per_A, lambdas_s_inv, noise_mV,
    quantise); default: the declared settings of config relaxation_study.synthetic_control.  Review 1/2: also
    run at the FITTED shared-gain parameters of the files in synthetic_control.fitted_parameter_files."""
    sc = dict(s["synthetic_control"])
    sc.update(params or {})
    df = D.load_raw(lid)
    D.verify_file(lid, df)
    q_mV = voltage_step_mV(df) if sc.get("quantise", False) else None
    prim = [r for r in collect_rests(lid, df, s) if r["primary"]]
    drive = Drive(df, prim, s["t0_s"], int(s["n_subsample"]))
    mf = MechFile(drive, s)
    out = []
    w = mode_weights(mf.r, mf.q, sc["alpha"], 10 ** sc["log10_a"], s)
    for li, lam in enumerate(sc["lambdas_s_inv"]):
        rng = _seq(s, 777 if tag == "declared" else 778 + sum(map(ord, tag)) % 1000, li)
        X0 = drive.states(mf.r + lam)
        rows = []
        for k, r in enumerate(prim):
            trel = np.asarray(r["t"], float)
            sel = trel >= s["t0_s"] - 1e-9
            tr = trel[sel]
            tau = tr + r["t_interruption_abs_s"] - drive.t[r["i_start"]]
            yfull = sc["b_mV_per_A"] * (np.exp(-np.outer(tau, mf.r + lam)) @ (X0[k] * w)) + rng.normal(0, sc["noise_mV"], len(tr))
            if q_mV:
                yfull = np.round(yfull / q_mV) * q_mV
            sub = log_subsample(tr, s["t0_s"], float(tr[-1]), int(s["n_subsample"]))
            t, y = tr[sub], yfull[sub]
            fits = fit_all(t, y, s, rng)
            ics = {m: bic(gauss_ll(fits[m]["sse"], len(t)), N_NONLIN[m] + N_LIN[m] + 1, len(t)) for m in MODELS}
            lamhat = 1e-3 * float(fits["TPL"]["theta"][1])
            rows.append(dict(best_bic=min(ics, key=ics.get), tpl_lambda=lamhat, dbic_tpl_pl=ics["TPL"] - ics["PL"],
                             dbic_tpl_2exp=ics["TPL"] - ics["2EXP"], dbic_tpl_sexp=ics["TPL"] - ics["SEXP"]))
        wins = {m: sum(r_["best_bic"] == m for r_ in rows) for m in MODELS}
        tl = np.array([r_["tpl_lambda"] for r_ in rows])
        out.append(dict(lambda_true=lam, n_rests=len(rows), bic_wins=wins,
                        tpl_lambda_median=float(np.median(tl)), tpl_lambda_iqr=[float(x) for x in np.percentile(tl, [25, 75])],
                        median_dbic_tpl_pl=float(np.median([r_["dbic_tpl_pl"] for r_ in rows])),
                        frac_dbic_tpl_pl_below_strong=float(np.mean([r_["dbic_tpl_pl"] < -float(s["decision_rules"]["strong_delta_bic"]) for r_ in rows])),
                        median_dbic_tpl_2exp=float(np.median([r_["dbic_tpl_2exp"] for r_ in rows])),
                        median_dbic_tpl_sexp=float(np.median([r_["dbic_tpl_sexp"] for r_ in rows]))))
    return dict(file=lid, tag=tag, settings={k: sc[k] for k in ("alpha", "log10_a", "b_mV_per_A", "lambdas_s_inv", "noise_mV")},
                quantisation_step_mV=q_mV, results=out)
