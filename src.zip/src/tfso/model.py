"""Equivalent-circuit voltage models of the TFSO study and their fast simulators.

Model (mixed order; I > 0 = charge, config dataset.sign_convention):

    dz/dt = eta I / (3600 Q_n),       Q_n = Q_id(T) (results/capacity.json 'Q_id_T_SP2'), eta = 1
    D^{alpha,lambda} V_p = -a_p V_p + b_p I,   a_p = 1/(R_p C_p) [s^-alpha],  b_p = 1/C_p [Ohm s^-alpha]
    V_t = U_al(z) + R_0 I + V_p

Families (all share the SOC Coulomb counting, Q_n and the aligned OCV U_al):
    TFO          tempered fractional        (alpha, lambda, R_0, R_p, C_p)
    FO           untempered, lambda = 0     (alpha, R_0, R_p, C_p)
    FO_alphaTFO  FO with alpha fixed (to the TFO estimate at the same temperature)
    RCL          alpha = 1 limit: D^{1,lambda} V = V' + lambda V, i.e. an RC branch with rate a_p + lambda
                 ("RC with leakage").  NOTE: a_p and lambda enter only through a_p + lambda (continuous time) and
                 through the pole e^{-lambda h}/(1 + h a_p) and gain h b_p/(1 + h a_p) (grid): one direction of
                 (lambda, a_p) is exactly unidentifiable; the effective 1RC quantities are reported (rcl_effective).
    2RC          R_0 + two RC branches (R_1, tau_1, R_2, tau_2), exact zero-order-hold discretisation.

Discretisation of the fractional branch (everywhere: identification and observers): uniform grid h, the grid current
I_n of data.get_dynamic_profile (charge-conserving FORWARD interval mean over [t_n, t_n + h], i.e. the zero-order-hold
value on [t_n, t_{n+1})), implicit Grunwald-Letnikov recursion with the tempered weights omega_j^{(alpha,lambda)} and
the exact Caputo correction (tempered.simulate_tempered_element), driven by the sequence u_n:

    (1 + h^alpha a_p) V_n = h^alpha b_p u_n - sum_{j=1}^{min(n,N_L)} omega_j V_{n-j}        (V_0 = 0: no correction)

INPUT TIMING (review 2026-09-27; config identification_study.input_timing).  The drive u_n is the grid current
delayed by `lag` samples, u_n = I_{n-lag} (u_n = 0 for n < lag; u_0 is never used because V_0 = 0 is given), and ONE
lag is applied to every dynamic branch of every family (fractional and 2RC):
    'causal'           lag 1 for all branches: u_n = I_{n-1} = the current held on [t_{n-1}, t_n), i.e. V_p(t_n)
                       depends only on the current that has flowed before t_n (PRIMARY convention).  For the 2RC
                       branch this is the exact ZOH solution; for alpha = 1, lambda = 0 the fractional branch is the
                       backward-Euler counterpart of the same ZOH input.
    'implicit_forward' lag 0 for all branches: u_n = I_n = the current held on [t_n, t_{n+1}); this is the
                       literal eq:m4b:observer convention (Vp_n driven by I_{m,n}) and carries a one-step
                       anticipation: V_p(t_n) already contains the feed-through h^alpha b_p/(1 + h^alpha a_p) I_n
                       of current flowing after t_n (sensitivity).
    'legacy_mixed'     fractional lag 0, 2RC lag 1 (the first identification run; sensitivity only - the families
                       are then not compared under the same convention).
    'causal_point_output'  as 'causal', but the output term R_0 I uses the point current I(t_n) (linear
                       interpolation of the logged current at t_n, the same interpolation as V(t_n)) instead of the
                       forward interval mean I_n (sensitivity).
Otherwise the output term R_0 I uses the grid current I_n (the observers' I_out at h = 1 s).

Because V_p is linear in u, V_p = b_p (k * u) with z-transform K(z) = h^alpha / (h^alpha a_p + Omega(z)),
Omega(z) = (1 - e^{-lambda h} z)^alpha (full memory) or Omega_L(z) = sum_{j<=N_L} omega_j z^j (finite memory).
polarisation_fft evaluates K on the circle |z| = r < 1 (M >= 4 N points, r^M = 1e-12) and multiplies by the
transform of (I_n r^n) in the same transform (one rfft/irfft pair, O(M log M)); kernel_fft returns k itself.
Both are validated against the direct recursion by unit_check() (max abs difference < 1e-9 V required).

Warm start (build_history): the record is simulated from the END OF THE CV STEP (step 3, last sample; SOC anchored at
z = 1, V_p = 0 ASSUMED there) through the rest (step 4), the pre-profile 1 A discharge (step 5), the rest (step 6)
and the profile (step 7); step-8 logger rows are dropped.  The grid is aligned with the profile grid of
data.get_dynamic_profile (t0 + k h), so the fractional memory carries the real history.  Only the profile window
is scored by the identification.

OCV (AlignedOCV): the selected PCHIP OCV at the file's temperature (ocv.load_ocv) on the observer axis with
Q_axis = Q_id(T), plus the two alignment parameters (charge-axis scale s and shift dq [Ah]):

    x(z) = s ((1 - z) Q_axis + dq) / Q_SP2,25,      U_al(z) = OCV_T(x(z)),   dU_al/dz = -OCV_T'(x) s Q_axis / Q_SP2,25

continued linearly with the end slope outside the PCHIP x-domain (config identification_study.ocv_extrapolation).
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field

import numpy as np
from scipy.signal import lfilter

from . import data as D
from . import ocv as O
from . import tempered as TM

# --------------------------------------------------------------------------------------
# Parameter containers
# --------------------------------------------------------------------------------------
PARAM_UNITS = {"alpha": "-", "lam": "1/s", "R0": "Ohm", "Rp": "Ohm", "Cp": "F s^(alpha-1)", "R1": "Ohm",
               "tau1": "s", "R2": "Ohm", "tau2": "s", "s": "-", "dq": "Ah"}

# input-timing conventions (see module doc): lag of the fractional and of the RC branches, output current
TIMING = {
    "causal": dict(frac_lag=1, rc_lag=1, output="grid"),
    "implicit_forward": dict(frac_lag=0, rc_lag=0, output="grid"),
    "legacy_mixed": dict(frac_lag=0, rc_lag=1, output="grid"),
    "causal_point_output": dict(frac_lag=1, rc_lag=1, output="point"),
}


def drive(I: np.ndarray, lag: int) -> np.ndarray:
    """u_n = I_{n-lag} (u_n = 0 for n < lag) and u_0 = 0 (V_0 = 0 is given, u_0 never enters)."""
    I = np.asarray(I, float)
    u = np.zeros_like(I)
    if lag == 0:
        u[1:] = I[1:]
    else:
        u[lag:] = I[:-lag]
    u[0] = 0.0
    return u


@dataclass
class TFOParams:
    """Tempered fractional model (FO: lam = 0; RCL: alpha = 1).  Units: see PARAM_UNITS."""
    alpha: float
    lam: float
    R0: float
    Rp: float
    Cp: float
    s: float = 1.0
    dq: float = 0.0

    @property
    def a_p(self) -> float:
        return 1.0 / (self.Rp * self.Cp)

    @property
    def b_p(self) -> float:
        return 1.0 / self.Cp

    def dc_resistance(self) -> float:
        """R_0 + b_p/(a_p + lambda^alpha) (DC gain, prop:m1:transfer)."""
        return self.R0 + self.b_p / (self.a_p + self.lam ** self.alpha)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class TwoRCParams:
    R0: float
    R1: float
    tau1: float
    R2: float
    tau2: float
    s: float = 1.0
    dq: float = 0.0

    def sorted(self) -> "TwoRCParams":
        """Label the branches so that tau1 <= tau2 (the model is symmetric in the two branches)."""
        if self.tau1 <= self.tau2:
            return self
        return TwoRCParams(self.R0, self.R2, self.tau2, self.R1, self.tau1, self.s, self.dq)

    def to_dict(self) -> dict:
        return asdict(self)


def rcl_effective(p: TFOParams, h: float = 1.0) -> dict:
    """Identifiable 1RC quantities of an alpha = 1 (RCL) parameter set: continuous rate a_p + lambda, time constant,
    DC resistance b_p/(a_p + lambda); grid pole e^{-lambda h}/(1 + h a_p) and its equivalent time constant."""
    rate = p.a_p + p.lam
    pole = math.exp(-p.lam * h) / (1.0 + h * p.a_p)
    gain = h * p.b_p / (1.0 + h * p.a_p)
    return dict(rate_1_s=rate, tau_s=1.0 / rate, R_dc_Ohm=p.b_p / rate, pole_grid=pole,
                tau_grid_s=-h / math.log(pole), R_dc_grid_Ohm=gain / (1.0 - pole))


# --------------------------------------------------------------------------------------
# Tempered weights (alpha = 1 allowed) and direct recursion (reference)
# --------------------------------------------------------------------------------------
def weights(alpha: float, lam: float, h: float, N: int) -> np.ndarray:
    """omega_j^{(alpha,lambda)}, j = 0..N; tempered.gl_weights for alpha < 1, the alpha = 1 limit (1, -e^{-lam h}, 0..)."""
    if alpha < 1.0:
        return TM.gl_weights(alpha, lam, h, N)
    w = np.zeros(int(N) + 1)
    w[0] = 1.0
    if N >= 1:
        w[1] = -math.exp(-lam * h)
    return w


def polarisation_direct(alpha: float, lam: float, a: float, b: float, I, h: float, N_L: int | None = None) -> np.ndarray:
    """Reference: direct implicit GL recursion (tempered.simulate_tempered_element; alpha = 1 by an explicit loop).
    I is the DRIVE sequence u (see drive(); u_0 is not used)."""
    I = np.asarray(I, float)
    if alpha < 1.0:
        return TM.simulate_tempered_element(alpha, lam, a, b, I, h, x0=0.0, N_L=N_L)
    x = np.zeros(I.size)
    e, den = math.exp(-lam * h), 1.0 + h * a
    for n in range(1, I.size):
        x[n] = (h * b * I[n] + e * x[n - 1]) / den
    return x


# --------------------------------------------------------------------------------------
# FFT simulation of the linear branch
# --------------------------------------------------------------------------------------
class FFTGrid:
    """Evaluation circle |z| = r for sequences of length N: M = 2^ceil(log2(oversample N)), r = r_pow_M^(1/M).
    Caches the transform of the (fixed) input I_n r^n so that one objective evaluation costs one K(z) evaluation
    on M/2+1 points plus one irfft."""

    def __init__(self, N: int, oversample: int = 4, r_pow_M: float = 1e-12):
        self.N = int(N)
        self.M = 1 << int(math.ceil(math.log2(max(oversample * self.N, 16))))
        self.log_r = math.log(r_pow_M) / self.M
        self.r = math.exp(self.log_r)
        m = np.arange(self.M // 2 + 1)
        self.z = self.r * np.exp(-2j * np.pi * m / self.M)        # K(z_m) = sum_n k_n r^n e^{-2 pi i m n / M}
        self.rn = np.exp(self.log_r * np.arange(self.N))
        self.inv_rn = np.exp(-self.log_r * np.arange(self.N))
        self._I_hat = {}

    def K(self, alpha: float, lam: float, a: float, h: float, N_L: int | None = None) -> np.ndarray:
        ha = h ** alpha
        if N_L is None:
            w = 1.0 - math.exp(-lam * h) * self.z
            Om = np.exp(alpha * np.log(w)) if alpha != 1.0 else w
        else:
            om = weights(alpha, lam, h, int(N_L))
            Om = np.fft.rfft(om * np.exp(self.log_r * np.arange(om.size)), n=self.M)
        return ha / (ha * a + Om)

    def I_hat(self, I: np.ndarray) -> np.ndarray:
        key = (I.ctypes.data, I.size, float(I[1:].sum()))
        if key not in self._I_hat:
            J = np.array(I, float)
            J[0] = 0.0                     # V_0 = 0 is given: I_0 does not enter the recursion
            self._I_hat = {key: np.fft.rfft(J * self.rn, n=self.M)}
        return self._I_hat[key]


def kernel_fft(alpha: float, lam: float, a: float, h: float, N: int, N_L: int | None = None,
               grid: FFTGrid | None = None, oversample: int = 4, r_pow_M: float = 1e-12) -> np.ndarray:
    """Impulse response k_0..k_{N-1} of the recursion (V = b (k * I)): k_n = r^{-n} IFFT[K(r e^{i theta_m})]_n."""
    g = grid or FFTGrid(N, oversample, r_pow_M)
    return np.fft.irfft(g.K(alpha, lam, a, h, N_L), n=g.M)[:N] * g.inv_rn[:N]


def polarisation_fft(alpha: float, lam: float, a: float, b: float, I, h: float, N_L: int | None = None,
                     grid: FFTGrid | None = None, oversample: int = 4, r_pow_M: float = 1e-12) -> np.ndarray:
    """V_p on the grid by one transform: V_n r^n = IFFT[b K(z_m) FFT(I_n r^n)] (I_0 := 0, V_0 = 0)."""
    I = np.asarray(I, float)
    g = grid if (grid is not None and grid.N == I.size) else FFTGrid(I.size, oversample, r_pow_M)
    v = np.fft.irfft(b * g.K(alpha, lam, a, h, N_L) * g.I_hat(I), n=g.M)[:I.size]
    return v * g.inv_rn


def polarisation_fft_conv(alpha, lam, a, b, I, h, N_L=None, oversample=4, r_pow_M=1e-12) -> np.ndarray:
    """Variant: kernel by FFT, then FFT convolution (scipy.signal.fftconvolve)."""
    from scipy.signal import fftconvolve
    I = np.asarray(I, float).copy()
    I[0] = 0.0
    k = kernel_fft(alpha, lam, a, h, I.size, N_L, oversample=oversample, r_pow_M=r_pow_M)
    return b * fftconvolve(k, I)[:I.size]


def polarisation_2rc(R: float, tau: float, u, h: float) -> np.ndarray:
    """RC branch driven by the drive sequence u (drive(I, lag)): V_n = e^{-h/tau} V_{n-1} + R (1 - e^{-h/tau}) u_n,
    V_0 = 0.  With u = drive(I, 1) (u_n = I_{n-1}, the grid current held on [t_{n-1}, t_n)) this is the exact
    zero-order-hold solution; with u = drive(I, 0) it anticipates the current by one step (sensitivity only)."""
    p = math.exp(-h / tau)
    u = np.asarray(u, float).copy()
    u[0] = 0.0
    return lfilter([R * (1.0 - p)], [1.0, -p], u)


def polarisation_2rc_direct(R, tau, u, h):
    u = np.asarray(u, float)
    p = math.exp(-h / tau)
    x = np.zeros(u.size)
    for n in range(1, u.size):
        x[n] = p * x[n - 1] + R * (1.0 - p) * u[n]
    return x


def step_response(params, timing: str = "causal", h: float = 1.0, lags_s=(0.0, 1.0, 10.0, 100.0)) -> dict:
    """Discrete terminal-voltage step response R(k h) [Ohm] of the model under `timing`: the cell rests on [t_0, t_1),
    a 1 A current flows from t_1 on (grid currents I = (0, 1, 1, ...)), R(k h) = (V_t - U)(t_{1+k}) / 1 A.  The same
    definition (same lag after the onset) is used for every family, so R(0) contains any one-step feed-through of an
    anticipating convention.  Also returns the DC resistance (continuous-time formula)."""
    kmax = int(round(max(lags_s) / h)) + 2
    I = np.zeros(kmax + 1); I[1:] = 1.0
    tm = TIMING[timing]
    if isinstance(params, TwoRCParams):
        u = drive(I, tm["rc_lag"])
        Vp = polarisation_2rc(params.R1, params.tau1, u, h) + polarisation_2rc(params.R2, params.tau2, u, h)
        rdc = params.R0 + params.R1 + params.R2
    else:
        u = drive(I, tm["frac_lag"])
        Vp = polarisation_direct(params.alpha, params.lam, params.a_p, params.b_p, u, h)
        rdc = params.dc_resistance()
    out = {f"R_{g:g}s_Ohm": float(params.R0 + Vp[1 + int(round(g / h))]) for g in lags_s}
    out["R_dc_Ohm"] = float(rdc)
    return out


# --------------------------------------------------------------------------------------
# OCV with alignment
# --------------------------------------------------------------------------------------
class AlignedOCV:
    """U_al(z) = OCV_T(s ((1 - z) Q_axis + dq) / Q_ref) with linear continuation outside the PCHIP domain."""

    def __init__(self, T: int, Q_axis: float, extrapolation: str = "linear"):
        _, _, meta = O.load_ocv(int(T), outside="extrapolate")
        self.T, self.Q_axis, self.m, self.Q_ref = int(T), float(Q_axis), meta["model"], float(meta["Q_ref"])
        self.lo, self.hi = (float(v) for v in meta["x_domain"])
        self.extrapolation = extrapolation
        self.U_lo, self.U_hi = float(self.m.predict(self.lo)), float(self.m.predict(self.hi))
        self.d_lo, self.d_hi = float(self.m.deriv(self.lo)), float(self.m.deriv(self.hi))
        self.meta = dict(T=self.T, Q_axis_Ah=self.Q_axis, Q_ref_Ah=self.Q_ref, x_domain=[self.lo, self.hi],
                         method=meta["method"], extrapolation=extrapolation)

    def x(self, z, s=1.0, dq=0.0):
        return s * ((1.0 - np.asarray(z, float)) * self.Q_axis + dq) / self.Q_ref

    def ocv_x(self, x):
        x = np.asarray(x, float)
        if self.extrapolation != "linear":
            return self.m.predict(x)
        xi = np.clip(x, self.lo, self.hi)
        u = self.m.predict(xi)
        return u + np.where(x < self.lo, self.d_lo * (x - self.lo), 0.0) + np.where(x > self.hi, self.d_hi * (x - self.hi), 0.0)

    def docv_x(self, x):
        x = np.asarray(x, float)
        if self.extrapolation != "linear":
            return self.m.deriv(x)
        return np.where(x < self.lo, self.d_lo, np.where(x > self.hi, self.d_hi, self.m.deriv(np.clip(x, self.lo, self.hi))))

    def U(self, z, s=1.0, dq=0.0):
        return self.ocv_x(self.x(z, s, dq))

    def dUdz(self, z, s=1.0, dq=0.0):
        return -self.docv_x(self.x(z, s, dq)) * s * self.Q_axis / self.Q_ref

    def frac_outside(self, z, s=1.0, dq=0.0) -> float:
        x = self.x(z, s, dq)
        return float(np.mean((x < self.lo) | (x > self.hi)))


# --------------------------------------------------------------------------------------
# History (warm start) of one dynamic file
# --------------------------------------------------------------------------------------
@dataclass
class History:
    logical_id: str
    T: int
    h: float
    Q_axis: float
    t: np.ndarray            # s, relative to the first profile sample (negative in the warm-start history)
    I: np.ndarray            # A, grid current (charge-conserving interval mean)
    V: np.ndarray            # V, measured terminal voltage (linear interpolation)
    z: np.ndarray            # Coulomb-counting SOC with Q_axis, z = 1 at the end of CV
    i0: int                  # index of the first profile sample
    meta: dict = field(default_factory=dict)
    I_point: np.ndarray | None = None   # A, point current I(t_n) (linear interpolation of the logged current)
    _drives: dict = field(default_factory=dict, repr=False)

    @property
    def prof(self) -> slice:
        return slice(self.i0, self.t.size)

    def drive(self, lag: int) -> np.ndarray:
        """Cached drive sequence u_n = I_{n-lag} (fixed array object, so FFTGrid caches its transform)."""
        if lag not in self._drives:
            self._drives[lag] = drive(self.I, lag)
        return self._drives[lag]

    def I_output(self, timing: str) -> np.ndarray:
        return self.I_point if TIMING[timing]["output"] == "point" else self.I


def build_history(logical_id: str, Q_axis: float, h: float | None = None, df=None, check: bool = True) -> History:
    """Uniform-grid record from the end of CV (steps 3 last sample, 4, 5, 6, 7; step 8 dropped); see module doc."""
    cfg = D.load_config()["dataset"]
    ent = D.CATALOG[logical_id]
    h = float(cfg["resample_h_s"]) if h is None else float(h)
    if df is None:
        df = D.load_raw(logical_id)
    prof = D.get_dynamic_profile(logical_id, h=h, df=df)
    step = df[D.COL["step"]].to_numpy()
    t = df[D.COL["t"]].to_numpy(); I = df[D.COL["I"]].to_numpy(); V = df[D.COL["V"]].to_numpy()
    ia = int(np.where(step == 3)[0][-1])
    keep = np.zeros(len(df), bool); keep[ia:] = True
    keep &= np.isin(step, [3, 4, 5, 6, 7]) & (step != int(cfg["logger_step_index_to_drop"]))
    idx = np.where(keep)[0]
    ta, Ia, Va, sa = t[idx], I[idx], V[idx], step[idx]
    _, first = np.unique(ta, return_index=True); first = np.sort(first)
    ta, Ia, Va, sa = ta[first], Ia[first], Va[first], sa[first]
    t0 = float(prof["meta"]["t0_abs_s"])
    n_pre = int(math.floor((t0 - ta[0]) / h + 1e-9))
    n_prof = prof["t"].size
    tg = t0 + h * (np.arange(n_pre + n_prof) - n_pre)
    from scipy.integrate import cumulative_trapezoid
    q = np.concatenate([[0.0], cumulative_trapezoid(Ia, ta)])            # A s from the anchor
    qg = np.interp(tg, ta, q)
    Ig = np.empty_like(tg)
    Ig[:-1] = np.diff(qg) / h
    Ig[-1] = Ia[-1]
    Vg = np.interp(tg, ta, Va)
    zg = 1.0 + qg / 3600.0 / Q_axis
    meta = dict(anchor_t_abs_s=float(ta[0]), anchor_V=float(Va[0]), anchor_I_A=float(Ia[0]), n_history=n_pre,
                n_profile=n_prof, first_grid_offset_s=float(tg[0] - ta[0]), z_profile_start=float(zg[n_pre]),
                z_profile_end=float(zg[-1]), Q_axis_Ah=float(Q_axis), T=int(ent["temperature_C"]),
                history_steps={int(s_): float(np.ptp(ta[sa == s_])) for s_ in (4, 5, 6)},
                assumption="SOC z = 1 and V_p = 0 at the last sample of the CV step (step 3); Coulomb counting with "
                           "Q_axis = Q_id(T), eta = 1, through the rest, the pre-profile 1 A discharge, the rest and the profile")
    if check:
        dI = float(np.max(np.abs(Ig[n_pre:-1] - prof["I"][:-1])))
        dV = float(np.max(np.abs(Vg[n_pre:] - prof["V"])))
        meta.update(max_abs_I_diff_vs_get_dynamic_profile_A=dI, max_abs_V_diff_vs_get_dynamic_profile_V=dV)
        if dI > 1e-9 or dV > 1e-9:
            raise RuntimeError(f"{logical_id}: history grid does not reproduce get_dynamic_profile (dI {dI}, dV {dV})")
    Ipt = np.interp(tg, ta, Ia)
    return History(logical_id, int(ent["temperature_C"]), h, float(Q_axis), tg - t0, Ig, Vg, zg, n_pre, meta, I_point=Ipt)


# --------------------------------------------------------------------------------------
# Terminal-voltage simulation
# --------------------------------------------------------------------------------------
def simulate(params, hist: History, ocv: AlignedOCV, method: str = "fft", N_L: int | None = None,
             grid: FFTGrid | None = None, window: slice | None = None, timing: str = "causal") -> dict:
    """V_t = U_al(z) + R0 I_out + V_p on the history grid.  params: TFOParams or TwoRCParams.  method 'fft' | 'direct'.
    timing: input-timing convention (TIMING; module doc).  window: slice where U and V_t are evaluated (V_p always
    on the full grid; default all)."""
    h, tm = hist.h, TIMING[timing]
    if isinstance(params, TwoRCParams):
        u = hist.drive(tm["rc_lag"])
        f = polarisation_2rc if method == "fft" else polarisation_2rc_direct
        Vp = f(params.R1, params.tau1, u, h) + f(params.R2, params.tau2, u, h)
    else:
        u = hist.drive(tm["frac_lag"])
        if method == "fft":
            Vp = polarisation_fft(params.alpha, params.lam, params.a_p, params.b_p, u, h, N_L, grid=grid)
        else:
            Vp = polarisation_direct(params.alpha, params.lam, params.a_p, params.b_p, u, h, N_L)
    w = window or slice(0, u.size)
    U = ocv.U(hist.z[w], params.s, params.dq)
    Io = hist.I_output(timing)
    return dict(Vt=U + params.R0 * Io[w] + Vp[w], Vp=Vp[w], U=U, z=hist.z[w])


# --------------------------------------------------------------------------------------
# Unit check (FFT vs direct recursion)
# --------------------------------------------------------------------------------------
def unit_check(hist: History, param_sets: list[tuple] | None = None, oversample: int = 4, r_pow_M: float = 1e-12,
               tol: float = 1e-9) -> dict:
    """Max |V_p^FFT - V_p^direct| over parameter sets (alpha, lam, Rp, Cp, N_L) on a real current record, for the
    single-transform and the kernel+fftconvolve variants, plus the 2RC lfilter vs loop check."""
    if param_sets is None:
        param_sets = [(0.5, 0.0, 0.02, 2000.0, None), (0.5, 1e-4, 0.02, 2000.0, None), (0.1, 0.0, 0.5, 1.0e6, None),
                      (0.1, 0.05, 1e-3, 1.0, None), (0.99, 1e-3, 0.02, 5000.0, None), (1.0, 0.0, 0.5, 1.0e6, None),
                      (1.0, 1e-3, 0.01, 1000.0, None), (0.3, 2e-4, 0.05, 1.0e4, None), (0.7, 0.01, 0.2, 100.0, None),
                      (0.5, 1e-4, 0.02, 2000.0, 400), (0.3, 0.0, 0.05, 1.0e4, 100), (1.0, 1e-3, 0.01, 1000.0, 50)]
    g = FFTGrid(hist.I.size, oversample, r_pow_M)
    rows, worst = [], 0.0
    for (al, lam, Rp, Cp, NL) in param_sets:
        a, b = 1.0 / (Rp * Cp), 1.0 / Cp
        vd = polarisation_direct(al, lam, a, b, hist.I, hist.h, NL)
        v1 = polarisation_fft(al, lam, a, b, hist.I, hist.h, NL, grid=g)
        v2 = polarisation_fft_conv(al, lam, a, b, hist.I, hist.h, NL, oversample, r_pow_M)
        e1, e2 = float(np.max(np.abs(v1 - vd))), float(np.max(np.abs(v2 - vd)))
        worst = max(worst, e1, e2)
        rows.append(dict(alpha=al, lam=lam, Rp=Rp, Cp=Cp, N_L=NL, max_abs_Vp_V=float(np.max(np.abs(vd))),
                         err_single_transform_V=e1, err_kernel_conv_V=e2))
    u1 = drive(hist.I, 1)
    e2rc = float(np.max(np.abs(polarisation_2rc(0.02, 30.0, u1, hist.h) - polarisation_2rc_direct(0.02, 30.0, u1, hist.h))))
    return dict(logical_id=hist.logical_id, N=int(hist.I.size), M=g.M, r=g.r, r_pow_M=r_pow_M, rows=rows,
                max_err_V=worst, err_2rc_lfilter_vs_loop_V=e2rc, tol_V=tol, passed=bool(worst < tol and e2rc < tol))


def unit_check_identified(hists: list, cases: list, ocvs: dict, tol: float = 1e-9,
                          oversample: int = 4, r_pow_M: float = 1e-12) -> dict:
    """FFT vs direct recursion for the full terminal voltage V_t with IDENTIFIED parameter sets.
    cases: dicts with keys label, params (TFOParams/TwoRCParams), N_L (None = full memory, or int), timing.
    Every case is run on every history (identification and test-length records)."""
    rows, worst = [], 0.0
    for H in hists:
        g = FFTGrid(H.I.size, oversample, r_pow_M)
        for c in cases:
            a = simulate(c["params"], H, ocvs[H.logical_id], method="fft", N_L=c["N_L"], grid=g, timing=c["timing"])
            d = simulate(c["params"], H, ocvs[H.logical_id], method="direct", N_L=c["N_L"], timing=c["timing"])
            e = float(np.max(np.abs(a["Vt"] - d["Vt"])))
            worst = max(worst, e)
            rows.append(dict(file=H.logical_id, N=int(H.I.size), label=c["label"], N_L=c["N_L"], timing=c["timing"],
                             max_abs_dVt_V=e))
    return dict(rows=rows, max_err_V=worst, tol_V=tol, passed=bool(worst < tol))
