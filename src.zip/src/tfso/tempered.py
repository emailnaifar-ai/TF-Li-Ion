"""Tempered fractional calculus core of the TFSO study.

Implements, with the notation and labels of the manuscript blocks M1-M4b
(``manuscript_parts/math``):

* Grunwald-Letnikov (GL) weights of the tempered Caputo-type derivative
  ``D^{alpha,lambda} f = e^{-lambda t} CD^alpha[e^{lambda t} f]`` by the stable
  product recursion (lem:m1:glweights, lem:m2:weights), partial sums ``W_n``;
* the finite-memory truncation bounds of thm:m2:truncation and the memory rule
  cor:m2:memory-rule (Lambert-W closed forms with a bisection cross-check);
* real-argument Mittag-Leffler functions, the tempered kernels ``e_lambda``,
  ``g_lambda`` of lem:m1:solution and their L1 norm;
* the implicit finite-memory recursion (eq:m2:implicit-scheme) for one tempered
  relaxation element ``D^{alpha,lambda} x = -a x + b I`` with a ring buffer and
  the exact Caputo correction, and its exact step response;
* the error system of the observer: the continuous-time limit (thm:m3a:convergence,
  thm:m4a:convergence) and the implemented sampled-data recursion
  (prop:m4b:errorrec, thm:m4b:certificate);
* gain certificates (explicit 2x2 M-matrix inequalities and LPs via
  ``scipy.optimize.linprog``; lem:m3a:certificate, prop:m3c:equivalence,
  def:m4b:damping) and LMI gain synthesis with CVXPY + Clarabel (alg:m3c:design);
* the per-sample cost of the finite-memory observer (rem:m4b:cost).

Units (SI unless stated): time t, h, L in s; lambda, sigma in s^-1; a_p in
s^-alpha; b_p in Ohm s^-alpha; I in A; V_p in V; SOC z dimensionless; kappa in V;
l_1 in V^-1 s^-1; l_2 in s^-alpha; Q_n in A h.

All functions are pure numpy/scipy; mpmath is used only for cross-checks and
fallbacks.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy import special as sp
from scipy.optimize import brentq, linprog

__all__ = [
    "gl_weights", "gl_weights_untempered", "partial_sums_W", "weight_bound",
    "C_alpha", "C_alpha_sharp", "upper_gamma_neg", "upper_gamma_neg_mp",
    "tail_integral", "truncation_bound", "untempered_truncation_bound",
    "worst_case_remainder", "memory_rule", "rho_alpha",
    "mittag_leffler", "mittag_leffler_asymptotic", "tempered_kernel",
    "kernel_l1_norm", "tempered_step_integral", "exact_step_response",
    "simulate_tempered_element", "gl_derivative",
    "sigma_h", "mu_hL", "mu_h", "sigma_bar_L", "comparison_matrix",
    "certify_gains_continuous", "certify_gains_discrete", "sigma_star",
    "design_gains", "discrete_transient_bound", "continuous_transient_constant",
    "simulate_error_system", "bias_steady_state", "cost_per_sample",
    "plant_bound", "soc_gain",
]


# ---------------------------------------------------------------------------
# 1. GL weights and partial sums
# ---------------------------------------------------------------------------
def _check_alpha(alpha: float) -> None:
    if not (0.0 < alpha < 1.0):
        raise ValueError(f"alpha must lie in (0,1), got {alpha}")


def gl_weights_untempered(alpha: float, N: int) -> np.ndarray:
    """Untempered GL weights ``omega_j^{(alpha)}``, j = 0..N (dimensionless).

    Stable product recursion ``omega_0 = 1``, ``omega_j = (1 - (alpha+1)/j) omega_{j-1}``
    (lem:m1:glweights (i)); no Gamma-function calls.  ``omega_j < 0`` for j >= 1.
    Relative rounding error grows at most linearly in j (product of N roundings).
    """
    _check_alpha(alpha)
    N = int(N)
    if N < 0:
        raise ValueError("N must be >= 0")
    fac = np.empty(N + 1)
    fac[0] = 1.0
    if N:
        j = np.arange(1, N + 1, dtype=float)
        fac[1:] = 1.0 - (alpha + 1.0) / j
    return np.cumprod(fac)


def gl_weights(alpha: float, lam: float, h: float, N: int) -> np.ndarray:
    """Tempered GL weights ``omega_j^{(alpha,lambda)} = omega_j^{(alpha)} e^{-lambda j h}``, j = 0..N.

    Parameters
    ----------
    alpha : order in (0,1).
    lam : tempering rate lambda >= 0 [s^-1].
    h : step [s].
    N : largest index.

    The recursion ``omega_j = (1-(alpha+1)/j) e^{-lambda h} omega_{j-1}`` is used
    (vectorised as a cumulative product).  Properties (lem:m1:glweights):
    omega_0 = 1, omega_j < 0 (j >= 1),
    ``sum_{j>=1} |omega_j^{(alpha,lambda)}| = 1 - (1 - e^{-lambda h})^alpha``.
    """
    _check_alpha(alpha)
    if lam < 0 or h <= 0:
        raise ValueError("need lam >= 0 and h > 0")
    N = int(N)
    fac = np.empty(N + 1)
    fac[0] = 1.0
    if N:
        j = np.arange(1, N + 1, dtype=float)
        fac[1:] = (1.0 - (alpha + 1.0) / j) * math.exp(-lam * h)
    return np.cumprod(fac)


def partial_sums_W(alpha: float, N: int) -> np.ndarray:
    """``W_n = sum_{j=0}^n omega_j^{(alpha)} = Gamma(n+1-alpha)/(Gamma(1-alpha) Gamma(n+1))``, n = 0..N.

    Recursion ``W_0 = 1``, ``W_n = (1 - alpha/n) W_{n-1}`` (lem:m2:weights (iii));
    bounds ``(n+1)^{-alpha} < Gamma(1-alpha) W_n < n^{-alpha}`` (eq:m2:Wn-bound).
    Dimensionless.
    """
    _check_alpha(alpha)
    N = int(N)
    fac = np.empty(N + 1)
    fac[0] = 1.0
    if N:
        n = np.arange(1, N + 1, dtype=float)
        fac[1:] = 1.0 - alpha / n
    return np.cumprod(fac)


def C_alpha(alpha: float) -> float:
    """``C_alpha = alpha/Gamma(2-alpha)`` (dimensionless), constant of thm:m2:truncation."""
    return alpha / math.gamma(2.0 - alpha)


def C_alpha_sharp(alpha: float, N_L) -> np.ndarray | float:
    """Sharp constant ``C_alpha^sharp(N_L) = alpha/Gamma(1-alpha) (N_L+1)/(N_L+1-alpha)`` (thm:m2:truncation)."""
    N_L = np.asarray(N_L, dtype=float)
    out = alpha / math.gamma(1.0 - alpha) * (N_L + 1.0) / (N_L + 1.0 - alpha)
    return out if out.ndim else float(out)


def weight_bound(alpha: float, j) -> tuple[np.ndarray, np.ndarray]:
    """Two-sided Gautschi bound on ``|omega_j^{(alpha)}|``, j >= 1 (lem:m1:glweights (iv)).

    Returns ``(lower, upper)`` with
    ``lower = alpha/Gamma(1-alpha) (j+1)^{-1-alpha}`` and ``upper = C_alpha j^{-1-alpha}``;
    both strict for every j >= 1 (at j = 1: ``|omega_1| = alpha < alpha/Gamma(2-alpha)``;
    the equality at j = 1 mentioned in M2 concerns only the intermediate step
    ``j/(j-alpha) <= 1/(1-alpha)`` of the proof).
    Tempered weights satisfy the same bounds times ``e^{-lambda j h}``.
    """
    j = np.asarray(j, dtype=float)
    if np.any(j < 1):
        raise ValueError("j >= 1 required")
    lower = alpha / math.gamma(1.0 - alpha) * (j + 1.0) ** (-1.0 - alpha)
    upper = C_alpha(alpha) * j ** (-1.0 - alpha)
    return lower, upper


# ---------------------------------------------------------------------------
# 2. Upper incomplete gamma of negative order and truncation bounds
# ---------------------------------------------------------------------------
def _gamma_neg_cf(alpha: float, x: float) -> float:
    """Gamma(-alpha, x) by the Legendre continued fraction (modified Lentz), x > 0 moderate/large."""
    s = -alpha
    tiny = 1e-300
    b = x + 1.0 - s
    c = 1.0 / tiny
    d = 1.0 / b
    hcf = d
    for i in range(1, 10000):
        an = -i * (i - s)
        b += 2.0
        d = an * d + b
        if abs(d) < tiny:
            d = tiny
        c = b + an / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        de = d * c
        hcf *= de
        if abs(de - 1.0) < 1e-16:
            break
    return math.exp(-x + s * math.log(x)) * hcf


def upper_gamma_neg(alpha: float, x) -> np.ndarray | float:
    """Upper incomplete gamma ``Gamma(-alpha, x) = int_x^inf s^{-alpha-1} e^{-s} ds`` for x > 0.

    For x <= 2 the recurrence of lem:m2:incgamma is used,
    ``Gamma(-alpha,x) = (x^{-alpha} e^{-x} - Gamma(1-alpha) Q(1-alpha,x))/alpha``
    with ``Q = scipy.special.gammaincc`` (no cancellation there); for x > 2 the
    Legendre continued fraction (the recurrence loses ~log10(x) digits by
    cancellation for large x).  Cross-checked against ``mpmath.gammainc(-alpha, x)``
    (``upper_gamma_neg_mp``) in the tests to ~1e-14 relative.
    """
    xa = np.asarray(x, dtype=float)
    if np.any(xa <= 0):
        raise ValueError("x > 0 required")
    out = np.empty_like(xa)
    flat_x = xa.ravel()
    flat_o = out.ravel()
    g1 = math.gamma(1.0 - alpha)
    for k, xv in enumerate(flat_x):
        if xv <= 2.0:
            flat_o[k] = (xv ** (-alpha) * math.exp(-xv) - g1 * sp.gammaincc(1.0 - alpha, xv)) / alpha
        else:
            flat_o[k] = _gamma_neg_cf(alpha, xv)
    out = flat_o.reshape(xa.shape)
    return out if out.ndim else float(out)


def upper_gamma_neg_mp(alpha: float, x: float, dps: int = 30) -> float:
    """Reference value of Gamma(-alpha, x) with mpmath (cross-check only)."""
    import mpmath as mp
    with mp.workdps(dps):
        return float(mp.gammainc(-mp.mpf(alpha), mp.mpf(x)))


def rho_alpha(alpha: float, x):
    """``rho_alpha(x) = alpha x^alpha Gamma(-alpha,x)`` = tempered/untempered bound ratio (eq:m2:ratio-rho)."""
    x = np.asarray(x, dtype=float)
    out = alpha * x ** alpha * upper_gamma_neg(alpha, x)
    return out


def tail_integral(alpha: float, lam: float, L):
    """``int_L^inf x^{-1-alpha} e^{-lambda x} dx`` [s^-alpha] (eq:m2:incgamma-integral).

    ``= lambda^alpha Gamma(-alpha, lambda L)`` for lambda > 0 and ``L^{-alpha}/alpha`` for lambda = 0.
    """
    L = np.asarray(L, dtype=float)
    if lam == 0:
        return L ** (-alpha) / alpha
    return lam ** alpha * upper_gamma_neg(alpha, lam * L)


def truncation_bound(alpha: float, lam: float, L, f_sup: float, form: str = "gamma", h: float | None = None):
    """Bound on the finite-memory remainder ``|R_L(t_n)|`` of thm:m2:truncation [units of f times s^-alpha].

    Parameters
    ----------
    alpha, lam : order and tempering rate [s^-1].
    L : memory length [s] (scalar or array), ``N_L = L/h``.
    f_sup : ``||f||_inf`` (for the plant: the physical bound B_p [V]).
    form :
        ``'gamma'``  ``f_sup C_alpha lambda^alpha Gamma(-alpha, lambda L)`` (tight, h-independent);
        ``'a'``      ``f_sup C_alpha e^{-lambda L}/(lambda L^{1+alpha})`` (lambda > 0);
        ``'b'``      ``f_sup e^{-lambda L} L^{-alpha}/Gamma(2-alpha)``;
        ``'sharp'``  ``f_sup C_alpha^sharp(N_L) int_L^inf x^{-1-alpha} e^{-lambda x} dx`` (needs h).
        For lambda = 0, 'gamma' and 'b' reduce to the untempered bound
        ``f_sup L^{-alpha}/Gamma(2-alpha)`` (eq:m2:trunc-untempered) and 'a' is infinite.
    """
    L = np.asarray(L, dtype=float)
    Ca = C_alpha(alpha)
    if form == "gamma":
        return f_sup * Ca * tail_integral(alpha, lam, L)
    if form == "a":
        if lam == 0:
            return np.full_like(L, np.inf)
        return f_sup * Ca * np.exp(-lam * L) / (lam * L ** (1.0 + alpha))
    if form == "b":
        return f_sup * np.exp(-lam * L) * L ** (-alpha) / math.gamma(2.0 - alpha)
    if form == "sharp":
        if h is None:
            raise ValueError("form='sharp' needs the step h (N_L = L/h)")
        return f_sup * C_alpha_sharp(alpha, np.round(L / h)) * tail_integral(alpha, lam, L)
    raise ValueError(f"unknown form {form!r}")


def untempered_truncation_bound(alpha: float, L, f_sup: float):
    """Untempered short-memory bound ``f_sup L^{-alpha}/Gamma(2-alpha)`` (eq:m2:trunc-untempered)."""
    L = np.asarray(L, dtype=float)
    return f_sup * L ** (-alpha) / math.gamma(2.0 - alpha)


def worst_case_remainder(alpha: float, lam: float, h: float, N_L: int, f_sup: float = 1.0,
                         rtol: float = 1e-17) -> float:
    """Exact worst case ``f_sup h^{-alpha} sum_{j>N_L} |omega_j^{(alpha,lambda)}|`` of |R_L| (constant f).

    Summed directly (no subtraction from the closed-form total, which would cancel
    catastrophically for large lambda L).  Terms are generated by the recursion
    from index N_L in blocks until the next block is below ``rtol`` times the
    running sum (the neglected remainder is below rtol times the result by
    lem:m1:glweights (vii), since the terms decrease geometrically there).  For lambda = 0 the untempered tail
    ``sum_{j>N} |omega_j| = W_N`` (lem:m2:weights (iii)) is used exactly.
    """
    N_L = int(N_L)
    if lam == 0:
        return f_sup * h ** (-alpha) * float(partial_sums_W(alpha, N_L)[-1])
    # |omega_{N_L}| in log form via lgamma for the starting value (then recursion)
    lw = (math.log(alpha) + math.lgamma(N_L - alpha) - math.lgamma(1 - alpha) - math.lgamma(N_L + 1.0)) \
        if N_L >= 1 else 0.0
    w_prev = math.exp(lw) if N_L >= 1 else 1.0  # |omega_{N_L}|, untempered
    q = math.exp(-lam * h)
    total = 0.0
    j0 = N_L
    block = 200000
    logq_prev = -lam * h * N_L
    while True:
        j = np.arange(j0 + 1, j0 + block + 1, dtype=float)
        fac = np.abs(1.0 - (alpha + 1.0) / j)
        w = w_prev * np.cumprod(fac)
        e = np.exp(logq_prev + np.log(q) * np.arange(1, block + 1))
        terms = w * e
        s = float(np.sum(terms[::-1]))
        total += s
        w_prev = float(w[-1])
        logq_prev = logq_prev + math.log(q) * block
        j0 += block
        if s <= rtol * total or terms[-1] == 0.0:
            break
    return f_sup * h ** (-alpha) * total


# ---------------------------------------------------------------------------
# 3. Memory-selection rule (cor:m2:memory-rule)
# ---------------------------------------------------------------------------
def _bisect_decreasing(fun, target: float, lo: float, hi: float, rtol: float = 1e-13) -> float:
    """Root of fun(L) = target for fun strictly decreasing on [lo, hi] (hi grown if needed)."""
    while fun(hi) > target:
        lo, hi = hi, 2.0 * hi
        if hi > 1e300:
            raise RuntimeError("no bracket")
    for _ in range(400):
        mid = 0.5 * (lo + hi)
        if fun(mid) > target:
            lo = mid
        else:
            hi = mid
        if hi - lo <= rtol * hi:
            break
    return 0.5 * (lo + hi)


def memory_rule(alpha: float, lam: float, f_sup: float, eps: float, form: str = "rule",
                h: float | None = None) -> dict:
    """Memory horizons of cor:m2:memory-rule [s].

    Parameters
    ----------
    alpha, lam : order and tempering rate [s^-1] (lam > 0 for the tempered horizons).
    f_sup : a priori bound B >= ||f||_inf (plant: B_p [V]).
    eps : tolerance on |R_L| [units of f times s^-alpha].
    form : which horizon is returned under key ``'L'``: ``'rule'`` = min(L*, L*_b),
        ``'a'`` = L*, ``'b'`` = L*_b, ``'gamma'`` = L*_Gamma, ``'sharp'`` = sharp-constant root
        (needs h), ``'0'`` = untempered L*_0.
    h : optional step [s]; then ``N_L = ceil(L/h)`` is returned too.

    Returns a dict with ``L_star`` (Lambert W0 closed form of the explicit bound 'a'),
    ``L_b_star``, ``L_Gamma_star`` (root of the Gamma bound, by bisection),
    ``L_0_star`` (untempered), the bisection cross-checks ``L_star_bisect``,
    ``L_b_star_bisect`` and the selected ``L`` (and ``N_L``).  Closed forms
    (eq:m2:Lstar): with ``K = C_alpha B lambda^alpha/eps``,
    ``L* = (1+alpha)/lambda W0(K^{1/(1+alpha)}/(1+alpha))``,
    ``L*_0 = (B/(eps Gamma(2-alpha)))^{1/alpha}``,
    ``L*_b = (alpha/lambda) W0(lambda L*_0/alpha)``.
    """
    _check_alpha(alpha)
    Ca = C_alpha(alpha)
    L0 = (f_sup / (eps * math.gamma(2.0 - alpha))) ** (1.0 / alpha)
    out = {"L_0_star": L0}
    if lam > 0:
        K = Ca * f_sup * lam ** alpha / eps
        u = K ** (1.0 / (1.0 + alpha)) / (1.0 + alpha)
        Ls = (1.0 + alpha) / lam * float(np.real(sp.lambertw(u, 0)))
        Lb = alpha / lam * float(np.real(sp.lambertw(lam * L0 / alpha, 0)))
        fa = lambda L: float(truncation_bound(alpha, lam, L, f_sup, "a"))
        fb = lambda L: float(truncation_bound(alpha, lam, L, f_sup, "b"))
        fg = lambda L: float(truncation_bound(alpha, lam, L, f_sup, "gamma"))
        out.update(L_star=Ls, L_b_star=Lb,
                   L_star_bisect=_bisect_decreasing(fa, eps, 1e-12, max(Ls, 1e-6)),
                   L_b_star_bisect=_bisect_decreasing(fb, eps, 1e-12, max(Lb, 1e-6)),
                   L_Gamma_star=_bisect_decreasing(fg, eps, 1e-12, max(min(Ls, Lb), 1e-6)))
        out["L_rule"] = min(Ls, Lb)
        if h is not None:
            def fs(L):
                # eq:m2:Lsharp: C_alpha^sharp evaluated at the real argument L/h (decreasing in it)
                return float(C_alpha_sharp(alpha, L / h) * f_sup * tail_integral(alpha, lam, L))
            out["L_sharp_star"] = max(h, _bisect_decreasing(fs, eps, 1e-12, max(out["L_Gamma_star"], 1e-6)))
    else:
        out.update(L_star=np.inf, L_b_star=L0, L_Gamma_star=L0, L_rule=L0)
    key = {"rule": "L_rule", "a": "L_star", "b": "L_b_star", "gamma": "L_Gamma_star",
           "sharp": "L_sharp_star", "0": "L_0_star"}[form]
    out["L"] = out[key]
    if h is not None:
        out["N_L"] = int(math.ceil(out["L"] / h - 1e-12))
    return out


# ---------------------------------------------------------------------------
# 4. Mittag-Leffler functions (real argument z <= 0)
# ---------------------------------------------------------------------------
def _ml_series(alpha: float, beta: float, z: np.ndarray, kmax: int = 2000) -> np.ndarray:
    """Power series sum_k z^k/Gamma(alpha k + beta); used only where |z|^{1/alpha} <= 4."""
    out = np.zeros_like(z)
    zk = np.ones_like(z)
    for k in range(kmax):
        rg = sp.rgamma(alpha * k + beta)
        term = zk * rg
        out += term
        if k > 5 and np.all(np.abs(term) <= 1e-17 * np.maximum(np.abs(out), 1e-300)):
            break
        zk = zk * z
    return out


def _ml_spectral(alpha: float, beta: float, x: np.ndarray) -> np.ndarray:
    """E_{alpha,beta}(-x), x > 0, 0 < beta < 1 + alpha, by the spectral (Bromwich-on-the-cut) integral

    ``E_{a,b}(-x) = (1/pi) int_0^inf e^{-r} r^{a-b} [r^a sin(pi b) + x sin(pi(b-a))]
    / (r^{2a} + 2 x r^a cos(pi a) + x^2) dr``,

    discretised by the trapezoid rule in s = ln r.  The integrand is analytic in the
    strip |Im s| < d = min(pi(1-a)/a, pi/2), so the step ds = 2 pi d'/40 with
    d' = 0.9 d gives an exponentially small (~e^{-40}) discretisation error.
    """
    d = 0.9 * min(math.pi * (1.0 - alpha) / alpha, math.pi / 2.0)
    ds = min(0.1, 2.0 * math.pi * d / 40.0)
    e0 = alpha - beta + 1.0
    if abs(math.sin(math.pi * (beta - alpha))) < 1e-14:
        e0 += alpha
    s_lo = -45.0 / max(e0, 1e-3)
    s_hi = math.log(80.0)
    s = np.arange(s_lo, s_hi + ds, ds)
    r = np.exp(s)
    ra = r ** alpha
    sb = math.sin(math.pi * beta)
    sba = math.sin(math.pi * (beta - alpha))
    ca = math.cos(math.pi * alpha)
    base = np.exp(-r) * r ** (alpha - beta) * r * ds / math.pi   # includes dr = r ds
    out = np.empty_like(x)
    for k0 in range(0, x.size, 256):
        xx = x[k0:k0 + 256][:, None]
        num = ra[None, :] * sb + xx * sba
        den = ra[None, :] ** 2 + 2.0 * xx * ra[None, :] * ca + xx ** 2
        out[k0:k0 + 256] = np.sum(base[None, :] * num / den, axis=1)
    return out


def _ml_mpmath(alpha: float, beta: float, z: float) -> float:
    """High-precision power-series value (working precision adapted to the cancellation).

    Cost grows like |z|^{1/alpha}; intended for cross-checks and for beta outside
    (0, 1+alpha).  Refuses |z|^{1/alpha} > 3000 (use the spectral method there).
    """
    import mpmath as mp
    x = abs(z)
    X = x ** (1.0 / alpha)
    if X > 3000:
        raise ValueError("mpmath series too expensive for |z|^(1/alpha) > 3000")
    dps = int(30 + X / math.log(10.0) * 1.1)
    with mp.workdps(dps):
        zz = mp.mpf(z)
        s = mp.mpf(0)
        zk = mp.mpf(1)
        k = 0
        tol = mp.mpf(10) ** (-25)
        am, bm = mp.mpf(alpha), mp.mpf(beta)   # exact binary values, argument formed in mp
        while True:
            t = zk * mp.rgamma(am * k + bm)
            s += t
            if k > 10 and k > 2 * X and abs(t) < tol * max(abs(s), mp.mpf(10) ** (-300)):
                break
            zk *= zz
            k += 1
        return float(s)


def mittag_leffler(alpha: float, beta: float, z, method: str = "auto") -> np.ndarray | float:
    """Two-parameter Mittag-Leffler function ``E_{alpha,beta}(z)`` for real z <= 0, 0 < alpha < 1.

    method 'auto': power series where ``|z|^{1/alpha} <= 4`` (cancellation below
    ~1e-14), the spectral integral (``_ml_spectral``, needs 0 < beta < 1 + alpha)
    elsewhere, and the mpmath series with adapted precision as fallback.
    For beta >= 1 + alpha the exact recurrence
    ``E_{a,b}(z) = (E_{a,b-a}(z) - 1/Gamma(b-a))/z`` reduces beta first.
    'series', 'spectral', 'mpmath' force a method.  Accuracy ~1e-13 relative
    (cross-checked in the tests).  Dimensionless.
    """
    _check_alpha(alpha)
    za = np.asarray(z, dtype=float)
    if np.any(za > 0):
        raise ValueError("only z <= 0 is supported")
    flat = za.ravel().copy()
    out = np.empty_like(flat)
    if method == "mpmath":
        out = np.array([_ml_mpmath(alpha, beta, v) for v in flat])
    else:
        small = np.abs(flat) ** (1.0 / alpha) <= 4.0
        if method == "series":
            small[:] = True
        if method == "spectral":
            small[:] = flat == 0.0
        if np.any(small):
            out[small] = _ml_series(alpha, beta, flat[small])
        big = ~small
        if np.any(big):
            if 0.0 < beta < 1.0 + alpha:
                out[big] = _ml_spectral(alpha, beta, -flat[big])
            elif beta >= 1.0 + alpha:
                # E_{a,b}(z) = (E_{a,b-a}(z) - 1/Gamma(b-a))/z, applied until b < 1 + a
                zb = flat[big]
                out[big] = (mittag_leffler(alpha, beta - alpha, zb) - sp.rgamma(beta - alpha)) / zb
            else:
                out[big] = [_ml_mpmath(alpha, beta, v) for v in flat[big]]
    out = out.reshape(za.shape)
    return out if out.ndim else float(out)


def mittag_leffler_asymptotic(alpha: float, beta: float, z, nterms: int = 2):
    """Asymptotic expansion ``E_{alpha,beta}(z) ~ -sum_{k=1}^{n} z^{-k}/Gamma(beta - alpha k)`` (z -> -inf).

    With beta = 1, n = 2 this is eq:m1:mlasym:
    ``E_alpha(-x) ~ x^{-1}/Gamma(1-alpha) - x^{-2}/Gamma(1-2 alpha)``.
    """
    z = np.asarray(z, dtype=float)
    return -sum(z ** (-k) * sp.rgamma(beta - alpha * k) for k in range(1, nterms + 1))


# ---------------------------------------------------------------------------
# 5. Tempered kernels, L1 norm, step response
# ---------------------------------------------------------------------------
def tempered_kernel(alpha: float, lam: float, a: float, t):
    """Kernels of lem:m1:solution for ``D^{alpha,lambda} x = -a x + u``.

    Returns ``(e_lambda(t), g_lambda(t))`` with
    ``e_lambda(t) = e^{-lambda t} E_alpha(-a t^alpha)`` in (0, e^{-lambda t}] (dimensionless) and
    ``g_lambda(t) = e^{-lambda t} t^{alpha-1} E_{alpha,alpha}(-a t^alpha)`` > 0 [s^{alpha-1}]
    (``g_lambda(0) = +inf``).  a in s^-alpha, lam in s^-1, t in s.
    """
    t = np.asarray(t, dtype=float)
    ta = t ** alpha
    e = np.exp(-lam * t) * mittag_leffler(alpha, 1.0, -a * ta)
    with np.errstate(divide="ignore"):
        g = np.exp(-lam * t) * np.where(t > 0, t ** (alpha - 1.0), np.inf) * mittag_leffler(alpha, alpha, -a * ta)
    return e, g


def kernel_l1_norm(alpha: float, lam: float, a: float, quad: bool = False):
    """``||g_lambda||_{L1(0,inf)} = 1/(a + lambda^alpha)`` [s^alpha] (lem:m1:solution (iii)).

    With ``quad=True`` returns ``(closed_form, time_domain_quadrature, spectral_quadrature)``:
    the time-domain value integrates ``g_lambda`` after the substitution u = t^alpha,
    ``int_0^inf g_lambda = (1/alpha) int_0^inf E_{alpha,alpha}(-a u) e^{-lambda u^{1/alpha}} du``
    (smooth integrand, scipy ``quad``); the spectral value is
    ``(1/a) int_0^inf r K_a(r)/(r+lambda) dr`` (rem:m1:spectral).
    """
    closed = 1.0 / (a + lam ** alpha)
    if not quad:
        return closed
    from scipy.integrate import quad as q

    def fu(u):
        return mittag_leffler(alpha, alpha, -a * u) * math.exp(-lam * u ** (1.0 / alpha)) / alpha

    # split at a few scales; tail for lam = 0 decays like u^-2
    brk = [0.0, 1.0 / a, 10.0 / a, 100.0 / a, 1e3 / a, 1e4 / a]
    tval = sum(q(fu, brk[i], brk[i + 1], limit=200, epsabs=0, epsrel=1e-12)[0] for i in range(len(brk) - 1))
    tval += q(fu, brk[-1], np.inf, limit=200, epsabs=0, epsrel=1e-10)[0]

    def Ka(r):
        return a * r ** (alpha - 1) * math.sin(alpha * math.pi) / math.pi / (
            r ** (2 * alpha) + 2 * a * r ** alpha * math.cos(alpha * math.pi) + a * a)

    def fs(s):
        r = math.exp(s)
        return r * Ka(r) * r / (r + lam) / a

    sval = q(fs, -80.0 / alpha, 80.0 / alpha, limit=500, epsabs=0, epsrel=1e-12,
             points=[math.log(a) / alpha])[0]
    return closed, tval, sval


def tempered_step_integral(alpha: float, lam: float, a: float, t) -> np.ndarray:
    """``S_lambda(t) = int_0^t g_lambda(tau) dtau`` [s^alpha] (response of x to a unit step of u).

    Spectral form (from rem:m1:spectral): with ``D(r) = r^{2a'} + 2 a r^{a'} cos(pi a') + a^2`` (a' = alpha),
    ``S_lambda(t) = (1/pi) int_0^inf r^alpha sin(pi alpha)/D(r) (1 - e^{-(r+lambda) t})/(r+lambda) dr``,
    trapezoid in s = ln r (strip half-width min(pi(1-alpha)/alpha, pi/2)).
    ``S_lambda(inf) = 1/(a + lambda^alpha)``; for lambda = 0, ``S_0(t) = (1 - E_alpha(-a t^alpha))/a``.
    """
    t = np.atleast_1d(np.asarray(t, dtype=float))
    d = 0.9 * min(math.pi * (1.0 - alpha) / alpha, math.pi / 2.0)
    ds = min(0.1, 2.0 * math.pi * d / 40.0)
    s = np.arange(-45.0 / alpha + math.log(a) / alpha, 45.0 / alpha + math.log(a) / alpha, ds)
    r = np.exp(s)
    ra = r ** alpha
    w = ra * math.sin(math.pi * alpha) / (ra * ra + 2 * a * ra * math.cos(math.pi * alpha) + a * a) \
        / (r + lam) * r * ds / math.pi
    out = np.empty_like(t)
    for k0 in range(0, t.size, 128):
        tt = t[k0:k0 + 128][:, None]
        out[k0:k0 + 128] = np.sum(w[None, :] * (-np.expm1(-(r[None, :] + lam) * tt)), axis=1)
    return out


def exact_step_response(alpha: float, lam: float, a: float, b: float, I0: float, t, x0: float = 0.0):
    """Exact solution of ``D^{alpha,lambda} x = -a x + b I0`` (constant current I0 [A] for t >= 0).

    ``x(t) = x0 e_lambda(t) + b I0 S_lambda(t)`` (lem:m1:solution (i)); units of x = V when
    b is in Ohm s^-alpha.  Steady state ``b I0/(a + lambda^alpha)`` (prop:m1:transfer DC gain).
    """
    t = np.atleast_1d(np.asarray(t, dtype=float))
    e, _ = tempered_kernel(alpha, lam, a, t)
    return x0 * e + b * I0 * tempered_step_integral(alpha, lam, a, t)


# ---------------------------------------------------------------------------
# 6. Finite-memory implicit recursion (ring buffer) and GL derivative
# ---------------------------------------------------------------------------
class _RingBuffer:
    """History of the last N_L values stored twice (length 2 N_L) so that the window
    ``x_{n-N_L}, ..., x_{n-1}`` is always one contiguous slice (O(1) push, no copy)."""

    def __init__(self, N_L: int):
        self.N = int(N_L)
        self.buf = np.zeros(2 * self.N)
        self.pos = 0  # slot of the next write

    def push(self, v: float) -> None:
        self.buf[self.pos] = v
        self.buf[self.pos + self.N] = v
        self.pos = (self.pos + 1) % self.N

    def window(self) -> np.ndarray:
        """Oldest -> newest, i.e. (x_{n-N_L}, ..., x_{n-1}); unused slots are 0."""
        return self.buf[self.pos:self.pos + self.N]


def simulate_tempered_element(alpha: float, lam: float, a: float, b: float, I, h: float,
                              x0: float = 0.0, N_L: int | None = None) -> np.ndarray:
    """Implicit finite-memory GL recursion for ``D^{alpha,lambda} x = -a x + b I`` (eq:m2:implicit-scheme).

    ``(1 + h^alpha a) x_n = h^alpha b I_n - sum_{j=1}^{min(n,N_L)} omega_j^{(alpha,lambda)} x_{n-j}
    + x_0 e^{-lambda t_n} W_n``  (exact Caputo correction, def:m2:finite-memory).

    Parameters
    ----------
    alpha, lam : order, tempering rate [s^-1];  a [s^-alpha];  b [Ohm s^-alpha].
    I : current samples I_0..I_N [A] (array, length N+1); I_0 is not used (x_0 is given).
    h : step [s];  x0 : initial value [V];  N_L : memory in samples (None = full memory).

    Returns x_0..x_N [V].  Cost: min(n, N_L) multiply-adds per step (one dot product
    with a contiguous ring-buffer slice); storage 2 N_L history doubles + N_L weights.
    A priori bound (lem:m2:apriori): ``|x_n| <= max(|x_0|, b ||I||_inf / a)``.
    """
    I = np.asarray(I, dtype=float)
    N = I.size - 1
    NL = N if (N_L is None or N_L >= N) else int(N_L)
    NL = max(NL, 1)
    om = gl_weights(alpha, lam, h, NL)
    wrev = om[1:][::-1].copy()          # (omega_{N_L}, ..., omega_1) matches window order
    W = partial_sums_W(alpha, N) if x0 != 0.0 else None
    ha = h ** alpha
    den = 1.0 + ha * a
    x = np.empty(N + 1)
    x[0] = x0
    rb = _RingBuffer(NL)
    rb.push(x0)
    for n in range(1, N + 1):
        mem = float(np.dot(wrev, rb.window()))
        corr = x0 * math.exp(-lam * n * h) * W[n] if W is not None else 0.0
        x[n] = (ha * b * I[n] - mem + corr) / den
        rb.push(x[n])
    return x


def gl_derivative(f, alpha: float, lam: float, h: float, N_L: int | None = None) -> np.ndarray:
    """Corrected GL approximation ``D_h`` / ``D_{h,L}`` of ``D^{alpha,lambda} f`` at t_n (def:m1:scheme, def:m2:finite-memory).

    ``h^{-alpha}[sum_{j=0}^{min(n,N_L)} omega_j^{(alpha,lambda)} f_{n-j} - f_0 e^{-lambda t_n} W_n]``,
    vectorised with FFT-free direct convolution (``np.convolve``); units of f times s^-alpha.
    """
    f = np.asarray(f, dtype=float)
    N = f.size - 1
    NL = N if (N_L is None or N_L >= N) else int(N_L)
    om = gl_weights(alpha, lam, h, NL)
    conv = np.convolve(f, om)[:N + 1]
    W = partial_sums_W(alpha, N)
    t = h * np.arange(N + 1)
    return h ** (-alpha) * (conv - f[0] * np.exp(-lam * t) * W)


# ---------------------------------------------------------------------------
# 7. Discrete comparison quantities (def:m3c:comparison, def:m4b:damping)
# ---------------------------------------------------------------------------
def sigma_h(sigma: float, h: float) -> float:
    """``sigma_h = (1 - e^{-sigma h})/h`` [s^-1] (<= sigma, -> sigma as h -> 0)."""
    return -math.expm1(-sigma * h) / h


def mu_h(alpha: float, lam: float, sigma: float, h: float) -> float:
    """Full-memory discrete damping ``h^{-alpha}(1 - e^{-(lambda-sigma)h})^alpha`` [s^-alpha], sigma <= lambda."""
    if sigma > lam:
        raise ValueError("full memory: sigma <= lambda required")
    return h ** (-alpha) * (-math.expm1(-(lam - sigma) * h)) ** alpha


def mu_hL(alpha: float, lam: float, sigma: float, h: float, N_L: int | None) -> float:
    """``mu_{h,L}(sigma) = h^{-alpha}[1 - sum_{j=1}^{N_L} |omega_j^{(alpha)}| e^{-(lambda-sigma) j h}]`` [s^-alpha].

    ``N_L = None`` gives the full-memory value ``mu_h(sigma)`` (sigma <= lambda).
    Finite memory: defined for every sigma (also sigma > lambda, where it may be
    negative); overflow-safe evaluation with exponent shifting.
    """
    if N_L is None:
        return mu_h(alpha, lam, sigma, h)
    w = -gl_weights_untempered(alpha, int(N_L))[1:]
    j = np.arange(1, int(N_L) + 1, dtype=float)
    ex = -(lam - sigma) * j * h
    m = float(np.max(ex))
    if m > 700:
        S = math.exp(m) * float(np.sum(w * np.exp(ex - m)))
        return -math.inf if not math.isfinite(S) else h ** (-alpha) * (1.0 - S)
    return h ** (-alpha) * (1.0 - float(np.sum(w * np.exp(ex))))


def sigma_bar_L(alpha: float, lam: float, ap: float, h: float, N_L: int) -> float:
    """Root sigma > lambda of ``a_p + mu_{h,L}(sigma) = 0`` (prop:m3c:rates-discrete (iii)) [s^-1]."""
    f = lambda s: ap + mu_hL(alpha, lam, s, h, N_L)
    hi = lam + 1e-3
    while f(hi) > 0:
        hi = lam + 2.0 * (hi - lam)
    return brentq(f, lam, hi, xtol=1e-15, rtol=1e-13)


def comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, sigma, h=None, N_L=None) -> np.ndarray:
    """Comparison matrix ``M_sigma`` (continuous, eq:m3a:Msigma) or ``M_{h,L}(sigma)`` (discrete, eq:m4b:Mmatrix).

    Continuous (h None): ``[[-(l1 k1 - sigma), l1], [l2 k2, -(ap + l2 + (lam - sigma)^alpha)]]``, sigma <= lam.
    Discrete: sigma -> sigma_h, (lam - sigma)^alpha -> mu_{h,L}(sigma).
    """
    if h is None:
        if sigma > lam:
            raise ValueError("continuous certificate needs sigma <= lambda")
        S, mu = sigma, (lam - sigma) ** alpha
    else:
        S, mu = sigma_h(sigma, h), mu_hL(alpha, lam, sigma, h, N_L)
    return np.array([[-(l1 * k1 - S), l1], [l2 * k2, -(ap + l2 + mu)]])


@dataclass
class Certificate:
    """Result of a gain certificate test."""
    certified: bool
    explicit: bool
    lp: bool
    lp_margin: float
    positivity: bool = True
    d: np.ndarray | None = None          # M^T d < 0 (LP dual certificate, weighted l1 norm)
    xi: np.ndarray | None = None         # M xi < 0 (weighted max norm |e|_xi, eq:m3a:vnorm)
    P: np.ndarray | None = None          # diagonal LMI certificate He(P M) < 0
    M: np.ndarray | None = None
    info: dict = field(default_factory=dict)


def _lp_certificate(M: np.ndarray, transpose: bool = True):
    """LP: maximise t s.t. (M^T d)_i <= -t, d >= 0, d_1 + d_2 = 1, t <= 1 (scipy HiGHS).

    Feasible certificate iff optimum t* > 0; returns (t*, d).
    """
    A = M.T if transpose else M
    # variables (d1, d2, t); minimise -t
    c = np.array([0.0, 0.0, -1.0])
    A_ub = np.hstack([A, np.ones((2, 1))])
    b_ub = np.zeros(2)
    A_eq = np.array([[1.0, 1.0, 0.0]])
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=[1.0],
                  bounds=[(0, None), (0, None), (None, 1.0)], method="highs")
    if res.status != 0:
        return -np.inf, None
    return -res.fun, res.x[:2]


def _explicit_certs(m1, m2, c12, c21):
    """Closed-form certificates of prop:m3c:equivalence for N = [[-m1, c12],[c21, -m2]]."""
    d = np.array([0.5 * (c21 / m1 + m2 / c12), 1.0])
    xi = np.array([1.0, 0.5 * (c21 / m2 + m1 / c12)])
    P = np.diag([c21, c12]) if c21 > 0 else np.diag([2 * m1 * m2, c12 ** 2])
    return d, xi, P


def certify_gains_continuous(alpha, lam, ap, k1, k2, l1, l2, sigma=0.0, tol_lp=1e-12) -> Certificate:
    """Certificate of lem:m3a:certificate / lem:m4a:metzler at rate sigma in [0, lambda].

    Explicit test: ``l1 k1 > sigma`` and ``(l1 k1 - sigma)(ap + l2 + (lam-sigma)^alpha) > l1 l2 k2``;
    LP test: exists d > 0 with ``M_sigma^T d < 0`` (scipy linprog); both are returned and
    must agree (prop:m3c:equivalence).  Gains: l1 [V^-1 s^-1], l2 [s^-alpha]; kappas [V].
    """
    M = comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, sigma)
    m1, m2 = -M[0, 0], -M[1, 1]
    explicit = bool(m1 > 0 and m1 * m2 > l1 * l2 * k2)
    t, d_lp = _lp_certificate(M)
    lp = bool(t > tol_lp)
    cert = Certificate(certified=explicit, explicit=explicit, lp=lp, lp_margin=t, M=M,
                       info={"theta": l1 * l2 * k2 / (m1 * m2) if m1 > 0 and m2 > 0 else np.inf})
    if explicit:
        cert.d, cert.xi, cert.P = _explicit_certs(m1, m2, l1, l2 * k2)
    elif lp:
        cert.d = d_lp
    return cert


def certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, sigma, h, N_L=None, tol_lp=1e-12) -> Certificate:
    """Discrete condition (DC) of def:m4b:damping for the implemented observer.

    ``h l1 k2 <= 1`` (positivity), ``l1 k1 > sigma_h`` and
    ``(l1 k1 - sigma_h)(ap + l2 + mu_{h,L}(sigma)) > l1 l2 k2``.  Full memory (N_L None)
    requires sigma <= lambda; finite memory admits sigma > lambda (certifies the
    homogeneous finite-memory recursion; rem:m3c:finite-memory-rate).
    """
    if N_L is None and sigma > lam:
        return Certificate(False, False, False, -np.inf, info={"reason": "full memory: sigma > lambda"})
    M = comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, sigma, h=h, N_L=N_L)
    m1, m2 = -M[0, 0], -M[1, 1]
    pos = bool(h * l1 * k2 <= 1.0)
    explicit = bool(m1 > 0 and m1 * m2 > l1 * l2 * k2)
    t, d_lp = _lp_certificate(M)
    lp = bool(t > tol_lp)
    cert = Certificate(certified=explicit and pos, explicit=explicit, lp=lp, lp_margin=t, positivity=pos, M=M,
                       info={"sigma_h": sigma_h(sigma, h), "mu": m2 - ap - l2})
    if explicit:
        cert.d, cert.xi, cert.P = _explicit_certs(m1, m2, l1, l2 * k2)
    elif lp:
        cert.d = d_lp
    return cert


def sigma_star(alpha, lam, ap, k1, k2, l1, l2, h=None, N_L=None, tol=1e-12) -> float | None:
    """Largest certified rate [s^-1] (bisection; the condition is monotone in sigma, lem:m4b:damping (vi)).

    Continuous / full memory: searched in [0, lambda]; finite memory: in [0, sigma_max]
    with the upper end from ``a_p + l2 + mu_{h,L} = 0`` and ``sigma_h < l1 k1``.
    Returns None if not certified at sigma = 0.
    """
    def ok(s):
        if h is None:
            return certify_gains_continuous(alpha, lam, ap, k1, k2, l1, l2, s).explicit
        return certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, s, h, N_L).certified
    if not ok(0.0):
        return None
    if h is None or N_L is None:
        hi = lam
    else:
        hi = lam + 1e-3
        while ok(hi):
            hi = lam + 2 * (hi - lam)
    if ok(hi):
        return hi
    lo = 0.0
    while hi - lo > tol * max(hi, 1e-300):
        mid = 0.5 * (lo + hi)
        if ok(mid):
            lo = mid
        else:
            hi = mid
    return lo


# ---------------------------------------------------------------------------
# 8. LMI gain synthesis (CVXPY + Clarabel), alg:m3c:design
# ---------------------------------------------------------------------------
def _lmi_margin(S, mu, ap, k1, k2, l1min, l1max, l2max, h=None):
    """max t s.t. He(P M) <= -t I, p1 + p2 = 1, gain box, [positivity h k2 y1 <= p1].

    Variables p1, p2 > 0, y1 = p1 l1, y2 = p2 l2 (Y = P diag(l1, l2)); the matrix
    ``He(P M) = [[2(S p1 - k1 y1), y1 + k2 y2], [y1 + k2 y2, -2((ap+mu) p2 + y2)]]``
    is affine in (p, y).  Returns (t*, l1, l2, P) or (-inf, None, None, None).
    """
    import cvxpy as cp
    p = cp.Variable(2)
    y = cp.Variable(2)
    t = cp.Variable()
    L11 = 2 * (S * p[0] - k1 * y[0])
    L12 = y[0] + k2 * y[1]
    L22 = -2 * ((ap + mu) * p[1] + y[1])
    Lm = cp.bmat([[L11 + t, L12], [L12, L22 + t]])
    cons = [Lm << 0, p >= 1e-9, cp.sum(p) == 1, y[0] >= l1min * p[0], y[0] <= l1max * p[0],
            y[1] >= 0, y[1] <= l2max * p[1], t <= 10.0]
    if h is not None:
        cons.append(h * k2 * y[0] <= p[0])
    prob = cp.Problem(cp.Maximize(t), cons)
    try:
        prob.solve(solver=cp.CLARABEL)
    except Exception:  # pragma: no cover - solver failure is reported as infeasible
        return -np.inf, None, None, None
    if prob.status not in ("optimal", "optimal_inaccurate") or t.value is None:
        return -np.inf, None, None, None
    pv, yv = np.asarray(p.value), np.asarray(y.value)
    return float(t.value), float(yv[0] / pv[0]), float(max(yv[1], 0.0) / pv[1]), np.diag(pv)


def design_gains(alpha, lam, ap, k1, k2, h=None, N_L=None, l1max=None, l1min=0.0, l2max=1.0,
                 t_feas=1e-9, tol_sigma=1e-7, margin=0.1):
    """Gain synthesis by the diagonal LMI in (P, Y) with bisection on sigma (alg:m3c:design).

    For each trial rate sigma the margin program (``_lmi_margin``) is solved with
    CVXPY + Clarabel; a rate is accepted only if the solver margin exceeds
    ``t_feas`` AND the recovered gains ``l_i = y_i/p_i`` pass the explicit
    inequalities (``certify_gains_continuous`` / ``certify_gains_discrete``).
    Bracket: [0, lambda] (continuous or full memory) or [0, sigma_bar] with sigma_bar
    from ``a_p + l2max + mu_{h,L}(sigma) = 0`` (finite memory).  Default
    ``l1max = 1/(h k2)`` (positivity) in discrete time and ``10`` [V^-1 s^-1] in
    continuous time.

    Returns dict(sigma_cert, l1, l2, P, sigma_d = (1-margin) sigma_cert) or None.

    Equivalent YALMIP code (MATLAB), fixed sigma, discrete case::

        p = sdpvar(2,1); y = sdpvar(2,1); t = sdpvar(1);
        S = (1-exp(-sigma*h))/h;  mu = muhL(sigma);          % continuous: S = sigma, mu = (lam-sigma)^alpha
        L = [2*(S*p(1)-k1*y(1)),  y(1)+k2*y(2);
             y(1)+k2*y(2),       -2*((ap+mu)*p(2)+y(2))];
        F = [L + t*eye(2) <= 0, p >= 1e-9, sum(p) == 1, ...
             l1min*p(1) <= y(1) <= l1max*p(1), 0 <= y(2) <= l2max*p(2), h*k2*y(1) <= p(1)];
        optimize(F, -t, sdpsettings('solver','sedumi'));   % or sdpt3 / mosek
        l1 = value(y(1))/value(p(1)); l2 = value(y(2))/value(p(2));
    """
    if l1max is None:
        l1max = 1.0 / (h * k2) if h is not None else 10.0

    def prog(s):
        if h is None:
            return _lmi_margin(s, (lam - s) ** alpha, ap, k1, k2, l1min, l1max, l2max)
        return _lmi_margin(sigma_h(s, h), mu_hL(alpha, lam, s, h, N_L), ap, k1, k2, l1min, l1max, l2max, h=h)

    def check(s, l1, l2):
        if l1 is None:
            return False
        if h is None:
            return certify_gains_continuous(alpha, lam, ap, k1, k2, l1, l2, s).explicit
        return certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, s, h, N_L).certified

    if h is None or N_L is None:
        hi = lam
    else:
        f = lambda s: ap + l2max + mu_hL(alpha, lam, s, h, N_L)
        up = lam + 1e-3
        while f(up) > 0:
            up = lam + 2 * (up - lam)
        hi = brentq(f, lam, up)
        hi = min(hi, -math.log(max(1.0 - h * l1max * k1, 1e-300)) / h)
    t0, a0, b0, P0 = prog(0.0)
    if not (t0 > t_feas and check(0.0, a0, b0)):
        return None
    th, ah, bh, Ph = prog(hi)
    if th > t_feas and check(hi, ah, bh):
        lo, best = hi, (ah, bh, Ph)
    else:
        lo, best = 0.0, (a0, b0, P0)
        while hi - lo > tol_sigma * max(1.0, hi):
            mid = 0.5 * (lo + hi)
            tm, am, bm, Pm = prog(mid)
            if tm > t_feas and check(mid, am, bm):
                lo, best = mid, (am, bm, Pm)
            else:
                hi = mid
    return {"sigma_cert": lo, "l1": best[0], "l2": best[1], "P": best[2], "sigma_d": (1 - margin) * lo}


# ---------------------------------------------------------------------------
# 9. Transient bounds
# ---------------------------------------------------------------------------
def continuous_transient_constant(alpha, lam, ap, k1, k2, l1, l2, sigma, use_cone=True):
    """Constant C and weight vector xi of thm:m3a:convergence / prop:m3a:Cone.

    ``|e(t)|_xi <= C e^{-sigma t} |e(0)|_xi`` with ``|e|_xi = max(|e_z|/xi_1, |e_p|/xi_2)``
    (eq:m3a:vnorm), c = l1 k1 - sigma, at = ap + l2 + (lam - sigma)^alpha,
    theta = l1 l2 k2/(c at) (eq:m3a:Msigma).

    * ``use_cone=True`` and ``c (ap + l2) > l1 l2 k2`` (eq:m3a:Cone; always true at
      sigma = lambda under the certificate): C = 1 with xi = (1, xi_2), xi_2 the midpoint
      of ``(l2 k2/(ap + l2), c/l1)`` (prop:m3a:Cone).
    * otherwise the geometric weights ``xi_2 = sqrt(l2 k2 c/(at l1))`` and
      ``C = 1 + q2 max(1, q1/(1-theta)) = max(1 + q2, 1/(1-theta))`` (eq:m3a:constC),
      ``q1 = l1 xi_2/c``, ``q2 = l2 k2/(at xi_2)`` (so q1 q2 = theta); C = 1 if l2 = 0.

    Returns (C, xi, theta).
    """
    c = l1 * k1 - sigma
    at = ap + l2 + (lam - sigma) ** alpha
    theta = l1 * l2 * k2 / (c * at)
    if l2 == 0:
        return 1.0, np.array([1.0, 0.5 * c / l1]), theta
    if use_cone and c * (ap + l2) > l1 * l2 * k2:
        return 1.0, np.array([1.0, 0.5 * (l2 * k2 / (ap + l2) + c / l1)]), theta
    v2 = math.sqrt(l2 * k2 * c / (at * l1))
    q1 = l1 * v2 / c
    q2 = l2 * k2 / (at * v2)
    C = 1.0 + q2 * max(1.0, q1 / (1.0 - theta))
    return C, np.array([1.0, v2]), theta


def plant_bound(ap, bp, lam, alpha, I_max, Vp0_bar=0.0):
    """Plant polarisation bound ``B_p = bar V_p0 + b_p I_max/(a_p + lambda^alpha)`` [V]
    (eq:m1:plantbound = eq:m3a:Bp); ``Vp0_bar >= |V_p(0)|`` (Assumption (A12)), 0 after rest.
    The uniform version over the parameter box uses ``b_p^+`` and ``a_p^-``."""
    return Vp0_bar + bp * I_max / (ap + lam ** alpha)


def soc_gain(alpha, lam, ap, k1, k2, l2, h=None, N_L=None):
    """SOC gain from the polarisation channel, ``gamma_zp = 1/(k1 (ap + l2 + M) - l2 k2)``.

    M = lambda^alpha (continuous gain eq:m2:gain-zp = [-M_0^{-1}]_12, h None);
    M = mu_h(0) (``gamma_zp^{(h)}``, full memory, N_L None) or M = mu_{h,L}(0)
    (``gamma_zp^{(h,L)}``) of eq:m2:gain-zp-h.  Only the discrete gains certify the
    implemented recursion (cor:m2:soc, cor:m4b:memory).  Units V^-1 s^alpha.
    Raises ValueError if ``k1 (ap + l2 + M) <= l2 k2``.
    """
    M = lam ** alpha if h is None else mu_hL(alpha, lam, 0.0, h, N_L)
    den = k1 * (ap + l2 + M) - l2 * k2
    if den <= 0:
        raise ValueError("gain condition k1 (ap + l2 + M) > l2 k2 violated")
    return 1.0 / den


def discrete_transient_bound(alpha, lam, ap, k1, k2, l1, l2, sigma, h, N_L, ez0, ep0, n):
    """Disturbance-free bound (i) of thm:m4b:certificate at indices n.

    ``|e_z,n| <= xi_1 vartheta_n``, ``|e_p,n| <= |e_p0| e^{-lambda t_n} + xi_2 vartheta_n``, with
    ``vartheta_n = d_1|e_z0| e^{-sigma t_n} + (l1 |e_p0|/nu) e^{-sigma' t_n}``, sigma' = min(sigma, lambda),
    xi from eq:m4b:xi, d = 1/xi, ``nu = [-M_{h,L}(sigma') xi]_1``.  Returns (bz, bp).
    """
    cert = certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, sigma, h, N_L)
    if not cert.certified:
        raise ValueError("(DC) does not hold at this sigma")
    c = ap + l2 + mu_hL(alpha, lam, sigma, h, N_L)
    xi = np.array([1.0, 0.5 * (l2 * k2 / c + (l1 * k1 - sigma_h(sigma, h)) / l1)])
    d = 1.0 / xi
    sp_ = min(sigma, lam)
    Mp = comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, sp_, h=h, N_L=N_L)
    nu = float(-(Mp @ xi)[0])
    t = h * np.asarray(n, dtype=float)
    th = d[0] * abs(ez0) * np.exp(-sigma * t) + l1 * abs(ep0) / nu * np.exp(-sp_ * t)
    return xi[0] * th, abs(ep0) * np.exp(-lam * t) + xi[1] * th


# ---------------------------------------------------------------------------
# 10. Error-system simulation
# ---------------------------------------------------------------------------
def _as_seq(v, N, h, refine=1):
    """Scalar / callable(t) / array(N+1) -> array on the (fine) grid of N*refine+1 points (ZOH for arrays)."""
    M = N * refine
    if v is None:
        return np.zeros(M + 1)
    if callable(v):
        return np.asarray([v(k * h / refine) for k in range(M + 1)], dtype=float)
    a = np.asarray(v, dtype=float)
    if a.ndim == 0:
        return np.full(M + 1, float(a))
    if a.size != N + 1:
        raise ValueError("array inputs must have N+1 samples")
    idx = np.minimum(np.arange(M + 1) // refine, N)
    return a[idx]


def simulate_error_system(alpha, lam, ap, l1, l2, kappa, h, N, ez0, ep0, wz=None, wp=None,
                          N_L=None, mode="discrete", refine=1) -> dict:
    """Error dynamics of the SOC observer (nominal parameters).

    mode='discrete': the implemented sampled-data recursion (eq:m4b:ez-rec, eq:m4b:ep-rec)
        ``e_z,n = (1 - h l1 k_{n-1}) e_z,n-1 - h l1 e_p,n-1 + h w_z,n-1``,
        ``(1 + h^a (ap+l2)) e_p,n = -sum_{j<=m_n} omega_j e_p,n-j + e_p0 e^{-lam t_n} W_n
        + h^a(-l2 k_n e_z,n + w_p,n)`` with memory N_L (None = full); pass
        ``w_p + r - R_L`` as ``wp`` to include the plant residuals.
    mode='continuous': approximation of the continuous-time error system
        (lem:m3a:error) on a grid refined ``refine`` times, full memory, same scheme
        (first order); kappa and w are held (arrays) or sampled (callables).

    kappa : scalar, array (N+1) or callable(t) [V]; wz [s^-1]; wp [V s^-alpha];
    ez0 [-], ep0 = V_p(0) [V].  Returns dict(t, ez, ep) on the coarse grid.
    """
    if mode not in ("discrete", "continuous"):
        raise ValueError("mode must be 'discrete' or 'continuous'")
    if mode == "continuous":
        N_L = None
    else:
        refine = 1
    hh = h / refine
    M = N * refine
    k = _as_seq(kappa, N, h, refine)
    wzs = _as_seq(wz, N, h, refine)
    wps = _as_seq(wp, N, h, refine)
    NL = M if (N_L is None or N_L >= M) else int(N_L)
    NL = max(NL, 1)
    om = gl_weights(alpha, lam, hh, NL)
    wrev = om[1:][::-1].copy()
    W = partial_sums_W(alpha, M)
    ha = hh ** alpha
    den = 1.0 + ha * (ap + l2)
    ez = np.empty(M + 1)
    ep = np.empty(M + 1)
    ez[0], ep[0] = ez0, ep0
    rb = _RingBuffer(NL)
    rb.push(ep0)
    for n in range(1, M + 1):
        ez[n] = (1.0 - hh * l1 * k[n - 1]) * ez[n - 1] - hh * l1 * ep[n - 1] + hh * wzs[n - 1]
        mem = float(np.dot(wrev, rb.window()))
        corr = ep0 * math.exp(-lam * n * hh) * W[n]
        ep[n] = (-mem + corr + ha * (-l2 * k[n] * ez[n] + wps[n])) / den
        rb.push(ep[n])
    sl = slice(None, None, refine)
    return {"t": h * np.arange(N + 1), "ez": ez[sl], "ep": ep[sl]}


# ---------------------------------------------------------------------------
# 11. Constant-bias steady state and cost
# ---------------------------------------------------------------------------
def bias_steady_state(dI, kappa, R0, ap, bp, l1, l2, eta, Qn, lam, alpha, h=None, N_L=None,
                      I=0.0) -> float:
    """Constant-bias SOC error (eq:m3c:bias = eq:m4b:steady, cor:m4a:bias) [-].

    ``e_z,ss = (dI/kappa)[R0 + bp/(ap+M) - eta (ap+l2+M)/(3600 Qn l1 (ap+M))]
               - bp I (M - lambda^alpha)/(kappa (ap+M)(ap+lambda^alpha))``
    with ``M = lambda^alpha`` (continuous, h None: the last term vanishes, eq:m4a:biasss) or
    ``M = mu_0 = mu_{h,L}(0)`` of the implemented observer (``mu_h(0)`` for full memory,
    N_L None).  ``I`` is the constant true current [A]: for the implemented observer the
    plant residual and the truncation residual add the gain-independent offset of the
    last term (rem:m3c:bias, rem:m4b:steadystate), which is zero when I = 0.
    Compare with the Coulomb drift ``eta dI t/(3600 Qn)``.
    """
    M = lam ** alpha if h is None else mu_hL(alpha, lam, 0.0, h, N_L)
    ss = dI / kappa * (R0 + bp / (ap + M) - eta * (ap + l2 + M) / (3600.0 * Qn * l1 * (ap + M)))
    return ss - bp * I * (M - lam ** alpha) / (kappa * (ap + M) * (ap + lam ** alpha))


def cost_per_sample(N_L: int, store_weights: bool = True, dtype_bytes: int = 8) -> dict:
    """Per-sample cost of the finite-memory observer update (rem:m4b:cost).

    Multiply-adds: N_L for the memory sum plus a constant overhead (SOC update 4,
    implicit polarisation update 6, output 2; one OCV evaluation counted separately).
    Storage: doubled ring buffer 2 N_L values (contiguous window) plus N_L weights
    (``store_weights=True``); without stored weights they are regenerated by the
    recursion (one extra multiply each).  ``bytes_min`` is the minimum: one plain
    circular buffer of N_L values (two slices per dot product) and no weight table.
    Returns dict(macs, ocv_evals, bytes, bytes_min).
    """
    N_L = int(N_L)
    macs = N_L + 12 + (0 if store_weights else N_L)
    nbytes = dtype_bytes * (2 * N_L + (N_L if store_weights else 0) + 8)
    return {"macs": macs, "ocv_evals": 1, "bytes": nbytes, "bytes_min": dtype_bytes * (N_L + 8)}
