"""Canonical data layer for the CALCE INR18650-20R (SP1/SP2/SP3) Arbin exports.

Every number used downstream (identification, observer, relaxation fits) must come
through this module.  Nothing here is hard-coded from documentation: capacities,
sampling intervals, sign convention and SOC anchors are all *measured* from the
exported channels and cross-checked against the Arbin capacity columns.

Public API
----------
CATALOG                     logical_id -> metadata (cell, temperature, test type, sources, split)
load_config()               parsed config/config.yaml
read_workbook(path)         concatenate chunked data sheets of one Arbin workbook (with metadata)
load_raw(logical_id)        DataFrame from data_processed (rebuilt from data_raw if missing)
verify_file(logical_id)     integrity checks that must pass before any estimation
segments(logical_id)        one row per (cycle, step): type, timing, Ah, currents, voltages, dt stats
get_dynamic_profile(id, h)  step-7 profile on a uniform grid (+ irregular arrays, metadata)
reference_soc(id, ...)      trapezoidal Coulomb-counting reference SOC with uncertainty band
get_relaxations(id)         rest periods after 1 A pulses (incremental-OCV files)
get_ocv_points(id)          relaxed voltages at the end of each long rest, with SOC labels
compute_capacity()          measured capacities, ground-truth Q_ref(T) +/- u_Q(T) and estimator-side Q_id(T) for SP2
cv_to_cutoff_throughput(id) net Ah from the end of CV (step 3) to the 2.5 V cutoff (end of step 7), Arbin + trapezoid
audit_file(id)              machine-readable inventory entry (items 1-12 of the audit specification)

Conventions
-----------
* Current(A) > 0 is charge, < 0 is discharge (verified numerically in verify_file / audit_file).
* Test_Time(s) is the clock; Date_Time is a 1 s-rounded wall clock that drifts.
* Temperatures are chamber set points from the file names; NO temperature channel exists.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from scipy.integrate import cumulative_trapezoid

# --------------------------------------------------------------------------------------
# Paths / config
# --------------------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / "config" / "config.yaml"

_CONFIG_CACHE: dict | None = None


def load_config(refresh: bool = False) -> dict:
    """Return the parsed project configuration (cached)."""
    global _CONFIG_CACHE
    if _CONFIG_CACHE is None or refresh:
        with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
            _CONFIG_CACHE = yaml.safe_load(fh)
    return _CONFIG_CACHE


def _path(key: str) -> Path:
    return ROOT / load_config()["paths"][key]


MANIFEST_PATH = ROOT / "data_manifest.json"

# --------------------------------------------------------------------------------------
# Column layout of the Arbin MITS_PRO export
# --------------------------------------------------------------------------------------
COLUMNS = [
    "Data_Point", "Test_Time(s)", "Date_Time", "Step_Time(s)", "Step_Index", "Cycle_Index",
    "Current(A)", "Voltage(V)", "Charge_Capacity(Ah)", "Discharge_Capacity(Ah)",
    "Charge_Energy(Wh)", "Discharge_Energy(Wh)", "dV/dt(V/s)", "Internal_Resistance(Ohm)",
    "Is_FC_Data", "AC_Impedance(Ohm)", "ACI_Phase_Angle(Deg)",
]
COL = dict(t="Test_Time(s)", date="Date_Time", st="Step_Time(s)", step="Step_Index",
           cyc="Cycle_Index", I="Current(A)", V="Voltage(V)", Qc="Charge_Capacity(Ah)",
           Qd="Discharge_Capacity(Ah)", dp="Data_Point")
CHANNELS = {
    "current": "Current(A)", "voltage": "Voltage(V)", "time": "Test_Time(s)",
    "wall_clock": "Date_Time", "step_time": "Step_Time(s)", "step_index": "Step_Index",
    "cycle_index": "Cycle_Index", "charge_capacity": "Charge_Capacity(Ah)",
    "discharge_capacity": "Discharge_Capacity(Ah)", "charge_energy": "Charge_Energy(Wh)",
    "discharge_energy": "Discharge_Energy(Wh)", "temperature": None,
}
UNITS = {"current": "A", "voltage": "V", "time": "s", "capacity": "Ah", "energy": "Wh",
         "temperature": "degC (chamber set point only; not a logged channel)"}
CHUNK_ROWS = 63990  # rows per chunked Excel sheet (Channel_x-xxx_1, _2, _3)

TEMPERATURE_NOTE = ("Chamber set point taken from the file name / Info-sheet test name. "
                    "No temperature channel exists in any export (the Info sheet reports "
                    "Temp = 0 auxiliary channels).")

# --------------------------------------------------------------------------------------
# Catalog
# --------------------------------------------------------------------------------------
_DYN_DATES = {  # (T, profile) -> {start_soc_label: file date prefix}
    (0, "DST"): {50: "02_24_2016", 80: "02_24_2016"},
    (0, "FUDS"): {50: "02_25_2016", 80: "02_25_2016"},
    (0, "US06"): {50: "02_26_2016", 80: "02_26_2016"},
    (0, "BJDST"): {50: "02_29_2016", 80: "02_27_2016"},
    (25, "DST"): {50: "11_05_2015", 80: "11_05_2015"},
    (25, "FUDS"): {50: "11_09_2015", 80: "11_06_2015"},
    (25, "US06"): {50: "11_11_2015", 80: "11_11_2015"},
    (25, "BJDST"): {50: "11_13_2015", 80: "11_12_2015"},
    (45, "DST"): {50: "12_11_2015", 80: "12_11_2015"},
    (45, "FUDS"): {50: "12_15_2015", 80: "12_15_2015"},
    (45, "US06"): {50: "12_16_2015", 80: "12_16_2015"},
    (45, "BJDST"): {50: "12_17_2015", 80: "12_17_2015"},
}
_OCV_FILES = {  # (cell, T) -> (zip stem, workbook name)
    (1, 0): ("SP1_0C_IC_OCV_02_26_2016", "02_26_2016_SP20-1_0C_incrementalOCV.xls"),
    (1, 25): ("SP1_25C_IC_OCV_12_2_2015", "12_2_2015_Incremental OCV test_SP20-1.xlsx"),
    (1, 45): ("SP1_45C_IC_OCV_12_09_2015", "12_09_2015_Incremental OCV test_SP20-1.xlsx"),
    (3, 0): ("SP3_0C_IC_OCV_03_09_2016", "03_09_2016_SP20-3_0C_incrementalOCV.xls"),
    (3, 25): ("SP3_25C_IC_OCV_12_2_2015", "12_2_2015_Incremental OCV test_SP20-3.xlsx"),
    (3, 45): ("SP3_45C_IC_OCV_12_09_2015", "12_09_2015_Incremental OCV test_SP20-3.xlsx"),
}
_INITCAP_FILES = {
    1: ("SP1_Initial capacity_10_16_2015", "10_16_2015_Initial capacity_SP20-1.xlsx"),
    2: ("SP2_Initial_capacity_10_16_2015", "10_16_2015_Initial capacity_SP20-2.xls"),
    3: ("SP3_Initial capacity_10_16_2015", "10_16_2015_Initial capacity_SP20-3.xls"),
}


def _csv_name(workbook: str) -> str:
    """Processed CSV name: same sanitisation as the original conversion (scratch/convert.py)."""
    return re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(workbook)[0]) + ".csv"


def _split_map(cfg: dict) -> dict:
    names = {"ocv_and_relaxation": "ocv_relaxation", "capacity": "capacity",
             "identification_dynamic": "identification", "validation_dynamic": "validation",
             "test_dynamic": "test"}
    out = {}
    for key, ids in cfg["splits"].items():
        for lid in ids:
            if lid in out:
                raise ValueError(f"logical id {lid} assigned to two splits")
            out[lid] = names.get(key, key)
    return out


def _build_catalog() -> dict:
    cfg = load_config()
    splits = _split_map(cfg)
    cat = {}

    def add(lid, cell, T, ttype, profile, soc, zstem, folder, wb):
        cat[lid] = dict(
            logical_id=lid, cell=f"SP20-{cell}", cell_short=f"SP{cell}", temperature_C=T,
            test_type=ttype, profile=profile, start_soc_label=soc,
            source_zip=f"{zstem}.zip", source_folder=folder, source_workbook=wb,
            source_workbook_path=str(_path("data_raw") / folder / wb),
            processed_csv=str(_path("data_processed") / _csv_name(wb)),
            split=splits.get(lid, "unassigned"),
        )

    for (cell, T), (zstem, wb) in _OCV_FILES.items():
        add(f"SP{cell}_IC_OCV_{T}C", cell, T, "incremental_ocv", None, None, zstem, zstem, wb)
    for cell, (zstem, wb) in _INITCAP_FILES.items():
        add(f"SP{cell}_INITCAP", cell, 25, "initial_capacity", None, None, zstem, zstem, wb)
    for (T, prof), dates in _DYN_DATES.items():
        folder = f"SP2_{T}C_{prof}"
        for soc, date in dates.items():
            tag = f"_{T}C" if T != 25 else ""
            wb = f"{date}_SP20-2{tag}_{prof}_{soc}SOC.xls"
            add(f"SP2_{T}C_{prof}_{soc}SOC", 2, T, "dynamic", prof, soc, folder, folder, wb)
    return cat


CATALOG: dict = _build_catalog()
LOGICAL_IDS = list(CATALOG)


def ids_by(**kw) -> list[str]:
    """Logical ids whose catalog entry matches all keyword filters, e.g. ids_by(test_type='dynamic')."""
    return [k for k, v in CATALOG.items() if all(v.get(a) == b for a, b in kw.items())]


# --------------------------------------------------------------------------------------
# Raw workbook conversion
# --------------------------------------------------------------------------------------
def md5sum(path: str | Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def _chunk_key(name: str):
    m = re.match(r"^(.*?)(?:_(\d+))?$", name)
    return (m.group(1), int(m.group(2)) if m.group(2) else 0)


def _drop_chunk_duplicates(df: pd.DataFrame) -> tuple[pd.DataFrame, list[int]]:
    """Drop rows that are exact repeats of the previous row (the last row of a chunked sheet is
    repeated as the first row of the next sheet).  Returns the cleaned frame and dropped positions."""
    if len(df) < 2:
        return df.reset_index(drop=True), []
    if COL["dp"] not in df.columns or COL["t"] not in df.columns:
        # review fix: a CSV without Data_Point / Test_Time(s) used to escape load_raw as a bare KeyError
        # before verify_file could report it; leave the frame untouched so verify_file raises
        # DataVerificationError('all_17_columns_present')
        return df.reset_index(drop=True), []
    same_dp = df[COL["dp"]].to_numpy()[1:] == df[COL["dp"]].to_numpy()[:-1]
    same_t = df[COL["t"]].to_numpy()[1:] == df[COL["t"]].to_numpy()[:-1]
    cand = np.where(same_dp & same_t)[0] + 1
    drop = [int(i) for i in cand if df.iloc[i].equals(df.iloc[i - 1])]
    if drop:
        df = df.drop(index=df.index[drop])
    return df.reset_index(drop=True), drop


def read_workbook(path: str | Path) -> tuple[pd.DataFrame, dict]:
    """Read one Arbin workbook: concatenate its chunked data sheets in order, drop the repeated
    chunk-boundary rows, and collect metadata (sheets, rows per sheet, Info-sheet text)."""
    path = Path(path)
    xl = pd.ExcelFile(path)
    sheets = xl.sheet_names
    data_sheets = sorted([s for s in sheets if s.startswith("Channel")], key=_chunk_key)
    if not data_sheets:  # SP1 initial-capacity .xlsx: Sheet1 holds the data, Sheet2/3 are empty
        data_sheets = [s for s in sheets if s.startswith("Sheet")]
    parts, rows_per_sheet = [], {}
    for s in data_sheets:
        d = xl.parse(s)
        if d.shape[1] < 5 or len(d) == 0:
            rows_per_sheet[s] = int(len(d))
            continue
        rows_per_sheet[s] = int(len(d))
        parts.append(d)
    raw = pd.concat(parts, ignore_index=True)
    missing = [c for c in COLUMNS if c not in raw.columns]
    if missing:
        raise ValueError(f"{path.name}: missing columns {missing}")
    raw = raw[COLUMNS]
    df, dropped = _drop_chunk_duplicates(raw)
    info_rows, info_test_name, info_channel, info_schedule, info_start = [], None, None, None, None
    channels_listed: list[str] = []
    # the channel of THIS workbook is encoded in its data-sheet name (Channel_1-005_1 -> "1-005");
    # the Info sheet lists every channel of the multi-channel test (e.g. 1-005 and 1-006), so the
    # channel row is selected by matching the data-sheet name, not by position.
    m_sheet = re.match(r"^Channel_(\d-\d{3})", data_sheets[0]) if data_sheets else None
    sheet_channel = m_sheet.group(1) if m_sheet else None
    if "Info" in sheets:
        inf = xl.parse("Info", header=None)
        for row in inf.values.tolist():
            cells = [str(v).strip() for v in row if str(v) != "nan"]
            if cells:
                info_rows.append(cells)
        if len(info_rows) > 1:
            info_test_name = info_rows[1][0]
        chan_rows = [r for r in info_rows if len(r) >= 3 and re.match(r"^\d-\d{3}$", r[0])]
        channels_listed = [r[0] for r in chan_rows]
        pick = [r for r in chan_rows if r[0] == sheet_channel] or chan_rows[:1]
        if pick:
            info_channel, info_start, info_schedule = pick[0][0], pick[0][1], pick[0][2]
    meta = dict(
        workbook=path.name, sheets=sheets, data_sheets=data_sheets, rows_per_sheet=rows_per_sheet,
        n_rows_raw=int(len(raw)), n_rows=int(len(df)), chunk_duplicate_rows_dropped=dropped,
        info_test_name=info_test_name, info_channel=info_channel, info_schedule_file=info_schedule,
        info_start_datetime=info_start, info_rows=info_rows,
        info_channels_listed=channels_listed, data_sheet_channel=sheet_channel,
    )
    return df, meta


_DTYPES = {c: "float64" for c in COLUMNS}
_DTYPES.update({"Data_Point": "int64", "Step_Index": "int64", "Cycle_Index": "int64",
                "Date_Time": "str"})


def _read_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=_DTYPES)
    df, _ = _drop_chunk_duplicates(df)  # idempotent even for CSVs written before the fix
    return df


def _manifest() -> dict | None:
    if MANIFEST_PATH.exists():
        with open(MANIFEST_PATH, "r", encoding="utf-8") as fh:
            return json.load(fh)
    return None


def load_raw(logical_id: str, rebuild: bool = False) -> pd.DataFrame:
    """Load the processed CSV of a logical id; rebuild it from the raw workbook when missing."""
    ent = CATALOG[logical_id]
    csv = Path(ent["processed_csv"])
    if rebuild or not csv.exists():
        wb = Path(ent["source_workbook_path"])
        if not wb.exists():
            raise FileNotFoundError(f"{logical_id}: neither {csv} nor {wb} exists")
        df, _ = read_workbook(wb)
        csv.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(csv, index=False)
        return df
    return _read_csv(csv)


# --------------------------------------------------------------------------------------
# Verification
# --------------------------------------------------------------------------------------
class DataVerificationError(RuntimeError):
    pass


EXPECTED_STEPS = {
    "dynamic": dict(required={1, 2, 3, 4, 5, 6, 7, 8}, allowed=set(range(1, 9))),
    "initial_capacity": dict(required=set(range(1, 13)), allowed=set(range(1, 13))),
    "incremental_ocv": dict(required={1, 2, 3, 4, 5, 6, 9, 10}, allowed=set(range(1, 17))),
}


def sign_convention_check(df: pd.DataFrame, thresh: float = 0.05) -> dict:
    """Correlate the sign of Current(A) with increments of the Arbin capacity columns."""
    I = df[COL["I"]].to_numpy()
    Im = 0.5 * (I[1:] + I[:-1])
    dQc = np.diff(df[COL["Qc"]].to_numpy())
    dQd = np.diff(df[COL["Qd"]].to_numpy())
    pos, neg = Im > thresh, Im < -thresh
    fc = float((dQc[pos] > 0).mean()) if pos.any() else float("nan")
    fd = float((dQd[neg] > 0).mean()) if neg.any() else float("nan")
    fc_wrong = float((dQc[neg] > 0).mean()) if neg.any() else float("nan")
    fd_wrong = float((dQd[pos] > 0).mean()) if pos.any() else float("nan")
    corr = float(np.corrcoef(np.sign(Im[pos | neg]), (dQc - dQd)[pos | neg])[0, 1]) if (pos | neg).sum() > 2 else float("nan")
    ok = (fc > 0.99) and (fd > 0.99)
    return dict(statement="Current(A) > 0 = charge (Charge_Capacity increases), "
                          "Current(A) < 0 = discharge (Discharge_Capacity increases)",
                n_samples_I_positive=int(pos.sum()), n_samples_I_negative=int(neg.sum()),
                frac_charge_capacity_increasing_when_I_positive=fc,
                frac_discharge_capacity_increasing_when_I_negative=fd,
                frac_discharge_capacity_increasing_when_I_positive=fd_wrong,
                frac_charge_capacity_increasing_when_I_negative=fc_wrong,
                corr_sign_I_vs_net_capacity_increment=corr, threshold_A=thresh, verified=bool(ok))


def verify_file(logical_id: str, df: pd.DataFrame | None = None, raise_on_fail: bool = True) -> dict:
    """Integrity checks that MUST pass before any estimation.  Returns a dict of checks; raises
    DataVerificationError (listing every failed check) unless raise_on_fail is False."""
    ent = CATALOG[logical_id]
    checks = {}
    wb = Path(ent["source_workbook_path"])
    csv = Path(ent["processed_csv"])
    checks["workbook_exists"] = wb.exists()
    checks["processed_csv_exists"] = csv.exists()
    man = _manifest()
    if man is None or logical_id not in man.get("files", {}):
        checks["md5_matches_manifest"] = False
        checks["md5_note"] = "data_manifest.json missing or has no entry; run scripts/00_convert_raw.py"
    else:
        m = man["files"][logical_id]
        checks["md5_source"] = md5sum(wb) if wb.exists() else None
        checks["md5_matches_manifest"] = checks["md5_source"] == m["source_md5"]
        if csv.exists():
            checks["csv_md5_matches_manifest"] = md5sum(csv) == m["csv_md5"]
    if df is None:
        df = load_raw(logical_id)
    missing_cols = [c for c in COLUMNS if c not in df.columns]
    checks["all_17_columns_present"] = not missing_cols
    checks["missing_columns"] = missing_cols
    if missing_cols:
        # review fix: a frame with a missing column used to escape as a KeyError from the checks
        # below; it is an integrity failure and must surface as DataVerificationError
        checks["passed"] = False
        checks["failed_checks"] = ["all_17_columns_present"]
        if raise_on_fail:
            raise DataVerificationError(f"{logical_id}: failed checks ['all_17_columns_present']; missing {missing_cols}")
        return checks
    I = df[COL["I"]].to_numpy(); V = df[COL["V"]].to_numpy(); t = df[COL["t"]].to_numpy()
    checks["current_within_5A"] = bool(np.nanmax(np.abs(I)) <= 5.0)
    checks["I_abs_max_A"] = float(np.nanmax(np.abs(I)))
    checks["voltage_within_2p3_4p4"] = bool(np.nanmin(V) >= 2.3 and np.nanmax(V) <= 4.4)
    checks["V_min_V"], checks["V_max_V"] = float(np.nanmin(V)), float(np.nanmax(V))
    checks["no_missing_values"] = bool(df[COLUMNS].isna().sum().sum() == 0)
    sc = sign_convention_check(df)
    checks["sign_convention_verified"] = sc["verified"]
    checks["sign_convention"] = sc
    dt = np.diff(t)
    checks["test_time_monotone_nondecreasing"] = bool(np.all(dt >= 0))
    checks["n_repeated_timestamps"] = int((dt == 0).sum())
    checks["data_point_strictly_increasing"] = bool(np.all(np.diff(df[COL["dp"]].to_numpy()) > 0))
    steps = set(int(s) for s in df[COL["step"]].unique())
    exp = EXPECTED_STEPS[ent["test_type"]]
    checks["step_indices"] = sorted(steps)
    checks["step_index_set_as_expected"] = exp["required"].issubset(steps) and steps.issubset(exp["allowed"])
    checks["n_rows"] = int(len(df))
    must = ["workbook_exists", "processed_csv_exists", "md5_matches_manifest", "all_17_columns_present",
            "current_within_5A", "voltage_within_2p3_4p4", "no_missing_values", "sign_convention_verified",
            "test_time_monotone_nondecreasing", "step_index_set_as_expected",
            # review fix (hardening): Data_Point monotonicity was computed but not enforced, so a frame with
            # repeated/reordered rows (e.g. a chunk-boundary duplicate that escaped de-duplication) passed
            "data_point_strictly_increasing"]
    if "csv_md5_matches_manifest" in checks:
        # review fix: the CSV is what load_raw actually reads, so a modified CSV must fail too
        must.append("csv_md5_matches_manifest")
    failed = [k for k in must if not checks.get(k, False)]
    checks["passed"] = not failed
    checks["failed_checks"] = failed
    if failed and raise_on_fail:
        raise DataVerificationError(f"{logical_id}: failed checks {failed}; details: "
                                    + json.dumps({k: checks.get(k) for k in failed + ['md5_note'] if k in checks}, default=str))
    return checks


# --------------------------------------------------------------------------------------
# Segmentation
# --------------------------------------------------------------------------------------
def _classify(step: int, test_type: str, I_mean: float, I_min: float, I_max: float, V_max: float, n: int) -> str:
    if test_type == "dynamic" and step == 7:
        return "dynamic"
    if test_type == "dynamic" and step == 8:
        return "logger_artifact"
    if abs(I_mean) < 0.005 and (I_max - I_min) < 0.01:
        return "rest"
    if I_mean > 0:
        if n > 1 and (I_max - I_min) > 0.03 and V_max > 4.19 and I_min < 0.5:
            return "cv"
        return "charge"
    return "discharge"


def _trapz_net_Ah(t: np.ndarray, I: np.ndarray) -> float:
    return float(np.trapezoid(I, t) / 3600.0) if len(t) > 1 else 0.0


def segments(logical_id: str, df: pd.DataFrame | None = None) -> pd.DataFrame:
    """One row per (Cycle_Index, Step_Index) group, in order of first appearance."""
    ent = CATALOG[logical_id]
    if df is None:
        df = load_raw(logical_id)
    ttype = ent["test_type"]
    t = df[COL["t"]].to_numpy(); I = df[COL["I"]].to_numpy(); V = df[COL["V"]].to_numpy()
    Qc = df[COL["Qc"]].to_numpy(); Qd = df[COL["Qd"]].to_numpy()
    key = df[COL["cyc"]].to_numpy() * 1000 + df[COL["step"]].to_numpy()
    codes, uniq = pd.factorize(key, sort=False)
    rows = []
    for g, k in enumerate(uniq):
        idx = np.where(codes == g)[0]
        tg, Ig, Vg = t[idx], I[idx], V[idx]
        n = len(idx)
        dt = np.diff(tg) if n > 1 else np.array([])
        i0, i1 = int(idx[0]), int(idx[-1])
        ib = i0 - 1 if i0 > 0 else i0  # base row for Arbin capacity deltas
        I_mean, I_min, I_max = float(Ig.mean()), float(Ig.min()), float(Ig.max())
        typ = _classify(int(k % 1000), ttype, I_mean, I_min, I_max, float(Vg.max()), n)
        # our own integration over the segment, including the link from the previous sample
        if i0 > 0 and typ not in ("logger_artifact", "rest"):
            tt = np.concatenate([[t[ib]], tg]); II = np.concatenate([[I[ib]], Ig])
        else:
            tt, II = tg, Ig
        Ah_net = _trapz_net_Ah(tt, II)
        row = dict(
            logical_id=logical_id, cycle=int(k // 1000), step=int(k % 1000), type=typ, n=n,
            i_start=i0, i_end=i1, t_start=float(tg[0]), t_end=float(tg[-1]), duration_s=float(tg[-1] - tg[0]),
            I_mean=I_mean, I_min=I_min, I_max=I_max,
            V_start=float(Vg[0]), V_end=float(Vg[-1]), V_min=float(Vg.min()), V_max=float(Vg.max()),
            dV=float(Vg[-1] - Vg[0]),
            Ah_charge_arbin=float(Qc[i1] - Qc[ib]), Ah_discharge_arbin=float(Qd[i1] - Qd[ib]),
            Ah_net_trapz=Ah_net, Ah_throughput_trapz=float(np.trapezoid(np.abs(II), tt) / 3600.0) if len(tt) > 1 else 0.0,
            dt_median=float(np.median(dt)) if n > 1 else np.nan, dt_min=float(dt.min()) if n > 1 else np.nan,
            dt_max=float(dt.max()) if n > 1 else np.nan,
            dt_p5=float(np.percentile(dt, 5)) if n > 1 else np.nan, dt_p95=float(np.percentile(dt, 95)) if n > 1 else np.nan,
            n_dt_gt_3x_median=int((dt > 3 * np.median(dt)).sum()) if n > 1 else 0,
            n_dt_nonpositive=int((dt <= 0).sum()) if n > 1 else 0,
        )
        rows.append(row)
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------------------
# Dynamic profiles
# --------------------------------------------------------------------------------------
def _dt_stats(dt: np.ndarray) -> dict:
    if len(dt) == 0:
        return dict(median=np.nan, min=np.nan, max=np.nan, p5=np.nan, p95=np.nan, n=0)
    return dict(median=float(np.median(dt)), min=float(dt.min()), max=float(dt.max()),
                p5=float(np.percentile(dt, 5)), p95=float(np.percentile(dt, 95)), n=int(len(dt)))


def current_levels(I: np.ndarray, decimals: int = 2, min_frac: float = 0.002) -> list[dict]:
    """Histogram of current levels (rounded), for the dynamic-profile inventory."""
    r = np.round(I, decimals)
    vals, cnt = np.unique(r, return_counts=True)
    order = np.argsort(-cnt)
    out = []
    for j in order:
        if cnt[j] / len(I) >= min_frac:
            out.append(dict(level_A=float(vals[j]), n=int(cnt[j]), frac=float(cnt[j] / len(I))))
    return out


def get_dynamic_profile(logical_id: str, h: float | None = None, df: pd.DataFrame | None = None) -> dict:
    """Step-7 dynamic profile on a uniform grid of step h (default config resample_h_s).

    Returns dict(t, I, V) on the uniform grid (t re-based to 0 at the first step-7 sample,
    V linearly interpolated, I charge-conserving: I[k] is the mean of the piecewise-linear
    irregular current over [t_k, t_k + h], so that cumsum(I[:-1]) * h / 3600 equals the trapezoidal
    net Ah of the irregular record at every grid point, i.e. the same integration that defines
    reference_soc), the irregular arrays (t_raw, I_raw, V_raw, Qc_raw, Qd_raw) and metadata.

    Review fix: the previous sample-and-hold (I[k] = last irregular sample <= t_k) double-counted
    ~1.5 % of the samples because the logger interval (~1.0155 s) is longer than h = 1 s; the
    aliasing with the profile period left a cumulative-charge error of up to 21 A s (0.3 % SOC,
    0.63 % of the net Ah on SP2_0C_DST_50SOC).  Throughput is preserved to 0.1 % on every grid
    interval without a current sign reversal; inside a reversal interval the throughput of a
    sampled signal is not defined better than the sampling interval (meta reports both).

    Review finding (not changed, documented): a grid interval straddling a charge/discharge reversal
    carries the mean current, so the GROSS charge-direction Ah on the grid is several % lower than on
    the raw record (e.g. 0.242 vs 0.263 Ah on SP2_25C_DST_80SOC) and the gross discharge Ah ~1 % lower;
    the net Ah is conserved to < 0.01 %.  meta['throughput'] reports raw/grid charge and discharge Ah."""
    cfg = load_config()["dataset"]
    ent = CATALOG[logical_id]
    if ent["test_type"] != "dynamic":
        raise ValueError(f"{logical_id} is not a dynamic-profile file")
    if h is None:
        h = float(cfg["resample_h_s"])
    if df is None:
        df = load_raw(logical_id)
    step = df[COL["step"]].to_numpy()
    s7, s8 = int(cfg["dynamic_profile_step_index"]), int(cfg["logger_step_index_to_drop"])
    m7 = step == s7
    d7 = df.loc[m7]
    t = d7[COL["t"]].to_numpy(); I = d7[COL["I"]].to_numpy(); V = d7[COL["V"]].to_numpy()
    Qc = d7[COL["Qc"]].to_numpy(); Qd = d7[COL["Qd"]].to_numpy()
    # step-8 logger rows: check they coincide with step-7 timestamps and carry zero current
    m8 = step == s8
    t8 = df.loc[m8, COL["t"]].to_numpy()
    if len(t8):
        pos = np.searchsorted(t, t8)
        gap = np.minimum(np.abs(t[np.clip(pos, 0, len(t) - 1)] - t8), np.abs(t[np.clip(pos - 1, 0, len(t) - 1)] - t8))
        logger = dict(n_dropped=int(m8.sum()), max_gap_to_step7_sample_s=float(gap.max()),
                      max_abs_current_A=float(np.abs(df.loc[m8, COL["I"]]).max()))
    else:
        logger = dict(n_dropped=0, max_gap_to_step7_sample_s=None, max_abs_current_A=None)
    # de-duplicate timestamps (keep first)
    _, first = np.unique(t, return_index=True)
    first = np.sort(first)
    n_dup = int(len(t) - len(first))
    t, I, V, Qc, Qd = t[first], I[first], V[first], Qc[first], Qd[first]
    t0 = float(t[0]); tr = t - t0
    dt = np.diff(tr)
    tu = np.arange(0.0, tr[-1] + 1e-9, h)
    Vu = np.interp(tu, tr, V)
    # charge-conserving current: Q(t) = trapezoidal cumulative charge of the irregular record
    # (piecewise-linear I), I[k] = (Q(t_k + h) - Q(t_k)) / h; the last grid point holds the last sample
    q_raw = np.concatenate([[0.0], cumulative_trapezoid(I, tr)])  # A s
    q_grid = np.interp(tu, tr, q_raw)
    Iu = np.empty_like(tu)
    Iu[:-1] = np.diff(q_grid) / h
    Iu[-1] = I[-1]
    # throughput bookkeeping: per-interval |charge| on both grids and on the intervals without a sign reversal
    dq_raw = np.diff(q_raw); dq_grid = np.diff(q_grid)
    rev_raw = np.sign(I[1:]) * np.sign(I[:-1]) < 0
    # a grid interval is 'reversal-free' when no raw sign reversal falls inside it
    t_rev = tr[1:][rev_raw]
    rev_grid = np.zeros(len(tu) - 1, bool)
    if len(t_rev):
        k = np.clip(np.searchsorted(tu, t_rev, side="right") - 1, 0, len(tu) - 2)
        rev_grid[k] = True
        k2 = np.clip(np.searchsorted(tu, tr[:-1][rev_raw], side="right") - 1, 0, len(tu) - 2)
        rev_grid[k2] = True
    throughput = dict(raw_trapz_abs_I_Ah=float(np.trapezoid(np.abs(I), tr) / 3600.0),
                      raw_sum_abs_interval_charge_Ah=float(np.abs(dq_raw).sum() / 3600.0),
                      grid_sum_abs_interval_charge_Ah=float(np.abs(dq_grid).sum() / 3600.0),
                      n_sign_reversals_raw=int(rev_raw.sum()), n_grid_intervals_with_reversal=int(rev_grid.sum()),
                      grid_reversal_free_Ah=float(np.abs(dq_grid[~rev_grid]).sum() / 3600.0),
                      raw_reversal_free_Ah=float(np.abs(np.diff(np.interp(tu, tr, np.concatenate([[0.0], cumulative_trapezoid(np.abs(I), tr)])))[~rev_grid]).sum() / 3600.0),
                      raw_charge_Ah_trapz=float(np.trapezoid(np.clip(I, 0, None), tr) / 3600.0),
                      raw_discharge_Ah_trapz=float(np.trapezoid(np.clip(-I, 0, None), tr) / 3600.0),
                      grid_charge_Ah=float(np.clip(Iu[:-1], 0, None).sum() * h / 3600.0),
                      grid_discharge_Ah=float(np.clip(-Iu[:-1], 0, None).sum() * h / 3600.0),
                      note="throughput inside an interval containing a current sign reversal is not defined better than the "
                           "sampling interval; net charge is conserved exactly at every grid point. Review finding: because a "
                           "grid interval that straddles a charge/discharge reversal carries the MEAN current, the gross charge "
                           "(regen) Ah on the grid is lower than on the raw record by several % (and the gross discharge Ah by "
                           "~1 %); only net Ah (the quantity entering SOC with eta = 1) is conserved. Compare grid_charge_Ah / "
                           "raw_charge_Ah_trapz before using a charge-direction-dependent efficiency (eta != 1) on the grid.")
    seg = segments(logical_id, df)
    s5 = seg[(seg.step == 5)].iloc[0]; s6 = seg[(seg.step == 6)].iloc[0]; s3 = seg[(seg.step == 3)].iloc[0]
    s2 = seg[(seg.step == 2)].iloc[0]
    meta = dict(
        logical_id=logical_id, h_s=h, n_raw_step7=int(m7.sum()), n_duplicate_timestamps_removed=n_dup,
        n_uniform=int(len(tu)), logger_rows=logger, dt_observed=_dt_stats(dt),
        t0_abs_s=t0, profile_duration_s=float(tr[-1]), V_start=float(V[0]), V_end=float(V[-1]),
        V_min=float(V.min()), V_max=float(V.max()), I_min=float(I.min()), I_max=float(I.max()),
        net_Ah_arbin=float((Qc[-1] - Qc[0]) - (Qd[-1] - Qd[0])), net_Ah_trapz=_trapz_net_Ah(tr, I),
        net_Ah_grid=float(np.sum(Iu[:-1]) * h / 3600.0), throughput=throughput,
        resampling="V: linear interpolation; I: charge-conserving mean of the piecewise-linear irregular current over each grid interval",
        Ah_charge_arbin=float(Qc[-1] - Qc[0]), Ah_discharge_arbin=float(Qd[-1] - Qd[0]),
        current_levels=current_levels(I),
        rest_before_profile=dict(step=6, duration_s=float(s6.duration_s), V_start=float(s6.V_start),
                                 V_end=float(s6.V_end), dV=float(s6.dV), n=int(s6.n), dt_median=float(s6.dt_median)),
        pre_profile_discharge=dict(step=5, Ah_arbin=float(s5.Ah_discharge_arbin), Ah_trapz=float(-s5.Ah_net_trapz),
                                   I_mean=float(s5.I_mean), duration_s=float(s5.duration_s),
                                   V_start=float(s5.V_start), V_end=float(s5.V_end)),
        pre_profile_charge=dict(cc_step=2, cv_step=3, Ah_cc_arbin=float(s2.Ah_charge_arbin),
                                Ah_cv_arbin=float(s3.Ah_charge_arbin), cv_end_current_A=float(s3.I_min),
                                cv_end_voltage_V=float(s3.V_end), cc_start_voltage_V=float(s2.V_start)),
    )
    return dict(t=tu, I=Iu, V=Vu, t_raw=tr, I_raw=I, V_raw=V, Qc_raw=Qc, Qd_raw=Qd, meta=meta)


# --------------------------------------------------------------------------------------
# Reference SOC
# --------------------------------------------------------------------------------------
def _q_ref_default(ent: dict) -> tuple[float, float | None, str]:
    """(Q_ref [Ah], u_Q [Ah] or None, provenance) for a dynamic file: the ground-truth Q_ref(T) of
    results/capacity.json (median CV-end-to-cutoff throughput over the 8 SP2 files at T)."""
    cap_path = _path("results") / "capacity.json"
    if cap_path.exists():
        with open(cap_path, "r", encoding="utf-8") as fh:
            cap = json.load(fh)
        cell = ent["cell_short"]
        T = str(ent["temperature_C"])
        e = cap.get("Q_ref_T_SP2", {}).get(T)
        if cell == "SP2" and e is not None and "u_Q_Ah" in e:
            return (float(e["Q_ref_Ah"]), float(e["u_Q_Ah"]),
                    f"results/capacity.json Q_ref_T_SP2[{T}] ({cap.get('method')}): {e['arithmetic']}")
    q = float(load_config()["dataset"]["cell_nominal_capacity_Ah"])
    warnings.warn(f"results/capacity.json (current method) not available for {ent['logical_id']}; using nominal {q} Ah")
    return q, None, f"nominal capacity {q} Ah from config (results/capacity.json not available)"


def reference_soc(logical_id: str, Q_ref_Ah: float | None = None, eta: float | None = None,
                  h: float | None = None, q_ref_rel_unc: float | None = None, current_offset_A: float | None = None,
                  df: pd.DataFrame | None = None, profile: dict | None = None) -> dict:
    """Reference (ground-truth) SOC on the uniform profile grid by trapezoidal Coulomb counting
    anchored at SOC = 1 at the end of the CC/CV charge (last sample of step 3), through the 2 h rest
    (step 4), the pre-profile 1 A discharge (step 5), the 2 h rest (step 6) and the profile (step 7):

        q(t)   = (1/3600) trapz_{t_a}^{t} I_eff dtau            [Ah, charge > 0; I_eff = eta I for I > 0]
        SOC(t) = 1 + q(t) / Q_ref

    Q_ref defaults to Q_ref(T) of results/capacity.json (median CV-end-to-cutoff throughput of the 8
    SP2 dynamic files at T).  It is a ground-truth definition only and must NEVER be passed to an
    estimator (estimators use Q_id(T), capacity.json 'Q_id_T_SP2').

    Uncertainty band (first-order, linear sum; SOC units):

        band(t) = (|q(t)| / Q_ref) * (u_Q / Q_ref)  +  I_off * (t - t_a) / (3600 * Q_ref)

    first term: relative capacity uncertainty u_Q/Q_ref applied to the removed charge (dSOC/dQ_ref =
    -q/Q_ref^2); u_Q = half-range of the throughput over the 8 files (capacity.json), so q_ref_rel_unc
    defaults to u_Q(T)/Q_ref(T) (config reference_soc_band.fallback_q_ref_rel_unc if unavailable or if
    Q_ref_Ah is given without q_ref_rel_unc).  Second term: constant current-sensor offset I_off
    (default config reference_soc_band.current_offset_A = 5 mA) integrated over the time elapsed since
    the anchor t_a (includes the rests and the pre-profile discharge).  soc_lo/soc_hi = soc -/+ band;
    the RSS combination is returned as unc_total_rss."""
    ent = CATALOG[logical_id]
    if ent["test_type"] != "dynamic":
        raise ValueError("reference_soc is defined for dynamic-profile files only")
    cfg = load_config()["dataset"]
    if eta is None:
        eta = float(cfg["coulombic_efficiency"])
    if df is None:
        df = load_raw(logical_id)
    if profile is None:
        profile = get_dynamic_profile(logical_id, h=h, df=df)
    band_cfg = cfg.get("reference_soc_band", {})
    u_Q = None
    if Q_ref_Ah is None:
        Q_ref_Ah, u_Q, prov = _q_ref_default(ent)
    else:
        prov = "argument"
    if q_ref_rel_unc is None:
        q_ref_rel_unc = (u_Q / Q_ref_Ah) if u_Q is not None else float(band_cfg.get("fallback_q_ref_rel_unc", 0.02))
    if current_offset_A is None:
        current_offset_A = float(band_cfg.get("current_offset_A", 0.005))
    step = df[COL["step"]].to_numpy()
    t = df[COL["t"]].to_numpy(); I = df[COL["I"]].to_numpy(); V = df[COL["V"]].to_numpy()
    Qc = df[COL["Qc"]].to_numpy(); Qd = df[COL["Qd"]].to_numpy()
    ia = int(np.where(step == 3)[0][-1])  # anchor: end of CV
    keep = np.zeros(len(df), bool); keep[ia:] = True; keep &= step != int(cfg["logger_step_index_to_drop"])
    keep &= np.isin(step, [3, 4, 5, 6, 7])
    idx = np.where(keep)[0]
    ta, Ia = t[idx], I[idx]
    _, first = np.unique(ta, return_index=True); first = np.sort(first)
    ta, Ia, idx = ta[first], Ia[first], idx[first]
    Ieff = np.where(Ia > 0, eta * Ia, Ia)
    q = np.concatenate([[0.0], cumulative_trapezoid(Ieff, ta)]) / 3600.0  # Ah, signed (charge > 0)
    q_arbin = (Qc[idx] - Qc[ia]) - (Qd[idx] - Qd[ia])
    soc_a = 1.0 + q / Q_ref_Ah
    soc_arb_a = 1.0 + q_arbin / Q_ref_Ah
    tu_abs = profile["meta"]["t0_abs_s"] + profile["t"]
    soc = np.interp(tu_abs, ta, soc_a)
    soc_arb = np.interp(tu_abs, ta, soc_arb_a)
    q_u = np.interp(tu_abs, ta, q)
    # Uncertainty band (first-order propagation of  soc(t) = 1 + q(t) / Q_ref,  q in Ah):
    #   dsoc/dQ_ref = -q / Q_ref^2   ->  |dsoc| = |q| / Q_ref * (dQ_ref / Q_ref) = |q| / Q_ref * q_ref_rel_unc
    #   a constant current-sensor offset dI [A] over the elapsed time (t - t_anchor) [s] integrates to
    #   dq = dI * (t - t_anchor) / 3600 [Ah]   ->  |dsoc| = dI * (t - t_anchor) / (3600 * Q_ref)
    #   unc_total_linear = unc_Q + unc_I (worst case, both errors of the same sign);
    #   unc_total_rss    = sqrt(unc_Q^2 + unc_I^2) (independent errors).  soc_lo/soc_hi use the linear sum.
    unc_Q = np.abs(q_u) / Q_ref_Ah * q_ref_rel_unc
    unc_I = current_offset_A * (tu_abs - t[ia]) / 3600.0 / Q_ref_Ah
    unc_tot = unc_Q + unc_I
    m7 = np.isin(step[idx], [7])
    return dict(
        t=profile["t"], soc_ref=soc, soc_lo=soc - unc_tot, soc_hi=soc + unc_tot,
        unc_Q_ref=unc_Q, unc_current_offset=unc_I, unc_total_linear=unc_tot, unc_total_rss=np.sqrt(unc_Q**2 + unc_I**2),
        soc_arbin=soc_arb, net_Ah_from_full=q_u,
        Q_ref_Ah=Q_ref_Ah, Q_ref_provenance=prov, u_Q_Ah=u_Q, eta=eta, q_ref_rel_unc=q_ref_rel_unc, current_offset_A=current_offset_A,
        band_formula="band(t) = (|q(t)|/Q_ref)(u_Q/Q_ref) + I_off (t - t_anchor)/(3600 Q_ref), summed linearly",
        anchor=dict(row=ia, statement="SOC = 1 at the last sample of the CV step (Step_Index 3) at this "
                                      "chamber temperature; Coulomb counting from there through steps 4-7 "
                                      "(step-8 logger rows excluded)",
                    t_s=float(t[ia]), V=float(V[ia]), I_A=float(I[ia]), Qc_Ah=float(Qc[ia]), Qd_Ah=float(Qd[ia])),
        cross_check=dict(max_abs_diff_Ah_trapz_vs_arbin=float(np.max(np.abs(q - q_arbin))),
                         max_abs_diff_soc_trapz_vs_arbin=float(np.max(np.abs(soc_a - soc_arb_a))),
                         max_abs_diff_Ah_on_profile=float(np.max(np.abs(q[m7] - q_arbin[m7]))) if m7.any() else None),
        soc_profile_start=float(soc[0]), soc_profile_end=float(soc[-1]), soc_min=float(soc.min()),
        net_Ah_pre_profile=float(np.interp(tu_abs[0], ta, q)),
        unc_at_profile_end=dict(Q_ref=float(unc_Q[-1]), current_offset=float(unc_I[-1]), linear=float(unc_tot[-1])),
    )


# --------------------------------------------------------------------------------------
# Relaxations and OCV points (incremental-OCV files)
# --------------------------------------------------------------------------------------
def _full_anchor(seg: pd.DataFrame) -> int:
    """Row index of the 'full' anchor: last sample of the first CV segment (cycle 1)."""
    cv = seg[(seg.type == "cv") & (seg.cycle == seg.cycle.min())]
    if len(cv):
        return int(cv.iloc[0].i_end)
    ch = seg[seg.type.isin(["charge", "cv"])]
    return int(ch.iloc[0].i_end)


def own_capacity(logical_id: str, df: pd.DataFrame | None = None, seg: pd.DataFrame | None = None) -> dict:
    """Total discharged Ah after the initial full charge (Arbin column and trapezoid), with the
    end-of-last-pulse voltage that tells whether the 2.5 V cutoff terminated the discharge branch."""
    if df is None:
        df = load_raw(logical_id)
    if seg is None:
        seg = segments(logical_id, df)
    ia = _full_anchor(seg)
    Qd = df[COL["Qd"]].to_numpy(); Qc = df[COL["Qc"]].to_numpy()
    dis = seg[(seg.type == "discharge") & (seg.i_start > ia)]
    last = dis.iloc[-1]
    return dict(anchor_row=ia, anchor_t_s=float(df[COL["t"]].iloc[ia]), anchor_V=float(df[COL["V"]].iloc[ia]),
                Q_total_discharge_arbin_Ah=float(Qd[-1] - Qd[ia]),
                Q_total_discharge_trapz_Ah=float(-dis.Ah_net_trapz.sum()),
                Q_total_charge_after_anchor_arbin_Ah=float(Qc[-1] - Qc[ia]),
                n_discharge_pulses=int(len(dis)), last_discharge_end_V=float(last.V_end),
                last_discharge_cycle=int(last.cycle), last_discharge_step=int(last.step),
                cutoff_2p5V_reached=bool(last.V_end <= 2.51))


def get_relaxations(logical_id: str, df: pd.DataFrame | None = None, min_pulse_current_A: float = 0.9) -> list[dict]:
    """Rest periods that directly follow a 1 A CC pulse (charge or discharge).  Each dict has
    t (s since the last sample under current), V, the preceding pulse, the cumulative net Ah
    from the full anchor, and the SOC label based on the file's own total discharge capacity."""
    if df is None:
        df = load_raw(logical_id)
    seg = segments(logical_id, df)
    cap = own_capacity(logical_id, df, seg)
    ia, Qtot = cap["anchor_row"], cap["Q_total_discharge_arbin_Ah"]
    t = df[COL["t"]].to_numpy(); V = df[COL["V"]].to_numpy(); I = df[COL["I"]].to_numpy()
    Qc = df[COL["Qc"]].to_numpy(); Qd = df[COL["Qd"]].to_numpy()
    out = []
    for k in range(1, len(seg)):
        s, p = seg.iloc[k], seg.iloc[k - 1]
        if s.type != "rest" or p.type not in ("charge", "discharge") or p.n < 2:
            continue
        if abs(p.I_mean) < min_pulse_current_A or s.i_start <= ia:
            continue
        i0, i1 = int(s.i_start), int(s.i_end)
        t_int = float(t[int(p.i_end)])
        net_dis = float((Qd[i0] - Qd[ia]) - (Qc[i0] - Qc[ia]))
        out.append(dict(
            logical_id=logical_id, cycle=int(s.cycle), step=int(s.step), i_start=i0, i_end=i1,
            t=t[i0:i1 + 1] - t_int, V=V[i0:i1 + 1], I=I[i0:i1 + 1],
            t_interruption_abs_s=t_int, gap_last_pulse_sample_to_first_rest_sample_s=float(t[i0] - t_int),
            duration_s=float(s.duration_s), n=int(s.n), dt_median=float(s.dt_median), dt_max=float(s.dt_max),
            V_first=float(s.V_start), V_last=float(s.V_end), dV_rest=float(s.dV),
            pulse=dict(direction=p.type, step=int(p.step), cycle=int(p.cycle), Ah_arbin=float(p.Ah_charge_arbin if p.type == "charge" else p.Ah_discharge_arbin),
                       Ah_trapz=float(abs(p.Ah_net_trapz)), I_mean=float(p.I_mean), duration_s=float(p.duration_s),
                       V_start=float(p.V_start), V_end_under_load=float(p.V_end),
                       I_end_under_load=float(I[int(p.i_end)])),  # current at the sample t is measured from
            net_discharged_Ah_from_full=net_dis, Q_total_discharge_Ah=Qtot,
            soc_label=1.0 - net_dis / Qtot, soc_basis="own capacity: total Arbin Discharge_Capacity after the initial full charge of this file",
        ))
    return out


def get_ocv_points(logical_id: str, df: pd.DataFrame | None = None, min_rest_s: float = 3600.0) -> pd.DataFrame:
    """Relaxed voltage at the end of each long rest, with cumulative Ah and own-capacity SOC."""
    if df is None:
        df = load_raw(logical_id)
    seg = segments(logical_id, df)
    cap = own_capacity(logical_id, df, seg)
    ia, Qtot = cap["anchor_row"], cap["Q_total_discharge_arbin_Ah"]
    t = df[COL["t"]].to_numpy(); V = df[COL["V"]].to_numpy()
    Qc = df[COL["Qc"]].to_numpy(); Qd = df[COL["Qd"]].to_numpy()
    rows = []
    for k in range(len(seg)):
        s = seg.iloc[k]
        if s.type != "rest" or s.duration_s < min_rest_s or s.i_start < ia:
            continue
        p = seg.iloc[k - 1] if k > 0 else None
        if p is None:
            direction = "unknown"
        elif p.type == "discharge":
            direction = "discharge"
        elif p.type == "charge":
            direction = "charge"
        elif p.type == "cv":
            direction = "full_after_cv"
        else:
            direction = p.type
        i0, i1 = int(s.i_start), int(s.i_end)
        net_dis = float((Qd[i0] - Qd[ia]) - (Qc[i0] - Qc[ia]))
        tt = t[i0:i1 + 1] - t[i0]
        rows.append(dict(
            logical_id=logical_id, cycle=int(s.cycle), step=int(s.step), direction=direction,
            rest_duration_s=float(s.duration_s), n=int(s.n),
            V_first=float(s.V_start), V_1h=float(np.interp(3600.0, tt, V[i0:i1 + 1])), V_relaxed=float(s.V_end),
            dV_rest=float(s.dV), dV_last_10min=float(V[i1] - np.interp(tt[-1] - 600.0, tt, V[i0:i1 + 1])),
            net_discharged_Ah_from_full=net_dis, Q_total_discharge_Ah=Qtot, soc=1.0 - net_dis / Qtot,
            pulse_Ah=float(abs(p.Ah_net_trapz)) if p is not None else np.nan,
            pulse_I_mean=float(p.I_mean) if p is not None else np.nan,
        ))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------------------
# Capacity
# --------------------------------------------------------------------------------------
def cv_to_cutoff_throughput(logical_id: str, df: pd.DataFrame | None = None) -> dict:
    """Net charge removed from the end of the CV step (last sample of step 3, SOC = 1) to the end of the
    dynamic profile (last sample of step 7, 2.5 V cutoff) of one SP2 dynamic file, in Ah (> 0 = removed).

    Q_arbin = -[(Qc[end] - Qc[anchor]) - (Qd[end] - Qd[anchor])] from the Arbin cumulative columns;
    Q_trapz = -trapz(Current(A), Test_Time(s)) / 3600 over steps 3-7 from the anchor, step-8 logger rows
    and duplicate timestamps (keep first) removed, i.e. the same integration as reference_soc."""
    ent = CATALOG[logical_id]
    if ent["test_type"] != "dynamic":
        raise ValueError(f"{logical_id} is not a dynamic-profile file")
    cfg = load_config()["dataset"]
    rc = cfg["reference_capacity"]
    if df is None:
        df = load_raw(logical_id)
    step = df[COL["step"]].to_numpy()
    t = df[COL["t"]].to_numpy(); I = df[COL["I"]].to_numpy(); V = df[COL["V"]].to_numpy()
    Qc = df[COL["Qc"]].to_numpy(); Qd = df[COL["Qd"]].to_numpy()
    s_from, s_to = int(rc["throughput_from_step"]), int(rc["throughput_to_step"])
    ia = int(np.where(step == s_from)[0][-1])
    ie = int(np.where(step == s_to)[0][-1])
    rows = np.arange(len(df))
    keep = (rows >= ia) & (rows <= ie) & (step != int(cfg["logger_step_index_to_drop"]))
    tt, II = t[keep], I[keep]
    _, first = np.unique(tt, return_index=True)
    first = np.sort(first)
    q_arb = -float((Qc[ie] - Qc[ia]) - (Qd[ie] - Qd[ia]))
    q_tr = -float(np.trapezoid(II[first], tt[first]) / 3600.0)
    cut = float(rc["cutoff_V"]) + float(rc["cutoff_tolerance_V"])
    return dict(logical_id=logical_id, temperature_C=ent["temperature_C"], profile=ent["profile"],
                start_soc_label=ent["start_soc_label"], split=ent["split"],
                anchor_row=ia, end_row=ie, t_anchor_s=float(t[ia]), t_end_s=float(t[ie]),
                V_anchor=float(V[ia]), V_end=float(V[ie]), I_end_A=float(I[ie]), ends_at_cutoff=bool(V[ie] <= cut),
                n_rows_after_end=int(len(df) - 1 - ie),
                Q_arbin_Ah=q_arb, Q_trapz_Ah=q_tr, arbin_minus_trapz_Ah=q_arb - q_tr)


def compute_capacity(dfs: dict | None = None, include_dynamic: bool = True) -> dict:
    """Measured capacities, the ground-truth reference capacity Q_ref(T) and the identification
    capacity Q_id(T) for SP2, arithmetic included.

    Q_ref(T) = median over the 8 SP2 dynamic files at T of the net charge throughput from the last
    sample of the CV step (step 3, SOC = 1) to the last sample of the profile (step 7, 2.5 V cutoff),
    from the Arbin Charge_/Discharge_Capacity columns (trapezoid of Current(A) as cross-check);
    u_Q(T) = half-range over the same 8 files.  Q_ref is a GROUND-TRUTH DEFINITION ONLY (it uses the
    validation and test files) and must never be given to an estimator; estimators may only use
    Q_id(T) = throughput of SP2_<T>C_DST_80SOC (identification file).  Also returned: the 1 A
    capacities at 25 C of SP1/SP2/SP3 (initial-capacity tests, SP2 unlogged-pause note) and the
    incremental-OCV totals (with the cutoff flag).  The superseded OCV-ratio Q_ref is kept for
    traceability under 'superseded_ocv_ratio_method'.

    include_dynamic=False skips every SP2 dynamic file (no Q_ref/Q_id keys are returned): use it when only the
    initial-capacity and incremental-OCV capacities are needed, so that no validation/test file is read."""
    cfg = load_config()["dataset"]
    rc = cfg["reference_capacity"]
    dfs = dfs or {}
    out = dict(method=rc["method"],
               description=("Q_ref(T) for SP2 = median over the 8 SP2 dynamic files at T of the net charge throughput from the "
                            "end of the CV step (step 3) to the end of the profile (step 7, 2.5 V cutoff), Arbin "
                            "Charge_/Discharge_Capacity columns (trapezoidal integration of Current(A) as cross-check); "
                            "u_Q(T) = half-range over the 8 files; Q_id(T) = throughput of SP2_<T>C_DST_80SOC (the only "
                            "capacity an estimator may use). Also: 1 A CC discharge capacity to 2.5 V at 25 C of SP1/SP2/SP3 "
                            "(initial-capacity tests) and total discharged Ah of the incremental-OCV files after the initial "
                            "full charge."),
               initial_capacity_1A_25C_Ah={}, incremental_ocv_total_discharge_Ah={}, notes=[])
    for lid in ids_by(test_type="initial_capacity"):
        ent = CATALOG[lid]
        df = dfs.get(lid) if lid in dfs else load_raw(lid)
        seg = segments(lid, df)
        dis = seg[seg.type == "discharge"]
        d = dis.iloc[0]
        rec = dict(logical_id=lid, step=int(d.step), Q_Ah=float(d.Ah_discharge_arbin), Q_trapz_Ah=float(-d.Ah_net_trapz),
                   I_mean_A=float(d.I_mean), duration_s=float(d.duration_s), V_start=float(d.V_start), V_end=float(d.V_end),
                   n_discharge_segments=int(len(dis)))
        # unlogged pause inside the discharge (wall-clock jump)
        i0, i1 = int(d.i_start), int(d.i_end)
        wall = pd.to_datetime(df[COL["date"]].iloc[i0:i1 + 1]).to_numpy().astype("datetime64[s]").astype("int64")
        tt = df[COL["t"]].to_numpy()[i0:i1 + 1]
        jump = np.diff(wall) - np.diff(tt)
        j = int(np.argmax(jump))
        if jump[j] > 60:
            Qd = df[COL["Qd"]].to_numpy()
            rec["unlogged_pause"] = dict(row=i0 + j, pause_s=float(jump[j]), Q_before_pause_Ah=float(Qd[i0 + j] - Qd[i0 - 1]),
                                        V_before_pause=float(df[COL["V"]].iloc[i0 + j]), V_after_pause=float(df[COL["V"]].iloc[i0 + j + 1]),
                                        note="Date_Time advances while Test_Time does not: the discharge was interrupted "
                                             "and resumed; the total includes capacity extracted after the recovery.")
            out["notes"].append(f"{lid}: 1 A discharge interrupted for {jump[j]:.0f} s (wall clock) at "
                                f"{df[COL['V']].iloc[i0 + j]:.3f} V; Q before pause {rec['unlogged_pause']['Q_before_pause_Ah']:.4f} Ah, total {rec['Q_Ah']:.4f} Ah")
        out["initial_capacity_1A_25C_Ah"][ent["cell_short"]] = rec
    for lid in ids_by(test_type="incremental_ocv"):
        ent = CATALOG[lid]
        df = dfs.get(lid) if lid in dfs else load_raw(lid)
        cap = own_capacity(lid, df)
        cap["logical_id"] = lid
        out["incremental_ocv_total_discharge_Ah"][lid] = cap
        if not cap["cutoff_2p5V_reached"]:
            out["notes"].append(f"{lid}: discharge branch ended by the pulse schedule at {cap['last_discharge_end_V']:.3f} V "
                                f"(2.5 V cutoff not reached): total {cap['Q_total_discharge_arbin_Ah']:.4f} Ah is a lower bound of the capacity at {ent['temperature_C']} C")
    # ---- superseded method (kept for traceability only; NOT used anywhere) ----------------------------
    # Review fix (capacity revision): Q_ref(T) used to be Q_SP2(25 C) x mean SP1/SP3 OCV-test ratio
    # Q_ocv(T)/Q_ocv(25 C).  At 45 C both OCV tests and at 0 C the SP1 test stopped before the 2.5 V cutoff, so
    # the ratios were built from lower bounds and Q_ref(45 C) was biased low.  The ratios are still reported
    # under 'superseded_ocv_ratio_method' for traceability.
    ratios = {}
    for cell in ("SP1", "SP3"):
        q25 = out["incremental_ocv_total_discharge_Ah"][f"{cell}_IC_OCV_25C"]["Q_total_discharge_arbin_Ah"]
        for T in cfg["temperatures_C"]:
            e = out["incremental_ocv_total_discharge_Ah"][f"{cell}_IC_OCV_{T}C"]
            qT = e["Q_total_discharge_arbin_Ah"]
            ratios.setdefault(str(T), {})[cell] = dict(Q_T_Ah=qT, Q_25_Ah=q25, ratio=qT / q25,
                                                       cutoff_2p5V_reached=e["cutoff_2p5V_reached"],
                                                       arithmetic=f"{qT:.4f}/{q25:.4f} = {qT / q25:.5f}")
    q2 = out["initial_capacity_1A_25C_Ah"]["SP2"]["Q_Ah"]
    out["superseded_ocv_ratio_method"] = dict(
        method=rc.get("superseded_method"),
        status="SUPERSEDED - invalid at 0 C and 45 C (OCV tests did not reach the 2.5 V cutoff); not used anywhere",
        temperature_ratio_Q_T_over_Q_25C=ratios,
        Q_ref_Ah={T: q2 * 0.5 * (r["SP1"]["ratio"] + r["SP3"]["ratio"]) for T, r in ratios.items()})
    # ---- current method: CV-end -> 2.5 V cutoff throughput of the SP2 dynamic files -----------------------
    if not include_dynamic:
        out["dynamic_files_read"] = False
        out["note_include_dynamic"] = "include_dynamic=False: no SP2 dynamic file was read; Q_ref/Q_id not computed"
        return out
    per_file = {}
    for lid in ids_by(test_type="dynamic"):
        df = dfs.get(lid) if lid in dfs else load_raw(lid)
        per_file[lid] = cv_to_cutoff_throughput(lid, df)
    out["dynamic_throughput_SP2"] = per_file
    out["Q_ref_T_SP2"], out["Q_id_T_SP2"] = {}, {}
    for T in cfg["temperatures_C"]:
        lids = sorted(k for k, v in per_file.items() if v["temperature_C"] == T)
        qa = np.array([per_file[k]["Q_arbin_Ah"] for k in lids])
        qt = np.array([per_file[k]["Q_trapz_Ah"] for k in lids])
        med, lo, hi = float(np.median(qa)), float(qa.min()), float(qa.max())
        u = 0.5 * (hi - lo)
        srt = np.sort(qa)
        mid = (f"mean({srt[len(srt) // 2 - 1]:.4f}, {srt[len(srt) // 2]:.4f})" if len(srt) % 2 == 0
               else f"{srt[len(srt) // 2]:.4f}")
        out["Q_ref_T_SP2"][str(T)] = dict(
            Q_ref_Ah=med, u_Q_Ah=u, u_Q_rel=u / med, Q_min_Ah=lo, Q_max_Ah=hi, n_files=int(len(lids)),
            Q_ref_trapz_Ah=float(np.median(qt)), u_Q_trapz_Ah=float(0.5 * (qt.max() - qt.min())),
            max_abs_arbin_minus_trapz_Ah=float(np.max(np.abs(qa - qt))),
            max_rel_arbin_minus_trapz=float(np.max(np.abs(qa - qt) / qa)),
            files=lids, all_end_at_cutoff=bool(all(per_file[k]["ends_at_cutoff"] for k in lids)),
            arithmetic=(f"Q_ref({T} C) = median of {len(lids)} Arbin throughputs = {mid} = {med:.4f} Ah; "
                        f"u_Q = ({hi:.4f} - {lo:.4f})/2 = {u:.4f} Ah ({100 * u / med:.2f} %)"),
            role=("GROUND-TRUTH DEFINITION ONLY (reference SOC of every SP2 file at this temperature); uses all 8 files, "
                  "including validation and test files, and is NEVER given to any estimator/observer"),
        )
        lid_id = f"SP2_{T}C_{rc['identification_capacity_profile']}_{rc['identification_start_soc']}SOC"
        e = per_file[lid_id]
        out["Q_id_T_SP2"][str(T)] = dict(
            logical_id=lid_id, split=CATALOG[lid_id]["split"], Q_id_Ah=e["Q_arbin_Ah"], Q_id_trapz_Ah=e["Q_trapz_Ah"],
            rel_diff_to_Q_ref=e["Q_arbin_Ah"] / med - 1.0,
            role="the ONLY capacity the observer/estimators may use (identification file only)")
    out["cell_capacity_25C_initial_Ah"] = {}
    for c, v in out["initial_capacity_1A_25C_Ah"].items():
        rec = dict(logical_id=v["logical_id"], Q_Ah=v["Q_Ah"], Q_trapz_Ah=v["Q_trapz_Ah"])
        if "unlogged_pause" in v:
            rec.update(Q_before_unlogged_pause_Ah=v["unlogged_pause"]["Q_before_pause_Ah"],
                       unlogged_pause_s=v["unlogged_pause"]["pause_s"],
                       note=("the 1 A discharge was interrupted near the cutoff (Date_Time advances while Test_Time does not); "
                             "Q_Ah includes the charge extracted after the pause, Q_before_unlogged_pause_Ah does not"))
        out["cell_capacity_25C_initial_Ah"][c] = rec
    out["leakage_statement"] = (
        "Q_ref(T) is the median over all 8 SP2 dynamic files at T (identification, validation and test) and is used ONLY to "
        "define the reference (ground-truth) SOC; it is never passed to any estimator. Estimators may use Q_id(T) (throughput "
        "of the identification file SP2_<T>C_DST_80SOC) and nothing derived from validation or test files.")
    out["Q_ref_uncertainty_note"] = (
        "u_Q(T) = half-range of the CV-end-to-cutoff throughput over the 8 SP2 dynamic files at T (it contains the "
        "rate/profile dependence of the charge extractable before the 2.5 V cutoff and the run-to-run scatter). "
        "Reference-SOC band: band(t) = (|q(t)|/Q_ref)(u_Q/Q_ref) + I_off (t - t_anchor)/(3600 Q_ref) with I_off = "
        f"{float(cfg['reference_soc_band']['current_offset_A']) * 1000:.0f} mA, summed linearly.")
    return out


# --------------------------------------------------------------------------------------
# Audit
# --------------------------------------------------------------------------------------
def _date_time_drift(df: pd.DataFrame) -> dict:
    t = df[COL["t"]].to_numpy()
    wall = pd.to_datetime(df[COL["date"]]).to_numpy().astype("datetime64[s]").astype("int64").astype(float)
    drift = (wall - wall[0]) - (t - t[0])
    jumps = np.diff(drift)
    j = int(np.argmax(np.abs(jumps))) if len(jumps) else 0
    return dict(date_time_first=str(df[COL["date"]].iloc[0]), date_time_last=str(df[COL["date"]].iloc[-1]),
                date_time_span_s=float(wall[-1] - wall[0]), drift_min_s=float(drift.min()), drift_max_s=float(drift.max()),
                drift_at_end_s=float(drift[-1]), largest_step_change_s=float(jumps[j]) if len(jumps) else 0.0,
                largest_step_change_row=j, resolution_s=1.0,
                statement="Date_Time is rounded to 1 s and drifts relative to Test_Time(s); Test_Time(s) is the clock used everywhere")


def _discontinuities(df: pd.DataFrame, seg: pd.DataFrame) -> dict:
    t = df[COL["t"]].to_numpy(); V = df[COL["V"]].to_numpy(); I = df[COL["I"]].to_numpy()
    st = df[COL["st"]].to_numpy(); step = df[COL["step"]].to_numpy()
    dt = np.diff(t)
    neg = np.where(dt < 0)[0]
    zero = np.where(dt == 0)[0]
    same_step = np.diff(step) == 0
    # Step_Time resets inside a (cycle, step) group.  The groups are evaluated on their own rows
    # (not on consecutive rows of the file) so that a step-8 logger row interleaved between two
    # step-7 samples does not hide the loop-boundary reset of the dynamic profile; logger-artifact
    # groups are skipped (their Step_Time is ~0 and jitters).  Reported row = index of the row
    # before the reset.
    key = df[COL["cyc"]].to_numpy() * 1000 + step
    skip = {int(r.cycle) * 1000 + int(r.step) for r in seg.itertuples() if r.type == "logger_artifact"}
    codes, uniq = pd.factorize(key, sort=False)
    st_reset_list = []
    for g, k in enumerate(uniq):
        if int(k) in skip:
            continue
        idx = np.where(codes == g)[0]
        if len(idx) > 1:
            st_reset_list.extend(idx[:-1][np.diff(st[idx]) < 0].tolist())
    st_reset = np.array(sorted(st_reset_list), dtype=int)
    # dt > 3x the median of its own (cycle, step) segment
    med = {int(r.cycle) * 1000 + int(r.step): r.dt_median for r in seg.itertuples()}
    med_row = np.array([med.get(int(k), np.nan) for k in key[1:]])
    big = np.where(same_step & (dt > 3 * med_row))[0]
    dV = np.abs(np.diff(V)); dI = np.abs(np.diff(I))
    vj = np.where((dV > 0.3) & (dI < 0.05))[0]
    vj_all = np.where(dV > 0.3)[0]
    return dict(
        n_negative_dt=int(len(neg)), negative_dt_rows=[int(i) for i in neg[:20]],
        n_repeated_timestamps=int(len(zero)), repeated_timestamp_rows=[int(i) for i in zero[:20]],
        repeated_timestamp_test_times=[float(t[i]) for i in zero[:20]],
        n_dt_gt_3x_segment_median=int(len(big)), dt_gt_3x_rows=[int(i) for i in big[:20]],
        dt_gt_3x_values_s=[float(dt[i]) for i in big[:20]],
        n_step_time_resets_within_step=int(len(st_reset)), step_time_reset_rows=[int(i) for i in st_reset[:20]],
        step_time_reset_steps=sorted(set(int(step[i]) for i in st_reset)),
        n_voltage_jumps_gt_0p3V_total=int(len(vj_all)),
        n_voltage_jumps_gt_0p3V_unexplained=int(len(vj)), unexplained_voltage_jump_rows=[int(i) for i in vj[:20]],
        unexplained_voltage_jumps=[dict(row=int(i), V_before=float(V[i]), V_after=float(V[i + 1]), I_A=float(I[i]), dt_s=float(dt[i])) for i in vj[:20]],
    )


def _seg_records(seg: pd.DataFrame, types: tuple[str, ...]) -> list[dict]:
    cols = ["cycle", "step", "type", "n", "t_start", "t_end", "duration_s", "Ah_charge_arbin", "Ah_discharge_arbin",
            "Ah_net_trapz", "Ah_throughput_trapz", "I_mean", "I_min", "I_max", "V_start", "V_end", "V_min", "V_max", "dV",
            "dt_median", "dt_min", "dt_max", "dt_p5", "dt_p95", "n_dt_gt_3x_median", "n_dt_nonpositive"]
    sub = seg[seg.type.isin(types)][cols]
    recs = sub.to_dict(orient="records")
    for r in recs:
        for k, v in list(r.items()):
            if isinstance(v, (np.floating, np.integer)):
                r[k] = v.item()
            if isinstance(v, float) and np.isnan(v):
                r[k] = None
    return recs


def audit_file(logical_id: str, df: pd.DataFrame | None = None, capacity: dict | None = None) -> dict:
    """Machine-readable inventory entry for one logical id (all items of the audit spec)."""
    ent = dict(CATALOG[logical_id])
    cfg = load_config()["dataset"]
    if df is None:
        df = load_raw(logical_id)
    man = _manifest() or {}
    mf = man.get("files", {}).get(logical_id, {})
    checks = verify_file(logical_id, df, raise_on_fail=False)
    seg = segments(logical_id, df)
    t = df[COL["t"]].to_numpy(); V = df[COL["V"]].to_numpy()
    anomalies = []
    inv = dict(
        logical_id=logical_id, cell=ent["cell"], temperature_C=ent["temperature_C"], temperature_note=TEMPERATURE_NOTE,
        test_type=ent["test_type"], profile=ent["profile"], start_soc_label=ent["start_soc_label"], split=ent["split"],
        source=dict(zip=ent["source_zip"], workbook=ent["source_workbook"], folder=ent["source_folder"],
                    md5=mf.get("source_md5"), size_bytes=mf.get("source_size_bytes"), sheets=mf.get("sheets"),
                    data_sheets=mf.get("data_sheets"), rows_per_sheet=mf.get("rows_per_sheet"),
                    n_rows_raw_sheets=mf.get("n_rows_raw"), chunk_duplicate_rows_dropped=mf.get("chunk_duplicate_rows_dropped"),
                    info_test_name=mf.get("info_test_name"), info_schedule_file=mf.get("info_schedule_file"),
                    info_channel=mf.get("info_channel"), info_channels_listed=mf.get("info_channels_listed"),
                    data_sheet_channel=mf.get("data_sheet_channel"),
                    processed_csv=os.path.relpath(ent["processed_csv"], ROOT), csv_md5=mf.get("csv_md5")),
        channels=dict(CHANNELS, all_columns=list(df.columns),
                      constant_zero_columns=[c for c in COLUMNS if c != COL["date"] and bool((df[c] == 0).all())]),
        units=UNITS, sign_convention=checks["sign_convention"], verification=checks,
        n_rows=int(len(df)), test_time_first_s=float(t[0]), test_time_last_s=float(t[-1]), duration_s=float(t[-1] - t[0]),
        date_time=_date_time_drift(df), missing_values_per_column={c: int(df[c].isna().sum()) for c in COLUMNS},
    )
    disc = _discontinuities(df, seg)
    inv["repeated_timestamps"] = dict(n=disc["n_repeated_timestamps"], rows=disc["repeated_timestamp_rows"],
                                      test_times_s=disc["repeated_timestamp_test_times"],
                                      origin="chunk-boundary duplicate rows removed at load; remaining repeats are genuine timestamp collisions")
    inv["discontinuities"] = disc
    inv["sampling"] = dict(nominal_s=cfg["nominal_sampling_s"],
                           per_step=[dict(cycle=int(r.cycle), step=int(r.step), type=r.type, n=int(r.n),
                                          dt_median=None if np.isnan(r.dt_median) else float(r.dt_median),
                                          dt_min=None if np.isnan(r.dt_min) else float(r.dt_min),
                                          dt_max=None if np.isnan(r.dt_max) else float(r.dt_max),
                                          dt_p5=None if np.isnan(r.dt_p5) else float(r.dt_p5),
                                          dt_p95=None if np.isnan(r.dt_p95) else float(r.dt_p95)) for r in seg.itertuples()],
                           overall=_dt_stats(np.diff(t)))
    inv["segments_charge_discharge"] = _seg_records(seg, ("charge", "discharge", "cv", "dynamic"))
    rests = _seg_records(seg, ("rest",))
    for r in rests:
        r["V_initial"], r["V_final"], r["dV_over_rest"] = r["V_start"], r["V_end"], r["dV"]
    inv["segments_rest"] = rests
    inv["n_segments"] = dict(seg.type.value_counts().astype(int).to_dict())
    # --- generic anomalies
    if mf.get("chunk_duplicate_rows_dropped"):
        anomalies.append(f"chunked export: {len(mf['chunk_duplicate_rows_dropped'])} exact duplicate rows at sheet boundaries "
                         f"(rows {mf['chunk_duplicate_rows_dropped']} of the concatenation) dropped; they were repeated timestamps / repeated Data_Point")
    if disc["n_repeated_timestamps"]:
        anomalies.append(f"{disc['n_repeated_timestamps']} repeated Test_Time values remain at rows {disc['repeated_timestamp_rows']}")
    if disc["n_negative_dt"]:
        anomalies.append(f"{disc['n_negative_dt']} negative dt")
    if V.max() > 4.25:
        n_ov = int((V > 4.25).sum())
        anomalies.append(f"voltage above 4.25 V in {n_ov} sample(s), max {V.max():.4f} V (row {int(np.argmax(V))}, step {int(df[COL['step']].iloc[int(np.argmax(V))])})")
    if V.min() < 2.5:
        anomalies.append(f"voltage below 2.5 V: min {V.min():.4f} V (row {int(np.argmin(V))}, step {int(df[COL['step']].iloc[int(np.argmin(V))])})")
    if abs(inv["date_time"]["largest_step_change_s"]) > 60:
        anomalies.append(f"Date_Time jumps by {inv['date_time']['largest_step_change_s']:.0f} s relative to Test_Time at row "
                         f"{inv['date_time']['largest_step_change_row']} (unlogged pause)")
    if disc["n_voltage_jumps_gt_0p3V_unexplained"]:
        anomalies.append(f"{disc['n_voltage_jumps_gt_0p3V_unexplained']} voltage jump(s) > 0.3 V without a current step: {disc['unexplained_voltage_jumps']}")
    if t[0] > 100:
        anomalies.append(f"Test_Time starts at {t[0]:.1f} s (not ~0): the exported record begins after an unexported initial period")
    anomalies.append("no temperature channel: temperature is the chamber set point from the file name only")
    # --- test-type specifics
    if ent["test_type"] == "dynamic":
        prof = get_dynamic_profile(logical_id, df=df)
        m = prof["meta"]
        inv["dynamic"] = dict(n_samples_step7=m["n_raw_step7"], n_step8_logger_rows_dropped=m["logger_rows"]["n_dropped"],
                              logger_rows=m["logger_rows"], n_duplicate_timestamps_removed=m["n_duplicate_timestamps_removed"],
                              profile_duration_s=m["profile_duration_s"], dt_observed_step7=m["dt_observed"],
                              current_levels_step7=m["current_levels"], net_Ah_step7_arbin=m["net_Ah_arbin"], net_Ah_step7_trapz=m["net_Ah_trapz"],
                              net_Ah_step7_grid=m["net_Ah_grid"], throughput_step7=m["throughput"], resampling=m["resampling"],
                              Ah_charge_step7=m["Ah_charge_arbin"], Ah_discharge_step7=m["Ah_discharge_arbin"],
                              V_start=m["V_start"], V_end=m["V_end"], V_min=m["V_min"], V_max=m["V_max"], I_min=m["I_min"], I_max=m["I_max"],
                              rest_before_profile=m["rest_before_profile"], pre_profile_discharge=m["pre_profile_discharge"],
                              pre_profile_charge=m["pre_profile_charge"], n_uniform_grid=m["n_uniform"], h_s=m["h_s"])
        ref = reference_soc(logical_id, df=df, profile=prof)
        inv["reference_soc"] = dict(
            available="reconstructed", anchoring=ref["anchor"]["statement"], anchor=ref["anchor"],
            method="trapezoidal Coulomb counting of Current(A) over Test_Time(s) (our integration) and Arbin Charge_/Discharge_Capacity differences (cross-check)",
            pre_profile_discharge_Ah=m["pre_profile_discharge"]["Ah_arbin"], expected_pre_profile_discharge_Ah=0.4 if ent["start_soc_label"] == 80 else 1.0,
            Q_ref_Ah=ref["Q_ref_Ah"], Q_ref_provenance=ref["Q_ref_provenance"], eta=ref["eta"],
            soc_at_profile_start=ref["soc_profile_start"], soc_at_profile_end=ref["soc_profile_end"], soc_min=ref["soc_min"],
            cross_check=ref["cross_check"], uncertainty=dict(q_ref_rel_unc=ref["q_ref_rel_unc"], current_offset_A=ref["current_offset_A"],
                                                             at_profile_end=ref["unc_at_profile_end"],
                                                             u_Q_Ah=ref["u_Q_Ah"], formula=ref["band_formula"],
                                                             statement=(f"SOC band = (|net Ah|/Q_ref) x u_Q/Q_ref ({100 * ref['q_ref_rel_unc']:.2f} %) + "
                                                                        f"{1000 * ref['current_offset_A']:.0f} mA x elapsed time/(3600 Q_ref) (sensor offset), summed linearly")))
        frac = 1.0 - ent["start_soc_label"] / 100.0
        exp_Ah = frac * float(cfg["cell_nominal_capacity_Ah"])
        implied = m["pre_profile_discharge"]["Ah_arbin"] / frac
        inv["reference_soc"]["schedule_reference_capacity_Ah"] = implied
        inv["reference_soc"]["schedule_note"] = (f"pre-profile discharge = (1 - {ent['start_soc_label']}/100) x {implied:.3f} Ah: the test schedule "
                                                 f"used a reference capacity of {implied:.2f} Ah for the SOC label")
        if abs(m["pre_profile_discharge"]["Ah_arbin"] - exp_Ah) > 0.01:
            anomalies.append(f"pre-profile discharge {m['pre_profile_discharge']['Ah_arbin']:.4f} Ah instead of {exp_Ah:.2f} Ah: the "
                             f"{ent['start_soc_label']} % label is defined relative to a schedule capacity of {implied:.3f} Ah (0 C schedules use 1.8 Ah), "
                             f"not {cfg['cell_nominal_capacity_Ah']} Ah")
        anomalies.append(f"{m['logger_rows']['n_dropped']} step-8 logger rows interleaved in step 7 (timestamps within "
                         f"{m['logger_rows']['max_gap_to_step7_sample_s']:.4f} s of a step-7 sample, Current written as 0) dropped")
        if m["V_end"] < 2.49:
            anomalies.append(f"profile ended at {m['V_end']:.4f} V (below the 2.5 V cutoff: last transient sample)")
    elif ent["test_type"] == "incremental_ocv":
        cap = own_capacity(logical_id, df, seg)
        rel = get_relaxations(logical_id, df)
        ocv = get_ocv_points(logical_id, df)
        inv["incremental_ocv"] = dict(
            own_capacity=cap, n_relaxations_after_1A_pulses=len(rel),
            n_discharge_relaxations=sum(r["pulse"]["direction"] == "discharge" for r in rel),
            n_charge_relaxations=sum(r["pulse"]["direction"] == "charge" for r in rel),
            discharge_pulse_Ah=[round(r["pulse"]["Ah_arbin"], 4) for r in rel if r["pulse"]["direction"] == "discharge"],
            charge_pulse_Ah=[round(r["pulse"]["Ah_arbin"], 4) for r in rel if r["pulse"]["direction"] == "charge"],
            relaxation_durations_s=[round(r["duration_s"], 1) for r in rel],
            ocv_points=ocv.to_dict(orient="records"),
            last_step=dict(cycle=int(seg.iloc[-1].cycle), step=int(seg.iloc[-1].step), type=seg.iloc[-1].type, n=int(seg.iloc[-1].n)),
            initial_state=dict(V_first=float(V[0]), cc_step2_n=int(seg[(seg.step == 2) & (seg.cycle == 1)].n.iloc[0]),
                               cv_step3_Ah=float(seg[(seg.step == 3) & (seg.cycle == 1)].Ah_charge_arbin.iloc[0]),
                               cv_end_current_A=float(seg[(seg.step == 3) & (seg.cycle == 1)].I_min.iloc[0])))
        inv["reference_soc"] = dict(
            available="own-capacity SOC labels",
            anchoring="SOC = 1 at the end of the initial CV step (cycle 1, step 3) at this temperature; net discharged Ah from the "
                      "Arbin capacity columns; SOC = 1 - net_Ah / Q_total where Q_total is this file's total discharged Ah",
            Q_total_discharge_Ah=cap["Q_total_discharge_arbin_Ah"], Q_total_trapz_Ah=cap["Q_total_discharge_trapz_Ah"],
            cutoff_2p5V_reached=cap["cutoff_2p5V_reached"], last_discharge_end_V=cap["last_discharge_end_V"],
            uncertainty="pulse Ah from Arbin vs trapezoid agree to the values in segments; SOC label uncertainty is dominated by whether the "
                        "discharge branch reached the 2.5 V cutoff (see cutoff_2p5V_reached)")
        if not cap["cutoff_2p5V_reached"]:
            anomalies.append(f"discharge branch ended at {cap['last_discharge_end_V']:.3f} V by the pulse schedule, not at the 2.5 V cutoff: "
                             f"total {cap['Q_total_discharge_arbin_Ah']:.4f} Ah is a lower bound of the capacity at this temperature")
        p_Ah = [r["pulse"]["Ah_arbin"] for r in rel if r["pulse"]["direction"] == "discharge"]
        if p_Ah and abs(np.median(p_Ah) - 0.2) > 0.01:
            anomalies.append(f"discharge pulses of {np.median(p_Ah):.4f} Ah (schedule step of 0.1 x 1.8 Ah at 0 C) instead of 0.2 Ah")
        last = seg.iloc[-1]
        if not (last.type == "rest" and last.duration_s > 3600):
            anomalies.append(f"file truncated: ends in cycle {int(last.cycle)} step {int(last.step)} ({last.type}, {int(last.n)} samples); "
                             f"steps present {sorted(set(seg.step))}")
        s2 = seg[(seg.step == 2) & (seg.cycle == 1)].iloc[0]
        if s2.n <= 5:
            anomalies.append(f"initial CC charge (step 2) has only {int(s2.n)} sample(s) (cell already at {V[0]:.3f} V at start); "
                             f"the CV step reached {inv['incremental_ocv']['initial_state']['cv_end_current_A']:.3f} A and added {inv['incremental_ocv']['initial_state']['cv_step3_Ah']:.4f} Ah")
        ch = seg[(seg.type == "charge") & (seg.V_max > 4.2005)]
        if len(ch):
            anomalies.append(f"{len(ch)} time-limited 1 A charge pulse(s) exceeded 4.2 V (max {ch.V_max.max():.4f} V, cycles {sorted(set(ch.cycle))})")
    else:  # initial capacity
        dis = seg[seg.type == "discharge"].iloc[0]
        ch = seg[seg.type == "charge"]
        inv["initial_capacity"] = dict(Q_1A_discharge_arbin_Ah=float(dis.Ah_discharge_arbin), Q_1A_discharge_trapz_Ah=float(-dis.Ah_net_trapz),
                                       discharge_step=int(dis.step), discharge_duration_s=float(dis.duration_s), V_end=float(dis.V_end),
                                       first_charge_cc_Ah=float(ch.iloc[0].Ah_charge_arbin), cv_Ah=float(seg[seg.type == "cv"].iloc[0].Ah_charge_arbin),
                                       cv_end_current_A=float(seg[seg.type == "cv"].iloc[0].I_min))
        if capacity is not None:
            rec = capacity["initial_capacity_1A_25C_Ah"].get(ent["cell_short"], {})
            if "unlogged_pause" in rec:
                inv["initial_capacity"]["unlogged_pause"] = rec["unlogged_pause"]
        inv["reference_soc"] = dict(available="capacity measurement", anchoring="full CC/CV charge to 4.2 V / 0.02 A then 1 A discharge to 2.5 V at 25 C",
                                    Q_1A_Ah=float(dis.Ah_discharge_arbin))
    inv["anomalies"] = anomalies
    return inv
