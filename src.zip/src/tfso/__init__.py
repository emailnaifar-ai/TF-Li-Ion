"""tfso -- tempered fractional SOC observer study on the CALCE INR18650-20R (SP1/SP2/SP3) data.

Sub-modules
-----------
tfso.data : canonical data layer (catalog, raw loading, verification, segmentation,
            dynamic-profile resampling, reference SOC, relaxations, OCV points).
"""
from . import data  # noqa: F401

__version__ = "0.1.0"
__all__ = ["data", "__version__"]
