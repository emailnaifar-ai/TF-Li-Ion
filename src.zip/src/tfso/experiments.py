"""Experiment harness: cases (data + reference SOC), scenarios, corruptions, resampling and a tidy runner.

Protocol (stated once here, used by every experiment script)
------------------------------------------------------------
* A case is one SP2 dynamic file: ``data.verify_file`` is called before use; the profile (step 7) is
  taken on the uniform grid of ``data.get_dynamic_profile`` (h = config dataset.resample_h_s = 1 s;
  charge-conserving current, linearly interpolated voltage) and the reference SOC from
  ``data.reference_soc`` with Q_ref(T) (ground truth only; never passed to an estimator).  Estimators
  use Q_n = Q_id(T) (results/capacity.json 'Q_id_T_SP2') only; ``run_case`` refuses any other Q_n on a
  measured file unless a capacity/temperature-mismatch label is given in ``extra``.
* Split guard: ``load_case`` loads only the validation split by default; the test split additionally
  needs ``final_evaluation=True`` (final-evaluation scripts only).
* Cold start: every estimator starts at the first profile sample with V_p-hat = 0 and an EMPTY (zero)
  memory buffer; the rest/pre-profile history is not replayed into the observers (unlike the
  identification, which warm-starts the plant memory from the end of CV).
* Initial SOC scenarios: 'nominal' = inversion, on config estimators.ocv_inversion_interval, of ONE
  common reference OCV at the last voltage of the rest before the profile (step 6, 2 h rest;
  relaxation assumed complete).  The reference OCV is the selected PCHIP OCV at the file's temperature
  on the Q_id(T) axis with the alignment of config estimators.nominal_z0_ocv (s = 1, dq = 0: no model's
  identified alignment is favoured), so every method (including CC) starts from the SAME nominal z0.
  'plus20' / 'minus20' = reference initial SOC +- 0.20 (absolute, not clipped).
* Sensor corruption (explicit seeds; a non-empty corruption without a seed raises):
  I_m = I + I_offset + N(0, sigma_I^2), V_m = V + N(0, sigma_V^2), with independent streams for I and
  V from ``numpy.random.SeedSequence(seed).spawn(2)``; the same current error is added to the output
  current I_out of re-gridded cases (one sensor).  Metrics use the uncorrupted reference SOC and the
  uncorrupted measured voltage.
* Input timing (P0 alignment): every estimator uses the 'causal' convention of ``tfso.model`` with which
  its parameters were identified: SOC and polarisation are driven by u_k = I_{k-1} (the current held on
  [t_{k-1}, t_k)), the output term R0 I uses the grid current I_k (``observer.INPUT_TIMING``).
* Re-gridding to h = m x 1 s (``resample_case``): the DYNAMICS current is the mean of the m 1-s grid
  values over [t_k, t_k + h), held on that interval (ZOH; charge-conserving, the Coulomb count at every
  coarse grid point equals that of the 1 s grid; ``I_mode='sample'`` gives sample-and-hold of I(t_k)),
  and the estimators apply it causally (u_k = coarse mean over [t_{k-1}, t_k)); the VOLTAGE is the point
  sample V(t_k) and the OUTPUT current ``I_out`` (used in R0 I in the output equation, innovation and l2
  injection) is the 1 s grid current at t_k (the 1 s interval mean over [t_k, t_k + 1 s), i.e. exactly the
  output current R0 I_n of the identified model at t_k), so V_k and R0 I_out,k refer to the same instant
  as on the 1 s grid (h = 1 s is the control: resample_case(case, 1) returns the case unchanged; on it
  every estimator run open loop reproduces model.simulate(timing='causal') to rounding).  Reference SOC
  sampled at t_k.
* h-dependence of hyper-parameters (``hyper_for_h``): memory is held constant in SECONDS
  (N_L(h) = ceil(L_s/h)) and the per-step process-noise covariances scale with h (Q(h) = Q(1 s) h,
  constant random-walk intensity per second); R, P0 and the continuous-time observer gains l1, l2 are
  unchanged.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field

import numpy as np

from . import data as D
from . import metrics as MX
from .observer import FastOCV, as_fast_ocv, run_estimator

__all__ = ["Case", "load_case", "resample_case", "initial_soc", "corrupt_signals", "perturb_params",
           "capacity_mismatch", "temperature_mismatch", "run_case", "records_frame", "estimator_config",
           "q_id", "make_synthetic_case", "synthetic_dst_current", "SCENARIOS_Z0", "hyper_for_h", "default_hyper",
           "observer_hyper",
           "nominal_reference_ocv"]

SCENARIOS_Z0 = ("nominal", "plus20", "minus20")
_NOMINAL_OCV_CACHE: dict = {}


def estimator_config() -> dict:
    """The ``estimators`` section of config.yaml (with the validation section merged under 'validation')."""
    cfg = D.load_config()
    out = dict(cfg.get("estimators", {}))
    out["validation"] = cfg.get("validation", {})
    return out


def q_id(T: int) -> float:
    """Q_id(T) [Ah] from results/capacity.json 'Q_id_T_SP2' (the only capacity an estimator may use)."""
    p = D.ROOT / "results" / "capacity.json"
    with open(p, "r", encoding="utf-8") as fh:
        cap = json.load(fh)
    return float(cap["Q_id_T_SP2"][str(int(T))]["Q_id_Ah"])


# ---------------------------------------------------------------------------
# Hyper-parameters versus h
# ---------------------------------------------------------------------------
_Q_KEYS = {"FOEKF": ("Q",), "EKF2RC": ("Q",), "AEKF2RC": ("Q", "Q_min")}


def hyper_for_h(method: str, hyper: dict, h: float, h_ref: float = 1.0) -> dict:
    """Hyper-parameters specified at step h_ref converted to step h (see module docstring):
    memory: 'L_s' kept (seconds); an integer 'N_L' given at h_ref becomes L_s = N_L h_ref;
    Q (and Q_min for AEKF2RC) scaled by h/h_ref.  The conversion is recorded in 'h_scaling'."""
    out = dict(hyper)
    note = dict(h_ref=float(h_ref), h=float(h))
    if method in ("TFO", "FOO", "FOEKF"):
        if "L_s" not in out and out.get("N_L") not in (None, "full"):
            out["L_s"] = float(out["N_L"]) * float(h_ref)
            note["L_s_from_N_L"] = out["L_s"]
        if "L_s" in out:
            out.pop("N_L", None)
    for k in _Q_KEYS.get(method, ()):
        if k in out:
            out[k] = [float(v) * float(h) / float(h_ref) for v in out[k]]
            note[f"{k}_scale"] = float(h) / float(h_ref)
    out["h_scaling"] = note
    return out


def default_hyper(method: str, h: float = 1.0) -> dict:
    """Config defaults (estimators.defaults, specified at h = 1 s) converted to step h.  For TFO/FOO the
    gains are NOT in the defaults (they are designed per model/temperature by
    ``observer.design_observer_gains`` with the design settings returned here)."""
    d = dict(estimator_config().get("defaults", {}).get(method, {}))
    if "memory_L_s" in d:
        d["L_s"] = d.pop("memory_L_s")
        d.pop("N_L", None)
    return hyper_for_h(method, d, h, 1.0)


def observer_hyper(method: str, params: dict, ocv, h: float = 1.0, **overrides) -> dict:
    """Runnable TFO/FOO hyper-parameters: config design settings (``default_hyper``, overridable) and the
    gains of ``observer.design_observer_gains`` for this model (params incl. alignment s, dq), OCV and h.
    The design result (sigma_cert, kappa1/2, certified, h l1 kappa2, objective) is kept under 'design'."""
    from .observer import design_observer_gains
    if method not in ("TFO", "FOO"):
        raise ValueError("observer_hyper is for TFO/FOO")
    d = default_hyper(method, h)
    d.update(overrides)
    L_s = d.get("L_s")
    N_L = None if L_s in (None, "full") else int(math.ceil(float(L_s) / h - 1e-9))
    focv = as_fast_ocv(ocv, s=params.get("s"), dq=params.get("dq"))
    g = design_observer_gains(params, focv, h, N_L, z_interval=tuple(d["z_interval"]),
                              lam_override=0.0 if method == "FOO" else None, l1max=d.get("l1max"),
                              l2max=float(d.get("l2max", 1.0)), margin=float(d.get("margin", 0.1)),
                              tau_z_min=d.get("tau_z_min"), l2min=float(d.get("l2min", 0.0)))
    if g["l1"] is None:
        raise RuntimeError(f"{method}: gain design infeasible ({g})")
    return dict(l1=g["l1"], l2=g["l2"], L_s=L_s, z_interval=list(d["z_interval"]), h_scaling=d.get("h_scaling"),
                design=g)


# ---------------------------------------------------------------------------
# Cases
# ---------------------------------------------------------------------------
@dataclass
class Case:
    logical_id: str
    T: int
    profile: str
    start_level: str
    split: str
    h: float
    t: np.ndarray
    I: np.ndarray
    V: np.ndarray
    soc_ref: np.ndarray
    V_rest_end: float
    meta: dict = field(default_factory=dict)
    I_out: np.ndarray | None = None          # output current (point sample at t_k) for re-gridded cases

    @property
    def z_ref0(self) -> float:
        return float(self.soc_ref[0])


def load_case(logical_id: str, allow_splits=("validation",), final_evaluation: bool = False) -> Case:
    """Verified case on the 1 s grid.  Only the validation split is allowed by default; other splits
    must be requested explicitly in ``allow_splits`` and the test split additionally needs
    ``final_evaluation=True``."""
    ent = D.CATALOG[logical_id]
    if ent["split"] not in allow_splits:
        raise PermissionError(f"{logical_id} is in split {ent['split']!r}, not allowed here ({allow_splits})")
    if ent["split"] == "test" and not final_evaluation:
        raise PermissionError(f"{logical_id} is a TEST file: pass final_evaluation=True (final evaluation only)")
    df = D.load_raw(logical_id)
    chk = D.verify_file(logical_id, df)
    prof = D.get_dynamic_profile(logical_id, df=df)
    ref = D.reference_soc(logical_id, df=df, profile=prof)
    meta = dict(verify_passed=bool(chk["passed"]), Q_ref_Ah=ref["Q_ref_Ah"], Q_ref_provenance=ref["Q_ref_provenance"],
                profile_meta={k: prof["meta"][k] for k in ("n_uniform", "profile_duration_s", "V_start", "V_end",
                                                            "net_Ah_grid", "rest_before_profile")},
                soc_band_end=ref["unc_at_profile_end"])
    return Case(logical_id=logical_id, T=int(ent["temperature_C"]), profile=str(ent["profile"]),
                start_level=f"{ent['start_soc_label']}SOC", split=str(ent["split"]), h=float(prof["meta"]["h_s"]),
                t=np.asarray(prof["t"], float), I=np.asarray(prof["I"], float), V=np.asarray(prof["V"], float),
                soc_ref=np.asarray(ref["soc_ref"], float),
                V_rest_end=float(prof["meta"]["rest_before_profile"]["V_end"]), meta=meta)


def resample_case(case: Case, h_new: float, I_mode: str = "mean") -> Case:
    """Coarser uniform grid h_new = m h (m integer); see the module docstring for the rules."""
    m = int(round(h_new / case.h))
    if m < 1 or abs(m * case.h - h_new) > 1e-9:
        raise ValueError("h_new must be an integer multiple of the case step")
    if m == 1:
        return case
    n = case.t.size
    K = (n - 1) // m                       # coarse samples k = 0..K at t = k m h
    idx = np.arange(K + 1) * m
    I_point = (case.I if case.I_out is None else case.I_out)[idx].copy()
    if I_mode == "mean":
        Ic = np.empty(K + 1)
        blocks = case.I[: K * m].reshape(K, m)
        Ic[:K] = blocks.mean(axis=1)
        Ic[K] = case.I[idx[-1]]
    elif I_mode == "sample":
        Ic = case.I[idx].copy()
    else:
        raise ValueError(I_mode)
    Vc = case.V[idx].copy()
    meta = dict(case.meta)
    meta["resampling"] = dict(h_from=case.h, h_to=float(h_new), I_mode=I_mode, V_mode="point sample V(t_k)",
                              I_out_mode="1 s grid current at t_k (the identified model's output current R0 I_n; output terms R0 I)")
    return Case(case.logical_id, case.T, case.profile, case.start_level, case.split, float(h_new),
                case.t[idx].copy(), Ic, Vc, case.soc_ref[idx].copy(), case.V_rest_end, meta, I_out=I_point)


def nominal_reference_ocv(T: int) -> FastOCV:
    """The common reference OCV for the 'nominal' z0 (config estimators.nominal_z0_ocv; cached per T)."""
    key = int(T)
    if key not in _NOMINAL_OCV_CACHE:
        from . import model as M
        ec = estimator_config()
        al = ec.get("nominal_z0_ocv", {"s": 1.0, "dq_Ah": 0.0})
        _NOMINAL_OCV_CACHE[key] = as_fast_ocv(M.AlignedOCV(key, q_id(key)), s=float(al["s"]), dq=float(al["dq_Ah"]))
    return _NOMINAL_OCV_CACHE[key]


def initial_soc(case: Case, scenario: str, ocv=None, params: dict | None = None) -> float:
    """z0 for 'nominal' (inversion of ``ocv`` at the end-of-rest voltage; by default the common reference
    OCV ``nominal_reference_ocv(case.T)`` for measured files; a synthetic case needs ``ocv``),
    'plus20', 'minus20', or a float string/number = absolute offset from the reference initial SOC."""
    if scenario == "nominal":
        if ocv is None:
            if case.split == "synthetic":
                raise ValueError("'nominal' on a synthetic case needs an OCV")
            f = nominal_reference_ocv(case.T)
        else:
            f = as_fast_ocv(ocv, s=(params or {}).get("s"), dq=(params or {}).get("dq"))
        lo, hi = estimator_config().get("ocv_inversion_interval", [-0.05, 1.05])
        return float(f.invert(case.V_rest_end, float(lo), float(hi)))
    if scenario == "plus20":
        return case.z_ref0 + 0.20
    if scenario == "minus20":
        return case.z_ref0 - 0.20
    return case.z_ref0 + float(scenario)


# ---------------------------------------------------------------------------
# Corruptions and mismatches
# ---------------------------------------------------------------------------
def corrupt_signals(I, V, seed: int | None, I_offset: float = 0.0, I_noise_std: float = 0.0,
                    V_noise_std: float = 0.0) -> tuple[np.ndarray, np.ndarray]:
    """I_m = I + I_offset + sigma_I N(0,1), V_m = V + sigma_V N(0,1); independent child streams of
    SeedSequence(seed) for I and V (the same seed gives the same noise for every method).  Random
    corruption (sigma_I or sigma_V > 0) without an explicit integer seed raises (common random numbers
    across methods are required for paired comparisons)."""
    I = np.asarray(I, float)
    V = np.asarray(V, float)
    if (I_noise_std > 0 or V_noise_std > 0) and seed is None:
        raise ValueError("random sensor corruption requires an explicit seed")
    Im = I + I_offset
    Vm = V.copy()
    if I_noise_std > 0 or V_noise_std > 0:
        sI, sV = np.random.SeedSequence(int(seed)).spawn(2)
        if I_noise_std > 0:
            Im = Im + I_noise_std * np.random.default_rng(sI).standard_normal(I.size)
        if V_noise_std > 0:
            Vm = Vm + V_noise_std * np.random.default_rng(sV).standard_normal(V.size)
    return Im, Vm


PERTURB_KEYS = ("alpha", "lam", "R0", "Rp", "Cp", "R1", "R2", "tau1", "tau2", "C1", "C2")


def perturb_params(params: dict, frac: float, seed: int | None = None, keys=None, factors: dict | None = None,
                   alpha_max: float = 0.999) -> tuple[dict, dict]:
    """Multiplicative parameter perturbation.  ``factors`` (dict key -> factor) is applied as given;
    otherwise each key in ``keys`` (default: the model parameters present among PERTURB_KEYS) is
    multiplied by an independent U[1 - frac, 1 + frac] factor from default_rng(seed) (seed required).
    alpha is capped at alpha_max < 1.  Qn, eta and the OCV are NOT perturbed here (see
    capacity_mismatch).  Returns (new_params, factors_used)."""
    p = dict(params)
    if factors is None:
        if seed is None:
            raise ValueError("random parameter perturbation requires an explicit seed")
        keys = [k for k in (keys or PERTURB_KEYS) if k in params]
        rng = np.random.default_rng(seed)
        factors = {k: float(rng.uniform(1.0 - frac, 1.0 + frac)) for k in keys}
    for k, f in factors.items():
        p[k] = float(params[k]) * float(f)
    if "alpha" in p:
        p["alpha"] = min(p["alpha"], alpha_max)
    return p, dict(factors)


def capacity_mismatch(params: dict, factor: float) -> dict:
    """Estimator capacity Qn -> factor x Qn (e.g. 0.95, 1.05 of Q_id(T)); pass
    extra={'capacity_mismatch': factor} to run_case."""
    p = dict(params)
    p["Qn"] = float(params["Qn"]) * float(factor)
    return p


def temperature_mismatch(params_by_T: dict, ocv_by_T: dict, T_used: int) -> tuple[dict, object]:
    """Estimator parameters, capacity and aligned OCV identified at T_used (applied to a file at another
    T); pass extra={'temperature_mismatch': T_used} to run_case."""
    return dict(params_by_T[int(T_used)]), ocv_by_T[int(T_used)]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
_MISMATCH_LABELS = ("capacity_mismatch", "temperature_mismatch")


def run_case(method: str, params: dict, hyper: dict, case: Case, z0_scenario: str = "nominal", ocv=None,
             corruption: dict | None = None, seed: int | None = None, scenario: str = "baseline",
             band: float | None = None, t_post: float | None = None, keep_series: bool = False,
             extra: dict | None = None, nominal_ocv=None) -> dict:
    """Evaluate one method on one case/scenario; returns a tidy (flat) record.

    corruption: dict(I_offset, I_noise_std, V_noise_std) (seeded by ``seed``; required when random);
    metrics against the uncorrupted reference SOC and measured voltage.  ``nominal_ocv``: OCV for the
    'nominal' z0 (default: the common reference OCV of the file's temperature; for synthetic cases the
    estimator's OCV).  ``extra`` entries are copied into the record (e.g. perturbation factors,
    mismatch labels 'capacity_mismatch' / 'temperature_mismatch', which also lift the Q_n = Q_id(T) check)."""
    extra = dict(extra or {})
    if case.split != "synthetic" and not any(k in extra for k in _MISMATCH_LABELS):
        qid = q_id(case.T)
        if abs(float(params["Qn"]) - qid) > 1e-9 * qid:
            raise ValueError(f"params['Qn'] = {params['Qn']} != Q_id({case.T}) = {qid}; "
                             "pass a mismatch label in extra for mismatch scenarios")
    src_ocv = ocv if ocv is not None else params.get("ocv")
    focv = as_fast_ocv(src_ocv, s=params.get("s"), dq=params.get("dq")) if (src_ocv is not None) else None
    if z0_scenario == "nominal":
        if nominal_ocv is None and case.split == "synthetic":
            nominal_ocv = focv
        z0 = initial_soc(case, "nominal", nominal_ocv)
        z0_source = "common reference OCV (config estimators.nominal_z0_ocv)" if case.split != "synthetic" \
            else "estimator OCV (synthetic)"
    else:
        z0 = initial_soc(case, z0_scenario)
        z0_source = "reference SOC + offset"
    corruption = dict(corruption or {})
    I_out = case.I_out
    if corruption:
        Im, Vm = corrupt_signals(case.I, case.V, seed, **corruption)
        if I_out is not None:
            I_out = I_out + (Im - case.I)
    else:
        Im, Vm = case.I, case.V
    res = run_estimator(method, params, hyper, Im, Vm, case.h, z0, focv, I_out=I_out)
    met = MX.soc_metrics(case.t, res["zhat"], case.soc_ref, Vt_hat=res["Vt_hat"], V_ref=case.V, band=band,
                         t_post=t_post, Vt_prior=res.get("Vt_prior"))
    fl = res["flags"]
    rec = dict(method=method, file=case.logical_id, T=case.T, profile=case.profile, start_level=case.start_level,
               split=case.split, h=case.h, z0_scenario=z0_scenario, z0_source=z0_source, scenario=scenario,
               seed=seed, seed_entropy=(None if seed is None else int(np.random.SeedSequence(int(seed)).entropy)),
               z0=float(z0), z_ref0=case.z_ref0, z0_error=float(z0 - case.z_ref0),
               I_offset=float(corruption.get("I_offset", 0.0)), I_noise_std=float(corruption.get("I_noise_std", 0.0)),
               V_noise_std=float(corruption.get("V_noise_std", 0.0)),
               N_L=res["hyper_used"].get("N_L"), N_L_requested=fl.get("N_L_requested"), N_L_used=fl.get("N_L_used"),
               full_memory=fl.get("full_memory"), L_s=fl.get("L_s_requested"),
               cpu_process_s=res["cpu_process_s"], cpu_per_sample_us=res["cpu_per_sample_us"], wall_s=res["wall_s"],
               wall_per_sample_us=res["wall_per_sample_us"], n_history_samples=res["n_history_samples"],
               bytes_state=res["bytes_state"], soc_clip_count=fl.get("soc_clip_count", 0),
               nonfinite=fl.get("nonfinite", False), positivity_ok=fl.get("positivity_ok"),
               h_l1_kappa2_clip=fl.get("h_l1_kappa2_clip"), n_outside_z_interval=fl.get("n_outside_z_interval"),
               explicit_stable=fl.get("explicit_stable"))
    rec.update(met)
    rec.update(extra)
    if keep_series:
        rec["_series"] = dict(t=case.t, zhat=res["zhat"], zref=case.soc_ref, Vt_hat=res["Vt_hat"],
                              Vt_prior=res.get("Vt_prior"), V=case.V, Vp_hat=res["Vp_hat"])
    return rec


def records_frame(records: list[dict]):
    """pandas DataFrame of tidy records (series entries dropped)."""
    import pandas as pd
    return pd.DataFrame([{k: v for k, v in r.items() if not k.startswith("_")} for r in records])


# ---------------------------------------------------------------------------
# Synthetic data (tests and smoke checks)
# ---------------------------------------------------------------------------
def synthetic_dst_current(N: int, h: float = 1.0, scale: float = 1.0) -> np.ndarray:
    """DST-like piecewise-constant current (A, > 0 charge) of N+1 samples: a 360 s cycle of discharge
    steps (0.5 to 2 C-rate-like levels for a 2 Ah cell) and two regenerative charge steps, net discharge."""
    # (duration s, current A) ; one cycle = 360 s, net about -0.6 A mean
    cyc = [(16, 0.0), (28, -0.5), (12, -1.0), (8, 0.5), (16, 0.0), (24, -0.5), (12, -1.0), (8, 0.5), (16, 0.0),
           (24, -0.5), (12, -1.0), (8, 0.5), (16, 0.0), (36, -1.0), (8, -2.0), (24, -0.5), (8, -2.0), (32, 1.0),
           (8, -1.0), (24, -0.5), (8, -2.0), (32, 0.0)]
    tt = np.arange(N + 1) * h
    edges = np.cumsum([0] + [d for d, _ in cyc])
    levels = np.array([c for _, c in cyc])
    ph = np.mod(tt, edges[-1])
    k = np.searchsorted(edges, ph, side="right") - 1
    return scale * levels[k]


def make_synthetic_case(params: dict, U, dU, N: int = 6000, h: float = 1.0, z_true0: float = 0.8,
                        Vp0: float = 0.0, plant_N_L: int | None = None, current=None) -> Case:
    """Case generated by the TFO model in the 'causal' timing of tfso.model (the one of the identification
    and of every estimator): z_n = z_{n-1} + h beta I_{n-1}; Vp by the implicit tempered GL recursion driven
    by u_n = I_{n-1} (tempered.simulate_tempered_element, memory plant_N_L, exact Caputo correction for
    Vp0 != 0); V_n = U(z_n) + R0 I_n + Vp_n.  ``U``/``dU`` are vectorised callables."""
    from . import tempered
    from .observer import model_constants
    c = model_constants(params)
    I = synthetic_dst_current(N, h) if current is None else np.asarray(current, float)
    z = z_true0 + np.concatenate([[0.0], np.cumsum(h * c["beta"] * I[:-1])])
    u = np.concatenate([[0.0], I[:-1]])            # causal drive u_n = I_{n-1} (u_0 is never used)
    Vp = tempered.simulate_tempered_element(float(params["alpha"]), float(params.get("lam", 0.0)), c["ap"], c["bp"],
                                            u, h, x0=Vp0, N_L=plant_N_L)
    V = np.asarray(U(z), float) + float(params["R0"]) * I + Vp
    t = h * np.arange(I.size)
    return Case("synthetic", 25, "DSTlike", "synthetic", "synthetic", h, t, I, V, z, float(np.asarray(U(z[0]))),
                meta=dict(Vp=Vp, plant_N_L=plant_N_L, Vp0=Vp0, input_timing="causal"))
