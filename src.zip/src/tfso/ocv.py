"""OCV-SOC identification for the CALCE INR18650-20R cells (SP1/SP3 incremental-OCV tests).

Axes
----
* Cell-intrinsic axis (all fitting happens here):  x = q / Q_cell,25
  q        = Ah removed from full (last sample of the first CV step of the file, data._full_anchor),
             net Arbin Discharge_Capacity - Charge_Capacity at the start of each 2 h rest;
  Q_cell,25 = the cell's own 25 C initial 1 A capacity (results/capacity.json, SP1 2.0094 Ah, SP3 1.9775 Ah).
  OCV_T(x) is decreasing in x.

* Any SOC axis used by an observer:  z = 1 - q / Q_axis   (q = Ah removed from full of the observed cell).
  Transfer to SP2 assumes that SP2 has the same OCV at the same *fractional* depth of discharge relative to its own
  25 C capacity Q_SP2,25:

      U(z; T, Q_axis) = OCV_T( (1 - z) * Q_axis / Q_SP2,25 ),
      dU/dz          = - OCV_T'( (1 - z) Q_axis / Q_SP2,25 ) * Q_axis / Q_SP2,25 .

  Q_SP2,25 = 2.0283 Ah (SP2_INITCAP step 6).  Caveat: that discharge contains an unlogged 208 s pause at 2.557 V and
  2.0048 Ah had been removed before the pause; 2.0048 Ah is the documented sensitivity value (function
  `soc_axis(..., Q_ref=...)` accepts either).  The observer uses Q_axis = Q_id(T), the SP2 DST 80SOC net throughput
  from the end of CV to the end of the profile (2.5 V cutoff).

Branches and the primary OCV
----------------------------
Relaxed points (end of each >= 1 h rest, data.get_ocv_points) are split into 'discharge' (after a 1 A discharge
pulse), 'charge' (after a 1 A charge pulse or the CC-to-4.2 V step) and 'full' (after CV).  The primary OCV is the
mean of the two branches where both exist: each branch is interpolated with a monotone PCHIP through its own points
and averaged at the branch abscissae inside the overlap of the two coverages (branch_average).  Outside that coverage a single
branch is used and flagged ('full' at x ~ 0, 'discharge_only' at the bottom).  Sensitivity: discharge branch only.

Models (all expose fit(x, U) -> self, predict(x), deriv(x) [dOCV/dx], params() -> JSON-able dict, domain)
------
PchipModel       monotone PCHIP through the (per-cell) branch-averaged points; pooled model = mean of per-cell PCHIPs
MonoSplineModel  cubic B-spline least squares + 2nd-difference penalty, dOCV/dx <= 0 imposed on a dense grid (cvxpy)
CombinedModel    Plett (2004, Part 2) combined model  K0 - K1/s - K2 s + K3 ln s + K4 ln(1-s),
                 s = eps + (1 - 2 eps)(1 - x / x_scale)  (scaling keeps the singularities outside the data)
ExpCubicModel    weng2014unified Table 1 model 4:  K0 + K1 exp(a s) + K2 s + K3 s^2 + K4 s^3,  s = 1 - x
The parametric models are unconstrained; monotonicity is checked a posteriori on the fit domain.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.interpolate import Akima1DInterpolator, BSpline, PchipInterpolator

MV = 1e3  # V -> mV


# --------------------------------------------------------------------------------------
# Relaxed OCV points
# --------------------------------------------------------------------------------------
def classify_points(pts: pd.DataFrame, Q_cell25: float) -> pd.DataFrame:
    """Add branch labels and the cell-intrinsic abscissa to data.get_ocv_points output."""
    p = pts.copy()
    p["q_Ah"] = p["net_discharged_Ah_from_full"]
    p["x"] = p["q_Ah"] / Q_cell25
    p["branch"] = p["direction"].map({"discharge": "discharge", "charge": "charge", "full_after_cv": "full"})
    if p["branch"].isna().any():
        raise ValueError(f"unexpected rest directions: {sorted(p.loc[p.branch.isna(), 'direction'].unique())}")
    p["U"] = p["V_relaxed"]
    return p.reset_index(drop=True)


def closure(p: pd.DataFrame) -> dict:
    """Coulomb-counting closure of a file: q of the final after-CV rest (0 if the charge were exactly returned)."""
    full = p[p.branch == "full"].sort_values("cycle")
    if len(full) < 2:
        return dict(available=False, q_final_full_Ah=None, x_final_full=None,
                    note="no end-of-test full point (file truncated)")
    last = full.iloc[-1]
    return dict(available=True, q_final_full_Ah=float(last.q_Ah), x_final_full=float(last.x),
                U_first_full_V=float(full.iloc[0].U), U_final_full_V=float(last.U),
                dU_full_points_mV=float((last.U - full.iloc[0].U) * MV))


def closure_corrected(p: pd.DataFrame, Q_cell25: float) -> pd.DataFrame:
    """Sensitivity ('closure-corrected charge branch'): rescale the charged Ah counted after the last discharge by a
    constant factor f = Q_dis / C_final so that the final after-CV rest returns to q = 0.  f is a Coulomb-counting
    CLOSURE correction, not a charge efficiency (f > 1 occurs in 3 of the 5 files with a closure point, which would
    be an unphysical efficiency).  Files without a final full point are unchanged.  Column 'closure_factor'."""
    c = closure(p)
    out = p.copy()
    if not c["available"]:
        out["closure_factor"] = 1.0
        return out
    q_end = float(p[p.branch == "discharge"].q_Ah.max())
    after = p.index[p.index > p[p.branch == "discharge"].q_Ah.idxmax()]
    C = q_end - p.loc[after, "q_Ah"]                       # charged Ah counted from the bottom
    C_final = q_end - c["q_final_full_Ah"]
    eta = q_end / C_final
    out.loc[after, "q_Ah"] = q_end - eta * C
    out["x"] = out["q_Ah"] / Q_cell25
    out["closure_factor"] = eta
    return out


eta_corrected = closure_corrected  # backward-compatible alias (pre-review name)


def _branch_interp(b: pd.DataFrame):
    b = b.sort_values("x")
    if len(b) < 2:
        return None
    return PchipInterpolator(b.x.to_numpy(), b.U.to_numpy(), extrapolate=False)


def branch_average(p: pd.DataFrame, merge_tol: float = 0.02, full: str = "mean") -> tuple[pd.DataFrame, pd.DataFrame]:
    """Per-cell primary OCV points and the hysteresis gap.

    Returns (avg, gap).  avg columns: x, U, kind in {'full', 'mean', 'discharge_only', 'charge_only'}, U_dis, U_chg.
    * 'full': x = 0 by definition (end of CV, the anchor of q), U = mean of the file's after-CV rests (the first one
      is at q = 0 exactly; the end-of-test one differs only by the Coulomb-counting closure error, see closure()).
    * 'mean': inside the overlap of the two branch coverages, at the union of the discharge- and charge-branch
      abscissae (a charge abscissa closer than merge_tol to a discharge abscissa is dropped), each branch
      interpolated by its own monotone PCHIP, U = (U_dis + U_chg) / 2.
    * single-branch points outside the overlap, dropped when closer than merge_tol to a 'mean' point.
    gap: x, U_chg - U_dis (V) at the 'mean' abscissae.
    full: 'mean' (primary), 'first' (first after-CV rest, q = 0 exactly) or 'last' (end-of-test after-CV rest) -- the
    two after-CV rests of a file differ by up to ~14 mV (within-cell repeatability), a sensitivity variant."""
    d = p[p.branch == "discharge"].sort_values("x")
    c = p[p.branch == "charge"].sort_values("x")
    f = p[p.branch == "full"]
    idis, ichg = _branch_interp(d), _branch_interp(c)
    lo, hi = max(d.x.min(), c.x.min()), min(d.x.max(), c.x.max())
    xd_in = d.x[(d.x >= lo) & (d.x <= hi)].to_numpy()
    xc_in = c.x[(c.x >= lo) & (c.x <= hi)].to_numpy()
    xc_keep = [xc for xc in xc_in if len(xd_in) == 0 or np.min(np.abs(xd_in - xc)) >= merge_tol]
    xm = np.sort(np.concatenate([xd_in, xc_keep]))
    rows, gaps = [], []
    fs = f.sort_values("cycle")
    Uf = {"mean": float(f.U.mean()), "first": float(fs.U.iloc[0]), "last": float(fs.U.iloc[-1])}[full]
    rows.append(dict(x=0.0, U=Uf, kind="full", U_dis=np.nan, U_chg=np.nan, n_src=int(len(f)) if full == "mean" else 1))
    for xv in xm:
        ud, uc = float(idis(xv)), float(ichg(xv))
        rows.append(dict(x=float(xv), U=0.5 * (ud + uc), kind="mean", U_dis=ud, U_chg=uc, n_src=2))
        gaps.append(dict(x=float(xv), gap_V=uc - ud, U_dis=ud, U_chg=uc))
    for br, pts in (("discharge_only", d), ("charge_only", c)):
        for _, r in pts.iterrows():
            if lo <= r.x <= hi:
                continue
            if len(xm) and np.min(np.abs(xm - r.x)) < merge_tol:
                continue
            rows.append(dict(x=float(r.x), U=float(r.U), kind=br,
                             U_dis=float(r.U) if br == "discharge_only" else np.nan,
                             U_chg=float(r.U) if br == "charge_only" else np.nan, n_src=1))
    avg = pd.DataFrame(rows).sort_values("x").reset_index(drop=True)
    return avg, pd.DataFrame(gaps)


def discharge_set(p: pd.DataFrame) -> pd.DataFrame:
    """Sensitivity point set: full point (mean of after-CV rests) + discharge branch."""
    f = p[p.branch == "full"]
    d = p[p.branch == "discharge"]
    rows = [dict(x=0.0, U=float(f.U.mean()), kind="full")]
    rows += [dict(x=float(r.x), U=float(r.U), kind="discharge") for _, r in d.iterrows()]
    return pd.DataFrame(rows).sort_values("x").reset_index(drop=True)


def is_strictly_decreasing(U: np.ndarray) -> bool:
    return bool(np.all(np.diff(np.asarray(U)) < 0))


# --------------------------------------------------------------------------------------
# Axis mapping
# --------------------------------------------------------------------------------------
def z_to_x(z, Q_axis: float, Q_ref: float):
    """x = (1 - z) Q_axis / Q_ref  (Q_ref = Q_SP2,25 by default in the observer)."""
    return (1.0 - np.asarray(z, float)) * Q_axis / Q_ref


def x_to_z(x, Q_axis: float, Q_ref: float):
    return 1.0 - np.asarray(x, float) * Q_ref / Q_axis


def soc_axis(model, z, Q_axis: float, Q_ref: float) -> tuple[np.ndarray, np.ndarray]:
    """U(z) and dU/dz [V per unit SOC] of an x-model on the SOC axis z = 1 - q / Q_axis."""
    x = z_to_x(z, Q_axis, Q_ref)
    return model.predict(x), -model.deriv(x) * Q_axis / Q_ref


# --------------------------------------------------------------------------------------
# Models on the x axis
# --------------------------------------------------------------------------------------
class PchipModel:
    """Monotone (Fritsch-Carlson) PCHIP; with several cells the model is the mean of the per-cell interpolants on
    the intersection of their domains.  fit(x, U, groups) takes a group label per point (cell)."""
    name = "pchip"

    def __init__(self, **_):
        self.parts = []

    def fit(self, x, U, groups=None):
        x, U = np.asarray(x, float), np.asarray(U, float)
        groups = np.zeros(len(x), int) if groups is None else np.asarray(groups)
        self.parts = []
        for g in pd.unique(groups):
            m = groups == g
            o = np.argsort(x[m])
            xs, us = x[m][o], U[m][o]
            self.parts.append((str(g), xs, us, PchipInterpolator(xs, us, extrapolate=True)))
        self.domain = (max(p[1][0] for p in self.parts), min(p[1][-1] for p in self.parts))
        return self

    def predict(self, x):
        return np.mean([p[3](np.asarray(x, float)) for p in self.parts], axis=0)

    def deriv(self, x):
        return np.mean([p[3].derivative()(np.asarray(x, float)) for p in self.parts], axis=0)

    def params(self):
        return dict(type="pchip_mean_of_cells", domain=list(self.domain),
                    nodes={g: dict(x=xs.tolist(), U=us.tolist()) for g, xs, us, _ in self.parts},
                    rebuild="mean over cells of scipy.interpolate.PchipInterpolator(x, U)")


class MonoSplineModel:
    """Cubic B-spline, min mean((B c - U)^2) + lam * ||D2 c||^2  s.t.  B'(x_grid) c <= 0 (decreasing in x)."""
    name = "mono_spline"

    def __init__(self, n_knots=4, lam=1e-4, degree=3, n_grid=400, solver="CLARABEL", domain=None, **_):
        self.n_knots, self.lam, self.k, self.n_grid, self.solver = int(n_knots), float(lam), int(degree), int(n_grid), solver
        self.fixed_domain = domain

    def fit(self, x, U, groups=None):
        import cvxpy as cp
        x, U = np.asarray(x, float), np.asarray(U, float)
        a, b = self.fixed_domain if self.fixed_domain is not None else (float(x.min()), float(x.max()))
        self.domain = (a, b)
        inner = np.linspace(a, b, self.n_knots + 2)[1:-1]
        k = self.k
        self.t = np.concatenate([[a] * (k + 1), inner, [b] * (k + 1)])
        nb = len(self.t) - k - 1
        B = BSpline.design_matrix(np.clip(x, a, b), self.t, k).toarray()
        xg = np.linspace(a, b, self.n_grid)
        Bd = np.column_stack([BSpline(self.t, np.eye(nb)[j], k).derivative()(xg) for j in range(nb)])
        D2 = np.diff(np.eye(nb), 2, axis=0)
        c = cp.Variable(nb)
        obj = cp.sum_squares(B @ c - U) / len(U) + self.lam * cp.sum_squares(D2 @ c)
        prob = cp.Problem(cp.Minimize(obj), [Bd @ c <= 0])
        prob.solve(solver=getattr(cp, self.solver))
        SOLVER_STATUS[prob.status] = SOLVER_STATUS.get(prob.status, 0) + 1
        if c.value is None or prob.status not in ("optimal", "optimal_inaccurate"):
            raise RuntimeError(f"mono spline solve failed: {prob.status}")
        self.c = np.asarray(c.value, float)
        self.status = prob.status
        self._s = BSpline(self.t, self.c, k, extrapolate=True)
        self._d = self._s.derivative()
        return self

    def predict(self, x):
        return self._s(np.asarray(x, float))

    def deriv(self, x):
        return self._d(np.asarray(x, float))

    def params(self):
        return dict(type="bspline", degree=self.k, knots=self.t.tolist(), coefficients=self.c.tolist(),
                    n_interior_knots=self.n_knots, lam=self.lam, domain=list(self.domain), solver_status=self.status,
                    rebuild="scipy.interpolate.BSpline(knots, coefficients, degree)(x)")


class CombinedModel:
    """Plett (2004) combined model on s = eps + (1 - 2 eps)(1 - x / x_scale)."""
    name = "combined"

    def __init__(self, eps=0.05, x_scale=1.05, **_):
        self.eps, self.xs = float(eps), float(x_scale)

    def _s(self, x):
        return self.eps + (1 - 2 * self.eps) * (1 - np.asarray(x, float) / self.xs)

    def _F(self, s):
        return np.column_stack([np.ones_like(s), -1 / s, -s, np.log(s), np.log(1 - s)])

    def fit(self, x, U, groups=None):
        x = np.asarray(x, float)
        s = self._s(x)
        if np.any(s <= 0) or np.any(s >= 1):
            raise ValueError("combined model: data outside the scaled (0, 1) interval; increase x_scale")
        self.K = np.linalg.lstsq(self._F(s), np.asarray(U, float), rcond=None)[0]
        self.domain = (float(x.min()), float(x.max()))
        return self

    def predict(self, x):
        return self._F(self._s(x)) @ self.K

    def deriv(self, x):
        s = self._s(x)
        dF = np.column_stack([np.zeros_like(s), 1 / s**2, -np.ones_like(s), 1 / s, -1 / (1 - s)])
        return dF @ self.K * (-(1 - 2 * self.eps) / self.xs)

    def params(self):
        return dict(type="combined_plett2004", K=self.K.tolist(), eps=self.eps, x_scale=self.xs, domain=list(self.domain),
                    formula="U = K0 - K1/s - K2 s + K3 ln s + K4 ln(1-s), s = eps + (1-2 eps)(1 - x/x_scale)")


class ExpCubicModel:
    """weng2014unified Table 1 model 4 on s = 1 - x; rate a profiled on a grid (linear LS for K)."""
    name = "exp_cubic"

    def __init__(self, a_grid=(-60.0, 60.0, 0.25), **_):
        lo, hi, st = a_grid
        self.a_grid = np.arange(lo, hi + 1e-12, st)
        self.a_grid = self.a_grid[np.abs(self.a_grid) > 1e-9]

    @staticmethod
    def _F(s, a):
        return np.column_stack([np.ones_like(s), np.exp(a * s), s, s**2, s**3])

    def fit(self, x, U, groups=None):
        x, U = np.asarray(x, float), np.asarray(U, float)
        s = 1 - x
        best = None
        for a in self.a_grid:
            F = self._F(s, a)
            K, *_ = np.linalg.lstsq(F, U, rcond=None)
            sse = float(np.sum((F @ K - U) ** 2))
            if best is None or sse < best[0]:
                best = (sse, a, K)
        _, self.a, self.K = best
        self.domain = (float(x.min()), float(x.max()))
        return self

    def predict(self, x):
        return self._F(1 - np.asarray(x, float), self.a) @ self.K

    def deriv(self, x):
        s = 1 - np.asarray(x, float)
        dF = np.column_stack([np.zeros_like(s), self.a * np.exp(self.a * s), np.ones_like(s), 2 * s, 3 * s**2])
        return -(dF @ self.K)

    def params(self):
        return dict(type="exp_cubic_weng2014_model4", K=self.K.tolist(), a=float(self.a), domain=list(self.domain),
                    formula="U = K0 + K1 exp(a s) + K2 s + K3 s^2 + K4 s^3, s = 1 - x")


class NodeInterpModel(PchipModel):
    """Representation-sensitivity model: Akima / modified-Akima (makima) interpolant through the same per-cell nodes
    as PchipModel (mean of the per-cell interpolants).  Not shape-preserving in general: monotonicity must be checked."""
    name = "node_interp"

    def __init__(self, method="makima", **_):
        super().__init__()
        self.method = method

    def fit(self, x, U, groups=None):
        x, U = np.asarray(x, float), np.asarray(U, float)
        groups = np.zeros(len(x), int) if groups is None else np.asarray(groups)
        self.parts = []
        for g in pd.unique(groups):
            m = groups == g
            o = np.argsort(x[m])
            xs, us = x[m][o], U[m][o]
            self.parts.append((str(g), xs, us, Akima1DInterpolator(xs, us, method=self.method, extrapolate=True)))
        self.domain = (max(p[1][0] for p in self.parts), min(p[1][-1] for p in self.parts))
        return self

    def params(self):
        d = super().params()
        d.update(type=f"{self.method}_mean_of_cells", rebuild=f"mean over cells of Akima1DInterpolator(x, U, method='{self.method}')")
        return d


MODELS = {"pchip": PchipModel, "mono_spline": MonoSplineModel, "combined": CombinedModel, "exp_cubic": ExpCubicModel,
          "makima": lambda **k: NodeInterpModel(method="makima"), "akima": lambda **k: NodeInterpModel(method="akima")}


def monotone_check(model, n: int = 2001, domain=None) -> dict:
    """A posteriori monotonicity on the fit domain: max of dOCV/dx (must be <= 0)."""
    a, b = domain or model.domain
    xg = np.linspace(a, b, n)
    d = model.deriv(xg)
    return dict(monotone=bool(np.all(d <= 1e-9)), max_dOCV_dx=float(d.max()),
                x_at_max=float(xg[int(np.argmax(d))]), domain=[float(a), float(b)])


def model_from_params(p: dict):
    """Rebuild a saved model (as written by params()) for downstream use."""
    t = p["type"]
    if t == "bspline":
        m = MonoSplineModel(n_knots=p["n_interior_knots"], lam=p["lam"], degree=p["degree"])
        m.t, m.c, m.k, m.domain = np.asarray(p["knots"]), np.asarray(p["coefficients"]), p["degree"], tuple(p["domain"])
        m._s = BSpline(m.t, m.c, m.k, extrapolate=True)
        m._d = m._s.derivative()
        return m
    if t == "pchip_mean_of_cells":
        m = PchipModel()
        m.parts = [(g, np.asarray(v["x"]), np.asarray(v["U"]), PchipInterpolator(v["x"], v["U"], extrapolate=True))
                   for g, v in p["nodes"].items()]
        m.domain = tuple(p["domain"])
        return m
    if t in ("makima_mean_of_cells", "akima_mean_of_cells"):
        m = NodeInterpModel(method=t.split("_")[0])
        m.parts = [(g, np.asarray(v["x"]), np.asarray(v["U"]),
                    Akima1DInterpolator(v["x"], v["U"], method=m.method, extrapolate=True)) for g, v in p["nodes"].items()]
        m.domain = tuple(p["domain"])
        return m
    if t == "combined_plett2004":
        m = CombinedModel(eps=p["eps"], x_scale=p["x_scale"])
        m.K, m.domain = np.asarray(p["K"]), tuple(p["domain"])
        return m
    if t == "exp_cubic_weng2014_model4":
        m = ExpCubicModel()
        m.a, m.K, m.domain = p["a"], np.asarray(p["K"]), tuple(p["domain"])
        return m
    raise ValueError(t)


def load_ocv(T: int, path: str | Path | None = None, Q_ref: float | None = None, outside: str = "warn"):
    """Observer-facing loader.  Returns (U(z, Q_axis), dUdz(z, Q_axis), meta) for the selected model at T (C).
    Q_ref defaults to Q_SP2,25 stored in ocv_fits.json; pass the pre-pause value for the sensitivity.

    The OCV is only supported by relaxed points of both cells on meta['supported_z_interval'] (for Q_axis = the
    stored default).  Outside the model's x-domain the interpolant is EXTRAPOLATED (e.g. at 45 C the dynamic cutoff
    states z < ~0.03 lie below the lowest relaxed OCV point).  outside = 'warn' (default: extrapolate and warn once),
    'extrapolate' (silent), 'clip' (evaluate at the nearest domain end) or 'nan' (NaN outside the domain)."""
    import warnings
    if outside not in ("warn", "extrapolate", "clip", "nan"):
        raise ValueError(outside)
    if path is None:
        path = Path(__file__).resolve().parents[2] / "results" / "ocv_fits.json"
    with open(path, "r", encoding="utf-8") as fh:
        res = json.load(fh)
    sel = res["selected"]["per_temperature"][str(T)]
    m = model_from_params(sel["params"])
    Qr = float(res["axis"]["Q_SP2_25C_Ah"] if Q_ref is None else Q_ref)

    lo, hi = m.domain
    warned = []

    def _eval(z, Q_axis, which):
        z = np.asarray(z, float)
        x = z_to_x(z, Q_axis, Qr)
        out_m = (x < lo - 1e-12) | (x > hi + 1e-12)
        if outside == "clip":
            z = x_to_z(np.clip(x, lo, hi), Q_axis, Qr)
        elif outside == "warn" and np.any(out_m) and not warned:
            warnings.warn(f"load_ocv({T}): z outside the OCV data domain (x in [{lo:.4f}, {hi:.4f}]); extrapolating", stacklevel=3)
            warned.append(True)
        v = soc_axis(m, z, Q_axis, Qr)[which]
        if outside == "nan":
            v = np.where(out_m, np.nan, v)
        return v

    def U(z, Q_axis):
        return _eval(z, Q_axis, 0)

    def dU(z, Q_axis):
        return _eval(z, Q_axis, 1)

    sup = sel.get("supported_z_interval", sel.get("validated_z_interval"))
    return U, dU, dict(model=m, Q_ref=Qr, Q_axis_default=res["axis"]["Q_axis_Ah"][str(T)], method=sel["method"],
                       supported_z_interval=sup, validated_z_interval=sup, x_domain=[lo, hi], outside=outside)


# --------------------------------------------------------------------------------------
# Hyper-parameter grids, leave-one-point-out and cross-cell validation
# --------------------------------------------------------------------------------------
def hp_grid(method: str, cfg: dict) -> list[dict]:
    """Hyper-parameter grid of a method from the config section `ocv`."""
    if method in ("pchip", "makima", "akima"):
        return [{}]
    if method == "mono_spline":
        s = cfg["mono_spline"]
        return [dict(n_knots=k, lam=l, degree=s["degree"], n_grid=s["n_constraint_grid"], solver=s["solver"])
                for k in s["n_interior_knots"] for l in s["lambda"]]
    if method == "combined":
        return [dict(eps=e, x_scale=cfg["combined"]["x_scale"]) for e in cfg["combined"]["eps"]]
    if method == "exp_cubic":
        return [dict(a_grid=tuple(cfg["exp_cubic"]["a_grid"]))]
    raise ValueError(method)


def make_model(method: str, hp: dict):
    return MODELS[method](**hp)


def _err_stats(e: np.ndarray) -> dict:
    e = np.asarray(e, float)
    if len(e) == 0:
        return dict(n=0, rmse_mV=None, max_abs_mV=None, mean_mV=None)
    return dict(n=int(len(e)), rmse_mV=float(np.sqrt(np.mean(e**2)) * MV), max_abs_mV=float(np.max(np.abs(e)) * MV),
                mean_mV=float(np.mean(e) * MV))


SOLVER_STATUS: dict = {}  # tally of every spline QP status (LOPO and final fits), reported in ocv_fits.json


class _SplineLOPO:
    """One compiled cvxpy problem per (training set, number of knots) with the point weights and lambda as
    parameters, so that the leave-one-point-out loop over the lambda grid does not recompile."""

    def __init__(self, x, U, n_knots, degree, n_grid, solver):
        import cvxpy as cp
        self.cp = cp
        a, b = float(x.min()), float(x.max())
        self.domain = (a, b)
        inner = np.linspace(a, b, n_knots + 2)[1:-1]
        self.t = np.concatenate([[a] * (degree + 1), inner, [b] * (degree + 1)])
        self.k = degree
        nb = len(self.t) - degree - 1
        B = BSpline.design_matrix(x, self.t, degree).toarray()
        xg = np.linspace(a, b, n_grid)
        Bd = np.column_stack([BSpline(self.t, np.eye(nb)[j], degree).derivative()(xg) for j in range(nb)])
        D2 = np.diff(np.eye(nb), 2, axis=0)
        self.c = cp.Variable(nb)
        self.w = cp.Parameter(len(x), nonneg=True)
        self.lam = cp.Parameter(nonneg=True)
        obj = cp.sum(cp.multiply(self.w, cp.square(B @ self.c - U))) + self.lam * cp.sum_squares(D2 @ self.c)
        self.prob = cp.Problem(cp.Minimize(obj), [Bd @ self.c <= 0])
        self.solver = getattr(cp, solver)

    def solve(self, w, lam):
        self.w.value = w / w.sum()
        self.lam.value = lam
        self.prob.solve(solver=self.solver)
        SOLVER_STATUS[self.prob.status] = SOLVER_STATUS.get(self.prob.status, 0) + 1
        if self.c.value is None or self.prob.status not in ("optimal", "optimal_inaccurate"):
            raise RuntimeError(f"spline LOPO solve failed: {self.prob.status}")
        return BSpline(self.t, np.asarray(self.c.value, float), self.k, extrapolate=True)


def lopo(method: str, hp_list: list[dict], x, U, groups) -> list[dict]:
    """Leave-one-point-out errors (prediction - measurement) for every hyper-parameter set.  A left-out point is
    scored only when it lies strictly inside the x-range of the remaining points of its own group (cell), so that
    every method is scored on the same interior points and no score is an extrapolation."""
    x, U, groups = np.asarray(x, float), np.asarray(U, float), np.asarray(groups)
    n = len(x)

    def interior(i):
        own = (groups == groups[i]) & (np.arange(n) != i)
        return own.any() and x[own].min() < x[i] < x[own].max()

    out = []
    if method == "mono_spline":
        by_k = {}
        for hp in hp_list:
            by_k.setdefault((hp["n_knots"], hp["degree"], hp["n_grid"], hp["solver"]), []).append(hp)
        for (nk, deg, ng, sol), hps in by_k.items():
            prob = _SplineLOPO(x, U, nk, deg, ng, sol)
            errs = {hp["lam"]: [] for hp in hps}
            for i in range(n):
                keep = np.ones(n, bool); keep[i] = False
                if not interior(i):
                    continue
                w = keep.astype(float)
                for hp in hps:
                    s = prob.solve(w, hp["lam"])
                    errs[hp["lam"]].append(float(s(x[i]) - U[i]))
            for hp in hps:
                out.append(dict(hp=hp, **_err_stats(np.array(errs[hp["lam"]]))))
        return out
    for hp in hp_list:
        e = []
        for i in range(n):
            keep = np.ones(n, bool); keep[i] = False
            if not interior(i):
                continue
            try:
                m = make_model(method, hp).fit(x[keep], U[keep], groups[keep])
            except ValueError:
                continue
            a, b = m.domain
            if not (a < x[i] < b):
                continue
            e.append(float(m.predict(np.array([x[i]]))[0] - U[i]))
        out.append(dict(hp=hp, **_err_stats(np.array(e))))
    return out


def select_hp(method: str, cfg: dict, x, U, groups) -> tuple[dict, list[dict]]:
    """Hyper-parameters minimising the leave-one-point-out RMSE on (x, U) only."""
    table = lopo(method, hp_grid(method, cfg), x, U, groups)
    ok = [r for r in table if r["rmse_mV"] is not None]
    best = min(ok, key=lambda r: r["rmse_mV"])
    return best["hp"], table


def cross_cell(method: str, cfg: dict, sets: dict) -> dict:
    """Fit on one cell (hyper-parameters by LOPO on that cell only), predict the other cell's points inside the
    training domain.  sets: {cell: DataFrame(x, U)}."""
    cells = list(sets)
    res, all_e = {}, []
    for a in cells:
        for b in cells:
            if a == b:
                continue
            A, Bp = sets[a], sets[b]
            hp, _ = select_hp(method, cfg, A.x.to_numpy(), A.U.to_numpy(), np.array([a] * len(A)))
            m = make_model(method, hp).fit(A.x.to_numpy(), A.U.to_numpy(), np.array([a] * len(A)))
            lo, hi = m.domain
            inside = (Bp.x >= lo) & (Bp.x <= hi)
            e = m.predict(Bp.x[inside].to_numpy()) - Bp.U[inside].to_numpy()
            all_e.append(e)
            res[f"{a}->{b}"] = dict(hp=hp, n_excluded_outside_domain=int((~inside).sum()), monotone=monotone_check(m),
                                    x_eval=Bp.x[inside].tolist(), err_mV=(e * MV).tolist(), **_err_stats(e))
    res["pooled"] = _err_stats(np.concatenate(all_e))
    return res


def eval_on(model, pts: pd.DataFrame) -> dict:
    """In-sample / external errors of a model on a point set, inside its domain."""
    lo, hi = model.domain
    m = (pts.x >= lo - 1e-12) & (pts.x <= hi + 1e-12)
    e = model.predict(pts.x[m].to_numpy()) - pts.U[m].to_numpy()
    return dict(n_outside_domain=int((~m).sum()), **_err_stats(e))


# --------------------------------------------------------------------------------------
# Slope bounds and flat regions
# --------------------------------------------------------------------------------------
def slope_bounds(model, z_lo: float, z_hi: float, Q_axis: float, Q_ref: float, n: int = 2001) -> dict:
    """kappa_1 = min dU/dz, kappa_2 = max dU/dz on [z_lo, z_hi] (V per unit SOC and mV per %SOC)."""
    z = np.linspace(z_lo, z_hi, n)
    _, d = soc_axis(model, z, Q_axis, Q_ref)
    i1, i2 = int(np.argmin(d)), int(np.argmax(d))
    return dict(z_interval=[float(z_lo), float(z_hi)], kappa1_V_per_soc=float(d[i1]), kappa2_V_per_soc=float(d[i2]),
                kappa1_mV_per_pct=float(d[i1] * 10.0), kappa2_mV_per_pct=float(d[i2] * 10.0),
                z_at_kappa1=float(z[i1]), z_at_kappa2=float(z[i2]), ratio_kappa2_over_kappa1=float(d[i2] / d[i1]))


def flat_regions(model, z_lo: float, z_hi: float, Q_axis: float, Q_ref: float, thr: float, n: int = 2001) -> dict:
    """Sub-intervals of [z_lo, z_hi] where dU/dz < thr and the local minima of dU/dz."""
    z = np.linspace(z_lo, z_hi, n)
    _, d = soc_axis(model, z, Q_axis, Q_ref)
    below = d < thr
    regions, i = [], 0
    while i < n:
        if below[i]:
            j = i
            while j + 1 < n and below[j + 1]:
                j += 1
            k = i + int(np.argmin(d[i:j + 1]))
            regions.append(dict(z_from=float(z[i]), z_to=float(z[j]), min_slope_V_per_soc=float(d[k]), z_at_min=float(z[k])))
            i = j + 1
        else:
            i += 1
    mins = [dict(z=float(z[k]), slope_V_per_soc=float(d[k])) for k in range(1, n - 1) if d[k] < d[k - 1] and d[k] <= d[k + 1]]
    return dict(threshold_V_per_soc=thr, regions=regions, local_minima=mins)


# --------------------------------------------------------------------------------------
# Review additions: relaxation extrapolation, secant bounds, curvature, axis alignment, grid edges
# --------------------------------------------------------------------------------------
def extrapolate_rests(lid: str, df: pd.DataFrame, p: pd.DataFrame, segs: pd.DataFrame, t_fit_from_s: float,
                      horizon_s: float, V_col: str = "Voltage(V)", t_col: str = "Test_Time(s)") -> pd.DataFrame:
    """Sensitivity for incomplete relaxation: replace each relaxed voltage (end of a ~2 h rest) by a log-time linear
    extrapolation V(t) = a + b ln t fitted on t >= t_fit_from_s of that rest and evaluated at t = horizon_s.
    Log-linear extrapolation over-estimates the remaining relaxation when the tail decays faster than ln t
    (tempered/exponential tails), so a long horizon is an upper-bound stress case.  Returns a copy of p with U
    replaced and columns dV_extrap (V), b_mV_per_decade."""
    out = p.copy()
    rest = segs[(segs.type == "rest")]
    dv, bb = [], []
    t_all, V_all = df[t_col].to_numpy(), df[V_col].to_numpy()
    for _, r in p.iterrows():
        s = rest[(rest.cycle == r.cycle) & (rest.step == r.step)]
        if len(s) != 1:
            raise RuntimeError(f"{lid}: rest (cycle {r.cycle}, step {r.step}) not unique in segments")
        i0, i1 = int(s.i_start.iloc[0]), int(s.i_end.iloc[0])
        tt = t_all[i0:i1 + 1] - t_all[i0]
        vv = V_all[i0:i1 + 1]
        if abs(vv[-1] - r.U) > 1e-9:
            raise RuntimeError(f"{lid}: rest end voltage does not match the relaxed point")
        m = tt >= t_fit_from_s
        b = np.polyfit(np.log(tt[m]), vv[m], 1)
        d = float(np.polyval(b, np.log(horizon_s)) - np.polyval(b, np.log(tt[-1]))) if horizon_s > tt[-1] else 0.0
        dv.append(d)
        bb.append(float(b[0] * np.log(10) * MV))
    out["dV_extrap"] = dv
    out["b_mV_per_decade"] = bb
    out["U"] = out["U"] + out["dV_extrap"]
    return out


def min_secant_slope(x: np.ndarray, U: np.ndarray, z_lo: float, z_hi: float, Q_axis: float, Q_ref: float) -> dict:
    """Smallest secant slope dU/dz between adjacent points whose z lies in [z_lo, z_hi].  By the mean-value theorem
    every differentiable interpolant through these points has min dU/dz <= this value on the span of the points,
    i.e. the data only bound kappa_1 FROM ABOVE; the value of kappa_1 itself is a property of the representation."""
    o = np.argsort(x)
    x, U = np.asarray(x, float)[o], np.asarray(U, float)[o]
    z = x_to_z(x, Q_axis, Q_ref)
    keep = (z >= z_lo - 1e-9) & (z <= z_hi + 1e-9)
    x, U, z = x[keep], U[keep], z[keep]
    if len(x) < 2:
        return dict(n=int(len(x)), min_secant_V_per_soc=None, z_mid=None)
    sl = (U[:-1] - U[1:]) / (z[:-1] - z[1:])
    k = int(np.argmin(sl))
    return dict(n=int(len(x)), min_secant_V_per_soc=float(sl[k]), z_mid=float(0.5 * (z[k] + z[k + 1])),
                max_secant_V_per_soc=float(sl.max()))


def max_curvature(model, z_lo: float, z_hi: float, Q_axis: float, Q_ref: float, n: int = 4001) -> float:
    """max |d2U/dz2| on [z_lo, z_hi] by central differences of dU/dz (V per unit SOC^2)."""
    z = np.linspace(z_lo, z_hi, n)
    d = soc_axis(model, z, Q_axis, Q_ref)[1]
    return float(np.max(np.abs(np.gradient(d, z))))


def alignment_rmse(p1: pd.DataFrame, q2: np.ndarray, U2: np.ndarray, Q2: float, dq: float, core: tuple) -> float:
    """Cross-cell RMSE (V) between cell 1 (branch-averaged, fixed axis) and cell 2 re-mapped to x = (q + dq) / Q2,
    both directions (PCHIP of one cell evaluated at the other cell's points), inside the core x-range."""
    x2 = (np.asarray(q2) + dq) / Q2
    o = np.argsort(x2)
    x2, U2 = x2[o], np.asarray(U2)[o]
    if np.any(np.diff(x2) <= 0):
        return np.inf
    f1 = PchipInterpolator(p1.x.to_numpy(), p1.U.to_numpy(), extrapolate=False)
    f2 = PchipInterpolator(x2, U2, extrapolate=False)
    lo, hi = core
    e = []
    m2 = (x2 >= lo) & (x2 <= hi)
    e.append(f1(x2[m2]) - U2[m2])
    x1 = p1.x.to_numpy()
    m1 = (x1 >= lo) & (x1 <= hi)
    e.append(f2(x1[m1]) - p1.U.to_numpy()[m1])
    e = np.concatenate(e)
    e = e[np.isfinite(e)]
    return float(np.sqrt(np.mean(e**2))) if len(e) else np.inf


def grid_edge(hp: dict, grid: list[dict]) -> dict:
    """Which numeric hyper-parameters of hp sit at the minimum or maximum of their grid (empty dict = interior)."""
    flags = {}
    for k, v in hp.items():
        if not isinstance(v, (int, float)) or isinstance(v, bool):
            continue
        vals = sorted({g[k] for g in grid if k in g})
        if len(vals) < 2:
            continue
        if v == vals[0]:
            flags[k] = "min"
        elif v == vals[-1]:
            flags[k] = "max"
    return flags
