"""Benchmark SOC estimators (FO-EKF, EKF and Sage-Husa AEKF on the 2RC model, Coulomb counting).

All are called through ``tfso.observer.run_estimator`` (common interface, see that module).  Literature
formulations followed and every simplification are stated in the docstrings of ``_run_foekf`` and
``_run_ekf2rc``.  Scalar (pure-Python float) implementations exploit the diagonal state-transition
matrices, so the per-sample cost is dominated by the interpreter, not by 2x2/3x3 matrix calls.
Every method evaluates the OCV ONCE per sample inside the timed loop (at the prior SOC, for the
innovation and the one-step-ahead output); the a-posteriori output ``Vt_hat`` is reconstructed after the
loop (vectorised, outside the timed region).
"""
from __future__ import annotations

import math
import time
import warnings

import numpy as np

from .observer import (N_SCALAR_ALLOWANCE, SOC_CLIP, _result, gl_weights_general, model_constants,
                       resolve_memory)

__all__ = ["foekf_model", "ekf2rc_model", "ekf2rc_step_functions", "foekf_step_functions"]


# ---------------------------------------------------------------------------
# FO-EKF (Sierociuk-Dzielinski fractional Kalman filter, Mu et al. 2017 battery formulation)
# ---------------------------------------------------------------------------
def foekf_model(params: dict, h: float, discretisation: str = "implicit"):
    """GL state-space model of the FO-EKF (untempered, lambda forced to 0), state x_k = [z_k, Vp_k].

    SOC channel (integer order, exact for ZOH current): z_k = z_{k-1} + h beta I_{k-1}  (B0 = h beta).

    'implicit' (default; the project discretisation used in identification and inside every observer,
    with the 'causal' input timing of tfso.model: the input sample is I_{k-1}, the current held on
    [t_{k-1}, t_k)):
        (1 + h^a a_p) Vp_k = h^a b_p I_{k-1} - sum_{j>=1} omega_j Vp_{k-j}
        => Vp_k = F11 Vp_{k-1} + B1 I_{k-1} - sum_{j>=2} (omega_j/den) Vp_{k-j},
        den = 1 + h^a a_p, F11 = -omega_1/den = alpha/den, B1 = h^a b_p/den, memory weights omega_j/den.
    'explicit' (the literal Sierociuk-Dzielinski / Mu et al. form):
        Vp_k = (alpha - h^a a_p) Vp_{k-1} + h^a b_p I_{k-1} - sum_{j>=2} omega_j Vp_{k-j};
        stable only if h^a a_p < 2^alpha (flagged).
    y_k = U(z_k) + R0 I_k + Vp_k,  H_k = [U'(z_k), 1].
    Returns dict(F11, B0, B1, mem_scale, input_lag, alpha, ha, ap, bp, beta, explicit_stable)."""
    alpha = float(params["alpha"])
    c = model_constants(params)
    ha = h ** alpha
    if discretisation == "implicit":
        den = 1.0 + ha * c["ap"]
        return dict(F00=1.0, F11=alpha / den, B0=h * c["beta"], B1=ha * c["bp"] / den, mem_scale=1.0 / den,
                    input_lag=1, alpha=alpha, ha=ha, ap=c["ap"], bp=c["bp"], beta=c["beta"], den=den,
                    discretisation="implicit", explicit_stable=None)
    if discretisation == "explicit":
        return dict(F00=1.0, F11=alpha - ha * c["ap"], B0=h * c["beta"], B1=ha * c["bp"], mem_scale=1.0,
                    input_lag=1, alpha=alpha, ha=ha, ap=c["ap"], bp=c["bp"], beta=c["beta"], den=1.0,
                    discretisation="explicit", explicit_stable=bool(ha * c["ap"] < 2.0 ** alpha))
    raise ValueError("discretisation must be 'implicit' or 'explicit'")


def _run_foekf(params, hyper, I, V, Io, h, z0, ocv, method="FOEKF"):
    """Fractional-order EKF.

    Formulation followed: the fractional Kalman filter (FKF) of Sierociuk & Dzielinski (2006) in the
    battery form of Mu et al. (2017, Applied Energy 207, ``mu2017novel``; the same structure is used by
    ``xiong2019novel`` and ``hu2018coestimation``): GL discretisation of the commensurate model with
    orders (1, alpha) for (z, Vp), prediction

        x^-_k = F x_{k-1} + B u - sum_{j=2}^{m_k} Upsilon_j x_{k-j}
        P^-_k = F P_{k-1} F^T + Q + sum_{j=2}^{m_k} Upsilon_j P_{k-j} Upsilon_j^T,

    and the standard EKF measurement update with H_k = [U'(z^-_k), 1].  Because the SOC channel is of
    integer order, Upsilon_j = diag(0, s omega_j^{(alpha)}) for j >= 2 (s = mem_scale), so the covariance
    memory term is ``diag(0, sum_j (s omega_j)^2 P22_{k-j})``.

    Deviation from mu2017novel (stated): by default the prediction uses the IMPLICIT GL recursion of the
    project model (``foekf_model``, 'implicit'; the discretisation with which the FO parameters are
    identified and which every other observer uses), so F11 = alpha/(1 + h^a a_p), the input enters as
    h^a b_p I_{k-1}/(1 + h^a a_p) ('causal' timing of tfso.model: the current held on [t_{k-1}, t_k); the
    output uses R0 I_k) and the memory is divided by (1 + h^a a_p).  With zero Kalman gains (Q = 0,
    P0 = 0) the prediction reproduces tfso.model.simulate(FO parameters, timing='causal').  The literal explicit form is
    available with hyper['discretisation'] = 'explicit' (its stability condition h^a a_p < 2^alpha is
    recorded in flags['explicit_stable'] and a warning is issued when it fails).

    Simplifications (stated): (i) untempered model (lambda = 0) as in the cited papers; (ii) the
    cross-covariances E[(x_l - xh_l)(x_m - xh_m)^T], l != m, of the memory terms are neglected (the
    standard FKF assumption of Sierociuk-Dzielinski); (iii) the memory sums use posterior estimates
    and are truncated at N_L samples (short-memory principle, same memory length as the TFO);
    (iv) Q, R, P0 are constant diagonal hyper-parameters (no adaptation); (v) cold start (empty memory);
    (vi) the output Jacobian is evaluated at the prior z^-_k; (vii) the measured current I_{k-1} is treated
    as noise-free input in the prediction (its noise is absorbed in Q).
    """
    disc = str(hyper.get("discretisation", "implicit"))
    m = foekf_model(params, h, disc)
    R0 = float(params["R0"])
    alpha = m["alpha"]
    F11, B0, B1, sc, lag = m["F11"], m["B0"], m["B1"], m["mem_scale"], m["input_lag"]
    if disc == "explicit" and not m["explicit_stable"]:
        warnings.warn(f"FOEKF explicit GL unstable: h^a a_p = {m['ha'] * m['ap']:.3g} >= 2^a = {2 ** alpha:.3g}",
                      RuntimeWarning)
    q0, q1 = [float(v) for v in hyper["Q"]]
    Rm = float(hyper["R"])
    P0 = hyper["P0"]
    zmin, zmax = hyper.get("soc_clip", SOC_CLIP)
    N = I.size - 1
    mem_info = resolve_memory(hyper, N, h)
    full, NL = mem_info["full_memory"], mem_info["N_L_used"]
    om = gl_weights_general(alpha, 0.0, h, NL)
    wm = sc * om[1:].copy()
    wm[0] = 0.0                                   # j = 1 is inside F
    wrev = wm[::-1].copy()                        # (s omega_NL, ..., s omega_2, 0)
    wrev2 = wrev * wrev
    bufv = np.zeros(2 * NL)
    bufp = np.zeros(2 * NL)
    pos = 0
    Il, Vl, Iol = I.tolist(), V.tolist(), Io.tolist()
    both = ocv.both
    zhat = np.empty(N + 1)
    Vp = np.empty(N + 1)
    Vtm = np.empty(N + 1)
    nclip = 0
    dot = np.dot
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    z, v = float(z0), 0.0
    p00, p01, p11 = float(P0[0]), 0.0, float(P0[1])
    Uz, _ = both(z)
    zhat[0], Vp[0], Vtm[0] = z, v, Uz + R0 * Iol[0] + v
    bufv[pos] = v; bufv[pos + NL] = v
    bufp[pos] = p11; bufp[pos + NL] = p11
    pos = (pos + 1) % NL
    for k in range(1, N + 1):
        Ik1 = Il[k - 1]
        Iin = Ik1 if lag else Il[k]                 # lag = 1 for both discretisations ('causal' timing)
        memv = float(dot(wrev, bufv[pos:pos + NL]))
        memp = float(dot(wrev2, bufp[pos:pos + NL]))
        # prediction
        z = z + B0 * Ik1
        v = F11 * v + B1 * Iin - memv
        p00 = p00 + q0
        p01 = F11 * p01
        p11 = F11 * F11 * p11 + q1 + memp
        if z < zmin:
            z = zmin; nclip += 1
        elif z > zmax:
            z = zmax; nclip += 1
        # update
        Uz, d = both(z)
        yprior = Uz + R0 * Iol[k] + v
        Vtm[k] = yprior
        innov = Vl[k] - yprior
        c0 = p00 * d + p01
        c1 = p01 * d + p11
        S = d * c0 + c1 + Rm
        k0, k1 = c0 / S, c1 / S
        z = z + k0 * innov
        v = v + k1 * innov
        p00 = p00 - k0 * c0
        p01 = p01 - k0 * c1
        p11 = p11 - k1 * c1
        if z < zmin:
            z = zmin; nclip += 1
        elif z > zmax:
            z = zmax; nclip += 1
        bufv[pos] = v; bufv[pos + NL] = v
        bufp[pos] = p11; bufp[pos + NL] = p11
        pos = (pos + 1) % NL
        zhat[k] = z
        Vp[k] = v
    cpu, wall = time.process_time() - t_c0, time.perf_counter() - t_w0
    Vt = ocv.U(zhat) + R0 * Io + Vp                    # a-posteriori output, outside the timed loop
    nbytes = 8 * (bufv.size + bufp.size + wrev.size + wrev2.size + 3 + N_SCALAR_ALLOWANCE)
    flags = dict(soc_clip_count=nclip, nonfinite=bool(not np.all(np.isfinite(zhat))), **mem_info,
                 P_final=[p00, p01, p11], discretisation=disc, explicit_stable=m["explicit_stable"])
    hyper_used = dict(Q=[q0, q1], R=Rm, P0=list(map(float, P0)), N_L=mem_info["N_L_requested"],
                      L_s=mem_info["L_s_requested"], alpha=alpha, discretisation=disc, soc_clip=[zmin, zmax])
    return _result(method, zhat, Vt, Vp, cpu, wall, NL, nbytes, flags, hyper_used, Vt_prior=Vtm)


# ---------------------------------------------------------------------------
# EKF / AEKF on the 2RC model
# ---------------------------------------------------------------------------
def ekf2rc_model(params: dict, h: float) -> dict:
    """Exact ZOH discretisation of the 2RC model (Plett 2004); params R0, R1, R2 and tau1, tau2 [s]
    (tfso.model.TwoRCParams) or C1, C2 [F]:
    z_k = z_{k-1} + B0 I_{k-1} with B0 = h beta;  V_i,k = e_i V_i,k-1 + R_i (1 - e_i) I_{k-1},
    e_i = exp(-h/(R_i C_i));  y_k = U(z_k) + R0 I_k + V_1,k + V_2,k.  This is the 'causal' timing of
    tfso.model (model.polarisation_2rc with u = drive(I, 1)) with which the 2RC parameters are identified."""
    c = model_constants(params)
    R1, R2 = float(params["R1"]), float(params["R2"])
    tau1 = float(params["tau1"]) if "tau1" in params else R1 * float(params["C1"])
    tau2 = float(params["tau2"]) if "tau2" in params else R2 * float(params["C2"])
    e1 = math.exp(-h / tau1)
    e2 = math.exp(-h / tau2)
    return dict(beta=c["beta"], B0=h * c["beta"], e1=e1, e2=e2, g1=R1 * (1.0 - e1), g2=R2 * (1.0 - e2),
                R0=float(params["R0"]), h=h, tau1=tau1, tau2=tau2)


def _run_ekf2rc(params, hyper, I, V, Io, h, z0, ocv, adaptive=False, method="EKF2RC"):
    """EKF (Plett 2004, Part 3, 'plett2004estimation') on the 2RC model, states [z, V1, V2].

    Time update with I_{k-1} (z_k^- = z_{k-1} + h beta I_{k-1}), measurement update with V_k and I_k
    (no update at k = 0); P^- = A P A^T + Q with A = diag(1, e1, e2); K = P^- H^T / (H P^- H^T + R),
    H = [U'(z^-), 1, 1]; P = P^- - K S K^T (symmetric storage).  Simplifications w.r.t. Plett's enhanced
    self-correcting cell model: no hysteresis state, no low-pass 'zero-state' filter; the 2RC parameters
    are the identified ones (tfso.model.TwoRCParams); Q, R, P0 constant and diagonal.

    adaptive=True ('AEKF2RC'): the Sage-Husa estimator of the noise statistics (Sage & Husa 1969,
    ``sage1969algorithms``, DOI 10.1109/SAP.1969.269927) with the exponential fading-memory weights
    d_k = (1 - b)/(1 - b^{k+1}) (k = 1, 2, ...), the form used in adaptive battery EKFs (the adaptive
    FO-EKF of ``song2024adaptive`` uses Sage-Husa adaptation per its abstract; its full text was not
    accessible, so its exact variant is NOT claimed to be reproduced):
        R_k = (1 - d_k) R_{k-1} + d_k (eps_k^2 - H P^- H^T)             (floored at R_min, counted)
        Q_k = (1 - d_k) Q_{k-1} + d_k (K eps^2 K^T + P_k - A P_{k-1} A^T) = Q_{k-1} + d_k K (eps^2 - S) K^T,
    of which only the diagonal is kept (floored at Q_min, counted).  Simplifications (stated): noise
    means are not estimated (zero-mean assumption); Q is kept diagonal; floors replace the
    positive-definiteness loss of the unbiased Sage-Husa estimator.  The recursion is fully specified by
    these equations and one hyper-parameter (b), hence reproducible; the fault-tolerant variant of
    rout2024online depends on unpublished switching thresholds and was not chosen.
    """
    m = ekf2rc_model(params, h)
    B0, e1, e2, g1, g2, R0 = m["B0"], m["e1"], m["e2"], m["g1"], m["g2"], m["R0"]
    q0, q1, q2 = [float(v) for v in hyper["Q"]]
    Rm = float(hyper["R"])
    P0 = hyper["P0"]
    zmin, zmax = hyper.get("soc_clip", SOC_CLIP)
    b = float(hyper.get("b", 0.995)) if adaptive else 0.0
    Rmin = float(hyper.get("R_min", 1e-8))
    Qmin = [float(v) for v in hyper.get("Q_min", [1e-14, 1e-12, 1e-12])]
    N = I.size - 1
    Il, Vl, Iol = I.tolist(), V.tolist(), Io.tolist()
    both = ocv.both
    zhat = np.empty(N + 1)
    Vp = np.empty(N + 1)
    Vtm = np.empty(N + 1)
    nclip = nR = nQ = 0
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    z, v1, v2 = float(z0), 0.0, 0.0
    p00, p11, p22 = float(P0[0]), float(P0[1]), float(P0[2])
    p01 = p02 = p12 = 0.0
    Uz, _ = both(z)
    zhat[0], Vp[0], Vtm[0] = z, 0.0, Uz + R0 * Iol[0]
    bk = 1.0
    for k in range(1, N + 1):
        Ik1 = Il[k - 1]
        z = z + B0 * Ik1
        v1 = e1 * v1 + g1 * Ik1
        v2 = e2 * v2 + g2 * Ik1
        p00 = p00 + q0
        p01 = e1 * p01
        p02 = e2 * p02
        p11 = e1 * e1 * p11 + q1
        p12 = e1 * e2 * p12
        p22 = e2 * e2 * p22 + q2
        if z < zmin:
            z = zmin; nclip += 1
        elif z > zmax:
            z = zmax; nclip += 1
        Uz, d = both(z)
        yprior = Uz + R0 * Iol[k] + v1 + v2
        Vtm[k] = yprior
        innov = Vl[k] - yprior
        c0 = p00 * d + p01 + p02
        c1 = p01 * d + p11 + p12
        c2 = p02 * d + p12 + p22
        HPH = d * c0 + c1 + c2
        if adaptive:
            bk *= b
            dk = (1.0 - b) / (1.0 - bk * b)
            Rn = (1.0 - dk) * Rm + dk * (innov * innov - HPH)
            if Rn < Rmin:
                Rn = Rmin; nR += 1
            Rm = Rn
        S = HPH + Rm
        k0, k1, k2 = c0 / S, c1 / S, c2 / S
        z = z + k0 * innov
        v1 = v1 + k1 * innov
        v2 = v2 + k2 * innov
        p00 -= k0 * c0
        p01 -= k0 * c1
        p02 -= k0 * c2
        p11 -= k1 * c1
        p12 -= k1 * c2
        p22 -= k2 * c2
        if adaptive:
            f = dk * (innov * innov - S)
            q0n, q1n, q2n = q0 + f * k0 * k0, q1 + f * k1 * k1, q2 + f * k2 * k2
            if q0n < Qmin[0]:
                q0n = Qmin[0]; nQ += 1
            if q1n < Qmin[1]:
                q1n = Qmin[1]; nQ += 1
            if q2n < Qmin[2]:
                q2n = Qmin[2]; nQ += 1
            q0, q1, q2 = q0n, q1n, q2n
        if z < zmin:
            z = zmin; nclip += 1
        elif z > zmax:
            z = zmax; nclip += 1
        zhat[k] = z
        Vp[k] = v1 + v2
    cpu, wall = time.process_time() - t_c0, time.perf_counter() - t_w0
    Vt = ocv.U(zhat) + R0 * Io + Vp                    # a-posteriori output, outside the timed loop
    # covariance 6 (+ adaptive Q 3, R 1) + fixed allowance
    nscal = 6 + (4 if adaptive else 0) + N_SCALAR_ALLOWANCE
    flags = dict(soc_clip_count=nclip, nonfinite=bool(not np.all(np.isfinite(zhat))),
                 P_final=[p00, p11, p22])
    if adaptive:
        flags.update(R_floor_count=nR, Q_floor_count=nQ, R_final=Rm, Q_final=[q0, q1, q2])
    hyper_used = dict(Q=[float(v) for v in hyper["Q"]], R=float(hyper["R"]), P0=list(map(float, P0)),
                      soc_clip=[zmin, zmax])
    if adaptive:
        hyper_used.update(b=b, R_min=Rmin, Q_min=Qmin)
    return _result(method, zhat, Vt, Vp, cpu, wall, 0, 8 * nscal, flags, hyper_used, Vt_prior=Vtm)


# ---------------------------------------------------------------------------
# Coulomb counting
# ---------------------------------------------------------------------------
def _run_cc(params, hyper, I, V, h, z0, method="CC"):
    """z_k = z_{k-1} + h beta I_{k-1}, as a per-sample loop (same loop structure as the other methods,
    so its timing is comparable)."""
    B0 = h * model_constants(params)["beta"]
    N = I.size - 1
    Il = I.tolist()
    zhat = np.empty(N + 1)
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    z = float(z0)
    zhat[0] = z
    for k in range(1, N + 1):
        z = z + B0 * Il[k - 1]
        zhat[k] = z
    cpu, wall = time.process_time() - t_c0, time.perf_counter() - t_w0
    return _result(method, zhat, None, None, cpu, wall, 0, 8 * N_SCALAR_ALLOWANCE,
                   dict(soc_clip_count=0, nonfinite=bool(not np.all(np.isfinite(zhat)))), {})


# ---------------------------------------------------------------------------
# Model/Jacobian functions used by the filters (exposed for the finite-difference tests)
# ---------------------------------------------------------------------------
def ekf2rc_step_functions(params: dict, ocv, h: float) -> dict:
    """Functions of the 2RC EKF: f(x, I_prev) (time update), F(x) (its Jacobian, = diag(1, e1, e2)),
    g(x, I) (output) and G(x) (output Jacobian [U'(z), 1, 1]) exactly as used inside ``_run_ekf2rc``."""
    from .observer import as_fast_ocv
    m = ekf2rc_model(params, h)
    o = as_fast_ocv(ocv)

    def f(x, I_prev):
        x = np.asarray(x, float)
        return np.array([x[0] + m["B0"] * I_prev, m["e1"] * x[1] + m["g1"] * I_prev,
                         m["e2"] * x[2] + m["g2"] * I_prev])

    def F(x):
        return np.diag([1.0, m["e1"], m["e2"]])

    def g(x, I):
        return o.U_s(float(x[0])) + m["R0"] * I + float(x[1]) + float(x[2])

    def G(x):
        return np.array([o.dU_s(float(x[0])), 1.0, 1.0])

    return dict(f=f, F=F, g=g, G=G, model=m)


def foekf_step_functions(params: dict, ocv, h: float, discretisation: str = "implicit") -> dict:
    """Functions of the FO-EKF: f(x, I_prev, I_now, mem) (prediction given the memory sum of Vp,
    mem = sum_{j>=2} s omega_j Vp_{k-j}), F(x) = diag(1, F11), g(x, I), G(x) = [U'(z), 1]."""
    from .observer import as_fast_ocv
    m = foekf_model(params, h, discretisation)
    o = as_fast_ocv(ocv)
    R0 = float(params["R0"])

    def f(x, I_prev, I_now=None, mem=0.0):
        x = np.asarray(x, float)
        Iin = I_prev if m["input_lag"] else (I_prev if I_now is None else I_now)
        return np.array([x[0] + m["B0"] * I_prev, m["F11"] * x[1] + m["B1"] * Iin - mem])

    def F(x):
        return np.diag([1.0, m["F11"]])

    def g(x, I):
        return o.U_s(float(x[0])) + R0 * I + float(x[1])

    def G(x):
        return np.array([o.dU_s(float(x[0])), 1.0])

    return dict(f=f, F=F, g=g, G=G, model=m)
