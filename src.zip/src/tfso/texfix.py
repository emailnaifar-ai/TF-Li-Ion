"""Final typesetting pass for the generated LaTeX tables (units through siunitx, wording, caption sources).

The table writers of the analysis scripts build their LaTeX line by line; ``finalize_table`` is applied to the
complete text just before it is written. It changes only the LaTeX code part of each line (the text before an
unescaped ``%``), never a number or a ``% src:`` comment:

* hand-written units are replaced by siunitx commands (``400~s`` -> ``\\SI{400}{\\second}``,
  ``25\\,$^\\circ$C`` -> ``\\SI{25}{\\celsius}``, ``95\\,\\%`` -> ``\\SI{95}{\\percent}``, ...);
* ``file``/``files`` become ``record``/``records`` (the manuscript's term for a measured record);
* every caption line that carries no ``% src:`` comment receives the one given by the writer.
"""
from __future__ import annotations

import re

_NUM = r"(\d+(?:\.\d+)?)"

# order matters: specific patterns before generic ones
_RULES: list[tuple[str, str]] = [
    # $\lambda=10^{-4}$\,s$^{-1}$  ->  $\lambda=\SI{e-4}{\per\second}$
    (r"\$([^$]*?)10\^\{(-?\d+)\}\$(?:~|\\,)s\$\^\{-1\}\$", r"$\1\\SI{e\2}{\\per\\second}$"),
    # $h=1$\,s, $L=400$\,s, $t-t_0\ge600$~s  ->  $h=\SI{1}{\second}$ ...
    (r"\$([^$]*?)" + _NUM + r"\$(?:~|\\,)s\b", r"$\1\\SI{\2}{\\second}$"),
    # 25/45\,$^\circ$C -> \SI{25}{\celsius}/\SI{45}{\celsius}
    (_NUM + r"/" + _NUM + r"\\,\$\^\\circ\$C", r"\\SI{\1}{\\celsius}/\\SI{\2}{\\celsius}"),
    (_NUM + r"\\,\$\^\\circ\$C", r"\\SI{\1}{\\celsius}"),
    # $\pm0.05$\% -> $\pm\SI{0.05}{\percent}$ ; $...=0.5$\,\% -> $...=\SI{0.5}{\percent}$
    (r"\$([^$]*?)" + _NUM + r"\$(?:\\,)?\\%", r"$\1\\SI{\2}{\\percent}$"),
    # ranges and relations: 5--21\,\% -> \SIrange{5}{21}{\percent}; \leq2\,\% -> \leq\SI{2}{\percent}
    (r"(?<![\w.{$^])" + _NUM + r"--" + _NUM + r"(?:\\,)?\\%", r"\\SIrange{\1}{\2}{\\percent}"),
    (r"(\\le(?:q)?)" + _NUM + r"(?:\\,)?\\%", r"\1\\SI{\2}{\\percent}"),
    # plain numbers with units
    (r"(?<![\w.{$^])" + _NUM + r"(?:\\,)?\\%", r"\\SI{\1}{\\percent}"),
    (r"(?<![\w.{$^])" + _NUM + r"(?:~|\\,)s\b", r"\\SI{\1}{\\second}"),
    (r"(?<![\w.{$^])" + _NUM + r"\\,kB\b", r"\\SI{\1}{kB}"),
    (r"\$\\mu\$s\b", r"\\si{\\micro\\second}"),
    (r"\(s; ", r"(\\si{\\second}; "),
    (r"(?<=\s)\(s\)", r"(\\si{\\second})"),
    (r"\bin mV\b", r"in \\si{\\milli\\volt}"),
    (r"\$L\$ \(s\)", r"$L$ (\\si{\\second})"),
    # wording
    (r"\bfiles\b", "records"),
    (r"\bfile\b", "record"),
    (r"\bFiles\b", "Records"),
    (r"\bper-record\b", "per-record"),
    (r"\bPer-file\b", "Per-record"),
    (r"\bper-file\b", "per-record"),
]
_COMPILED = [(re.compile(p), r) for p, r in _RULES]
_UNESCAPED_PCT = re.compile(r"(?<!\\)%")


def _split_comment(line: str) -> tuple[str, str]:
    m = _UNESCAPED_PCT.search(line)
    return (line, "") if m is None else (line[:m.start()], line[m.start():])


def fix_code(code: str) -> str:
    for rx, rep in _COMPILED:
        code = rx.sub(rep, code)
    return code


def finalize_table(text: str, caption_src: str | None = None) -> str:
    """Apply the unit and wording rules to the code part of every line; add ``caption_src`` to caption lines."""
    out = []
    for line in text.split("\n"):
        code, comment = _split_comment(line)
        if code.lstrip().startswith("%"):
            out.append(line)
            continue
        code = fix_code(code)
        if caption_src and "\\caption{" in code and "% src:" not in comment:
            comment = (comment + " " if comment else "") + "% src: " + caption_src
            code = code.rstrip() + " "
        out.append(code + comment)
    return "\n".join(out)
