"""SOC estimators of the TFSO study with one common interface (``run_estimator``).

Methods
-------
``'TFO'``     proposed tempered fractional observer: the sampled-data, semi-implicit, finite-memory
              recursion eq:m4b:observer / eq:obs:disc of the manuscript, implemented literally, with the
              input sample u_{m,n} := I_{m,n-1} = the measured current applied on [t_{n-1}, t_n):

                  z_n   = z_{n-1} + h [beta u_{m,n} + l1 ytilde_{n-1}]                  (explicit Euler)
                  (1 + h^a (a_p + l2)) Vp_n = h^a [b_p u_{m,n} + l2 (V_n - U(z_n) - R0 I_{m,n})]
                                              - sum_{j=1}^{min(n,N_L)} omega_j^{(a,lam)} Vp_{n-j}
                  Vt_n  = U(z_n) + R0 I_{m,n} + Vp_n,   ytilde_n = V_n - Vt_n,

              with Vp_0 = 0 (the Caputo correction term vanishes), ytilde_0 = V_0 - U(z_0) - R0 I_0,
              a doubled ring buffer of the last N_L values of Vp (``tempered._RingBuffer`` layout) and
              the weights generated once by the product recursion (``tempered.gl_weights``).
              INPUT TIMING (P0 alignment, 2026-09-27): this is the 'causal' convention of ``tfso.model``
              (TIMING['causal']) with which every parameter set is identified: SOC and polarisation are
              driven by u_n = I_{n-1} (no anticipation: Vp_n depends only on the current that flowed before
              t_n) and the output term R0 I uses the grid current I_n (``I_out``).  With l1 = l2 = 0 the
              recursion reproduces ``tfso.model.simulate(..., timing='causal')`` (scripts/p0_timing_alignment.py,
              results/timing_alignment.json).  The earlier implementation drove Vp with I_{m,n}
              (model timing 'implicit_forward').
              Full memory (m_n = n) when the memory is None / 'full' or N_L >= N.  SOC clipping to
              [-0.05, 1.05] is a numerical safeguard only and is counted in ``flags``.
``'FOO'``     the same observer with lambda = 0 (untempered fractional observer); own parameters/gains.
(the four benchmarks below live in ``tfso.benchmarks``)
``'FOEKF'``   fractional-order EKF on the untempered model, state [z, Vp]: the fractional Kalman filter
              of Sierociuk & Dzielinski (2006) in the battery form of Mu et al. (2017, ``mu2017novel``),
              with the IMPLICIT GL prediction of the project model by default (see ``_run_foekf``).
``'EKF2RC'``  conventional EKF on the 2RC model with exact ZOH discretisation (Plett 2004, ``plett2004estimation``).
``'AEKF2RC'`` Sage-Husa adaptive EKF on the same 2RC model (Sage & Husa 1969, ``sage1969algorithms``).
``'CC'``      Coulomb counting from z0 (open loop).

Common interface
----------------
``run_estimator(method, params, hyper, I_m, V_m, h, z0, ocv, I_out=None) -> dict`` with keys
``zhat, Vt_hat, Vt_prior, Vp_hat (or None), cpu_process_s, cpu_per_sample_us, wall_s, n_history_samples,
bytes_state, flags, method, hyper_used``.

* ``I_m`` [A] (> 0 charge) and ``V_m`` [V] on the uniform grid t_n = n h, n = 0..N; I_n is held
  (zero-order hold) on [t_n, t_{n+1}), so the dynamics (SOC and every polarisation branch of every
  method) are driven by u_n = I_{m,n-1}, the current applied on [t_{n-1}, t_n) ('causal' timing of
  ``tfso.model``; I_{m,N} enters only the output term).
  ``I_out`` (optional, same length) is the current used in the OUTPUT terms R0 I (output equation,
  innovation, l2 injection); default ``I_out = I_m`` (= the grid current I_n, exactly the output
  current of ``tfso.model.simulate`` at h = 1 s).  For signals re-gridded to a coarser h
  (``experiments.resample_case``) it is the 1 s grid current at t_n, i.e. the same output current as
  the identified model at t_n, while the dynamics are driven by the coarse held mean u_n = I_{m,n-1}.
* ``params``: ``alpha, lam, R0, Rp, Cp`` (or ``ap, bp``) for TFO/FOO/FOEKF; ``R0, R1, R2`` and
  ``tau1, tau2`` (or ``C1, C2``) for the 2RC filters; ``s, dq`` (OCV alignment; REQUIRED when the OCV
  is a ``tfso.model.AlignedOCV``); ``Qn`` [Ah] (= Q_id(T), never Q_ref) and ``eta``; optionally ``ocv``.
* ``ocv``: the aligned OCV object: a ``tfso.model.AlignedOCV`` (alignment s, dq from ``params``), anything
  with vectorised ``U(z)`` and ``dU(z)``, a tuple ``(U, dU)`` or a prebuilt ``FastOCV``; if None,
  ``params['ocv']`` is used.  It is tabulated once on a fine uniform z grid and evaluated per step by
  cubic Hermite interpolation of (U, dU) (``FastOCV``; measured on the aligned PCHIP OCVs at 0/25/45 C:
  |U error| <= 3.3e-10 V, |dU/dz error| <= 6.1e-5 V per unit SOC; exact for a linear OCV).  The table
  is model data and is NOT counted in ``bytes_state``.
* Memory (TFO/FOO/FOEKF): ``hyper['L_s']`` (memory length in SECONDS; N_L = ceil(L_s / h)) or
  ``hyper['N_L']`` (samples); None or 'full' = full memory.  N_L < 1 raises.  ``flags`` records
  ``N_L_requested``, ``N_L_used`` (= min(N_L_requested, N)) and ``full_memory`` (True when the run is
  numerically a full-memory run, i.e. no memory requested or N_L_requested >= N).
* Outputs: ``Vt_prior`` is the ONE-STEP-AHEAD (a-priori) output prediction, formed before V_n is used
  (TFO/FOO: U(zhat_n) + R0 I_out,n + Vp^-_n with Vp^-_n the implicit update without the l2 injection;
  Kalman filters: U(z^-_n) + R0 I_out,n + Vp^-_n); ``Vt_hat`` is the a-posteriori output (after the
  measurement at n has been used).  Voltage-fidelity metrics use ``Vt_prior``.
* ``cpu_process_s`` is ``time.process_time()`` over the estimation loop only (table building, weight
  generation, array allocation and the a-posteriori output reconstruction excluded).  The Windows
  process-time clock ticks at 15.6 ms, so a single run is quantised; ``wall_s`` (``time.perf_counter``
  over the same loop) is the quantity used for timing, with repeats (``scripts/estimator_timing.py``).
* ``bytes_state`` (one rule for all methods): 8 bytes x [history buffers + stored weight vectors +
  error-covariance / adaptive-statistics entries (Kalman filters only) + a fixed allowance of 8 scalars
  for the recursion's own state and constants].  For TFO/FOO with finite N_L this equals
  ``tempered.cost_per_sample(N_L)['bytes'] = 8 (2 N_L + N_L + 8)``.

Units: SI; z dimensionless; l1 in V^-1 s^-1, l2 in s^-alpha; a_p in s^-alpha; b_p in Ohm s^-alpha.
"""
from __future__ import annotations

import math
import time
import warnings

import numpy as np

from . import tempered

__all__ = ["METHODS", "FastOCV", "as_fast_ocv", "gl_weights_general", "run_estimator", "resolve_memory",
           "model_constants", "design_observer_gains", "slope_bounds_fast", "SOC_CLIP", "bind_ocv",
           "N_SCALAR_ALLOWANCE", "INPUT_TIMING"]

METHODS = ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC")
SOC_CLIP = (-0.05, 1.05)
N_SCALAR_ALLOWANCE = 8          # fixed allowance (state + constants) in bytes_state, identical for all methods
INPUT_TIMING = "causal"         # tfso.model.TIMING key shared by every estimator (u_n = I_{n-1}; output R0 I_n)


# ---------------------------------------------------------------------------
# Fast scalar OCV
# ---------------------------------------------------------------------------
class FastOCV:
    """Tabulated OCV on a uniform z grid with cubic Hermite interpolation of (U, dU/dz).

    Parameters
    ----------
    U, dU : vectorised callables of z (V and V per unit SOC).
    z_lo, z_hi, n : table range and number of nodes (default [-0.2, 1.2], 28001 nodes, dz = 5e-5).

    ``U_s(z)`` / ``dU_s(z)`` / ``both(z)`` are scalar (pure-Python) evaluations; outside the table the
    function is continued linearly with the end slope.  ``U(z)`` / ``dU(z)`` are vectorised (numpy)
    versions of the same interpolant.  Hermite interpolation reproduces cubic polynomials exactly (so a
    linear OCV is reproduced to rounding); for a C^4 OCV the error is <= dz^4 max|U''''| / 384.
    """

    def __init__(self, U, dU, z_lo: float = -0.2, z_hi: float = 1.2, n: int = 28001):
        self.z_lo, self.z_hi, self.n = float(z_lo), float(z_hi), int(n)
        self.zg = np.linspace(self.z_lo, self.z_hi, self.n)
        self.dz = (self.z_hi - self.z_lo) / (self.n - 1)
        self.Ug = np.asarray(U(self.zg), dtype=float).copy()
        self.dUg = np.asarray(dU(self.zg), dtype=float).copy()
        if not (np.all(np.isfinite(self.Ug)) and np.all(np.isfinite(self.dUg))):
            raise ValueError("OCV table contains non-finite values")
        self._U = self.Ug.tolist()
        self._D = self.dUg.tolist()
        self._src = (U, dU)

    def both(self, z: float) -> tuple[float, float]:
        """(U(z), dU/dz(z)) for a Python float z."""
        dz = self.dz
        u = (z - self.z_lo) / dz
        if u <= 0.0:
            return self._U[0] + self._D[0] * (z - self.z_lo), self._D[0]
        if u >= self.n - 1:
            return self._U[-1] + self._D[-1] * (z - self.z_hi), self._D[-1]
        i = int(u)
        t = u - i
        y0, y1 = self._U[i], self._U[i + 1]
        m0, m1 = self._D[i] * dz, self._D[i + 1] * dz
        t2 = t * t
        t3 = t2 * t
        val = (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * m1
        der = ((6 * t2 - 6 * t) * y0 + (3 * t2 - 4 * t + 1) * m0 + (-6 * t2 + 6 * t) * y1 + (3 * t2 - 2 * t) * m1) / dz
        return val, der

    def U_s(self, z: float) -> float:
        return self.both(z)[0]

    def dU_s(self, z: float) -> float:
        return self.both(z)[1]

    def _vec(self, z):
        z = np.asarray(z, dtype=float)
        u = (z - self.z_lo) / self.dz
        i = np.clip(np.floor(u).astype(np.int64), 0, self.n - 2)
        t = u - i
        y0, y1 = self.Ug[i], self.Ug[i + 1]
        m0, m1 = self.dUg[i] * self.dz, self.dUg[i + 1] * self.dz
        t2, t3 = t * t, t * t * t
        val = (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * m1
        der = ((6 * t2 - 6 * t) * y0 + (3 * t2 - 4 * t + 1) * m0 + (-6 * t2 + 6 * t) * y1 + (3 * t2 - 2 * t) * m1) / self.dz
        lo, hi = u <= 0.0, u >= self.n - 1
        val = np.where(lo, self.Ug[0] + self.dUg[0] * (z - self.z_lo), val)
        der = np.where(lo, self.dUg[0], der)
        val = np.where(hi, self.Ug[-1] + self.dUg[-1] * (z - self.z_hi), val)
        der = np.where(hi, self.dUg[-1], der)
        return val, der

    def U(self, z):
        z = np.asarray(z, dtype=float)
        return self._vec(z)[0] if z.ndim else self.U_s(float(z))

    def dU(self, z):
        z = np.asarray(z, dtype=float)
        return self._vec(z)[1] if z.ndim else self.dU_s(float(z))

    def max_table_error(self, n_test: int = 5001) -> float:
        """Max |U_table - U_source| [V] at points between the nodes (self-check)."""
        z = np.linspace(self.z_lo + 0.37 * self.dz, self.z_hi - 0.63 * self.dz, n_test)
        return float(np.max(np.abs(self.U(z) - np.asarray(self._src[0](z), float))))

    def slope_range(self, lo: float, hi: float) -> tuple[float, float]:
        """(min, max) of dU/dz over the table nodes in [lo, hi] plus the two end points."""
        m = (self.zg >= lo) & (self.zg <= hi)
        d = np.concatenate([self.dUg[m], [self.dU_s(float(lo)), self.dU_s(float(hi))]])
        return float(np.min(d)), float(np.max(d))

    def invert(self, V: float, lo: float = -0.05, hi: float = 1.05) -> float:
        """z with U(z) = V by bisection on [lo, hi]; clipped to the ends.

        Raises ValueError if U is not strictly increasing on [lo, hi] (dU/dz <= 0 at a table node),
        because the inversion would then be ambiguous."""
        if self.slope_range(lo, hi)[0] <= 0.0:
            raise ValueError(f"OCV is not strictly increasing on [{lo}, {hi}]: inversion ambiguous")
        if V <= self.U_s(lo):
            return lo
        if V >= self.U_s(hi):
            return hi
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            if self.U_s(mid) < V:
                lo = mid
            else:
                hi = mid
            if hi - lo < 1e-13:
                break
        return 0.5 * (lo + hi)


def bind_ocv(ocv, s: float, dq: float):
    """(U(z), dU(z)) of a ``tfso.model.AlignedOCV``-like object (methods ``U(z, s, dq)``, ``dUdz(z, s, dq)``)
    with the alignment parameters (axis scale s, shift dq [Ah]) bound:
    x(z) = s ((1 - z) Q_axis + dq) / Q_SP2,25, U_al(z) = OCV_T(x(z))."""
    return (lambda z: ocv.U(z, s, dq)), (lambda z: ocv.dUdz(z, s, dq))


def as_fast_ocv(ocv, s: float | None = None, dq: float | None = None, **kw) -> FastOCV:
    """Wrap an OCV object into a FastOCV: a FastOCV (returned as is), a ``tfso.model.AlignedOCV``
    (``U(z, s, dq)``/``dUdz(z, s, dq)``; s and dq MUST be given: each model uses its own identified
    alignment, so a missing alignment raises instead of silently using s = 1, dq = 0), an object with
    vectorised ``.U(z)``/``.dU(z)``, a dict with keys U, dU, or a tuple ``(U, dU, ...)``."""
    if isinstance(ocv, FastOCV):
        return ocv
    if hasattr(ocv, "dUdz") and hasattr(ocv, "U"):
        if s is None or dq is None:
            raise ValueError("an AlignedOCV needs the model's alignment parameters s and dq (params['s'], params['dq'])")
        U, dU = bind_ocv(ocv, float(s), float(dq))
    elif isinstance(ocv, (tuple, list)):
        U, dU = ocv[0], ocv[1]
    elif hasattr(ocv, "U") and hasattr(ocv, "dU"):
        U, dU = ocv.U, ocv.dU
    elif isinstance(ocv, dict) and "U" in ocv and "dU" in ocv:
        U, dU = ocv["U"], ocv["dU"]
    else:
        raise TypeError("ocv must provide U(z) and dU(z)")
    return FastOCV(U, dU, **kw)


# ---------------------------------------------------------------------------
# Weights (alpha in (0, 1], used by FOEKF so that alpha = 1 is admissible)
# ---------------------------------------------------------------------------
def gl_weights_general(alpha: float, lam: float, h: float, N: int) -> np.ndarray:
    """``omega_j^{(alpha,lambda)}``, j = 0..N, for 0 < alpha <= 1 (alpha = 1: [1, -e^{-lam h}, 0, ...]).

    Identical to ``tempered.gl_weights`` for alpha in (0, 1) (same product recursion)."""
    if not (0.0 < alpha <= 1.0):
        raise ValueError("alpha must lie in (0, 1]")
    if alpha < 1.0:
        return tempered.gl_weights(alpha, lam, h, N)
    w = np.zeros(int(N) + 1)
    w[0] = 1.0
    if N >= 1:
        w[1] = -math.exp(-lam * h)
    return w


# ---------------------------------------------------------------------------
# Parameters, memory
# ---------------------------------------------------------------------------
def model_constants(params: dict) -> dict:
    """Derived constants: beta = eta/(3600 Qn) [1/(A s)], a_p, b_p for the fractional element."""
    out = {}
    Qn = float(params["Qn"])
    eta = float(params.get("eta", 1.0))
    out["beta"] = eta / (3600.0 * Qn)
    if "ap" in params and "bp" in params:
        out["ap"], out["bp"] = float(params["ap"]), float(params["bp"])
    elif "Rp" in params and "Cp" in params:
        out["ap"] = 1.0 / (float(params["Rp"]) * float(params["Cp"]))
        out["bp"] = 1.0 / float(params["Cp"])
    return out


def resolve_memory(hyper: dict, N: int, h: float) -> dict:
    """Memory of the GL recursion from ``hyper``: 'L_s' [s] (N_L = ceil(L_s/h)) takes precedence over
    'N_L' [samples]; None or 'full' = full memory.  Returns dict(N_L_requested (None = full),
    N_L_used = min(requested, N), full_memory, L_s_requested)."""
    L_s = hyper.get("L_s", None) if "L_s" in hyper else "absent"
    if L_s != "absent":
        if L_s is None or L_s == "full":
            req = None
        else:
            if not float(L_s) > 0:
                raise ValueError(f"memory length L_s must be > 0 (got {L_s})")
            req = int(math.ceil(float(L_s) / h - 1e-9))
        Ls = None if req is None else float(L_s)
    else:
        v = hyper.get("N_L", None)
        req = None if (v is None or v == "full") else int(v)
        Ls = None
    if req is not None and req < 1:
        raise ValueError(f"N_L must be >= 1 (got {req}); use None for full memory")
    full = req is None or req >= N
    return dict(N_L_requested=req, N_L_used=int(N if full else req), full_memory=bool(full), L_s_requested=Ls)


def _resolve_ocv(ocv, params, hyper):
    src = ocv if ocv is not None else params.get("ocv")
    if src is None:
        raise ValueError("an OCV object is required (argument ocv or params['ocv'])")
    kw = {}
    if hyper is not None and "ocv_table" in hyper:
        kw = dict(hyper["ocv_table"])
    return as_fast_ocv(src, s=params.get("s"), dq=params.get("dq"), **kw)


def _prep_signals(I_m, V_m, I_out=None):
    I = np.asarray(I_m, dtype=float)
    V = np.asarray(V_m, dtype=float)
    if I.shape != V.shape or I.ndim != 1:
        raise ValueError("I_m and V_m must be 1-D arrays of equal length")
    if I.size < 2:
        raise ValueError("need at least two samples")
    Io = I if I_out is None else np.asarray(I_out, dtype=float)
    if Io.shape != I.shape:
        raise ValueError("I_out must have the same shape as I_m")
    return I, V, Io


def _result(method, zhat, Vt, Vp, cpu, wall, n_hist, nbytes, flags, hyper_used, Vt_prior=None):
    N = max(len(zhat) - 1, 1)
    return dict(method=method, zhat=zhat, Vt_hat=Vt, Vt_prior=Vt_prior, Vp_hat=Vp, cpu_process_s=float(cpu),
                cpu_per_sample_us=float(cpu) / N * 1e6, wall_s=float(wall),
                wall_per_sample_us=float(wall) / N * 1e6, n_history_samples=int(n_hist),
                bytes_state=int(nbytes), flags=flags, hyper_used=hyper_used)


# ---------------------------------------------------------------------------
# TFO / FOO  (eq:m4b:observer)
# ---------------------------------------------------------------------------
def _run_tfo(params, hyper, I, V, Io, h, z0, ocv, lam_override=None, method="TFO"):
    alpha = float(params["alpha"])
    lam = float(params.get("lam", 0.0)) if lam_override is None else float(lam_override)
    R0 = float(params["R0"])
    c = model_constants(params)
    ap, bp, beta = c["ap"], c["bp"], c["beta"]
    l1, l2 = float(hyper["l1"]), float(hyper["l2"])
    zmin, zmax = hyper.get("soc_clip", SOC_CLIP)
    N = I.size - 1
    mem_info = resolve_memory(hyper, N, h)
    full, NL = mem_info["full_memory"], mem_info["N_L_used"]
    ha = h ** alpha
    den = 1.0 + ha * (ap + l2)
    den0 = 1.0 + ha * ap                      # prior (no l2 injection)
    om = tempered.gl_weights(alpha, lam, h, NL)
    Il, Vl, Iol = I.tolist(), V.tolist(), Io.tolist()
    both = ocv.both
    zhat = np.empty(N + 1)
    Vp = np.empty(N + 1)
    Vt = np.empty(N + 1)
    Vtm = np.empty(N + 1)
    nclip = 0
    if full:
        wrevF = om[1:][::-1].copy()          # (omega_N, ..., omega_1)
        hist = np.zeros(N + 1)               # Vp_0..Vp_N
    else:
        wrev = om[1:][::-1].copy()           # (omega_NL, ..., omega_1)
        buf = np.zeros(2 * NL)               # doubled ring buffer: window = buf[pos:pos+NL]
        pos = 0
    dot = np.dot
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    # n = 0: zhat_0 = z0, Vp_0 = 0 (Caputo correction vanishes)
    zh = float(z0)
    U0, _ = both(zh)
    vp = 0.0
    vt = U0 + R0 * Iol[0]
    ytil = Vl[0] - vt
    zhat[0], Vp[0], Vt[0], Vtm[0] = zh, vp, vt, vt
    if not full:
        buf[pos] = 0.0
        buf[pos + NL] = 0.0
        pos = (pos + 1) % NL
    for n in range(1, N + 1):
        zh = zh + h * (beta * Il[n - 1] + l1 * ytil)       # beta u_{m,n} = beta I_{m,n-1}
        if zh < zmin:
            zh = zmin
            nclip += 1
        elif zh > zmax:
            zh = zmax
            nclip += 1
        Uz, _ = both(zh)
        un = Il[n - 1]                                       # causal input sample: current on [t_{n-1}, t_n)
        Ion = Iol[n]
        if full:
            mem = float(dot(wrevF[N - n:], hist[:n]))
        else:
            mem = float(dot(wrev, buf[pos:pos + NL]))
        vfree = ha * bp * un - mem
        Vtm[n] = Uz + R0 * Ion + vfree / den0                # one-step-ahead output (before V_n is used)
        vp = (vfree + ha * l2 * (Vl[n] - Uz - R0 * Ion)) / den
        if full:
            hist[n] = vp
        else:
            buf[pos] = vp
            buf[pos + NL] = vp
            pos = (pos + 1) % NL
        vt = Uz + R0 * Ion + vp
        ytil = Vl[n] - vt
        zhat[n] = zh
        Vp[n] = vp
        Vt[n] = vt
    cpu, wall = time.process_time() - t_c0, time.perf_counter() - t_w0
    if full:
        n_hist = N
        nbytes = 8 * (hist.size + wrevF.size + N_SCALAR_ALLOWANCE)
    else:
        n_hist = NL
        nbytes = 8 * (buf.size + wrev.size + N_SCALAR_ALLOWANCE)   # = tempered.cost_per_sample(NL)['bytes']
    # positivity (S5) h l1 kappa_2 <= 1 on the whole clip range, and on the certified interval if given
    k2_clip = ocv.slope_range(zmin, zmax)[1]
    hlk = h * l1 * k2_clip
    flags = dict(soc_clip_count=nclip, nonfinite=bool(not np.all(np.isfinite(zhat))), **mem_info,
                 h_l1_kappa2_clip=float(hlk), positivity_ok=bool(hlk <= 1.0), kappa2_clip=float(k2_clip))
    zi = hyper.get("z_interval")
    if zi is not None:
        k2_int = ocv.slope_range(float(zi[0]), float(zi[1]))[1]
        flags.update(z_interval=[float(zi[0]), float(zi[1])], h_l1_kappa2_interval=float(h * l1 * k2_int),
                     n_outside_z_interval=int(np.sum((zhat < zi[0]) | (zhat > zi[1]))))
    if not flags["positivity_ok"]:
        warnings.warn(f"{method}: h*l1*kappa2 = {hlk:.3g} > 1 on the clip range (S5 violated)", RuntimeWarning)
    hyper_used = dict(l1=l1, l2=l2, N_L=mem_info["N_L_requested"], L_s=mem_info["L_s_requested"], lam=lam,
                      alpha=alpha, soc_clip=[zmin, zmax], input_timing=INPUT_TIMING)
    return _result(method, zhat, Vt, Vp, cpu, wall, n_hist, nbytes, flags, hyper_used, Vt_prior=Vtm)


# ---------------------------------------------------------------------------
# Common interface
# ---------------------------------------------------------------------------
def run_estimator(method: str, params: dict, hyper: dict, I_m: np.ndarray, V_m: np.ndarray, h: float,
                  z0: float, ocv=None, I_out=None, **kw) -> dict:
    """Run one estimator on (I_m, V_m) sampled on t_n = n h from the initial SOC guess z0.

    method: one of METHODS.  hyper:
      TFO/FOO : l1 [V^-1 s^-1], l2 [s^-alpha], L_s [s] or N_L [samples] (None = full memory),
                soc_clip, z_interval (certified SOC interval; samples outside are counted) (optional).
                FOO forces lambda = 0 regardless of params['lam'].
      FOEKF   : Q = [q_z, q_Vp], R, P0 = [p_z, p_Vp], L_s or N_L, discretisation ('implicit' default |
                'explicit').
      EKF2RC  : Q = [q_z, q_V1, q_V2], R, P0 = [p_z, p_V1, p_V2].
      AEKF2RC : as EKF2RC plus b (fading factor), R_min, Q_min.
      CC      : none.
    ``I_out``: current for the output terms (default I_m), see the module docstring.
    ``ocv`` may be omitted for CC.  Extra keyword arguments are ignored (kept for forward compatibility).
    """
    I, V, Io = _prep_signals(I_m, V_m, I_out)
    h = float(h)
    hyper = dict(hyper or {})
    if method == "CC":
        from . import benchmarks as _bm
        return _bm._run_cc(params, hyper, I, V, h, float(z0))
    ocv_f = _resolve_ocv(ocv, params, hyper)
    if method == "TFO":
        return _run_tfo(params, hyper, I, V, Io, h, float(z0), ocv_f, method="TFO")
    if method == "FOO":
        return _run_tfo(params, hyper, I, V, Io, h, float(z0), ocv_f, lam_override=0.0, method="FOO")
    from . import benchmarks as _bm
    if method == "FOEKF":
        return _bm._run_foekf(params, hyper, I, V, Io, h, float(z0), ocv_f)
    if method == "EKF2RC":
        return _bm._run_ekf2rc(params, hyper, I, V, Io, h, float(z0), ocv_f, adaptive=False, method="EKF2RC")
    if method == "AEKF2RC":
        return _bm._run_ekf2rc(params, hyper, I, V, Io, h, float(z0), ocv_f, adaptive=True, method="AEKF2RC")
    raise ValueError(f"unknown method {method!r}; expected one of {METHODS}")


# ---------------------------------------------------------------------------
# Gain design helper for TFO / FOO (certified by tempered.certify_gains_discrete)
# ---------------------------------------------------------------------------
def slope_bounds_fast(ocv, z_lo: float, z_hi: float, n: int = 4001) -> tuple[float, float]:
    """(kappa_1, kappa_2) = (min, max) of dU/dz on [z_lo, z_hi] [V per unit SOC] (grid of n points
    plus all table nodes inside the interval when ``ocv`` is a FastOCV)."""
    f = as_fast_ocv(ocv)
    d = f.dU(np.linspace(z_lo, z_hi, n))
    k1, k2 = float(np.min(d)), float(np.max(d))
    t1, t2 = f.slope_range(z_lo, z_hi)
    return min(k1, t1), max(k2, t2)


def design_observer_gains(params: dict, ocv, h: float, N_L, z_interval=(-0.05, 1.05), lam_override=None,
                          l1max=None, l2max: float = 1.0, margin: float = 0.1, tau_z_min: float | None = None,
                          l2min: float = 0.0) -> dict:
    """Gain synthesis for TFO (or FOO with lam_override = 0) certified on the OCV slope bounds of
    ``z_interval`` (default: the whole clip range [-0.05, 1.05], so the certificate holds wherever zhat
    can go).

    Design objective (stated): maximise the certified rate sigma by the diagonal LMI of
    ``tempered.design_gains`` subject to l1 <= l1max_eff with
        l1max_eff = min(l1max (if given), 1/(h kappa_2)  [positivity (S5)],  1/(kappa_2 tau_z_min) [bandwidth]),
    i.e. the fastest SOC-loop mode l1 kappa_2 is limited to 1/tau_z_min (noise / model-error rejection).
    If the LMI returns l2 < l2min, l2 is raised to l2min and the pair is re-certified
    (``certify_gains_discrete`` at sigma = 0 and ``sigma_star``).  Returns hyper dict(l1, l2, N_L,
    z_interval, sigma_cert, kappa1, kappa2, certified, h_l1_kappa2, design)."""
    alpha = float(params["alpha"])
    lam = float(params.get("lam", 0.0)) if lam_override is None else float(lam_override)
    ap = model_constants(params)["ap"]
    k1, k2 = slope_bounds_fast(ocv, *z_interval)
    cands = [1.0 / (h * k2)]
    if l1max is not None:
        cands.append(float(l1max))
    if tau_z_min is not None:
        cands.append(1.0 / (k2 * float(tau_z_min)))
    l1m = min(cands)
    design = dict(objective="max certified rate (tempered.design_gains LMI)", l1max_eff=l1m, l1max=l1max,
                  tau_z_min=tau_z_min, l2min=l2min, l2max=l2max, margin=margin, z_interval=list(z_interval))
    res = tempered.design_gains(alpha, lam, ap, k1, k2, h=h, N_L=N_L, l1max=l1m, l2max=l2max, margin=margin)
    if res is None:
        return dict(l1=None, l2=None, N_L=N_L, certified=False, kappa1=k1, kappa2=k2, z_interval=list(z_interval),
                    design=design)
    l1, l2, sig = float(res["l1"]), float(res["l2"]), float(res["sigma_cert"])
    if l1 > l1m:                              # solver tolerance: enforce the bound exactly, re-certified below
        l1 = l1m
        s = tempered.sigma_star(alpha, lam, ap, k1, k2, l1, l2, h=h, N_L=N_L)
        sig = min(sig, float(s)) if s is not None else float("nan")
    if l2 < l2min:
        l2 = float(l2min)
        design["l2_raised_to_l2min"] = True
        s = tempered.sigma_star(alpha, lam, ap, k1, k2, l1, l2, h=h, N_L=N_L)
        sig = float(s) if s is not None else float("nan")
    cert = tempered.certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
    return dict(l1=l1, l2=l2, N_L=N_L, z_interval=list(z_interval), sigma_cert=sig, kappa1=k1, kappa2=k2,
                certified=bool(cert.certified), h_l1_kappa2=float(h * l1 * k2), design=design)
