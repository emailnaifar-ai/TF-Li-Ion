"""SOC-estimation metrics, paired-difference statistics and Monte-Carlo summaries.

Conventions
-----------
* SOC error e_n = zhat_n - z_ref,n (dimensionless); SOC metrics are reported in % SOC (x 100).
* Convergence time to a band b (default +-2 % SOC, config validation.error_band_convergence):
  t_c = t_{m+1} - t_0 where m is the LAST index with |e_m| > b, i.e. the first time after which |e|
  stays inside the band until the end of the record; t_c = 0 if |e| <= b everywhere and
  t_c = inf if the last sample is outside the band.
* Within-band percentages for the bands of config estimators.within_bands (default 1 % and 2 %;
  key ``within<100 b>_pct``, e.g. within1_pct, within2_pct); |e| <= b counts as inside.
* Post-convergence variants (prefix ``post_``) use the samples with t - t_0 >= t_post (config
  estimators.post_convergence_t_s, default 600 s).
* Terminal voltage: ``vt_rmse_mV`` is the RMSE of the ONE-STEP-AHEAD (a-priori) output prediction
  ``Vt_prior`` (formed before V_n is used, so it does not reward measurement injection and is comparable
  across methods); ``vt_apost_rmse_mV`` is the RMSE of the a-posteriori output ``Vt_hat`` (reported
  for completeness only).  Reference: the clean measured voltage at t_n (point sample at t_k for
  re-gridded cases).  NaN when the estimator has no voltage output (Coulomb counting).
* Settings not passed explicitly are read from config.yaml (``estimators`` section).
"""
from __future__ import annotations

import math

import numpy as np
from scipy import stats

__all__ = ["soc_metrics", "convergence_time", "paired_difference", "mc_summary", "PCT", "metric_settings"]

PCT = 100.0
_CFG = None


def metric_settings() -> dict:
    """bands, t_post, band (convergence) and bootstrap settings from config.yaml (cached)."""
    global _CFG
    if _CFG is None:
        from .data import load_config
        cfg = load_config()
        est = cfg.get("estimators", {})
        _CFG = dict(within_bands=[float(v) for v in est.get("within_bands", [0.01, 0.02])],
                    t_post=float(est.get("post_convergence_t_s", 600.0)),
                    band=float(cfg.get("validation", {}).get("error_band_convergence", 0.02)),
                    bootstrap=dict(est.get("bootstrap", dict(n_boot=10000, seed=20260927, ci=0.95))))
    return _CFG


def _band_key(b: float) -> str:
    v = 100.0 * b
    return f"within{int(round(v))}_pct" if abs(v - round(v)) < 1e-9 else f"within{v:g}_pct".replace(".", "p")


def convergence_time(t, e, band: float = 0.02) -> float:
    """First time (relative to t[0]) after which |e| <= band until the end; inf if never."""
    t = np.asarray(t, float)
    a = np.abs(np.asarray(e, float))
    out = ~(a <= band)                      # NaN counts as outside
    if not out.any():
        return 0.0
    m = int(np.flatnonzero(out)[-1])
    if m == a.size - 1:
        return math.inf
    return float(t[m + 1] - t[0])


def _basic(e, bands, prefix=""):
    e = np.asarray(e, float)
    keys = [_band_key(b) for b in bands]
    if e.size == 0:
        nan = float("nan")
        out = {f"{prefix}rmse_pct": nan, f"{prefix}mae_pct": nan, f"{prefix}maxabs_pct": nan,
               f"{prefix}bias_pct": nan}
        out.update({f"{prefix}{k}": nan for k in keys})
        return out
    a = np.abs(e)
    out = {f"{prefix}rmse_pct": float(PCT * np.sqrt(np.mean(e * e))),
           f"{prefix}mae_pct": float(PCT * np.mean(a)),
           f"{prefix}maxabs_pct": float(PCT * np.max(a)),
           f"{prefix}bias_pct": float(PCT * np.mean(e))}
    for b, k in zip(bands, keys):
        out[f"{prefix}{k}"] = float(PCT * np.mean(a <= b))
    return out


def _rmse_mV(x, ref, mask=None):
    ev = np.asarray(x, float) - np.asarray(ref, float)
    if mask is not None:
        ev = ev[mask]
    return float(1e3 * np.sqrt(np.mean(ev * ev))) if ev.size else float("nan")


def soc_metrics(t, zhat, zref, Vt_hat=None, V_ref=None, band: float | None = None, t_post: float | None = None,
                Vt_prior=None, bands=None) -> dict:
    """All per-run metrics.

    Returns rmse/mae/maxabs/bias (% SOC), within-band percentages, conv_time_s (band ``band``),
    vt_rmse_mV (a-priori output), vt_apost_rmse_mV (a-posteriori output), and the same with prefix
    ``post_`` for t - t0 >= t_post, plus final_abs_err_pct and n_samples.  Unspecified settings come
    from config.yaml (``metric_settings``)."""
    ms = metric_settings()
    band = ms["band"] if band is None else float(band)
    t_post = ms["t_post"] if t_post is None else float(t_post)
    bands = ms["within_bands"] if bands is None else [float(b) for b in bands]
    t = np.asarray(t, float)
    e = np.asarray(zhat, float) - np.asarray(zref, float)
    out = dict(n_samples=int(e.size), band=float(band), t_post_s=float(t_post))
    out.update(_basic(e, bands))
    out["conv_time_s"] = convergence_time(t, e, band)
    out["final_abs_err_pct"] = float(PCT * abs(e[-1]))
    post = (t - t[0]) >= t_post
    out.update(_basic(e[post], bands, prefix="post_"))
    nan = float("nan")
    for key, series in (("vt", Vt_prior), ("vt_apost", Vt_hat)):
        if series is not None and V_ref is not None:
            out[f"{key}_rmse_mV"] = _rmse_mV(series, V_ref)
            out[f"post_{key}_rmse_mV"] = _rmse_mV(series, V_ref, post) if post.any() else nan
        else:
            out[f"{key}_rmse_mV"] = nan
            out[f"post_{key}_rmse_mV"] = nan
    return out


def paired_difference(a, b, n_boot: int | None = None, seed: int | None = None, ci: float | None = None,
                      censor_at: float | None = None) -> dict:
    """Paired comparison of metric values a_i (method A) and b_i (method B) over the same files/runs.

    Censoring (for convergence times, where inf = never converged): every +inf (-inf) is replaced by
    +censor_at (-censor_at) BEFORE differencing, so failures keep their rank instead of being dropped.
    Default ``censor_at`` = 1 + 1.01 x max finite |value| over a and b (larger than every finite value);
    pass the record duration + h for convergence times.  Pairs with a NaN are dropped (counted in n_nan).

    d_i = a_i - b_i; returns n, median difference, percentile-bootstrap CI of the median difference
    (resampling pairs, ``numpy.random.default_rng(seed)``), mean difference (of the censored values),
    number of pairs with a < b and a > b, the number of infinite (non-converged) values per method
    (n_inf_a, n_inf_b), and the two-sided Wilcoxon signed-rank p-value (scipy, zero differences
    dropped by the 'wilcox' rule; p = 1 when all differences are zero).  n_boot, seed, ci default to
    config estimators.bootstrap."""
    bs = metric_settings()["bootstrap"]
    n_boot = int(bs.get("n_boot", 10000) if n_boot is None else n_boot)
    seed = int(bs.get("seed", 20260927) if seed is None else seed)
    ci = float(bs.get("ci", 0.95) if ci is None else ci)
    a = np.asarray(a, float).copy()
    b = np.asarray(b, float).copy()
    if a.shape != b.shape:
        raise ValueError("a and b must be paired (same shape)")
    nan_pair = np.isnan(a) | np.isnan(b)
    n_inf_a, n_inf_b = int(np.sum(np.isinf(a) & ~nan_pair)), int(np.sum(np.isinf(b) & ~nan_pair))
    a, b = a[~nan_pair], b[~nan_pair]
    fin = np.concatenate([a[np.isfinite(a)], b[np.isfinite(b)]])
    if censor_at is None:
        censor_at = 1.0 + 1.01 * (float(np.max(np.abs(fin))) if fin.size else 0.0)
    censor_at = float(censor_at)
    if fin.size and censor_at <= float(np.max(np.abs(fin))):
        raise ValueError("censor_at must exceed every finite value")
    a = np.where(np.isinf(a), np.sign(a) * censor_at, a)
    b = np.where(np.isinf(b), np.sign(b) * censor_at, b)
    d = a - b
    n = int(d.size)
    out = dict(n=n, n_nan=int(np.sum(nan_pair)), median_diff=float("nan"), ci_lo=float("nan"), ci_hi=float("nan"),
               mean_diff=float("nan"), n_a_better=int(np.sum(d < 0)), n_b_better=int(np.sum(d > 0)),
               n_inf_a=n_inf_a, n_inf_b=n_inf_b, censor_at=censor_at if (n_inf_a or n_inf_b) else None,
               wilcoxon_p=float("nan"), n_boot=n_boot, seed=seed, ci_level=ci)
    if n == 0:
        return out
    out["median_diff"] = float(np.median(d))
    out["mean_diff"] = float(np.mean(d))
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_boot, n))
    meds = np.median(d[idx], axis=1)
    lo, hi = np.quantile(meds, [(1 - ci) / 2, 1 - (1 - ci) / 2], method="linear")
    out["ci_lo"], out["ci_hi"] = float(lo), float(hi)
    if np.any(d != 0):
        out["wilcoxon_p"] = float(stats.wilcoxon(d, zero_method="wilcox", alternative="two-sided").pvalue)
    else:
        out["wilcoxon_p"] = 1.0
    return out


def mc_summary(df, value_cols, group_cols) -> "object":
    """Median and IQR (q25, q75) over Monte-Carlo seeds of each value column, per group.

    ``df``: pandas DataFrame of tidy records (one row per run).  Returns a DataFrame with columns
    ``<col>_median, <col>_q25, <col>_q75, <col>_iqr`` and ``n_runs`` per group."""
    import pandas as pd
    g = df.groupby(list(group_cols), dropna=False)
    parts = {"n_runs": g.size()}
    for c in value_cols:
        parts[f"{c}_median"] = g[c].median()
        parts[f"{c}_q25"] = g[c].quantile(0.25)
        parts[f"{c}_q75"] = g[c].quantile(0.75)
    out = pd.DataFrame(parts)
    for c in value_cols:
        out[f"{c}_iqr"] = out[f"{c}_q75"] - out[f"{c}_q25"]
    return out.reset_index()
