"""E1: main test-set comparison of the frozen estimators (18 SP2 FUDS/US06/BJDST test files x 3 initial-SOC scenarios).

Every hyper-parameter and parameter set comes from results/frozen_config.json (status FROZEN, written by
scripts/05_design_tune.py on the validation files only); nothing is tuned or selected here.  Settings: config.yaml
`validation_main` (declared before the first test run), `estimators`, `identification_refined`, `identification_study`.
Test files are loaded only through experiments.load_case(..., allow_splits=('test',), final_evaluation=True), which
calls data.verify_file.  Clean measured signals (no corruption).

Outputs (all numbers, tables and figures are regenerated from the first two):
  results/validation_main.json    per-run metrics (whole / admissible windows, with and without t >= 600 s), paired
                                  differences TFO - benchmark, Q_ref +- u_Q sensitivity, convergence-tail fits,
                                  open-loop voltage-model accuracy, certificates of the full-memory variants, runtime
  results/validation_series.npz   every plotted array (SOC estimates, reference and band, |e| envelopes, fitted tails,
                                  measured / modelled voltages, residual ACFs)
  tables/tab_soc_results.tex, figures/fig_soc_test.pdf, fig_error_envelopes.pdf, fig_vt_model.pdf, fig_resid_acf.pdf,
  reports/validation_main_findings.md

Usage: python scripts/06_validate.py [--report-only]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import identify as ID  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES = ROOT / "results"
FIG = ROOT / "figures"
TAB = ROOT / "tables"
REP = ROOT / "reports"
TEMPS = (0, 25, 45)
PROFILES = ("FUDS", "US06", "BJDST")
# evaluated method -> (frozen entry, estimator, memory override)
METHODS = {"TFO": ("TFO", "TFO", None), "FOO": ("FOO", "FOO", None), "FOO_full": ("FOO", "FOO", "full"),
           "TFO_full": ("TFO", "TFO", "full"), "FOEKF": ("FOEKF", "FOEKF", None),
           "EKF2RC": ("EKF2RC", "EKF2RC", None), "AEKF2RC": ("AEKF2RC", "AEKF2RC", None), "CC": ("CC", "CC", None)}
VM_FAMS = ("TFO", "FO", "2RC")
TASK_VERSION = "E1-2026-09-27-a"


# ---------------------------------------------------------------------------------------------------------------
# Configuration, freeze guard
# ---------------------------------------------------------------------------------------------------------------
def cfg():
    c = D.load_config()
    return c, dict(c["validation_main"]), dict(c["estimators"])


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def frozen():
    fz = load_json("frozen_config.json")
    if not str(fz.get("status", "")).startswith("FROZEN") or fz.get("frozen_utc") is None:
        raise PermissionError("results/frozen_config.json is not FROZEN: test evaluation refused")
    return fz


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def code_hash() -> str:
    c, vm, est = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([vm, est], sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("scripts/06_validate.py", "src/tfso/observer.py", "src/tfso/benchmarks.py", "src/tfso/experiments.py",
              "src/tfso/metrics.py", "src/tfso/model.py", "results/frozen_config.json",
              "results/identification_refined.json", "results/capacity.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def admissible():
    return tuple(float(x) for x in D.load_config()["identification_refined"]["admissible_soc_interval"])


_OCV = {}


def aligned_ocv(T):
    if T not in _OCV:
        _OCV[T] = MD.AlignedOCV(int(T), E.q_id(int(T)))
    return _OCV[T]


def method_spec(fz, name, T):
    entry, est, mem = METHODS[name]
    e = fz["methods"][entry]["per_T"][str(T)]
    p = dict(e["params"])
    hy = dict(e.get("hyper", {}))
    if mem == "full":
        hy["L_s"] = None
        hy.pop("N_L", None)
    return est, p, hy


# ---------------------------------------------------------------------------------------------------------------
# Metrics on the declared windows
# ---------------------------------------------------------------------------------------------------------------
def conv_time_masked(t, e, mask, band):
    """Time (from the profile start t[0]) after which |e| <= band on every masked sample until the end; inf if the last
    masked sample is outside; 0 if none is outside."""
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return float("nan")
    out = ~(np.abs(e[idx]) <= band)
    if not out.any():
        return 0.0
    m = int(np.flatnonzero(out)[-1])
    if m == idx.size - 1:
        return math.inf
    return float(t[idx[m + 1]] - t[0])


def window_metrics(t, e, zref, Vtp, V, est):
    band = float(D.load_config()["validation"]["error_band_convergence"])
    bands = [float(b) for b in est["within_bands"]]
    tpost = float(est["post_convergence_t_s"])
    lo, hi = admissible()
    post = (t - t[0]) >= tpost
    adm = (zref >= lo) & (zref <= hi)
    out = {}
    for w, m in (("whole", np.ones_like(post)), ("whole_post", post), ("adm", adm), ("adm_post", adm & post)):
        ee = e[m]
        if ee.size == 0:
            continue
        a = np.abs(ee)
        out[f"{w}_rmse_pct"] = float(100 * np.sqrt(np.mean(ee * ee)))
        out[f"{w}_mae_pct"] = float(100 * np.mean(a))
        out[f"{w}_maxabs_pct"] = float(100 * np.max(a))
        out[f"{w}_bias_pct"] = float(100 * np.mean(ee))
        for b in bands:
            out[f"{w}_within{int(round(100 * b))}_pct"] = float(100 * np.mean(a <= b))
        out[f"{w}_n"] = int(ee.size)
        if Vtp is not None:
            ev = (np.asarray(Vtp) - V)[m]
            out[f"{w}_vt_rmse_mV"] = float(1e3 * np.sqrt(np.mean(ev * ev)))
        else:
            out[f"{w}_vt_rmse_mV"] = float("nan")
    out["whole_conv_time_s"] = conv_time_masked(t, e, np.ones_like(post), band)
    out["adm_conv_time_s"] = conv_time_masked(t, e, adm, band)
    # post hoc diagnostic (added after the first test run; reported only): first entry into the band
    for w, m in (("whole", np.ones_like(post)), ("adm", adm)):
        ii = np.flatnonzero(m & (np.abs(e) <= band))
        out[f"{w}_first_entry_s"] = float(t[ii[0]] - t[0]) if ii.size else math.inf
    out["frac_admissible"] = float(adm.mean())
    return out


# ---------------------------------------------------------------------------------------------------------------
# Convergence-tail fit  log|e| = c - lambda_eff t - rho log t
# ---------------------------------------------------------------------------------------------------------------
def tail_window(t, y, t0, tmax, stop, sign_change):
    """[i0, i1) window: from t >= t0 until the first |y| <= stop, the first sign change of y (if requested) or t > tmax."""
    i0 = int(np.searchsorted(t, t0 - 1e-9))
    if i0 >= t.size:
        return i0, i0, "record too short"
    if abs(y[i0]) <= stop:
        return i0, i0, "|e| <= e_stop at t_start"
    s0 = np.sign(y[i0])
    i1 = t.size
    reason = "end of record"
    for k in range(i0, t.size):
        if t[k] > tmax:
            i1, reason = k, "t_max"
            break
        if abs(y[k]) <= stop:
            i1, reason = k, "|e| <= e_stop"
            break
        if sign_change and np.sign(y[k]) != s0:
            i1, reason = k, "sign change"
            break
    return i0, i1, reason


def tail_fit(t, y, t0, tmax, stop, sign_change, min_n, hac_lags):
    import statsmodels.api as sm
    i0, i1, reason = tail_window(t, y, t0, tmax, stop, sign_change)
    n = i1 - i0
    out = dict(n=int(n), t_from_s=float(t[i0]) if i0 < t.size else None,
               t_to_s=float(t[i1 - 1]) if n > 0 else None, window_end=reason, fitted=False)
    if n < min_n:
        out["reason"] = f"fewer than {min_n} samples in the window ({reason})"
        return out
    tt, ly = t[i0:i1], np.log(np.abs(y[i0:i1]))
    X = np.column_stack([np.ones(n), -tt, -np.log(tt)])
    r = sm.OLS(ly, X).fit(cov_type="HAC", cov_kwds={"maxlags": int(hac_lags)})
    ci = r.conf_int(0.05)
    cov = r.cov_params()
    corr = float(cov[1, 2] / math.sqrt(cov[1, 1] * cov[2, 2])) if cov[1, 1] > 0 and cov[2, 2] > 0 else float("nan")
    r_exp = sm.OLS(ly, X[:, :2]).fit()
    r_alg = sm.OLS(ly, X[:, [0, 2]]).fit()
    out.update(fitted=True, c=float(r.params[0]), lambda_eff=float(r.params[1]), rho=float(r.params[2]),
               lambda_eff_ci=[float(ci[1, 0]), float(ci[1, 1])], rho_ci=[float(ci[2, 0]), float(ci[2, 1])],
               r2=float(r.rsquared), corr_lambda_rho=corr, r2_exponential_only=float(r_exp.rsquared),
               lambda_exp_only=float(r_exp.params[1]), r2_algebraic_only=float(r_alg.rsquared),
               rho_alg_only=float(r_alg.params[1]), e_start=float(abs(y[i0])), e_end=float(abs(y[i1 - 1])))
    return out


def tail_curve(fit, t):
    return np.exp(fit["c"] - fit["lambda_eff"] * t - fit["rho"] * np.log(t))


# ---------------------------------------------------------------------------------------------------------------
# One test file: every method x scenario, Q_ref sensitivity, tail fits, open-loop voltage models
# ---------------------------------------------------------------------------------------------------------------
def voltage_models(lid, T, df, soc_ref):
    c = D.load_config()
    s = c["identification_study"]
    Q = E.q_id(T)
    H = MD.build_history(lid, Q, h=float(s["h_s"]), df=df)
    ocv = MD.AlignedOCV(T, Q, extrapolation=s["ocv_extrapolation"])
    g = MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    J = load_json("identification_refined.json")
    sets = J["chosen_parameter_sets"][str(T)]
    acc_ref = J["accuracy"].get(lid, {}).get("causal_full", {})
    lo, hi = admissible()
    adm = (soc_ref >= lo) & (soc_ref <= hi)
    kz = float(s["knee_window"]["z_min"])
    knee = H.z[H.prof] >= kz
    max_lag = int(c["validation_main"]["voltage_models"]["acf_max_lag_s"] / H.h)
    stats, arrays = {}, {"V_meas": H.V[H.prof].astype(np.float32), "t_V": H.t[H.prof].astype(np.float32)}
    for fam in VM_FAMS:
        th = sets[fam]
        if fam == "2RC":
            P = MD.TwoRCParams(th["R0"], th["R1"], th["tau1"], th["R2"], th["tau2"], th["s"], th["dq"])
        else:
            P = MD.TFOParams(th["alpha"], th.get("lam", 0.0), th["R0"], th["Rp"], th["Cp"], th["s"], th["dq"])
        sim = MD.simulate(P, H, ocv, method="fft", grid=None if fam == "2RC" else g, window=H.prof, timing="causal")
        r = sim["Vt"] - H.V[H.prof]
        st, acf = ID.residual_stats(r, int(s["accuracy"]["ljung_box_lags"]), s["accuracy"]["quantiles"], max_lag)
        st["rmse_admissible_mV"] = float(np.sqrt(np.mean(r[adm] ** 2)) * 1e3)
        st["rmse_z_ge_knee_mV"] = float(np.sqrt(np.mean(r[knee] ** 2)) * 1e3)
        ref = acc_ref.get(fam, {}).get("rmse_mV")
        st["rmse_mV_identification_refined_json"] = ref
        st["consistency_abs_diff_mV"] = None if ref is None else float(abs(ref - st["rmse_mV"]))
        stats[fam] = st
        arrays[f"Vt_{fam}"] = sim["Vt"].astype(np.float32)
        arrays[f"acf_{fam}"] = np.asarray(acf, np.float32)
    return stats, arrays


def file_task(lid):
    t0w, t0c = time.perf_counter(), time.process_time()
    c, vm, est = cfg()
    fz = frozen()
    assert lid in c["splits"]["test_dynamic"], lid
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)     # data.verify_file inside
    if not case.meta["verify_passed"]:
        raise RuntimeError(f"{lid} failed data.verify_file")
    T = case.T
    df = D.load_raw(lid)
    prof = D.get_dynamic_profile(lid, df=df)
    ref = D.reference_soc(lid, df=df, profile=prof)
    if np.max(np.abs(ref["soc_ref"] - case.soc_ref)) > 1e-12:
        raise RuntimeError("reference SOC mismatch")
    cap = load_json("capacity.json")["Q_ref_T_SP2"][str(T)]
    Qr, uQ = float(cap["Q_ref_Ah"]), float(cap["u_Q_Ah"])
    refs_q = {"Q_minus": D.reference_soc(lid, Q_ref_Ah=Qr - uQ, df=df, profile=prof)["soc_ref"],
              "Q_plus": D.reference_soc(lid, Q_ref_Ah=Qr + uQ, df=df, profile=prof)["soc_ref"]}
    tf = vm["tail_fit"]
    t = case.t
    records, series, tails = [], {}, []
    zhat_nom = {}
    for sc in vm["scenarios"]:
        for name in METHODS:
            estm, p, hy = method_spec(fz, name, T)
            focv = O.as_fast_ocv(aligned_ocv(T), s=p["s"], dq=p["dq"]) if estm != "CC" else None
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                rec = E.run_case(estm, p, hy, case, z0_scenario=sc, ocv=focv, keep_series=True)
            sr = rec.pop("_series")
            zh = np.asarray(sr["zhat"], float)
            e = zh - case.soc_ref
            m = window_metrics(t, e, case.soc_ref, sr["Vt_prior"] if estm != "CC" else None, case.V, est)
            if abs(m["whole_rmse_pct"] - rec["rmse_pct"]) > 1e-9:
                raise RuntimeError("metric mismatch with metrics.soc_metrics")
            qs = {}
            for k, zr in refs_q.items():
                mq = window_metrics(t, zh - zr, zr, None, case.V, est)
                qs[k] = {kk: mq[kk] for kk in ("adm_post_rmse_pct", "whole_post_rmse_pct", "adm_post_maxabs_pct")}
            row = dict(method=name, estimator=estm, file=lid, T=T, profile=case.profile, start_level=case.start_level,
                       scenario=sc, z0=rec["z0"], z_ref0=rec["z_ref0"], z0_error=rec["z0_error"], n_samples=int(t.size),
                       duration_s=float(t[-1] - t[0]), N_L_requested=rec["N_L_requested"], N_L_used=rec["N_L_used"],
                       full_memory=rec["full_memory"], cpu_process_s=rec["cpu_process_s"],
                       cpu_per_sample_us=rec["cpu_per_sample_us"], wall_s=rec["wall_s"],
                       wall_per_sample_us=rec["wall_per_sample_us"], n_history_samples=rec["n_history_samples"],
                       bytes_state=rec["bytes_state"], soc_clip_count=rec["soc_clip_count"], nonfinite=rec["nonfinite"],
                       positivity_ok=rec["positivity_ok"], n_outside_z_interval=rec["n_outside_z_interval"],
                       vt_apost_rmse_mV=rec["vt_apost_rmse_mV"], q_ref_sensitivity=qs, **m)
            records.append(row)
            series[f"zhat|{name}|{sc}"] = zh.astype(np.float32)
            if sc == "nominal":
                zhat_nom[name] = zh
                continue
            variants = [("primary", float(tf["e_stop"]))] + [(f"e_stop_{v:g}", float(v)) for v in tf["e_stop_sensitivity"]]
            for vkey, stop in variants:
                fit = tail_fit(t, e, float(tf["t_start_s"]), float(tf["t_max_s"]), stop,
                               bool(tf["stop_on_sign_change"]), int(tf["min_samples"]), int(tf["hac_lags"]))
                tails.append(dict(kind="error", variant=vkey, e_stop=stop, method=name, file=lid, T=T,
                                  profile=case.profile, start_level=case.start_level, scenario=sc, **fit))
    for sc in vm["scenarios"]:
        if sc == "nominal":
            continue
        for name in METHODS:
            dlt = np.asarray(series[f"zhat|{name}|{sc}"], float) - zhat_nom[name]
            fit = tail_fit(t, dlt, float(tf["t_start_s"]), float(tf["t_max_s"]), float(tf["delta_stop"]),
                           bool(tf["stop_on_sign_change"]), int(tf["min_samples"]), int(tf["hac_lags"]))
            tails.append(dict(kind="incremental", variant="delta", e_stop=float(tf["delta_stop"]), method=name, file=lid,
                              T=T, profile=case.profile, start_level=case.start_level, scenario=sc, **fit))
    vstats, varr = voltage_models(lid, T, df, case.soc_ref)
    series.update(varr)
    series.update(t_soc=t.astype(np.float32), zref=case.soc_ref.astype(np.float32),
                  zref_lo=np.asarray(ref["soc_lo"], np.float32), zref_hi=np.asarray(ref["soc_hi"], np.float32),
                  zref_Qminus=refs_q["Q_minus"].astype(np.float32), zref_Qplus=refs_q["Q_plus"].astype(np.float32))
    info = dict(file=lid, T=T, profile=case.profile, start_level=case.start_level, split=case.split,
                verified=bool(case.meta["verify_passed"]), n_samples=int(t.size), duration_s=float(t[-1] - t[0]),
                z_ref0=case.z_ref0, z_ref_end=float(case.soc_ref[-1]), soc_band_end=case.meta["soc_band_end"],
                Q_ref_Ah=Qr, u_Q_Ah=uQ, loaded_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return dict(info=info, records=records, tails=tails, vmodels=vstats, series=series,
                wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)


# ---------------------------------------------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------------------------------------------
KEY_METRICS = ("adm_post_rmse_pct", "adm_rmse_pct", "whole_post_rmse_pct", "whole_rmse_pct", "adm_post_mae_pct",
               "whole_post_mae_pct", "adm_post_maxabs_pct", "whole_post_maxabs_pct", "whole_maxabs_pct",
               "whole_conv_time_s", "adm_conv_time_s", "whole_first_entry_s", "adm_first_entry_s", "adm_post_within1_pct", "adm_post_within2_pct",
               "whole_post_within1_pct", "whole_post_within2_pct", "adm_vt_rmse_mV", "whole_vt_rmse_mV",
               "cpu_per_sample_us", "wall_per_sample_us", "n_history_samples", "bytes_state")


def _f(v):
    return float("inf") if v == "inf" else (float("nan") if v in (None, "nan") else float(v))


def summarise(recs, keys=("method",)):
    import pandas as pd
    df = pd.DataFrame([{k: (r[k] if k in r else None) for k in ("method", "T", "profile", "scenario", "file",
                                                               "start_level") + KEY_METRICS} for r in recs])
    for k in KEY_METRICS:
        df[k] = df[k].map(_f)
    out = []
    for g, d in df.groupby(list(keys)):
        g = g if isinstance(g, tuple) else (g,)
        row = dict(zip(keys, [x.item() if hasattr(x, "item") else x for x in g]), n=int(len(d)))
        for k in KEY_METRICS:
            v = d[k].to_numpy(float)
            fin = v[np.isfinite(v)]
            row[f"{k}_mean"] = float(np.mean(v)) if np.all(np.isfinite(v)) else float("nan")
            row[f"{k}_median"] = float(np.median(v))
            row[f"{k}_n_inf"] = int(np.sum(np.isinf(v)))
            row[f"{k}_max_finite"] = float(np.max(fin)) if fin.size else float("nan")
        out.append(row)
    return out


# supplementary paired metrics added after the first test run (reported as such; not part of the declared list)
SUPP_PAIRED = ("adm_conv_time_s", "adm_first_entry_s", "whole_first_entry_s")


def paired(recs, vm):
    pc = vm["paired"]
    ref = pc["reference_method"]
    dur_max = max(r["duration_s"] for r in recs) + 1.0
    idx = {(r["method"], r["file"], r["scenario"]): r for r in recs}
    pairs = sorted({(r["file"], r["scenario"], r["T"], r["profile"]) for r in recs})
    groups = [("all", None)] + [(f"T={T}", ("T", T)) for T in TEMPS] + [(f"profile={p}", ("profile", p)) for p in PROFILES] \
        + [(f"scenario={s}", ("scenario", s)) for s in vm["scenarios"]]
    out = []
    for comp in pc["comparators"]:
        for met in list(pc["metrics"]) + [m for m in SUPP_PAIRED if m not in pc["metrics"]]:
            for gname, g in groups:
                sel = [pp for pp in pairs if g is None or {"T": pp[2], "profile": pp[3], "scenario": pp[1]}[g[0]] == g[1]]
                a = [_f(idx[(ref, f, s)][met]) for f, s, _, _ in sel]
                b = [_f(idx[(comp, f, s)][met]) for f, s, _, _ in sel]
                if all(np.isnan(b)):
                    continue
                pdiff = MX.paired_difference(a, b, censor_at=dur_max if "conv_time" in met else None)
                out.append(dict(reference=ref, comparator=comp, metric=met, group=gname, **pdiff))
    return out


def q_sensitivity(recs):
    out = []
    for m, Tg in [(m, Tg) for m in METHODS for Tg in ("all",) + TEMPS]:
        rr = [r for r in recs if r["method"] == m and (Tg == "all" or r["T"] == Tg)]
        row = dict(method=m, T=Tg, n=len(rr))
        for key in ("adm_post_rmse_pct", "whole_post_rmse_pct"):
            base = np.array([r[key] for r in rr], float)
            row[f"{key}_Q_ref_mean"] = float(np.mean(base))
            row[f"{key}_Q_ref_median"] = float(np.median(base))
            for q in ("Q_minus", "Q_plus"):
                v = np.array([r["q_ref_sensitivity"][q][key] for r in rr], float)
                row[f"{key}_{q}_mean"] = float(np.mean(v))
                row[f"{key}_{q}_median"] = float(np.median(v))
        out.append(row)
    return out


def tail_summary(tails):
    out = []
    kinds = sorted({(t["kind"], t["variant"]) for t in tails})
    for kind, var in kinds:
        for m in METHODS:
            for Tg in ("all",) + TEMPS:
                rr = [t for t in tails if t["kind"] == kind and t["variant"] == var and t["method"] == m
                      and (Tg == "all" or t["T"] == Tg)]
                fit = [t for t in rr if t["fitted"]]
                row = dict(kind=kind, variant=var, method=m, T=Tg, n_runs=len(rr), n_fitted=len(fit))
                if fit:
                    lam = np.array([t["lambda_eff"] for t in fit])
                    rho = np.array([t["rho"] for t in fit])
                    row.update(lambda_eff_median=float(np.median(lam)), lambda_eff_q25=float(np.quantile(lam, .25)),
                               lambda_eff_q75=float(np.quantile(lam, .75)), rho_median=float(np.median(rho)),
                               rho_q25=float(np.quantile(rho, .25)), rho_q75=float(np.quantile(rho, .75)),
                               n_lambda_ci_gt0=int(sum(t["lambda_eff_ci"][0] > 0 for t in fit)),
                               n_lambda_ci_lt0=int(sum(t["lambda_eff_ci"][1] < 0 for t in fit)),
                               n_rho_ci_gt0=int(sum(t["rho_ci"][0] > 0 for t in fit)),
                               n_rho_ci_lt0=int(sum(t["rho_ci"][1] < 0 for t in fit)),
                               r2_median=float(np.median([t["r2"] for t in fit])),
                               r2_exp_only_median=float(np.median([t["r2_exponential_only"] for t in fit])),
                               r2_alg_only_median=float(np.median([t["r2_algebraic_only"] for t in fit])),
                               corr_lambda_rho_median=float(np.median([t["corr_lambda_rho"] for t in fit])),
                               window_s_median=float(np.median([t["t_to_s"] - t["t_from_s"] + 1 for t in fit])))
                out.append(row)
    return out


def envelopes(results, vm):
    """Median and 10-90 % quantiles of |e| over the +-0.20 runs per temperature and method, and the tail fit on the
    median envelope (same window rule, unsigned)."""
    tf = vm["tail_fit"]
    env, fits = {}, []
    for T in TEMPS:
        rs = [r for r in results if r["info"]["T"] == T]
        n = min(r["info"]["n_samples"] for r in rs)
        t = np.arange(n, dtype=float)
        env[f"env_t|{T}"] = t
        for m in METHODS:
            E_ = np.array([np.abs(r["series"][f"zhat|{m}|{sc}"][:n].astype(float) - r["series"]["zref"][:n].astype(float))
                           for r in rs for sc in ("plus20", "minus20")])
            q10, q50, q90 = np.quantile(E_, [0.1, 0.5, 0.9], axis=0)
            env[f"env_med|{T}|{m}"], env[f"env_q10|{T}|{m}"], env[f"env_q90|{T}|{m}"] = q50, q10, q90
            fit = tail_fit(t, q50, float(tf["t_start_s"]), float(tf["t_max_s"]), float(tf["e_stop"]), False,
                           int(tf["min_samples"]), int(tf["hac_lags"]))
            fits.append(dict(T=T, method=m, n_runs=int(E_.shape[0]), n_grid=int(n), **fit))
            if fit["fitted"]:
                i0, i1 = int(fit["t_from_s"]), int(fit["t_to_s"]) + 1
                env[f"env_fit|{T}|{m}"] = np.column_stack([t[i0:i1], tail_curve(fit, t[i0:i1])])
    return env, fits


def full_memory_certificates(fz, results):
    out = []
    for T in TEMPS:
        nmax = max(r["info"]["n_samples"] for r in results if r["info"]["T"] == T)
        for entry in ("TFO", "FOO"):
            e = fz["methods"][entry]["per_T"][str(T)]
            p = e["params"]
            lam = float(p["lam"]) if entry == "TFO" else 0.0
            ap = 1.0 / (float(p["Rp"]) * float(p["Cp"]))
            k1, k2 = float(e["kappa1"]), float(e["kappa2"])
            l1, l2 = float(e["hyper"]["l1"]), float(e["hyper"]["l2"])
            row = dict(T=T, method=entry, lam=lam, l1=l1, l2=l2, kappa1=k1, kappa2=k2, max_test_samples=int(nmax))
            for lab, NL in (("L400", int(e["N_L"])), ("full", None)):
                c = TM.certify_gains_discrete(float(p["alpha"]), lam, ap, k1, k2, l1, l2, 0.0, 1.0, NL)
                s = TM.sigma_star(float(p["alpha"]), lam, ap, k1, k2, l1, l2, h=1.0, N_L=NL)
                row[f"certified_{lab}"] = bool(c.certified)
                row[f"sigma_star_{lab}"] = None if s is None else float(s)
            if entry == "TFO":
                ab = fz["ablation_memory_TFO"][str(T)]
                row["L_cert_s"] = float(ab["L_cert_s"])
                row["L_cert_ge_longest_test_profile"] = bool(ab["L_cert_s"] >= nmax)
            out.append(row)
    return out


def run_pool(fn, tasks, workers):
    if workers <= 1:
        return [fn(t) for t in tasks]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, tasks, chunksize=1))


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return f if math.isfinite(f) else ("inf" if f > 0 else ("-inf" if f < 0 else "nan"))
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    return o


def compute(workers):
    c, vm, est = cfg()
    fz = frozen()
    files = list(c["splits"]["test_dynamic"])
    t0w, t0c = time.perf_counter(), time.process_time()
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    results = run_pool(file_task, files, workers)
    recs = [r for x in results for r in x["records"]]
    tails = [t for x in results for t in x["tails"]]
    env, env_fits = envelopes(results, vm)
    out = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), test_phase_started_utc=started,
               script="scripts/06_validate.py", code_hash=code_hash(), task_version=TASK_VERSION,
               frozen_config=dict(sha256=sha256_file(RES / "frozen_config.json"), frozen_utc=fz["frozen_utc"],
                                  code_hash=fz["code_hash"], status=fz["status"]),
               settings=vm, admissible_soc_interval_reference=list(admissible()),
               methods={m: dict(frozen_entry=METHODS[m][0], estimator=METHODS[m][1], memory=METHODS[m][2] or "frozen",
                                description=vm["methods"][m]) for m in METHODS},
               files=[x["info"] for x in results], all_files_verified=bool(all(x["info"]["verified"] for x in results)),
               records=recs, summary=dict(by_method=summarise(recs, ("method",)),
                                          by_method_T=summarise(recs, ("method", "T")),
                                          by_method_profile=summarise(recs, ("method", "profile")),
                                          by_method_T_profile=summarise(recs, ("method", "T", "profile")),
                                          by_method_scenario=summarise(recs, ("method", "scenario"))),
               paired=paired(recs, vm), q_ref_sensitivity=q_sensitivity(recs), tails=tails,
               tail_summary=tail_summary(tails), envelope_fits=env_fits,
               voltage_models={x["info"]["file"]: x["vmodels"] for x in results},
               full_memory_certificates=full_memory_certificates(fz, results))
    out["runtime"] = dict(main_wall_s=time.perf_counter() - t0w, main_process_s=time.process_time() - t0c,
                          worker_wall_s_sum=float(sum(x["wall_s"] for x in results)),
                          worker_process_s_sum=float(sum(x["cpu_s"] for x in results)), workers=workers,
                          per_file={x["info"]["file"]: dict(wall_s=x["wall_s"], process_s=x["cpu_s"]) for x in results})
    with open(RES / "validation_main.json", "w", encoding="utf-8") as fh:
        json.dump(jsonable(out), fh, indent=1)
    arrs = {}
    for x in results:
        for k, v in x["series"].items():
            arrs[f"{x['info']['file']}|{k}"] = np.asarray(v)
    for k, v in env.items():
        arrs[k] = np.asarray(v, np.float32)
    np.savez_compressed(RES / "validation_series.npz", **arrs)
    return out


# ---------------------------------------------------------------------------------------------------------------
# Table and figures (regenerated from results/validation_main.json and results/validation_series.npz only)
# ---------------------------------------------------------------------------------------------------------------
MLABEL = {"TFO": "TFO", "FOO": "FOO", "FOO_full": "FOO (full)", "TFO_full": "TFO (full)", "FOEKF": "FOEKF",
          "EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC", "CC": "CC"}


def styles():
    from tfso import plotstyle as ps
    st = {m: dict(ps.SERIES[m]) for m in ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC")}
    st["TFO_full"] = dict(color=ps.SLOTS[5], ls=(0, (3, 1, 1, 1)), marker="P")
    st["FOO_full"] = dict(color=ps.SLOTS[7], ls=(0, (6, 2)), marker="X")
    return st


def load_outputs():
    J = load_json("validation_main.json")
    Z = np.load(RES / "validation_series.npz")
    return J, Z


def summary_row(J, key, method, **grp):
    tab = {(): "by_method", ("T",): "by_method_T", ("profile",): "by_method_profile",
           ("T", "profile"): "by_method_T_profile", ("scenario",): "by_method_scenario"}[tuple(grp)]
    for r in J["summary"][tab]:
        if r["method"] == method and all(r[k] == v for k, v in grp.items()):
            return r
    raise KeyError((method, grp))


def write_table(J):
    meth = list(METHODS)
    L = ["% Generated by scripts/06_validate.py from results/validation_main.json (do not edit by hand).",
         r"\begin{table}[t]\centering\footnotesize\setlength{\tabcolsep}{3.2pt}",
         r"\caption{SOC estimation on the 18 unseen test files (FUDS, US06, BJDST; SP2, 50\,\% and 80\,\% start), "
         r"mean over the two start levels and the three initial-SOC scenarios (nominal, $\pm0.20$) of each "
         r"temperature--profile cell (6 runs; 54 runs in the last row). (a) Post-convergence ($t\ge600$\,s) SOC RMSE on "
         r"the admissible reference-SOC interval $[0.10,0.95]$ of the certificate (primary); (b) post-convergence SOC "
         r"RMSE over the whole profile. \% SOC; lowest value of each row in bold. All hyper-parameters frozen on the "
         r"validation files; TFO: $\lambda=10^{-4}$\,s$^{-1}$, $L=400$\,s; FOO: $\lambda=0$, $L=400$\,s; (full): the same "
         r"parameters and gains with full memory.}\label{tab:soc_results}",
         r"\begin{tabular}{ll" + "r" * len(meth) + "}", r"\toprule",
         r"$T$ & profile & " + " & ".join(MLABEL[m] for m in meth) + r" \\"]
    for key, title in (("adm_post_rmse_pct", "(a) admissible interval, $t\\ge600$\\,s"),
                       ("whole_post_rmse_pct", "(b) whole profile, $t\\ge600$\\,s")):
        L += [r"\midrule", r"\multicolumn{%d}{l}{%s} \\" % (2 + len(meth), title), r"\midrule"]
        rows = [(f"{T}\\,\\textdegree C", p, dict(T=T, profile=p)) for T in TEMPS for p in PROFILES]
        rows.append(("all", "all", {}))
        for tl, pl, g in rows:
            vals = [summary_row(J, key, m, **g)[f"{key}_mean"] for m in meth]
            best = min(vals)
            cells = [(r"\textbf{%.2f}" % v) if v == best else ("%.2f" % v) for v in vals]
            L.append(f"{tl} & {pl} & " + " & ".join(cells) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    TAB.mkdir(exist_ok=True)
    (TAB / "tab_soc_results.tex").write_text("\n".join(L) + "\n", encoding="utf-8")


def fig_soc(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    st = styles()
    files = {(f["T"], f["profile"], f["start_level"]): f["file"] for f in J["files"]}
    fig, axs = plt.subplots(6, 3, figsize=ps.figsize("text", 215), sharey=True, layout="constrained")
    for i, (T, sl) in enumerate([(T, s) for T in TEMPS for s in ("50SOC", "80SOC")]):
        for j, p in enumerate(PROFILES):
            ax = axs[i, j]
            f = files[(T, p, sl)]
            th = Z[f"{f}|t_soc"] / 3600.0
            ax.fill_between(th, Z[f"{f}|zref_lo"], Z[f"{f}|zref_hi"], color=ps.SHADE2, lw=0, label="reference band")
            ax.plot(th, Z[f"{f}|zref"], color=ps.INK, lw=0.9, label="reference SOC")
            for m in ("EKF2RC", "TFO"):
                for k, sc in enumerate(("nominal", "plus20", "minus20")):
                    ax.plot(th, Z[f"{f}|zhat|{m}|{sc}"], color=st[m]["color"], ls=st[m]["ls"], lw=0.8,
                            label=MLABEL[m] if k == 0 else None)
            ax.set_ylim(-0.1, 1.08)
            if i == 0:
                ax.set_title(p)
            if j == 0:
                ax.set_ylabel(f"{T} °C, {sl[:2]} %\nSOC (-)")
            if i == 5:
                ax.set_xlabel("time (h)")
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=4)
    ps.save(fig, FIG / "fig_soc_test.pdf")
    plt.close(fig)


ENV_METHODS = ("TFO", "FOO", "TFO_full", "FOO_full", "FOEKF", "EKF2RC", "AEKF2RC")


def fig_envelopes(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    st = styles()
    band = float(D.load_config()["validation"]["error_band_convergence"])
    fits = {(f["T"], f["method"]): f for f in J["envelope_fits"]}
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 120), layout="constrained")
    for j, T in enumerate(TEMPS):
        t = Z[f"env_t|{T}"].astype(float)
        for i, loglog in enumerate((False, True)):
            ax = axs[i, j]
            ax.fill_between(t[1:], 100 * Z[f"env_q10|{T}|TFO"][1:], 100 * Z[f"env_q90|{T}|TFO"][1:], color=ps.SHADE2,
                            lw=0, label="TFO 10-90 %")
            for m in ENV_METHODS:
                ax.plot(t[1:], 100 * Z[f"env_med|{T}|{m}"][1:], color=st[m]["color"], ls=st[m]["ls"], lw=0.9,
                        label=MLABEL[m] + " median")
            if fits[(T, "TFO")]["fitted"]:
                a = Z[f"env_fit|{T}|TFO"]
                ax.plot(a[:, 0], 100 * a[:, 1], color=ps.INK, lw=1.4, ls=(0, (1, 1)), label="tail fit (TFO median)")
            ax.axhline(100 * band, color=ps.INK2, lw=ps.LW["ref"], ls="--")
            ax.set_yscale("log")
            ax.set_ylim(1e-2, 40)
            if loglog:
                ax.set_xscale("log")
                ax.set_xlim(1, t[-1])
            else:
                ax.set_xlim(0, t[-1])
            ax.set_xlabel("time since profile start (s)")
            if j == 0:
                ax.set_ylabel(("log-log" if loglog else "semilog") + "\n|SOC error| (% SOC)")
            if i == 0:
                ax.set_title(f"{T} °C (±0.20 runs, n = {fits[(T, 'TFO')]['n_runs']})")
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=5)
    ps.save(fig, FIG / "fig_error_envelopes.pdf")
    plt.close(fig)


VM_STYLE = {"TFO": ("TFO", "tempered fractional"), "FO": ("FOO", "fractional (λ = 0)"), "2RC": ("FOEKF", "2RC")}


def fig_vt(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    vm = J["settings"]["voltage_models"]
    T = int(vm["representative_T"])
    files = {(f["T"], f["profile"], f["start_level"]): f["file"] for f in J["files"]}
    fig, axs = plt.subplots(4, 3, figsize=ps.figsize("text", 190), layout="constrained")
    for j, p in enumerate(PROFILES):
        f = files[(T, p, "80SOC")]
        t = Z[f"{f}|t_V"].astype(float)
        V = Z[f"{f}|V_meas"]
        w1, w2 = [((a if a >= 0 else t[-1] + a), (b if b > 0 else t[-1] + b)) for a, b in vm["transient_windows_s"]]
        wins = [(0.0, t[-1]), w1, (1000.0, 1060.0), w2]     # 60 s zoom inside window 1 (presentation only)
        for i, (a, b) in enumerate(wins):
            ax = axs[i, j]
            m = (t >= a) & (t <= b)
            x = t[m] / (3600.0 if i == 0 else 1.0)
            ax.plot(x, V[m], color=ps.INK, lw=1.3 if i else 0.8, label="measured")
            for fam in VM_FAMS:
                sn, lab = VM_STYLE[fam]
                s = ps.SERIES[sn]
                ax.plot(x, Z[f"{f}|Vt_{fam}"][m], color=s["color"], ls=s["ls"], lw=0.9, label=f"{lab} model")
            r = J["voltage_models"][f]
            if i == 0:
                ax.set_title(f"{p}, {T} °C, 80 % start" + "\n" + "TFO/FO/2RC RMSE " + "/".join(f"{r[fam]['rmse_mV']:.1f}" for fam in VM_FAMS) + " mV",
                             fontsize=ps.FONT_PT["base"])
                ax.set_xlabel("time (h)")
                for k, (a2, b2) in enumerate((w1, w2)):
                    ax.axvspan(a2 / 3600.0, b2 / 3600.0, color=ps.SHADE, lw=0)
            else:
                ax.set_xlabel("time (s)")
            if j == 0:
                ax.set_ylabel(["whole profile", "window 1", "zoom 60 s", "window 2"][i] + "\n$V_t$ (V)")
    h, l = axs[1, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=4)
    ps.save(fig, FIG / "fig_vt_model.pdf")
    plt.close(fig)


def fig_acf(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    fig, axs = plt.subplots(1, 3, figsize=ps.figsize("text", 62), sharey=True, layout="constrained")
    for j, T in enumerate(TEMPS):
        ax = axs[j]
        fl = [f["file"] for f in J["files"] if f["T"] == T]
        n = np.median([J["voltage_models"][f]["TFO"]["n"] for f in fl])
        for fam in VM_FAMS:
            sn, lab = VM_STYLE[fam]
            s = ps.SERIES[sn]
            A = np.array([Z[f"{f}|acf_{fam}"] for f in fl], float)
            lag = np.arange(A.shape[1])
            if fam == "TFO":
                ax.fill_between(lag, A.min(0), A.max(0), color=ps.SHADE2, lw=0, label="TFO min-max over files")
            ax.plot(lag, np.median(A, 0), color=s["color"], ls=s["ls"], lw=1.0, label=f"{lab} (median)")
        ci = 1.96 / math.sqrt(n)
        ax.axhspan(-ci, ci, color=ps.SHADE, lw=0)
        ax.axhline(0, color=ps.INK2, lw=ps.LW["ref"])
        ax.set_title(f"{T} °C ({len(fl)} test files)")
        ax.set_xlabel("lag (s)")
        if j == 0:
            ax.set_ylabel("residual ACF (-)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=4)
    ps.save(fig, FIG / "fig_resid_acf.pdf")
    plt.close(fig)


# ---------------------------------------------------------------------------------------------------------------
# Findings report (every number read from results/validation_main.json)
# ---------------------------------------------------------------------------------------------------------------
def _n(v, d=3):
    if v is None:
        return "-"
    if isinstance(v, str):
        return v
    if not math.isfinite(v):
        return "inf" if v > 0 else "nan"
    a = abs(v)
    if a != 0 and (a < 1e-3 or a >= 1e5):
        return f"{v:.2e}"
    return f"{v:.{d}f}"


def _p(v):
    return "-" if v is None or (isinstance(v, float) and not math.isfinite(v)) else f"{v:.2g}"


def _pair(J, comp, met, grp):
    for r in J["paired"]:
        if r["comparator"] == comp and r["metric"] == met and r["group"] == grp:
            return r
    return None


def _qs(J, m, T="all"):
    for r in J["q_ref_sensitivity"]:
        if r["method"] == m and r["T"] == T:
            return r
    raise KeyError((m, T))


def _ts(J, kind, var, m, T):
    for r in J["tail_summary"]:
        if r["kind"] == kind and r["variant"] == var and r["method"] == m and r["T"] == T:
            return r
    raise KeyError((kind, m, T))


def write_report(J):
    fz = load_json("frozen_config.json")
    S = {r["method"]: r for r in J["summary"]["by_method"]}
    rt = J["runtime"]
    P = lambda c, g="all", met="adm_post_rmse_pct": _pair(J, c, met, g)  # noqa: E731
    km = "adm_post_rmse_pct"
    rank = sorted(METHODS, key=lambda m: S[m][f"{km}_mean"])
    L = ["# Main test-set comparison (E1)", "",
         f"Generated by `scripts/06_validate.py` from `results/validation_main.json` ({J['generated_utc']}, code hash "
         f"{J['code_hash']}). Frozen configuration `results/frozen_config.json` (frozen {J['frozen_config']['frozen_utc']}, "
         f"sha256 {J['frozen_config']['sha256'][:16]}, freeze code hash {J['frozen_config']['code_hash']}); no "
         f"hyper-parameter changed. {len(J['files'])} test files, all passed data.verify_file: {J['all_files_verified']}; "
         f"{len(J['records'])} runs (8 methods x 18 files x 3 initial-SOC scenarios), clean measured signals. Runtime: main "
         f"wall {rt['main_wall_s']:.1f} s, main process {rt['main_process_s']:.1f} s, worker process sum "
         f"{rt['worker_process_s_sum']:.1f} s ({rt['workers']} workers).", "",
         "Windows: *whole* = all samples; *admissible* = reference SOC in [0.10, 0.95] (the certificate's interval, PRIMARY "
         "for certified claims); *post* = t >= 600 s. Primary metric = admissible post-convergence SOC RMSE (% SOC), as in "
         "the freeze. TFO = lambda 1e-4 1/s, L = 400 s; FOO = lambda 0, L = 400 s; (full) = same parameters and gains, full "
         "memory. Paired differences are TFO minus comparator over the 54 (file, scenario) pairs (positive = TFO worse).", ""]
    # ---- key findings -------------------------------------------------------------------------------------------
    f1 = P("FOO")
    fe, fk, fa = P("FOEKF"), P("EKF2RC"), P("AEKF2RC")
    q = {m: (_qs(J, m)[f"{km}_Q_minus_mean"], _qs(J, m)[f"{km}_Q_ref_mean"], _qs(J, m)[f"{km}_Q_plus_mean"]) for m in METHODS}
    best = [min(METHODS, key=lambda m: q[m][i]) for i in range(3)]
    tT = {T: _ts(J, "error", "primary", "TFO", T) for T in TEMPS}
    tA = _ts(J, "error", "primary", "TFO", "all")
    dA = _ts(J, "incremental", "delta", "TFO", "all")
    L += ["## Key findings", "",
          "1. **Ranking (primary metric, mean over 54 runs):** " + ", ".join(
              f"{MLABEL[m]} {S[m][km + '_mean']:.3f}" for m in rank) + ". TFO does not win on the test set. Whole-profile post-convergence RMSE: " + ", ".join(
              f"{MLABEL[m]} {S[m]['whole_post_rmse_pct_mean']:.3f}" for m in sorted(METHODS, key=lambda m: S[m]['whole_post_rmse_pct_mean'])) + ".",
          f"2. **Tempering at the 400 s budget gives no gain.** TFO - FOO: median {_n(f1['median_diff'])} % SOC "
          f"[{_n(f1['ci_lo'])}, {_n(f1['ci_hi'])}], TFO worse in {f1['n_b_better']}/{f1['n']} pairs (p {_p(f1['wilcoxon_p'])}): "
          "statistically consistent, practically negligible, and in the direction predicted by the validation tie.",
          f"3. **TFO is worse than every Kalman benchmark.** Median TFO - FOEKF {_n(fe['median_diff'])} "
          f"[{_n(fe['ci_lo'])}, {_n(fe['ci_hi'])}] (worse in {fe['n_b_better']}/{fe['n']}), - EKF-2RC {_n(fk['median_diff'])} "
          f"[{_n(fk['ci_lo'])}, {_n(fk['ci_hi'])}] ({fk['n_b_better']}/{fk['n']}), - AEKF-2RC {_n(fa['median_diff'])} "
          f"[{_n(fa['ci_lo'])}, {_n(fa['ci_hi'])}] ({fa['n_b_better']}/{fa['n']}). Exceptions (CI containing 0): "
          + "; ".join(f"{MLABEL[c]} at {g}" for c in ("FOEKF", "EKF2RC", "AEKF2RC") for g in [f"T={T}" for T in TEMPS] +
                      [f"profile={p}" for p in PROFILES] if P(c, g)["ci_lo"] <= 0 <= P(c, g)["ci_hi"]) + ".",
          f"4. **Full memory is not uniformly better.** TFO - TFO (full): " + "; ".join(
              f"{g} {_n(P('TFO_full', g)['median_diff'])} [{_n(P('TFO_full', g)['ci_lo'])}, {_n(P('TFO_full', g)['ci_hi'])}]"
              for g in ["all"] + [f"T={T}" for T in TEMPS]) + ". The frozen certified horizon L_cert exceeds every test "
          "profile, so TFO (full) is also the certified-memory ablation.",
          f"5. **Reference capacity matters as much as the method.** With Q_ref - u_Q / Q_ref / Q_ref + u_Q the best method "
          f"is {MLABEL[best[0]]} / {MLABEL[best[1]]} / {MLABEL[best[2]]}; TFO {q['TFO'][0]:.3f} / {q['TFO'][1]:.3f} / "
          f"{q['TFO'][2]:.3f} % SOC (Section 4): the spread of TFO's mean RMSE over Q_ref -+ u_Q ({q['TFO'][2] - q['TFO'][0]:.3f}) "
          f"exceeds the mean TFO - FOEKF gap ({S['TFO'][km + '_mean'] - S['FOEKF'][km + '_mean']:.3f}).",
          f"6. **Transients.** Median first entry into +-2 %: TFO {_n(S['TFO']['whole_first_entry_s_median'], 0)} s, "
          f"FOEKF {_n(S['FOEKF']['whole_first_entry_s_median'], 0)} s, EKF-2RC {_n(S['EKF2RC']['whole_first_entry_s_median'], 0)} s. "
          f"The +-0.20 errors of TFO decay at lambda_eff (median {_n(tA['lambda_eff_median'])} 1/s; per T "
          + ", ".join(f"{T} C {_n(tT[T]['lambda_eff_median'])}" for T in TEMPS)
          + f") inside the SOC-loop range l1 kappa (Section 5), about {tA['lambda_eff_median'] / 1e-4:.0f} times the frozen "
          f"lambda; rho median {_n(tA['rho_median'])} (CI > 0 in {tA['n_rho_ci_gt0']}/{tA['n_fitted']}, < 0 in "
          f"{tA['n_rho_ci_lt0']}/{tA['n_fitted']}); pure-exponential R^2 {_n(tA['r2_exp_only_median'], 4)} vs pure-algebraic "
          f"{_n(tA['r2_alg_only_median'], 4)}. The fitted windows are the pre-asymptotic loop transient; the asymptotic "
          "regime of thm:asymptotic (e^{-lambda t} t^{-alpha} or t^{-1-alpha}) is not observable before the model-error floor, "
          f"so no exponential or algebraic tail law is claimed. The floor-free incremental error gives rho median "
          f"{_n(dA['rho_median'])} (CI > 0 in {dA['n_rho_ci_gt0']}/{dA['n_fitted']}), a weak algebraic factor, at the same loop rate.",
          "7. **Voltage models (open loop, test files):** TFO, FO and 2RC are practically identical; residuals are strongly "
          "autocorrelated (Ljung-Box p = 0 for every file and model, Section 6).", ""]
    # ---- headline table ------------------------------------------------------------------------------------------
    L += ["## 1. Per-method summary (54 runs)", "",
          "| method | adm. post RMSE mean / median / max | whole post RMSE | adm. post max abs | within 2 % (adm. post, %) | adm. conv. time median (never) | first entry (s) | a-priori V_t RMSE adm. (mV) | process / wall per sample (us) | history | bytes |",
          "|---|---|---|---|---|---|---|---|---|---|---|"]
    for m in METHODS:
        r = S[m]
        L.append(f"| {MLABEL[m]} | {_n(r[km + '_mean'])} / {_n(r[km + '_median'])} / {_n(r[km + '_max_finite'])} | "
                 f"{_n(r['whole_post_rmse_pct_mean'])} | {_n(r['adm_post_maxabs_pct_mean'])} | "
                 f"{_n(r['adm_post_within2_pct_mean'], 1)} | {_n(r['adm_conv_time_s_median'], 0)} ({r['adm_conv_time_s_n_inf']}) | "
                 f"{_n(r['whole_first_entry_s_median'], 0)} | {_n(r['adm_vt_rmse_mV_mean'], 2)} | "
                 f"{_n(r['cpu_per_sample_us_mean'], 2)} / {_n(r['wall_per_sample_us_median'], 2)} | "
                 f"{_n(r['n_history_samples_median'], 0)} | {_n(r['bytes_state_median'], 0)} |")
    L += ["", "Means unless stated. Whole-profile convergence (last exit from +-2 %) is 'never' for "
          + ", ".join(f"{MLABEL[m]} {S[m]['whole_conv_time_s_n_inf']}/54" for m in METHODS)
          + " runs: the end-of-discharge region dominates it. Process time has 15.6 ms resolution on Windows; wall "
          "times are single runs on a shared machine. Per temperature and profile: `tables/tab_soc_results.tex`.", ""]
    # ---- paired --------------------------------------------------------------------------------------------------
    L += ["## 2. Paired differences, primary metric (% SOC)", "",
          "Median [95 % bootstrap CI of the median]; TFO better/worse; Wilcoxon p. Profile and scenario groups are in the JSON.", "",
          "| comparator | all (54) | 0 C (18) | 25 C (18) | 45 C (18) |", "|---|---|---|---|---|"]
    for c in J["settings"]["paired"]["comparators"]:
        cells = []
        for g in ["all"] + [f"T={T}" for T in TEMPS]:
            r = P(c, g)
            cells.append(f"{_n(r['median_diff'])} [{_n(r['ci_lo'])}, {_n(r['ci_hi'])}]; {r['n_a_better']}/{r['n_b_better']}; "
                         f"{_p(r['wilcoxon_p'])}")
        L.append(f"| {MLABEL[c]} | " + " | ".join(cells) + " |")
    L += ["", "All 54 pairs, other metrics (median [CI]; TFO better/worse):", ""]
    for met in ("whole_post_rmse_pct", "adm_post_maxabs_pct", "adm_vt_rmse_mV", "adm_conv_time_s"):
        tag = " (supplementary, post hoc)" if met == "adm_conv_time_s" else ""
        L.append(f"* `{met}`{tag}: " + "; ".join(
            f"{MLABEL[c]} {_n(P(c, met=met)['median_diff'])} [{_n(P(c, met=met)['ci_lo'])}, {_n(P(c, met=met)['ci_hi'])}] "
            f"{P(c, met=met)['n_a_better']}/{P(c, met=met)['n_b_better']}" for c in J["settings"]["paired"]["comparators"]
            if c != "CC" and P(c, met=met) is not None))
    nsub = {}
    for r in J["paired"]:
        if r["metric"] == km and r["group"] != "all":
            d = nsub.setdefault(MLABEL[r["comparator"]], [0, 0, 0, []])
            d[0] += 1
            d[1] += int(r["ci_lo"] > 0)
            d[2] += int(r["ci_hi"] < 0)
            if r["ci_hi"] < 0:
                d[3].append(r["group"])
    L += ["", "Subgroups (3 temperatures, 3 profiles, 3 scenarios) with the CI of the median difference above 0 (TFO worse) / "
          "below 0 (TFO better): " + "; ".join(f"{k} {v[1]}/{v[0]} / {v[2]}/{v[0]}" + (f" ({', '.join(v[3])})" if v[3] else "")
                                               for k, v in nsub.items()) + ".", ""]
    # ---- memory / certificates -------------------------------------------------------------------------------------
    FC = J["full_memory_certificates"]
    L += ["## 3. Certificates of the evaluated memories", "",
          f"(DC) at sigma = 0 with the frozen gains and kappa bounds holds for TFO and FOO at L = 400 s and at full memory at "
          f"every temperature: {all(r['certified_L400'] and r['certified_full'] for r in FC)}. sigma* at L = 400 s: " +
          ", ".join(f"{r['method']} {r['T']} C {_n(r['sigma_star_L400'])}" for r in FC) + " 1/s; at full memory sigma* = lambda ("
          + ", ".join(f"{r['method']} {_n(r['sigma_star_full'])}" for r in FC if r["T"] == 0) + " 1/s). L_cert(T) of the "
          "freeze exceeds the longest test profile at every temperature: "
          f"{all(r['L_cert_ge_longest_test_profile'] for r in FC if 'L_cert_s' in r)}."]
    # ---- Q_ref -----------------------------------------------------------------------------------------------------
    cap = load_json("capacity.json")["Q_ref_T_SP2"]
    L += ["", "## 4. Reference-SOC uncertainty", "",
          "Estimates unchanged, reference recomputed with Q_ref(T) -+ u_Q(T) (u_Q/Q_ref " +
          ", ".join(f"{T} C {cap[str(T)]['u_Q_rel'] * 100:.2f} %" for T in TEMPS) +
          "). Mean admissible post RMSE (% SOC), Q_ref - u_Q / Q_ref / Q_ref + u_Q:", "",
          "| method | all | 0 C | 25 C | 45 C |", "|---|---|---|---|---|"]
    for m in METHODS:
        L.append(f"| {MLABEL[m]} | " + " | ".join(
            "{:.2f} / {:.2f} / {:.2f}".format(*(_qs(J, m, T)[f"{km}_{k}_mean"] for k in ("Q_minus", "Q_ref", "Q_plus")))
            for T in ("all",) + TEMPS) + " |")
    # ---- tails -----------------------------------------------------------------------------------------------------
    tf = J["settings"]["tail_fit"]
    L += ["", "## 5. Convergence tails (+-0.20 runs)", "",
          f"Declared before the test run: log|e| = c - lambda_eff t - rho log t, OLS on 1 s samples from t = "
          f"{tf['t_start_s']:.0f} s to the first |e| <= {tf['e_stop']} (sensitivity {tf['e_stop_sensitivity']}), first sign "
          f"change or t = {tf['t_max_s']:.0f} s; >= {tf['min_samples']} samples; 95 % Newey-West CIs ({tf['hac_lags']} lags). "
          f"Incremental: delta = zhat(scenario) - zhat(nominal), stop |delta| <= {tf['delta_stop']}.", "",
          "| kind | method | T | fitted | lambda_eff median [IQR] | rho median [IQR] | rho CI >0 / <0 | R^2 full / exp / alg | corr | window (s) |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    rows = [("error", "primary", "TFO", T) for T in ("all",) + TEMPS] + \
        [("error", "primary", m, "all") for m in ("FOO", "TFO_full", "FOEKF", "EKF2RC", "AEKF2RC")] + \
        [("incremental", "delta", "TFO", T) for T in ("all",) + TEMPS] + \
        [("incremental", "delta", m, "all") for m in ("FOO", "FOEKF", "EKF2RC", "AEKF2RC")]
    for kind, var, m, T in rows:
        r = _ts(J, kind, var, m, T)
        if r["n_fitted"] == 0:
            L.append(f"| {kind} | {MLABEL[m]} | {T} | 0/{r['n_runs']} | not fitted (converged before the window) | | | | | |")
            continue
        L.append(f"| {kind} | {MLABEL[m]} | {T} | {r['n_fitted']}/{r['n_runs']} | {_n(r['lambda_eff_median'])} "
                 f"[{_n(r['lambda_eff_q25'])}, {_n(r['lambda_eff_q75'])}] | {_n(r['rho_median'])} [{_n(r['rho_q25'])}, "
                 f"{_n(r['rho_q75'])}] | {r['n_rho_ci_gt0']}/{r['n_rho_ci_lt0']} | {_n(r['r2_median'], 4)} / "
                 f"{_n(r['r2_exp_only_median'], 4)} / {_n(r['r2_alg_only_median'], 4)} | {_n(r['corr_lambda_rho_median'], 2)} | "
                 f"{_n(r['window_s_median'], 0)} |")
    tp = fz["methods"]["TFO"]["per_T"]
    L += ["", "l1 kappa1 .. l1 kappa2 of the frozen TFO (1/s): " + "; ".join(
        f"{T} C {_n(tp[str(T)]['hyper']['l1'] * tp[str(T)]['kappa1'])}..{_n(tp[str(T)]['hyper']['l1'] * tp[str(T)]['kappa2'])}"
        for T in TEMPS) + f". lambda_eff and rho are strongly anti-correlated in every fit (corr about -0.97); e_stop "
        f"sensitivity: rho median " + ", ".join(
            f"{v}: {_n(_ts(J, 'error', f'e_stop_{v:g}', 'TFO', 'all')['rho_median'])}" for v in tf["e_stop_sensitivity"]) +
        ". Median-envelope fits (TFO): " + "; ".join(
            f"{f['T']} C " + (f"lambda_eff {_n(f['lambda_eff'])} [{_n(f['lambda_eff_ci'][0])}, {_n(f['lambda_eff_ci'][1])}], rho "
                              f"{_n(f['rho'])} [{_n(f['rho_ci'][0])}, {_n(f['rho_ci'][1])}], R^2 {_n(f['r2'], 4)}"
                              if f["fitted"] else f"not fitted ({f['n']} samples)")
            for f in J["envelope_fits"] if f["method"] == "TFO") + ".", ""]
    # ---- voltage models ----------------------------------------------------------------------------------------------
    VM = J["voltage_models"]
    L += ["## 6. Open-loop voltage models on the test files", "",
          "Identification parameter sets (causal_full), causal timing, warm start from the end of CV; mean over the 6 files "
          "per temperature. RMSE whole / admissible / z >= 0.1 (mV); lag-1 ACF.", "", "| T | TFO | FO | 2RC |", "|---|---|---|---|"]
    for T in TEMPS:
        fl = [f["file"] for f in J["files"] if f["T"] == T]
        g = lambda fam, k: float(np.mean([VM[f][fam][k] for f in fl]))  # noqa: E731
        L.append(f"| {T} | " + " | ".join(f"{g(fam, 'rmse_mV'):.1f} / {g(fam, 'rmse_admissible_mV'):.1f} / "
                                          f"{g(fam, 'rmse_z_ge_knee_mV'):.1f}; {g(fam, 'acf_lag1'):.2f}" for fam in VM_FAMS) + " |")
    cons = max(VM[f][fam]["consistency_abs_diff_mV"] or 0.0 for f in VM for fam in VM_FAMS)
    lbmax = max(VM[f][fam]["ljung_box_p"] for f in VM for fam in VM_FAMS)
    L += ["", f"Max Ljung-Box p over files and models {lbmax:.2g}; max |RMSE - identification_refined.json| {cons:.1e} mV.", "",
          "## 7. Outputs and post hoc items", "",
          "`results/validation_main.json`, `results/validation_series.npz`, `tables/tab_soc_results.tex`, "
          "`figures/fig_soc_test.pdf`, `fig_error_envelopes.pdf`, `fig_vt_model.pdf`, `fig_resid_acf.pdf`. Added after the "
          "first test run (reported only, no selection): first-entry time into +-2 %, paired tests of the admissible "
          "convergence and first-entry times, Q_ref sensitivity per temperature, a 60 s zoom row in fig_vt_model."]
    (REP / "validation_main_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def make_outputs():
    J, Z = load_outputs()
    write_table(J)
    fig_soc(J, Z)
    fig_envelopes(J, Z)
    fig_vt(J, Z)
    fig_acf(J, Z)
    write_report(J)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report-only", action="store_true")
    ap.add_argument("--compute-only", action="store_true")
    a = ap.parse_args()
    _, vm, _ = cfg()
    if not a.report_only:
        compute(int(vm["max_workers"]))
    if not a.compute_only:
        make_outputs()


if __name__ == "__main__":
    main()
