"""E2: robustness of the frozen estimators on the 18 test files (FUDS / US06 / BJDST, SP2, 0/25/45 C).

Settings: config.yaml `robustness` (declared 2026-09-27 before the first run of this script), `estimators`,
`design_tuning.admissible_soc_interval`.  Every parameter and hyper-parameter comes from results/frozen_config.json
('methods' = primary memory budget 400 s); nothing is re-tuned.  Test files are loaded with
experiments.load_case(..., allow_splits=('test',), final_evaluation=True) (data.verify_file inside).

Cases (per file and method; 'nominal' initial SOC unless stated):
 (a) z0 = reference +- 0.20 (plus20 / minus20) and the nominal baseline;
 (b) current-sensor offset delta_I in {-50, -20, +20, +50} mA;
 (c) voltage noise std {1, 5, 10} mV;   (d) current noise std {10, 50} mA   (20 Monte-Carlo seeds each);
 (e) joint parameter scaling R0 | Rp (R1, R2) | Cp (tau1, tau2) x {0.8, 1.2}, alpha x {0.9, 1.1} (fractional
     models), every sign combination; the worst combination per method is reported;
 (f) capacity Q_n x {0.95, 1.05};   (g) parameters/OCV/Q_n/hyper-parameters of 25 C on the 0 and 45 C files.
Metrics: admissible post-convergence RMSE (reference SOC in [0.10, 0.95], t - t0 >= 600 s; PRIMARY) and the
whole-profile metrics of metrics.soc_metrics.  Bias theory: thm:robust(vi) / eq:m4b:steady (TFO, FOO) and the
Coulomb-counting drift.  Figure trajectories: the file declared in FIG_FILE (fixed before the first run).

Outputs: results/robustness.json, tables/tab_robustness.tex, figures/fig_robustness.pdf, reports/robustness_findings.md
Usage: python scripts/06b_robustness.py [--report-only] [--workers N]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import itertools
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES = ROOT / "results"
CACHE = ROOT / "scratch" / "robustness_cache"
TASK_VERSION = "E2-2026-09-27-a"
FIG_FILE = "SP2_25C_FUDS_80SOC"          # trajectory panel of the figure (declared before the first run)
FIG_STRIDE = 10                           # stored trajectory samples every 10 s
FRACTIONAL = ("TFO", "FOO", "FOEKF")
TWO_RC = ("EKF2RC", "AEKF2RC")


# ---------------------------------------------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------------------------------------------
def cfg():
    c = D.load_config()
    return c, dict(c["robustness"]), dict(c["estimators"]), dict(c["design_tuning"])


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def code_hash() -> str:
    c, rb, est, dt = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([rb, est, dt["admissible_soc_interval"], c["validation"]], sort_keys=True).encode())
    h.update(TASK_VERSION.encode())
    for f in ("src/tfso/observer.py", "src/tfso/benchmarks.py", "src/tfso/tempered.py", "src/tfso/experiments.py",
              "src/tfso/metrics.py", "src/tfso/model.py", "results/frozen_config.json", "results/capacity.json"):
        h.update((ROOT / f).read_bytes())
    src = (ROOT / "scripts" / "06b_robustness.py").read_text(encoding="utf-8")
    h.update(src.split(chr(10) + "# === " + "ANALYSIS ===" + chr(10))[0].encode())   # compute part only (report edits keep the cache)
    return h.hexdigest()[:16]


_FZ = None
_OCV = {}


def frozen():
    global _FZ
    if _FZ is None:
        _FZ = load_json("frozen_config.json")
    return _FZ


def method_setup(method, T):
    """(params, hyper, FastOCV) of the frozen primary configuration at temperature T."""
    e = frozen()["methods"][method]["per_T"][str(int(T))]
    p = dict(e["params"])
    hy = dict(e.get("hyper", {}))
    if method == "CC":
        return p, hy, None
    key = (method, int(T))
    if key not in _OCV:
        _OCV[key] = O.as_fast_ocv(MD.AlignedOCV(int(T), E.q_id(int(T))), s=p["s"], dq=p["dq"])
    return p, hy, _OCV[key]


def q_ref(T):
    return float(load_json("capacity.json")["Q_ref_T_SP2"][str(int(T))]["Q_ref_Ah"])


# ---------------------------------------------------------------------------------------------------------------
# Scenario list (identical for every file; the temperature mismatch only on the 0 / 45 C files)
# ---------------------------------------------------------------------------------------------------------------
def param_combos(method):
    _, rb, _, _ = cfg()
    ps, al = [float(v) for v in rb["param_scale"]], [float(v) for v in rb["alpha_scale"]]
    if method in FRACTIONAL:
        out = []
        for fR0, fRp, fCp, fa in itertools.product(ps, ps, ps, al):
            out.append((f"R0x{fR0:g}_Rpx{fRp:g}_Cpx{fCp:g}_ax{fa:g}",
                        dict(R0=fR0, Rp=fRp, Cp=fCp, alpha=fa)))
        return out
    if method in TWO_RC:
        return [(f"R0x{a:g}_Rpx{b:g}_Cpx{c:g}", dict(R0=a, R1=b, R2=b, tau1=c, tau2=c))
                for a, b, c in itertools.product(ps, ps, ps)]
    return []                                       # CC has no model parameters (only Q_n, case f)


def scenarios(T, method):
    """List of dicts: scenario, group, level, z0, corruption, seeds (None = deterministic), factors, mismatch."""
    _, rb, _, _ = cfg()
    out = [dict(scenario="baseline", group="baseline", level=0.0, z0="nominal")]
    for z in rb["z0_scenarios"]:
        if z != "nominal":
            out.append(dict(scenario=f"z0_{z}", group="z0", level=0.2 if z == "plus20" else -0.2, z0=z))
    for d in rb["current_offset_A"]:
        out.append(dict(scenario=f"bias_{1000 * d:+.0f}mA", group="bias", level=float(d), z0="nominal",
                        corruption=dict(I_offset=float(d))))
    for s in rb["voltage_noise_std_V"]:
        out.append(dict(scenario=f"vnoise_{1000 * s:.0f}mV", group="vnoise", level=float(s), z0="nominal",
                        corruption=dict(V_noise_std=float(s)), mc=True))
    for s in rb["current_noise_std_A"]:
        out.append(dict(scenario=f"inoise_{1000 * s:.0f}mA", group="inoise", level=float(s), z0="nominal",
                        corruption=dict(I_noise_std=float(s)), mc=True))
    for lab, fac in param_combos(method):
        out.append(dict(scenario=f"param_{lab}", group="param", level=lab, z0="nominal", factors=fac))
    for f in rb["capacity_factor"]:
        out.append(dict(scenario=f"cap_{float(f):g}", group="cap", level=float(f), z0="nominal", cap=float(f)))
    tm = rb["temperature_mismatch"]
    if int(T) in [int(v) for v in tm["file_T"]]:
        out.append(dict(scenario=f"temp_{int(tm['T_used'])}C", group="temp", level=int(tm["T_used"]), z0="nominal",
                        T_used=int(tm["T_used"])))
    return out


# ---------------------------------------------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------------------------------------------
def adm_metrics(t, e, zref):
    """Admissible-interval metrics (reference SOC in the admissible interval; post: t - t0 >= t_post)."""
    _, _, est, dt = cfg()
    lo, hi = dt["admissible_soc_interval"]
    tpost = float(est["post_convergence_t_s"])
    band = float(D.load_config()["validation"]["error_band_convergence"])
    adm = (zref >= lo) & (zref <= hi)
    post = (t - t[0]) >= tpost
    m = adm & post
    ee = e[m]
    out = dict(adm_n=int(ee.size))
    if ee.size == 0 or not np.all(np.isfinite(ee)):
        for k in ("rmse", "mae", "maxabs", "bias", "within1", "within2"):
            out[f"adm_{k}_pct"] = float("inf") if k in ("rmse", "mae", "maxabs") else float("nan")
    else:
        a = np.abs(ee)
        out.update(adm_rmse_pct=float(100 * np.sqrt(np.mean(ee * ee))), adm_mae_pct=float(100 * np.mean(a)),
                   adm_maxabs_pct=float(100 * np.max(a)), adm_bias_pct=float(100 * np.mean(ee)))
        for b in est["within_bands"]:
            out[f"adm_within{int(round(100 * b))}_pct"] = float(100 * np.mean(a <= b))
    # admissible convergence time: last admissible sample outside the band -> next admissible sample
    idx = np.flatnonzero(adm)
    bad = idx[~(np.abs(e[idx]) <= band)]
    if bad.size == 0:
        out["adm_conv_time_s"] = 0.0 if idx.size else float("nan")
    else:
        later = idx[idx > bad[-1]]
        out["adm_conv_time_s"] = float(t[later[0]] - t[0]) if later.size else float("inf")
    return out


def run_one(method, p, hy, f, case, sc, seed=None, extra=None, keep=False):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        rec = E.run_case(method, p, hy, case, z0_scenario=sc["z0"], ocv=f, corruption=sc.get("corruption"),
                         seed=seed, scenario=sc["scenario"], keep_series=True, extra=extra)
    s = rec.pop("_series")
    e = np.asarray(s["zhat"], float) - np.asarray(s["zref"], float)
    rec.update(adm_metrics(case.t, e, case.soc_ref))
    rec.update(group=sc["group"], level=sc["level"], duration_s=float(case.t[-1] - case.t[0]))
    return rec, (e if keep else None)


# ---------------------------------------------------------------------------------------------------------------
# Bias theory (thm:robust(vi), eq:m4b:steady) for TFO / FOO
# ---------------------------------------------------------------------------------------------------------------
def bias_coefficient(method, p, hy, h=1.0):
    """A [Ohm] with (zhat - z)_ss = -(delta_I / kappa) A: implemented (M = mu_{h,L}(0)) and continuous (M = lam^a)."""
    c = O.model_constants(p)
    lam = 0.0 if method == "FOO" else float(p.get("lam", 0.0))
    N_L = int(math.ceil(float(hy["L_s"]) / h - 1e-9))
    args = (float(p["R0"]), c["ap"], c["bp"], float(hy["l1"]), float(hy["l2"]), float(p.get("eta", 1.0)),
            float(p["Qn"]), lam, float(p["alpha"]))
    A_impl = TM.bias_steady_state(1.0, 1.0, *args, h=h, N_L=N_L, I=0.0)
    A_cont = TM.bias_steady_state(1.0, 1.0, *args, h=None, N_L=None, I=0.0)
    M = TM.mu_hL(float(p["alpha"]), lam, 0.0, h, N_L)
    R_tot_impl = float(p["R0"]) + c["bp"] / (c["ap"] + M)
    R_tot_cont = float(p["R0"]) + c["bp"] / (c["ap"] + lam ** float(p["alpha"]))
    return dict(A_impl=float(A_impl), A_cont=float(A_cont), mu0=float(M), R_tot_impl=float(R_tot_impl),
                R_tot_cont=float(R_tot_cont), N_L=N_L, lam=lam)


def bias_compare(method, p, hy, f, case, dI, e_b, e_0):
    """Observed delta_e = e_biased - e_nominal vs the quasi-steady prediction on the admissible post window."""
    _, _, est, dt = cfg()
    lo, hi = dt["admissible_soc_interval"]
    t, zref = case.t, case.soc_ref
    m = (zref >= lo) & (zref <= hi) & ((t - t[0]) >= float(est["post_convergence_t_s"]))
    d_obs = (e_b - e_0)[m]
    out = dict(method=method, file=case.logical_id, T=case.T, dI=float(dI), n=int(m.sum()))
    if method in ("TFO", "FOO"):
        bc = bias_coefficient(method, p, hy)
        z_obs = 1.0 - (1.0 - zref[m]) * q_ref(case.T) / float(p["Qn"])
        kap = np.asarray(f.dU(z_obs), float)
        pred = -dI * bc["A_impl"] / kap
        pred_c = -dI * bc["A_cont"] / kap
        zi = hy.get("z_interval")
        k1, k2 = O.slope_bounds_fast(f, float(zi[0]), float(zi[1]))
        out.update(bc, pred_mean=float(np.mean(pred)), pred_cont_mean=float(np.mean(pred_c)),
                   pred_k1=float(-dI * bc["A_impl"] / k1), pred_k2=float(-dI * bc["A_impl"] / k2),
                   kappa1=float(k1), kappa2=float(k2),
                   rms_obs_minus_pred=float(np.sqrt(np.mean((d_obs - pred) ** 2))),
                   corr=float(np.corrcoef(d_obs, pred)[0, 1]) if d_obs.size > 2 and np.std(d_obs) > 0 else float("nan"),
                   t_cross_s=float(3600.0 * float(p["Qn"]) * abs(bc["A_impl"]) / (float(p.get("eta", 1.0)) * k1)))
    if method == "CC":
        te = float(t[-1] - t[0])
        out.update(drift_end_pred=float(float(p.get("eta", 1.0)) * dI * te / (3600.0 * float(p["Qn"]))),
                   drift_end_obs=float((e_b - e_0)[-1]))
    out.update(obs_mean=float(np.mean(d_obs)) if d_obs.size else float("nan"),
               obs_q05=float(np.quantile(d_obs, 0.05)) if d_obs.size else float("nan"),
               obs_q95=float(np.quantile(d_obs, 0.95)) if d_obs.size else float("nan"),
               obs_end=float((e_b - e_0)[-1]),
               obs_adm_end=float(d_obs[-1]) if d_obs.size else float("nan"),
               t_adm_end_s=float(t[m][-1] - t[0]) if d_obs.size else float("nan"))
    return out


# ---------------------------------------------------------------------------------------------------------------
# One file (worker task)
# ---------------------------------------------------------------------------------------------------------------
_DROP = ("z0_source", "seed_entropy", "N_L_requested", "n_history_samples", "bytes_state", "band", "t_post_s",
         "h_l1_kappa2_clip", "explicit_stable", "cpu_process_s", "cpu_per_sample_us", "wall_per_sample_us")


def file_task(lid):
    t_w0, t_c0 = time.perf_counter(), time.process_time()
    _, rb, _, _ = cfg()
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)
    if not case.meta["verify_passed"]:
        raise RuntimeError(f"{lid} failed data.verify_file")
    T = case.T
    seeds = [int(s) for s in rb["mc_seeds"]][: int(rb["mc_runs"])]
    recs, bias_rows, traj = [], [], {}
    stride = slice(None, None, FIG_STRIDE)
    if lid == FIG_FILE:
        traj = dict(t=(case.t - case.t[0])[stride].tolist(), zref=case.soc_ref[stride].tolist(), e={})
    for method in rb["methods"]:
        p0, hy0, f0 = method_setup(method, T)
        e_nom = None
        for sc in scenarios(T, method):
            p, hy, f, extra = p0, hy0, f0, dict(group_label=sc["group"])
            if "factors" in sc:
                p, fac = E.perturb_params(p0, 0.0, factors=sc["factors"])
                extra.update({f"fac_{k}": v for k, v in fac.items()})
            if "cap" in sc:
                p = E.capacity_mismatch(p0, sc["cap"])
                extra["capacity_mismatch"] = sc["cap"]
            if "T_used" in sc:
                p, hy, f = method_setup(method, sc["T_used"])
                extra["temperature_mismatch"] = sc["T_used"]
            keep = sc["group"] in ("baseline", "bias", "z0")
            for seed in (seeds if sc.get("mc") else [None]):
                rec, e = run_one(method, p, hy, f, case, sc, seed=seed, extra=extra, keep=keep)
                if sc["group"] in ("baseline", "z0"):
                    base = e if sc["scenario"] == "baseline" else e_nom
                    for bd in rb["diagnostic_forgetting_time"]["bands"]:
                        rec[f"fgt{int(round(100 * bd))}_s"] = MX.convergence_time(case.t, e - base, float(bd))
                recs.append({k: v for k, v in rec.items() if k not in _DROP})
                if sc["scenario"] == "baseline":
                    e_nom = e
                if sc["group"] == "bias":
                    bias_rows.append(bias_compare(method, p, hy, f, case, sc["level"], e, e_nom))
                if traj and keep:
                    traj["e"].setdefault(sc["scenario"], {})[method] = np.round(e[stride], 6).tolist()
    return dict(file=lid, T=T, profile=case.profile, start_level=case.start_level, n=int(case.t.size),
                duration_s=float(case.t[-1] - case.t[0]), z_ref0=case.z_ref0, verify_passed=True,
                records=recs, bias=bias_rows, traj=traj,
                wall_s=time.perf_counter() - t_w0, process_s=time.process_time() - t_c0, pid=os.getpid())


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        v = float(o)
        return v if math.isfinite(v) else ("inf" if v > 0 else ("-inf" if v < 0 else "nan"))
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def unjson(v):
    if isinstance(v, str) and v in ("inf", "-inf", "nan"):
        return float(v)
    return v


def compute(workers):
    c, rb, _, _ = cfg()
    files = list(c["splits"]["test_dynamic"])
    assert len(files) == 18
    CACHE.mkdir(parents=True, exist_ok=True)
    ch = code_hash()
    out, todo = {}, []
    for lid in files:
        p = CACHE / f"{lid}.json"
        if p.exists():
            with open(p, "r", encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("code_hash") == ch:
                out[lid] = d
                continue
        todo.append(lid)
    print(f"[E2] code hash {ch}; cached {len(out)}, to run {len(todo)} (workers {workers})", flush=True)
    t0 = time.perf_counter()
    if todo:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for lid, d in zip(todo, ex.map(file_task, todo)):
                d["code_hash"] = ch
                with open(CACHE / f"{lid}.json", "w", encoding="utf-8") as fh:
                    json.dump(jsonable(d), fh)
                out[lid] = json.loads(json.dumps(jsonable(d)))
                print(f"[E2] {lid}: {len(d['records'])} runs, wall {d['wall_s']:.1f} s, process {d['process_s']:.1f} s",
                      flush=True)
    info = dict(code_hash=ch, wall_this_call_s=time.perf_counter() - t0, n_files_computed=len(todo), workers=workers)
    if todo:
        with open(CACHE / "_run_info.json", "w", encoding="utf-8") as fh:
            json.dump(dict(info, compute_wall_s=info["wall_this_call_s"], utc=datetime.now(timezone.utc).isoformat()), fh)
    return [out[l] for l in files], info


# === ANALYSIS ===
METRICS = ("adm_rmse_pct", "post_rmse_pct", "rmse_pct", "adm_maxabs_pct", "maxabs_pct", "adm_within2_pct",
           "within2_pct", "adm_within1_pct", "adm_conv_time_s", "conv_time_s", "vt_rmse_mV", "adm_bias_pct",
           "final_abs_err_pct", "fgt1_s", "fgt2_s")
PAIRED_METRICS = ("adm_rmse_pct", "post_rmse_pct", "adm_conv_time_s", "conv_time_s", "fgt1_s", "fgt2_s")
CONV = ("adm_conv_time_s", "conv_time_s", "fgt1_s", "fgt2_s")


def qstats(v):
    v = np.asarray([unjson(x) for x in v], float)
    v = v[~np.isnan(v)]
    if v.size == 0:
        return dict(n=0, median=float("nan"), q25=float("nan"), q75=float("nan"), n_inf=0)
    meth = "inverted_cdf" if np.any(np.isinf(v)) else "linear"
    q25, med, q75 = np.quantile(v, [0.25, 0.5, 0.75], method=meth)
    return dict(n=int(v.size), median=float(med), q25=float(q25), q75=float(q75), n_inf=int(np.sum(np.isinf(v))),
                mean=float(np.mean(v)) if np.all(np.isfinite(v)) else float("nan"))


def frame(results):
    import pandas as pd
    rows = []
    for d in results:
        for r in d["records"]:
            rows.append({k: unjson(v) for k, v in r.items()})
    return pd.DataFrame(rows)


def per_file(df):
    """One value per (scenario, method, file): the seed median for Monte-Carlo cases (+ seed IQR)."""
    g = df.groupby(["scenario", "group", "method", "file", "T"], dropna=False)
    agg = {}
    for m in METRICS:
        agg[m] = g[m].median()
        agg[m + "_seed_iqr"] = g[m].quantile(0.75) - g[m].quantile(0.25)
    agg["n_runs"] = g.size()
    import pandas as pd
    return pd.DataFrame(agg).reset_index()


def worst_param(pf, methods):
    """Per method: the parameter combination with the largest mean over files of the primary metric."""
    out = {}
    sub = pf[pf.group == "param"]
    for m in methods:
        s = sub[sub.method == m]
        if s.empty:
            continue
        means = s.groupby("scenario")["adm_rmse_pct"].mean().sort_values()
        out[m] = dict(worst=str(means.index[-1]), worst_mean=float(means.iloc[-1]), best=str(means.index[0]),
                      best_mean=float(means.iloc[0]), median_over_combos=float(means.median()),
                      n_combos=int(means.size), all_means={str(k): float(v) for k, v in means.items()})
    return out


def with_pseudo(pf, wp):
    """Adds pseudo-scenario 'param_worst' (each method's own worst combination)."""
    import pandas as pd
    parts = [pf]
    for m, w in wp.items():
        s = pf[(pf.method == m) & (pf.scenario == w["worst"])].copy()
        s["scenario"], s["group"] = "param_worst", "param_worst"
        parts.append(s)
    return pd.concat(parts, ignore_index=True)


def summaries(pf, methods, scen_order):
    out = {}
    for sc in scen_order:
        out[sc] = {}
        for m in methods:
            s = pf[(pf.scenario == sc) & (pf.method == m)]
            if s.empty:
                continue
            ent = {k: qstats(s[k].values) for k in METRICS}
            ent["seed_iqr_median"] = {k: float(np.nanmedian(s[k + "_seed_iqr"].values)) for k in METRICS
                                      if s["n_runs"].max() > 1}
            ent["n_files"] = int(s.file.nunique())
            ent["n_runs"] = int(s["n_runs"].sum())
            out[sc][m] = ent
    return out


def paired_vs_ref(pf, methods, scen_order, ref, durations):
    out = {}
    for sc in scen_order:
        out[sc] = {}
        a0 = pf[(pf.scenario == sc) & (pf.method == ref)].set_index("file")
        for m in methods:
            if m == ref:
                continue
            b = pf[(pf.scenario == sc) & (pf.method == m)].set_index("file")
            common = [f for f in a0.index if f in b.index]
            if not common:
                continue
            out[sc][m] = {}
            for k in PAIRED_METRICS:
                cen = (max(durations[f] for f in common) + 1.0) if k in CONV else None
                out[sc][m][k] = MX.paired_difference(b.loc[common, k].values.astype(float),
                                                     a0.loc[common, k].values.astype(float), censor_at=cen)
    return out


def degradation(pf, methods, scen_order):
    """Paired change of the primary metric vs the baseline, per method (files as units)."""
    out = {}
    for sc in scen_order:
        if sc == "baseline":
            continue
        out[sc] = {}
        for m in methods:
            a = pf[(pf.scenario == sc) & (pf.method == m)].set_index("file")
            b = pf[(pf.scenario == "baseline") & (pf.method == m)].set_index("file")
            common = [f for f in a.index if f in b.index]
            if common:
                out[sc][m] = MX.paired_difference(a.loc[common, "adm_rmse_pct"].values.astype(float),
                                                  b.loc[common, "adm_rmse_pct"].values.astype(float))
    return out


def bias_summary(results):
    import pandas as pd
    b = pd.DataFrame([{k: unjson(v) for k, v in r.items()} for d in results for r in d["bias"]])
    out = dict(per_method_dI={}, theory={}, cc={})
    for (m, dI), s in b.groupby(["method", "dI"]):
        out["per_method_dI"].setdefault(m, {})[f"{1000 * dI:+.0f}mA"] = dict(
            obs_mean_median_pct=float(100 * s.obs_mean.median()), obs_mean_q25_pct=float(100 * s.obs_mean.quantile(0.25)),
            obs_mean_q75_pct=float(100 * s.obs_mean.quantile(0.75)), obs_end_median_pct=float(100 * s.obs_end.median()),
            obs_adm_end_median_pct=float(100 * s.obs_adm_end.median()),
            n_files=int(s.file.nunique()))
    for m in ("TFO", "FOO"):
        s = b[b.method == m]
        ratio = (s.obs_mean / s.pred_mean).values
        ratio_c = (s.obs_mean / s.pred_cont_mean).values
        slope = float(np.sum(s.obs_mean * s.pred_mean) / np.sum(s.pred_mean ** 2))
        within = ((s.obs_mean - s.pred_k1) * (s.obs_mean - s.pred_k2) <= 0).values
        perT = {}
        for T, sT in s.groupby("T"):
            r0 = sT.iloc[0]
            perT[str(int(T))] = dict(A_impl_Ohm=float(r0.A_impl), A_cont_Ohm=float(r0.A_cont), mu0=float(r0.mu0),
                                     R_tot_impl_Ohm=float(r0.R_tot_impl), R_tot_cont_Ohm=float(r0.R_tot_cont),
                                     kappa1=float(r0.kappa1), kappa2=float(r0.kappa2), t_cross_s=float(r0.t_cross_s),
                                     ratio_obs_pred_median=float(np.median(sT.obs_mean / sT.pred_mean)))
        out["theory"][m] = dict(n=int(len(s)), ratio_obs_pred_median=float(np.median(ratio)),
                                ratio_obs_pred_q25=float(np.quantile(ratio, 0.25)),
                                ratio_obs_pred_q75=float(np.quantile(ratio, 0.75)),
                                ratio_obs_cont_median=float(np.median(ratio_c)), ls_slope_obs_on_pred=slope,
                                corr_time_median=float(np.nanmedian(s["corr"])),
                                rms_obs_minus_pred_median_pct=float(100 * np.median(s.rms_obs_minus_pred)),
                                frac_within_kappa_interval=float(np.mean(within)), per_T=perT)
    s = b[b.method == "CC"]
    out["cc"] = dict(max_abs_end_obs_minus_pred=float(np.max(np.abs(s.drift_end_obs - s.drift_end_pred))),
                     drift_end_pred_pct_by_dI={f"{1000 * dI:+.0f}mA": dict(
                         median=float(100 * sd.drift_end_pred.median()), min=float(100 * sd.drift_end_pred.min()),
                         max=float(100 * sd.drift_end_pred.max())) for dI, sd in s.groupby("dI")})
    return out, b


def load_cached():
    c, _, _, _ = cfg()
    files = list(c["splits"]["test_dynamic"])
    ch = code_hash()
    res = []
    for lid in files:
        with open(CACHE / f"{lid}.json", "r", encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("code_hash") != ch:
            raise RuntimeError(f"cache of {lid} is stale (hash {d.get('code_hash')} != {ch}); run without --report-only")
        res.append(d)
    info = dict(code_hash=ch, wall_this_call_s=0.0, n_files_computed=0, workers=0)
    ri = CACHE / "_run_info.json"
    if ri.exists():
        with open(ri, "r", encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("code_hash") == ch:
            info.update(last_compute_wall_s=d["compute_wall_s"], last_compute_workers=d["workers"], last_compute_utc=d["utc"])
    return res, info


def scenario_order(pf):
    groups = ["baseline", "z0", "bias", "vnoise", "inoise", "param_worst", "cap", "temp"]
    order = []
    for g in groups:
        sc = sorted(pf[pf.group == g].scenario.unique(), key=lambda x: (x.startswith("z0_minus"), _lev(x)))
        order += list(sc)
    return order


def _lev(sc):
    import re
    m = re.search(r"([+-]?\d+(\.\d+)?)", sc.split("_", 1)[-1]) if "_" in sc else None
    return float(m.group(1)) if m else 0.0


def finalize(results, run_info, t_w0, t_c0):
    c, rb, est, dt = cfg()
    methods = list(rb["methods"])
    df = frame(results)
    pf = per_file(df)
    wp = worst_param(pf, methods)
    pf2 = with_pseudo(pf, wp)
    order = scenario_order(pf2)
    durations = {d["file"]: d["duration_s"] for d in results}
    summ = summaries(pf2, methods, order)
    paired = paired_vs_ref(pf2, methods, order, rb["reference_method"], durations)
    degr = degradation(pf2, methods, order)
    bsum, brows = bias_summary(results)
    flags = dict(nonfinite_runs=int(df["nonfinite"].fillna(False).astype(bool).sum()),
                 positivity_violations_TFO_FOO=int((df[df.method.isin(["TFO", "FOO"])]["positivity_ok"] == False).sum()),  # noqa: E712
                 soc_clip_runs=int((df["soc_clip_count"].fillna(0) > 0).sum()),
                 soc_clip_runs_by_method={m: int((df[df.method == m]["soc_clip_count"].fillna(0) > 0).sum()) for m in methods})
    fig = figure_data(results, pf2, summ, brows, methods)
    timing = dict(per_file=[dict(file=d["file"], wall_s=d["wall_s"], process_s=d["process_s"], n_runs=len(d["records"]),
                                 pid=d.get("pid")) for d in results],
                  sum_worker_wall_s=float(sum(d["wall_s"] for d in results)),
                  sum_worker_process_s=float(sum(d["process_s"] for d in results)), **run_info)
    out = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), script="scripts/06b_robustness.py",
               task_version=TASK_VERSION, frozen_config=dict(code_hash=frozen()["code_hash"], frozen_utc=frozen()["frozen_utc"],
                                                            budget_s=frozen()["memory_budget_primary_s"]),
               settings=rb, admissible_soc_interval=dt["admissible_soc_interval"],
               t_post_s=float(est["post_convergence_t_s"]),
               primary="adm_rmse_pct: post-convergence SOC RMSE on the admissible reference-SOC interval (certified claims); whole-profile metrics alongside",
               files=[dict(file=d["file"], T=d["T"], profile=d["profile"], start_level=d["start_level"], n=d["n"],
                           duration_s=d["duration_s"], z_ref0=d["z_ref0"], verify_passed=d["verify_passed"]) for d in results],
               n_runs=int(len(df)), flags=flags, param_worst=wp, scenario_order=order, summary=summ,
               paired_vs_TFO=paired, degradation_vs_baseline=degr, bias_theory=bsum,
               per_file=pf2[["scenario", "method", "file", "T", "adm_rmse_pct", "post_rmse_pct", "adm_conv_time_s",
                             "conv_time_s", "adm_rmse_pct_seed_iqr", "n_runs"]].to_dict(orient="records"),
               bias_rows=brows.to_dict(orient="records"), figure=fig, timing=timing)
    timing["main_wall_s"] = time.perf_counter() - t_w0
    timing["main_process_s"] = time.process_time() - t_c0
    with open(RES / "robustness.json", "w", encoding="utf-8") as fh:
        json.dump(jsonable(out), fh, indent=1)
    out = json.loads(json.dumps(jsonable(out)))
    write_table(out)
    make_figure(out)
    write_report(out)
    print(f"[E2] done: {out['n_runs']} runs; wall {time.perf_counter() - t_w0:.1f} s, "
          f"main process {time.process_time() - t_c0:.1f} s, workers' process {timing['sum_worker_process_s']:.1f} s")


# ---------------------------------------------------------------------------------------------------------------
# Figure data, table, figure
# ---------------------------------------------------------------------------------------------------------------
def figure_data(results, pf, summ, brows, methods):
    fd = dict(fig_file=FIG_FILE)
    tr = next(d["traj"] for d in results if d["file"] == FIG_FILE)
    fd["traj"] = tr
    fd["conv"] = {sc: {m: pf[(pf.scenario == sc) & (pf.method == m)][["file", "adm_conv_time_s", "conv_time_s", "fgt1_s",
                                                                       "fgt2_s"]]
                       .to_dict(orient="records") for m in methods} for sc in ("z0_plus20", "z0_minus20")}
    lev = [("bias_-50mA", -50), ("bias_-20mA", -20), ("baseline", 0), ("bias_+20mA", 20), ("bias_+50mA", 50)]
    fd["bias_curve"] = {m: [dict(dI_mA=v, **{k: summ[sc][m]["adm_rmse_pct"][k] for k in ("median", "q25", "q75")})
                            for sc, v in lev] for m in methods}
    b = brows[brows.method.isin(["TFO", "FOO"])]
    fd["theory"] = b[["method", "file", "T", "dI", "obs_mean", "pred_mean", "pred_cont_mean", "pred_k1",
                      "pred_k2"]].to_dict(orient="records")
    return fd


def _cell(ent, pr, key="adm_rmse_pct", nd=2):
    st = ent[key]
    txt = f"{st['median']:.{nd}f} ({st['q25']:.{nd}f}--{st['q75']:.{nd}f})"
    if pr is not None:
        d = pr[key]
        if isinstance(d["ci_lo"], (int, float)) and d["ci_lo"] > 0:
            txt += r"$^{+}$"
        elif isinstance(d["ci_hi"], (int, float)) and d["ci_hi"] < 0:
            txt += r"$^{-}$"
    return txt


def _conv_cell(ent, pr):
    st = ent["adm_conv_time_s"]
    med = st["median"]
    ms = r"n.c." if not isinstance(med, (int, float)) or not math.isfinite(med) else f"{med:.0f}"
    txt = f"{ms} [{st['n_inf']}/{st['n']}]"
    if pr is not None:
        d = pr["adm_conv_time_s"]
        if isinstance(d["ci_lo"], (int, float)) and d["ci_lo"] > 0:
            txt += r"$^{+}$"
        elif isinstance(d["ci_hi"], (int, float)) and d["ci_hi"] < 0:
            txt += r"$^{-}$"
    return txt


LABELS = {"baseline": "Nominal (baseline)", "z0_plus20": r"$z_0$ error $+0.20$", "z0_minus20": r"$z_0$ error $-0.20$",
          "param_worst": r"Parameters, worst of $2^4$ ($2^3$)", "temp_25C": r"25\,$^\circ$C model on 0/45\,$^\circ$C"}


def label_of(sc):
    if sc in LABELS:
        return LABELS[sc]
    g, v = sc.split("_", 1)
    if g == "bias":
        return rf"$\delta_I={v.replace('mA', '')}$\,mA"
    if g == "vnoise":
        return rf"$\sigma_V={v.replace('mV', '')}$\,mV"
    if g == "inoise":
        return rf"$\sigma_I={v.replace('mA', '')}$\,mA"
    if g == "cap":
        return rf"$\hat Q_n={v}\,Q_{{\mathrm{{id}}}}$"
    return sc


def write_table(out):
    methods = list(out["settings"]["methods"])
    ref = out["settings"]["reference_method"]
    S, P = out["summary"], out["paired_vs_TFO"]
    nmc = int(out["settings"]["mc_runs"])
    lines = [r"% Generated by scripts/06b_robustness.py from results/robustness.json (do not edit by hand).",
             r"\begin{table*}[t]\centering\footnotesize\setlength{\tabcolsep}{3pt}",
             r"\caption{Robustness on the 18 test files (frozen configuration, memory budget 400~s). Entries: median "
             r"(q25--q75) over files of the post-convergence SOC RMSE (\% SOC; $t-t_0\ge600$~s) on the admissible "
             r"reference-SOC interval $[0.10,0.95]$; for the noise cases the per-file value is the median over "
             + str(nmc) + r" Monte-Carlo seeds. $^{+}$/$^{-}$: the 95\% bootstrap CI of the paired median difference "
             r"to TFO (files as units) lies above/below zero (method worse/better than TFO). Lower block: admissible "
             r"convergence time to $\pm2$\% SOC (s; median over files, [not converged/files]). Parameter case: each "
             r"method's worst joint scaling of $R_0$, $R_p$ ($R_1,R_2$), $C_p$ ($\tau_1,\tau_2$) by 0.8/1.2 and $\alpha$ by "
             r"0.9/1.1; temperature case: 12 files.}\label{tab:robustness}",
             r"\begin{tabular}{l" + "l" * len(methods) + r"}\toprule",
             "Case & " + " & ".join(methods) + r" \\ \midrule"]
    for sc in out["scenario_order"]:
        if sc not in S:
            continue
        row = [label_of(sc)]
        for m in methods:
            if m not in S[sc]:
                row.append("--")
                continue
            pr = None if m == ref else P.get(sc, {}).get(m)
            row.append(_cell(S[sc][m], pr))
        lines.append(" & ".join(row) + r" \\")
        if sc in ("baseline", "z0_minus20", "bias_+50mA", "vnoise_10mV", "inoise_50mA", "param_worst", "cap_1.05"):
            lines.append(r"\addlinespace[2pt]")
    lines.append(r"\midrule")
    for sc in ("baseline", "z0_plus20", "z0_minus20"):
        row = [label_of(sc) + r", $t_c$ (s)"]
        for m in methods:
            pr = None if m == ref else P.get(sc, {}).get(m)
            row.append(_conv_cell(S[sc][m], pr))
        lines.append(" & ".join(row) + r" \\")
    lines += [r"\bottomrule\end{tabular}", r"\end{table*}"]
    (ROOT / "tables").mkdir(exist_ok=True)
    (ROOT / "tables" / "tab_robustness.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")



def _f(v):
    v = unjson(v)
    return float(v) if v is not None else float("nan")


def make_figure(out):
    from tfso import plotstyle as ps
    plt = ps.setup()
    methods = list(out["settings"]["methods"])
    fd = out["figure"]
    tr = fd["traj"]
    t_h = np.asarray(tr["t"], float) / 3600.0
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 112), layout="constrained")
    # (a), (b): SOC error on the declared file, z0 = reference +- 0.20
    for k, sc in enumerate(("z0_plus20", "z0_minus20")):
        ax = axs[0, k]
        for m in methods:
            st = ps.line(m, lw=1.0)
            ax.plot(t_h, 100 * np.asarray(tr["e"][sc][m], float), label=m, **st)
        ax.axhspan(-2, 2, color=ps.SHADE, zorder=0, lw=0)
        ax.axhline(0, color=ps.INK2, lw=0.6)
        ax.set_xlabel("Time (h)")
        ax.set_ylabel(r"SOC error $\hat z - z$ (% SOC)")
        ax.set_ylim(-24, 24) if sc == "z0_plus20" else ax.set_ylim(-24, 24)
        ps.note(ax, ("$z_0$ error $+0.20$" if sc == "z0_plus20" else "$z_0$ error $-0.20$") + f"\n{fd['fig_file']}")
        ps.panel_label(ax, k)
    axs[0, 0].legend(ncol=2, loc="lower right", fontsize=6.5, handlelength=2.2)
    # (c): paired forgetting time t_f(1 %) over the 18 files (both z0 errors); never at the top
    ax = axs[0, 2]
    top = 3.0e4
    for i, m in enumerate(methods):
        for j, sc in enumerate(("z0_plus20", "z0_minus20")):
            vals = np.array([_f(r["fgt1_s"]) for r in fd["conv"][sc][m]], float)
            y = np.where(np.isfinite(vals), np.maximum(vals, 1.0), top)
            x = i + (j - 0.5) * 0.36 + np.linspace(-0.09, 0.09, y.size)
            ax.plot(x, y, **ps.points(m, marker="o" if j == 0 else "s", filled=(j == 0), ms=3.0))
            med = np.quantile(np.where(np.isfinite(vals), np.maximum(vals, 1.0), np.inf), 0.5, method="inverted_cdf")
            ax.plot([i + (j - 0.5) * 0.36 - 0.14, i + (j - 0.5) * 0.36 + 0.14], [min(med, top)] * 2, color=ps.INK, lw=1.2)
    ax.set_yscale("log")
    ax.axhline(1.5e4, color=ps.MUTED, lw=0.5, ls=":")
    ax.text(-0.4, top * 1.25, "never", ha="left", va="bottom", fontsize=6.5, color=ps.INK2)
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(methods, rotation=30, ha="right")
    ax.set_ylabel(r"Forgetting time $t_f(1\%)$ (s)")
    ax.set_ylim(0.7, top * 3)
    ax.set_title("filled $+0.20$, open $-0.20$; bar: median", fontsize=6.5, color=ps.INK2, loc="right")
    ps.panel_label(ax, 2)
    # (d): admissible RMSE vs current offset
    ax = axs[1, 0]
    for i, m in enumerate(methods):
        bc = fd["bias_curve"][m]
        x = np.array([r["dI_mA"] for r in bc], float) + (i - 2.5) * 1.3
        med = np.array([_f(r["median"]) for r in bc])
        lo, hi = np.array([_f(r["q25"]) for r in bc]), np.array([_f(r["q75"]) for r in bc])
        ax.errorbar(x, med, yerr=[med - lo, hi - med], capsize=0, elinewidth=0.6, label=m,
                    **ps.line(m, marker=True, lw=1.0, ms=3.2))
    ax.set_xlabel(r"Current offset $\delta_I$ (mA)")
    ax.set_ylabel("Admissible RMSE (% SOC)")
    ax.set_xticks([-50, -20, 0, 20, 50])
    ps.note(ax, "median, IQR over 18 files", x=0.5, ha="center")
    ps.panel_label(ax, 3)
    # (e): SOC shift caused by the offset on the declared file: TFO, FOO vs CC drift
    ax = axs[1, 1]
    for m in ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC"):
        st = ps.line(m, lw=1.0)
        d = 100 * (np.asarray(tr["e"]["bias_+50mA"][m], float) - np.asarray(tr["e"]["baseline"][m], float))
        ax.plot(t_h, d, label=m, **st)
    th = [r for r in fd["theory"] if r["file"] == fd["fig_file"] and abs(r["dI"] - 0.05) < 1e-12 and r["method"] == "TFO"]
    if th:
        ax.axhline(100 * th[0]["pred_mean"], color=ps.INK2, lw=0.7, ls="--")
        ax.text(t_h[-1], 100 * th[0]["pred_mean"], "thm:robust(vi), TFO\n(window mean)", ha="right", va="top",
                fontsize=6.5, color=ps.INK2)
    ax.axhline(0, color=ps.INK2, lw=0.6)
    ax.set_xlabel("Time (h)")
    ax.set_ylabel(r"$\Delta e$ at $\delta_I=+50$ mA (% SOC)")
    ps.note(ax, fd["fig_file"], x=0.02, ha="left")
    ps.panel_label(ax, 4)
    # (f): observed vs predicted mean SOC shift (all files, all offsets)
    ax = axs[1, 2]
    lim = 0.0
    for m, mk in (("FOO", "s"), ("TFO", "o")):
        rows = [r for r in fd["theory"] if r["method"] == m]
        x = 100 * np.array([r["pred_mean"] for r in rows])
        y = 100 * np.array([r["obs_mean"] for r in rows])
        lim = max(lim, np.max(np.abs(np.concatenate([x, y]))))
        ax.plot(x, y, label=m, **ps.points(m, marker=mk, filled=(m == "TFO"), ms=2.4 if m == "TFO" else 4.2))
    lim *= 1.08
    ax.plot([-lim, lim], [-lim, lim], color=ps.INK2, lw=0.7, ls="--")
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_xlabel("Predicted shift, eq. (steady) (% SOC)")
    ax.set_ylabel("Observed mean shift (% SOC)")
    ax.legend(loc="lower right", fontsize=6.5)
    ps.note(ax, "18 files x 4 offsets\nadmissible window", x=0.02, ha="left")
    ps.panel_label(ax, 5)
    (ROOT / "figures").mkdir(exist_ok=True)
    ps.save(fig, ROOT / "figures" / "fig_robustness.pdf")
    ps.preview_png(ROOT / "figures" / "fig_robustness.pdf")
    plt.close(fig)



# ---------------------------------------------------------------------------------------------------------------
# Findings report (every number from results/robustness.json, frozen_config.json, capacity.json)
# ---------------------------------------------------------------------------------------------------------------
def _n(v, nd=2):
    v = unjson(v)
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "n/a"
    if isinstance(v, float) and math.isinf(v):
        return "never"  # noqa
    return f"{v:.{nd}f}"


def _pd(d, nd=2, unit=""):
    return f"{_n(d['median_diff'], nd)}{unit} [{_n(d['ci_lo'], nd)}, {_n(d['ci_hi'], nd)}]"


def _span(vals):
    return f"{min(vals):.3g}-{max(vals):.3g} (max/min {max(vals) / min(vals):.2f})"


def write_report(out):
    rb, S, P, B = out["settings"], out["summary"], out["paired_vs_TFO"], out["bias_theory"]
    M = list(rb["methods"])
    fz = frozen()
    cap = load_json("capacity.json")
    tm = out["timing"]
    L = []
    w = L.append
    w("# E2 robustness findings (test files, frozen configuration)\n")
    w(f"Generated by `scripts/06b_robustness.py` ({out['generated_utc']}); all numbers from `results/robustness.json`. "
      f"Frozen configuration `results/frozen_config.json` (code hash {out['frozen_config']['code_hash']}, primary memory "
      f"budget {out['frozen_config']['budget_s']} s); nothing was re-tuned. Settings: config `robustness` (declared before the "
      "first run; the paired forgetting-time diagnostic was added after the first analysis and is reported only).\n")
    key_findings(out, w)
    w("## Protocol\n")
    nf = len(out["files"])
    w(f"- {nf} test files (FUDS/US06/BJDST x 50/80 % SOC x 0/25/45 C), all pass `data.verify_file`; {out['n_runs']} runs; "
      f"methods {', '.join(M)}; paired differences d = method - TFO with files as units (95 % percentile bootstrap CI of the "
      "median difference, 10 000 resamples, seed 20260927; d > 0 means worse than TFO).")
    w(f"- Monte-Carlo cases: {rb['mc_runs']} seeds {rb['mc_seeds'][0]}-{rb['mc_seeds'][-1]} (= validation.seeds; the same seed "
      "for every file, level and method: common random numbers). Per file the seed median is used; across files median (q25-q75).")
    w("- PRIMARY metric (certified claims): post-convergence SOC RMSE (t - t0 >= 600 s) on the admissible reference-SOC interval "
      "[0.10, 0.95]. Whole-profile post-convergence RMSE and convergence times (+-2 %) are reported alongside; the whole profile "
      "includes the end-of-discharge knee (z < 0.10), where every model-based method is outside the certified interval.")
    w(f"- Cost: sum over the 18 worker tasks {tm['sum_worker_wall_s']:.0f} s wall / {tm['sum_worker_process_s']:.0f} s process; "
      f"2 worker processes" + (f"; the computing run took {tm['last_compute_wall_s']:.0f} s wall" if "last_compute_wall_s" in tm else "")
      + f"; the analysis/report call {tm.get('main_wall_s', 0):.0f} s wall (main process {tm.get('main_process_s', 0):.0f} s).")
    fl = out["flags"]
    w(f"- Flags: {fl['nonfinite_runs']} non-finite runs; {fl['positivity_violations_TFO_FOO']} TFO/FOO runs violate h l1 kappa2 <= 1 on "
      f"the clip range; SOC clipping [-0.05, 1.05] active in {fl['soc_clip_runs']} runs (numerical safeguard only; counted per run)."
      "\n")
    w("## Magnitudes and their support\n")
    w("- References.bib / literature_comparison.json hold NO verified sensor-accuracy specification (vendor sheets excluded; "
      "waag2014critical, lin2018theoretical, zhao2017observability support only the qualitative bias effect). The one "
      "quantitative anchor is shi2023robust: 0.2 A bias and 5 mA / 5 mV noise as test levels (abstract-level information).")
    w("- Voltage noise 5 mV: same level as shi2023robust. 1 and 10 mV: **sensitivity analysis**.")
    w("- Current offset +-20/+-50 mA (1-2.5 % of the 2 A nominal 1C current, below the 0.2 A of shi2023robust) and current "
      "noise 10/50 mA (above its 5 mA): **sensitivity analysis** (no cited sensor specification).")
    tf = [fz["methods"]["TFO"]["per_T"][str(T)]["params"] for T in (0, 25, 45)]
    qid = [cap["Q_id_T_SP2"][str(T)]["Q_id_Ah"] for T in (0, 25, 45)]
    qr = [cap["Q_ref_T_SP2"][str(T)]["Q_ref_Ah"] for T in (0, 25, 45)]
    w("- Parameters x0.8/1.2, alpha x0.9/1.1, capacity x0.95/1.05, 25 C model on 0/45 C: **sensitivity analyses**. Context from "
      f"the identified values (frozen TFO over 0/25/45 C): R0 {_span([p['R0'] for p in tf])} Ohm, Rp {_span([p['Rp'] for p in tf])} "
      f"Ohm, Cp {_span([p['Cp'] for p in tf])}, alpha {_span([p['alpha'] for p in tf])}; Q_id {_span(qid)} Ah. The baseline itself "
      "carries a capacity mismatch Q_id/Q_ref - 1 = " + ", ".join(f"{100 * (a / b - 1):+.1f} %" for a, b in zip(qid, qr))
      + " (0/25/45 C), because the estimators use Q_id and the ground truth Q_ref.\n")
    w("## Table 6 (primary metric, % SOC, median over files; +/-: 95 % CI of the paired difference to TFO above/below 0; IQRs and CIs in tables/tab_robustness.tex and results/robustness.json)" + chr(10))
    w("| Case | " + " | ".join(M) + " |")
    w("|---|" + "---|" * len(M))
    for sc in out["scenario_order"]:
        row = [sc]
        for m in M:
            if m not in S[sc]:
                row.append("--")
                continue
            v = _n(S[sc][m]["adm_rmse_pct"]["median"])
            if m != "TFO" and m in P.get(sc, {}):
                d = P[sc][m]["adm_rmse_pct"]
                v += "+" if isinstance(d["ci_lo"], float) and d["ci_lo"] > 0 else (
                    "-" if isinstance(d["ci_hi"], float) and d["ci_hi"] < 0 else "")
            row.append(v)
        w("| " + " | ".join(row) + " |")
    w("\nWhole-profile post-convergence RMSE (median over files): " + "; ".join(
        f"{sc}: " + ", ".join(f"{m} {_n(S[sc][m]['post_rmse_pct']['median'])}" for m in M if m in S[sc])
        for sc in ("baseline", "bias_+50mA", "bias_-50mA", "temp_25C")) + ".\n")
    report_sections(out, w)
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "robustness_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")




def key_findings(out, w):
    rb, S, P, B, D_ = out["settings"], out["summary"], out["paired_vs_TFO"], out["bias_theory"], out["degradation_vs_baseline"]
    M = list(rb["methods"])
    med = lambda sc, m, k="adm_rmse_pct": S[sc][m][k]["median"]                    # noqa: E731
    ds = [abs(P[sc]["FOO"]["adm_rmse_pct"]["median_diff"]) for sc in out["scenario_order"] if "FOO" in P.get(sc, {})]
    pm = B["per_method_dI"]
    th = B["theory"]["TFO"]
    nz = [x for x in out["scenario_order"] if x.startswith(("vnoise", "inoise"))]
    mx = {m: max(abs(D_[sc][m]["median_diff"]) for sc in nz) for m in M}
    conv = out["figure"]["conv"]
    nslow = lambda sc, m: sum(1 for r in conv[sc][m] if not (unjson(r["fgt1_s"]) <= 1000.0))   # noqa: E731
    tmax = lambda sc: max(float(unjson(r["fgt1_s"])) for r in conv[sc]["TFO"])                # noqa: E731
    w("## Key findings\n")
    w(f"1. Tempering does not change robustness at the 400 s budget: over all cases |median(FOO - TFO)| <= {max(ds):.3f} % SOC "
      "(primary metric); TFO and FOO have almost the same DC conductance mu_(h,L)(0) and respond identically to every disturbance.")
    w(f"2. Initial SOC error +-0.20: TFO forgets it on every file (t_f(1 %) median {_n(med('z0_plus20', 'TFO', 'fgt1_s'), 0)} / "
      f"{_n(med('z0_minus20', 'TFO', 'fgt1_s'), 0)} s) and its primary RMSE does not change (paired median "
      f"{_n(D_['z0_plus20']['TFO']['median_diff'])} / {_n(D_['z0_minus20']['TFO']['median_diff'])} % SOC); the Kalman filters forget "
      f"it within seconds on most files (median FOEKF {_n(med('z0_plus20', 'FOEKF', 'fgt1_s'), 0)} s, EKF2RC "
      f"{_n(med('z0_plus20', 'EKF2RC', 'fgt1_s'), 0)} s), but EKF2RC/AEKF2RC are bimodal: t_f(1 %) > 1000 s or never on "
      + " / ".join(f"{nslow(sc, 'EKF2RC')}/{nslow(sc, 'AEKF2RC')}" for sc in ("z0_plus20", "z0_minus20"))
      + f" files (+0.20 / -0.20), against a TFO maximum of {max(tmax(sc) for sc in ('z0_plus20', 'z0_minus20')):.0f} s; "
      f"CC never does (primary RMSE {_n(med('z0_plus20', 'CC'))} / {_n(med('z0_minus20', 'CC'))}). The declared +-2 % convergence "
      f"time of TFO ({_n(med('z0_plus20', 'TFO', 'adm_conv_time_s'), 0)} s) equals its nominal-z0 value: it measures the model error, not the transient.")
    w(f"3. Current offset: the TFO SOC shift is bounded and follows thm:robust(vi)/eq:m4b:steady with the implemented DC "
      f"conductance (observed/predicted {_n(th['ratio_obs_pred_median'])}, IQR {_n(th['ratio_obs_pred_q25'])}-{_n(th['ratio_obs_pred_q75'])}); "
      f"at +-50 mA it is {_n(pm['TFO']['+50mA']['obs_mean_median_pct'])} / {_n(pm['TFO']['-50mA']['obs_mean_median_pct'])} % SOC "
      f"against a CC drift of {_n(B['cc']['drift_end_pred_pct_by_dI']['+50mA']['median'])} % at the profile end. EKF2RC and FOEKF "
      f"accumulate part of the offset (shift at +50 mA, window mean / last admissible sample: FOEKF "
      f"{_n(pm['FOEKF']['+50mA']['obs_mean_median_pct'])} / {_n(pm['FOEKF']['+50mA']['obs_adm_end_median_pct'])}, EKF2RC "
      f"{_n(pm['EKF2RC']['+50mA']['obs_mean_median_pct'])} / {_n(pm['EKF2RC']['+50mA']['obs_adm_end_median_pct'])}, AEKF2RC "
      f"{_n(pm['AEKF2RC']['+50mA']['obs_mean_median_pct'])} / {_n(pm['AEKF2RC']['+50mA']['obs_adm_end_median_pct'])}, TFO "
      f"{_n(pm['TFO']['+50mA']['obs_mean_median_pct'])} / {_n(pm['TFO']['+50mA']['obs_adm_end_median_pct'])} %; the TFO "
      f"shift shrinks where the OCV slope grows, as 1/kappa predicts). Because the TFO baseline error is negative "
      f"(mean {_n(med('baseline', 'TFO', 'adm_bias_pct'))} % SOC) and its shift has the opposite sign to delta_I, TFO is best at "
      f"-50 mA ({_n(med('bias_-50mA', 'TFO'))}) and worse than the Kalman filters at +50 mA ({_n(med('bias_+50mA', 'TFO'))}).")
    w("4. White sensor noise is negligible for TFO/FOO/FOEKF (largest paired change " + ", ".join(
        f"{m} {mx[m]:.3f}" for m in ("TFO", "FOEKF", "EKF2RC", "AEKF2RC")) + " % SOC).")
    w(f"5. Model mismatch is the weak point of TFO/FOO: worst joint parameter scaling {_n(med('param_worst', 'TFO'))} % SOC "
      f"(EKF2RC {_n(med('param_worst', 'EKF2RC'))}, FOEKF {_n(med('param_worst', 'FOEKF'))}); 25 C model on 0/45 C "
      f"{_n(med('temp_25C', 'TFO'))} (FOEKF {_n(med('temp_25C', 'FOEKF'))}, CC {_n(med('temp_25C', 'CC'))}). Capacity +-5 % "
      f"hardly affects TFO (paired change {_n(D_['cap_0.95']['TFO']['median_diff'])} / {_n(D_['cap_1.05']['TFO']['median_diff'])}) "
      f"but affects CC ({_n(D_['cap_0.95']['CC']['median_diff'])} / {_n(D_['cap_1.05']['CC']['median_diff'])}).\n")


def report_sections(out, w):
    rb, S, P, B, D_ = out["settings"], out["summary"], out["paired_vs_TFO"], out["bias_theory"], out["degradation_vs_baseline"]
    M = list(rb["methods"])
    q = lambda sc, m, k: S[sc][m][k]                                              # noqa: E731
    w("## (a) Initial SOC error +-0.20\n")
    for k, lab in (("fgt1_s", "Forgetting time t_f(1 %) (paired to the nominal run; median s [never/18], +0.20 / -0.20)"),
                   ("adm_conv_time_s", "Admissible convergence time to +-2 % (median s [not converged/18], +0.20 / -0.20 / nominal)")):
        w(f"- {lab}: " + ", ".join(
            f"{m} " + " / ".join(f"{_n(q(sc, m, k)['median'], 0)} [{q(sc, m, k)['n_inf']}]"
                                 for sc in (("z0_plus20", "z0_minus20") if k == "fgt1_s" else ("z0_plus20", "z0_minus20", "baseline")))
            for m in M) + ".")
    w("")
    w("## (b) Current-sensor offset\n")
    pm = B["per_method_dI"]
    w("- SOC shift e_biased - e_nominal, mean over the admissible post-convergence window / at its last sample (median over "
      "files, % SOC; the profile end is not used because the SOC clip at the knee masks it): " + "; ".join(f"{m}: " + ", ".join(
          f"{k} {_n(v['obs_mean_median_pct'])} / {_n(v['obs_adm_end_median_pct'])}" for k, v in pm[m].items()) for m in M) + ".")
    for m in ("TFO",):
        t = B["theory"][m]
        w(f"- {m} vs thm:robust(vi) with the implemented DC conductance M = mu_(h,L)(0) (eq:m4b:steady; local slope kappa(t) of "
          f"the observer's OCV): observed/predicted mean shift {_n(t['ratio_obs_pred_median'])} (IQR {_n(t['ratio_obs_pred_q25'])}-"
          f"{_n(t['ratio_obs_pred_q75'])}, n = {t['n']}), least-squares slope {_n(t['ls_slope_obs_on_pred'])}, median time "
          f"correlation {_n(t['corr_time_median'])}, median RMS(obs - pred) {_n(t['rms_obs_minus_pred_median_pct'])} % SOC; "
          f"{100 * t['frac_within_kappa_interval']:.0f} % of the file means lie inside [delta_I A/kappa2, delta_I A/kappa1]. "
          f"With the continuous-time value M = lambda^alpha the ratio is {_n(t['ratio_obs_cont_median'])}.")
        w("  Per T: " + "; ".join(
            f"{T} C: A = {_n(v['A_impl_Ohm'], 3)} Ohm (continuous {_n(v['A_cont_Ohm'], 3)}), R_tot = {_n(v['R_tot_impl_Ohm'], 3)} "
            f"(continuous {_n(v['R_tot_cont_Ohm'], 3)}) Ohm, mu0 = {_n(v['mu0'], 3)}, t_x = {_n(v['t_cross_s'], 0)} s"
            for T, v in t["per_T"].items()) + ".")
    t = B["theory"]["FOO"]
    w(f"- FOO: observed/predicted {_n(t['ratio_obs_pred_median'])} with M = mu_(h,L)(0) (mu0 = " + ", ".join(
        f"{_n(v['mu0'], 3)}" for v in t["per_T"].values()) + f" at 0/25/45 C), but {_n(t['ratio_obs_cont_median'])} with the "
      "continuous untempered value M = 0 (R_tot = R0 + Rp = " + ", ".join(f"{_n(v['R_tot_cont_Ohm'], 3)}" for v in t["per_T"].values())
      + " Ohm): the 400 s memory, not lambda, sets the DC conductance of both observers.")
    cc = B["cc"]
    w(f"- Coulomb counting: the observed drift equals eta delta_I t/(3600 Q_n) to {cc['max_abs_end_obs_minus_pred']:.1e}; at the "
      "profile end it is " + ", ".join(f"{k}: {_n(v['median'])} % (range {_n(v['min'])} to {_n(v['max'])})"
                                       for k, v in cc["drift_end_pred_pct_by_dI"].items()) + ". t_x is the time after which the "
      "observer's bounded shift is smaller than the CC drift (thm:robust(vi), kappa = kappa1).")
    w("")
    w("## (c), (d) Sensor noise\n")
    nz = [x for x in out["scenario_order"] if x.startswith(("vnoise", "inoise"))]
    for sc in ("vnoise_10mV",):
        w(f"- {sc}: change of the primary RMSE vs noise-free (paired median [CI], % SOC) " + ", ".join(
            f"{m} {_pd(D_[sc][m])}" for m in M) + "; median seed IQR " + ", ".join(
            f"{m} {_n(S[sc][m]['seed_iqr_median'].get('adm_rmse_pct'), 3)}" for m in M) + ".")
    w("- inoise_50mA: median seed IQR " + ", ".join(
        f"{m} {_n(S['inoise_50mA'][m]['seed_iqr_median'].get('adm_rmse_pct'), 3)}" for m in M) + ".")
    w("- Largest |paired median change| over all " + str(len(nz)) + " noise cases: " + ", ".join(
        f"{m} {max(abs(D_[sc][m]['median_diff']) for sc in nz):.3f}" for m in M) + " % SOC.\n")
    w("## (e) Parameter perturbation\n")
    w("- Worst combination (mean primary RMSE over files; median over combinations): " + "; ".join(
        f"{m} {v['worst'].replace('param_', '')} ({_n(v['worst_mean'])}; {_n(v['median_over_combos'])})"
        for m, v in out["param_worst"].items()) + ".")
    w("- CC has no model parameters (unaffected)." + chr(10))
    w("## (f), (g) Capacity and temperature mismatch\n")
    for sc in [x for x in out["scenario_order"] if x.startswith(("cap_", "temp_"))]:
        w(f"- {sc}: change of the primary RMSE vs baseline (paired median [CI], % SOC) " + ", ".join(
            f"{m} {_pd(D_[sc][m])}" for m in M if m in D_[sc]) + ".")
    w("")
    w("## Caveats" + chr(10))
    w("- The bias prediction is quasi-steady (constant current and slope in the theorem, local slope used here); the whole-profile "
      "metrics include the knee z < 0.10 where the certificate does not apply. The forgetting time was added after the first "
      "analysis (config `robustness.diagnostic_forgetting_time`); no choice depends on it. All magnitudes except 5 mV are "
      "sensitivity levels, not cited sensor specifications.")


# === MAIN ===
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report-only", action="store_true", help="use the cached per-file runs only")
    ap.add_argument("--compute-only", action="store_true")
    ap.add_argument("--workers", type=int, default=None)
    a = ap.parse_args()
    _, rb, _, _ = cfg()
    workers = min(int(a.workers or rb["max_workers"]), 2)
    t_w0, t_c0 = time.perf_counter(), time.process_time()
    results, run_info = compute(0 if a.report_only else workers) if not a.report_only else load_cached()
    if a.compute_only:
        print(f"[E2] compute wall {time.perf_counter() - t_w0:.1f} s, main process {time.process_time() - t_c0:.1f} s")
        return
    finalize(results, run_info, t_w0, t_c0)


if __name__ == "__main__":
    main()
