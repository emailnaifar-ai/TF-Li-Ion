"""Computational cost of every SOC estimator (task E4): CPU/wall time per sample, storage, operation counts.

Writes results/machine.json, results/cost.json (all numbers and every plotted array), tables/tab_cost.tex and
figures/fig_cost_memory.pdf (+ .png preview).  Settings: config ``cost_study`` (declared before the first run).

Protocol
--------
* Inputs: the VALIDATION file ``cost_study.timing_file`` (SP2_25C_DST_50SOC, ``data.verify_file`` via
  ``experiments.load_case``), nominal initial SOC, no corruption, h = 1 s.  Frozen parameters and hyper-parameters
  of results/frozen_config.json; for the memory grid only the memory L of TFO / FOO / FOEKF changes (frozen
  gains / covariances).  The frozen configuration of every method is also timed on the 0 C and 45 C validation
  files (check that the per-sample time does not depend on T).  No test file is loaded.
* Clocks: ``time.process_time`` (CPU time of this process) and ``time.perf_counter`` (wall), both read by
  ``observer.run_estimator`` around the estimation loop only (weight generation, OCV table, allocation and the
  a-posteriori output reconstruction are outside).  One repeat = B back-to-back runs (B from the warm-up run so
  that a repeat lasts about ``target_repeat_s``); the B in-loop readings are summed, which reduces the Windows
  process-time quantisation (tick ~15.6 ms) to a few per cent per repeat.  ``repeats`` repeats, each in a newly
  shuffled configuration order (seeded), so slow drifts of the machine load hit every configuration alike.
  Reported: median, IQR and minimum over repeats of the per-sample time.  Single process, sequential.
* Operation counts (``op_counts``) are those of an IDEALISED embedded implementation of the implemented
  recursions (observer._run_tfo, benchmarks._run_foekf / _run_ekf2rc / _run_cc): every constant precomputed,
  value-only OCV evaluation (Horner form, dz*dU stored) where the method does not need dU/dz, no diagnostic
  outputs.  The desktop code differs (FastOCV.both always returns dU/dz; _run_tfo also forms a diagnostic
  one-step-ahead output); its effect on the timing is measured with the variant TFO_lean (value-only OCV, no
  diagnostic output; identical zhat, checked bitwise).  Operation counts are also given per storage layout:
  the 'minimal' layout (weights regenerated in every sample) costs N_L extra divisions, multiplications and
  additions per sample (``layout_extra_ops``).  Storage (``storage_values``) for three buffer layouts, with the
  fixed scalars derived per method from the recursions (``SCALARS``); the implementation's bytes_state uses a
  uniform 8-scalar allowance (convention, checked separately); float32 bytes are analytic (4 bytes per value;
  float32 accuracy of the recursions is NOT tested here).
* Full memory: TFO/FOO use a growing sum (m_n = n MACs at step n, mean (N+1)/2); the implemented FOEKF uses a
  fixed zero-padded window of N samples (2(N-1) MACs every step).  The variant FOEKF_grow (growing sum, same
  zhat up to rounding) is timed for a like-for-like full-memory comparison.
* Weight generation (once, at design time): ``tempered.gl_weights`` (vectorised numpy) timed per N_L.
* Statistics: percentile-bootstrap CIs (repeats resampled per configuration) of the linear fit of the median
  time against N_L; TFO - FOO differences paired by repeat round (approximate pairing: same shuffled round,
  not simultaneous) with bootstrap CI and Wilcoxon signed-rank p; Kruskal-Wallis across temperatures.
Timings are desktop CPython + numpy on the machine of results/machine.json, NOT an embedded target; other
analyses may run concurrently on this machine (load recorded per repeat, not controlled; affinity not pinned).

Outputs: results/cost.json (measurement + analysis; written ONCE by the measurement run), results/machine.json,
results/cost_outputs.json (figure arrays, outputs code hash), tables/tab_cost.tex, figures/fig_cost_memory.pdf,
reports/cost_findings.md; the measured script version is archived as results/archive/08_cost_<hash>.py.

Run from the project root:  python scripts/08_cost.py            (measure + outputs)
                            python scripts/08_cost.py --outputs  (table/figure/report from results/cost.json only)
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES, TAB, FIG = ROOT / "results", ROOT / "tables", ROOT / "figures"
OUT_RES, REP = RES, ROOT / "reports"            # output locations (redirected by --quick)
MEM_METHODS = ("TFO", "FOO", "FOEKF")
ALL_METHODS = ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC")
BASE = {"TFO_lean": "TFO", "FOEKF_grow": "FOEKF"}           # timing variants -> frozen method they reproduce


# ---------------------------------------------------------------------------------------------------------------
# Operation counts (per sample n >= 1), derived line by line from the implemented recursions
# ---------------------------------------------------------------------------------------------------------------
# Each step: (description, mul, add, div, cmp).  Constants precomputed once (h beta, h l1, h^a b_p, h^a l2,
# 1/(1 + h^a (a_p + l2)), F11, F11^2, B0, B1, e_i, g_i, e_i e_j, 1 - b ...).  The memory sum is counted separately
# as multiply-adds (MACs, one multiplication and one addition each).  OCV evaluations are counted separately.
_STEPS = {
    "TFO": [("z <- z + (h beta) u + (h l1) ytilde", 2, 2, 0, 0),
            ("SOC clip (safeguard)", 0, 0, 0, 2),
            ("f = (h^a b_p) u - memory sum", 1, 1, 0, 0),
            ("e = V - U(z) - R0 I_out", 1, 2, 0, 0),
            ("Vp = (f + (h^a l2) e) / den  (1/den precomputed)", 2, 1, 0, 0),
            ("ytilde = e - Vp", 0, 1, 0, 0)],
    "FOEKF": [("z- = z + B0 I", 1, 1, 0, 0),
              ("v- = F11 v + B1 I - memv", 2, 2, 0, 0),
              ("p00 += q0; p01 *= F11; p11 = F11^2 p11 + q1 + memp", 2, 3, 0, 0),
              ("SOC clip (prior)", 0, 0, 0, 2),
              ("y- = U + R0 I_out + v; innov = V - y-", 1, 3, 0, 0),
              ("c0 = p00 d + p01; c1 = p01 d + p11; S = d c0 + c1 + R", 3, 4, 0, 0),
              ("K = c / S (one reciprocal)", 2, 0, 1, 0),
              ("x += K innov", 2, 2, 0, 0),
              ("P -= K c^T (3 entries)", 3, 3, 0, 0),
              ("SOC clip (posterior)", 0, 0, 0, 2)],
    "EKF2RC": [("z- = z + B0 I; V_i- = e_i V_i + g_i I", 5, 3, 0, 0),
               ("P- = A P A^T + Q (6 entries, A diagonal)", 5, 3, 0, 0),
               ("SOC clip (prior)", 0, 0, 0, 2),
               ("y- = U + R0 I_out + V1 + V2; innov", 1, 4, 0, 0),
               ("c = P- H^T (3 entries)", 3, 6, 0, 0),
               ("S = H c + R", 1, 3, 0, 0),
               ("K = c / S (one reciprocal)", 3, 0, 1, 0),
               ("x += K innov", 3, 3, 0, 0),
               ("P -= K c^T (6 entries)", 6, 6, 0, 0),
               ("SOC clip (posterior)", 0, 0, 0, 2)],
    "AEKF2RC_extra": [("b^k and d_k = (1 - b)/(1 - b^(k+1))", 2, 1, 1, 0),
                      ("innov^2", 1, 0, 0, 0),
                      ("R_k = (1 - d_k) R + d_k (innov^2 - HPH), floor", 2, 3, 0, 1),
                      ("f = d_k (innov^2 - S)", 1, 1, 0, 0),
                      ("Q_ii += f K_i^2 (3), floors", 6, 3, 0, 3)],
    "CC": [("z <- z + (h beta) I", 1, 1, 0, 0)],
}
# One OCV evaluation on the uniform cubic-Hermite table of FastOCV (nodes U_i and dz*dU_i stored):
# index u = (z - z_lo)/dz (1 mul 1 add), t = u - i (1 add), dy = y1 - y0 (1 add), c = 3 dy - 2 m0 - m1 (2 mul 2 add),
# d = m0 + m1 - 2 dy (1 mul 2 add), U = y0 + t (m0 + t (c + t d)) (3 mul 3 add), range checks (2 cmp);
# derivative dU = (m0 + t (2 c + 3 t d)) / dz: 5 mul 2 add more.
OCV_VALUE = dict(mul=7, add=10, div=0, cmp=2)
OCV_DERIV_EXTRA = dict(mul=5, add=2, div=0, cmp=0)


def op_counts(method: str, N_L: int | None) -> dict:
    """Per-sample operations of one estimator step (n >= 1) with memory N_L (TFO/FOO/FOEKF)."""
    key = "TFO" if method in ("TFO", "FOO") else ("EKF2RC" if method in ("EKF2RC", "AEKF2RC") else method)
    steps = list(_STEPS[key]) + (list(_STEPS["AEKF2RC_extra"]) if method == "AEKF2RC" else [])
    fixed = {k: int(sum(s[i] for s in steps)) for i, k in ((1, "mul"), (2, "add"), (3, "div"), (4, "cmp"))}
    if method in ("TFO", "FOO"):
        mem_macs = int(N_L)                                  # sum_{j=1}^{N_L} omega_j Vp_{n-j}
    elif method == "FOEKF":
        mem_macs = 2 * (int(N_L) - 1)                        # memv and memp, j = 2..N_L
    else:
        mem_macs = 0
    ocv_evals = 0 if method == "CC" else 1
    needs_deriv = method in ("FOEKF", "EKF2RC", "AEKF2RC")
    ocv_mul = ocv_add = 0
    if ocv_evals:
        ocv_mul = OCV_VALUE["mul"] + (OCV_DERIV_EXTRA["mul"] if needs_deriv else 0)
        ocv_add = OCV_VALUE["add"] + (OCV_DERIV_EXTRA["add"] if needs_deriv else 0)
    flops_fixed = fixed["mul"] + fixed["add"] + fixed["div"]
    return dict(method=method, N_L=N_L, memory_macs=mem_macs, fixed=fixed, fixed_flops=flops_fixed,
                ocv_evals=ocv_evals, ocv_derivative=needs_deriv, ocv_flops=ocv_mul + ocv_add,
                total_flops=2 * mem_macs + flops_fixed + ocv_mul + ocv_add,
                mul_total=mem_macs + fixed["mul"] + ocv_mul,
                steps=[dict(step=s[0], mul=s[1], add=s[2], div=s[3], cmp=s[4]) for s in steps])


def weight_gen_ops(method: str, N_L: int) -> dict:
    """Operations of the weight recursion omega_j = (r - c/j) omega_{j-1}, r = e^{-lam h}, c = (alpha+1) r
    (constants combined once): per weight 1 division, 1 subtraction, 1 multiplication (+1 exp for TFO).
    FOEKF: the scale s is folded into omega_1; the squared weights need 1 more multiplication each."""
    ops = dict(div=N_L, add=N_L, mul=N_L, exp=1 if method == "TFO" else 0)
    if method == "FOEKF":
        ops["mul"] += N_L
    return ops


def layout_extra_ops(method: str, N_L: int | None, layout: str) -> dict:
    """Per-sample operations ADDED by a storage layout on top of op_counts (stored weights).  'minimal' regenerates
    the weights inside every sample (weight_gen_ops per sample; the alternative, a stored table of 1/j, removes
    the divisions but costs N_L stored values, i.e. the storage saving).  The other layouts add nothing."""
    if layout != "minimal" or method not in MEM_METHODS:
        return dict(div=0, mul=0, add=0, flops=0)
    n = int(N_L) - (1 if method == "FOEKF" else 0)          # FOEKF: j = 2..N_L
    o = weight_gen_ops(method, n)
    return dict(div=o["div"], mul=o["mul"], add=o["add"], flops=o["div"] + o["mul"] + o["add"])


# Fixed scalars of each recursion (state, ring index, previous current for the causal input u_n = I_{n-1},
# precomputed constants; covariances / adaptive statistics are counted in 'cov'; OCV table not included).
SCALARS = {
    "TFO": ["z", "ytilde", "ring index", "I_prev", "h beta", "h l1", "h^a b_p", "h^a l2", "1/den", "R0",
            "z_min", "z_max"],
    "FOEKF": ["z", "Vp", "ring index", "I_prev", "B0", "F11", "B1", "F11^2", "q_z", "q_Vp", "R", "R0",
              "z_min", "z_max"],
    "EKF2RC": ["z", "V1", "V2", "I_prev", "B0", "e1", "e2", "g1", "g2", "R0", "e1^2", "e1 e2", "e2^2",
               "q0", "q1", "q2", "R", "z_min", "z_max"],
    "AEKF2RC": ["z", "V1", "V2", "I_prev", "B0", "e1", "e2", "g1", "g2", "R0", "e1^2", "e1 e2", "e2^2",
                "b", "1-b", "b^(k+1)", "R_min", "Qmin_0", "Qmin_1", "Qmin_2", "z_min", "z_max"],
    "CC": ["z", "I_prev", "h beta"],
}
SCALARS["FOO"] = SCALARS["TFO"]
COV = {"TFO": 0, "FOO": 0, "FOEKF": 3, "EKF2RC": 6, "AEKF2RC": 10, "CC": 0}   # AEKF: 6 P + adaptive R, Q (4)


def storage_values(method: str, N_L: int | None, layout: str = "implemented", scalars: str = "derived") -> dict:
    """Stored floating-point values: history, weights, covariance/adaptive statistics and fixed scalars.
    scalars='derived' (reported): len(SCALARS[method]); 'allowance': the uniform 8-scalar convention of the
    implementation's bytes_state (used only to check the rule against the implementation)."""
    S = len(SCALARS[method]) if scalars == "derived" else O.N_SCALAR_ALLOWANCE
    cov = COV[method]
    if method not in MEM_METHODS:
        return dict(history=0, weights=0, cov=cov, scalars=S, total=cov + S, history_samples=0)
    hist_seq, wtab = (1, 1) if method in ("TFO", "FOO") else (2, 2)   # FOEKF: Vp and P22; s omega, (s omega)^2
    N_L = int(N_L)
    buf = {"implemented": 2 * N_L, "single_ring": N_L, "minimal": N_L}[layout] * hist_seq
    w = 0 if layout == "minimal" else N_L * wtab
    return dict(history=buf, weights=w, cov=cov, scalars=S, total=buf + w + cov + S, history_samples=N_L * hist_seq)


def storage_full(method: str, N: int, scalars: str = "derived") -> dict:
    """Implemented full-memory storage of TFO/FOO (history N+1 values and N weights; grows with the run length)."""
    S = len(SCALARS[method]) if scalars == "derived" else O.N_SCALAR_ALLOWANCE
    return dict(history=N + 1, weights=N, cov=0, scalars=S, total=2 * N + 1 + S, history_samples=N)


def storage_formula(method: str, layout: str) -> str:
    """'a N_L + b' read off storage_values (no hand-typed storage rule)."""
    s1, s2 = storage_values(method, 1000, layout)["total"], storage_values(method, 2000, layout)["total"]
    a = (s2 - s1) // 1000
    return f"{'' if a == 1 else f'{a} '}N_L + {s1 - 1000 * a}"


# ---------------------------------------------------------------------------------------------------------------
# Machine description
# ---------------------------------------------------------------------------------------------------------------
def machine_info() -> dict:
    import numpy
    import scipy
    info = dict(platform=platform.platform(), system=platform.system(), release=platform.release(),
                machine=platform.machine(), processor_id=platform.processor(),
                python=platform.python_version(), python_implementation=platform.python_implementation(),
                numpy=numpy.__version__, scipy=scipy.__version__)
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        info["cpu_model"] = str(winreg.QueryValueEx(k, "ProcessorNameString")[0]).strip()
        info["cpu_nominal_MHz"] = int(winreg.QueryValueEx(k, "~MHz")[0])
    except Exception as exc:                                  # non-Windows or no access
        info["cpu_model"] = f"unavailable ({type(exc).__name__})"
    try:
        import psutil
        info["cores_physical"] = psutil.cpu_count(logical=False)
        info["cores_logical"] = psutil.cpu_count(logical=True)
        info["ram_total_GiB"] = round(psutil.virtual_memory().total / 2 ** 30, 2)
        f = psutil.cpu_freq()
        if f is not None:
            info["cpu_freq_MHz_reported"] = dict(current=f.current, max=f.max)
            info["cpu_freq_note"] = ("psutil/WMI report the base clock as 'max'; turbo frequencies above it are not "
                                     "captured, and the actual clock during timing was not recorded")
        info["psutil"] = psutil.__version__
        info["affinity_during_timing"] = dict(cpus=list(psutil.Process().cpu_affinity()), pinned=False)
    except Exception as exc:
        info["psutil_error"] = str(exc)
    cs_info = _cpu_sets()
    if cs_info:
        info["cpu_sets"] = cs_info
        classes = sorted({c["efficiency_class"] for c in cs_info})
        info["hybrid"] = dict(
            is_hybrid=len(classes) > 1,
            per_efficiency_class={str(k): [c["logical_processor"] for c in cs_info if c["efficiency_class"] == k]
                                  for k in classes},
            note="Windows GetSystemCpuSetInformation EfficiencyClass: higher = performance core. The timing process "
                 "was not pinned, so the OS scheduler chose the core (P or LP-E) in every repeat.")
    try:
        cfg = numpy.show_config(mode="dicts")
        info["numpy_blas"] = cfg.get("Build Dependencies", {}).get("blas", {})
    except Exception:
        pass
    for c in ("process_time", "perf_counter"):
        ci = time.get_clock_info(c)
        info[f"clock_{c}"] = dict(implementation=ci.implementation, resolution_s=ci.resolution, monotonic=ci.monotonic)
    info["process_time_tick_s_measured"] = _process_tick()
    info["note"] = ("Timings in results/cost.json are desktop CPython + numpy on this machine (general-purpose OS, "
                    "other analyses possibly running concurrently); they are NOT embedded / microcontroller timings.")
    return info


def _cpu_sets() -> list:
    """Per logical processor: core index, last-level-cache index and EfficiencyClass (Windows only)."""
    try:
        import ctypes
        import ctypes.wintypes as wt
        k = ctypes.windll.kernel32
        n = wt.ULONG(0)
        k.GetSystemCpuSetInformation(None, 0, ctypes.byref(n), None, 0)
        buf = ctypes.create_string_buffer(n.value)
        if not k.GetSystemCpuSetInformation(buf, n, ctypes.byref(n), None, 0):
            return []
        raw, off, out = buf.raw, 0, []
        while off < n.value:
            size = int.from_bytes(raw[off:off + 4], "little")
            out.append(dict(logical_processor=raw[off + 14], core=raw[off + 15], llc=raw[off + 16],
                            efficiency_class=raw[off + 18]))
            off += size
        return out
    except Exception:
        return []


def _process_tick(n: int = 20) -> float:
    """Smallest non-zero increment of time.process_time observed while spinning (Windows: ~15.6 ms)."""
    incs = []
    t0 = time.process_time()
    while len(incs) < n:
        t1 = time.process_time()
        if t1 != t0:
            incs.append(t1 - t0)
            t0 = t1
    return float(np.median(incs))


def machine_load() -> dict:
    try:
        import psutil
        return dict(utc=_utc(), cpu_percent_1s=psutil.cpu_percent(interval=1.0),
                    loadavg_1_5_15=[float(v) for v in psutil.getloadavg()])
    except Exception as exc:
        return dict(utc=_utc(), error=str(exc))


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")



# ---------------------------------------------------------------------------------------------------------------
# Configurations and measurement
# ---------------------------------------------------------------------------------------------------------------
def load_json(name):
    with open(RES / name, encoding="utf-8") as fh:
        return json.load(fh)


def build_configs(cs: dict, frozen: dict) -> list:
    """Timed configurations: memory grid (timing file) + frozen configuration of every method (other files)."""
    cases, ocvs, cfgs = {}, {}, []
    for f in [cs["timing_file"]] + list(cs["frozen_check_files"]):
        c = E.load_case(f)                                    # validation split only; data.verify_file inside
        if not c.meta["verify_passed"]:
            raise RuntimeError(f"verify_file failed for {f}")
        cases[f] = c
    T_grid = cases[cs["timing_file"]].T

    def focv(T, p):
        if T not in ocvs:
            ocvs[T] = MD.AlignedOCV(T, E.q_id(T))
        return O.as_fast_ocv(ocvs[T], s=p["s"], dq=p["dq"])

    def add(method, case, L_label, role):
        T = case.T
        base = BASE.get(method, method)
        fz = frozen["methods"][base]["per_T"][str(T)]
        p, hyp = dict(fz["params"]), dict(fz["hyper"])
        if base in MEM_METHODS:
            hyp["L_s"] = None if L_label == "full" else float(L_label)
        cfgs.append(dict(id=f"{method}|T{T}|L{L_label}|{role}", method=method, T=T, L=L_label, role=role,
                         file=case.logical_id, params=p, hyper=hyp, case=case,
                         ocv=(focv(T, p) if method != "CC" else None),
                         z0=float(E.initial_soc(case, cs["z0_scenario"]))))

    cg = cases[cs["timing_file"]]
    for L in cs["L_grid_s"]:
        for m in MEM_METHODS:
            add(m, cg, L, "memory_grid")
    for L in cs["L_grid_s"]:
        add("TFO_lean", cg, L, "variant")                   # value-only OCV, no diagnostic output
    add("FOEKF_grow", cg, "full", "variant")                 # growing full-memory sum (like TFO/FOO)
    for m in ("EKF2RC", "AEKF2RC", "CC"):
        add(m, cg, "-", "frozen")
    for f in cs["frozen_check_files"]:
        c = cases[f]
        for m in ALL_METHODS:
            L = frozen["methods"][m]["per_T"][str(c.T)]["hyper"].get("L_s") if m in MEM_METHODS else "-"
            add(m, c, (int(L) if m in MEM_METHODS else "-"), "frozen")
    return cfgs, T_grid


def run_once(c):
    cs = c["case"]
    if c["method"] in BASE:                                   # same signal preparation as run_estimator
        I, V, Io = O._prep_signals(cs.I, cs.V, cs.I_out)
        f = _run_tfo_lean if c["method"] == "TFO_lean" else _run_foekf_grow
        return f(c["params"], c["hyper"], I, V, Io, float(cs.h), float(c["z0"]), c["ocv"])
    return O.run_estimator(c["method"], c["params"], c["hyper"], cs.I, cs.V, cs.h, c["z0"], c["ocv"], I_out=cs.I_out)


def _value_only(ocv):
    """FastOCV.both without the derivative (same arithmetic for the value, hence bitwise-identical U)."""
    Ul, Dl, z_lo, z_hi, dz, nmax = ocv._U, ocv._D, ocv.z_lo, ocv.z_hi, ocv.dz, ocv.n - 1

    def U(z):
        u = (z - z_lo) / dz
        if u <= 0.0:
            return Ul[0] + Dl[0] * (z - z_lo)
        if u >= nmax:
            return Ul[-1] + Dl[-1] * (z - z_hi)
        i = int(u)
        t = u - i
        y0, y1 = Ul[i], Ul[i + 1]
        m0, m1 = Dl[i] * dz, Dl[i + 1] * dz
        t2 = t * t
        t3 = t2 * t
        return (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * m1
    return U


def _run_tfo_lean(params, hyper, I, V, Io, h, z0, ocv):
    """Timing variant of observer._run_tfo (TFO): the same recursion with a value-only OCV and without the
    diagnostic one-step-ahead output.  Used ONLY for timing; zhat is checked to equal the TFO's bitwise."""
    alpha, lam, R0 = float(params["alpha"]), float(params.get("lam", 0.0)), float(params["R0"])
    c = O.model_constants(params)
    ap, bp, beta = c["ap"], c["bp"], c["beta"]
    l1, l2 = float(hyper["l1"]), float(hyper["l2"])
    zmin, zmax = hyper.get("soc_clip", O.SOC_CLIP)
    N = I.size - 1
    mi = O.resolve_memory(hyper, N, h)
    full, NL = mi["full_memory"], mi["N_L_used"]
    ha = h ** alpha
    den = 1.0 + ha * (ap + l2)
    om = TM.gl_weights(alpha, lam, h, NL)
    Il, Vl, Iol = I.tolist(), V.tolist(), Io.tolist()
    U = _value_only(ocv)
    zhat = np.empty(N + 1)
    if full:
        wrevF, hist = om[1:][::-1].copy(), np.zeros(N + 1)
    else:
        wrev, buf, pos = om[1:][::-1].copy(), np.zeros(2 * NL), 0
    dot = np.dot
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    zh = float(z0)
    ytil = Vl[0] - (U(zh) + R0 * Iol[0])
    zhat[0] = zh
    if not full:
        buf[pos] = 0.0
        buf[pos + NL] = 0.0
        pos = (pos + 1) % NL
    for n in range(1, N + 1):
        zh = zh + h * (beta * Il[n - 1] + l1 * ytil)
        if zh < zmin:
            zh = zmin
        elif zh > zmax:
            zh = zmax
        Uz = U(zh)
        Ion = Iol[n]
        mem = float(dot(wrevF[N - n:], hist[:n])) if full else float(dot(wrev, buf[pos:pos + NL]))
        vfree = ha * bp * Il[n - 1] - mem
        vp = (vfree + ha * l2 * (Vl[n] - Uz - R0 * Ion)) / den
        if full:
            hist[n] = vp
        else:
            buf[pos] = vp
            buf[pos + NL] = vp
            pos = (pos + 1) % NL
        ytil = Vl[n] - (Uz + R0 * Ion + vp)
        zhat[n] = zh
    cpu, wall = time.process_time() - t_c0, time.perf_counter() - t_w0
    nb = 8 * ((hist.size + wrevF.size) if full else (buf.size + wrev.size)) + 8 * O.N_SCALAR_ALLOWANCE
    return O._result("TFO_lean", zhat, None, None, cpu, wall, N if full else NL, nb, dict(**mi), {})


def _run_foekf_grow(params, hyper, I, V, Io, h, z0, ocv):
    """Timing variant of benchmarks._run_foekf for FULL memory with a growing sum (dot over the k stored
    samples, as TFO/FOO) instead of the fixed zero-padded N window.  Same recursion otherwise (implicit
    discretisation); zhat is checked against FOEKF full (equal up to summation-order rounding)."""
    from tfso import benchmarks as BM
    m = BM.foekf_model(params, h, str(hyper.get("discretisation", "implicit")))
    R0, alpha = float(params["R0"]), m["alpha"]
    F11, B0, B1, sc = m["F11"], m["B0"], m["B1"], m["mem_scale"]
    q0, q1 = [float(v) for v in hyper["Q"]]
    Rm, P0 = float(hyper["R"]), hyper["P0"]
    zmin, zmax = hyper.get("soc_clip", O.SOC_CLIP)
    N = I.size - 1
    mi = O.resolve_memory(hyper, N, h)
    if not mi["full_memory"]:
        raise ValueError("FOEKF_grow is the full-memory variant only")
    wm = sc * O.gl_weights_general(alpha, 0.0, h, N)[1:].copy()
    wm[0] = 0.0
    wrev = wm[::-1].copy()
    wrev2 = wrev * wrev
    hv, hp = np.zeros(N + 1), np.zeros(N + 1)
    Il, Vl, Iol = I.tolist(), V.tolist(), Io.tolist()
    both = ocv.both
    zhat = np.empty(N + 1)
    dot = np.dot
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    z, v = float(z0), 0.0
    p00, p01, p11 = float(P0[0]), 0.0, float(P0[1])
    zhat[0] = z
    hv[0], hp[0] = v, p11
    for k in range(1, N + 1):
        Ik1 = Il[k - 1]
        memv = float(dot(wrev[N - k:], hv[:k]))
        memp = float(dot(wrev2[N - k:], hp[:k]))
        z = z + B0 * Ik1
        v = F11 * v + B1 * Ik1 - memv
        p00 = p00 + q0
        p01 = F11 * p01
        p11 = F11 * F11 * p11 + q1 + memp
        if z < zmin:
            z = zmin
        elif z > zmax:
            z = zmax
        Uz, d = both(z)
        innov = Vl[k] - (Uz + R0 * Iol[k] + v)
        c0 = p00 * d + p01
        c1 = p01 * d + p11
        S = d * c0 + c1 + Rm
        k0, k1 = c0 / S, c1 / S
        z = z + k0 * innov
        v = v + k1 * innov
        p00 = p00 - k0 * c0
        p01 = p01 - k0 * c1
        p11 = p11 - k1 * c1
        if z < zmin:
            z = zmin
        elif z > zmax:
            z = zmax
        hv[k], hp[k] = v, p11
        zhat[k] = z
    cpu, wall = time.process_time() - t_c0, time.perf_counter() - t_w0
    nb = 8 * (hv.size + hp.size + wrev.size + wrev2.size + 3 + O.N_SCALAR_ALLOWANCE)
    return O._result("FOEKF_grow", zhat, None, None, cpu, wall, N, nb, dict(**mi), {})


def _zhash(z):
    return hashlib.sha1(np.round(np.asarray(z, float), 12).tobytes()).hexdigest()[:16]


def measure(cs: dict, cfgs: list) -> list:
    rng = np.random.default_rng(int(cs["order_seed"]))
    R, W, target = int(cs["repeats"]), int(cs["warmup"]), float(cs["target_repeat_s"])
    info = {}
    for c in cfgs:
        for _ in range(max(W, 1)):
            r = run_once(c)
        fl = r["flags"]
        N = int(r["zhat"].size - 1)
        info[c["id"]] = dict(N=N, B=max(1, int(math.ceil(target / max(r["wall_s"], 1e-6)))), cpu=[], wall=[],
                             zhash=_zhash(r["zhat"]), bytes_state=int(r["bytes_state"]),
                             n_history_samples=int(r["n_history_samples"]), N_L_used=fl.get("N_L_used"),
                             full_memory=bool(fl.get("full_memory", False)), deterministic=True, zhat=r["zhat"])
    for c in cfgs:                                            # timing variants reproduce their base method
        if c["method"] in BASE:
            bid = f"{BASE[c['method']]}|T{c['T']}|L{c['L']}|memory_grid"
            dz = np.abs(info[c["id"]]["zhat"] - info[bid]["zhat"])
            info[c["id"]]["equivalence"] = dict(base_id=bid, max_abs_zhat_diff=float(dz.max()),
                                                bitwise_identical=bool(np.all(dz == 0.0)))
    for d in info.values():
        d.pop("zhat")
    tick = _process_tick()
    load_trace = []
    try:
        import psutil
        psutil.getloadavg()                                   # starts the Windows load-average emulation
        psutil.cpu_percent(None)
    except Exception:
        psutil = None
    t0 = time.perf_counter()
    for rep in range(R):
        for k in rng.permutation(len(cfgs)):
            c = cfgs[int(k)]
            d = info[c["id"]]
            cpu = wall = 0.0
            for _ in range(d["B"]):
                r = run_once(c)
                cpu += r["cpu_process_s"]
                wall += r["wall_s"]
            if _zhash(r["zhat"]) != d["zhash"]:
                d["deterministic"] = False
            d["cpu"].append(cpu / (d["B"] * d["N"]) * 1e6)
            d["wall"].append(wall / (d["B"] * d["N"]) * 1e6)
        if psutil is not None:
            load_trace.append(dict(repeat=rep, t_s=time.perf_counter() - t0, cpu_percent=psutil.cpu_percent(None),
                                   loadavg_1min=float(psutil.getloadavg()[0])))
        print(f"repeat {rep + 1}/{R} done, {time.perf_counter() - t0:.0f} s", flush=True)
    out = []
    for c in cfgs:
        d = info[c["id"]]
        rec = dict(id=c["id"], method=c["method"], T=c["T"], L=c["L"], role=c["role"], file=c["file"],
                   N_samples=d["N"], runs_per_repeat=d["B"], repeats=R, warmup=W, N_L_used=d["N_L_used"],
                   full_memory=d["full_memory"], bytes_state=d["bytes_state"],
                   n_history_samples=d["n_history_samples"], deterministic=d["deterministic"], zhash=d["zhash"],
                   process_time_quantum_us=tick / (d["B"] * d["N"]) * 1e6,
                   equivalence=d.get("equivalence"))
        for clk in ("cpu", "wall"):
            a = np.asarray(d[clk])
            rec[f"{clk}_us_per_sample"] = dict(median=float(np.median(a)), q25=float(np.quantile(a, 0.25)),
                                               q75=float(np.quantile(a, 0.75)), min=float(a.min()),
                                               max=float(a.max()), values=[float(v) for v in a])
        m = BASE.get(c["method"], c["method"])
        if c["method"] == "FOEKF_grow":                     # growing histories N+1 (x2), weights N (x2), P 3
            sv = dict(total=2 * (d["N"] + 1) + 2 * d["N"] + 3 + O.N_SCALAR_ALLOWANCE)
        elif m in MEM_METHODS and d["full_memory"] and m != "FOEKF":
            sv = storage_full(m, d["N"], scalars="allowance")
        else:
            sv = storage_values(m, d["N_L_used"] if m in MEM_METHODS else None, scalars="allowance")
        rec["storage_check"] = dict(values_rule=sv["total"], bytes_rule=8 * sv["total"],
                                    matches_bytes_state=bool(8 * sv["total"] == d["bytes_state"]),
                                    note="implementation convention: uniform 8-scalar allowance")
        out.append(rec)
    return out, dict(process_time_tick_s=tick, per_repeat=load_trace)


def weight_generation(cs: dict, frozen: dict, T: int, N_list: list) -> list:
    wg = cs["weight_gen"]
    R, target = int(wg["repeats"]), float(wg["target_batch_s"])
    rows = []
    for method in MEM_METHODS:
        p = frozen["methods"][method]["per_T"][str(T)]["params"]
        alpha, lam = float(p["alpha"]), (float(p["lam"]) if method == "TFO" else 0.0)
        den = 1.0 + O.model_constants(p)["ap"]               # h = 1 s

        def gen(N, alpha=alpha, lam=lam, den=den, method=method):
            if method == "FOEKF":
                w = O.gl_weights_general(alpha, 0.0, 1.0, N)[1:] / den
                return w, w * w
            return TM.gl_weights(alpha, lam, 1.0, N)

        for N in N_list:
            t1 = time.perf_counter()
            gen(N)
            K = max(1, int(target / max(time.perf_counter() - t1, 1e-7)))
            cpu, wall = [], []
            for _ in range(R):
                c0, w0 = time.process_time(), time.perf_counter()
                for _ in range(K):
                    gen(N)
                cpu.append((time.process_time() - c0) / K * 1e6)
                wall.append((time.perf_counter() - w0) / K * 1e6)
            rows.append(dict(method=method, N_L=int(N), alpha=alpha, lam=lam, calls_per_batch=K,
                             wall_us_per_call=dict(median=float(np.median(wall)), q25=float(np.quantile(wall, 0.25)),
                                                   q75=float(np.quantile(wall, 0.75))),
                             cpu_us_per_call=dict(median=float(np.median(cpu)), q25=float(np.quantile(cpu, 0.25)),
                                                  q75=float(np.quantile(cpu, 0.75))),
                             ops=weight_gen_ops(method, int(N))))
    return rows


def _stor(m, NL, lay, N_full=None):
    v = storage_full(m, N_full) if N_full is not None else storage_values(m, NL, lay)
    x = layout_extra_ops(m, NL, lay) if N_full is None else dict(div=0, mul=0, add=0, flops=0)
    base = op_counts(m, NL)
    return dict(values=v["total"], history_samples=v["history_samples"], scalars=v["scalars"],
                bytes_f64=8 * v["total"], bytes_f32=4 * v["total"], extra_ops_per_sample=x,
                total_flops_per_sample=base["total_flops"] + x["flops"],
                div_per_sample=base["fixed"]["div"] + x["div"])


def analytic_rows(cs: dict, frozen: dict, N_run: int) -> dict:
    """Operation counts and storage (float64 / float32; three layouts) on the memory grid, at the certified
    memories of the frozen TFO, and the untempered certified horizon of the frozen FOO (gain_design.json)."""
    grid = []
    for L in cs["L_grid_s"]:
        for m in MEM_METHODS:
            NL = N_run if L == "full" else int(math.ceil(float(L)))
            st = {lay: _stor(m, NL, lay) for lay in ("implemented", "single_ring", "minimal")}
            if L == "full" and m != "FOEKF":
                st["implemented"] = _stor(m, NL, "implemented", N_full=N_run)
            ops = op_counts(m, NL)
            if L == "full":                                   # TFO/FOO growing sum; FOEKF fixed zero-padded window
                ops["full_memory_sum"] = (dict(kind="growing", macs_at_step_n="n", mean_macs=(NL + 1) / 2, max_macs=NL)
                                          if m != "FOEKF" else
                                          dict(kind="fixed zero-padded window of N", macs_every_step=2 * (NL - 1)))
            grid.append(dict(method=m, L=L, N_L=NL, full_memory=(L == "full"), ops=ops, storage=st))
    for m in ("EKF2RC", "AEKF2RC", "CC"):
        grid.append(dict(method=m, L="-", N_L=None, full_memory=False, ops=op_counts(m, None),
                         storage={lay: _stor(m, None, lay) for lay in ("implemented", "single_ring", "minimal")}))
    cert = []
    for T, a in frozen["ablation_memory_TFO"].items():
        for key in ("L_cert_s", "L_short_s"):
            NL = int(math.ceil(float(a[key])))
            cert.append(dict(T=int(T), which=key, L_s=float(a[key]), N_L=NL, ops=op_counts("TFO", NL),
                             storage={lay: _stor("TFO", NL, lay) for lay in ("implemented", "single_ring", "minimal")}))
    unt = []
    eps = float(D.load_config()["design_tuning"]["eps_z_primary"])
    gd = load_json("gain_design.json")
    for T in (0, 25, 45):
        Lf = int(frozen["methods"]["FOO"]["per_T"][str(T)]["L_s"])
        for e in gd["post_certificates"]:
            if int(e["T"]) == T and float(e["lam"]) == 0.0 and int(e["L"]) == Lf:
                for mr in e["memory_requirement"]:
                    if abs(float(mr["eps_z"]) - eps) < 1e-12 and mr.get("defined"):
                        lg = float(mr["log10_L_untempered_s"])
                        unt.append(dict(T=T, eps_z=eps, log10_L_s=lg, log10_macs_per_sample=lg,
                                        log10_bytes_minimal_f64=math.log10(8.0) + lg,
                                        source=f"gain_design.json post_certificates (lam=0, L={Lf}) memory_requirement"))
    n = int(D.load_config()["estimators"]["ocv_table"]["n"])
    tcp = TM.cost_per_sample(400)
    return dict(grid=grid, certified_TFO=cert, untempered_FOO=unt, eps_z_primary=eps,
                frozen_lambda_TFO={T: float(frozen["methods"]["TFO"]["per_T"][str(T)]["params"]["lam"]) for T in (0, 25, 45)},
                tempered_cost_per_sample_overhead=int(tcp["macs"] - 400),
                storage_formulas={f"{m}|{lay}": storage_formula(m, lay) for m in ("TFO", "FOEKF")
                                  for lay in ("implemented", "single_ring", "minimal")},
                scalars={m: SCALARS[m] for m in ALL_METHODS}, cov_values=COV,
                ocv_table=dict(nodes=n, values=2 * n, bytes_f64=16 * n, bytes_f32=8 * n,
                               note="constant model data (U and dU/dz at every node), shared by every model-based "
                                    "method; not counted in the per-method state storage"))


def linear_fit(meas: list, cs: dict, N_run: int) -> dict:
    """Median time vs N_L (finite grid): least-squares line, percentile-bootstrap CI (repeats resampled per L),
    lower-contention fit on the per-configuration minima, and prediction at N_L = N/2, N and the certified L."""
    bs = cs["bootstrap"]
    rng = np.random.default_rng(int(bs["seed"]))
    out = {}
    for m in MEM_METHODS + ("TFO_lean",):
        role = "variant" if m in BASE else "memory_grid"
        rows = [r for r in meas if r["method"] == m and r["role"] == role and not r["full_memory"]]
        x = np.array([r["N_L_used"] for r in rows], float)
        for clk in ("cpu", "wall"):
            V = [np.asarray(r[f"{clk}_us_per_sample"]["values"]) for r in rows]
            y = np.array([np.median(v) for v in V])
            b, a = np.polyfit(x, y, 1)
            B = np.array([np.polyfit(x, [np.median(rng.choice(v, v.size)) for v in V], 1) for _ in range(int(bs["n_boot"]))])
            bmin, amin = np.polyfit(x, [v.min() for v in V], 1)
            from scipy import stats
            out[f"{m}_{clk}"] = dict(
                intercept_us=float(a), slope_ns_per_history_sample=float(b * 1e3),
                slope_ci95_ns=[float(v) for v in np.quantile(B[:, 0] * 1e3, [0.025, 0.975])],
                intercept_ci95_us=[float(v) for v in np.quantile(B[:, 1], [0.025, 0.975])],
                min_fit=dict(intercept_us=float(amin), slope_ns_per_history_sample=float(bmin * 1e3)),
                N_L=[int(v) for v in x], median_us=[float(v) for v in y],
                spearman_median_vs_NL=float(stats.spearmanr(x, y)[0]),
                rel_increase_first_to_last=float(y[-1] / y[0] - 1.0),
                predicted_us=dict(N_half=float(a + b * (N_run + 1) / 2), N=float(a + b * N_run)))
    return out


def statistics(meas: list, cs: dict, frozen: dict, T_grid: int, N_run: int, fit: dict) -> dict:
    from scipy import stats
    bs = cs["bootstrap"]
    rng = np.random.default_rng(int(bs["seed"]) + 1)
    get = {(r["method"], str(r["L"]), r["T"], r["role"]): r for r in meas}
    # TFO - FOO paired by repeat round (same shuffled round; approximate pairing)
    paired = []
    for L in cs["L_grid_s"]:
        for clk in ("cpu", "wall"):
            a = np.asarray(get[("TFO", str(L), T_grid, "memory_grid")][f"{clk}_us_per_sample"]["values"])
            b = np.asarray(get[("FOO", str(L), T_grid, "memory_grid")][f"{clk}_us_per_sample"]["values"])
            d = a - b
            B = [np.median(rng.choice(d, d.size)) for _ in range(int(bs["n_boot"]))]
            ci = [float(v) for v in np.quantile(B, [0.025, 0.975])]
            paired.append(dict(L=L, clock=clk, median_diff_us=float(np.median(d)), ci95_us=ci,
                               ci_excludes_0=bool(ci[0] > 0 or ci[1] < 0),
                               wilcoxon_p=float(stats.wilcoxon(d).pvalue) if np.any(d != 0) else 1.0))
    # certified-memory prediction (extrapolation of the desktop fit, indicative only)
    cert = {T: int(math.ceil(float(a["L_cert_s"]))) for T, a in frozen["ablation_memory_TFO"].items()}
    pred = {m: {T: float(fit[f"{m}_cpu"]["intercept_us"] + fit[f"{m}_cpu"]["slope_ns_per_history_sample"] * 1e-3 * NL)
                for T, NL in cert.items()} for m in ("TFO", "TFO_lean", "FOEKF")}
    # full memory, like-for-like
    full = {}
    for m, role in (("TFO", "memory_grid"), ("FOO", "memory_grid"), ("FOEKF", "memory_grid"),
                    ("TFO_lean", "variant"), ("FOEKF_grow", "variant")):
        r = get[(m, "full", T_grid, role)]
        fm = BASE.get(m, m) if m != "TFO_lean" else "TFO_lean"
        f = fit[f"{fm}_cpu"]
        full[m] = dict(cpu_median_us=r["cpu_us_per_sample"]["median"],
                       wall_median_us=r["wall_us_per_sample"]["median"],
                       fit_at_mean_growing_length_us=f["predicted_us"]["N_half"], fit_at_N_us=f["predicted_us"]["N"],
                       sum_kind=("fixed N window" if m == "FOEKF" else "growing"))
    # lean vs implemented TFO
    lean = []
    for L in cs["L_grid_s"]:
        for clk in ("cpu", "wall"):
            t = get[("TFO", str(L), T_grid, "memory_grid")][f"{clk}_us_per_sample"]["median"]
            l_ = get[("TFO_lean", str(L), T_grid, "variant")][f"{clk}_us_per_sample"]["median"]
            lean.append(dict(L=L, clock=clk, TFO_us=t, TFO_lean_us=l_, rel_diff=float(l_ / t - 1.0)))
    # temperature (in)dependence of the frozen configurations
    kw = {}
    for m in ALL_METHODS:
        groups = [np.asarray(r["cpu_us_per_sample"]["values"]) for r in meas if r["method"] == m and (
            r["role"] == "frozen" or (r["role"] == "memory_grid" and str(r["L"]) == str(int(frozen["memory_budget_primary_s"]))))]
        if len(groups) == 3:
            kw[m] = dict(p=float(stats.kruskal(*groups).pvalue), medians=[float(np.median(g)) for g in groups])
    rel_iqr = [(r["cpu_us_per_sample"]["q75"] - r["cpu_us_per_sample"]["q25"]) / r["cpu_us_per_sample"]["median"]
               for r in meas]
    wall_over_cpu = [r["wall_us_per_sample"]["median"] / r["cpu_us_per_sample"]["median"] for r in meas]
    return dict(paired_TFO_minus_FOO=paired, n_paired_ci_excluding_0=sum(p["ci_excludes_0"] for p in paired if p["clock"] == "cpu"),
                n_paired=sum(1 for p in paired if p["clock"] == "cpu"),
                predicted_cpu_at_certified_L_us=pred, certified_N_L=cert, full_memory=full, lean_vs_TFO=lean,
                kruskal_T=kw, rel_iqr_range=[float(min(rel_iqr)), float(max(rel_iqr))],
                rel_iqr_median=float(np.median(rel_iqr)),
                wall_over_cpu_median_range=[float(min(wall_over_cpu)), float(max(wall_over_cpu))])


# ---------------------------------------------------------------------------------------------------------------
# Outputs (regenerated from results/cost.json only)
# ---------------------------------------------------------------------------------------------------------------
def _grid_row(res, m, L):
    for g in res["analytic"]["grid"]:
        if g["method"] == m and str(g["L"]) == str(L):
            return g
    raise KeyError((m, L))


def _meas(res, m, L=None, T=None, role=None):
    for r in res["timing"]:
        if r["method"] == m and (L is None or str(r["L"]) == str(L)) and (T is None or r["T"] == T) \
                and (role is None or r["role"] == role):
            return r
    raise KeyError((m, L, T, role))


def _kb(b):
    return f"{b / 1000:.1f}" if b < 1e5 else f"{b / 1000:.0f}"


def _cpu(r):
    c = r["cpu_us_per_sample"]
    return f"{c['median']:.2f} [{c['q25']:.2f}, {c['q75']:.2f}]"


def write_table(res):
    cs = res["settings"]
    Tg, N, Lb = res["timing_T"], res["N_run"], int(res["memory_budget_primary_s"])
    st = res["statistics"]
    gmin = _grid_row(res, "TFO", Lb)["storage"]["minimal"]
    fz = res["analytic"]["storage_formulas"]
    lines = [r"% Generated by scripts/08_cost.py from results/cost.json -- do not edit by hand.",
             r"\begin{table}[t]", r"\centering", r"\footnotesize",
             r"\caption{Computational cost per sample at $h=1$\,s. Ops: multiply-adds of the memory sum(s) (MAC) "
             r"+ fixed floating-point operations (mul+add+div, constants precomputed) + OCV table evaluations "
             r"(U: value; U$'$: value and slope), counted for an idealised embedded implementation. Storage in kB "
             r"($10^3$ bytes), float64 (float32 in parentheses, analytic): impl.\ = implemented layout (doubled ring "
             r"buffer, stored weights, covariances, fixed scalars derived per method), ring = single circular buffer + "
             r"stored weights (the $2N_L$ layout of Remark~\ref{rem:m4b:cost}). A minimal layout that regenerates the "
             r"weights in every sample needs only " + fz["TFO|minimal"].replace("N_L", r"$N_L$") + r" values for TFO/FOO ("
             + f"{gmin['bytes_f64'] / 1e3:.2f}" + r"\,kB at $L=" + str(Lb) + r"$\,s) but adds $N_L$ divisions, $N_L$ "
             r"multiplications and $N_L$ additions per sample. CPU: \texttt{time.process\_time} over the estimation "
             r"loop, $\mu$s per sample, median [IQR] over " + str(cs["repeats"]) + r" repeats, desktop CPython on the "
             r"validation file " + cs["timing_file"].replace("_", r"\_") + r" (" + str(N) + r" samples); IQR/median "
             + f"{100 * st['rel_iqr_range'][0]:.0f}--{100 * st['rel_iqr_range'][1]:.0f}" + r"\,\%; absolute values "
             r"depend on machine load and core type (hybrid CPU, not pinned); indicative only, not an embedded timing. "
             r"$^a$Full memory, TFO/FOO: growing sum, $n$ MACs at step $n$ (mean $(N+1)/2$), storage for this file. "
             r"$^b$Full memory, FOEKF as implemented: fixed zero-padded window of $N$ samples, $2(N-1)$ MACs at every "
             r"step; the two full-memory CPU values are therefore not like for like (growing-sum FOEKF in the lower "
             r"block). $^c$TFO with a value-only OCV and without the diagnostic one-step-ahead output (identical "
             r"estimates); the TFO column includes an unused d$U$/d$z$ evaluation.}",
             r"\label{tab:cost}", r"\setlength{\tabcolsep}{2.8pt}",
             r"\begin{tabular}{rr lrrrr lrr}", r"\hline",
             r" & & \multicolumn{5}{c}{TFO / FOO} & \multicolumn{3}{c}{FOEKF} \\",
             r"$L$ [s] & $N_L$ & ops & kB impl. & kB ring & TFO CPU & FOO CPU & ops & kB impl. & CPU \\", r"\hline"]
    for L in cs["L_grid_s"]:
        g, gf = _grid_row(res, "TFO", L), _grid_row(res, "FOEKF", L)
        o, of = g["ops"], gf["ops"]
        s_, sf, sr = g["storage"]["implemented"], gf["storage"]["implemented"], g["storage"]["single_ring"]
        if L == "full":
            mt = f"$n$$^a$"
            mf = f"{of['memory_macs']}$^b$"
            ring = "--"
        else:
            mt, mf, ring = str(o["memory_macs"]), str(of["memory_macs"]), _kb(sr["bytes_f64"])
        lines.append(f"{'full' if L == 'full' else L} & {g['N_L']} & "
                     f"{mt}+{o['fixed_flops']}+U & {_kb(s_['bytes_f64'])} ({_kb(s_['bytes_f32'])}) & {ring} & "
                     f"{_cpu(_meas(res, 'TFO', L, Tg, 'memory_grid'))} & {_cpu(_meas(res, 'FOO', L, Tg, 'memory_grid'))} & "
                     f"{mf}+{of['fixed_flops']}+U$'$ & {_kb(sf['bytes_f64'])} ({_kb(sf['bytes_f32'])}) & "
                     f"{_cpu(_meas(res, 'FOEKF', L, Tg, 'memory_grid'))} \\\\")
    lines += [r"\hline", r"\multicolumn{2}{l}{Method} & ops & kB impl. & & CPU & & & & \\", r"\hline"]
    for m, lab in (("EKF2RC", "EKF (2RC)"), ("AEKF2RC", "AEKF (2RC)"), ("CC", "CC")):
        g = _grid_row(res, m, "-")
        o, s_ = g["ops"], g["storage"]["implemented"]
        u = "" if not o["ocv_evals"] else ("+U$'$" if o["ocv_derivative"] else "+U")
        lines.append(rf"\multicolumn{{2}}{{l}}{{{lab}}} & {o['fixed_flops']}{u} & {s_['bytes_f64'] / 1000:.3f} "
                     f"({s_['bytes_f32'] / 1000:.3f}) & & {_cpu(_meas(res, m, '-', Tg, 'frozen'))} & & & & \\\\")
    lines.append(rf"\multicolumn{{2}}{{l}}{{TFO$^c$, $L={Lb}$}} & & & & "
                 f"{_cpu(_meas(res, 'TFO_lean', Lb, Tg, 'variant'))} & & & & \\\\")
    lines.append(rf"\multicolumn{{2}}{{l}}{{FOEKF, growing full sum}} & & & & & & "
                 f"2($n-1$)+{_grid_row(res, 'FOEKF', 'full')['ops']['fixed_flops']}+U$'$ & & "
                 f"{_cpu(_meas(res, 'FOEKF_grow', 'full', Tg, 'variant'))} \\\\")
    lines += [r"\hline", r"\end{tabular}", r"\end{table}"]
    TAB.mkdir(exist_ok=True)
    (TAB / "tab_cost.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _stagger(vals, min_gap, log=False):
    """Label positions: sorted values pushed apart by at least min_gap (in log10 units if log)."""
    order = np.argsort(vals)
    pos = np.log10(vals) if log else np.asarray(vals, float)
    out = np.array(pos, float)
    for k in range(1, len(order)):
        a, b = order[k - 1], order[k]
        if out[b] - out[a] < min_gap:
            out[b] = out[a] + min_gap
    return 10 ** out if log else out


def make_figure(res):
    from tfso import plotstyle as ps
    plt = ps.setup()
    cs, Tg, N = res["settings"], res["timing_T"], res["N_run"]
    finite = [L for L in cs["L_grid_s"] if L != "full"]
    xfull = 9000.0                                            # 'full' drawn as a separate category (axis gap)
    fd = dict(L_s=[float(L) for L in finite], full_category_x=xfull, N_run=N, cpu={}, storage={},
              reference_cpu={}, reference_bytes={},
              full_note="TFO/FOO: growing sum (mean (N+1)/2 MACs); FOEKF: fixed zero-padded N window; FOEKF_grow: growing")
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=ps.figsize("text", 66), layout="constrained")
    series = (("TFO", "TFO", "memory_grid", {}), ("FOO", "FOO", "memory_grid", {}), ("FOEKF", "FOEKF", "memory_grid", {}),
              ("TFO_lean", "TFO", "variant", dict(ls=(0, (2.5, 1.5)), lw=ps.LW["thin"] + 0.2)))
    for m, sty, role, kw in series:
        rows = [_meas(res, m, L, Tg, role) for L in finite]
        med = np.array([r["cpu_us_per_sample"]["median"] for r in rows])
        q25 = np.array([r["cpu_us_per_sample"]["q25"] for r in rows])
        q75 = np.array([r["cpu_us_per_sample"]["q75"] for r in rows])
        lab = "TFO, value-only OCV" if m == "TFO_lean" else m
        if m == "TFO_lean":
            ax1.plot(finite, med, color=ps.SERIES[sty]["color"], label=lab, **kw)
        else:
            ax1.errorbar(finite, med, yerr=[med - q25, q75 - med], capsize=1.5, elinewidth=0.6, label=lab,
                         **ps.line(sty, marker=True))
        rf = _meas(res, m, "full", Tg, role)["cpu_us_per_sample"]
        fd["cpu"][m] = dict(median=med.tolist(), q25=q25.tolist(), q75=q75.tolist(),
                            full=dict(median=rf["median"], q25=rf["q25"], q75=rf["q75"]))
    dx = {"TFO": 0.93, "FOO": 1.0, "FOEKF": 1.07, "FOEKF_grow": 1.07}
    for m, role, filled in (("TFO", "memory_grid", False), ("FOO", "memory_grid", False),
                            ("FOEKF", "memory_grid", False), ("FOEKF_grow", "variant", True)):
        rf = _meas(res, m, "full", Tg, role)["cpu_us_per_sample"]
        sty = "FOEKF" if m == "FOEKF_grow" else m
        ax1.errorbar([xfull * dx[m]], [rf["median"]], yerr=[[rf["median"] - rf["q25"]], [rf["q75"] - rf["median"]]],
                     ecolor=ps.SERIES[sty]["color"], elinewidth=0.6, capsize=1.5,
                     **ps.points(sty, marker=("x" if m == "FOEKF_grow" else ps.SERIES[sty]["marker"]), filled=filled,
                                 ms=4.5, **({"mec": ps.SERIES[sty]["color"]} if m == "FOEKF_grow" else {})))
        if m == "FOEKF_grow":
            fd["cpu"]["FOEKF_grow"] = dict(full=dict(median=rf["median"], q25=rf["q25"], q75=rf["q75"]))
    ref = {m: _meas(res, m, "-", Tg, "frozen")["cpu_us_per_sample"]["median"] for m in ("EKF2RC", "AEKF2RC", "CC")}
    top = max(max(fd["cpu"][m]["q75"] + [fd["cpu"][m]["full"]["q75"]]) for m in ("TFO", "FOO", "FOEKF"))
    ly = _stagger(list(ref.values()), 0.075 * 1.35 * top)
    for (m, v), y in zip(ref.items(), ly):
        ax1.axhline(v, color=ps.SERIES[m]["color"], ls=ps.SERIES[m]["ls"], lw=ps.LW["ref"])
        ax1.text(4150, y, {"EKF2RC": "EKF", "AEKF2RC": "AEKF", "CC": "CC"}[m], color=ps.INK2, fontsize=7,
                 va="center", ha="center", bbox=dict(facecolor="white", edgecolor="none", pad=0.3, alpha=0.9))
        fd["reference_cpu"][m] = v
    ax1.axvline(cs_budget(res), color=ps.MUTED, ls=":", lw=ps.LW["ref"])
    ax1.axvline(5000, color=ps.MUTED, ls="-", lw=0.4)
    ax1.set_xscale("log")
    ax1.set_xlim(40, 11500)
    ax1.set_xticks(finite + [xfull])
    ax1.set_xticklabels([str(L) for L in finite] + ["full"])
    ax1.minorticks_off()
    ax1.set_ylim(0, 1.35 * top)
    ax1.text(cs_budget(res) * 1.06, 0.03 * top, "budget", color=ps.INK2, fontsize=7, rotation=90, va="bottom")
    ax1.set_xlabel("memory horizon $L$ [s]")
    ax1.set_ylabel(r"CPU time per sample [$\mu$s]")
    ax1.legend(loc="upper left", ncol=2, handlelength=2.2)
    ps.panel_label(ax1, 0, x=-0.09)
    # (b) storage (analytic)
    Lx = np.unique(np.concatenate([np.geomspace(50, 3.0e4, 60), finite]))
    for m, lay, dt, kw, lab in (("TFO", "implemented", 8, ps.line("TFO"), "TFO/FOO, implemented, float64"),
                                ("TFO", "single_ring", 8, ps.line("TFO", ls="--", lw=ps.LW["thin"] + 0.2),
                                 "TFO/FOO, single ring, float64"),
                                ("TFO", "minimal", 4, ps.line("TFO", ls=":", lw=ps.LW["ref"] + 0.3),
                                 f"TFO/FOO, minimal, float32 (+{layout_extra_ops('TFO', 1000, 'minimal')['flops'] // 1000}$N_L$ flops)"),
                                ("FOEKF", "implemented", 8, ps.line("FOEKF"), "FOEKF, implemented, float64")):
        b = np.array([dt * storage_values(m, int(math.ceil(L)), lay)["total"] for L in Lx])
        ax2.plot(Lx, b, label=lab, **kw)
        fd["storage"][f"{m}_{lay}_{'f64' if dt == 8 else 'f32'}"] = dict(L_s=Lx.tolist(), bytes=b.tolist())
    rb = {m: _grid_row(res, m, "-")["storage"]["implemented"]["bytes_f64"] for m in ("EKF2RC", "AEKF2RC", "CC")}
    ly = _stagger(list(rb.values()), 0.4, log=True)
    for (m, v), y in zip(rb.items(), ly):
        ax2.axhline(v, color=ps.SERIES[m]["color"], ls=ps.SERIES[m]["ls"], lw=ps.LW["ref"])
        ax2.text(2.9e4, y, f"{ {'EKF2RC': 'EKF', 'AEKF2RC': 'AEKF', 'CC': 'CC'}[m]} {v:.0f} B", color=ps.INK2,
                 fontsize=7, va="center", ha="right",
                 bbox=dict(facecolor="white", edgecolor="none", pad=0.4, alpha=0.85))
        fd["reference_bytes"][m] = v
    cert = [c for c in res["analytic"]["certified_TFO"] if c["which"] == "L_cert_s"]
    cx, cy = [c["L_s"] for c in cert], [c["storage"]["implemented"]["bytes_f64"] for c in cert]
    ax2.plot(cx, cy, ls="none", marker="D", mfc="white", mec=ps.INK, mew=0.8, ms=4.5,
             label=r"TFO certified $L$ ($\varepsilon_z$ = " + f"{100 * res['analytic']['eps_z_primary']:.1f} %)")
    fd["certified_TFO"] = dict(L_s=cx, bytes_f64=cy)
    ax2.axvline(cs_budget(res), color=ps.MUTED, ls=":", lw=ps.LW["ref"])
    ax2.set_xscale("log")
    ax2.set_yscale("log")
    ax2.set_ylim(10, 3e7)
    ax2.set_xlabel("memory horizon $L$ [s]")
    ax2.set_ylabel("state storage [bytes]")
    ax2.legend(loc="upper left", handlelength=2.2)
    ps.panel_label(ax2, 1, x=-0.09)
    FIG.mkdir(exist_ok=True)
    pdf = ps.save(fig, FIG / "fig_cost_memory.pdf")
    ps.preview_png(pdf)
    plt.close(fig)
    return fd


def cs_budget(res):
    return float(res["memory_budget_primary_s"])


def outputs(res):
    """Table, figure, report from the measurement dict; figure arrays -> results/cost_outputs.json (cost.json is
    never rewritten here)."""
    write_table(res)
    fd = make_figure(res)
    oc = dict(generated_utc=_utc(), source="results/cost.json", measurement_code_hash=res["code_hash"],
              outputs_code_hash=hashlib.sha1(Path(__file__).read_bytes()).hexdigest()[:16], figure_data=fd)
    with open(OUT_RES / "cost_outputs.json", "w", encoding="utf-8") as fh:
        json.dump(oc, fh, indent=1)
    write_report(res, oc)


# ---------------------------------------------------------------------------------------------------------------
# Findings report (reports/cost_findings.md), every number read from results/cost.json and results/machine.json
# ---------------------------------------------------------------------------------------------------------------
def _m(res, m, L, role="memory_grid", clk="cpu"):
    return _meas(res, m, L, res["timing_T"], role)[f"{clk}_us_per_sample"]


def write_report(res, oc):
    with open(OUT_RES / "machine.json", encoding="utf-8") as fh:
        mach = json.load(fh)
    cs, Tg, N = res["settings"], res["timing_T"], res["N_run"]
    Lb = int(res["memory_budget_primary_s"])
    an, sx = res["analytic"], res["statistics"]
    g = {(x["method"], str(x["L"])): x for x in an["grid"]}
    o_t, o_f = g[("TFO", str(Lb))]["ops"], g[("FOEKF", str(Lb))]["ops"]
    o_e, o_a, o_c = g[("EKF2RC", "-")]["ops"], g[("AEKF2RC", "-")]["ops"], g[("CC", "-")]["ops"]
    st = lambda m, L, lay="implemented", k="bytes_f64": g[(m, str(L))]["storage"][lay][k]  # noqa: E731
    fit = res["linear_fit"]
    cert = [c for c in an["certified_TFO"] if c["which"] == "L_cert_s"]
    unt = an["untempered_FOO"]
    wg = {(w["method"], w["N_L"]): w for w in res["weight_generation"]}
    ocvt = an["ocv_table"]
    fz = an["storage_formulas"]
    eps = an["eps_z_primary"]
    lam = sorted(set(an["frozen_lambda_TFO"].values()))
    fr = [r for r in res["timing"] if r["role"] == "frozen" or (r["role"] == "memory_grid" and str(r["L"]) == str(Lb))]
    xm = layout_extra_ops("TFO", Lb, "minimal")
    q = [r["process_time_quantum_us"] for r in res["timing"]]
    ld = mach.get("load_during_timing", {})
    hy = mach.get("hybrid", {})

    def spread(m):
        v = [r["cpu_us_per_sample"]["median"] for r in fr if r["method"] == m]
        return f"{min(v):.2f}-{max(v):.2f}"

    def c(m, L, role="memory_grid", clk="cpu"):
        x = _m(res, m, L, role, clk)
        return f"{x['median']:.2f} us (IQR {x['q25']:.2f}-{x['q75']:.2f})"

    def ci(v, d=2):
        return f"[{v[0]:.{d}f}, {v[1]:.{d}f}]"

    ft, ff, fl = fit["TFO_cpu"], fit["FOEKF_cpu"], fit["TFO_lean_cpu"]
    L = ["# E4 Computational cost: findings\n"]
    L.append(f"Generated by `scripts/08_cost.py` from `results/cost.json` (measurement code hash {res['code_hash']}, "
             f"script archived as `{res['archived_script']}`), `results/machine.json` and `results/cost_outputs.json` "
             f"(figure arrays; outputs code hash {oc['outputs_code_hash']}). Table `tables/tab_cost.tex` (Table 7), "
             f"Figure `figures/fig_cost_memory.pdf` (Figure 8). Settings: config `cost_study`. Validation files only "
             f"({', '.join(res['validation_files'])}, `verify_file` passed); no test file was loaded. Nothing is tuned "
             f"here; all parameters, gains and memories come from `results/frozen_config.json`.\n")
    L.append("## 1. Setup and clocks\n")
    hyb = ""
    if hy.get("is_hybrid"):
        pc = hy["per_efficiency_class"]
        hyb = (f" It is a hybrid CPU: logical processors {pc[max(pc)]} are performance cores and {pc[min(pc)]} are "
               f"low-power efficiency cores (Windows efficiency classes {max(pc)}/{min(pc)}).")
    L.append(f"- **Machine:** {mach.get('cpu_model')}, {mach.get('cores_physical')} physical / "
             f"{mach.get('cores_logical')} logical cores, {mach.get('ram_total_GiB')} GiB RAM; {mach.get('platform')}; "
             f"CPython {mach.get('python')}, numpy {mach.get('numpy')}, scipy {mach.get('scipy')}.{hyb} The reported "
             f"clock ({mach.get('cpu_freq_MHz_reported', {}).get('max')} MHz) is the base clock; turbo frequencies are "
             "not captured. The process was not pinned to a core. **These are desktop Python timings, not embedded "
             "timings.**")
    L.append(f"- **Workload:** frozen parameters and hyper-parameters on {cs['timing_file']} ({N} steps, h = 1 s, "
             "nominal z0). On the memory grid only L changes; gains and covariances stay frozen.")
    L.append(f"- **Clocks:** `time.process_time` (CPU) and `time.perf_counter` (wall), both read around the estimation "
             f"loop only. One repeat is B back-to-back runs (about {cs['target_repeat_s']} s); the in-loop readings are "
             f"summed. The process-time tick is {res['load_trace']['process_time_tick_s'] * 1e3:.1f} ms, so each "
             f"repeat's CPU value is quantised in steps of {min(q):.3f}-{max(q):.3f} us per sample. Equal medians of "
             f"different configurations can arise from this quantisation and carry no meaning. There are "
             f"{cs['repeats']} repeats, each in a newly shuffled order, in one sequential process.")
    if ld:
        L.append(f"- **Machine load (system-wide, not controlled):** CPU {ld['cpu_percent_per_repeat_range'][0]:.0f}-"
                 f"{ld['cpu_percent_per_repeat_range'][1]:.0f} % per repeat (median "
                 f"{ld['cpu_percent_per_repeat_median']:.0f} %), 1-min load average {ld['loadavg_1min_range'][0]:.1f}-"
                 f"{ld['loadavg_1min_range'][1]:.1f} on {mach.get('cores_logical')} logical cores; other analyses ran "
                 f"concurrently. The IQR is {100 * sx['rel_iqr_range'][0]:.0f}-{100 * sx['rel_iqr_range'][1]:.0f} % of "
                 f"the median (median {100 * sx['rel_iqr_median']:.0f} %) and median wall/CPU is "
                 f"{sx['wall_over_cpu_median_range'][0]:.2f}-{sx['wall_over_cpu_median_range'][1]:.2f}. **Absolute "
                 "microsecond values depend on load and core type and are not reproducible to better than a few tens "
                 "of per cent; the rankings are the robust part.**")
    ck = res["checks"]
    L.append(f"- **Checks:** outputs identical across repeats: {ck['all_deterministic']} (zhat hash stored per "
             f"record). The timing variant TFO_lean reproduces TFO bitwise: {ck['TFO_lean_bitwise_identical']}. "
             f"FOEKF_grow reproduces FOEKF full up to max |dz| = {ck['FOEKF_grow_max_abs_zhat_diff']:.1e}. The "
             f"implementation's `bytes_state` follows its uniform 8-scalar convention: "
             f"{ck['bytes_rule_matches_implementation']} (the storage reported below uses derived scalar counts).\n")
    L.append("## 2. Operation counts and storage (derived from the recursions)\n")
    L.append("Counts are per sample for an idealised embedded implementation: constants precomputed, memory sums "
             "counted as multiply-adds (MAC), OCV as a cubic-Hermite table look-up of about "
             f"{OCV_VALUE['mul'] + OCV_VALUE['add']} flops for U, or "
             f"{OCV_VALUE['mul'] + OCV_VALUE['add'] + OCV_DERIV_EXTRA['mul'] + OCV_DERIV_EXTRA['add']} flops for U and "
             "dU/dz. Scalars = state, ring index, previous current (causal input) and precomputed constants, counted "
             "per method; covariances and adaptive statistics are listed separately.\n")
    L.append("| Method | memory MACs | fixed mul/add/div | OCV | scalars + cov | values: implemented / single ring / minimal |")
    L.append("|---|---|---|---|---|---|")
    for m, lab, mac in (("TFO", "TFO = FOO", "N_L"), ("FOEKF", "FOEKF", "2 (N_L - 1)")):
        o = g[(m, str(Lb))]["ops"]
        L.append(f"| {lab} | {mac} | {o['fixed']['mul']}/{o['fixed']['add']}/{o['fixed']['div']} | "
                 f"{'U, dU' if o['ocv_derivative'] else 'U'} | {len(an['scalars'][m])} + {an['cov_values'][m]} | "
                 f"{fz[m + '|implemented']} / {fz[m + '|single_ring']} / {fz[m + '|minimal']} |")
    for m, lab in (("EKF2RC", "EKF (2RC)"), ("AEKF2RC", "AEKF (2RC)"), ("CC", "CC")):
        o = g[(m, "-")]["ops"]
        ocv = "-" if not o["ocv_evals"] else ("U, dU" if o["ocv_derivative"] else "U")
        L.append(f"| {lab} | 0 | {o['fixed']['mul']}/{o['fixed']['add']}/{o['fixed']['div']} | {ocv} | "
                 f"{len(an['scalars'][m])} + {an['cov_values'][m]} | {g[(m, '-')]['storage']['implemented']['values']} |")
    L.append("")
    L.append(f"- **Tempering adds no per-sample cost.** It changes only the weight values, so TFO and FOO have identical "
             f"counts. At the primary budget L = {Lb} s, TFO/FOO need {o_t['memory_macs']} MACs + {o_t['fixed_flops']} "
             f"flops + 1 OCV value per sample; FOEKF needs {o_f['memory_macs']} MACs + {o_f['fixed_flops']} flops + 1 OCV "
             f"value and slope (state and covariance memory sums, about twice the memory work).")
    L.append(f"- The arithmetic gap to the fixed-memory filters is modest at small L and grows linearly with L. In "
             f"total flops (2 per MAC + fixed + OCV): TFO/FOO {g[('TFO', '50')]['ops']['total_flops']} at L = 50 s and "
             f"{o_t['total_flops']} at L = {Lb} s; FOEKF {g[('FOEKF', '50')]['ops']['total_flops']} and "
             f"{o_f['total_flops']}; EKF {o_e['total_flops']}, AEKF {o_a['total_flops']}, CC {o_c['total_flops']}.")
    L.append(f"- `tempered.cost_per_sample` (rem:m4b:cost) counts N_L + {an['tempered_cost_per_sample_overhead']} MACs, "
             f"the same N_L + O(1) law; the line-by-line count gives {o_t['fixed']['mul']} multiplications and "
             f"{o_t['fixed']['add']} additions outside the memory sum.")
    L.append(f"- **Storage at L = {Lb} s (float64):** TFO/FOO {st('TFO', Lb) / 1e3:.2f} kB implemented (doubled ring "
             f"buffer + weights) and {st('TFO', Lb, 'single_ring') / 1e3:.2f} kB with a single circular buffer and "
             f"stored weights (the 2 N_L layout of rem:m4b:cost; Table 7 column 'ring'); FOEKF "
             f"{st('FOEKF', Lb) / 1e3:.2f} kB implemented. EKF, AEKF and CC hold {st('EKF2RC', '-'):.0f}, "
             f"{st('AEKF2RC', '-'):.0f} and {st('CC', '-'):.0f} bytes (derived scalars; the implementation's uniform "
             f"8-scalar convention gives {8 * (6 + O.N_SCALAR_ALLOWANCE)}, {8 * (10 + O.N_SCALAR_ALLOWANCE)} and "
             f"{8 * O.N_SCALAR_ALLOWANCE} bytes).")
    mfl = g[("TFO", str(Lb))]["storage"]["minimal"]["total_flops_per_sample"]
    L.append(f"- **The minimal layout trades storage for arithmetic.** Regenerating the weights inside every sample "
             f"(omega_j = (r - c/j) omega_(j-1), constants combined) leaves {st('TFO', Lb, 'minimal') / 1e3:.2f} kB "
             f"float64 / {st('TFO', Lb, 'minimal', 'bytes_f32') / 1e3:.2f} kB float32 at L = {Lb} s, but adds "
             f"{xm['div']} divisions, {xm['mul']} multiplications and {xm['add']} additions per sample, i.e. "
             f"{mfl} instead of {o_t['total_flops']} flops ({mfl / o_t['total_flops']:.1f}x), N_L of them divisions. "
             "Storing 1/j instead removes the divisions but costs N_L stored values, which cancels the saving. A "
             "division is generally slower than a multiply-add on microcontroller FPUs; no cycle count is cited or "
             "measured here. The manuscript remark rem:m4b:cost ('N_L further multiplications') understates this "
             "price (see Review response).")
    L.append(f"- **Full memory** grows without bound. For this {N}-sample file: TFO/FOO use a growing sum (n MACs at "
             f"step n, mean {(N + 1) / 2:.0f}) and {st('TFO', 'full') / 1e3:.1f} kB; the implemented FOEKF uses a fixed "
             f"zero-padded window of N samples ({g[('FOEKF', 'full')]['ops']['full_memory_sum']['macs_every_step']} "
             f"MACs at every step) and {st('FOEKF', 'full') / 1e3:.0f} kB. Each hour at h = 1 s adds "
             f"{8 * 2 * 3600 / 1e3:.1f} kB (TFO/FOO, float64).")
    L.append(f"- **The OCV table as implemented** ({ocvt['nodes']} nodes, U and dU/dz) is {ocvt['bytes_f64'] / 1e3:.0f} kB "
             "in float64, larger than every state buffer on the grid. It is constant model data shared by all "
             "model-based methods and is not counted in the state storage; an embedded implementation would use a "
             "much coarser table (not evaluated).\n")
    L.append("## 3. Measured desktop CPU time\n")
    L.append(f"- **At L = {Lb} s, CPU per sample:** TFO {c('TFO', Lb)}, FOO {c('FOO', Lb)}, FOEKF {c('FOEKF', Lb)}; "
             f"EKF (2RC) {c('EKF2RC', '-', 'frozen')}, AEKF {c('AEKF2RC', '-', 'frozen')}, CC {c('CC', '-', 'frozen')}. "
             f"Wall: TFO {c('TFO', Lb, clk='wall')}, FOEKF {c('FOEKF', Lb, clk='wall')}.")
    lv = [x for x in sx["lean_vs_TFO"] if x["clock"] == "cpu"]
    L.append(f"- **Unneeded work in the desktop TFO loop.** The implemented TFO evaluates dU/dz (unused) and a "
             f"diagnostic one-step-ahead output. Without them (TFO_lean, identical estimates) the CPU per sample is "
             f"{c('TFO_lean', Lb, 'variant')} at L = {Lb} s; over the grid the median changes by "
             f"{100 * min(x['rel_diff'] for x in lv):+.0f} to {100 * max(x['rel_diff'] for x in lv):+.0f} %. The "
             "operation counts already assume the value-only form. Desktop ratios between methods do not transfer to "
             "a compiled MCU implementation.")
    xo = ft["intercept_us"] / (ft["slope_ns_per_history_sample"] * 1e-3)
    L.append(f"- **Dependence on L.** Linear fit of the median CPU time against N_L (finite grid, 95 % bootstrap CI "
             f"over repeats): TFO {ft['intercept_us']:.2f} us {ci(ft['intercept_ci95_us'])} + "
             f"{ft['slope_ns_per_history_sample']:.2f} ns {ci(ft['slope_ci95_ns'])} per history sample; TFO_lean "
             f"{fl['intercept_us']:.2f} us + {fl['slope_ns_per_history_sample']:.2f} ns {ci(fl['slope_ci95_ns'])}; FOEKF "
             f"{ff['intercept_us']:.2f} us {ci(ff['intercept_ci95_us'])} + {ff['slope_ns_per_history_sample']:.2f} ns "
             f"{ci(ff['slope_ci95_ns'])}. On the per-configuration minima (lower contention): TFO "
             f"{ft['min_fit']['slope_ns_per_history_sample']:.2f} ns, FOEKF {ff['min_fit']['slope_ns_per_history_sample']:.2f} ns. "
             f"From L = 50 to 3200 s the median rises by {100 * ft['rel_increase_first_to_last']:.0f} % (TFO) and "
             f"{100 * ff['rel_increase_first_to_last']:.0f} % (FOEKF); the medians need not be monotone at small L "
             f"(Spearman {ft['spearman_median_vs_NL']:.2f} for TFO), because the noise exceeds the memory term there. "
             + (f"**Interpreter overhead dominates for L below about {xo:.0f} s (TFO); above that the memory term "
                f"({ft['slope_ns_per_history_sample']:.2f} ns per history sample) dominates.** "
                if ft["slope_ci95_ns"][0] > 0 else
                "**The TFO slope CI includes 0: the memory term is not resolved at these horizons.** ")
             + f"Extrapolated to the certified memories (outside the "
             "measured range, indicative): TFO "
             + ", ".join(f"{v:.1f}" for v in sx["predicted_cpu_at_certified_L_us"]["TFO"].values())
             + " us and FOEKF " + ", ".join(f"{v:.1f}" for v in sx["predicted_cpu_at_certified_L_us"]["FOEKF"].values())
             + " us at 0/25/45 C.")
    fm = sx["full_memory"]
    L.append(f"- **Full memory (not like for like as implemented).** TFO {fm['TFO']['cpu_median_us']:.2f} us (fit at "
             f"the mean growing length N/2: {fm['TFO']['fit_at_mean_growing_length_us']:.2f} us); FOEKF as implemented "
             f"{fm['FOEKF']['cpu_median_us']:.2f} us (fit at N: {fm['FOEKF']['fit_at_N_us']:.2f} us, fixed N window); "
             f"FOEKF with a growing sum {fm['FOEKF_grow']['cpu_median_us']:.2f} us (fit at N/2: "
             f"{fm['FOEKF_grow']['fit_at_mean_growing_length_us']:.2f} us). Only TFO vs FOEKF_grow compares equal "
             "memory work.")
    kw = sx["kruskal_T"]
    L.append(f"- **No temperature dependence was detected.** Frozen configurations on the three validation files: "
             f"median CPU per sample TFO {spread('TFO')}, FOO {spread('FOO')}, FOEKF {spread('FOEKF')}, EKF "
             f"{spread('EKF2RC')}, AEKF {spread('AEKF2RC')} us; Kruskal-Wallis p >= {min(v['p'] for v in kw.values()):.2f}.")
    pc = [p for p in sx["paired_TFO_minus_FOO"] if p["clock"] == "cpu"]
    ex = [p for p in pc if p["ci_excludes_0"]]
    sgn = {p["median_diff_us"] > 0 for p in ex}
    verdict = ("no systematic difference found" if (len(ex) <= 2 or len(sgn) > 1) else
               "a possible systematic difference (all excluding CIs share one sign)")
    L.append(f"- **TFO vs FOO: {verdict}.** Paired by repeat round (same shuffled round, not "
             f"simultaneous, so the pairing is approximate), the median TFO - FOO CPU difference ranges from "
             f"{min(p['median_diff_us'] for p in pc):+.3f} to {max(p['median_diff_us'] for p in pc):+.3f} us over "
             f"{len(pc)} values of L; {len(ex)} of {len(pc)} bootstrap CIs exclude 0"
             + (f" (L = {', '.join(str(p['L']) for p in ex)}, signs "
                f"{', '.join('+' if p['median_diff_us'] > 0 else '-' for p in ex)})" if ex else "")
             + ". With this many comparisons, isolated exclusions are expected by chance.\n")
    L.append("## 4. Weight generation (once, at design time)\n")
    wo = weight_gen_ops("TFO", 1)
    L.append(f"- The product recursion needs per weight {wo['div']} division, {wo['add']} addition and {wo['mul']} "
             "multiplication (constants r = e^(-lambda h), c = (alpha+1) r combined once), plus one exp for TFO; FOEKF "
             "needs one more multiplication for the squared weights.")
    L.append(f"- Measured with vectorised numpy (wall, per call): TFO N_L = {Lb}: {wg[('TFO', Lb)]['wall_us_per_call']['median']:.1f} us; "
             f"N_L = {N}: {wg[('TFO', N)]['wall_us_per_call']['median']:.1f} us; FOEKF N_L = {Lb}: "
             f"{wg[('FOEKF', Lb)]['wall_us_per_call']['median']:.1f} us. This is negligible against one estimation run.\n")
    L.append("## 5. Cost of the certified memories\n")
    L.append(f"- **Frozen TFO (lambda = {', '.join(f'{v:g}' for v in lam)} s^-1) at eps_z = {100 * eps:.1f} % SOC:** "
             + "; ".join(f"T = {x['T']} C: L_cert = {x['L_s']:.0f} s, {x['ops']['memory_macs']} MACs/sample, "
                         f"{x['storage']['implemented']['bytes_f64'] / 1e3:.0f} kB implemented, "
                         f"{x['storage']['single_ring']['bytes_f64'] / 1e3:.0f} kB single ring, "
                         f"{x['storage']['minimal']['bytes_f32'] / 1e3:.0f} kB minimal float32 (with "
                         f"{x['storage']['minimal']['div_per_sample']} divisions per sample)" for x in cert) + ".")
    rmin, rmax = min(x["L_s"] for x in cert) / Lb, max(x["L_s"] for x in cert) / Lb
    lmin, lmax = min(x["L_s"] for x in cert), max(x["L_s"] for x in cert)
    L.append("- **Frozen FOO (untempered, same eps_z):** the certified horizon of cor:m4b:memory(iii) is finite but "
             "10^" + "/10^".join(f"{u['log10_L_s']:.1f}" for u in unt)
             + " s at 0/25/45 C, i.e. about as many MACs per sample and stored values, which cannot be implemented. "
             f"**Only with tempering is the certified horizon of practical size** ({lmin:.0f}-{lmax:.0f} s against "
             "10^" + f"{min(u['log10_L_s'] for u in unt):.0f}-10^{max(u['log10_L_s'] for u in unt):.0f} s untempered). "
             f"The certified memory still costs {rmin:.0f}-{rmax:.0f} times the primary budget of {Lb} s, and the "
             f"selected L = {Lb} s is not certified (reports/tuning_findings.md, decision 6 and section 2).\n")
    L.append("## 6. Microcontroller context (cited numbers only)\n")
    L.append("- No cited source in References.bib gives a per-sample time budget, clock rate or RAM size that has been "
             "checked against its full text. `cheng2026embedded` is recorded in `reports/literature_comparison.json` "
             "with a RAM class for target BMS microcontrollers taken from a web snippet only; it is not used here for "
             "any fit or exceed statement. `oehler2022embedded` (embedded real-time EKF with an electrochemical model) "
             "has no entry in `literature_comparison.json` and its full text was not read, so its timing and memory "
             "figures are unknown to us, not absent. `wan2024embedded` timed a moving-horizon estimator on a Raspberry "
             "Pi 4B, which is not a BMS microcontroller; no number is quoted.")
    L.append("- **Real-time feasibility and memory fit on a specific MCU are NOT demonstrated.** Only operation and "
             "storage counts are given (Section 2, Table 7, Figure 8b).\n")
    L.append("## 7. Cautious conclusions\n")
    L.append(f"1. At the frozen L = {Lb} s, TFO and FOO have identical per-sample operation counts (N_L + O(1); "
             f"{o_t['total_flops']} flops, {st('TFO', Lb) / 1e3:.1f} kB implemented, "
             f"{st('TFO', Lb, 'single_ring') / 1e3:.1f} kB single ring). Tempering gives no cost advantage at a fixed "
             "memory. Its cost-relevant effect is that the certified truncation horizon becomes of practical size.")
    L.append(f"2. FOEKF needs about twice the memory work and storage of TFO/FOO at equal L. The 2RC EKF and AEKF need "
             f"{o_e['total_flops']}-{o_a['total_flops']} flops and {st('EKF2RC', '-'):.0f}-{st('AEKF2RC', '-'):.0f} bytes: "
             f"the arithmetic gap is modest at L = 50 s (factor {g[('TFO', '50')]['ops']['total_flops'] / o_a['total_flops']:.1f}"
             f"-{g[('TFO', '50')]['ops']['total_flops'] / o_e['total_flops']:.1f}) and grows linearly with L; the "
             f"storage ratio is {st('TFO', 50) / st('AEKF2RC', '-'):.0f}-{st('TFO', 50) / st('EKF2RC', '-'):.0f}x at "
             f"L = 50 s and {st('TFO', Lb) / st('AEKF2RC', '-'):.0f}-{st('TFO', Lb) / st('EKF2RC', '-'):.0f}x at "
             f"L = {Lb} s.")
    L.append("3. Desktop CPython times are dominated by interpreter overhead at the horizons used here; the memory term "
             + (f"is small but clearly non-zero ({ft['slope_ns_per_history_sample']:.2f} ns per history sample for TFO, "
                f"95 % CI {ci(ft['slope_ci95_ns'])}) and would dominate at the certified horizons. "
                if ft["slope_ci95_ns"][0] > 0 else
                f"is not resolved for TFO (95 % CI {ci(ft['slope_ci95_ns'])} ns per history sample). ")
             + "Every method runs far faster than real time on this PC; this "
             "says nothing quantitative about MCU execution time.")
    L.append(f"4. The certified TFO memories ({lmin:.0f}-{lmax:.0f} samples) are {rmin:.0f}-{rmax:.0f} times the budget. "
             f"A compact storage layout exists only at {cert[0]['storage']['minimal']['total_flops_per_sample'] / cert[0]['ops']['total_flops']:.1f}x "
             "the per-sample arithmetic including N_L divisions, and "
             "neither storage fit nor real-time feasibility on a BMS microcontroller is shown.")
    L.append(f"\nRuntime of the measurement: wall {res['runtime']['wall_s']:.0f} s, process "
             f"{res['runtime']['process_s']:.0f} s (1 process, no workers).\n")
    L += review_response(res, sx, fm, g, Lb, N)
    REP.mkdir(exist_ok=True)
    (REP / "cost_findings.md").write_text("\n".join(L), encoding="utf-8")


def review_response(res, sx, fm, g, Lb, N):
    """'Review response' section (two reviews of E4); every number read from results/cost.json."""
    ft, ff = res["linear_fit"]["TFO_cpu"], res["linear_fit"]["FOEKF_cpu"]
    lv = [x for x in sx["lean_vs_TFO"] if x["clock"] == "cpu" and str(x["L"]) == str(Lb)][0]
    xm = layout_extra_ops("TFO", Lb, "minimal")
    pc = [p for p in sx["paired_TFO_minus_FOO"] if p["clock"] == "cpu"]
    st = lambda m, L, lay="implemented": g[(m, str(L))]["storage"][lay]["bytes_f64"]  # noqa: E731
    R = ["## Review response\n",
         "Two reviews (verdicts: major issues; minor issues) were checked on the merits. All issues were judged valid "
         "and fixed. The measurement was re-run end to end with the revised script (validation files only, no "
         "hyper-parameter changed, `results/frozen_config.json` untouched); every number above comes from the new "
         "`results/cost.json`.\n",
         f"1. **Full-memory FOEKF is a fixed N window, not a growing sum (both reviews; valid).** Confirmed in "
         f"`benchmarks._run_foekf` (N_L = N, zero-padded ring). The report, Table 7 (footnotes a/b; the '<=' is "
         f"removed; FOEKF full = {g[('FOEKF', 'full')]['ops']['full_memory_sum']['macs_every_step']} MACs at every "
         f"step) and Figure 8a ('full' drawn as a separate category) now state this. A growing-sum FOEKF "
         f"(FOEKF_grow, same estimates up to max |dz| = {res['checks']['FOEKF_grow_max_abs_zhat_diff']:.1e}) was "
         f"timed for a like-for-like comparison: {fm['FOEKF_grow']['cpu_median_us']:.2f} us against "
         f"{fm['FOEKF']['cpu_median_us']:.2f} us as implemented and {fm['TFO']['cpu_median_us']:.2f} us for TFO. The "
         "shared benchmark code was not changed (other experiments use it).",
         f"2. **Operation price of the minimal layout (both reviews; valid).** Per-layout operation counts were added "
         f"(`layout_extra_ops`, `analytic.grid[*].storage[*].extra_ops_per_sample`): the minimal layout adds "
         f"{xm['div']} divisions, {xm['mul']} multiplications and {xm['add']} additions per sample at L = {Lb} s (the "
         "combined-constant recursion needs one multiplication per weight, not two). Sections 2, 5, 6 and conclusion 4, "
         "the Table 7 caption and the Figure 8b legend now state the trade. The MCU 'would fit' statement was removed. "
         "Recommended wording for `rem:m4b:cost` (manuscript file not owned by E4, so not edited here): '..., or N_L "
         "numbers if the weights are regenerated at each step, at the price of N_L further divisions, multiplications "
         "and additions per sample (or N_L stored reciprocals 1/j, which cancels the saving)'.",
         f"3. **Slope uncertainty and 'nearly free/flat' (review A; valid).** Bootstrap CIs are now reported (TFO "
         f"{ft['slope_ns_per_history_sample']:.2f} ns [{ft['slope_ci95_ns'][0]:.2f}, {ft['slope_ci95_ns'][1]:.2f}], "
         f"FOEKF {ff['slope_ns_per_history_sample']:.2f} ns [{ff['slope_ci95_ns'][0]:.2f}, {ff['slope_ci95_ns'][1]:.2f}]), "
         "together with a fit on the minima and the extrapolation to the certified horizons. The wording now says "
         "that interpreter overhead dominates only at short horizons.",
         f"4. **Unused dU/dz and diagnostic output in the timed TFO loop (both reviews; valid).** The TFO_lean variant "
         f"(value-only OCV, no one-step-ahead output, bitwise-identical zhat: {res['checks']['TFO_lean_bitwise_identical']}) "
         f"was timed on the whole grid: {100 * lv['rel_diff']:+.0f} % CPU at L = {Lb} s. It appears in Table 7 "
         "(footnote c) and Figure 8a. The operation counts are now described as those of an idealised embedded "
         "implementation (script docstring, report).",
         f"5. **Uniform 8-scalar allowance (both reviews; valid).** The fixed scalars are now derived per method from "
         f"the recursions (`SCALARS`, stored in `analytic.scalars`): TFO/FOO {len(SCALARS['TFO'])}, FOEKF "
         f"{len(SCALARS['FOEKF'])}, EKF {len(SCALARS['EKF2RC'])}, AEKF {len(SCALARS['AEKF2RC'])}, CC {len(SCALARS['CC'])}; "
         f"EKF/AEKF/CC state is {st('EKF2RC', '-'):.0f}/{st('AEKF2RC', '-'):.0f}/{st('CC', '-'):.0f} bytes. The "
         "implementation's convention is kept only as a separate consistency check.",
         "6. **'A certified finite memory exists only with tempering' (review A; valid).** Reworded: the untempered "
         "horizon of cor:m4b:memory(iii) is finite but of impractical size; tempering makes it practical (Sections 5, 7).",
         "7. **Machine description and load (both reviews; valid).** `results/machine.json` now records the hybrid "
         "core layout (from Windows CPU-set efficiency classes), that the reported clock is the base clock, that "
         "affinity was not pinned, RAM in GiB (`ram_total_GiB`), and the load per repeat. The IQR/median range and a "
         "caution on absolute values are in Section 1 and the Table 7 caption. Pinning was not used, because other "
         "analyses shared the machine.",
         "8. **MCU number from a web snippet; kB vs KB; oehler2022embedded not read (both reviews; valid).** The "
         "512 KB bullet and every fit/exceed statement were removed. Section 6 now says that no checked MCU budget is "
         "available and that oehler2022embedded was not read.",
         f"9. **TFO vs FOO without a paired analysis (review A; valid).** Round-paired differences with bootstrap CIs "
         f"and Wilcoxon p are in `statistics.paired_TFO_minus_FOO`; {sum(p['ci_excludes_0'] for p in pc)} of "
         f"{len(pc)} CIs exclude 0 (signs: "
         + (", ".join("+" if p["median_diff_us"] > 0 else "-" for p in pc if p["ci_excludes_0"]) or "none")
         + "); see Section 3.",
         "10. **Remark vs table layout; overlapping labels (review A; valid).** Table 7 has a single-ring column "
         "(the 2N_L layout of rem:m4b:cost). The reference-line labels in Figure 8 are staggered, and each storage "
         "reference line is labelled.",
         "11. **Process-time quantisation (review B; valid).** The quantum tick/(B N) is stored per record and stated "
         "in Section 1. Equal medians are not interpreted.",
         "12. **Conclusion 2 overstated (review B; valid).** It now gives the flop ratio at L = 50 s (modest, growing "
         "linearly with L) and the storage ratios at L = 50 s and at the budget.",
         "13. **Code-hash traceability and in-place rewrite of cost.json (review B; valid).** The measured script is "
         f"archived (`{res['archived_script']}`). `--outputs` no longer rewrites `results/cost.json`: the figure "
         "arrays and the outputs hash go to `results/cost_outputs.json`.",
         "14. **zhat hashes not stored (review B; valid).** `zhash` is stored in every timing record.",
         "15. **Hand-typed numbers (review B; valid).** lambda (frozen_config), eps_z (config "
         "design_tuning.eps_z_primary), the N_L + O(1) overhead (tempered.cost_per_sample) and the storage formulas "
         "(from `storage_values`) are now read or computed, not typed.\n",
         f"Runtime of the re-run: wall {res['runtime']['wall_s']:.0f} s, process {res['runtime']['process_s']:.0f} s, "
         "1 process.\n"]
    return R


# ---------------------------------------------------------------------------------------------------------------
def main():
    global OUT_RES, TAB, FIG, REP
    ap = argparse.ArgumentParser()
    ap.add_argument("--outputs", action="store_true", help="regenerate table/figure/report from results/cost.json")
    ap.add_argument("--quick", default=None, help="smoke test: 2 short repeats, all outputs written to this directory")
    args = ap.parse_args()
    if args.quick:
        OUT_RES = TAB = FIG = REP = Path(args.quick)
        OUT_RES.mkdir(parents=True, exist_ok=True)
    if args.outputs:
        with open(OUT_RES / "cost.json", encoding="utf-8") as fh:
            outputs(json.load(fh))
        return
    t_c0, t_w0 = time.process_time(), time.perf_counter()
    cfg = D.load_config()
    cs = cfg["cost_study"]
    if args.quick:
        cs = dict(cs, repeats=2, target_repeat_s=0.02, weight_gen=dict(repeats=2, target_batch_s=0.01),
                  bootstrap=dict(cs["bootstrap"], n_boot=50))
    frozen = load_json("frozen_config.json")
    if not str(frozen.get("status", "")).startswith("FROZEN"):
        raise RuntimeError("results/frozen_config.json is not frozen")
    code_hash = hashlib.sha1(Path(__file__).read_bytes()).hexdigest()[:16]
    if not args.quick:                                        # archive the measured script version
        (RES / "archive").mkdir(exist_ok=True)
        shutil.copyfile(Path(__file__), RES / "archive" / f"08_cost_{code_hash}.py")
    machine = machine_info()
    load = [machine_load()]
    cfgs, T_grid = build_configs(cs, frozen)
    N_run = cfgs[0]["case"].I.size - 1
    print(f"{len(cfgs)} configurations, N = {N_run} samples", flush=True)
    meas, trace = measure(cs, cfgs)
    load.append(machine_load())
    N_list = sorted({int(math.ceil(float(L))) for L in cs["L_grid_s"] if L != "full"} | {N_run}
                    | {int(math.ceil(float(a["L_cert_s"]))) for a in frozen["ablation_memory_TFO"].values()})
    wgen = weight_generation(cs, frozen, T_grid, N_list)
    load.append(machine_load())
    pt = [x["cpu_percent"] for x in trace["per_repeat"]]
    la = [x["loadavg_1min"] for x in trace["per_repeat"]]
    machine["load_during_timing"] = dict(
        cpu_percent_per_repeat_range=[min(pt), max(pt)] if pt else None,
        cpu_percent_per_repeat_median=float(np.median(pt)) if pt else None,
        loadavg_1min_range=[min(la), max(la)] if la else None,
        note="system-wide, other analyses running concurrently; not controlled (see results/cost.json load_trace)")
    with open(OUT_RES / "machine.json", "w", encoding="utf-8") as fh:
        json.dump(dict(generated_utc=_utc(), script="scripts/08_cost.py", code_hash=code_hash, **machine), fh, indent=1)
    fit = linear_fit(meas, cs, N_run)
    res = dict(generated_utc=_utc(), script="scripts/08_cost.py", code_hash=code_hash,
               archived_script=f"results/archive/08_cost_{code_hash}.py", settings=cs,
               description=__doc__.strip().splitlines()[0], timing_T=T_grid, N_run=N_run,
               memory_budget_primary_s=frozen["memory_budget_primary_s"],
               validation_files=[cs["timing_file"]] + list(cs["frozen_check_files"]), test_files_loaded=[],
               machine_ref="results/machine.json", machine_load=load, load_trace=trace,
               clock_note=("cpu = time.process_time (this process), wall = time.perf_counter, both summed over the "
                           "in-loop readings of the B runs of a repeat and divided by B N (process_time readings are "
                           "quantised at tick/(B N), stored per record); median/IQR/min over repeats; desktop "
                           "CPython, NOT embedded; affinity not pinned (hybrid CPU, see machine.json)"),
               op_count_convention=dict(steps=_STEPS, ocv_value=OCV_VALUE, ocv_derivative_extra=OCV_DERIV_EXTRA,
                                        note="idealised embedded implementation: per sample n >= 1, constants "
                                             "precomputed, value-only OCV where dU/dz is not needed; memory sums as "
                                             "MACs; per-layout extra operations in analytic.grid[*].storage"),
               timing=meas, linear_fit=fit, statistics=statistics(meas, cs, frozen, T_grid, N_run, fit),
               weight_generation=wgen, analytic=analytic_rows(cs, frozen, N_run),
               checks=dict(all_deterministic=all(r["deterministic"] for r in meas),
                           bytes_rule_matches_implementation=all(r["storage_check"]["matches_bytes_state"] for r in meas),
                           TFO_lean_bitwise_identical=all(r["equivalence"]["bitwise_identical"] for r in meas
                                                          if r["method"] == "TFO_lean"),
                           FOEKF_grow_max_abs_zhat_diff=max(r["equivalence"]["max_abs_zhat_diff"] for r in meas
                                                            if r["method"] == "FOEKF_grow")),
               runtime=dict(wall_s=time.perf_counter() - t_w0, process_s=time.process_time() - t_c0, workers=1))
    with open(OUT_RES / "cost.json", "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1)
    outputs(res)
    print("wrote cost.json, machine.json, cost_outputs.json, tab_cost.tex, fig_cost_memory.pdf, cost_findings.md",
          flush=True)


if __name__ == "__main__":
    main()
