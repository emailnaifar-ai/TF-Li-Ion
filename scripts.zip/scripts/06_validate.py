"""E1: main test-set comparison of the frozen estimators (18 SP2 FUDS/US06/BJDST test files x 3 initial-SOC scenarios).

Every hyper-parameter and parameter set comes from results/frozen_config.json (status FROZEN, written by
scripts/05_design_tune.py on the validation files only); nothing is tuned or selected here.  Settings: config.yaml
`validation_main` (declared before the first test run), `estimators`, `identification_refined`, `identification_study`.
Test files are loaded only through experiments.load_case(..., allow_splits=('test',), final_evaluation=True), which
calls data.verify_file.  Clean measured signals (no corruption).

Outputs (all numbers, tables and figures are regenerated from the first two):
  results/validation_main.json    per-run metrics (whole / admissible windows, with and without t >= 600 s), paired
                                  differences TFO - benchmark, Q_ref +- u_Q sensitivity, convergence-tail fits,
                                  open-loop voltage-model accuracy, certificates of the full-memory variants, runtime
  results/validation_series.npz   every plotted array (SOC estimates, reference and band, |e| envelopes, fitted tails,
                                  measured / modelled voltages, residual ACFs)
  tables/tab_soc_results.tex, figures/fig_soc_test.pdf, fig_error_envelopes.pdf, fig_vt_model.pdf, fig_resid_acf.pdf,
  reports/validation_main_findings.md

Usage: python scripts/06_validate.py [--report-only]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import identify as ID  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES = ROOT / "results"
FIG = ROOT / "figures"
TAB = ROOT / "tables"
REP = ROOT / "reports"
TEMPS = (0, 25, 45)
PROFILES = ("FUDS", "US06", "BJDST")
# evaluated method -> (frozen entry, estimator, memory override)
METHODS = {"TFO": ("TFO", "TFO", None), "FOO": ("FOO", "FOO", None), "FOO_full": ("FOO", "FOO", "full"),
           "TFO_full": ("TFO", "TFO", "full"), "FOEKF": ("FOEKF", "FOEKF", None),
           "EKF2RC": ("EKF2RC", "EKF2RC", None), "AEKF2RC": ("AEKF2RC", "AEKF2RC", None), "CC": ("CC", "CC", None)}
VM_FAMS = ("TFO", "FO", "2RC")
TASK_VERSION = "E1-2026-09-27-b-review1"
# supplementary / diagnostic methods added after the review (config validation_main.review_round_1; post hoc, frozen
# entries only, nothing selected from them)
SUPP = tuple(D.load_config()["validation_main"]["review_round_1"]["supplementary_methods"])
ALL_METHODS = tuple(METHODS) + SUPP
L1_METHODS = ("TFO", "FOO", "TFO_full", "FOO_full", "TFO_L1600", "FOO_L1600", "TFO_lam0", "FOO_lam1e-4")


# ---------------------------------------------------------------------------------------------------------------
# Configuration, freeze guard
# ---------------------------------------------------------------------------------------------------------------
def cfg():
    c = D.load_config()
    return c, dict(c["validation_main"]), dict(c["estimators"])


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def frozen():
    fz = load_json("frozen_config.json")
    if not str(fz.get("status", "")).startswith("FROZEN") or fz.get("frozen_utc") is None:
        raise PermissionError("results/frozen_config.json is not FROZEN: test evaluation refused")
    return fz


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def code_hash() -> str:
    c, vm, est = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([vm, est], sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("scripts/06_validate.py", "src/tfso/observer.py", "src/tfso/benchmarks.py", "src/tfso/experiments.py",
              "src/tfso/metrics.py", "src/tfso/model.py", "results/frozen_config.json",
              "results/identification_refined.json", "results/capacity.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def admissible():
    return tuple(float(x) for x in D.load_config()["identification_refined"]["admissible_soc_interval"])


_OCV = {}


def aligned_ocv(T):
    if T not in _OCV:
        _OCV[T] = MD.AlignedOCV(int(T), E.q_id(int(T)))
    return _OCV[T]


def method_spec(fz, name, T):
    if name in METHODS:
        entry, est, mem = METHODS[name]
        e = fz["methods"][entry]["per_T"][str(T)]
        p = dict(e["params"])
        hy = dict(e.get("hyper", {}))
        if mem == "full":
            hy["L_s"] = None
            hy.pop("N_L", None)
        return est, p, hy
    sm = D.load_config()["validation_main"]["review_round_1"]["supplementary_methods"][name]
    sec, entry = sm["source"].split(".")
    e = fz[sec][entry]["per_T"][str(T)]
    p = dict(e["params"])
    p.update(sm.get("params", {}))
    hy = dict(e.get("hyper", {}))
    hy.update(sm.get("hyper", {}))
    return sm["estimator"], p, hy


# ---------------------------------------------------------------------------------------------------------------
# Metrics on the declared windows
# ---------------------------------------------------------------------------------------------------------------
def conv_time_masked(t, e, mask, band):
    """Time (from the profile start t[0]) after which |e| <= band on every masked sample until the end; inf if the last
    masked sample is outside; 0 if none is outside."""
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return float("nan")
    out = ~(np.abs(e[idx]) <= band)
    if not out.any():
        return 0.0
    m = int(np.flatnonzero(out)[-1])
    if m == idx.size - 1:
        return math.inf
    return float(t[idx[m + 1]] - t[0])


def window_metrics(t, e, zref, Vtp, V, est):
    band = float(D.load_config()["validation"]["error_band_convergence"])
    bands = [float(b) for b in est["within_bands"]]
    tpost = float(est["post_convergence_t_s"])
    lo, hi = admissible()
    post = (t - t[0]) >= tpost
    adm = (zref >= lo) & (zref <= hi)
    out = {}
    for w, m in (("whole", np.ones_like(post)), ("whole_post", post), ("adm", adm), ("adm_post", adm & post)):
        ee = e[m]
        if ee.size == 0:
            continue
        a = np.abs(ee)
        out[f"{w}_rmse_pct"] = float(100 * np.sqrt(np.mean(ee * ee)))
        out[f"{w}_mae_pct"] = float(100 * np.mean(a))
        out[f"{w}_maxabs_pct"] = float(100 * np.max(a))
        out[f"{w}_bias_pct"] = float(100 * np.mean(ee))
        for b in bands:
            out[f"{w}_within{int(round(100 * b))}_pct"] = float(100 * np.mean(a <= b))
        out[f"{w}_n"] = int(ee.size)
        if Vtp is not None:
            ev = (np.asarray(Vtp) - V)[m]
            out[f"{w}_vt_rmse_mV"] = float(1e3 * np.sqrt(np.mean(ev * ev)))
        else:
            out[f"{w}_vt_rmse_mV"] = float("nan")
    out["whole_conv_time_s"] = conv_time_masked(t, e, np.ones_like(post), band)
    out["adm_conv_time_s"] = conv_time_masked(t, e, adm, band)
    # post hoc diagnostic (added after the first test run; reported only): first entry into the band
    for w, m in (("whole", np.ones_like(post)), ("adm", adm)):
        ii = np.flatnonzero(m & (np.abs(e) <= band))
        out[f"{w}_first_entry_s"] = float(t[ii[0]] - t[0]) if ii.size else math.inf
    out["frac_admissible"] = float(adm.mean())
    return out


# ---------------------------------------------------------------------------------------------------------------
# Convergence-tail fit  log|e| = c - lambda_eff t - rho log t
# ---------------------------------------------------------------------------------------------------------------
def tail_window(t, y, t0, tmax, stop, sign_change):
    """[i0, i1) window: from t >= t0 until the first |y| <= stop, the first sign change of y (if requested) or t > tmax."""
    i0 = int(np.searchsorted(t, t0 - 1e-9))
    if i0 >= t.size:
        return i0, i0, "record too short"
    if abs(y[i0]) <= stop:
        return i0, i0, "|e| <= e_stop at t_start"
    s0 = np.sign(y[i0])
    i1 = t.size
    reason = "end of record"
    for k in range(i0, t.size):
        if t[k] > tmax:
            i1, reason = k, "t_max"
            break
        if abs(y[k]) <= stop:
            i1, reason = k, "|e| <= e_stop"
            break
        if sign_change and np.sign(y[k]) != s0:
            i1, reason = k, "sign change"
            break
    return i0, i1, reason


def tail_fit(t, y, t0, tmax, stop, sign_change, min_n, hac_lags):
    import statsmodels.api as sm
    i0, i1, reason = tail_window(t, y, t0, tmax, stop, sign_change)
    n = i1 - i0
    out = dict(n=int(n), t_from_s=float(t[i0]) if i0 < t.size else None,
               t_to_s=float(t[i1 - 1]) if n > 0 else None, window_end=reason, fitted=False)
    if n < min_n:
        out["reason"] = f"fewer than {min_n} samples in the window ({reason})"
        return out
    tt, ly = t[i0:i1], np.log(np.abs(y[i0:i1]))
    X = np.column_stack([np.ones(n), -tt, -np.log(tt)])
    r = sm.OLS(ly, X).fit(cov_type="HAC", cov_kwds={"maxlags": int(hac_lags)})
    ci = r.conf_int(0.05)
    cov = r.cov_params()
    corr = float(cov[1, 2] / math.sqrt(cov[1, 1] * cov[2, 2])) if cov[1, 1] > 0 and cov[2, 2] > 0 else float("nan")
    r_exp = sm.OLS(ly, X[:, :2]).fit()
    r_alg = sm.OLS(ly, X[:, [0, 2]]).fit()
    out.update(fitted=True, c=float(r.params[0]), lambda_eff=float(r.params[1]), rho=float(r.params[2]),
               lambda_eff_ci=[float(ci[1, 0]), float(ci[1, 1])], rho_ci=[float(ci[2, 0]), float(ci[2, 1])],
               r2=float(r.rsquared), corr_lambda_rho=corr, r2_exponential_only=float(r_exp.rsquared),
               lambda_exp_only=float(r_exp.params[1]), r2_algebraic_only=float(r_alg.rsquared),
               rho_alg_only=float(r_alg.params[1]), e_start=float(abs(y[i0])), e_end=float(abs(y[i1 - 1])))
    return out


def tail_curve(fit, t):
    return np.exp(fit["c"] - fit["lambda_eff"] * t - fit["rho"] * np.log(t))


def kcontrol_fit(t, y, K, t0, tmax, stop, sign_change, hac_lags):
    """Review round 1: the declared incremental window refitted with the linearised loop rate as regressor,
    log|y| = c - g K(t) - rho log t, K(t) = int_0^t l1 U'(zhat_nominal) ds.  g ~ 1 and rho ~ 0 mean that the decay is
    the state-dependent exponential rate l1 U'(z(t)) and no algebraic factor is identifiable."""
    import statsmodels.api as sm
    i0, i1, _ = tail_window(t, y, t0, tmax, stop, sign_change)
    tt, ly, KK = t[i0:i1], np.log(np.abs(y[i0:i1])), K[i0:i1]
    X = np.column_stack([np.ones(tt.size), -KK, -np.log(tt)])
    r = sm.OLS(ly, X).fit(cov_type="HAC", cov_kwds={"maxlags": int(hac_lags)})
    ci = r.conf_int(0.05)
    rk = sm.OLS(ly, X[:, :2]).fit()
    return dict(g=float(r.params[1]), g_ci=[float(ci[1, 0]), float(ci[1, 1])], rho=float(r.params[2]),
                rho_ci=[float(ci[2, 0]), float(ci[2, 1])], r2=float(r.rsquared), r2_K_only=float(rk.rsquared),
                g_K_only=float(rk.params[1]))


# ---------------------------------------------------------------------------------------------------------------
# One test file: every method x scenario, Q_ref sensitivity, tail fits, open-loop voltage models
# ---------------------------------------------------------------------------------------------------------------
def voltage_models(lid, T, df, soc_ref):
    c = D.load_config()
    s = c["identification_study"]
    Q = E.q_id(T)
    H = MD.build_history(lid, Q, h=float(s["h_s"]), df=df)
    ocv = MD.AlignedOCV(T, Q, extrapolation=s["ocv_extrapolation"])
    g = MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    J = load_json("identification_refined.json")
    sets = J["chosen_parameter_sets"][str(T)]
    acc_ref = J["accuracy"].get(lid, {}).get("causal_full", {})
    lo, hi = admissible()
    adm = (soc_ref >= lo) & (soc_ref <= hi)
    kz = float(s["knee_window"]["z_min"])
    knee = H.z[H.prof] >= kz
    max_lag = int(c["validation_main"]["voltage_models"]["acf_max_lag_s"] / H.h)
    stats, arrays = {}, {"V_meas": H.V[H.prof].astype(np.float32), "t_V": H.t[H.prof].astype(np.float32)}
    for fam in VM_FAMS:
        th = sets[fam]
        if fam == "2RC":
            P = MD.TwoRCParams(th["R0"], th["R1"], th["tau1"], th["R2"], th["tau2"], th["s"], th["dq"])
        else:
            P = MD.TFOParams(th["alpha"], th.get("lam", 0.0), th["R0"], th["Rp"], th["Cp"], th["s"], th["dq"])
        sim = MD.simulate(P, H, ocv, method="fft", grid=None if fam == "2RC" else g, window=H.prof, timing="causal")
        r = sim["Vt"] - H.V[H.prof]
        st, acf = ID.residual_stats(r, int(s["accuracy"]["ljung_box_lags"]), s["accuracy"]["quantiles"], max_lag)
        st["rmse_admissible_mV"] = float(np.sqrt(np.mean(r[adm] ** 2)) * 1e3)
        st["rmse_z_ge_knee_mV"] = float(np.sqrt(np.mean(r[knee] ** 2)) * 1e3)
        ref = acc_ref.get(fam, {}).get("rmse_mV")
        st["rmse_mV_identification_refined_json"] = ref
        st["consistency_abs_diff_mV"] = None if ref is None else float(abs(ref - st["rmse_mV"]))
        stats[fam] = st
        arrays[f"Vt_{fam}"] = sim["Vt"].astype(np.float32)
        arrays[f"acf_{fam}"] = np.asarray(acf, np.float32)
    return stats, arrays


def file_task(lid):
    t0w, t0c = time.perf_counter(), time.process_time()
    c, vm, est = cfg()
    fz = frozen()
    assert lid in c["splits"]["test_dynamic"], lid
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)     # data.verify_file inside
    if not case.meta["verify_passed"]:
        raise RuntimeError(f"{lid} failed data.verify_file")
    T = case.T
    df = D.load_raw(lid)
    prof = D.get_dynamic_profile(lid, df=df)
    ref = D.reference_soc(lid, df=df, profile=prof)
    if np.max(np.abs(ref["soc_ref"] - case.soc_ref)) > 1e-12:
        raise RuntimeError("reference SOC mismatch")
    cap = load_json("capacity.json")["Q_ref_T_SP2"][str(T)]
    Qr, uQ = float(cap["Q_ref_Ah"]), float(cap["u_Q_Ah"])
    refs_q = {"Q_minus": D.reference_soc(lid, Q_ref_Ah=Qr - uQ, df=df, profile=prof)["soc_ref"],
              "Q_plus": D.reference_soc(lid, Q_ref_Ah=Qr + uQ, df=df, profile=prof)["soc_ref"],
              # review round 1: reference mapped to the estimators' charge axis (they integrate with Q_id)
              "obs_axis": 1.0 - (1.0 - case.soc_ref) * Qr / E.q_id(T)}
    rv = vm["review_round_1"]
    tf = vm["tail_fit"]
    t = case.t
    records, series, tails = [], {}, []
    zhat_nom = {}
    kcum = {}
    for sc in vm["scenarios"]:
        for name in ALL_METHODS:
            estm, p, hy = method_spec(fz, name, T)
            focv = O.as_fast_ocv(aligned_ocv(T), s=p["s"], dq=p["dq"]) if estm != "CC" else None
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                rec = E.run_case(estm, p, hy, case, z0_scenario=sc, ocv=focv, keep_series=True)
            sr = rec.pop("_series")
            zh = np.asarray(sr["zhat"], float)
            e = zh - case.soc_ref
            m = window_metrics(t, e, case.soc_ref, sr["Vt_prior"] if estm != "CC" else None, case.V, est)
            if abs(m["whole_rmse_pct"] - rec["rmse_pct"]) > 1e-9:
                raise RuntimeError("metric mismatch with metrics.soc_metrics")
            qs = {}
            for k, zr in refs_q.items():
                mq = window_metrics(t, zh - zr, zr, None, case.V, est)
                qs[k] = {kk: mq[kk] for kk in ("adm_post_rmse_pct", "whole_post_rmse_pct", "adm_post_maxabs_pct",
                                               "adm_post_bias_pct", "whole_post_bias_pct")}
            row = dict(method=name, role="primary" if name in METHODS else "supplementary", estimator=estm, file=lid, T=T, profile=case.profile, start_level=case.start_level,
                       scenario=sc, z0=rec["z0"], z_ref0=rec["z_ref0"], z0_error=rec["z0_error"], n_samples=int(t.size),
                       duration_s=float(t[-1] - t[0]), N_L_requested=rec["N_L_requested"], N_L_used=rec["N_L_used"],
                       full_memory=rec["full_memory"], cpu_process_s=rec["cpu_process_s"],
                       cpu_per_sample_us=rec["cpu_per_sample_us"], wall_s=rec["wall_s"],
                       wall_per_sample_us=rec["wall_per_sample_us"], n_history_samples=rec["n_history_samples"],
                       bytes_state=rec["bytes_state"], soc_clip_count=rec["soc_clip_count"], nonfinite=rec["nonfinite"],
                       positivity_ok=rec["positivity_ok"], n_outside_z_interval=rec["n_outside_z_interval"],
                       vt_apost_rmse_mV=rec["vt_apost_rmse_mV"], q_ref_sensitivity=qs, **m)
            records.append(row)
            series[f"zhat|{name}|{sc}"] = zh.astype(np.float32)
            if sc == "nominal":
                zhat_nom[name] = zh
                if name in L1_METHODS:      # loop-rate regressor K(t) = int l1 U'(zhat_nom) ds (review round 1)
                    k = float(hy["l1"]) * np.asarray(focv.dU(zh), float)
                    kcum[name] = np.concatenate([[0.0], np.cumsum(0.5 * (k[1:] + k[:-1]) * np.diff(t))])
                continue
            ew = rv["early_window_sensitivity"]
            variants = [("primary", float(tf["e_stop"]), float(tf["t_start_s"]), int(tf["min_samples"]))] +                 [(f"e_stop_{v:g}", float(v), float(tf["t_start_s"]), int(tf["min_samples"])) for v in tf["e_stop_sensitivity"]] +                 [("early_t10", float(tf["e_stop"]), float(ew["t_start_s"]), int(ew["min_samples"]))]
            for vkey, stop, tst, nmin in variants:
                fit = tail_fit(t, e, tst, float(tf["t_max_s"]), stop,
                               bool(tf["stop_on_sign_change"]), nmin, int(tf["hac_lags"]))
                tails.append(dict(kind="error", variant=vkey, e_stop=stop, method=name, file=lid, T=T,
                                  profile=case.profile, start_level=case.start_level, scenario=sc, **fit))
    for sc in vm["scenarios"]:
        if sc == "nominal":
            continue
        for name in ALL_METHODS:
            dlt = np.asarray(series[f"zhat|{name}|{sc}"], float) - zhat_nom[name]
            fit = tail_fit(t, dlt, float(tf["t_start_s"]), float(tf["t_max_s"]), float(tf["delta_stop"]),
                           bool(tf["stop_on_sign_change"]), int(tf["min_samples"]), int(tf["hac_lags"]))
            if name in kcum and fit["fitted"]:
                fit["kcontrol"] = kcontrol_fit(t, dlt, kcum[name], float(tf["t_start_s"]), float(tf["t_max_s"]),
                                               float(tf["delta_stop"]), bool(tf["stop_on_sign_change"]),
                                               int(tf["hac_lags"]))
            tails.append(dict(kind="incremental", variant="delta", e_stop=float(tf["delta_stop"]), method=name, file=lid,
                              T=T, profile=case.profile, start_level=case.start_level, scenario=sc, **fit))
    vstats, varr = voltage_models(lid, T, df, case.soc_ref)
    series.update(varr)
    series.update(t_soc=t.astype(np.float32), zref=case.soc_ref.astype(np.float32),
                  zref_lo=np.asarray(ref["soc_lo"], np.float32), zref_hi=np.asarray(ref["soc_hi"], np.float32),
                  zref_Qminus=refs_q["Q_minus"].astype(np.float32), zref_Qplus=refs_q["Q_plus"].astype(np.float32))
    info = dict(file=lid, T=T, profile=case.profile, start_level=case.start_level, split=case.split,
                verified=bool(case.meta["verify_passed"]), n_samples=int(t.size), duration_s=float(t[-1] - t[0]),
                z_ref0=case.z_ref0, z_ref_end=float(case.soc_ref[-1]), soc_band_end=case.meta["soc_band_end"],
                Q_ref_Ah=Qr, u_Q_Ah=uQ, loaded_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return dict(info=info, records=records, tails=tails, vmodels=vstats, series=series,
                wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)


# ---------------------------------------------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------------------------------------------
KEY_METRICS = ("adm_post_rmse_pct", "adm_rmse_pct", "whole_post_rmse_pct", "whole_rmse_pct", "adm_post_mae_pct",
               "whole_post_mae_pct", "adm_post_maxabs_pct", "whole_post_maxabs_pct", "whole_maxabs_pct",
               "whole_conv_time_s", "adm_conv_time_s", "whole_first_entry_s", "adm_first_entry_s", "adm_post_within1_pct", "adm_post_within2_pct",
               "whole_post_within1_pct", "whole_post_within2_pct", "adm_vt_rmse_mV", "whole_vt_rmse_mV",
               "cpu_per_sample_us", "wall_per_sample_us", "n_history_samples", "bytes_state",
               "adm_post_bias_pct", "whole_post_bias_pct", "soc_clip_count", "n_outside_z_interval")


def _f(v):
    return float("inf") if v == "inf" else (float("nan") if v in (None, "nan") else float(v))


def summarise(recs, keys=("method",)):
    import pandas as pd
    df = pd.DataFrame([{k: (r[k] if k in r else None) for k in ("method", "T", "profile", "scenario", "file",
                                                               "start_level") + KEY_METRICS} for r in recs])
    for k in KEY_METRICS:
        df[k] = df[k].map(_f)
    out = []
    for g, d in df.groupby(list(keys)):
        g = g if isinstance(g, tuple) else (g,)
        row = dict(zip(keys, [x.item() if hasattr(x, "item") else x for x in g]), n=int(len(d)))
        for k in KEY_METRICS:
            v = d[k].to_numpy(float)
            fin = v[np.isfinite(v)]
            row[f"{k}_mean"] = float(np.mean(v)) if np.all(np.isfinite(v)) else float("nan")
            row[f"{k}_median"] = float(np.median(v)) if not np.any(np.isnan(v)) else float("nan")
            row[f"{k}_n_inf"] = int(np.sum(np.isinf(v)))
            row[f"{k}_max_finite"] = float(np.max(fin)) if fin.size else float("nan")
            row[f"{k}_sum"] = float(np.sum(fin)) if fin.size else float("nan")
        out.append(row)
    return out


# supplementary paired metrics added after the first test run (reported as such; not part of the declared list)
SUPP_PAIRED = ("adm_conv_time_s", "adm_first_entry_s", "whole_first_entry_s")
# review round 1: the primary metric re-scored under Q_ref - u_Q, Q_ref + u_Q and on the observer charge axis
Q_PAIRED = ("adm_post_rmse_pct@Q_minus", "adm_post_rmse_pct@Q_plus", "adm_post_rmse_pct@obs_axis")


def contrasts(vm):
    ref = vm["paired"]["reference_method"]
    out = [(ref, c) for c in list(vm["paired"]["comparators"]) + list(SUPP)]
    out += [("FOO_lam1e-4", "FOO"), ("TFO_L1600", "FOO_L1600"), ("TFO_full", "FOO_full"), ("FOO", "FOO_L1600")]
    return out


def _val(r, met):
    """Metric value of one run; convergence/first-entry times never reached are censored at the file's own
    duration + h (review round 1; previously the global maximum duration)."""
    if "@" in met:
        k, q = met.split("@")
        v = _f(r["q_ref_sensitivity"][q][k])
    else:
        v = _f(r[met])
    if np.isinf(v) and met.endswith("_s"):
        return float(r["duration_s"]) + 1.0, True
    return v, bool(np.isinf(v))


def paired(recs, vm):
    """Paired differences d = metric(ref) - metric(comparator).  Review round 1: the FILE is the unit of inference.
    unit 'file': per-file mean over the 3 scenarios (groups all / T / profile; n = 18 / 6 / 6);
    unit 'scenario': one scenario at a time (n = 18 files); unit 'run': the 54 (file, scenario) pairs (descriptive
    only: the scenarios of one file are near-replicates after t = 600 s)."""
    idx = {(r["method"], r["file"], r["scenario"]): r for r in recs}
    finfo = {}
    for r in recs:
        finfo[r["file"]] = (r["T"], r["profile"])
    files = sorted(finfo)
    scen = list(vm["scenarios"])
    mets = list(vm["paired"]["metrics"]) + [m for m in SUPP_PAIRED if m not in vm["paired"]["metrics"]] + list(Q_PAIRED)
    fgroups = [("all", None)] + [(f"T={T}", (0, T)) for T in TEMPS] + [(f"profile={p}", (1, p)) for p in PROFILES]
    out = []
    for ref, comp in contrasts(vm):
        if (comp, files[0], scen[0]) not in idx:
            continue
        for met in mets:
            va = {(f, s): _val(idx[(ref, f, s)], met) for f in files for s in scen}
            vb = {(f, s): _val(idx[(comp, f, s)], met) for f in files for s in scen}
            if all(np.isnan(v[0]) for v in vb.values()):
                continue
            base = dict(reference=ref, comparator=comp, metric=met)
            for gname, g in fgroups:
                sel = [f for f in files if g is None or finfo[f][g[0]] == g[1]]
                a = [np.mean([va[(f, s)][0] for s in scen]) for f in sel]
                b = [np.mean([vb[(f, s)][0] for s in scen]) for f in sel]
                pdiff = MX.paired_difference(a, b)
                out.append(dict(base, unit="file", group=gname, n_never_ref=int(sum(va[(f, s)][1] for f in sel for s in scen)),
                                n_never_comp=int(sum(vb[(f, s)][1] for f in sel for s in scen)),
                                min_exact_wilcoxon_p=float(2.0 / 2 ** len(sel)), **pdiff))
            for s in scen:
                a = [va[(f, s)][0] for f in files]
                b = [vb[(f, s)][0] for f in files]
                pdiff = MX.paired_difference(a, b)
                out.append(dict(base, unit="scenario", group=f"scenario={s}", min_exact_wilcoxon_p=float(2.0 / 2 ** len(files)),
                                **pdiff))
            a = [va[(f, s)][0] for f in files for s in scen]
            b = [vb[(f, s)][0] for f in files for s in scen]
            out.append(dict(base, unit="run", group="all", **MX.paired_difference(a, b)))
    return out


def q_sensitivity(recs):
    out = []
    for m, Tg in [(m, Tg) for m in ALL_METHODS for Tg in ("all",) + TEMPS]:
        rr = [r for r in recs if r["method"] == m and (Tg == "all" or r["T"] == Tg)]
        row = dict(method=m, T=Tg, n=len(rr))
        for key in ("adm_post_rmse_pct", "whole_post_rmse_pct", "adm_post_bias_pct"):
            base = np.array([r[key] for r in rr], float)
            row[f"{key}_Q_ref_mean"] = float(np.mean(base))
            row[f"{key}_Q_ref_median"] = float(np.median(base))
            for q in ("Q_minus", "Q_plus", "obs_axis"):
                v = np.array([r["q_ref_sensitivity"][q][key] for r in rr], float)
                row[f"{key}_{q}_mean"] = float(np.mean(v))
                row[f"{key}_{q}_median"] = float(np.median(v))
        out.append(row)
    return out


def _med_ci_count(fit, key):
    v = np.array([t[key] for t in fit])
    return float(np.median(v)), float(np.quantile(v, .25)), float(np.quantile(v, .75))


def tail_summary(tails):
    out = []
    kinds = sorted({(t["kind"], t["variant"]) for t in tails})
    for kind, var in kinds:
        for m in ALL_METHODS:
            for Tg in ("all",) + TEMPS:
                rr = [t for t in tails if t["kind"] == kind and t["variant"] == var and t["method"] == m
                      and (Tg == "all" or t["T"] == Tg)]
                fit = [t for t in rr if t["fitted"]]
                row = dict(kind=kind, variant=var, method=m, T=Tg, n_runs=len(rr), n_fitted=len(fit))
                if fit:
                    lam = np.array([t["lambda_eff"] for t in fit])
                    rho = np.array([t["rho"] for t in fit])
                    row.update(lambda_eff_median=float(np.median(lam)), lambda_eff_q25=float(np.quantile(lam, .25)),
                               lambda_eff_q75=float(np.quantile(lam, .75)), rho_median=float(np.median(rho)),
                               rho_q25=float(np.quantile(rho, .25)), rho_q75=float(np.quantile(rho, .75)),
                               n_lambda_ci_gt0=int(sum(t["lambda_eff_ci"][0] > 0 for t in fit)),
                               n_lambda_ci_lt0=int(sum(t["lambda_eff_ci"][1] < 0 for t in fit)),
                               n_rho_ci_gt0=int(sum(t["rho_ci"][0] > 0 for t in fit)),
                               n_rho_ci_lt0=int(sum(t["rho_ci"][1] < 0 for t in fit)),
                               r2_median=float(np.median([t["r2"] for t in fit])),
                               r2_exp_only_median=float(np.median([t["r2_exponential_only"] for t in fit])),
                               r2_alg_only_median=float(np.median([t["r2_algebraic_only"] for t in fit])),
                               corr_lambda_rho_median=float(np.median([t["corr_lambda_rho"] for t in fit])),
                               window_s_median=float(np.median([t["t_to_s"] - t["t_from_s"] + 1 for t in fit])),
                               window_s_min=float(np.min([t["t_to_s"] - t["t_from_s"] + 1 for t in fit])),
                               window_s_max=float(np.max([t["t_to_s"] - t["t_from_s"] + 1 for t in fit])))
                    kc = [t["kcontrol"] for t in fit if "kcontrol" in t]
                    if kc:
                        row.update(kc_n=len(kc), kc_g_median=float(np.median([k["g"] for k in kc])),
                                   kc_rho_median=float(np.median([k["rho"] for k in kc])),
                                   kc_rho_q25=float(np.quantile([k["rho"] for k in kc], .25)),
                                   kc_rho_q75=float(np.quantile([k["rho"] for k in kc], .75)),
                                   kc_n_rho_ci_gt0=int(sum(k["rho_ci"][0] > 0 for k in kc)),
                                   kc_n_rho_ci_lt0=int(sum(k["rho_ci"][1] < 0 for k in kc)),
                                   kc_r2_median=float(np.median([k["r2"] for k in kc])),
                                   kc_r2_K_only_median=float(np.median([k["r2_K_only"] for k in kc])))
                out.append(row)
    return out


def failures(recs, thr):
    """Runs with admissible post RMSE above thr (% SOC), per method (review round 1)."""
    out = [dict(method=r["method"], file=r["file"], T=r["T"], profile=r["profile"], scenario=r["scenario"],
                adm_post_rmse_pct=r["adm_post_rmse_pct"], soc_clip_count=r["soc_clip_count"])
           for r in recs if _f(r["adm_post_rmse_pct"]) > thr]
    return sorted(out, key=lambda x: (x["method"], -x["adm_post_rmse_pct"]))


def timing_task(lid):
    """Repeated-loop timing of every primary method and the L = 1600 s variants on one file (nominal z0): median of
    run_case's perf_counter wall time over `repeats` runs after `warmup` runs (review round 1)."""
    c, vm, est = cfg()
    fz = frozen()
    tm = vm["review_round_1"]["timing"]
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)
    T = case.T
    out = []
    for name in tuple(METHODS) + ("TFO_L1600", "FOO_L1600"):
        estm, p, hy = method_spec(fz, name, T)
        focv = O.as_fast_ocv(aligned_ocv(T), s=p["s"], dq=p["dq"]) if estm != "CC" else None
        walls, procs = [], []
        for k in range(int(tm["warmup"]) + int(tm["repeats"])):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                rec = E.run_case(estm, p, hy, case, z0_scenario="nominal", ocv=focv)
            if k >= int(tm["warmup"]):
                walls.append(rec["wall_s"])
                procs.append(rec["cpu_process_s"])
        n = int(case.t.size)
        out.append(dict(method=name, file=lid, T=T, n_samples=n, repeats=len(walls),
                        wall_per_sample_us_median=float(1e6 * np.median(walls) / n),
                        wall_per_sample_us_min=float(1e6 * np.min(walls) / n),
                        wall_per_sample_us_iqr=float(1e6 * (np.quantile(walls, .75) - np.quantile(walls, .25)) / n),
                        process_per_sample_us_sum_repeats=float(1e6 * np.sum(procs) / (n * len(procs)))))
    return out


def timing_summary(recs, trecs):
    out = {}
    for m in tuple(METHODS) + ("TFO_L1600", "FOO_L1600"):
        rr = [r for r in recs if r["method"] == m]
        ns = sum(int(r["n_samples"]) for r in rr)
        tt = [x for x in trecs if x["method"] == m]
        out[m] = dict(runs=len(rr), agg_process_per_sample_us=float(1e6 * sum(float(r["cpu_process_s"]) for r in rr) / ns),
                      agg_process_resolution_us=float(1e6 * 0.015625 / ns),
                      repeated_wall_per_sample_us_median_over_files=float(np.median([x["wall_per_sample_us_median"] for x in tt])),
                      repeated_wall_per_sample_us_by_T={str(x["T"]): x["wall_per_sample_us_median"] for x in tt})
    return out


def params_at_bound(fz):
    """Frozen TFO/FOO (and L = 1600 s) parameters at the identification_study bounds (review round 1; the freeze's
    at_bound field lists tuning hyper-parameters only)."""
    b = D.load_config()["identification_study"]["bounds"]
    keymap = dict(alpha="alpha", R0="R0", Rp="Rp", Cp="Cp", s="align_s", dq="align_dq_Ah")
    out = []
    for sec, entry in (("methods", "TFO"), ("methods", "FOO"), ("secondary_budget_3200", "TFO"), ("secondary_budget_3200", "FOO")):
        for T in TEMPS:
            p = fz[sec][entry]["per_T"][str(T)]["params"]
            hits = []
            for k, bk in keymap.items():
                lo, hi = (float(x) for x in b[bk])
                v = float(p[k])
                tol = 1e-6 * max(abs(lo), abs(hi), 1.0) if k in ("s", "dq") else 1e-6 * max(abs(lo), abs(hi))
                if abs(v - lo) <= max(tol, 1e-6 * abs(lo)) or abs(v - hi) <= max(tol, 1e-6 * abs(hi)):
                    hits.append(f"{k}={v:.4g} ({'lower' if abs(v - lo) < abs(v - hi) else 'upper'} bound)")
            out.append(dict(section=sec, method=entry, T=T, at_bound=hits))
    return out


def envelopes(results, vm):
    """Median and 10-90 % quantiles of |e| over the +-0.20 runs per temperature and method, and the tail fit on the
    median envelope (same window rule, unsigned)."""
    tf = vm["tail_fit"]
    env, fits = {}, []
    for T in TEMPS:
        rs = [r for r in results if r["info"]["T"] == T]
        n = min(r["info"]["n_samples"] for r in rs)
        t = np.arange(n, dtype=float)
        env[f"env_t|{T}"] = t
        for m in METHODS:
            E_ = np.array([np.abs(r["series"][f"zhat|{m}|{sc}"][:n].astype(float) - r["series"]["zref"][:n].astype(float))
                           for r in rs for sc in ("plus20", "minus20")])
            q10, q50, q90 = np.quantile(E_, [0.1, 0.5, 0.9], axis=0)
            env[f"env_med|{T}|{m}"], env[f"env_q10|{T}|{m}"], env[f"env_q90|{T}|{m}"] = q50, q10, q90
            fit = tail_fit(t, q50, float(tf["t_start_s"]), float(tf["t_max_s"]), float(tf["e_stop"]), False,
                           int(tf["min_samples"]), int(tf["hac_lags"]))
            fits.append(dict(T=T, method=m, n_runs=int(E_.shape[0]), n_grid=int(n), **fit))
            if fit["fitted"]:
                i0, i1 = int(fit["t_from_s"]), int(fit["t_to_s"]) + 1
                env[f"env_fit|{T}|{m}"] = np.column_stack([t[i0:i1], tail_curve(fit, t[i0:i1])])
    return env, fits


def full_memory_certificates(fz, results):
    out = []
    for T in TEMPS:
        nmax = max(r["info"]["n_samples"] for r in results if r["info"]["T"] == T)
        for entry in ("TFO", "FOO"):
            e = fz["methods"][entry]["per_T"][str(T)]
            p = e["params"]
            lam = float(p["lam"]) if entry == "TFO" else 0.0
            ap = 1.0 / (float(p["Rp"]) * float(p["Cp"]))
            k1, k2 = float(e["kappa1"]), float(e["kappa2"])
            l1, l2 = float(e["hyper"]["l1"]), float(e["hyper"]["l2"])
            row = dict(T=T, method=entry, lam=lam, l1=l1, l2=l2, kappa1=k1, kappa2=k2, max_test_samples=int(nmax))
            for lab, NL in (("L400", int(e["N_L"])), ("full", None)):
                c = TM.certify_gains_discrete(float(p["alpha"]), lam, ap, k1, k2, l1, l2, 0.0, 1.0, NL)
                s = TM.sigma_star(float(p["alpha"]), lam, ap, k1, k2, l1, l2, h=1.0, N_L=NL)
                row[f"certified_{lab}"] = bool(c.certified)
                row[f"sigma_star_{lab}"] = None if s is None else float(s)
            if entry == "TFO":
                ab = fz["ablation_memory_TFO"][str(T)]
                row["L_cert_s"] = float(ab["L_cert_s"])
                row["L_cert_ge_longest_test_profile"] = bool(ab["L_cert_s"] >= nmax)
            out.append(row)
    return out


def run_pool(fn, tasks, workers):
    if workers <= 1:
        return [fn(t) for t in tasks]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, tasks, chunksize=1))


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return f if math.isfinite(f) else ("inf" if f > 0 else ("-inf" if f < 0 else "nan"))
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    return o


def compute(workers):
    c, vm, est = cfg()
    fz = frozen()
    files = list(c["splits"]["test_dynamic"])
    t0w, t0c = time.perf_counter(), time.process_time()
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    results = run_pool(file_task, files, workers)
    recs = [r for x in results for r in x["records"]]
    tails = [t for x in results for t in x["tails"]]
    env, env_fits = envelopes(results, vm)
    tfiles = [max((x for x in results if x["info"]["T"] == T), key=lambda x: x["info"]["n_samples"])["info"]["file"]
              for T in TEMPS]
    t1w, t1c = time.perf_counter(), time.process_time()
    trecs = [r for x in run_pool(timing_task, tfiles, workers) for r in x]
    t_timing = dict(wall_s=time.perf_counter() - t1w, main_process_s=time.process_time() - t1c)
    rv = vm["review_round_1"]
    idj, idr = load_json("identification.json"), load_json("identification_refined.json")
    out = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), test_phase_started_utc=started,
               script="scripts/06_validate.py", code_hash=code_hash(), task_version=TASK_VERSION,
               frozen_config=dict(sha256=sha256_file(RES / "frozen_config.json"), frozen_utc=fz["frozen_utc"],
                                  code_hash=fz["code_hash"], status=fz["status"]),
               settings=vm, admissible_soc_interval_reference=list(admissible()),
               methods={m: dict(frozen_entry=METHODS[m][0], estimator=METHODS[m][1], memory=METHODS[m][2] or "frozen",
                                description=vm["methods"][m]) for m in METHODS},
               supplementary_methods=rv["supplementary_methods"],
               files=[x["info"] for x in results], all_files_verified=bool(all(x["info"]["verified"] for x in results)),
               records=recs, summary=dict(by_method=summarise(recs, ("method",)),
                                          by_method_T=summarise(recs, ("method", "T")),
                                          by_method_profile=summarise(recs, ("method", "profile")),
                                          by_method_T_profile=summarise(recs, ("method", "T", "profile")),
                                          by_method_scenario=summarise(recs, ("method", "scenario"))),
               paired=paired(recs, vm), q_ref_sensitivity=q_sensitivity(recs), tails=tails,
               tail_summary=tail_summary(tails), envelope_fits=env_fits,
               voltage_models={x["info"]["file"]: x["vmodels"] for x in results},
               full_memory_certificates=full_memory_certificates(fz, results),
               failures=failures(recs, float(rv["failure_threshold_pct"])),
               timing=dict(records=trecs, summary=timing_summary(recs, trecs), files=tfiles, run=t_timing),
               frozen_params_at_bound=params_at_bound(fz),
               prior_test_access=dict(identification_json_generated_utc=idj.get("generated_utc"),
                                      identification_refined_test_phase_started_utc=idr.get("test_phase_started_utc"),
                                      frozen_utc=fz["frozen_utc"],
                                      note="scripts/04_identify.py and 04b_identify_refined.py evaluated the open-loop "
                                           "voltage models on the test files before the freeze (no selection made on them)"))
    out["runtime"] = dict(main_wall_s=time.perf_counter() - t0w, main_process_s=time.process_time() - t0c,
                          worker_wall_s_sum=float(sum(x["wall_s"] for x in results)),
                          worker_process_s_sum=float(sum(x["cpu_s"] for x in results)), workers=workers,
                          per_file={x["info"]["file"]: dict(wall_s=x["wall_s"], process_s=x["cpu_s"]) for x in results})
    with open(RES / "validation_main.json", "w", encoding="utf-8") as fh:
        json.dump(jsonable(out), fh, indent=1)
    arrs = {}
    for x in results:
        for k, v in x["series"].items():
            arrs[f"{x['info']['file']}|{k}"] = np.asarray(v)
    for k, v in env.items():
        arrs[k] = np.asarray(v, np.float32)
    np.savez_compressed(RES / "validation_series.npz", **arrs)
    return out


# ---------------------------------------------------------------------------------------------------------------
# Table and figures (regenerated from results/validation_main.json and results/validation_series.npz only)
# ---------------------------------------------------------------------------------------------------------------
MLABEL = {"TFO": "TFO", "FOO": "FOO", "FOO_full": "FOO (full)", "TFO_full": "TFO (full)", "FOEKF": "FOEKF",
          "EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC", "CC": "CC"}


def styles():
    from tfso import plotstyle as ps
    st = {m: dict(ps.SERIES[m]) for m in ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC")}
    st["TFO_full"] = dict(color=ps.SLOTS[5], ls=(0, (3, 1, 1, 1)), marker="P")
    st["FOO_full"] = dict(color=ps.SLOTS[7], ls=(0, (6, 2)), marker="X")
    return st


def load_outputs():
    J = load_json("validation_main.json")
    Z = np.load(RES / "validation_series.npz")
    return J, Z


def summary_row(J, key, method, **grp):
    tab = {(): "by_method", ("T",): "by_method_T", ("profile",): "by_method_profile",
           ("T", "profile"): "by_method_T_profile", ("scenario",): "by_method_scenario"}[tuple(grp)]
    for r in J["summary"][tab]:
        if r["method"] == method and all(r[k] == v for k, v in grp.items()):
            return r
    raise KeyError((method, grp))


def _hdr_m(lab):
    """Method name as an S-column head; '(full)' variants on two lines."""
    if lab.endswith(" (full)"):
        return r"{\begin{tabular}[b]{@{}c@{}}" + lab[:-7] + r"\\(full)\end{tabular}}"
    return "{" + lab + "}"


def write_table(J):
    """tables/tab_soc_results.tex (booktabs, siunitx S columns; fits the text width of the article class)."""
    meth = list(METHODS)
    L = ["% Generated by scripts/06_validate.py from results/validation_main.json (do not edit by hand).",
         r"\begin{table}[t]\centering\footnotesize\setlength{\tabcolsep}{3.2pt}",
         r"\caption{SOC estimation on the 18 unseen test records (FUDS, US06, BJDST; SP2, \SI{50}{\percent} and "
         r"\SI{80}{\percent} start), mean over the two start levels and the three initial-SOC scenarios (nominal, $\pm0.20$) "
         r"of each temperature--profile cell (6 runs from 2 records; 54 runs in the last row). (a) Post-convergence "
         r"($t\ge\SI{600}{\second}$) SOC RMSE on the admissible reference-SOC interval $[0.10,0.95]$ of the certificate "
         r"(primary); (b) post-convergence SOC RMSE over the whole profile. Values in \% SOC. The cell means carry no "
         r"dispersion and do not rank the methods: rankings are resolved only by the paired record-level tests of "
         r"Section~\ref{sec:mainresults}. All hyper-parameters frozen on the validation records; TFO: "
         r"$\lambda=\SI{e-4}{\per\second}$, $L=\SI{400}{\second}$; FOO: $\lambda=0$, $L=\SI{400}{\second}$; (full): the "
         r"same parameters and gains with full memory (identified and tuned at $L=\SI{400}{\second}$, so not a clean "
         r"memory ablation). (c) Panel (a) per initial-SOC scenario over all 18 records: CC cannot correct the $\pm0.20$ "
         r"offsets by construction and is competitive with the nominal initial SOC.}\label{tab:soc_results}",
         r"\begin{tabular}{@{}ll" + "S[table-format=2.2]" * len(meth) + "@{}}", r"\toprule",
         r"$T$ & Profile & " + " & ".join(_hdr_m(MLABEL[m]) for m in meth) + r" \\"]
    for key, title in (("adm_post_rmse_pct", "(a) admissible interval, $t\\ge\\SI{600}{\\second}$"),
                       ("whole_post_rmse_pct", "(b) whole profile, $t\\ge\\SI{600}{\\second}$")):
        L += [r"\midrule", r"\multicolumn{%d}{@{}l}{%s} \\" % (2 + len(meth), title), r"\midrule"]
        rows = [(f"\\SI{{{T}}}{{\\degreeCelsius}}", p, dict(T=T, profile=p)) for T in TEMPS for p in PROFILES]
        rows.append(("all", "all", {}))
        for tl, pl, g in rows:
            vals = [summary_row(J, key, m, **g)[f"{key}_mean"] for m in meth]
            cells = ["%.2f" % v for v in vals]  # no bold ranking: cell means carry no dispersion
            grp = ("by_method_T_profile" if g else "by_method") + (f"[T={g['T']},profile={g['profile']}]" if g else "")
            L.append(f"{tl} & {pl} & " + " & ".join(cells) + r" \\" + f" % src: results/validation_main.json:summary.{grp}.{key}_mean")
    L += [r"\midrule", r"\multicolumn{%d}{@{}l}{(c) admissible interval, $t\ge\SI{600}{\second}$, by initial-SOC scenario (18 runs each)} \\"
          % (2 + len(meth)), r"\midrule"]
    for sc, lab in (("nominal", "nominal"), ("plus20", r"$+0.20$"), ("minus20", r"$-0.20$")):
        vals = [summary_row(J, "adm_post_rmse_pct", m, scenario=sc)["adm_post_rmse_pct_mean"] for m in meth]
        cells = ["%.2f" % v for v in vals]
        L.append(f"all & {lab} & " + " & ".join(cells) + r" \\"
                 + f" % src: results/validation_main.json:summary.by_method_scenario[scenario={sc}].adm_post_rmse_pct_mean")
    L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    TAB.mkdir(exist_ok=True)
    (TAB / "tab_soc_results.tex").write_text("\n".join(L) + "\n", encoding="utf-8")


def fig_soc(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    st = styles()
    files = {(f["T"], f["profile"], f["start_level"]): f["file"] for f in J["files"]}
    fig, axs = plt.subplots(6, 3, figsize=ps.figsize("text", 215), sharey=True, layout="constrained")
    for i, (T, sl) in enumerate([(T, s) for T in TEMPS for s in ("50SOC", "80SOC")]):
        for j, p in enumerate(PROFILES):
            ax = axs[i, j]
            f = files[(T, p, sl)]
            th = Z[f"{f}|t_soc"] / 3600.0
            ax.fill_between(th, Z[f"{f}|zref_lo"], Z[f"{f}|zref_hi"], color=ps.SHADE2, lw=0, label="reference band")
            ax.plot(th, Z[f"{f}|zref"], color=ps.INK, lw=0.9, label="reference SOC")
            for m in ("EKF2RC", "TFO"):
                for k, sc in enumerate(("nominal", "plus20", "minus20")):
                    ax.plot(th, Z[f"{f}|zhat|{m}|{sc}"], color=st[m]["color"], ls=st[m]["ls"], lw=0.8,
                            label=MLABEL[m] if k == 0 else None)
            ax.set_ylim(-0.1, 1.08)
            if i == 0:
                ax.set_title(p)
            if j == 0:
                ax.set_ylabel(f"{T} °C, {sl[:2]} %\nSOC (-)")
            if i == 5:
                ax.set_xlabel("time (h)")
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=4)
    ps.save(fig, FIG / "fig_soc_test.pdf")
    plt.close(fig)


ENV_METHODS = ("TFO", "FOO", "TFO_full", "FOO_full", "FOEKF", "EKF2RC", "AEKF2RC")


def fig_envelopes(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    st = styles()
    band = float(D.load_config()["validation"]["error_band_convergence"])
    fits = {(f["T"], f["method"]): f for f in J["envelope_fits"]}
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 120), layout="constrained")
    for j, T in enumerate(TEMPS):
        t = Z[f"env_t|{T}"].astype(float)
        for i, loglog in enumerate((False, True)):
            ax = axs[i, j]
            ax.fill_between(t[1:], 100 * Z[f"env_q10|{T}|TFO"][1:], 100 * Z[f"env_q90|{T}|TFO"][1:], color=ps.SHADE2,
                            lw=0, label="TFO 10-90 %")
            for m in ENV_METHODS:
                ax.plot(t[1:], 100 * Z[f"env_med|{T}|{m}"][1:], color=st[m]["color"], ls=st[m]["ls"], lw=0.9,
                        label=MLABEL[m] + " median")
            if fits[(T, "TFO")]["fitted"]:
                a = Z[f"env_fit|{T}|TFO"]
                ax.plot(a[:, 0], 100 * a[:, 1], color=ps.INK, lw=1.4, ls=(0, (1, 1)), label="tail fit (TFO median)")
            ax.axhline(100 * band, color=ps.INK2, lw=ps.LW["ref"], ls="--")
            ax.set_yscale("log")
            ax.set_ylim(1e-2, 40)
            if loglog:
                ax.set_xscale("log")
                ax.set_xlim(1, t[-1])
            else:
                ax.set_xlim(0, t[-1])
            ax.set_xlabel("time since profile start (s)")
            if j == 0:
                ax.set_ylabel(("log-log" if loglog else "semilog") + "\n|SOC error| (% SOC)")
            if i == 0:
                ax.set_title(f"{T} °C (±0.20 runs, n = {fits[(T, 'TFO')]['n_runs']})")
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=5)
    ps.save(fig, FIG / "fig_error_envelopes.pdf")
    plt.close(fig)


# model families: plotstyle M_* series (colour of the estimator built on the model; 2RC = EKF-2RC colour)
VM_STYLE = {"TFO": ("M_TF", "tempered fractional"), "FO": ("M_FO", "fractional (λ = 0)"), "2RC": ("M_2RC", "2RC")}


def fig_vt(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    vm = J["settings"]["voltage_models"]
    T = int(vm["representative_T"])
    files = {(f["T"], f["profile"], f["start_level"]): f["file"] for f in J["files"]}
    fig, axs = plt.subplots(4, 3, figsize=ps.figsize("text", 190), layout="constrained")
    for j, p in enumerate(PROFILES):
        f = files[(T, p, "80SOC")]
        t = Z[f"{f}|t_V"].astype(float)
        V = Z[f"{f}|V_meas"]
        w1, w2 = [((a if a >= 0 else t[-1] + a), (b if b > 0 else t[-1] + b)) for a, b in vm["transient_windows_s"]]
        wins = [(0.0, t[-1]), w1, (1000.0, 1060.0), w2]     # 60 s zoom inside window 1 (presentation only)
        for i, (a, b) in enumerate(wins):
            ax = axs[i, j]
            m = (t >= a) & (t <= b)
            x = t[m] / (3600.0 if i == 0 else 1.0)
            ax.plot(x, V[m], color=ps.INK, lw=1.3 if i else 0.8, label="measured")
            for fam in VM_FAMS:
                sn, lab = VM_STYLE[fam]
                s = ps.SERIES[sn]
                ax.plot(x, Z[f"{f}|Vt_{fam}"][m], color=s["color"], ls=s["ls"], lw=0.9 if i else 0.6,
                        zorder={"TFO": 3.0, "FO": 2.6, "2RC": 2.2}[fam], label=f"{lab} model")   # TF model on top
            r = J["voltage_models"][f]
            if i == 0:
                ax.set_title(f"{p}, {T} °C, 80 % start" + "\n" + "TFO/FO/2RC RMSE " + "/".join(f"{r[fam]['rmse_mV']:.1f}" for fam in VM_FAMS) + " mV",
                             fontsize=ps.FONT_PT["base"])
                ax.set_xlabel("time (h)")
                for k, (a2, b2) in enumerate((w1, w2)):
                    ax.axvspan(a2 / 3600.0, b2 / 3600.0, color=ps.SHADE, lw=0)
            else:
                ax.set_xlabel("time (s)")
            if j == 0:
                ax.set_ylabel(["whole profile", "window 1", "zoom 60 s", "window 2"][i] + "\n$V_t$ (V)")
    h, l = axs[1, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=4)
    ps.save(fig, FIG / "fig_vt_model.pdf")
    plt.close(fig)


def fig_acf(J, Z):
    from tfso import plotstyle as ps
    plt = ps.setup()
    fig, axs = plt.subplots(1, 3, figsize=ps.figsize("text", 62), sharey=True, layout="constrained")
    for j, T in enumerate(TEMPS):
        ax = axs[j]
        fl = [f["file"] for f in J["files"] if f["T"] == T]
        n = np.median([J["voltage_models"][f]["TFO"]["n"] for f in fl])
        for fam in VM_FAMS:
            sn, lab = VM_STYLE[fam]
            s = ps.SERIES[sn]
            A = np.array([Z[f"{f}|acf_{fam}"] for f in fl], float)
            lag = np.arange(A.shape[1])
            if fam == "TFO":
                ax.fill_between(lag, A.min(0), A.max(0), color=ps.SHADE2, lw=0, label="TFO min-max over files")
            ax.plot(lag, np.median(A, 0), color=s["color"], ls=s["ls"], lw=1.0, label=f"{lab} (median)",
                    zorder={"TFO": 3.0, "FO": 2.6, "2RC": 2.2}[fam])
        ci = 1.96 / math.sqrt(n)
        ax.axhspan(-ci, ci, color=ps.SHADE, lw=0)
        ax.axhline(0, color=ps.INK2, lw=ps.LW["ref"])
        ax.set_title(f"{T} °C ({len(fl)} test files)")
        ax.set_xlabel("lag (s)")
        if j == 0:
            ax.set_ylabel("residual ACF (-)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=4)
    ps.save(fig, FIG / "fig_resid_acf.pdf")
    plt.close(fig)


# ---------------------------------------------------------------------------------------------------------------
# Findings report (every number read from results/validation_main.json)
# ---------------------------------------------------------------------------------------------------------------
def _n(v, d=3):
    if v is None:
        return "-"
    if isinstance(v, str):
        return v
    if not math.isfinite(v):
        return "inf" if v > 0 else "nan"
    a = abs(v)
    if a != 0 and (a < 1e-3 or a >= 1e5):
        return f"{v:.2e}"
    return f"{v:.{d}f}"


def _p(v):
    return "-" if v is None or (isinstance(v, float) and not math.isfinite(v)) else f"{v:.2g}"


def _pair(J, comp, met="adm_post_rmse_pct", grp="all", unit="file", ref="TFO"):
    for r in J["paired"]:
        if r["reference"] == ref and r["comparator"] == comp and r["metric"] == met and r["group"] == grp \
                and r.get("unit") == unit:
            return r
    return None


def _qs(J, m, T="all"):
    for r in J["q_ref_sensitivity"]:
        if r["method"] == m and r["T"] == T:
            return r
    raise KeyError((m, T))


def _ts(J, kind, var, m, T):
    for r in J["tail_summary"]:
        if r["kind"] == kind and r["variant"] == var and r["method"] == m and r["T"] == T:
            return r
    raise KeyError((kind, m, T))


def _pf(r, unit_word="files"):
    """'median [CI], TFO worse in k/n files, p' for one paired entry."""
    if r is None:
        return "-"
    n = r["n"]
    return (f"{_n(r['median_diff'])} [{_n(r['ci_lo'])}, {_n(r['ci_hi'])}], worse in {r['n_b_better']}/{n} {unit_word}, "
            f"p {_p(r['wilcoxon_p'])}")


ML2 = dict(MLABEL, TFO_L1600="TFO (L 1600)", FOO_L1600="FOO (L 1600)", TFO_lam0="TFO (lambda := 0)",
           **{"FOO_lam1e-4": "FOO (lambda := 1e-4)"}, EKF2RC_textbook="EKF-2RC (textbook noise)")
KM = "adm_post_rmse_pct"
KALMAN = ("FOEKF", "EKF2RC", "AEKF2RC")
QCASES = (("adm_post_rmse_pct@Q_minus", "Q_ref - u_Q"), ("adm_post_rmse_pct", "Q_ref"),
          ("adm_post_rmse_pct@Q_plus", "Q_ref + u_Q"), ("adm_post_rmse_pct@obs_axis", "observer axis"))


def _exceptions(J, comp):
    """All file-level and per-scenario subgroups where the CI of the median difference contains 0 or p >= 0.05."""
    out = []
    for r in J["paired"]:
        if r["reference"] != "TFO" or r["comparator"] != comp or r["metric"] != KM or r["group"] == "all" \
                or r.get("unit") not in ("file", "scenario"):
            continue
        ci0 = r["ci_lo"] <= 0 <= r["ci_hi"]
        pns = not (r["wilcoxon_p"] < 0.05)
        if ci0 or pns:
            out.append(f"{r['group']} ({_n(r['median_diff'])} [{_n(r['ci_lo'])}, {_n(r['ci_hi'])}], p {_p(r['wilcoxon_p'])}"
                       + ("; CI excludes 0 but p >= 0.05" if (pns and not ci0) else "") + ")")
    return out


def key_findings(J):
    S = {r["method"]: r for r in J["summary"]["by_method"]}
    SS = {(r["method"], r["scenario"]): r for r in J["summary"]["by_method_scenario"]}
    P = lambda c, g="all", met=KM, unit="file", ref="TFO": _pair(J, c, met, g, unit, ref)  # noqa: E731
    thr = float(J["settings"]["review_round_1"]["failure_threshold_pct"])
    fails = J["failures"]
    mean_rank = sorted(METHODS, key=lambda m: S[m][KM + "_mean"])
    med_rank = sorted(METHODS, key=lambda m: S[m][KM + "_median"])
    nom_rank = sorted(METHODS, key=lambda m: SS[(m, "nominal")][KM + "_mean"])
    nfail = {m: sum(1 for f in fails if f["method"] == m) for m in METHODS if m != "CC"}
    worst = {m: S[m][KM + "_max_finite"] for m in METHODS}
    cc = P("CC", "scenario=nominal", unit="scenario")
    f1, l0, l1_, l16 = P("FOO"), P("TFO_lam0"), P("FOO", ref="FOO_lam1e-4"), P("FOO_L1600", ref="TFO_L1600")
    cap = load_json("capacity.json")
    ratio = {T: cap["Q_ref_T_SP2"][str(T)]["Q_ref_Ah"] / cap["Q_id_T_SP2"][str(T)]["Q_id_Ah"] for T in TEMPS}
    qs = {m: _qs(J, m) for m in METHODS}
    tT = {T: _ts(J, "error", "primary", "TFO", T) for T in TEMPS}
    tE = {T: _ts(J, "error", "early_t10", "TFO", T) for T in TEMPS}
    dA, dF = _ts(J, "incremental", "delta", "TFO", "all"), _ts(J, "incremental", "delta", "FOO", "all")
    d16 = _ts(J, "incremental", "delta", "TFO_L1600", 0)
    dK = _ts(J, "incremental", "delta", "FOEKF", "all")
    L = ["## Key findings (revised after review; file = unit of inference)", ""]
    L.append(
        f"1. **TFO does not win on the test set.** Mean of the primary metric over the 54 runs: " +
        ", ".join(f"{ML2[m]} {S[m][KM + '_mean']:.3f}" for m in mean_rank) + ". Median over runs: " +
        ", ".join(f"{ML2[m]} {S[m][KM + '_median']:.3f}" for m in med_rank) +
        f" (EKF-2RC ranks first by median; its mean and AEKF-2RC's mean are raised by a few failed runs). Runs above "
        f"{thr:g} % SOC: " + ", ".join(f"{ML2[m]} {nfail[m]}" for m in METHODS if m != "CC") +
        f" (listed in Section 1). TFO's worst run is {worst['TFO']:.2f} % SOC, lower than the worst runs of EKF-2RC "
        f"({worst['EKF2RC']:.2f}) and AEKF-2RC ({worst['AEKF2RC']:.2f}).")
    L.append(
        f"2. **With the nominal (OCV-based) initial SOC, plain Coulomb counting is more accurate than TFO on most files.** "
        f"Nominal-scenario means: " + ", ".join(f"{ML2[m]} {SS[(m, 'nominal')][KM + '_mean']:.3f}" for m in nom_rank) +
        f". TFO - CC (nominal, n = 18 files): {_pf(cc)} (the Wilcoxon test is not significant because CC's "
        f"{sum(1 for f in fails if f['method'] == 'CC' and f['scenario'] == 'nominal')} nominal failures are large). "
        f"On these files TFO's closed-loop correction does not beat open-loop CC started from a good SOC; CC's pooled "
        f"mean ({S['CC'][KM + '_mean']:.2f}) comes from the +-0.20 runs ({SS[('CC', 'plus20')][KM + '_mean']:.2f} / "
        f"{SS[('CC', 'minus20')][KM + '_mean']:.2f}), which CC cannot correct by construction.")
    L.append(
        f"3. **Tempering gives no gain at either memory budget.** TFO - FOO (each with its own parameters and gains): {_pf(f1)}. "
        f"Pure lambda contrast with parameters and gains held fixed: TFO - TFO(lambda := 0) {_pf(l0)}; "
        f"FOO(lambda := 1e-4) - FOO {_pf(l1_)}. At L = 1600 s: TFO - FOO {_pf(l16)}. The effect is small "
        f"(hundredths of % SOC) and never favours tempering.")
    exc = {c: _exceptions(J, c) for c in KALMAN}
    exc_f, exc_nf = [], []
    for c in KALMAN:
        for r in J["paired"]:
            if r["reference"] != "TFO" or r["comparator"] != c or r["metric"] != KM or r["group"] == "all"                     or r.get("unit") not in ("file", "scenario"):
                continue
            if not (r["ci_lo"] <= 0 <= r["ci_hi"] or not r["wilcoxon_p"] < 0.05):
                continue
            k, v = r["group"].split("=")
            hit = any(f["method"] == c and str(f[k]) == v for f in fails)
            (exc_f if hit else exc_nf).append((c, r["group"]))
    ekt = P("EKF2RC_textbook")
    L.append(
        "4. **TFO is worse than the Kalman benchmarks overall.** File level (n = 18): TFO - FOEKF " + _pf(P("FOEKF")) +
        "; TFO - EKF-2RC " + _pf(P("EKF2RC")) + "; TFO - AEKF-2RC " + _pf(P("AEKF2RC")) +
        ". Per temperature there are only 6 files, so the smallest attainable exact Wilcoxon p is "
        f"{P('FOEKF', 'T=0')['min_exact_wilcoxon_p']:.3f}. Subgroups without a significant disadvantage (CI contains 0 or "
        "p >= 0.05): " + "; ".join(f"{ML2[c]}: " + (", ".join(exc[c]) if exc[c] else "none") for c in KALMAN) +
        f". Qualifications: at 45 C TFO and FOEKF are practically equal (median difference "
        f"{_n(P('FOEKF', 'T=45')['median_diff'])} % SOC). Exception groups that contain a failed benchmark run (> "
        f"{thr:g} % SOC, Section 1): " + ", ".join(f"{ML2[c]} {g}" for c, g in exc_f) + "; without one: " +
        (", ".join(f"{ML2[c]} {g}" for c, g in exc_nf) or "none") + ". The failures occur under the benchmarks' "
        "validation-tuned noise, which sits at tuning-box bounds and was tuned on one validation file per temperature. "
        "They are artefacts of benchmark tuning, not strengths of TFO. Diagnostic (not selected): "
        f"with an untuned textbook noise setting EKF-2RC has {sum(1 for f in fails if f['method'] == 'EKF2RC_textbook')} "
        f"runs above {thr:g} % SOC (max {S['EKF2RC_textbook'][KM + '_max_finite']:.2f}), and TFO - EKF-2RC(textbook) is {_pf(ekt)}, so "
        "the direction 'TFO worse' holds under sane alternative benchmark settings.")
    L.append(
        "5. **Reference capacity and SOC axis.** Every estimator integrates with Q_id, but the reference uses Q_ref "
        "(Q_ref/Q_id " + ", ".join(f"{T} C {ratio[T]:.4f}" for T in TEMPS) + "). This gives a common-mode bias; mean "
        "admissible post bias (% SOC): " + ", ".join(f"{ML2[m]} {qs[m]['adm_post_bias_pct_Q_ref_mean']:+.2f}" for m in METHODS
                                                    if m != "CC") +
        ". Paired TFO - comparator (file level, median, p) under " + " / ".join(q for _, q in QCASES) + ": " +
        "; ".join(f"{ML2[c]} " + " / ".join(f"{_n(P(c, met=mk)['median_diff'])} (p {_p(P(c, met=mk)['wilcoxon_p'])})"
                                             for mk, _ in QCASES) for c in KALMAN) +
        ". Comparators against which TFO's disadvantage is significant (p < 0.05): " + "; ".join(
            f"{q}: " + (", ".join(ML2[c] for c in KALMAN if P(c, met=mk)["wilcoxon_p"] < 0.05) or "none") for mk, q in QCASES) +
        ". There is no single 'best method' across reference capacities (under Q_ref - u_Q, TFO and FOO differ by "
        f"{abs(qs['TFO'][KM + '_Q_minus_mean'] - qs['FOO'][KM + '_Q_minus_mean']):.4f} % SOC).")
    L.append(
        "6. **The full-memory comparison depends on the reference and is confounded.** TFO - TFO (full), file level, under "
        + " / ".join(q for _, q in QCASES) + ": " +
        " / ".join(f"{_n(P('TFO_full', met=mk)['median_diff'])} (worse in {P('TFO_full', met=mk)['n_b_better']}/18, p "
                   f"{_p(P('TFO_full', met=mk)['wilcoxon_p'])})" for mk, _ in QCASES) +
        ". The sign flips with the reference capacity, and TFO (full) reuses parameters identified and gains tuned at L = "
        "400 s, so this is not a memory ablation. The clean ablation uses the frozen L = 1600 s entries, which have their "
        f"own parameters and gains: TFO(400) - TFO(1600) {_pf(P('TFO_L1600'))}; FOO(400) - FOO(1600) "
        f"{_pf(P('FOO_L1600', ref='FOO'))}. Per temperature, TFO(400) - TFO(1600): " +
        ", ".join(f"{T} C {_n(P('TFO_L1600', f'T={T}')['median_diff'])}" for T in TEMPS) + ".")
    L.append(
        f"7. **Transients.** First entry into +-2 % (post hoc diagnostic), median: TFO "
        f"{_n(S['TFO']['whole_first_entry_s_median'], 0)} s, FOEKF {_n(S['FOEKF']['whole_first_entry_s_median'], 0)} s, "
        f"EKF-2RC {_n(S['EKF2RC']['whole_first_entry_s_median'], 0)} s. Error tails of the +-0.20 TFO runs (declared window): "
        "lambda_eff median " + ", ".join(f"{T} C {_n(tT[T]['lambda_eff_median'])} ({tT[T]['n_fitted']}/{tT[T]['n_runs']} fits)"
                                         for T in TEMPS) +
        " 1/s, inside the loop range l1 kappa. At 45 C most runs reach e_stop before 60 samples. With a post-hoc earlier "
        "window (t >= 10 s, >= 20 samples) the fits are " + ", ".join(
            f"{T} C {_n(tE[T]['lambda_eff_median'])} ({tE[T]['n_fitted']}/{tE[T]['n_runs']}, median window "
            f"{_n(tE[T]['window_s_median'], 0)} s)" for T in TEMPS) +
        ". The windows are short and t and log t are collinear (median corr(lambda_eff, rho) "
        f"{_n(_ts(J, 'error', 'primary', 'TFO', 'all')['corr_lambda_rho_median'], 2)}), so no tail law is claimed. "
        f"**Incremental error:** the declared fit gives rho median {_n(dA['rho_median'])} (CI > 0 in {dA['n_rho_ci_gt0']}/"
        f"{dA['n_fitted']}). With the linearised loop rate as regressor, g median {_n(dA['kc_g_median'])}, and rho drops to "
        f"{_n(dA['kc_rho_median'])} (CI > 0 in {dA['kc_n_rho_ci_gt0']}, < 0 in {dA['kc_n_rho_ci_lt0']} of {dA['kc_n']}). "
        f"For FOO it drops from {_n(dF['rho_median'])} to {_n(dF['kc_rho_median'])} ({dF['kc_n_rho_ci_gt0']}/"
        f"{dF['kc_n_rho_ci_lt0']}). K(t) alone gives R^2 {_n(dA['kc_r2_K_only_median'], 4)}. The incremental decay is "
        "explained by the state-dependent rate l1 U'(z(t)), and no algebraic factor is identifiable. Positive rho is not "
        f"specific to fractional memory: FOEKF gives {_n(dK['rho_median'])} through its decaying gain. Residual exception: "
        f"TFO (L 1600) at 0 C keeps rho {_n(d16['kc_rho_median'])} with g {_n(d16['kc_g_median'])} "
        f"({d16['kc_n_rho_ci_gt0']}/{d16['kc_n']} CI > 0); this is not interpreted.")
    L.append(
        "8. **Voltage models (open loop).** TFO, FO and 2RC are practically identical on the test files, and their "
        "residuals are strongly autocorrelated (Section 6). Disclosure: these test-file numbers are not a first look. "
        "They were computed in scripts 04/04b before the freeze and are reproduced exactly here (Section 6).")
    L.append("")
    return L


def report_sections(J):
    fz = load_json("frozen_config.json")
    S = {r["method"]: r for r in J["summary"]["by_method"]}
    SS = {(r["method"], r["scenario"]): r for r in J["summary"]["by_method_scenario"]}
    P = lambda c, g="all", met=KM, unit="file", ref="TFO": _pair(J, c, met, g, unit, ref)  # noqa: E731
    comps = list(J["settings"]["paired"]["comparators"]) + list(SUPP)
    L = ["## 1. Per-method summary (54 runs per method)", "",
         "| method | adm. post RMSE mean / median / max | whole post RMSE | adm. post max abs | within 2 % (adm. post) | "
         "adm. post bias | band-keeping time median (never) | first entry (s) | V_t RMSE adm. (mV) | SOC clips (sum) | "
         "outside z-interval (median) | history | bytes |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for m in ALL_METHODS:
        r = S[m]
        L.append(f"| {ML2[m]}{'' if m in METHODS else ' *'} | {_n(r[KM + '_mean'])} / {_n(r[KM + '_median'])} / "
                 f"{_n(r[KM + '_max_finite'])} | {_n(r['whole_post_rmse_pct_mean'])} | {_n(r['adm_post_maxabs_pct_mean'])} | "
                 f"{_n(r['adm_post_within2_pct_mean'], 1)} | {r['adm_post_bias_pct_mean']:+.2f} | "
                 f"{_n(r['adm_conv_time_s_median'], 0)} ({r['adm_conv_time_s_n_inf']}) | {_n(r['whole_first_entry_s_median'], 0)} | "
                 f"{_n(r['adm_vt_rmse_mV_mean'], 2)} | {int(r['soc_clip_count_sum'])} | {_n(r['n_outside_z_interval_median'], 0)} | "
                 f"{_n(r['n_history_samples_median'], 0)} | {_n(r['bytes_state_median'], 0)} |")
    L += ["", "% SOC; means unless stated; * = supplementary (frozen L = 1600 s secondary-budget entries) or "
          "diagnostic method (review round 1; nothing selected from them). 'Band-keeping time' is the declared last exit from +-2 % on admissible samples. It "
          "measures late excursions rather than convergence (its median is a large fraction of the profile for "
          "TFO/FOO). 'First entry' is the transient metric (post hoc). Whole-profile last exit is 'never' for " +
          ", ".join(f"{ML2[m]} {S[m]['whole_conv_time_s_n_inf']}/54" for m in METHODS) + ". SOC clips are samples at the "
          f"clip limits {fz['soc_clip']}. 'Outside z-interval' counts samples where the ESTIMATE leaves the certificate's "
          "z_interval of the frozen gains; the admissible window is defined on the REFERENCE SOC [0.10, 0.95], so the two "
          "do not coincide.", "", "**Per initial-SOC scenario** (mean / median of the primary metric, 18 runs each):", "",
          "| method | nominal | +0.20 | -0.20 |", "|---|---|---|---|"]
    for m in METHODS:
        L.append(f"| {ML2[m]} | " + " | ".join(f"{SS[(m, s)][KM + '_mean']:.3f} / {SS[(m, s)][KM + '_median']:.3f}"
                                               for s in ("nominal", "plus20", "minus20")) + " |")
    thr = float(J["settings"]["review_round_1"]["failure_threshold_pct"])
    fl = [f for f in J["failures"] if f["method"] != "CC" or f["scenario"] == "nominal"]
    L += ["", f"**Runs above {thr:g} % SOC** (CC +-0.20 runs omitted: all "
          f"{sum(1 for f in J['failures'] if f['method'] == 'CC' and f['scenario'] != 'nominal')} of them fail by construction): " +
          "; ".join(f"{ML2[f['method']]} {f['file']} {f['scenario']} {f['adm_post_rmse_pct']:.2f} ({f['soc_clip_count']} clips)"
                    for f in fl) + ". TFO: none.", ""]
    TS = J["timing"]["summary"]
    L += ["**Cost per sample** (review round 1). Aggregated process time is the sum over the 54 runs divided by the "
          f"total samples, with resolution {_n(TS['TFO']['agg_process_resolution_us'], 3)} us. Repeated wall time is "
          f"perf_counter, median of {J['settings']['review_round_1']['timing']['repeats']} repeats on the longest test file "
          f"per temperature ({', '.join(J['timing']['files'])}), run while the other worker was busy (shared machine; "
          "indicative only):", "", "| method | aggregated process (us) | repeated wall, median over T (us) | per T 0/25/45 |",
          "|---|---|---|---|"]
    for m, r in TS.items():
        L.append(f"| {ML2[m]} | {r['agg_process_per_sample_us']:.2f} | {r['repeated_wall_per_sample_us_median_over_files']:.2f} | "
                 + "/".join(f"{r['repeated_wall_per_sample_us_by_T'][str(T)]:.2f}" for T in TEMPS) + " |")
    # ---- paired ---------------------------------------------------------------------------------------------------
    L += ["", "## 2. Paired differences TFO - comparator, primary metric (% SOC)", "",
          "Unit = file (mean over the 3 scenarios). Median [95 % bootstrap CI over files], TFO better/worse, exact "
          "Wilcoxon p. n = 18 overall and 6 per temperature, where the minimum attainable p is 0.031. The last column gives "
          "the 54 (file, scenario) pairs for comparison only: after t = 600 s these pairs are near-replicates, so their "
          "p-values overstate the precision.", "",
          "| comparator | all files (18) | 0 C (6) | 25 C (6) | 45 C (6) | 54 pairs (descriptive) |", "|---|---|---|---|---|---|"]
    cell = lambda r: "-" if r is None else (f"{_n(r['median_diff'])} [{_n(r['ci_lo'])}, {_n(r['ci_hi'])}]; "  # noqa: E731
                                            f"{r['n_a_better']}/{r['n_b_better']}; {_p(r['wilcoxon_p'])}")
    for c in comps:
        L.append(f"| {ML2[c]} | " + " | ".join(cell(P(c, g)) for g in ["all"] + [f"T={T}" for T in TEMPS]) +
                 f" | {cell(P(c, unit='run'))} |")
    L += ["", "By profile (6 files each) and by scenario (18 files, one run each):", "",
          "| comparator | FUDS | US06 | BJDST | nominal | +0.20 | -0.20 |", "|---|---|---|---|---|---|---|"]
    for c in comps:
        L.append(f"| {ML2[c]} | " + " | ".join(cell(P(c, f"profile={p}")) for p in PROFILES) + " | " +
                 " | ".join(cell(P(c, f"scenario={s}", unit="scenario")) for s in ("nominal", "plus20", "minus20")) + " |")
    L += ["", "Other contrasts (file level): " + "; ".join(
        f"{ML2[a]} - {ML2[b]} {_pf(P(b, ref=a))}" for a, b in (("FOO_lam1e-4", "FOO"), ("TFO_L1600", "FOO_L1600"),
                                                              ("TFO_full", "FOO_full"))) + ".", "",
          "Other metrics (file level, all files; median [CI], TFO better/worse, p):", ""]
    for met, tag in (("whole_post_rmse_pct", ""), ("adm_post_maxabs_pct", ""), ("adm_vt_rmse_mV", ""),
                     ("whole_conv_time_s", " (declared; never-converged runs censored at the file's duration + 1 s)"),
                     ("adm_conv_time_s", " (band-keeping, supplementary, post hoc)"),
                     ("whole_first_entry_s", " (post hoc)")):
        L.append(f"* `{met}`{tag}: " + "; ".join(
            f"{ML2[c]} {_n(P(c, met=met)['median_diff'])} [{_n(P(c, met=met)['ci_lo'])}, {_n(P(c, met=met)['ci_hi'])}] "
            f"{P(c, met=met)['n_a_better']}/{P(c, met=met)['n_b_better']} p {_p(P(c, met=met)['wilcoxon_p'])}"
            for c in list(J["settings"]["paired"]["comparators"]) if c != "CC" and P(c, met=met) is not None))
    L += ["", "Never-converged (whole window) runs of TFO: "
          f"{P('FOEKF', met='whole_conv_time_s')['n_never_ref']}/54."]
    # ---- certificates, bounds -------------------------------------------------------------------------------------
    FC = J["full_memory_certificates"]
    L += ["", "## 3. Certificates, parameter bounds, clipping", "",
          f"(DC) at sigma = 0 with the frozen gains and kappa bounds holds for TFO and FOO at L = 400 s and at full memory at "
          f"every temperature: {all(r['certified_L400'] and r['certified_full'] for r in FC)}. sigma* at L = 400 s: " +
          ", ".join(f"{r['method']} {r['T']} C {_n(r['sigma_star_L400'])}" for r in FC) + " 1/s. L_cert(T) exceeds the "
          f"longest test profile: {all(r['L_cert_ge_longest_test_profile'] for r in FC if 'L_cert_s' in r)}. Frozen "
          "fractional parameters at identification_study bounds (the freeze's at_bound lists tuning hyper-parameters only): " +
          "; ".join(f"{b['method']}{'' if b['section'] == 'methods' else ' (L 1600)'} {b['T']} C: {', '.join(b['at_bound'])}"
                    for b in J["frozen_params_at_bound"] if b["at_bound"]) + ". The certified claims concern the estimate "
          "inside the z-interval. The SOC-clip and outside-interval counts in Section 1 show how often the TFO/FOO "
          "estimates leave that interval (TFO clip samples per temperature: review response, item B8)."]
    # ---- Q_ref -------------------------------------------------------------------------------------------------------
    cap = load_json("capacity.json")["Q_ref_T_SP2"]
    L += ["", "## 4. Reference-SOC uncertainty and SOC axis", "",
          "The estimates are unchanged and only the reference is recomputed. Cases: Q_ref -+ u_Q (u_Q/Q_ref " +
          ", ".join(f"{T} C {cap[str(T)]['u_Q_rel'] * 100:.2f} %" for T in TEMPS) + ") and the observer axis "
          "z_obs = 1 - (1 - z_ref) Q_ref/Q_id (the charge axis the estimators integrate on; post hoc). Mean admissible "
          "post RMSE (% SOC) under Q_ref - u_Q / Q_ref / Q_ref + u_Q / observer axis, and mean bias under Q_ref / observer axis:",
          "", "| method | all | 0 C | 25 C | 45 C | bias Q_ref / obs. axis |", "|---|---|---|---|---|---|"]
    for m in ALL_METHODS:
        q0 = _qs(J, m)
        L.append(f"| {ML2[m]} | " + " | ".join(
            "{:.2f} / {:.2f} / {:.2f} / {:.2f}".format(*(_qs(J, m, T)[f"{KM}_{k}_mean"] for k in ("Q_minus", "Q_ref", "Q_plus", "obs_axis")))
            for T in ("all",) + TEMPS) + f" | {q0['adm_post_bias_pct_Q_ref_mean']:+.2f} / {q0['adm_post_bias_pct_obs_axis_mean']:+.2f} |")
    L += ["", "Paired TFO - comparator under each reference (file level, n = 18):", "",
          "| comparator | " + " | ".join(q for _, q in QCASES) + " |", "|---|---|---|---|---|"]
    for c in ("FOO", "TFO_full", "FOEKF", "EKF2RC", "AEKF2RC", "TFO_L1600"):
        L.append(f"| {ML2[c]} | " + " | ".join(cell(P(c, met=mk)) for mk, _ in QCASES) + " |")
    return L


def report_tails_vm(J):
    fz = load_json("frozen_config.json")
    tf = J["settings"]["tail_fit"]
    ew = J["settings"]["review_round_1"]["early_window_sensitivity"]
    L = ["", "## 5. Convergence tails (+-0.20 runs)", "",
         f"Declared model: log|e| = c - lambda_eff t - rho log t, fitted by OLS on 1 s samples. The window runs from t = "
         f"{tf['t_start_s']:.0f} s until the first |e| <= {tf['e_stop']} (sensitivity {tf['e_stop_sensitivity']}), the first "
         f"sign change or t = {tf['t_max_s']:.0f} s. A fit needs >= {tf['min_samples']} samples; CIs are 95 % Newey-West "
         f"({tf['hac_lags']} lags). Post-hoc early window: t >= {ew['t_start_s']:.0f} s, >= {ew['min_samples']} samples. "
         f"Incremental fit: delta = zhat(scenario) - zhat(nominal), stopped at |delta| <= {tf['delta_stop']}. Loop-rate control "
         "(post hoc): log|delta| = c - g K(t) - rho log t with K(t) = int l1 U'(zhat_nominal) ds.", "",
         "| kind | method | T | fitted | lambda_eff median [IQR] | rho median [IQR] | rho CI >0 / <0 | R^2 full / exp / alg | corr | window median (min-max) s |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    rows = [("error", "primary", "TFO", T) for T in ("all",) + TEMPS] + \
        [("error", "early_t10", "TFO", T) for T in ("all",) + TEMPS] + \
        [("error", "primary", m, "all") for m in ("FOO", "TFO_full", "FOEKF", "EKF2RC", "AEKF2RC")] + \
        [("incremental", "delta", "TFO", T) for T in ("all",) + TEMPS] + \
        [("incremental", "delta", m, "all") for m in ("FOO", "TFO_full", "TFO_L1600", "FOEKF", "EKF2RC", "AEKF2RC")]
    for kind, var, m, T in rows:
        r = _ts(J, kind, var, m, T)
        lab = f"{kind}{' (early)' if var == 'early_t10' else ''}"
        if r["n_fitted"] == 0:
            L.append(f"| {lab} | {ML2[m]} | {T} | 0/{r['n_runs']} | not fitted (converged before the window) | | | | | |")
            continue
        L.append(f"| {lab} | {ML2[m]} | {T} | {r['n_fitted']}/{r['n_runs']} | {_n(r['lambda_eff_median'])} "
                 f"[{_n(r['lambda_eff_q25'])}, {_n(r['lambda_eff_q75'])}] | {_n(r['rho_median'])} [{_n(r['rho_q25'])}, "
                 f"{_n(r['rho_q75'])}] | {r['n_rho_ci_gt0']}/{r['n_rho_ci_lt0']} | {_n(r['r2_median'], 4)} / "
                 f"{_n(r['r2_exp_only_median'], 4)} / {_n(r['r2_alg_only_median'], 4)} | {_n(r['corr_lambda_rho_median'], 2)} | "
                 f"{_n(r['window_s_median'], 0)} ({_n(r['window_s_min'], 0)}-{_n(r['window_s_max'], 0)}) |")
    L += ["", "Loop-rate-controlled incremental fits (same windows):", "",
          "| method | T | n | g median | rho declared -> controlled (median [IQR]) | controlled rho CI >0 / <0 | R^2 K+log / K only |",
          "|---|---|---|---|---|---|---|"]
    for m in ("TFO", "FOO", "TFO_full", "TFO_L1600", "FOO_L1600"):
        for T in ("all",) + TEMPS:
            r = _ts(J, "incremental", "delta", m, T)
            if "kc_n" not in r:
                continue
            L.append(f"| {ML2[m]} | {T} | {r['kc_n']} | {_n(r['kc_g_median'])} | {_n(r['rho_median'])} -> "
                     f"{_n(r['kc_rho_median'])} [{_n(r['kc_rho_q25'])}, {_n(r['kc_rho_q75'])}] | {r['kc_n_rho_ci_gt0']}/"
                     f"{r['kc_n_rho_ci_lt0']} | {_n(r['kc_r2_median'], 4)} / {_n(r['kc_r2_K_only_median'], 4)} |")
    tp = fz["methods"]["TFO"]["per_T"]
    L += ["", "l1 kappa1 .. l1 kappa2 of the frozen TFO (1/s): " + "; ".join(
        f"{T} C {_n(tp[str(T)]['hyper']['l1'] * tp[str(T)]['kappa1'])}..{_n(tp[str(T)]['hyper']['l1'] * tp[str(T)]['kappa2'])}"
        for T in TEMPS) + ". e_stop sensitivity (TFO, rho median): " + ", ".join(
            f"{v}: {_n(_ts(J, 'error', f'e_stop_{v:g}', 'TFO', 'all')['rho_median'])}" for v in tf["e_stop_sensitivity"]) +
        ". Median-envelope fits (TFO): " + "; ".join(
            f"{f['T']} C " + (f"lambda_eff {_n(f['lambda_eff'])} [{_n(f['lambda_eff_ci'][0])}, {_n(f['lambda_eff_ci'][1])}], rho "
                              f"{_n(f['rho'])} [{_n(f['rho_ci'][0])}, {_n(f['rho_ci'][1])}], R^2 {_n(f['r2'], 4)}"
                              if f["fitted"] else f"not fitted ({f['n']} samples)")
            for f in J["envelope_fits"] if f["method"] == "TFO") + ".", ""]
    VM = J["voltage_models"]
    pa = J["prior_test_access"]
    L += ["## 6. Open-loop voltage models on the test files", "",
          "Identification parameter sets (causal_full), causal timing, warm start from the end of CV; mean over the 6 files "
          "per temperature. RMSE whole / admissible / z >= 0.1 (mV); lag-1 ACF.", "", "| T | TFO | FO | 2RC |", "|---|---|---|---|"]
    for T in TEMPS:
        fl = [f["file"] for f in J["files"] if f["T"] == T]
        g = lambda fam, k: float(np.mean([VM[f][fam][k] for f in fl]))  # noqa: E731
        L.append(f"| {T} | " + " | ".join(f"{g(fam, 'rmse_mV'):.1f} / {g(fam, 'rmse_admissible_mV'):.1f} / "
                                          f"{g(fam, 'rmse_z_ge_knee_mV'):.1f}; {g(fam, 'acf_lag1'):.2f}" for fam in VM_FAMS) + " |")
    cons = max(VM[f][fam]["consistency_abs_diff_mV"] or 0.0 for f in VM for fam in VM_FAMS)
    lbmax = max(VM[f][fam]["ljung_box_p"] for f in VM for fam in VM_FAMS)
    L += ["", f"Max Ljung-Box p over files and models {lbmax:.2g}; max |RMSE - identification_refined.json| {cons:.1e} mV.", "",
          "**Disclosure (prior access to the test files).** The open-loop voltage accuracy on these test files was first "
          f"computed before the freeze ({pa['frozen_utc']}): in scripts/04_identify.py (results/identification.json, "
          f"{pa['identification_json_generated_utc']}), for all four input-timing conventions, which also used the longest "
          "test record in the FFT unit check; and in scripts/04b_identify_refined.py (test phase started "
          f"{pa['identification_refined_test_phase_started_utc']}, after its validation-file decision). The numbers above "
          "reproduce those values exactly. No parameter set or convention was selected on the test files. The 'causal' "
          "timing convention was fixed on physical grounds, but the test-file wins by convention were visible when it was "
          "fixed. fig_vt_model.pdf and fig_resid_acf.pdf therefore re-display results seen before the freeze. They are "
          "not a first look at unseen data (figure-caption note).", ""]
    return L


def report_tail_sections(J):
    L = ["## 7. Outputs, post hoc items, archive", "",
         "`results/validation_main.json`, `results/validation_series.npz`, `tables/tab_soc_results.tex`, "
         "`figures/fig_soc_test.pdf`, `fig_error_envelopes.pdf`, `fig_vt_model.pdf`, `fig_resid_acf.pdf`. "
         "**Added after the first test run** (reported only, no selection; before the review): first-entry time into "
         "+-2 %; paired tests of the admissible band-keeping and first-entry times; Q_ref sensitivity per temperature; "
         "a 60 s zoom row in fig_vt_model. Whether the incremental tail fit (settings: 'supplementary') predates the "
         "first E1 test run cannot be verified: the settings and code of that run were not archived, and there is no "
         "version control or test-access log. The incremental fit is therefore treated as post hoc. **Added in review "
         "round 1** (config validation_main.review_round_1, all post hoc): file-level inference; per-file censoring; "
         "observer-axis re-scoring and bias; the supplementary and diagnostic methods (L = 1600 s frozen entries, "
         "lambda-only contrasts, EKF-2RC textbook noise); loop-rate-controlled incremental fits; the early tail window; "
         "repeated timing; the failure list; the parameter-bound check. The pre-review script, config, JSON, table and "
         "report are archived with sha256 in `results/archive/E1_pre_review/` (MANIFEST.json). The primary-method "
         "records of this re-run equal the archived ones exactly (checked in the review response).", ""]
    return L


def review_response(J):
    P = lambda c, g="all", met=KM, unit="file", ref="TFO": _pair(J, c, met, g, unit, ref)  # noqa: E731
    O = json.loads((RES / "archive" / "E1_pre_review" / "validation_main.json").read_text(encoding="utf-8"))
    oi = {(r["method"], r["file"], r["scenario"]): r for r in O["records"]}
    dev = max(abs(_f(r[KM]) - _f(oi[(r["method"], r["file"], r["scenario"])][KM])) for r in J["records"] if r["role"] == "primary")
    old = lambda c, g="all": next(r for r in O["paired"] if r["comparator"] == c and r["metric"] == KM and r["group"] == g)  # noqa: E731
    dA = _ts(J, "incremental", "delta", "TFO", "all")
    t45 = _ts(J, "error", "primary", "TFO", 45)
    e45 = _ts(J, "error", "early_t10", "TFO", 45)
    S = {r["method"]: r for r in J["summary"]["by_method"]}
    clipT = {T: int(sum(r["soc_clip_count"] for r in J["records"] if r["method"] == "TFO" and r["T"] == T)) for T in TEMPS}
    L = ["## Review response (round 1)", "",
         "Frozen hyper-parameters were not changed and nothing was re-tuned. The primary-method records of the re-run "
         f"equal the pre-review records (max |difference| of the primary metric {dev:.1e}). Items are listed as reviewer "
         "A (fairness/statistics) and reviewer B (reproducibility), in their order.", "",
         f"* **A1 / B1 (major), pseudo-replication. Accepted.** The file is now the unit of inference: scenario means per "
         f"file, the bootstrap resamples files, the Wilcoxon test is on file values, and per-scenario results are reported "
         f"separately. TFO - EKF-2RC: p {_p(old('EKF2RC')['wilcoxon_p'])} -> {_p(P('EKF2RC')['wilcoxon_p'])}, CI "
         f"[{_n(old('EKF2RC')['ci_lo'])}, {_n(old('EKF2RC')['ci_hi'])}] -> [{_n(P('EKF2RC')['ci_lo'])}, {_n(P('EKF2RC')['ci_hi'])}], "
         f"worse in {P('EKF2RC')['n_b_better']}/18 files. The pre-review claim 'full memory better at 25 C' "
         f"({_n(old('TFO_full', 'T=25')['median_diff'])}, p {_p(old('TFO_full', 'T=25')['wilcoxon_p'])}) becomes "
         f"{_n(P('TFO_full', 'T=25')['median_diff'])} [{_n(P('TFO_full', 'T=25')['ci_lo'])}, {_n(P('TFO_full', 'T=25')['ci_hi'])}], "
         f"p {_p(P('TFO_full', 'T=25')['wilcoxon_p'])}, and is withdrawn. Per-temperature p-values are now bounded below by 0.031.",
         f"* **A2 (major), CC beats TFO with the nominal SOC. Accepted.** This is now key finding 2, with the nominal ranking "
         f"and the per-scenario table. TFO - CC (nominal): median {_n(P('CC', 'scenario=nominal', unit='scenario')['median_diff'])}, "
         f"TFO worse in {P('CC', 'scenario=nominal', unit='scenario')['n_b_better']}/18 files.",
         f"* **A3 (major), 'weak algebraic factor'. Accepted.** The statement is removed. With the loop-rate regressor, g "
         f"{_n(dA['kc_g_median'])} and rho {_n(dA['rho_median'])} -> {_n(dA['kc_rho_median'])} "
         f"({dA['kc_n_rho_ci_gt0']} > 0 / {dA['kc_n_rho_ci_lt0']} < 0), so no algebraic factor is identifiable.",
         "* **A4 (major), Q_ref vs Q_id axis and the confounded full-memory ablation. Accepted.** The per-method bias and the "
         "observer-axis re-scoring are reported (Section 4), and the paired results are given under Q_ref -+ u_Q and on "
         "the observer axis. Finding 6 now calls TFO vs TFO (full) reference-dependent and confounded, and adds the "
         f"clean L = 1600 s ablation (TFO(400) - TFO(1600) median {_n(P('TFO_L1600')['median_diff'])}, p "
         f"{_p(P('TFO_L1600')['wilcoxon_p'])}).",
         f"* **A5 (minor), EKF-2RC 25 C exception. Accepted as a disclosure.** EKF-2RC was not mis-configured: it used the "
         "same equal-budget validation-only procedure as every method, and its bound hits are recorded in the freeze. It "
         "is therefore not re-tuned and not re-frozen. Its failures are listed, and the untuned textbook-noise diagnostic "
         f"is reported: TFO - EKF-2RC(textbook) worse in {P('EKF2RC_textbook')['n_b_better']}/18 files.",
         "* **A6 (minor), median ranking, per-file failures, worst case. Accepted** (key finding 1, Section 1).",
         f"* **A7 (minor), lambda-only contrast. Accepted.** TFO - TFO(lambda := 0) median {_n(P('TFO_lam0')['median_diff'])}, "
         f"worse in {P('TFO_lam0')['n_b_better']}/18 files.",
         "* **A8 / B6 (minor), 'best method under Q_ref - u_Q'. Accepted.** Replaced by paired results under each reference.",
         "* **A9 / B7 (minor), CPU resolution. Accepted.** The per-run process column is removed. Section 1 reports the "
         "aggregated process time with its resolution and repeated perf_counter timings.",
         "* **A10 (minor), convergence censoring and naming. Accepted.** Never-converged runs are censored at each file's "
         "duration + 1 s. The admissible last-exit metric is renamed 'band-keeping time', and first entry is kept as the "
         "post hoc transient metric.",
         f"* **A11 (minor), FOEKF at 45 C. Accepted.** Qualified as practically equal (median {_n(P('FOEKF', 'T=45')['median_diff'])}).",
         "* **B2 (minor), incomplete exceptions. Accepted.** All temperature, profile and scenario subgroups are scanned. "
         "Subgroups where the CI and p disagree are flagged (key finding 4).",
         "* **B3 (minor), prior test-file access. Accepted.** Disclosure added (Section 6).",
         "* **B4 (minor), settings archive. Partly accepted.** The pre-review state is archived with hashes. The first E1 "
         "test run cannot be reconstructed, which is stated in Section 7. The incremental fit is treated as post hoc, and "
         "first-entry times are flagged as post hoc in finding 7.",
         f"* **B5 (minor), 45 C tail fits. Accepted.** n_fitted is shown in finding 7 ({t45['n_fitted']}/{t45['n_runs']} at 45 C). "
         f"The post-hoc early-window sensitivity fits {e45['n_fitted']}/{e45['n_runs']} with a median window of "
         f"{_n(e45['window_s_median'], 0)} s.",
         f"* **B8 (minor), clipping and the certified interval. Accepted.** Section 1 now has the clip and outside-interval "
         f"counts. TFO clip samples by temperature: " + ", ".join(f"{T} C {clipT[T]}" for T in TEMPS) +
         f" (total {int(S['TFO']['soc_clip_count_sum'])}).",
         "* **B9 (minor), declared whole_conv_time_s omitted. Accepted.** It is restored in Section 2.",
         "* **B10 (minor), parameters at bounds. Accepted.** Reported in Section 3. The frozen file is not edited, because "
         "renaming its fields would change the recorded sha256.", ""]
    return L


def write_report(J):
    rt = J["runtime"]
    L = ["# Main test-set comparison (E1), revised after review round 1", "",
         f"Generated by `scripts/06_validate.py` from `results/validation_main.json` ({J['generated_utc']}, code hash "
         f"{J['code_hash']}, task {J['task_version']}). Frozen configuration `results/frozen_config.json` (frozen "
         f"{J['frozen_config']['frozen_utc']}, sha256 {J['frozen_config']['sha256'][:16]}); no parameter or hyper-parameter "
         f"changed. {len(J['files'])} test files, all passed data.verify_file: {J['all_files_verified']}. {len(J['records'])} "
         f"runs: 8 primary methods and {len(SUPP)} supplementary/diagnostic methods x 18 files x 3 initial-SOC scenarios, "
         f"clean signals. Runtime: main wall {rt['main_wall_s']:.1f} s, main process {rt['main_process_s']:.1f} s, "
         f"worker process sum {rt['worker_process_s_sum']:.1f} s ({rt['workers']} workers); the timing benchmark adds "
         f"{J['timing']['run']['wall_s']:.1f} s wall.", "",
         "Windows: *whole* = all samples; *admissible* = reference SOC in [0.10, 0.95], the interval of the certificate's "
         "slope bounds, which is PRIMARY for certified claims; *post* = t >= 600 s. Primary metric = admissible "
         "post-convergence SOC RMSE (% SOC). TFO = lambda 1e-4 1/s, L = 400 s; FOO = lambda 0, L = 400 s; (full) = the "
         "same parameters and gains with full memory. Paired differences are TFO minus comparator (positive = TFO "
         "worse). **Unit of inference = test file** (n = 18; 6 per temperature or profile). The three initial-SOC "
         "scenarios of a file are near-replicates after t = 600 s and are never counted as independent.", ""]
    L += key_findings(J) + report_sections(J) + report_tails_vm(J) + report_tail_sections(J) + review_response(J)
    (REP / "validation_main_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def make_outputs():
    J, Z = load_outputs()
    write_table(J)
    fig_soc(J, Z)
    fig_envelopes(J, Z)
    fig_vt(J, Z)
    fig_acf(J, Z)
    write_report(J)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report-only", action="store_true")
    ap.add_argument("--compute-only", action="store_true")
    a = ap.parse_args()
    _, vm, _ = cfg()
    if not a.report_only:
        compute(int(vm["max_workers"]))
    if not a.compute_only:
        make_outputs()


if __name__ == "__main__":
    main()
