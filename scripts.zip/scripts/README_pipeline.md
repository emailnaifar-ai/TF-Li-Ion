# Pipeline scripts

Run from the project root. `python scripts/reproduce_all.py` runs the numbered steps in order (see its `--help`);
`python scripts/09_figures_tables.py` rebuilds every manuscript figure and table from `results/` alone.

Runtimes are the wall times recorded by the scripts themselves in their result files (field named in the last
column), on the machine described in `results/machine.json` (Intel Core Ultra 9 288V, 8 physical cores, Windows 11,
Python 3.12.10), with other analyses running at the same time. They are indicative only. "Resumed" means the
recorded run reused cached per-task results, so its main wall time is shorter than a run from an empty cache; the
worker process times summed over tasks are then the better measure of the work.

| Step | Script | Reads | Writes | Recorded runtime (source) |
|---|---|---|---|---|
| 00 | `00_convert_raw.py` | `data_raw/*/*.xls(x)` (extracted CALCE archives) | `data_processed/*.csv`, `data_manifest.json` | not recorded |
| 01 | `01_audit.py` (`--tables-only`) | `data_processed/`, `data_manifest.json` | `results/dataset_inventory.json`, `results/capacity.json`, `reports/dataset_audit.md`, `reports/A_dataset_audit_report.md` (section 6), `tables/tab_dataset_inventory.tex`, `tables/tab_split_assignment.tex` | not recorded |
| 02 | `02_ocv.py` (calls `02b_ocv_report.py`) | incremental-OCV and initial-capacity files (SP1, SP3); net Ah of `SP2_*_DST_80SOC` | `results/ocv_fits.json`, `results/ocv_curves.npz`, `tables/tab_ocv.tex`, `figures/draft_ocv_*.pdf`, `reports/ocv_findings.md` | 132 s (`ocv_fits.json: runtime_s`) |
| 02b | `02b_ocv_report.py` | `results/ocv_fits.json`, `results/archive/ocv_fits_pre_review.json` | `reports/ocv_findings.md` | < 1 s (not recorded) |
| 03 | `03_relaxation.py` (`--from-results`) | 2 h rests of the six OCV files | `results/relaxation_phenomenological.json`, `results/relaxation_mechanistic.json`, `results/relaxation_curves.npz`, `tables/tab_relax_{ic,params,design}.tex`, `figures/draft_relax_*.pdf`, `reports/relaxation_findings.md` | 1349 s (`relaxation_*.json: meta.wall_time_s`) |
| 04 | `04_identify.py` (`--resume`, `--from-results`) | identification files `SP2_*_DST_80SOC`; validation/test files for open-loop accuracy | `results/identification.json`, `results/identification_arrays.npz`, `results/identification_runs/`, `tables/tab_params.tex`, `tables/tab_vmodel.tex`, `figures/fig_ident_*.pdf`, `figures/fig_vmodel_*.pdf`, `reports/identification_findings.md` | 3349 s, 6 workers (`identification.json: runtime.full_run_wall_s`) |
| 04b | `04b_identify_refined.py` (`--resume`, `--from-results`) | as 04, `results/identification.json` | `results/identification_refined.json`, `results/identification_refined_arrays.npz`, `results/identification_refined_runs/`, `figures/draft_p1_*.pdf`, `reports/identification_refined_findings.md` | 692 s resumed; 1156 s worker CPU (`identification_refined.json: runtime`) |
| 04c | `04c_memory_identification.py` (`--resume`) | identification and validation files | `results/identification_memory.json`, `results/identification_memory_runs/`; regenerates the 04b report | 1628 s, 2 workers; 2764 s worker CPU (`identification_memory.json: runtime`) |
| 05 | `05_design_tune.py` (`--report-only`) | validation files `SP2_*_DST_50SOC`, results of 04b/04c | `results/gain_design.json`, `results/tuning.json`, `results/frozen_config.json`, `tables/tab_hyper.tex`, `figures/draft_p2_*.pdf`, `reports/tuning_findings.md` | 528 s, 2 workers (`gain_design.json: runtime.main_wall_s`) |
| 06 | `06_validate.py` (`--report-only`) | the 18 test files, `results/frozen_config.json` | `results/validation_main.json`, `results/validation_series.npz`, `tables/tab_soc_results.tex`, `figures/fig_soc_test.pdf`, `fig_error_envelopes.pdf`, `fig_vt_model.pdf`, `fig_resid_acf.pdf`, `reports/validation_main_findings.md` | 41 s, 2 workers (`validation_main.json: runtime.main_wall_s`) |
| 06b | `06b_robustness.py` (`--report-only`) | the 18 test files, frozen configuration; per-file cache `scratch/robustness_cache/` | `results/robustness.json`, `tables/tab_robustness.tex`, `figures/fig_robustness.pdf`, `reports/robustness_findings.md` | 468 s, 2 workers; 885 s summed worker wall (`robustness.json: timing`) |
| 07 | `07_ablation.py` (`--report-only`) | identification, validation and test files; frozen configuration | `results/ablation.json`, `results/ablation_runs/`, `tables/tab_ablation.tex`, `figures/fig_rmse_memory.pdf`, `fig_sensitivity.pdf`, `fig_params_temperature.pdf`, `reports/ablation_findings.md` | 185 s with cached tasks; 1706 s worker CPU (`ablation.json: runtime`) |
| 08 | `08_cost.py` (`--outputs`) | validation file `SP2_25C_DST_50SOC` (+ 0/45 C checks), frozen configuration | `results/cost.json`, `results/machine.json`, `results/cost_outputs.json`, `tables/tab_cost.tex`, `figures/fig_cost_memory.pdf`, `reports/cost_findings.md` | 1198 s wall, 979 s CPU, 1 process (`cost.json: runtime`) |
| 09 | `09_figures_tables.py` (`--only`, `--png`, `--list`) | `results/*.json`, `results/*.npz`, `config/config.yaml`; for `tab_hyper` one nominal run per method on the validation files (state size) | all 14 manuscript figures and all generated tables (list: `reports/figure_table_manifest.md`) | 33 s (measured 2026-09-27, this machine) |
| 09a | `09a_figs_ocv_relax.py` (`--png`) | `results/ocv_*`, `results/relaxation_*` | `figures/fig_ocv.pdf`, `fig_relax.pdf`, `fig_relax_acf.pdf` (also built by 09) | about 6 s (09 log) |
| aux | `p0_timing_alignment.py` | validation file `SP2_25C_DST_50SOC`, `results/identification.json` | `results/timing_alignment.json` | 8 s (`timing_alignment.json: wall_s`) |
| aux | `estimator_timing.py` | synthetic data | `results/estimator_timing.json` | not recorded |
| aux | `estimator_review_checks.py` | synthetic data, validation files | `results/estimator_review_checks.json` | 19 s (`estimator_review_checks.json: runtime_s`) |
| aux | `estimators_notes_build.py` | the two JSON files above, `pytest tests/test_estimators.py` | `reports/estimators_notes.md` | not recorded |

Recorded wall times of the numbered steps add up to about 9.6e3 s (2.7 h); the pipeline has not been timed end to end.

## Figure code

The analysis scripts keep their figure functions; `09_figures_tables.py` imports them and calls them on the saved
results, so each manuscript figure has one code path. The optimiser figure (`fig:optimizers`) is defined in
`09_figures_tables.py` and called from `04_identify.py`. All figures use `src/tfso/plotstyle.py`: text width
169.3 mm, 8 pt tick and legend text, fixed colour, dash and marker per method (TFO, FOO, FOEKF, EKF-2RC, AEKF-2RC,
CC) and per model family (tempered fractional, fractional, 2RC use the colours of TFO, FOO and EKF-2RC).

## Table writers

Every generated table is written by a function of its analysis script (`write_table`, `make_tables`,
`make_table`, `tables_only`); `09_figures_tables.py` calls these functions on the saved results. The table layouts
were changed on 2026-09-27 to fit the text width of the article class with 0.8 in margins without scaling (booktabs,
siunitx S columns for plain numeric columns, two-line cells for intervals); the printed numbers did not change
(checked number by number against the previous files). Each data row carries a `% src:` comment naming the result
field.

Side effect to note: `05_design_tune.py` and `06_validate.py` include their own source file in their `code_hash`,
and `07_ablation.py` includes `05_design_tune.py` in its cache key. The format change of the table writers therefore
changed these hashes: the `code_hash` stored in `results/gain_design.json`, `results/tuning.json`,
`results/validation_main.json` and `results/ablation.json` refers to the scripts before the change, and a full
re-run of step 07 recomputes its cached tasks in `results/ablation_runs/` instead of reusing them. The `--report-only`
and `--from-results` modes are not affected (the per-file cache of 06b hashes only the computation part of 06b and
is still valid).

## Seeds and time measurement

All seeds are in `config/config.yaml` (bootstrap, multi-start, Sobol and (1+1)-ES tuning, Monte-Carlo noise,
shuffled timing order); the point jitter of `fig:optimizers` uses a fixed seed (0). Wall times are
`time.perf_counter`; CPU times are `time.process_time` of the process concerned (worker CPU = sum over worker
tasks). The per-sample estimator costs of Table `tab:cost` are `time.process_time` over the estimation loop only
(see `scripts/08_cost.py`).
