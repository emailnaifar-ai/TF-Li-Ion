"""Manuscript figures for Section 5.1-5.2 (OCV-SOC slope bounds, relaxation-tail analysis).

Rebuilds from results/ only (no raw data, no refitting):
    results/ocv_fits.json, results/ocv_curves.npz                    -> figures/fig_ocv.pdf
    results/relaxation_phenomenological.json, results/relaxation_curves.npz
                                                                      -> figures/fig_relax.pdf, figures/fig_relax_acf.pdf
Style: src/tfso/plotstyle.py (journal style shared by all figure scripts).
Run:   python scripts/09a_figs_ocv_relax.py [--png]   (--png also writes 200 dpi previews next to the PDFs)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import plotstyle as ps  # noqa: E402
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter  # noqa: E402

RES = ROOT / "results"
FIG = ROOT / "figures"
TEMPS = (0, 25, 45)
CELLS = ("SP1", "SP3")
CELL_NAME = {"SP1": "SP1", "SP3": "SP3"}   # abbreviations of Section 2 (file names: SP20-1, SP20-3)


def _load_json(name: str) -> dict:
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _config_interval() -> list:
    """Admissible SOC interval of the observer (config.yaml: model.soc_interval)."""
    import yaml
    with open(ROOT / "config" / "config.yaml", "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    return [float(v) for v in cfg["model"]["soc_interval"]]


# ================================================================================================================
# fig_ocv: OCV-SOC points and curves (top) and dU/dz with kappa_1, kappa_2 on the admissible interval (bottom)
# ================================================================================================================
def fig_ocv(plt) -> Path:
    R = _load_json("ocv_fits.json")
    Z = np.load(RES / "ocv_curves.npz")
    q_sp2 = float(R["axis"]["Q_SP2_25C_Ah"])
    zadm = _config_interval()
    lab = f"[{zadm[0]:.2f},{zadm[1]:.2f}]"
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 112), sharex=True, sharey="row",
                            layout="constrained",
                            gridspec_kw=dict(height_ratios=[1.25, 1.0]))
    ymax_slope = 0.0
    for j, T in enumerate(TEMPS):
        sel = R["selected"]["per_temperature"][str(T)]
        q_axis = float(sel["Q_axis_Ah"])
        blk = next(b for b in sel["intervals"] if b["label"] == lab)
        k1, k2 = float(blk["kappa1_envelope_min_V_per_soc"]), float(blk["kappa2_envelope_max_V_per_soc"])
        a0, a1 = axs[0, j], axs[1, j]
        # ---- top: U_oc(z) and relaxed points mapped to the observer axis z = 1 - x Q_SP2,25 / Q_id(T) ----
        a0.axvspan(*zadm, color=ps.SHADE, lw=0, zorder=0)
        a0.plot(Z[f"T{T}_z"], Z[f"T{T}_U_z"], color=ps.INK, lw=ps.LW["data"], zorder=3)
        # SP3 (open squares, larger) first, SP1 (small filled circles) on top, so that both stay visible
        for c, ms, zo in (("SP3", 4.6, 4), ("SP1", 2.6, 5)):
            for br, col in (("discharge", ps.SERIES["discharge"]["color"]), ("charge", ps.SERIES["charge"]["color"]),
                            ("full", ps.INK)):
                x = Z[f"T{T}_{c}_{br}_x"]
                U = Z[f"T{T}_{c}_{br}_U"]
                z = 1.0 - x * q_sp2 / q_axis
                a0.plot(z, U, zorder=zo, **ps.points(color=col, marker=ps.CELL_MARKER[c], filled=ps.CELL_FILLED[c],
                                                     ms=ms, mew=0.8 if c == "SP3" else 0.0))
        a0.set_xlim(-0.06, 1.04)
        a0.set_ylim(3.0, 4.25)
        ps.note(a0, f"{T} °C", x=0.04, y=0.96, ha="left")
        if j == 0:
            a0.set_ylabel(r"relaxed OCV $U_\mathrm{oc}$ (V)")
        # ---- bottom: dU/dz ----
        z = Z[f"T{T}_z"]
        a1.axvspan(*zadm, color=ps.SHADE, lw=0, zorder=0)
        for c, ls in zip(CELLS, (":", "-.")):
            a1.plot(z, Z[f"T{T}_dUdz_{c}_only"], color=ps.MUTED, lw=0.8, ls=ls, zorder=2)
        a1.plot(z, Z[f"T{T}_dUdz_rep_mono_spline_pooled"], color=ps.MUTED, lw=0.9, ls="--", zorder=2)
        a1.plot(z, Z[f"T{T}_dUdz"], color=ps.INK, lw=ps.LW["data"], zorder=3)
        for kv, col in ((k1, ps.SLOTS[0]), (k2, ps.SLOTS[1])):
            a1.hlines(kv, zadm[0], zadm[1], colors=col, lw=1.0, ls=(0, (4, 2)), zorder=4)
        a1.text(0.75, k1 + 0.05, rf"$\kappa_1 = {k1:.3f}$", color=ps.INK, ha="center", va="bottom", fontsize=8,
                bbox=dict(facecolor="white", edgecolor="none", pad=0.6, alpha=0.85), zorder=5)
        a1.text(0.55, k2 + 0.06, rf"$\kappa_2 = {k2:.2f}$", color=ps.INK, ha="center", va="bottom", fontsize=8,
                bbox=dict(facecolor="white", edgecolor="none", pad=0.6, alpha=0.85), zorder=5)
        ymax_slope = max(ymax_slope, float(np.nanmax(Z[f"T{T}_dUdz"])), k2)
        a1.set_xlabel(r"SOC $z$")
        if j == 0:
            a1.set_ylabel(r"$\partial U_\mathrm{oc}/\partial z$ (V per unit SOC)")
    axs[1, 0].set_ylim(0.0, 1.12 * ymax_slope)
    for k, ax in enumerate(axs.ravel()):
        ps.panel_label(ax, k)
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    dot = dict(ls="none", marker="o", ms=4.5)
    h = [Line2D([], [], color=ps.SERIES["discharge"]["color"], **dot),
         Line2D([], [], color=ps.SERIES["charge"]["color"], **dot),
         Line2D([], [], color=ps.INK, **dot),
         Line2D([], [], color=ps.INK2, mfc=ps.INK2, ls="none", marker="o", ms=3.0, mew=0.0),
         Line2D([], [], color=ps.INK2, ls="none", marker="s", ms=4.6, mfc="white", mew=0.8),
         Line2D([], [], color=ps.INK, lw=ps.LW["data"]),
         Line2D([], [], color=ps.MUTED, lw=0.9, ls="--"),
         Line2D([], [], color=ps.MUTED, lw=0.8, ls=":"),
         Line2D([], [], color=ps.MUTED, lw=0.8, ls="-."),
         Line2D([], [], color=ps.SLOTS[0], lw=1.0, ls=(0, (4, 2))),
         Line2D([], [], color=ps.SLOTS[1], lw=1.0, ls=(0, (4, 2))),
         Patch(facecolor=ps.SHADE, edgecolor="none")]
    lbl = ["discharge branch", "charge branch", "rest after CV phase", "SP1", "SP3", "selected (PCHIP, mean of cells)",
           "tied representation", "SP1 only", "SP3 only", r"$\kappa_1$ (envelope)", r"$\kappa_2$ (envelope)",
           f"admissible interval [{zadm[0]:.2f}, {zadm[1]:.2f}]"]
    fig.legend(h, lbl, loc="outside lower center", ncol=4, handlelength=2.4, columnspacing=1.6)
    return ps.save(fig, FIG / "fig_ocv.pdf")


# ================================================================================================================
# fig_relax: representative rests with PL / EXP / TPL fits (linear, log-log, residuals) and TPL lambda vs SOC and T
# ================================================================================================================
def fig_relax(plt) -> Path:
    P = _load_json("relaxation_phenomenological.json")
    A = np.load(RES / "relaxation_curves.npz")
    seg = {f["logical_id"]: f for f in P["segments"]}
    show = [lid for T in TEMPS for lid in seg if seg[lid]["temperature_C"] == T and seg[lid]["cell"] == "SP20-1"]
    models = ("PL", "EXP", "TPL")
    names = {"PL": "power law (PL)", "EXP": "exponential (EXP)", "TPL": "tempered power law (TPL)"}
    t0 = float(P["meta"]["settings"]["t0_s"])
    fig = plt.figure(figsize=ps.figsize("text", 190), layout="constrained")
    gs = fig.add_gridspec(4, 3, height_ratios=[1.0, 1.0, 0.72, 1.05])
    axs = np.empty((4, 3), dtype=object)
    for j, lid in enumerate(show):
        p = f"fits__{lid}__"
        tf, yf, ts, ys, tg = A[p + "t_full"], A[p + "V_full_mV"], A[p + "t_sub"], A[p + "V_sub_mV"], A[p + "t_grid"]
        si = int(A[p + "seg_index"])
        meta = seg[lid]["rests"][si]["meta"]
        vinf = float(A[p + "TPL_Vinf_mV"])
        ax = axs[0, j] = fig.add_subplot(gs[0, j])
        ax.plot(tf, yf, color=ps.MUTED, lw=2.4, alpha=0.55, solid_capstyle="butt", zorder=1)
        for m in models:
            ax.plot(tg, A[p + f"{m}_grid_mV"], **ps.line(m), zorder=3)
        ax.set_xlim(0, tf[-1] * 1.01)
        ax.set_xlabel(r"time since interruption $t$ (s)")
        ps.note(ax, f"{seg[lid]['temperature_C']} °C, SP1, {meta['branch']} rest\n"
                    rf"$z_\mathrm{{r}}$ = {meta['soc_label']:.1f}, window [{t0:.0f} s, $t_\mathrm{{end}}$]",
                x=0.97, y=0.05, ha="right", va="bottom")
        ax = axs[1, j] = fig.add_subplot(gs[1, j])
        ax.loglog(ts, np.abs(ys - vinf), zorder=4, **ps.points(color=ps.INK2, marker="o", filled=False, ms=2.8))
        for m in models:
            ax.loglog(tg, np.abs(A[p + f"{m}_grid_mV"] - vinf), **ps.line(m), zorder=3)
        ax.set_ylim(bottom=max(0.05, 0.3 * float(np.min(np.abs(ys - vinf)[np.abs(ys - vinf) > 0]))))
        # labelled ticks inside each decade when the panel spans few decades, so that every panel has several
        # readable labels (1, 2, 5 x 10^k below 1.6 decades; 1, 3 x 10^k below 2.6 decades; powers of ten otherwise)
        lo, hi = ax.get_ylim()
        dec = np.log10(hi / lo)
        subs = (1.0, 2.0, 5.0) if dec < 1.6 else ((1.0, 3.0) if dec < 2.6 else (1.0,))
        ax.yaxis.set_major_locator(LogLocator(base=10, subs=subs, numticks=12))
        ax.yaxis.set_minor_locator(LogLocator(base=10, subs=tuple(v for v in range(2, 10) if v not in subs),
                                              numticks=12))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
        ax.yaxis.set_minor_formatter(NullFormatter())
        ax.set_xlabel(r"$t$ (s)")
        ax = axs[2, j] = fig.add_subplot(gs[2, j])
        for m in models:
            ax.semilogx(ts, A[p + f"{m}_resid_sub_mV"], **ps.line(m, lw=0.9))
        ax.axhline(0, color=ps.INK2, lw=ps.LW["thin"])
        ax.set_xlabel(r"$t$ (s)")
    axs[0, 0].set_ylabel(r"$V_t - V_t(t_\mathrm{end})$ (mV)")
    axs[1, 0].set_ylabel(r"$|V_t - \hat V_\infty^\mathrm{TPL}|$ (mV)")
    axs[2, 0].set_ylabel("residual (mV)")
    # ---- row 4: TPL lambda-hat with ACF-block bootstrap 95 % intervals vs SOC label, one panel per temperature ----
    thr = float(P["meta"]["settings"]["lambda_zero_threshold_s_inv"])
    T_, prim = A["lam__seg_T"], A["lam__seg_primary"] == 1
    t_end = float(np.median([seg[l]["rests"][int(A[f"fits__{l}__seg_index"])]["meta"]["rest_duration_s"] for l in show]))
    for j, T in enumerate(TEMPS):
        ax = axs[3, j] = fig.add_subplot(gs[3, j])
        for br, brname in ((0, "discharge"), (1, "charge")):
            for c, cname in ((1, "SP1"), (3, "SP3")):
                m = (T_ == T) & (A["lam__seg_branch"] == br) & (A["lam__seg_cell"] == c) & prim
                if not m.any():
                    continue
                x = A["lam__seg_soc"][m] + (-0.012 if c == 1 else 0.012)
                y = A["lam__seg_lam"][m]
                err = np.vstack([y - A["lam__seg_lo"][m], A["lam__seg_hi"][m] - y]).clip(min=0)
                col = ps.SERIES[brname]["color"]
                ax.errorbar(x, y, yerr=err, fmt=ps.CELL_MARKER[cname], ms=3.8, color=col,
                            mfc=col if ps.CELL_FILLED[cname] else "white", mec=col, mew=0.8, elinewidth=0.7,
                            capsize=0, zorder=3)
        ax.axhline(1.0 / t_end, color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)), zorder=2)
        ax.set_yscale("symlog", linthresh=thr, linscale=0.6)
        ax.set_ylim(-0.3 * thr, 0.05)
        ax.set_yticks([0, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2])
        ax.set_xlim(-0.02, 1.02)
        ax.set_xlabel(r"SOC label of the rest $z_\mathrm{r}$")
        ps.note(ax, f"{T} °C", x=0.97, y=0.96)
        if j == 0:
            ax.set_ylabel(r"TPL $\hat\lambda$ (s$^{-1}$)")
    for k, ax in enumerate(axs.ravel()):
        ps.panel_label(ax, k)
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=ps.MUTED, lw=2.4, alpha=0.55)] + [Line2D([], [], **ps.line(m)) for m in models]
    h += [Line2D([], [], **ps.points(color=ps.INK2, marker="o", filled=False, ms=2.8))]
    lbl = ["measured"] + [names[m] for m in models] + ["log-spaced subsample"]
    fig.legend(h, lbl, loc="outside upper center", ncol=5, handlelength=2.4, columnspacing=1.0)
    dot = dict(ls="none", marker="o", ms=4.5)
    h2 = [Line2D([], [], color=ps.SERIES["discharge"]["color"], **dot),
          Line2D([], [], color=ps.SERIES["charge"]["color"], **dot),
          Line2D([], [], color=ps.INK2, **dot),
          Line2D([], [], color=ps.INK2, ls="none", marker="s", ms=4.5, mfc="white", mew=0.9),
          Line2D([], [], color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)))]
    fig.legend(h2, ["rest after discharge pulse", "rest after charge pulse", "SP1", "SP3",
                    r"$1/t_\mathrm{end}$"], loc="outside lower center", ncol=5)
    return ps.save(fig, FIG / "fig_relax.pdf")


# ================================================================================================================
# fig_relax_acf: median residual autocorrelation per law and temperature
# ================================================================================================================
def fig_relax_acf(plt) -> Path:
    A = np.load(RES / "relaxation_curves.npz")
    models = ("PL", "EXP", "TPL", "2EXP", "SEXP")
    fig, axs = plt.subplots(1, 3, figsize=ps.figsize("text", 66), sharey=True, layout="constrained")
    for j, T in enumerate(TEMPS):
        ax = axs[j]
        lags = np.arange(len(A[f"acf__T{T}__PL_median"]))
        ax.fill_between(lags, A[f"acf__T{T}__TPL_q25"], A[f"acf__T{T}__TPL_q75"], color=ps.SERIES["TPL"]["color"],
                        alpha=0.15, lw=0, zorder=1)
        for m in models:
            ax.plot(lags, A[f"acf__T{T}__{m}_median"], **ps.line(m, lw=1.1), zorder=3)
        ax.plot(lags, A[f"acf__T{T}__mech_shared_median"], color=ps.INK, lw=1.1, zorder=3)
        ax.axhline(0, color=ps.INK2, lw=ps.LW["thin"])
        ax.set_xlim(0, lags[-1])
        lo = min(float(np.min(A[f"acf__T{t}__{m}_median"])) for t in TEMPS for m in models)
        ax.set_ylim(np.floor(10 * lo) / 10 - 0.02, 1.02)
        ax.set_xlabel("lag (subsample points)")
        ps.note(ax, f"{T} °C, {int(A[f'acf__T{T}__n_segments'])} rests", x=0.97, y=0.97)
        ps.panel_label(ax, j)
    axs[0].set_ylabel("residual autocorrelation")
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    h = [Line2D([], [], **ps.line(m, lw=1.1)) for m in models] + [Line2D([], [], color=ps.INK, lw=1.1),
                                                                   Patch(facecolor=ps.SERIES["TPL"]["color"], alpha=0.15)]
    lbl = list(models) + ["tempered element (shared gain)", "TPL interquartile range"]
    fig.legend(h, lbl, loc="outside lower center", ncol=4, handlelength=2.4, columnspacing=1.6)
    return ps.save(fig, FIG / "fig_relax_acf.pdf")


def main() -> None:
    plt = ps.setup()
    outs = [fig_ocv(plt), fig_relax(plt), fig_relax_acf(plt)]
    plt.close("all")
    for o in outs:
        print(f"[write] {o.relative_to(ROOT)}")
        if "--png" in sys.argv:   # previews go to a scratch folder, not to figures/
            prev = ROOT / "scratch" / "figure_previews" / (o.stem + ".png")
            prev.parent.mkdir(parents=True, exist_ok=True)
            print(f"[preview] {ps.preview_png(o, out=prev).relative_to(ROOT)}")


if __name__ == "__main__":
    main()
