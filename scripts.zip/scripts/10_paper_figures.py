"""Figures of the SHORT paper (manuscript.tex), rebuilt from saved results only (no experiment is re-run).

Contract (label -> file; sources):
    fig:arch    figures/paper_fig1_architecture.tex  hand-written TikZ (compact version of fig_architecture.tex)
    fig:relax   figures/paper_fig2_relaxation.pdf    relaxation_curves.npz, relaxation_phenomenological.json,
                                                     relaxation_mechanistic.json (synthetic_control)
    fig:soc     figures/paper_fig3_soc.pdf           validation_series.npz, validation_main.json
    fig:memory  figures/paper_fig4_memory.pdf        ablation.json (figure_data.memory, test.rows), cost.json (facts only)
    fig:robust  figures/paper_fig5_robustness.pdf    robustness.json (summary)

Final review: Fig. 4 and Fig. 5 have two panels (the CPU-cost and parameter-mismatch panels duplicated columns of
Table 3 and were removed); Fig. 2(b) row labels name the synthetic untempered controls; Fig. 2(c) legend sits
above the data; Fig. 3(a) names the record and the initial-SOC scenario.

Layout: one row of three (Figs. 2-3) or two (Figs. 4-5) panels, width 6.67 in (text width of the A4 / 0.8 in article class), height 2.25 in,
all text 8 pt, so the PDFs are included at natural size (width=\\textwidth). Colours follow src/tfso/plotstyle.py
(one colour, dash and marker per estimator in every figure). Semantic rule of the short paper: blue = tempered
(TFO, TPL, lambda > 0), orange = untempered fractional (FOO, PL, lambda = 0).

Usage (project root):  python scripts/10_paper_figures.py [--only 2,3,4,5] [--png DIR]   (--png: 200 dpi previews in DIR)
Without the CALCE data (public copy), figure 2 is skipped with a message and figures 3-5 are rebuilt.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import plotstyle as ps  # noqa: E402

RES, FIG = ROOT / "results", ROOT / "figures"
TEMPS = (0, 25, 45)
W_IN, H_IN = 6.67, 2.25
SEED = 20260927
METHODS = ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC")
MLAB = {"TFO": "TFO", "FOO": "FOO", "FOEKF": "FOEKF", "EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC", "CC": "CC"}
# relaxation laws: tempered = blue, untempered power law = orange (same meaning as TFO / FOO)
LAW = {"TPL": dict(color=ps.SLOTS[0], ls="-", marker="o"), "PL": dict(color=ps.SLOTS[1], ls="--", marker="s"),
       "EXP": dict(color=ps.SLOTS[2], ls=":", marker="v"), "2EXP": dict(color=ps.SLOTS[3], ls="-.", marker="^"),
       "SEXP": dict(color=ps.SLOTS[4], ls=(0, (5, 1.5, 1, 1.5, 1, 1.5)), marker="D")}
LAWLAB = {"TPL": "tempered power law", "PL": "power law", "EXP": "exponential", "2EXP": "two exponentials",
          "SEXP": "stretched exp."}
# lambda grid of the memory study: lambda = 0 in the FOO colour, lambda > 0 on an ordinal blue ramp (steps 250-700)
LAM_COL = {0.0: ps.SLOTS[1], 1e-4: "#86b6ef", 3e-4: "#5598e7", 1e-3: "#2a78d6", 3e-3: "#1c5cab", 1e-2: "#0d366b"}
FACTS: dict = {}          # derived numbers shown in the figures -> results/paper_figures.json (for '% src' comments)
LAM_MK = {0.0: "s", 1e-4: "o", 3e-4: "^", 1e-3: "D", 3e-3: "v", 1e-2: "P"}


def setup():
    plt = ps.setup()
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8, "xtick.labelsize": 8,
                         "ytick.labelsize": 8, "legend.fontsize": 8, "legend.handlelength": 2.2,
                         "legend.labelspacing": 0.3, "legend.handletextpad": 0.5, "legend.borderpad": 0.2,
                         "figure.constrained_layout.w_pad": 0.02, "figure.constrained_layout.h_pad": 0.02,
                         "figure.constrained_layout.wspace": 0.06})
    return plt


def row(plt, width_ratios=(1, 1, 1)):
    fig, axs = plt.subplots(1, len(width_ratios), figsize=(W_IN, H_IN), layout="constrained",
                            gridspec_kw=dict(width_ratios=list(width_ratios)))
    return fig, axs


def label(ax, k):
    ax.text(-0.01, 1.02, f"({chr(97 + k)})", transform=ax.transAxes, ha="right", va="bottom", fontsize=8,
            color=ps.INK, fontweight="bold")


def js(name):
    with open(RES / name, encoding="utf-8") as fh:
        return json.load(fh)


def plain(ax, axis="x"):
    from matplotlib.ticker import FuncFormatter, NullFormatter
    a = ax.xaxis if axis == "x" else ax.yaxis
    a.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    a.set_minor_formatter(NullFormatter())


def pts(m, ms):
    """Marker keywords of a method; unfilled glyphs (CC 'x') keep their colour as edge."""
    s = ps.SERIES[m]
    if s["marker"] in ("x", "+", "|", "_"):
        return dict(marker=s["marker"], ms=ms, mec=s["color"], mew=1.0)
    return dict(marker=s["marker"], ms=ms, mfc=s["color"], mec="white", mew=0.4)


def mstyle(m):
    s = ps.SERIES[m]
    return dict(color=s["color"], ls=s["ls"], marker=s["marker"])


# ================================================================================================================
# Fig. 2  relaxation-tail test
# ================================================================================================================
def fig2(plt):
    A = np.load(RES / "relaxation_curves.npz")
    P = js("relaxation_phenomenological.json")
    M = js("relaxation_mechanistic.json")
    t0 = float(P["meta"]["settings"]["t0_s"])
    thr = float(P["meta"]["settings"]["lambda_zero_threshold_s_inv"])
    fig, axs = row(plt, (1.0, 1.05, 0.95))
    # (a) representative 25 C rest, log-log, fits over the declared window
    ax = axs[0]
    p = f"fits__{REP_REST}__"
    vinf = float(A[p + "TPL_Vinf_mV"])
    tf, yf = A[p + "t_full"], A[p + "V_full_mV"]
    ts, ys, tg = A[p + "t_sub"], A[p + "V_sub_mV"], A[p + "t_grid"]
    ok = (tf > 0) & (np.abs(yf - vinf) > 0)
    ax.loglog(ts, np.abs(ys - vinf), ls="none", marker="o", ms=2.6, mfc="white", mec=ps.INK, mew=0.6, zorder=4,
              label="measured")
    for m in ("PL", "EXP", "TPL"):
        s = LAW[m]
        ax.loglog(tg, np.abs(A[p + f"{m}_grid_mV"] - vinf), color=s["color"], ls=s["ls"], lw=1.2, zorder=3,
                  label=LAWLAB[m])
    ax.set_ylim(0.15, 30)
    ax.set_xlim(t0 * 0.9, tf[-1] * 1.2)
    plain(ax, "y")
    ax.set_xlabel("time since interruption (s)")
    ax.set_ylabel(r"$|V_t-\hat V_\infty|$ (mV)")
    ax.legend(loc="lower left", frameon=False)
    # (b) TPL lambda-hat of the measured rests vs the untempered synthetic controls
    ax = axs[1]
    prim = A["lam__seg_primary"] == 1
    lam = A["lam__seg_lam"][prim]
    zero_x = 2.2e-7
    rng = np.random.default_rng(SEED)
    y0 = 3.0
    xv = np.where(lam < thr, zero_x, lam)
    ax.plot(xv, y0 + rng.uniform(-0.28, 0.28, xv.size), ls="none", marker="o", ms=3.0, mfc=ps.INK2, mec="white",
            mew=0.3, alpha=0.8, zorder=3)
    q25, q50, q75 = np.quantile(lam, [0.25, 0.5, 0.75])
    FACTS["fig2"] = dict(rep_rest=REP_REST, t0_s=t0, n_primary=int(lam.size), n_lambda_zero=int((lam < thr).sum()),
                         lambda_median=float(q50), lambda_q25=float(q25), lambda_q75=float(q75))
    ax.plot([q25, q75], [y0 - 0.45, y0 - 0.45], color=ps.INK, lw=1.6, solid_capstyle="butt")
    ax.plot([q50], [y0 - 0.45], marker="|", ms=7, mew=1.6, color=ps.INK)
    ctrl = [("declared", M["synthetic_control"])] + [(f["tag"], f) for f in M["synthetic_control"]["fitted"]]
    names = {"declared": "synthetic, $\\lambda=0$\n(declared)",
             "fitted_SP1_IC_OCV_25C": "synthetic, $\\lambda=0$\n(fit 25 °C)",
             "fitted_SP1_IC_OCV_0C": "synthetic, $\\lambda=0$\n(fit 0 °C)"}
    ylabs = [(y0, f"measured rests\n(n = {lam.size})")]
    for k, (tag, blk) in enumerate(ctrl):
        r = next(r for r in blk["results"] if float(r["lambda_true"]) == 0.0)
        yk = 2.0 - 0.75 * k
        a, b = r["tpl_lambda_iqr"]
        ax.plot([a, b], [yk, yk], color=ps.SLOTS[1], lw=1.6, solid_capstyle="butt")
        ax.plot([r["tpl_lambda_median"]], [yk], ls="none", marker="s", ms=4.2, mfc=ps.SLOTS[1], mec="white", mew=0.5)
        ylabs.append((yk, names.get(tag, tag)))
        FACTS["fig2"][f"control_{tag}_lambda_median"] = float(r["tpl_lambda_median"])
    ax.axvline(1.0 / 7200.0, color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)), zorder=1)
    ax.text(1.0 / 7200.0 * 1.15, 3.55, r"$1/t_\mathrm{end}$", color=ps.INK2, fontsize=8, va="center")
    ax.set_xscale("log")
    ax.set_xlim(1.2e-7, 4e-3)
    ax.set_xticks([zero_x, 1e-6, 1e-5, 1e-4, 1e-3])
    ax.set_xticklabels(["0", "$10^{-6}$", "$10^{-5}$", "$10^{-4}$", "$10^{-3}$"])
    ax.minorticks_off()
    ax.axvspan(1.2e-7, 4.5e-7, color=ps.SHADE, lw=0, zorder=0)
    ax.set_yticks([y for y, _ in ylabs])
    ax.set_yticklabels([s for _, s in ylabs])
    ax.set_ylim(0.1, 3.8)
    ax.grid(axis="y", visible=False)
    ax.set_xlabel(r"fitted TPL $\hat\lambda$ (s$^{-1}$)")
    # (c) BIC winner share vs window start
    ax = axs[2]
    t0s = sorted(int(k) for k in P["summary"] if k.isdigit())
    for m in ("TPL", "PL", "SEXP", "2EXP", "EXP"):
        v = [100.0 * P["summary"][str(t)]["all_primary"]["wins_bic"][m] / P["summary"][str(t)]["all_primary"]["n"]
             for t in t0s]
        s = LAW[m]
        ax.plot(t0s, v, color=s["color"], ls=s["ls"], marker=s["marker"], ms=3.8, mec="white", mew=0.5, lw=1.2,
                label={"TPL": "TPL", "PL": "PL", "SEXP": "SEXP", "2EXP": "2EXP", "EXP": "EXP"}[m])
    ax.axvline(t0, color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)))
    ax.set_xscale("log")
    ax.set_xticks(t0s)
    plain(ax, "x")
    ax.minorticks_off()
    ax.set_ylim(0, 100)
    ax.set_yticks([0, 20, 40, 60, 80])
    ax.set_xlabel(r"window start $t_0$ (s)")
    ax.set_ylabel("BIC wins (% of rests)")
    ax.legend(loc="upper center", ncol=3, frameon=True, framealpha=1.0, edgecolor="none", columnspacing=0.8,
              handlelength=1.8, bbox_to_anchor=(0.5, 1.01))
    for k, a in enumerate(axs):
        label(a, k)
    return ps.save(fig, FIG / "paper_fig2_relaxation.pdf")


# ================================================================================================================
# Fig. 3  SOC on unseen profiles
# ================================================================================================================
REP_FILE = "SP2_25C_FUDS_50SOC"
REP_REST = "SP3_IC_OCV_25C"


ENV3_METHODS = ("CC", "AEKF2RC", "EKF2RC", "FOEKF", "TFO")
ENV3_KEY = "paper_fig3_env"      # precomputed 1 s envelope shipped in the public validation_series.npz


def fig3_envelope(Z, files) -> tuple:
    """Fig. 3(b): median |SOC error| (%) over the files x (+0.20, -0.20) runs on the common 1 s grid.

    The public copy of validation_series.npz holds the SOC trajectories on a 60 s grid only (make_release.py,
    DECIMATE), so it ships this envelope precomputed from the 1 s trajectories under the keys ENV3_KEY|*."""
    if f"{ENV3_KEY}|t" in Z.files:
        return (np.asarray(Z[f"{ENV3_KEY}|t"], float),
                {m: np.asarray(Z[f"{ENV3_KEY}|med|{m}"], float) for m in ENV3_METHODS})
    n = min(int(Z[f"{f}|t_soc"].size) for f in files)
    med = {}
    for m in ENV3_METHODS:
        E = np.array([np.abs(Z[f"{f}|zhat|{m}|{sc}"][:n].astype(float) - Z[f"{f}|zref"][:n].astype(float))
                      for f in files for sc in ("plus20", "minus20")])
        med[m] = 100 * np.median(E, axis=0)
    return np.arange(n, dtype=float), med


def fig3(plt):
    J = js("validation_main.json")
    Z = np.load(RES / "validation_series.npz")
    files = [f["file"] for f in J["files"]]
    fig, axs = row(plt, (1.0, 1.0, 0.95))
    # (a) representative unseen profile from the -0.20 initial SOC error
    ax = axs[0]
    f = REP_FILE
    th = Z[f"{f}|t_soc"] / 3600.0
    ax.fill_between(th, 100 * Z[f"{f}|zref_lo"], 100 * Z[f"{f}|zref_hi"], color="#dcdad5", lw=0, zorder=1,
                    label="reference band")
    ax.plot(th, 100 * Z[f"{f}|zref"], color=ps.INK, lw=0.8, zorder=4, label="reference")
    FACTS["fig3"] = dict(rep_file=f, rep_scenario="minus20",
                         **{f"rep_rmse_pct_{r['method']}": float(r["adm_post_rmse_pct"]) for r in J["records"]
                            if r["file"] == f and r["scenario"] == "minus20"
                            and r["method"] in ("TFO", "FOEKF", "EKF2RC")})
    for m in ("EKF2RC", "FOEKF", "TFO"):
        s = mstyle(m)
        ax.plot(th, 100 * Z[f"{f}|zhat|{m}|minus20"], color=s["color"], ls=s["ls"], lw=1.1, zorder=3,
                label=MLAB[m])
    ax.set_xlim(0, th[-1])
    ax.set_ylim(0, 60)
    ax.text(0.03, 0.04, "FUDS, 25 °C, 50 % start;\ninitial estimate 0.20 low", transform=ax.transAxes,
            ha="left", va="bottom", fontsize=8, color=ps.INK)
    ax.set_xlabel("time (h)")
    ax.set_ylabel("SOC (%)")
    h, l = ax.get_legend_handles_labels()
    ax.legend(h[::-1], l[::-1], loc="upper right", frameon=False)
    # (b) median |SOC error| over the 18 files x (+0.20, -0.20) runs, common length
    ax = axs[1]
    t, MED = fig3_envelope(Z, files)
    n = int(t.size)
    FACTS["fig3"]["env_common_samples"] = n
    FACTS["fig3"]["env_n_runs"] = 2 * len(files)
    for m in ENV3_METHODS:
        med = MED[m]
        FACTS.setdefault("fig3", {})[f"env_first_below_2pct_s_{m}"] = int(np.argmax(med < 2.0))
        FACTS["fig3"][f"env_median_after_600s_pct_{m}"] = float(np.median(med[600:]))
        s = mstyle(m)
        ax.plot(t[1:], med[1:], color=s["color"], ls=s["ls"], lw=1.1, label=MLAB[m])
    ax.axhline(2.0, color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)))
    ax.axvline(600.0, color=ps.MUTED, lw=ps.LW["ref"], ls=":")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(1, n)
    ax.set_ylim(0.04, 40)
    plain(ax, "y")
    ax.set_xlabel("time since start (s)")
    ax.set_ylabel("median |SOC error| (%)")
    h, l = ax.get_legend_handles_labels()
    ax.legend(h[::-1], l[::-1], loc="lower left", frameon=False, ncol=3, columnspacing=0.7, handlelength=1.7)
    # (c) primary RMSE per test file (mean over the 3 initial-SOC scenarios), strip plot with medians
    ax = axs[2]
    rec = {(r["method"], r["file"], r["scenario"]): r["adm_post_rmse_pct"] for r in J["records"]}
    scen = J["settings"]["scenarios"]
    rng = np.random.default_rng(SEED)
    for i, m in enumerate(METHODS):
        v = np.array([np.mean([rec[(m, f, s)] for s in scen]) for f in files])
        s = mstyle(m)
        ax.plot(i + rng.uniform(-0.2, 0.2, v.size), v, ls="none", **pts(m, 3.4))
        FACTS["fig3"][f"file_rmse_median_pct_{m}"] = float(np.median(v))
        FACTS["fig3"][f"file_rmse_max_pct_{m}"] = float(np.max(v))
        ax.plot([i - 0.32, i + 0.32], [np.median(v)] * 2, color=ps.INK, lw=1.3, zorder=4)
    ax.set_yscale("log")
    ax.set_ylim(0.25, 30)
    plain(ax, "y")
    ax.set_xticks(range(len(METHODS)))
    ax.set_xticklabels([MLAB[m] for m in METHODS], rotation=35, ha="right", rotation_mode="anchor")
    ax.set_xlim(-0.6, len(METHODS) - 0.4)
    ax.grid(axis="x", visible=False)
    ax.set_ylabel("SOC RMSE per file (%)")
    for k, a in enumerate(axs):
        label(a, k)
    return ps.save(fig, FIG / "paper_fig3_soc.pdf")


# ================================================================================================================
# Fig. 4  tempering vs memory budget, certified horizon, cost
# ================================================================================================================
def strat_boot_mean(vals_by_T, n_boot=4000, seed=SEED):
    """95 % percentile interval of the pooled mean, files resampled within each temperature (as in 07_ablation)."""
    rng = np.random.default_rng(seed)
    arrs = [np.asarray(v, float) for v in vals_by_T.values()]
    tot = sum(a.size for a in arrs)
    bs = np.zeros(n_boot)
    for a in arrs:
        bs += a[rng.integers(0, a.size, (n_boot, a.size))].sum(axis=1)
    return np.quantile(bs / tot, [0.025, 0.975])


def fig4(plt):
    J = js("ablation.json")
    C = js("cost.json")
    cur = J["figure_data"]["memory"]["curves"]
    Lfull = float(J["figure_data"]["profile_duration_median_s"]["all"])
    rows = J["test"]["rows"]
    fig, axs = row(plt, (1.1, 0.9))
    # (a) pooled test SOC RMSE vs L for every lambda (own re-identified model and tuned gains per point)
    ax = axs[0]
    for lk in sorted(cur, key=float):
        cv = cur[lk]
        lam = float(lk)
        x = list(cv["L"]) + [Lfull]
        y = list(cv["adm_mean"]) + [cv["adm_full"]]
        col = LAM_COL[lam]
        lab = r"$\lambda=0$" if lam == 0 else rf"$10^{{{np.log10(lam):.1f}}}$".replace(".0}", "}")
        if lam == 3e-4:
            lab = r"$3{\times}10^{-4}$"
        elif lam == 3e-3:
            lab = r"$3{\times}10^{-3}$"
        if lam == 0:
            key = lambda v: v                                             # noqa: E731
            lo, hi = [], []
            for L in list(cv["L"]) + ["full"]:
                var = f"curve_0_{L}"
                d = {}
                for r in rows:
                    if r["variant"] == var:
                        d.setdefault((r["T"], r["file"]), []).append(float(r["adm_rmse_pct"]))
                byT = {T: [np.mean(v) for (TT, _), v in d.items() if TT == T] for T in TEMPS}
                a, b = strat_boot_mean(byT)
                lo.append(key(a))
                hi.append(key(b))
            ax.fill_between(x, lo, hi, color=ps.SLOTS[1], alpha=0.15, lw=0, zorder=1)
            FACTS["fig4"] = dict(lam0_ci95_lo=[float(v) for v in lo], lam0_ci95_hi=[float(v) for v in hi],
                                 L_grid=list(cv["L"]) + ["full"], full_drawn_at_s=Lfull)
        ax.plot(x[:-1], y[:-1], color=col, ls="-" if lam > 0 else "--", lw=1.1, marker=LAM_MK[lam], ms=3.3,
                mec="white", mew=0.4, zorder=3 if lam > 0 else 4, label=lab)
        ax.plot(x[-2:], y[-2:], color=col, ls=":", lw=0.8, zorder=2)
        ax.plot(x[-1:], y[-1:], ls="none", marker=LAM_MK[lam], ms=3.6, mfc="white", mec=col, mew=0.9, zorder=3)
    ax.axvline(400, color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)), zorder=0)
    ax.set_xscale("log")
    ax.set_xticks([50, 100, 400, 1600, Lfull])
    ax.set_xticklabels(["50", "100", "400", "1600", "full"])
    ax.minorticks_off()
    ax.set_xlim(38, 1.25e4)
    ax.set_ylim(1.2, 2.62)
    ax.set_xlabel(r"memory horizon $L$ (s)")
    ax.set_ylabel("test SOC RMSE (%)")
    ax.legend(loc="upper right", ncol=3, frameon=False, columnspacing=0.5, handlelength=1.5,
              handletextpad=0.3, bbox_to_anchor=(1.02, 1.03))
    # (b) certified memory horizon L_z*(0.5 %) vs lambda (neutral ink: markers = temperature)
    ax = axs[1]
    lams = [float(k) for k in sorted(cur, key=float) if float(k) > 0]
    tmk = {0: "o", 25: "s", 45: "^"}
    for T in TEMPS:
        y = [cur[f"{l:g}"]["certified_horizon_s"][str(T)] for l in lams]
        ax.plot(lams, y, color=ps.INK2, lw=0.8, marker=tmk[T], ms=3.8, mfc="white" if T == 25 else ps.INK2,
                mec=ps.INK2, mew=0.8, label=f"{T} °C")
    u = [cur["0"]["certified_horizon_s"][f"{T}_log10_untempered"] for T in TEMPS]
    ax.text(1.1e-4, 125, rf"$\lambda=0$: $10^{{{min(u):.0f}}}$–$10^{{{max(u):.0f}}}$ s", fontsize=8, color=ps.INK,
            ha="left", va="bottom")
    ax.axhline(400, color=ps.INK2, lw=ps.LW["ref"], ls=(0, (4, 2)))
    ax.text(1.1e-4, 470, r"$L=400$ s", color=ps.INK2, fontsize=8, va="bottom")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(8e-5, 1.25e-2)
    ax.set_ylim(90, 1.2e5)
    ax.set_xlabel(r"tempering rate $\lambda$ (s$^{-1}$)")
    ax.set_ylabel(r"certified horizon $L_z^*$ (s)")
    ax.legend(loc="upper right", frameon=False)
    # CPU cost and state size are reported in Table 3 and the text; only the state size is kept as a fact here
    kb = {g["L"]: g["storage"]["implemented"]["bytes_f64"] / 1000.0 for g in C["analytic"]["grid"]
          if g["method"] == "TFO" and not g["full_memory"]}
    FACTS["fig4"]["state_kB_TFO_implemented"] = {str(k): v for k, v in kb.items()}
    for k, a in enumerate(axs):
        label(a, k)
    return ps.save(fig, FIG / "paper_fig4_memory.pdf")


# ================================================================================================================
# Fig. 5  robustness (robustness.json summary: median and IQR over the 18 test files)
# ================================================================================================================
def _stat(S, sc, m):
    v = S[sc][m]["adm_rmse_pct"]
    return float(v["median"]), float(v["q25"]), float(v["q75"])


def fig5(plt):
    R = js("robustness.json")
    S = R["summary"]
    meth = [m for m in METHODS if m in R["methods_main"]]
    fig, axs = plt.subplots(1, 2, figsize=(W_IN, H_IN), layout="constrained",
                            gridspec_kw=dict(width_ratios=[1.0, 1.0]))
    off = np.linspace(-0.3, 0.3, len(meth))
    # (a) initial SOC error
    ax = axs[0]
    scs = [("z0_minus20", "−0.20"), ("baseline", "nominal"), ("z0_plus20", "+0.20")]
    for i, m in enumerate(meth):
        s = mstyle(m)
        for j, (sc, _) in enumerate(scs):
            md, a, b = _stat(S, sc, m)
            ax.plot([j + off[i]] * 2, [a, b], color=s["color"], lw=1.0, zorder=2)
            ax.plot([j + off[i]], [md], ls="none", zorder=3, label=MLAB[m] if j == 0 else None, **pts(m, 4.0))
    ax.set_yscale("log")
    ax.set_ylim(0.2, 60)
    plain(ax, "y")
    ax.set_xticks(range(len(scs)))
    ax.set_xticklabels([t for _, t in scs])
    ax.set_xlim(-0.5, len(scs) - 0.5)
    ax.grid(axis="x", visible=False)
    ax.set_xlabel("initial SOC error")
    ax.set_ylabel("SOC RMSE (%)")
    ax.legend(loc="center", ncol=3, frameon=False, columnspacing=0.6, handlelength=1.0,
              bbox_to_anchor=(0.5, 0.6))
    # (b) current-sensor offset (0 = baseline)
    ax = axs[1]
    lev = [("bias_-50mA", -50), ("bias_-20mA", -20), ("baseline", 0), ("bias_+20mA", 20), ("bias_+50mA", 50)]
    for i, m in enumerate(meth):
        s = mstyle(m)
        st = np.array([_stat(S, sc, m) for sc, _ in lev])
        x = np.array([v for _, v in lev]) + 1.6 * off[i] / 0.3
        ax.plot(x, st[:, 0], color=s["color"], ls=s["ls"], lw=1.1, zorder=3 if m in ("TFO", "CC") else 2,
                **pts(m, 3.6))
    ax.set_xticks([v for _, v in lev])
    ax.set_xlim(-58, 58)
    ax.set_ylim(0, 5.2)
    ax.set_xlabel("current offset (mA)")
    ax.set_ylabel("SOC RMSE (%)")
    for k, a in enumerate(axs):
        label(a, k)
    return ps.save(fig, FIG / "paper_fig5_robustness.pdf")


def measured_relaxation_available() -> bool:
    """False in the public copy, whose relaxation_curves.npz omits the measured channels (make_release.py)."""
    f = RES / "relaxation_curves.npz"
    return f.exists() and f"fits__{REP_REST}__t_full" in np.load(f, allow_pickle=False).files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--png", default=None, help="directory for 200 dpi PNG previews")
    ap.add_argument("--only", default=None, help="comma list of 2,3,4,5")
    a = ap.parse_args()
    todo = {"2": fig2, "3": fig3, "4": fig4, "5": fig5}
    keys = a.only.split(",") if a.only else list(todo)
    out = RES / "paper_figures.json"
    if out.exists():
        with open(out, encoding="utf-8") as fh:
            FACTS.update(json.load(fh))
    for k in keys:
        if k == "2" and not measured_relaxation_available():
            print("SKIPPED fig:relax (figures/paper_fig2_relaxation.pdf): needs the measured CALCE rest-voltage "
                  "channels, absent from results/relaxation_curves.npz; download the data and re-run the analysis "
                  "(README, sections 4-6). Figures 3-5 are rebuilt from the saved results.", flush=True)
            continue
        plt = setup()
        p = todo[k](plt)
        plt.close("all")
        print("wrote", p.relative_to(ROOT))
        if a.png:
            out = Path(a.png) / (p.stem + ".png")
            out.parent.mkdir(parents=True, exist_ok=True)
            ps.preview_png(p, out=out)
    FACTS["meta"] = dict(script="scripts/10_paper_figures.py", note="derived from results/*.json|npz only")
    with open(RES / "paper_figures.json", "w", encoding="utf-8") as fh:
        json.dump(FACTS, fh, indent=1)


if __name__ == "__main__":
    main()
