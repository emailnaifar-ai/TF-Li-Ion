"""P1 operator convention: Caputo-type tempered element (paper) versus normalized tempered element.

Paper element      D^{alpha,lambda} V = -a_p V + b I                     (a_p > 0)
Normalized element Dn V := D^{alpha,lambda} V - lambda^alpha V = -a' V + b I   (a' > 0)
Claim: the two coincide exactly under a' = a_p + lambda^alpha (same equation, same transfer function
b/((s+lambda)^alpha + a_p), same DC gain b/a', same branch point s = -lambda). The normalized class also contains
a' in (0, lambda^alpha], i.e. a_p = a' - lambda^alpha <= 0, whose denominator (s+lambda)^alpha - lambda^alpha + a'
has the real zero s* = (lambda^alpha - a')^{1/alpha} - lambda in (-lambda, 0]: slower decay than e^{-lambda t}, and
at a' = 0 a pole at s = 0 (capacitive DC limit).

Checks
  1. transfer functions on a complex grid;
  2. full-memory GL on a pulse current: project recursion (tempered.simulate_tempered_element with a_p) versus an
     independent implementation of the normalized operator written from its definition (own weights, own solve);
  3. step response: exact paper element (tempered.exact_step_response, spectral) versus Talbot inversion of the
     normalized transfer function (mpmath), and the GL result at the same instants;
  4. a' <= lambda^alpha: real zero, free response (GL with a_p < 0 versus Talbot inversion versus the residue
     (x0/alpha) e^{s* t}), and the growing step response for a' = 0;
  5. frozen TFO parameters (results/frozen_config.json, methods.TFO.per_T, primary budget 400 s):
     a_p, b_p, lambda^alpha, a', R_dc = b_p/a', R_p (paper) versus R_p' = b_p/a' (normalized).
Writes results/operator_convention.json. Run from the project root: python scripts/p1_operator_convention.py
"""
from __future__ import annotations

import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import mpmath as mp
import numpy as np
from scipy.special import binom

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import tempered as tp  # noqa: E402

mp.mp.dps = 30


def H_paper(s, alpha, lam, ap, b):
    return b / ((s + lam) ** alpha + ap)


def H_norm(s, alpha, lam, a1, b):
    return b / ((s + lam) ** alpha - lam ** alpha + a1)


def normalized_gl(alpha, lam, a1, b, I, h, x0=0.0):
    """Independent full-memory GL solver of Dn x = -a' x + b I written from the normalized definition, with its
    own weights w_j = (-1)^j binom(alpha, j) e^{-lam j h}. The Caputo-type initial value is removed exactly through
    D^{alpha,lam} x = D^{alpha,lam}[x - x0 e^{-lam t}] (D^{alpha,lam} e^{-lam t} = 0, Lemma S1.1.3); GL is applied to
    y = x - x0 e^{-lam t} (y_0 = 0) and the normalization term -lam^alpha x_n is kept separate."""
    I = np.asarray(I, float)
    N = I.size - 1
    j = np.arange(N + 1)
    w = ((-1.0) ** j) * binom(alpha, j) * np.exp(-lam * j * h)       # own weights (no recursion)
    t = j * h
    base = x0 * np.exp(-lam * t)
    y = np.zeros(N + 1)
    x = np.empty(N + 1)
    x[0] = x0
    ha = h ** (-alpha)
    for n in range(1, N + 1):
        mem = float(np.dot(w[1:n + 1], y[n - 1::-1][:n]))            # sum_{j=1}^{n} w_j y_{n-j}
        # ha*(y_n + mem) - lam^alpha x_n = -a' x_n + b I_n,  x_n = y_n + base_n
        y[n] = (b * I[n] - ha * mem + (lam ** alpha - a1) * base[n]) / (ha - lam ** alpha + a1)
        x[n] = y[n] + base[n]
    return x


def talbot(F, t):
    return np.array([float(mp.invertlaplace(F, float(tt), method="talbot")) for tt in t])


def check_pair(alpha, lam, a1, b, tag, t_eval, h=1.0, N_gl=3000, seed=20260927):
    ap = a1 - lam ** alpha
    out = dict(tag=tag, alpha=alpha, lam=lam, a_prime=a1, a_p=ap, b=b)
    # 1. transfer functions
    om = np.logspace(-6, 2, 400)
    s = np.concatenate([1j * om, 0.3 * om + 1j * om, np.array([0.0 + 0j, 1.0 + 0j])])
    hp, hn = H_paper(s, alpha, lam, ap, b), H_norm(s, alpha, lam, a1, b)
    out["tf_max_rel_diff"] = float(np.max(np.abs(hp - hn) / np.abs(hn)))
    out["dc_gain_paper"] = b / (ap + lam ** alpha)
    out["dc_gain_norm"] = b / a1
    # 2. GL on a pulse current (piecewise constant, 20 s segments, +-2 A), full memory
    rng = np.random.default_rng(seed)
    seg = rng.uniform(-2.0, 2.0, N_gl // 20 + 1)
    I = np.repeat(seg, 20)[:N_gl + 1]
    xp = tp.simulate_tempered_element(alpha, lam, ap, b, I, h)
    xn = normalized_gl(alpha, lam, a1, b, I, h)
    out["gl_pulse_max_abs_diff_V"] = float(np.max(np.abs(xp - xn)))
    out["gl_pulse_max_abs_V"] = float(np.max(np.abs(xp)))
    # 3. step response, I0 = 1 A
    Fn = lambda z: b / (z * ((z + lam) ** alpha - lam ** alpha + a1))  # noqa: E731
    xn_ex = talbot(Fn, t_eval)
    out["t_eval_s"] = list(map(float, t_eval))
    out["step_norm_talbot_V"] = xn_ex.tolist()
    if ap > 0:
        xp_ex = tp.exact_step_response(alpha, lam, ap, b, 1.0, t_eval)
        out["step_paper_exact_V"] = xp_ex.tolist()
        out["step_max_abs_diff_V"] = float(np.max(np.abs(xp_ex - xn_ex)))
    Ns = int(round(max(t_eval) / h))
    xs = tp.simulate_tempered_element(alpha, lam, ap, b, np.ones(Ns + 1), h)
    idx = np.round(np.asarray(t_eval) / h).astype(int)
    out["step_gl_V"] = xs[idx].tolist()
    out["step_gl_vs_talbot_max_abs_V"] = float(np.max(np.abs(xs[idx] - xn_ex)))
    return out


def extra_element(alpha, lam, a1, b, h, T_end, t_eval):
    """a' <= lambda^alpha: real zero, free response (x0 = 1) and step response."""
    la = lam ** alpha
    ap = a1 - la
    sstar = (la - a1) ** (1.0 / alpha) - lam
    den = (sstar + lam) ** alpha - la + a1
    out = dict(alpha=alpha, lam=lam, a_prime=a1, a_p=ap, lam_alpha=la, s_star=sstar, den_at_s_star=den,
               s_star_over_minus_lam=-sstar / lam)
    N = int(round(T_end / h))
    xf = tp.simulate_tempered_element(alpha, lam, ap, b, np.zeros(N + 1), h, x0=1.0)
    Ff = lambda z: (z + lam) ** (alpha - 1) / ((z + lam) ** alpha - la + a1)  # noqa: E731
    idx = np.round(np.asarray(t_eval) / h).astype(int)
    ex = talbot(Ff, t_eval)
    res = np.exp(sstar * np.asarray(t_eval)) / alpha
    out.update(t_eval_s=list(map(float, t_eval)), free_gl=xf[idx].tolist(), free_talbot=ex.tolist(),
               free_residue=res.tolist(), free_gl_vs_talbot_max_abs=float(np.max(np.abs(xf[idx] - ex))),
               free_times_exp_lam_t_talbot=(ex * np.exp(lam * np.asarray(t_eval))).tolist())
    # reference: paper-class element with the same lambda and a' = 2 lambda^alpha (a_p = lambda^alpha > 0)
    exr = talbot(lambda z: (z + lam) ** (alpha - 1) / ((z + lam) ** alpha + la), t_eval)
    out["ref_inside_class_a_prime"] = 2 * la
    out["ref_free_times_exp_lam_t"] = (exr * np.exp(lam * np.asarray(t_eval))).tolist()
    if a1 == 0.0:
        Fs = lambda z: b / (z * ((z + lam) ** alpha - la))  # noqa: E731
        st = talbot(Fs, t_eval)
        slope = b * lam ** (1 - alpha) / alpha
        out.update(step_talbot=st.tolist(), capacitive_slope_V_per_s=slope,
                   step_over_slope_t=(st / (slope * np.asarray(t_eval))).tolist(),
                   C_eff=alpha * lam ** (alpha - 1) / b)
    return out


def fitted_table():
    cfg = json.loads((ROOT / "results" / "frozen_config.json").read_text())
    rows = {}
    for T, rec in cfg["methods"]["TFO"]["per_T"].items():
        p = rec["params"]
        al, lam, Rp, Cp = p["alpha"], p["lam"], p["Rp"], p["Cp"]
        ap, bp = 1.0 / (Rp * Cp), 1.0 / Cp
        la = lam ** al
        a1 = ap + la
        rows[T] = dict(src=f"results/frozen_config.json:methods.TFO.per_T.{T}.params ({rec['parameter_set']})",
                       alpha=al, lam=lam, Rp=Rp, Cp=Cp, R0=p["R0"], a_p=ap, b_p=bp, lam_alpha=la, a_prime=a1,
                       R_dc=bp / a1, Rp_paper=bp / ap, Rp_prime_normalized=bp / a1,
                       tempering_share_of_dc_conductance=la / a1, a_prime_over_lam_alpha=a1 / la,
                       inside_equivalent_part=bool(a1 > la), R0_plus_R_dc=p["R0"] + bp / a1,
                       real_zero_in_principal_sheet=bool(a1 <= la))
    return rows


def main():
    fit = fitted_table()
    pairs = [check_pair(0.5, 0.01, 2 * 0.01 ** 0.5, 1.0, "illustrative alpha=0.5 lam=0.01",
                        np.array([1.0, 10.0, 100.0, 1000.0, 3000.0]))]
    for T, r in fit.items():
        pairs.append(check_pair(r["alpha"], r["lam"], r["a_prime"], r["b_p"], f"frozen TFO {T} C",
                                np.array([1.0, 10.0, 100.0, 1000.0, 1e4, 2e4])))
    extras = [extra_element(0.5, 0.01, a1, 1.0, 0.05, 1000.0, np.array([10.0, 100.0, 300.0, 600.0, 1000.0]))
              for a1 in (0.05, 0.0)]
    r0 = fit["0"]
    extras.append(extra_element(r0["alpha"], r0["lam"], 0.5 * r0["lam_alpha"], r0["b_p"], 1.0, 2e4,
                                np.array([100.0, 1e3, 1e4, 2e4])))
    out = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
               script="scripts/p1_operator_convention.py",
               algebra="Dn f := D^{alpha,lambda} f - lambda^alpha f; Dn V = -a' V + b I <=> D^{alpha,lambda} V = "
                       "-(a' - lambda^alpha) V + b I; L{Dn V} = ((s+lambda)^alpha - lambda^alpha) V(s) - "
                       "(s+lambda)^(alpha-1) V(0); H_n(s) = b/((s+lambda)^alpha - lambda^alpha + a') = "
                       "b/((s+lambda)^alpha + a_p) iff a' = a_p + lambda^alpha",
               fitted=fit, equivalence_checks=pairs, extra_normalized_elements=extras)
    (ROOT / "results" / "operator_convention.json").write_text(json.dumps(out, indent=1))
    for T, r in fit.items():
        print(T, {k: (round(v, 6) if isinstance(v, float) else v) for k, v in r.items() if k != "src"})
    for p in pairs:
        print(p["tag"], p["tf_max_rel_diff"], p["gl_pulse_max_abs_diff_V"], p.get("step_max_abs_diff_V"),
              p["step_gl_vs_talbot_max_abs_V"])
    for e in extras:
        print({k: e[k] for k in ("a_prime", "lam_alpha", "s_star", "den_at_s_star", "free_gl_vs_talbot_max_abs")})


if __name__ == "__main__":
    main()
