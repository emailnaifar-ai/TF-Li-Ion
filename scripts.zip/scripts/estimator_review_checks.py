"""Checks behind the estimator review response (reports/estimators_notes.md, section 'Review response').

Writes results/estimator_review_checks.json.  Uses synthetic data and the VALIDATION split only
(SP2_*_DST_50SOC, loaded through experiments.load_case with its default validation-only guard); no
identification or test file is used.  Identified parameters are read from results/identification.json.

Run from the project root:  python scripts/estimator_review_checks.py
"""
from __future__ import annotations

import json
import sys
import time
import warnings
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import benchmarks as B  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402
from tfso.data import load_config  # noqa: E402

SYN = load_config()["estimators"]["synthetic_test"]
P_SYN = dict(alpha=SYN["alpha"], lam=SYN["lam"], R0=SYN["R0"], Rp=SYN["Rp"], Cp=SYN["Cp"], Qn=SYN["Qn"], eta=1.0)
P2_SYN = dict(R0=0.05, R1=0.015, tau1=12.0, R2=0.02, tau2=400.0, Qn=2.0, eta=1.0)
HS = [1.0, 2.0, 5.0, 10.0]


def U_nl(z):
    z = np.asarray(z, float)
    return 3.5 + 0.6 * z + 0.05 * np.sin(2 * np.pi * z)


def dU_nl(z):
    z = np.asarray(z, float)
    return 0.6 + 0.1 * np.pi * np.cos(2 * np.pi * z)


OCV = O.FastOCV(U_nl, dU_nl)


def rms(x):
    x = np.asarray(x, float)
    return float(np.sqrt(np.mean(x * x)))


def identified(T):
    fits = json.load(open(ROOT / "results" / "identification.json", encoding="utf-8"))["per_T"][str(T)]["fits"]
    Q = E.q_id(T)
    out = {}
    for name in ("TFO", "FO", "2RC"):
        th = dict(fits[name]["theta"])
        th.update(Qn=Q, eta=1.0)
        out[name] = th
    return out


def check_ekf_h():
    """Open-loop SOC of every filter vs CC, and exact-2RC plant from the true SOC, at h = 1, 2, 5, 10 s."""
    out = []
    for h in HS:
        I = E.synthetic_dst_current(int(6000 / h), h)
        V = np.full(I.size, 3.8)
        cc = O.run_estimator("CC", P2_SYN, {}, I, V, h, 0.8)["zhat"]
        rec = dict(h=h)
        for meth in ("EKF2RC", "AEKF2RC"):
            r = O.run_estimator(meth, P2_SYN, dict(Q=[0, 0, 0], R=1e12, P0=[0, 1e-4, 1e-4], Q_min=[0, 0, 0]), I, V, h,
                                0.8, OCV)
            rec[f"{meth}_openloop_max_dz_vs_CC"] = float(np.max(np.abs(r["zhat"] - cc)))
        r = O.run_estimator("FOEKF", dict(P_SYN, lam=0.0), dict(Q=[0, 0], R=1e12, P0=[0, 1e-4], N_L=100), I, V, h, 0.8,
                            OCV)
        rec["FOEKF_openloop_max_dz_vs_CC"] = float(np.max(np.abs(r["zhat"] - cc)))
        # exact 2RC plant (true SOC start, noise-free)
        m = B.ekf2rc_model(P2_SYN, h)
        z = 0.8 + np.concatenate([[0], np.cumsum(m["B0"] * I[:-1])])
        v1, v2 = np.zeros_like(I), np.zeros_like(I)
        for k in range(1, I.size):
            v1[k] = m["e1"] * v1[k - 1] + m["g1"] * I[k - 1]
            v2[k] = m["e2"] * v2[k - 1] + m["g2"] * I[k - 1]
        Vp = U_nl(z) + P2_SYN["R0"] * I + v1 + v2
        for meth in ("EKF2RC", "AEKF2RC"):
            hy = E.hyper_for_h(meth, E.default_hyper(meth, 1.0), h)
            r = O.run_estimator(meth, P2_SYN, hy, I, Vp, h, 0.8, OCV)
            rec[f"{meth}_exact2RC_final_err_pct"] = float(100 * (r["zhat"][-1] - z[-1]))
        out.append(rec)
    return out


def check_resampling():
    """Exact TFO-model data re-gridded to h; exact-state TFO (l1 = l2 = 0, full memory) output residual and
    SOC error: new rule (point V(t_k), point I_out) vs the superseded rule (causal-mean V, block-mean I)."""
    case = E.make_synthetic_case(P_SYN, U_nl, dU_nl, N=6000, h=1.0)
    out = []
    for h in HS:
        c = E.resample_case(case, h)
        m = int(h)
        K = c.t.size - 1
        V_old = np.empty(K + 1)
        V_old[0] = case.V[0]
        if K and m > 1:
            V_old[1:] = case.V[1: K * m + 1].reshape(K, m).mean(axis=1)
        else:
            V_old = c.V
        hy = dict(l1=0.0, l2=0.0, N_L=None)
        rn = O.run_estimator("TFO", P_SYN, hy, c.I, c.V, h, c.soc_ref[0], OCV, I_out=c.I_out)
        ro = O.run_estimator("TFO", P_SYN, hy, c.I, V_old, h, c.soc_ref[0], OCV)
        # closed loop (certified gains) from the true SOC: SOC error induced by the re-gridding rule
        hc = dict(l1=0.03, l2=0.03, N_L=None)
        cn = O.run_estimator("TFO", P_SYN, hc, c.I, c.V, h, c.soc_ref[0], OCV, I_out=c.I_out)
        co = O.run_estimator("TFO", P_SYN, hc, c.I, V_old, h, c.soc_ref[0], OCV)
        out.append(dict(h=h, new_resid_rms_mV=1e3 * rms(rn["Vt_prior"] - c.V),
                        new_resid_max_mV=1e3 * float(np.max(np.abs(rn["Vt_prior"] - c.V))),
                        old_resid_rms_mV=1e3 * rms(ro["Vt_prior"] - V_old),
                        old_resid_max_mV=1e3 * float(np.max(np.abs(ro["Vt_prior"] - V_old))),
                        new_closed_soc_rmse_pct=100 * rms(cn["zhat"] - c.soc_ref),
                        old_closed_soc_rmse_pct=100 * rms(co["zhat"] - c.soc_ref),
                        new_closed_soc_max_pct=100 * float(np.max(np.abs(cn["zhat"] - c.soc_ref))),
                        old_closed_soc_max_pct=100 * float(np.max(np.abs(co["zhat"] - c.soc_ref)))))
    return out


def check_foekf_discretisation():
    """Explicit-GL stability of the identified FO parameters and open-loop Vp mismatch against the implicit
    plant; closed-loop FOEKF (config defaults) on implicit-model synthetic data, implicit vs explicit."""
    out = []
    I = E.synthetic_dst_current(6000, 1.0)
    for T in (0, 25, 45):
        pF = identified(T)["FO"]
        c = O.model_constants(pF)
        for h in HS:
            ha = h ** pF["alpha"]
            rec = dict(T=T, h=h, alpha=pF["alpha"], ha_ap=ha * c["ap"], two_pow_alpha=2 ** pF["alpha"],
                       explicit_stable=bool(ha * c["ap"] < 2 ** pF["alpha"]))
            out.append(rec)
        # closed loop at h = 1 on synthetic implicit data with these parameters and the nonlinear test OCV
        p = dict(pF, Qn=2.0)
        case = E.make_synthetic_case(p, U_nl, dU_nl, N=6000, h=1.0, z_true0=0.8, current=I)
        for disc in ("implicit", "explicit"):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                hy = dict(E.default_hyper("FOEKF", 1.0), discretisation=disc)
                r = O.run_estimator("FOEKF", p, hy, case.I, case.V, 1.0, case.soc_ref[0] - 0.2, OCV)
            post = case.t >= 600
            e = r["zhat"] - case.soc_ref
            out.append(dict(T=T, h=1.0, closed_loop=disc, post_rmse_pct=100 * rms(e[post]),
                            final_err_pct=100 * float(e[-1]), soc_clip_count=r["flags"]["soc_clip_count"],
                            explicit_stable=r["flags"]["explicit_stable"]))
    return out


def check_paired():
    a = np.array([np.inf, np.inf, np.inf, 1, 2, 3.0])
    b = np.array([10, 10, 10, 2, 1, 4.0])
    r1 = MX.paired_difference(a, b, censor_at=1001.0)
    aa = np.r_[np.full(12, 90.0), np.full(6, np.inf)]
    bb = np.full(18, 100.0)
    r2 = MX.paired_difference(aa, bb, censor_at=7201.0)
    rm = MX.paired_difference(np.array([np.inf, -np.inf, 1.0]), np.array([0.0, 0.0, 0.0]))
    keep = ("n", "median_diff", "ci_lo", "ci_hi", "n_a_better", "n_b_better", "n_inf_a", "n_inf_b", "wilcoxon_p")
    return dict(reviewer0_case={k: r1[k] for k in keep}, reviewer1_case={k: r2[k] for k in keep},
                mixed_inf_case={k: rm[k] for k in keep})


def check_apriori_output():
    """Frozen 20 % SOC error: a-priori vs a-posteriori output RMSE (EKF2RC with q_z = p_z = 0; TFO with
    l1 = 0, l2 = 50) on exact-model synthetic data."""
    p = dict(P_SYN)
    case = E.make_synthetic_case(p, U_nl, dU_nl, N=6000, h=1.0)
    r = O.run_estimator("TFO", p, dict(l1=0.0, l2=50.0, N_L=None), case.I, case.V, 1.0, case.soc_ref[0] - 0.2, OCV)
    I = E.synthetic_dst_current(6000)
    m = B.ekf2rc_model(P2_SYN, 1.0)
    z = 0.8 + np.concatenate([[0], np.cumsum(m["B0"] * I[:-1])])
    v1, v2 = np.zeros_like(I), np.zeros_like(I)
    for k in range(1, I.size):
        v1[k] = m["e1"] * v1[k - 1] + m["g1"] * I[k - 1]
        v2[k] = m["e2"] * v2[k - 1] + m["g2"] * I[k - 1]
    V = U_nl(z) + P2_SYN["R0"] * I + v1 + v2
    rk = O.run_estimator("EKF2RC", P2_SYN, dict(Q=[0, 1e-4, 1e-4], R=1e-4, P0=[0, 1e-2, 1e-2]), I, V, 1.0, 0.6, OCV)
    return dict(TFO_l1_0_l2_50=dict(soc_rmse_pct=100 * rms(r["zhat"] - case.soc_ref),
                                    vt_prior_rmse_mV=1e3 * rms(r["Vt_prior"] - case.V),
                                    vt_apost_rmse_mV=1e3 * rms(r["Vt_hat"] - case.V)),
                EKF2RC_frozen_soc=dict(soc_rmse_pct=100 * rms(rk["zhat"] - z),
                                       vt_prior_rmse_mV=1e3 * rms(rk["Vt_prior"] - V),
                                       vt_apost_rmse_mV=1e3 * rms(rk["Vt_hat"] - V)))


class _CountingOCV(O.FastOCV):
    def __init__(self, base):
        self.__dict__.update(base.__dict__)
        self.calls = 0

    def both(self, z):
        self.calls += 1
        return O.FastOCV.both(self, z)


def check_ocv_calls():
    case = E.make_synthetic_case(P_SYN, U_nl, dU_nl, N=2000, h=1.0)
    out = {}
    for meth, p, hy in (("TFO", P_SYN, dict(l1=0.03, l2=0.03, N_L=100)),
                        ("FOEKF", dict(P_SYN, lam=0.0), E.default_hyper("FOEKF")),
                        ("EKF2RC", P2_SYN, E.default_hyper("EKF2RC")), ("AEKF2RC", P2_SYN, E.default_hyper("AEKF2RC"))):
        f = _CountingOCV(OCV)
        O.run_estimator(meth, p, hy, case.I, case.V, 1.0, 0.7, f)
        out[meth] = f.calls / (case.I.size - 1)
    return out


def check_validation_defaults():
    """Every method with its CONFIG DEFAULTS (TFO/FOO gains from the default design) and the identified
    parameters on the validation files SP2_{0,25,45}C_DST_50SOC; nominal (common reference OCV) and
    +-20 % z0.  Sanity check of the defaults, not tuning."""
    recs, designs = [], []
    for T in (0, 25, 45):
        case = E.load_case(f"SP2_{T}C_DST_50SOC")                      # validation-only guard (default)
        par = identified(T)
        aocv = MD.AlignedOCV(T, E.q_id(T))
        runs = []
        for meth, pp in (("TFO", par["TFO"]), ("FOO", par["FO"])):
            hy = E.observer_hyper(meth, pp, aocv, 1.0)
            g = hy.pop("design")
            designs.append(dict(T=T, method=meth, l1=g["l1"], l2=g["l2"], sigma_cert=g["sigma_cert"],
                                kappa1=g["kappa1"], kappa2=g["kappa2"], certified=g["certified"],
                                h_l1_kappa2=g["h_l1_kappa2"], z_interval=g["z_interval"],
                                kappa_on_0p1_1=list(O.slope_bounds_fast(O.as_fast_ocv(aocv, s=pp["s"], dq=pp["dq"]),
                                                                        0.1, 1.0)),
                                z_ref_min=float(case.soc_ref.min()), z_ref_max=float(case.soc_ref.max())))
            runs.append((meth, pp, hy))
        runs += [("FOEKF", par["FO"], E.default_hyper("FOEKF")), ("EKF2RC", par["2RC"], E.default_hyper("EKF2RC")),
                 ("AEKF2RC", par["2RC"], E.default_hyper("AEKF2RC")), ("CC", par["2RC"], {})]
        for meth, pp, hy in runs:
            for sc in E.SCENARIOS_Z0:
                r = E.run_case(meth, pp, hy, case, z0_scenario=sc, ocv=None if meth == "CC" else aocv)
                recs.append({k: r[k] for k in ("method", "file", "T", "z0_scenario", "z0", "z_ref0", "rmse_pct",
                                               "post_rmse_pct", "maxabs_pct", "conv_time_s", "within2_pct",
                                               "vt_rmse_mV", "vt_apost_rmse_mV", "soc_clip_count", "positivity_ok",
                                               "n_outside_z_interval", "N_L_used")})
    # sensitivity to the l2 lower bound (TFO, default tau_z_min; certified range of l2)
    l2s = []
    for T in (0, 25, 45):
        case = E.load_case(f"SP2_{T}C_DST_50SOC")
        pp = identified(T)["TFO"]
        aocv = MD.AlignedOCV(T, E.q_id(T))
        for l2min in (0.0, 0.01, 0.1):
            hy = E.observer_hyper("TFO", pp, aocv, 1.0, l2min=l2min)
            g = hy.pop("design")
            for sc in E.SCENARIOS_Z0:
                r = E.run_case("TFO", pp, hy, case, z0_scenario=sc, ocv=aocv)
                l2s.append(dict(T=T, l2min=l2min, l2=g["l2"], certified=g["certified"], z0_scenario=sc,
                                post_rmse_pct=r["post_rmse_pct"]))
    return dict(designs=designs, records=recs, l2_sensitivity=l2s)


def main():
    t0 = time.time()
    res = dict(description=__doc__.strip().splitlines()[0], generated_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               ekf_h=check_ekf_h(), resampling=check_resampling(), foekf_discretisation=check_foekf_discretisation(),
               paired=check_paired(), apriori_output=check_apriori_output(), ocv_calls_per_sample=check_ocv_calls(),
               validation_defaults=check_validation_defaults())
    res["runtime_s"] = time.time() - t0
    path = ROOT / "results" / "estimator_review_checks.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1, default=lambda o: None if o is None else (float(o) if np.isscalar(o) else str(o)))
    print("wrote", path, f"({res['runtime_s']:.0f} s)")


if __name__ == "__main__":
    main()
