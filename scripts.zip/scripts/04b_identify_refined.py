"""P1 (1): R0 cross-check from current edges, edge-R0 sensitivity re-identification, parameter-set decision.

Settings: config identification_refined (declared before this script was first run) + identification_study.
Causal input timing only.  Splits: identification SP2_*_DST_80SOC (edges, fits), validation SP2_*_DST_50SOC (the
parameter-set DECISION, taken by the pre-declared rule and written to results/identification_refined.json BEFORE any
test file is loaded), test = 18 FUDS/US06/BJDST files (open-loop voltage accuracy only, loaded with
final_evaluation=True after the decision is on disk).

Phases (each worker task caches its result in results/identification_refined_runs/ with a config/code hash):
  E  edges       per identification file: switching instants of the schedule, clean edges, R(delta) statistics
  F  fits        TFO, FO, RCL, 2RC with R0 fixed at R0_edge(T) (TRF multistart + CMA-ES check); then FO(alpha_TFO)
  U  uncertainty TFO(edge-R0): local-scale block bootstrap (bootstrap_v2 primary spec) and lambda profile (profile_v2)
  D  decision    validation files only: causal_full (default) vs causal_knee vs edge_R0
  A  accuracy    identification + test files for the three sets (after D is frozen on disk)
Writes results/identification_refined.json, results/identification_refined_arrays.npz and (via
04b_report in this file) reports/identification_refined_findings.md.

Usage: python scripts/04b_identify_refined.py [--resume] [--from-results]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import identify as ID  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import tempered as TM  # noqa: E402

_spec = importlib.util.spec_from_file_location("ident04", ROOT / "scripts" / "04_identify.py")
I4 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(I4)

RES, REP, FIG = ROOT / "results", ROOT / "reports", ROOT / "figures"
OUT = RES / "identification_refined.json"
CACHE = RES / "identification_refined_runs"
TEMPS = (0, 25, 45)
FAMS = ("TFO", "FO", "FO_alphaTFO", "RCL", "2RC")
TIMING = "causal"
TASK_VERSION = "P1-2026-09-27-a"


def cfg():
    c = D.load_config()
    return c, dict(c["identification_study"]), dict(c["identification_refined"])


def code_hash() -> str:
    c, s, r = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([s, r], sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("src/tfso/model.py", "src/tfso/identify.py", "src/tfso/tempered.py", "src/tfso/data.py", "src/tfso/ocv.py",
              "results/capacity.json", "results/ocv_fits.json", "results/identification.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def cache_io(name: str, obj: dict | None = None):
    CACHE.mkdir(parents=True, exist_ok=True)
    p = CACHE / name
    if obj is not None:
        obj = dict(obj, code_hash=code_hash())
        I4.jdump(obj, p)
        return obj
    if p.exists():
        with open(p, "r", encoding="utf-8") as fh:
            o = json.load(fh)
        if o.get("code_hash") == code_hash():
            return o
    return None


def split_of(lid: str) -> str:
    c = D.load_config()["splits"]
    for k, v in (("identification", "identification_dynamic"), ("validation", "validation_dynamic"), ("test", "test_dynamic")):
        if lid in c[v]:
            return k
    raise KeyError(lid)


def load_file(lid: str, final_evaluation: bool = False) -> dict:
    """verify_file + history + aligned OCV + reference SOC on the profile grid.  Test files need final_evaluation=True
    and a frozen decision on disk (checked here)."""
    sp = split_of(lid)
    if sp == "test":
        if not final_evaluation:
            raise PermissionError(f"{lid} is a test file: final_evaluation=True required")
        with open(OUT, "r", encoding="utf-8") as fh:
            if json.load(fh).get("decision", {}).get("frozen_utc") is None:
                raise PermissionError("test file requested before the parameter-set decision was frozen on disk")
    _, s, _ = cfg()
    df = D.load_raw(lid)
    chk = D.verify_file(lid, df=df)
    T = int(D.CATALOG[lid]["temperature_C"])
    Q = I4.q_id(T)
    H = MD.build_history(lid, Q, h=float(s["h_s"]), df=df)
    ocv = MD.AlignedOCV(T, Q, extrapolation=s["ocv_extrapolation"])
    ref = D.reference_soc(lid, df=df)
    if ref["soc_ref"].size != H.t[H.prof].size:
        raise RuntimeError(f"{lid}: reference SOC grid size mismatch")
    return dict(lid=lid, T=T, split=sp, verified=bool(chk["passed"]), H=H, ocv=ocv, soc_ref=np.asarray(ref["soc_ref"]),
                df=df, profile=D.CATALOG[lid].get("profile"), start_soc=D.CATALOG[lid].get("start_soc_label"))


# ======================================================================================
# Phase E: current edges
# ======================================================================================
def task_edge(T: int) -> dict:
    c, s, rc = cfg()
    e = rc["edge"]
    t0w, t0c = time.perf_counter(), time.process_time()
    lid = I4.id_file(T)
    F = load_file(lid)
    df, H = F["df"], F["H"]
    st = df[D.COL["step"]].to_numpy(); tt = df[D.COL["t"]].to_numpy(); I = df[D.COL["I"]].to_numpy()
    V = df[D.COL["V"]].to_numpy(); stt = df[D.COL["st"]].to_numpy()
    i7 = np.where(st == int(e["profile_step"]))[0]
    newp = np.r_[True, (np.diff(i7) > 1) | (np.diff(stt[i7]) < 0)]
    per = np.cumsum(newp)
    s7, I7, V7, t7 = stt[i7], I[i7], V[i7], tt[i7]
    E = ID.current_edges(s7, I7, per, float(e["dI_min_A"]))
    so = ID.schedule_offset(E["lo"], E["hi"], E["j"], grid_step=float(e["schedule_offset_grid_s"]),
                            tol=float(e["schedule_jitter_tol_s"]))
    R = ID.edge_resistance(s7, I7, V7, E, so["c"], per, float(e["settle_tol_A"]), float(e["settle_tol_rel"]))
    t0_abs = float(D.get_dynamic_profile(lid, h=float(s["h_s"]), df=df)["meta"]["t0_abs_s"])
    t_edge = t7[E["b"]] - R["delta_post"] - t0_abs              # switching instant, s from the profile start
    z = np.interp(t_edge, H.t, H.z)
    vlo, vhi = e["V_limits_V"]
    ok_v = (R["V_post"] >= vlo) & (R["V_post"] <= vhi)
    has_c = np.isfinite(R["delta_post"])
    base = R["clean"] & ok_v & has_c
    rows = dict(delta_post=R["delta_post"], delta_pre=R["delta_pre"], R=R["R"], R_raw=R["R_raw"], dI=R["dI"],
                I_pre=R["I_pre"], I_post=R["I_post"], z=z, t_edge=t_edge, clean=R["clean"], ok_V=ok_v, has_instant=has_c,
                order=E["j"], period=per[E["a"]], pre_slope_V_s=R["pre_slope_V_s"])
    out = dict(T=T, file=lid, verified=F["verified"], n_edges=int(E["a"].size), n_clean=int(R["clean"].sum()),
               n_V_excluded=int((~ok_v).sum()), n_no_instant=int((~has_c).sum()), n_base=int(base.sum()),
               schedule={k: so[k] for k in ("d", "d_lo", "d_hi", "n_orders", "n_orders_consistent", "n_orders_ambiguous",
                                            "n_disjoint_best_sets", "grid_step", "tol")},
               sampling=dict(median_dt_edge_s=float(np.median(E["hi"] - E["lo"])),
                             n_pairs_dt_le_window=int(np.sum((E["hi"] - E["lo"]) <= float(e["window_s"])))),
               rows={k: np.asarray(v).tolist() for k, v in rows.items()},
               wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)
    return cache_io(f"edge_{T}.json", out)


def edge_stats(ed: dict, e: dict, seed: int) -> dict:
    """Statistics of R over the primary and sensitivity subsets of one file's edges."""
    r = {k: np.asarray(v, dtype=float) for k, v in ed["rows"].items()}
    base = r["clean"].astype(bool) & r["ok_V"].astype(bool) & r["has_instant"].astype(bool)
    W, zmin = float(e["window_s"]), float(e["z_min"])
    rng = np.random.default_rng(seed)

    def summ(m, key="R", boot=True):
        x = r[key][m]
        if x.size == 0:
            return dict(n=0)
        o = dict(n=int(x.size), median=float(np.median(x)), iqr=[float(np.percentile(x, 25)), float(np.percentile(x, 75))],
                 mean=float(np.mean(x)), sd=float(np.std(x, ddof=1)) if x.size > 1 else 0.0)
        if boot and x.size >= 5:
            bs = np.median(x[rng.integers(0, x.size, size=(int(e["n_boot"]), x.size))], axis=1)
            o["ci95_median"] = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
        return o
    prim = base & (r["delta_post"] <= W) & (r["z"] >= zmin)
    out = dict(primary=summ(prim), primary_raw_pre_voltage=summ(prim, "R_raw"),
               primary_all_z=summ(base & (r["delta_post"] <= W)),
               window={f"{w:g}": dict(z_ge_min=summ(base & (r["delta_post"] <= w) & (r["z"] >= zmin), boot=True),
                                      all_z=summ(base & (r["delta_post"] <= w), boot=False),
                                      raw_pre=summ(base & (r["delta_post"] <= w) & (r["z"] >= zmin), "R_raw", boot=False))
                       for w in e["window_sensitivity_s"]})
    bw = float(e["delta_bin_s"])
    edges = np.arange(0.0, 1.02 + 1e-9, bw)
    edges[-1] = max(edges[-1], 1.02)
    zc = base & (r["z"] >= zmin)
    out["delta_curve"] = [dict(lo=float(a), hi=float(b), **summ(zc & (r["delta_post"] >= a) & (r["delta_post"] < b), boot=False))
                          for a, b in zip(edges[:-1], edges[1:])]
    lin = zc & (r["delta_post"] <= 0.6)
    if lin.sum() > 5:
        A = np.c_[np.ones(lin.sum()), r["delta_post"][lin]]
        coef = np.linalg.lstsq(A, r["R"][lin], rcond=None)[0]
        out["linear_in_delta_0_to_0.6s"] = dict(intercept=float(coef[0]), slope_Ohm_per_s=float(coef[1]), n=int(lin.sum()))
    b = e["dI_bins_A"]
    out["by_abs_dI"] = [dict(lo=b[i], hi=b[i + 1], **summ(prim & (np.abs(r["dI"]) >= b[i]) & (np.abs(r["dI"]) < b[i + 1]), boot=False))
                        for i in range(len(b) - 1)]
    rest = 0.05
    out["by_direction"] = {
        "dI>0 (towards charge)": summ(prim & (r["dI"] > 0), boot=False),
        "dI<0 (towards discharge)": summ(prim & (r["dI"] < 0), boot=False),
        "from rest": summ(prim & (np.abs(r["I_pre"]) < rest), boot=False),
        "to rest": summ(prim & (np.abs(r["I_post"]) < rest), boot=False),
        "load to load": summ(prim & (np.abs(r["I_pre"]) >= rest) & (np.abs(r["I_post"]) >= rest), boot=False),
        "post level charge (I>0)": summ(prim & (r["I_post"] > rest), boot=False),
        "post level discharge (I<0)": summ(prim & (r["I_post"] < -rest), boot=False)}
    zb = e["z_bins"]
    out["by_z"] = [dict(lo=zb[i], hi=zb[i + 1], **summ(base & (r["delta_post"] <= W) & (r["z"] >= zb[i]) & (r["z"] < zb[i + 1]), boot=False))
                   for i in range(len(zb) - 1)]
    out["knee_z_lt_min"] = summ(base & (r["delta_post"] <= W) & (r["z"] < zmin), boot=False)
    # Spearman correlation of R with |dI| (primary subset)
    from scipy.stats import spearmanr
    if prim.sum() > 5:
        rho = spearmanr(np.abs(r["dI"][prim]), r["R"][prim])
        out["spearman_R_vs_abs_dI"] = dict(rho=float(rho.statistic), p=float(rho.pvalue))
    return out


def model_edge_curves(J0: dict, T: int, deltas: np.ndarray) -> dict:
    """Continuous-time step responses R(delta) = R0 + V_p(delta)/1 A of the identified (free-R0) fits."""
    P = J0["per_T"][str(T)]
    out = {}
    for key, fam, th in (("TFO", "TFO", P["fits"]["TFO"]["theta"]), ("FO", "FO", P["fits"]["FO"]["theta"]),
                         ("TFO_knee", "TFO", P["sensitivity"]["knee"]["fits"]["TFO"]["theta"]),
                         ("2RC", "2RC", P["fits"]["2RC"]["theta"])):
        if fam == "2RC":
            v = th["R0"] + th["R1"] * (1 - np.exp(-deltas / th["tau1"])) + th["R2"] * (1 - np.exp(-deltas / th["tau2"]))
        else:
            a, b = 1.0 / (th["Rp"] * th["Cp"]), 1.0 / th["Cp"]
            v = th["R0"] + TM.exact_step_response(th["alpha"], th["lam"], a, b, 1.0, deltas) if th["alpha"] < 1 else \
                th["R0"] + b / (a + th["lam"]) * (1 - np.exp(-(a + th["lam"]) * deltas))
        out[key] = np.asarray(v, float).tolist()
    return out


# ======================================================================================
# Phase F: edge-R0 fits (sensitivity)
# ======================================================================================
def task_fit(T: int, fam: str, R0e: float, extra_fixed: dict | None = None) -> dict:
    """TRF multistart (identification_study seeds/starts) + CMA-ES check, R0 fixed at R0_edge(T)."""
    c, s, rc = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    F = load_file(I4.id_file(T))
    H, ocv = F["H"], F["ocv"]
    B = s["bounds"]
    fixed = dict(extra_fixed or {}, R0=float(R0e))
    prob = ID.Problem(fam, H, ocv, B, fixed=fixed, lam_scale=float(s["lambda_asinh_scale"]), timing=TIMING)
    ti, fi = TEMPS.index(T), FAMS.index(fam)
    starts = ID.lhs_starts(prob.p, int(s["multistart"]), int(s["seeds"]["lhs"]) + 100 * ti + fi)
    runs = []
    for r, u0 in enumerate(starts):
        out = ID.run_trf(prob, u0, max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]),
                         xtol=float(c["identification"]["trf"]["xtol"]), ftol=float(c["identification"]["trf"]["ftol"]))
        out.update(run=r, optimizer="trf"); out.pop("trace", None)
        runs.append(out)
    cc = c["identification"]["cmaes"]
    for r in range(int(rc["refit"]["cmaes_check_runs"])):
        out = ID.run_cmaes(prob, starts[r], int(s["seeds"]["cmaes"]) + r, int(s["eval_budget"]), sigma0=float(cc["sigma0"]),
                           popsize=int(cc["popsize"]))
        out.update(run=r, optimizer="cmaes"); out.pop("trace", None)
        runs.append(out)
    b = min(runs, key=lambda q: q["rmse_mV"])
    rr = prob.model_V(b["theta"]) - prob.target
    btrf = min((q for q in runs if q["optimizer"] == "trf"), key=lambda q: q["rmse_mV"])
    bcma = min((q for q in runs if q["optimizer"] == "cmaes"), key=lambda q: q["rmse_mV"])
    res = dict(T=T, family=fam, fixed=prob.fixed, free=prob.free, runs=runs, best_trf_mV=btrf["rmse_mV"],
               best_cmaes_mV=bcma["rmse_mV"], cmaes_improves_trf_by_mV=btrf["rmse_mV"] - bcma["rmse_mV"],
               best_residual=I4.resid_dependence(rr, s, H.h), wall_s=time.perf_counter() - t0w,
               cpu_s=time.process_time() - t0c)
    tag = "" if not extra_fixed else "_a"
    return cache_io(f"fit_{T}_{fam}{tag}.json", res)


# ======================================================================================
# Phase U: bootstrap and lambda profile of TFO(edge R0)
# ======================================================================================
def task_boot(T: int, theta_hat: dict, R0e: float) -> dict:
    """identification_study.bootstrap_v2 primary spec (TFO, whole window, block_s, n_boot, two starts); R0 fixed.
    Same random stream as the free-R0 TFO_full bootstrap of scripts/04_identify.py (paired resamples)."""
    c, s, rc = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    bc = s["bootstrap_v2"]
    F = load_file(I4.id_file(T))
    H, ocv = F["H"], F["ocv"]
    B, ls = s["bounds"], float(s["lambda_asinh_scale"])
    g = MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    fixed = {"R0": float(R0e)}
    pf = ID.Problem("TFO", H, ocv, B, fixed=fixed, lam_scale=ls, grid=g, timing=TIMING)
    Vhat = pf.model_V(theta_hat)
    e = pf.target - Vhat
    sig, table = ID.local_scale(e, H.z[H.prof], int(bc["n_scale_bins"]))
    L = int(round(float(bc["block_s"]) / H.h))
    rng = np.random.default_rng(int(s["seeds"]["bootstrap"]) + 1000 * TEMPS.index(T) + 10 * 0)
    th2 = dict(theta_hat, lam=float(bc["extra_start_lambda"]) if theta_hat["lam"] < 1e-4 else 0.0)
    draws, rms, conv, from2, der = [], [], [], [], []
    for _ in range(int(bc["n_boot"])):
        Vs = Vhat + ID.wild_block_resample(e, sig, L, rng)
        pb = ID.Problem("TFO", H, ocv, B, fixed=fixed, lam_scale=ls, V_target=Vs, grid=g, timing=TIMING)
        best, k2 = None, False
        for k, th0 in enumerate((theta_hat, th2)):
            rr = ID.run_trf(pb, pb.to_u(th0), max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]))
            if best is None or rr["rmse_mV"] < best["rmse_mV"] - 1e-9:
                best, k2 = rr, k == 1
        t_ = dict(best["theta"])
        draws.append(t_); rms.append(best["rmse_mV"]); conv.append(best["converged"]); from2.append(k2)
        der.append(I4.derived("TFO", t_, TIMING, H.h))
    keys = [k for k in ID.FAMILY_FREE["TFO"] if k != "R0"]
    tol = float(bc["at_bound_unit_tol"])
    stats = {}
    for k in keys + ["R_1s_Ohm", "R_dc_Ohm"]:
        v = np.array([d[k] for d in draws]) if k in keys else np.array([d[k] for d in der])
        st = dict(ci95=[float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))], median=float(np.median(v)))
        if k in keys:
            u = np.array([ID.unit_position(k, x, B, ls) for x in v])
            st["frac_at_lower"] = float(np.mean(u <= tol)); st["frac_at_upper"] = float(np.mean(u >= 1 - tol))
        else:
            st["frac_at_lower"] = st["frac_at_upper"] = 0.0
        st["ci_valid"] = bool(st["frac_at_lower"] + st["frac_at_upper"] <= float(bc["max_frac_at_bound_for_ci"]))
        stats[k] = st
    lam_d = np.array([d["lam"] for d in draws])
    out = dict(T=T, spec="TFO_full_edgeR0", R0_fixed=float(R0e), block_s=float(bc["block_s"]), n_boot=int(bc["n_boot"]),
               stats=stats, draws={k: [d[k] for d in draws] for k in keys}, rmse_mV=rms,
               rmse_hat_mV=float(np.sqrt(np.mean(e ** 2)) * 1e3),
               rmse_quantiles_mV=[float(np.percentile(rms, q)) for q in (5, 50, 95)], n_converged=int(sum(conv)),
               n_best_from_second_start=int(sum(from2)),
               frac_lambda_at_0=float(np.mean(lam_d < float(s["lambda_zero_report"]))),
               wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)
    return cache_io(f"boot_{T}.json", out)


def task_profile(T: int, theta_hat: dict, R0e: float) -> dict:
    """lambda profile of TFO(edge R0), whole window, profile_v2 grid/starts, LR with the HAC n_eff (as 04_identify)."""
    c, s, rc = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    F = load_file(I4.id_file(T))
    H, ocv = F["H"], F["ocv"]
    B, ls = s["bounds"], float(s["lambda_asinh_scale"])
    g = MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    pc = s["profile_v2"]
    prob = ID.Problem("TFO", H, ocv, B, fixed={"R0": float(R0e)}, lam_scale=ls, grid=g, timing=TIMING)
    r_hat = prob.model_V(theta_hat) - prob.target
    dep = I4.resid_dependence(r_hat, s, H.h)
    n, tau = dep["n"], dep["tau"]
    rmse_hat = float(np.sqrt(np.mean(r_hat ** 2)) * 1e3)
    rows = ID.profile_likelihood_fixed("TFO", H, ocv, B, theta_hat, "lam", pc["lambda_grid"], {"R0": float(R0e)},
                                       lam_scale=ls, fft_grid=g, max_nfev=int(pc["max_nfev"]),
                                       diff_step=float(s["trf_diff_step"]), timing=TIMING,
                                       extra_starts=pc["extra_starts_lambda"])
    rm = min(min(r["rmse_mV"] for r in rows), rmse_hat)
    for r in rows:
        r["LR_nominal"] = 2 * n * math.log(r["rmse_mV"] / rm)
        r["LR_eff"] = r["LR_nominal"] / tau
    vals = [r["value"] for r in rows]
    zc = float(pc["crit_zero"])
    ci = ID.profile_interval(vals, [r["LR_eff"] for r in rows], float(pc["crit_interior"]), log=True, zero_crit=zc)
    r0 = [r for r in rows if r["value"] == 0.0][0]
    bws = {str(b): r0["LR_nominal"] / v["tau"] for b, v in dep["hac_sensitivity"].items()}
    out = dict(T=T, R0_fixed=float(R0e), theta_hat=theta_hat, rmse_hat_mV=rmse_hat, rmse_min_mV=rm,
               profile_found_lower=bool(rm < rmse_hat - 1e-6), dependence=dep, rows=rows, ci_eff=ci,
               zero_test=dict(LR_nominal=r0["LR_nominal"], LR_eff=r0["LR_eff"], delta_rmse_mV=r0["rmse_mV"] - rm,
                              excludes_0_eff=bool(r0["LR_eff"] > zc), LR_eff_by_bandwidth=bws,
                              n_bandwidths_rejecting=int(sum(v > zc for v in bws.values()) + (r0["LR_eff"] > zc))),
               n_unconverged=int(sum(not r["converged"] for r in rows)), wall_s=time.perf_counter() - t0w,
               cpu_s=time.process_time() - t0c)
    return cache_io(f"profile_{T}.json", out)


# ======================================================================================
# Phases D and A: open-loop accuracy of the parameter sets
# ======================================================================================
def accuracy_one(fam: str, theta: dict, F: dict, s: dict, grid, adm: tuple) -> dict:
    """Section-7 statistics (scripts/04_identify.evaluate) + RMSE over the admissible reference-SOC interval."""
    H = F["H"]
    st, _ = I4.evaluate(fam, theta, H, F["ocv"], s, TIMING, grid=None if fam == "2RC" else grid, full_stats=True)
    prob = ID.Problem(fam, H, F["ocv"], s["bounds"], fixed={k: theta[k] for k in ("alpha", "lam") if fam != "2RC"},
                      grid=None if fam == "2RC" else grid, timing=TIMING, lam_scale=float(s["lambda_asinh_scale"]))
    r = prob.model_V(theta) - H.V[H.prof]
    m = (F["soc_ref"] >= adm[0]) & (F["soc_ref"] <= adm[1])
    st["rmse_admissible_mV"] = float(np.sqrt(np.mean(r[m] ** 2)) * 1e3)
    st["frac_samples_admissible"] = float(m.mean())
    return st


def task_accuracy(lid: str, sets: dict, final_evaluation: bool = False) -> dict:
    """sets: {set_name: {fam: theta}} -> accuracy per set and family on one file."""
    c, s, rc = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    F = load_file(lid, final_evaluation=final_evaluation)
    g = MD.FFTGrid(F["H"].I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    adm = tuple(float(x) for x in rc["admissible_soc_interval"])
    acc = {k: {f: accuracy_one(f, th, F, s, g, adm) for f, th in fs.items()} for k, fs in sets.items()}
    info = dict(file=lid, T=F["T"], split=F["split"], verified=F["verified"], profile=F["profile"], start_soc=F["start_soc"],
                loaded_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return dict(info=info, accuracy=acc, wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)


def run_pool(jobs: dict, resume: bool, nw: int) -> dict:
    """jobs: {key: (cache_name or None, fn, args)}."""
    out, futs = {}, {}
    with ProcessPoolExecutor(max_workers=nw) as ex:
        for k, (cn, fn, a) in jobs.items():
            cached = cache_io(cn) if (resume and cn) else None
            if cached is not None:
                out[k] = cached
            else:
                futs[k] = ex.submit(fn, *a)
        for k, f in futs.items():
            out[k] = f.result()
            print(f"[done] {k}", flush=True)
    return out


# ======================================================================================
# Orchestration
# ======================================================================================
def load_J0() -> dict:
    with open(RES / "identification.json", "r", encoding="utf-8") as fh:
        return json.load(fh)


def default_sets(J0: dict, T: int) -> dict:
    P = J0["per_T"][str(T)]
    return {"causal_full": {f: P["fits"][f]["theta"] for f in FAMS},
            "causal_knee": {f: P["sensitivity"]["knee"]["fits"][f]["theta"] for f in FAMS}}


def decide(acc_val: dict, rc: dict) -> dict:
    """Pre-declared rule (config identification_refined.decision_rule) on the validation accuracies."""
    dr = rc["decision_rule"]
    fams = list(dr["families_checked"])
    imp_min, wor_max = float(dr["improve_z_ge_knee_min_frac"]), float(dr["worsen_whole_max_frac"])
    files = sorted(acc_val)

    def mean(setn, fam, key):
        return float(np.mean([acc_val[l]["accuracy"][setn][fam][key] for l in files]))
    table, qual = {}, {}
    for A in ("causal_knee", "edge_R0"):
        rows = {}
        for f in fams:
            zD, zA = mean("causal_full", f, "rmse_z_ge_knee_mV"), mean(A, f, "rmse_z_ge_knee_mV")
            wD, wA = mean("causal_full", f, "rmse_mV"), mean(A, f, "rmse_mV")
            rows[f] = dict(rmse_z_ge_knee_default_mV=zD, rmse_z_ge_knee_alt_mV=zA, improvement_frac=1 - zA / zD,
                           rmse_whole_default_mV=wD, rmse_whole_alt_mV=wA, worsening_frac=wA / wD - 1,
                           rmse_admissible_default_mV=mean("causal_full", f, "rmse_admissible_mV"),
                           rmse_admissible_alt_mV=mean(A, f, "rmse_admissible_mV"),
                           passes=bool(1 - zA / zD > imp_min and wA / wD - 1 <= wor_max))
        table[A] = rows
        qual[A] = all(r["passes"] for r in rows.values())
    cands = [A for A in qual if qual[A]]
    if cands:
        chosen = max(cands, key=lambda A: np.mean([table[A][f]["improvement_frac"] for f in fams]))
    else:
        chosen = "causal_full"
    return dict(rule=dr["rule"], families_checked=fams, validation_files=files, table=table, qualifies=qual,
                chosen=chosen, frozen_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                note="taken on validation files only; written to disk before any test file was loaded by this script")


def compute(resume: bool) -> dict:
    c, s, rc = cfg()
    tw0, tc0 = time.perf_counter(), time.process_time()
    nw = int(rc["max_workers"])
    J0 = load_J0()
    B = s["bounds"]
    # ---- E: edges
    RE = run_pool({T: (f"edge_{T}.json", task_edge, (T,)) for T in TEMPS}, resume, nw)
    e = rc["edge"]
    ES = {T: edge_stats(RE[T], e, int(e["seed"]) + TEMPS.index(T)) for T in TEMPS}
    R0e = {T: ES[T]["primary"]["median"] for T in TEMPS}
    print("R0_edge", R0e, flush=True)
    # ---- F: fits with R0 fixed
    RF = run_pool({(T, f): (f"fit_{T}_{f}.json", task_fit, (T, f, R0e[T])) for T in TEMPS for f in ("TFO", "FO", "RCL", "2RC")},
                  resume, nw)
    pre = {T: I4.nested_best({f: RF[(T, f)] for f in ("TFO", "FO", "RCL", "2RC")}) for T in TEMPS}
    RA = run_pool({T: (f"fit_{T}_FO_alphaTFO_a.json", task_fit,
                       (T, "FO_alphaTFO", R0e[T], {"alpha": pre[T]["TFO"]["theta"]["alpha"], "lam": 0.0})) for T in TEMPS},
                  resume, nw)
    bests = {}
    for T in TEMPS:
        d = {f: RF[(T, f)] for f in ("TFO", "FO", "RCL", "2RC")}
        d["FO_alphaTFO"] = RA[T]
        bests[T] = I4.nested_best(d)
    edge_set = {T: {f: dict(bests[T][f]["theta"]) for f in FAMS} for T in TEMPS}
    for T in TEMPS:     # 2RC branches labelled tau1 <= tau2
        th = edge_set[T]["2RC"]
        edge_set[T]["2RC"] = MD.TwoRCParams(**{k: th[k] for k in ("R0", "R1", "tau1", "R2", "tau2", "s", "dq")}).sorted().to_dict()
    # ---- U: bootstrap and lambda profile (TFO edge)
    jobs = {}
    for T in TEMPS:
        jobs[("boot", T)] = (f"boot_{T}.json", task_boot, (T, edge_set[T]["TFO"], R0e[T]))
        jobs[("profile", T)] = (f"profile_{T}.json", task_profile, (T, edge_set[T]["TFO"], R0e[T]))
    RU = run_pool(jobs, resume, nw)
    # ---- D: decision on validation files only
    sets = {T: dict(default_sets(J0, T), edge_R0=edge_set[T]) for T in TEMPS}
    val = [l for l in c["splits"]["validation_dynamic"]]
    RV = run_pool({l: (None, task_accuracy, (l, sets[int(D.CATALOG[l]["temperature_C"])], False)) for l in val}, False, nw)
    dec = decide(RV, rc)
    partial = dict(generated_utc=dec["frozen_utc"], status="decision frozen; test files not yet loaded by this script",
                   R0_edge_Ohm={str(T): R0e[T] for T in TEMPS}, decision=dec,
                   chosen_parameter_sets={str(T): sets[T][dec["chosen"]] for T in TEMPS})
    I4.jdump(partial, OUT)
    print("decision", dec["chosen"], flush=True)
    # ---- A: identification and test files (after the decision is on disk)
    ident = list(c["splits"]["identification_dynamic"])
    test = list(c["splits"]["test_dynamic"])
    jobsA = {l: (None, task_accuracy, (l, sets[int(D.CATALOG[l]["temperature_C"])], l in test)) for l in ident + test}
    t_test0 = datetime.now(timezone.utc).isoformat(timespec="seconds")
    RAcc = run_pool(jobsA, False, nw)
    RAcc.update(RV)
    worker_cpu = sum(float(x.get("cpu_s", 0.0)) for dct in (RE, RF, RA, RU) for x in dct.values()) + \
        sum(float(x["cpu_s"]) for x in RAcc.values())
    runtime = dict(main_wall_s=time.perf_counter() - tw0, main_process_s=time.process_time() - tc0,
                   worker_process_s_sum=worker_cpu, max_workers=nw, resumed=bool(resume),
                   note="process time = main process + sum of worker-task process times (tasks read from cache report their original times)")
    return assemble(J0, RE, ES, R0e, RF, RA, bests, edge_set, RU, dec, RAcc, sets, runtime, t_test0)


# ======================================================================================
# Assembly
# ======================================================================================
SETS = ("causal_full", "causal_knee", "edge_R0")
GROUPS = (("DST 80 % (identification)", lambda i: i["split"] == "identification"),
          ("DST 50 % (validation)", lambda i: i["split"] == "validation"),
          ("FUDS (test)", lambda i: i["split"] == "test" and i["profile"] == "FUDS"),
          ("US06 (test)", lambda i: i["split"] == "test" and i["profile"] == "US06"),
          ("BJDST (test)", lambda i: i["split"] == "test" and i["profile"] == "BJDST"))
ACC_KEYS = ("rmse_mV", "rmse_z_ge_knee_mV", "rmse_admissible_mV", "max_abs_mV", "mae_mV", "acf_lag1", "ljung_box_p",
            "frac_ocv_extrapolated", "frac_samples_z_below_knee", "frac_samples_admissible")


def group_tables(acc: dict) -> dict:
    """{set: {group: {fam: {key: mean over T of (mean over the group's files at T)}}}} (as identification_findings s. 7)."""
    out = {}
    for sn in SETS:
        out[sn] = {}
        for gname, pred in GROUPS:
            per_T = []
            for T in TEMPS:
                ls = [l for l, a in acc.items() if a["info"]["T"] == T and pred(a["info"])]
                per_T.append({f: {k: float(np.mean([acc[l]["accuracy"][sn][f][k] for l in ls])) for k in ACC_KEYS[:5]}
                              for f in FAMS})
            out[sn][gname] = {f: {k: float(np.mean([p[f][k] for p in per_T])) for k in ACC_KEYS[:5]} for f in FAMS}
            out[sn][gname]["_per_T"] = {str(T): p for T, p in zip(TEMPS, per_T)}
    return out


def test_wins(acc: dict) -> dict:
    out = {}
    for sn in SETS:
        wins = {f: 0 for f in FAMS}
        vals = {f: [] for f in FAMS}
        for l, a in acc.items():
            if a["info"]["split"] != "test":
                continue
            r = a["accuracy"][sn]
            wins[min(FAMS, key=lambda f: r[f]["rmse_mV"])] += 1
            for f in FAMS:
                vals[f].append(r[f]["rmse_mV"])
        out[sn] = dict(rmse_wins=wins, median_rmse_mV={f: float(np.median(v)) for f, v in vals.items()},
                       n_files=int(sum(wins.values())))
    return out


def assemble(J0, RE, ES, R0e, RF, RA, bests, edge_set, RU, dec, RAcc, sets, runtime, t_test0) -> dict:
    c, s, rc = cfg()
    B, ls, tolu = s["bounds"], float(s["lambda_asinh_scale"]), float(s["near_bound_unit_tol"])
    deltas = np.round(np.arange(0.01, 1.0201, 0.01), 4)
    J = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), script="scripts/04b_identify_refined.py",
             code_hash=code_hash(), settings=rc, input_timing=TIMING, runtime=runtime,
             splits=dict(identification=c["splits"]["identification_dynamic"], validation=c["splits"]["validation_dynamic"],
                         test=c["splits"]["test_dynamic"]),
             sign_note="R = dV/dI with the Arbin sign (I > 0 charge) = -dV/dI in the discharge-positive convention",
             edge={}, edge_fits={}, decision=dec, test_phase_started_utc=t_test0, accuracy={}, per_file_info={})
    for T in TEMPS:
        P0 = J0["per_T"][str(T)]
        st = ES[T]
        tfo, knee = P0["fits"]["TFO"], P0["sensitivity"]["knee"]["fits"]["TFO"]
        comp = dict(R0_edge=R0e[T], R0_edge_ci95=st["primary"].get("ci95_median"),
                    R0_TFO_causal_full=tfo["theta"]["R0"], R0_TFO_causal_knee=knee["theta"]["R0"],
                    R0_FO_causal_full=P0["fits"]["FO"]["theta"]["R0"], R0_2RC_causal_full=P0["fits"]["2RC"]["theta"]["R0"],
                    R_1s_TFO_causal_full=tfo["step_response"]["R_1s_Ohm"],
                    R_1s_TFO_ci95=P0["bootstrap"]["TFO_full"]["stats"]["R_1s_Ohm"]["ci95"],
                    R_1s_2RC_causal_full=P0["fits"]["2RC"]["step_response"]["R_1s_Ohm"],
                    R0_bootstrap_ci95_TFO=P0["bootstrap"]["TFO_full"]["stats"]["R0"]["ci95"],
                    R0_bootstrap_ci_valid_TFO=P0["bootstrap"]["TFO_full"]["stats"]["R0"]["ci_valid"])
        comp["ratio_R0_edge_over_R0_TFO"] = R0e[T] / comp["R0_TFO_causal_full"]
        comp["ratio_R0_edge_over_R1s_TFO"] = R0e[T] / comp["R_1s_TFO_causal_full"]
        J["edge"][str(T)] = dict({k: v for k, v in RE[T].items() if k not in ("rows", "code_hash")}, stats=st,
                                 comparison=comp, model_curves=dict(delta_s=deltas.tolist(), **model_edge_curves(J0, T, deltas)))
        # ---- edge-R0 fits
        fits = {}
        for f in FAMS:
            src = RA[T] if f == "FO_alphaTFO" else RF[(T, f)]
            fr = I4.fit_record(f, bests[T][f], src["runs"], B, s, TIMING, full=False)
            fr["at_bound"] = [k for k in fr["at_bound"] if k != "R0"]
            fr["near_bound"] = [k for k in fr["near_bound"] if k != "R0"]
            fr["theta"] = edge_set[T][f]
            fr["optimizer_check"] = dict(best_trf_mV=src["best_trf_mV"], best_cmaes_mV=src["best_cmaes_mV"],
                                         cmaes_improves_trf_by_mV=src["cmaes_improves_trf_by_mV"],
                                         wall_s=src["wall_s"], cpu_s=src["cpu_s"])
            fr["rmse_free_R0_mV"] = P0["fits"][f]["rmse_mV"]
            fr["delta_rmse_vs_free_R0_mV"] = fr["rmse_mV"] - P0["fits"][f]["rmse_mV"]
            fits[f] = fr
        pr, bo = RU[("profile", T)], RU[("boot", T)]
        J["edge_fits"][str(T)] = dict(R0_fixed_Ohm=R0e[T], fits=fits,
                                      bootstrap={k: v for k, v in bo.items() if k not in ("draws", "rmse_mV", "code_hash")},
                                      lambda_profile=dict(rows=[{k: r[k] for k in ("value", "rmse_mV", "LR_eff", "LR_nominal",
                                                                                   "converged", "best_start")} for r in pr["rows"]],
                                                          ci_eff=pr["ci_eff"], zero_test=pr["zero_test"],
                                                          tau_hac=pr["dependence"]["tau"], rmse_hat_mV=pr["rmse_hat_mV"],
                                                          rmse_min_mV=pr["rmse_min_mV"],
                                                          profile_found_lower=pr["profile_found_lower"],
                                                          n_unconverged=pr["n_unconverged"], wall_s=pr["wall_s"], cpu_s=pr["cpu_s"]),
                                      TFO_minus_FO_mV=fits["TFO"]["rmse_mV"] - fits["FO"]["rmse_mV"],
                                      TFO_minus_2RC_mV=fits["TFO"]["rmse_mV"] - fits["2RC"]["rmse_mV"])
    # ---- accuracy
    for l, a in RAcc.items():
        J["per_file_info"][l] = a["info"]
        J["accuracy"][l] = {sn: {f: {k: a["accuracy"][sn][f][k] for k in ACC_KEYS} for f in FAMS} for sn in SETS}
    J["accuracy_groups"] = group_tables(RAcc)
    J["test_wins"] = test_wins(RAcc)
    J["all_files_verified"] = bool(all(a["info"]["verified"] for a in RAcc.values()) and
                                   all(RE[T]["verified"] for T in TEMPS))
    # consistency: causal_full accuracy recomputed here vs identification.json
    dmax = 0.0
    for l, a in RAcc.items():
        T = a["info"]["T"]
        for f in FAMS:
            dmax = max(dmax, abs(a["accuracy"]["causal_full"][f]["rmse_mV"] - J0["per_T"][str(T)]["accuracy"][l][f]["rmse_mV"]))
    J["consistency_max_abs_diff_rmse_vs_identification_json_mV"] = dmax
    J["chosen_parameter_sets"] = {str(T): sets[T][dec["chosen"]] for T in TEMPS}
    J["all_parameter_sets"] = {str(T): sets[T] for T in TEMPS}
    return J


def save_arrays(RE: dict, J: dict):
    A = {}
    for T in TEMPS:
        for k, v in RE[T]["rows"].items():
            A[f"edge__{T}__{k}"] = np.asarray(v, float)
        mc = J["edge"][str(T)]["model_curves"]
        for k, v in mc.items():
            A[f"edgemodel__{T}__{k}"] = np.asarray(v, float)
        cur = J["edge"][str(T)]["stats"]["delta_curve"]
        A[f"edgecurve__{T}"] = np.array([[q["lo"], q["hi"], q.get("n", 0), q.get("median", np.nan),
                                          (q.get("iqr") or [np.nan, np.nan])[0], (q.get("iqr") or [np.nan, np.nan])[1]]
                                         for q in cur], float)
        rows = J["edge_fits"][str(T)]["lambda_profile"]["rows"]
        A[f"lamprofile_edge__{T}"] = np.array([[r["value"], r["rmse_mV"], r["LR_eff"]] for r in rows], float)
    np.savez_compressed(RES / "identification_refined_arrays.npz", **A)


def make_all(J: dict, A: dict):
    """Report and figures (defined in the REPORT section below when present)."""
    fn = globals().get("make_report_and_figures")
    if fn is None:
        print("report section not present: report/figures skipped", flush=True)
        return
    fn(J, A)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--from-results", action="store_true")
    a = ap.parse_args()
    tw0, tc0 = time.perf_counter(), time.process_time()
    if not a.from_results:
        J = compute(a.resume)
        I4.jdump(J, OUT)
        RE = {T: cache_io(f"edge_{T}.json") for T in TEMPS}
        with open(OUT, "r", encoding="utf-8") as fh:
            J = json.load(fh)
        save_arrays(RE, J)
    with open(OUT, "r", encoding="utf-8") as fh:
        J = json.load(fh)
    make_all(J, dict(np.load(RES / "identification_refined_arrays.npz")))
    print(f"total wall {time.perf_counter() - tw0:.1f} s, main process {time.process_time() - tc0:.1f} s", flush=True)


# ======================================================================================
# REPORT and FIGURES (generated from results/identification_refined.json, identification_refined_arrays.npz and,
# when present, results/identification_memory.json; nothing is hand-typed)
# ======================================================================================
def _f(v, d=3):
    if v is None:
        return "-"
    if isinstance(v, str):
        return v
    if v != 0 and (abs(v) < 1e-3 or abs(v) >= 1e4):
        return f"{v:.2e}"
    return f"{v:.{d}f}"


def _mo(v):
    return _f(None if v is None else 1e3 * v, 1)


def main_report_only():
    with open(OUT, "r", encoding="utf-8") as fh:
        J = json.load(fh)
    make_all(J, dict(np.load(RES / "identification_refined_arrays.npz")))


def _load_mem():
    p = RES / "identification_memory.json"
    if not p.exists():
        return None
    with open(p, "r", encoding="utf-8") as fh:
        return json.load(fh)


def fig_edge(J, A):
    from tfso import plotstyle as ps
    plt = ps.setup()
    fig, axs = plt.subplots(1, 3, figsize=ps.figsize("text", 58), layout="constrained")
    for k, T in enumerate(TEMPS):
        ax = axs[k]
        cur = A[f"edgecurve__{T}"]
        mid = 0.5 * (cur[:, 0] + cur[:, 1])
        ok = cur[:, 2] >= 5
        ax.errorbar(mid[ok], 1e3 * cur[ok, 3], yerr=[1e3 * (cur[ok, 3] - cur[ok, 4]), 1e3 * (cur[ok, 5] - cur[ok, 3])],
                    fmt="o", ms=3.5, color=ps.INK, ecolor=ps.INK2, elinewidth=0.7, capsize=0, label="edges (median, IQR)")
        d = A[f"edgemodel__{T}__delta_s"]
        ax.plot(d, 1e3 * A[f"edgemodel__{T}__TFO"], color=ps.SLOTS[0], ls="-", lw=1.2, label="TFO fit, continuous step")
        ax.plot(d, 1e3 * A[f"edgemodel__{T}__2RC"], color=ps.SLOTS[1], ls="--", lw=1.2, label="2RC fit, continuous step")
        c = J["edge"][str(T)]["comparison"]
        ax.axhline(1e3 * c["R0_TFO_causal_full"], color=ps.SLOTS[0], ls=":", lw=0.7, label="$R_0$ of the TFO fit")
        ax.axhline(1e3 * c["R0_edge"], color=ps.INK2, ls="-.", lw=0.7, label="$R_{0,edge}$ (median, $\\delta\\leq$0.25 s)")
        ax.axvspan(0, float(J["settings"]["edge"]["window_s"]), color=ps.SHADE, zorder=0)
        ax.set_title(f"{T} °C", fontsize=8.5)
        ax.set_xlabel("delay of post-edge sample $\\delta$ (s)")
        if k == 0:
            ax.set_ylabel("$\\Delta V/\\Delta I$ (m$\\Omega$)")
        ps.panel_label(ax, k)
    axs[0].legend(loc="lower right", bbox_to_anchor=(1.0, 0.06), fontsize=7)
    return ps.save(fig, FIG / "draft_p1_edge_R0.pdf")


def fig_memory(M):
    from tfso import plotstyle as ps
    plt = ps.setup()
    Ls = [L for L in M["L_s"] if L != "full"]
    fig, axs = plt.subplots(3, 3, figsize=ps.figsize("text", 150), layout="constrained", sharex=True)
    xfull = 6400.0
    for k, T in enumerate(TEMPS):
        rows = M["per_T"][str(T)]["rows"]
        get = lambda cfgn, lam=None: [next(q for q in rows if q["L"] == L and q["config"] == cfgn and q["lam_fixed"] == lam)
                                      for L in Ls + ["full"]]
        x = np.array([float(L) for L in Ls] + [xfull])
        fo, tf = get("FO_trunc"), get("TFO_trunc")
        for j, (key, lab) in enumerate((("identification", "identification RMSE (mV)"), ("validation", "validation RMSE (mV)"))):
            ax = axs[j, k]
            ax.plot(x, [q[key]["rmse_mV"] for q in fo], color=ps.SLOTS[1], ls="--", marker="s", ms=3.5, label="FO-trunc")
            ax.plot(x, [q[key]["rmse_mV"] for q in tf], color=ps.SLOTS[0], ls="-", marker="o", ms=3.5, label="TFO-trunc")
            for i, lam in enumerate(M["lambda_grid"][::2]):
                g = get("TFO_grid", lam)
                ax.plot(x, [q[key]["rmse_mV"] for q in g], color=ps.MUTED, ls=[":", "-.", (0, (6, 2))][i % 3], lw=0.8,
                        label=f"TFO-grid $\\lambda$={lam:g}")
            if k == 0:
                ax.set_ylabel(lab)
        ax = axs[2, k]
        ax.plot(x[:-1], [q["bounds"]["trunc_untempered"] for q in fo[:-1]], color=ps.SLOTS[1], ls="--", marker="s", ms=3.5,
                label="untempered bound (FO-trunc)")
        ax.plot(x[:-1], [q["bounds"]["trunc_gamma"] for q in tf[:-1]], color=ps.SLOTS[0], ls="-", marker="o", ms=3.5,
                label="tempered bound (TFO-trunc)")
        for i, lam in enumerate(M["lambda_grid"][::2]):
            g = get("TFO_grid", lam)
            ax.plot(x[:-1], [q["bounds"]["trunc_gamma"] for q in g[:-1]], color=ps.MUTED, ls=[":", "-.", (0, (6, 2))][i % 3],
                    lw=0.8)
        ax.set_yscale("log")
        if k == 0:
            ax.set_ylabel("truncation bound (V s$^{-\\alpha}$)")
        ax.set_xlabel("memory L (s); rightmost = full")
        for j in range(3):
            axs[j, k].set_xscale("log")
            ps.panel_label(axs[j, k], 3 * j + k)
        axs[0, k].set_title(f"{T} °C", fontsize=8.5)
    h_, l_ = axs[0, 0].get_legend_handles_labels()
    fig.legend(h_, l_, loc="outside lower center", ncol=5, fontsize=7)
    axs[2, 0].legend(loc="lower left", fontsize=7)
    return ps.save(fig, FIG / "draft_p1_memory.pdf")


def report_lines(J: dict, M: dict | None) -> list[str]:
    e = J["settings"]["edge"]
    L = ["# Refined identification (P1): edge R0 cross-check, parameter-set decision, memory-budget identification", "",
         f"Generated by `scripts/04b_identify_refined.py` (+ `scripts/04c_memory_identification.py`) from "
         f"`results/identification_refined.json`{' and `results/identification_memory.json`' if M else ''} "
         f"({J['generated_utc']}, code hash {J['code_hash']}). Every number is read from those files. Causal input timing "
         f"only. All files pass `data.verify_file`: {J['all_files_verified']}.", ""]
    # ---- 1 edge
    L += ["## 1. Ohmic resistance from current edges (identification files only)", "",
          f"Raw step-{e['profile_step']} samples. An edge = consecutive samples with |dI| >= {e['dI_min_A']} A. "
          "The logger does NOT add samples at current transitions: the two samples that bracket an edge are always "
          f"~1 s apart (median {_f(J['edge']['0']['sampling']['median_dt_edge_s'])} s at 0 C; pairs within "
          f"{e['window_s']} s: " + "/".join(str(J['edge'][str(T)]['sampling']['n_pairs_dt_le_window']) for T in TEMPS) +
          " at 0/25/45 C). The short sub-second samples of the files are logger rows at zero current, not edges. "
          "The declared window is therefore applied to the delay delta = t_post - c of the post-edge sample after the "
          "switching instant c. The schedule switches on whole seconds of the step clock plus a common offset d "
          f"(solved per file from all periods, jitter tolerance {e['schedule_jitter_tol_s']} s), and the pre-edge voltage is "
          "extrapolated linearly to c from the last two samples of the previous level. R = dV/dI with the Arbin sign "
          "(= -dV/dI with discharge positive). Primary: delta <= "
          f"{e['window_s']} s and Coulomb-counting z >= {e['z_min']}.", "",
          "| T | edges / clean / primary n | offset d (s) | R0_edge median (mOhm) | IQR | 95 % CI (median) | raw V_pre | all z | "
          "linear fit, delta -> 0 |", "|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        E = J["edge"][str(T)]; st = E["stats"]; p = st["primary"]; sc = E["schedule"]
        lin = st.get("linear_in_delta_0_to_0.6s", {})
        L.append(f"| {T} | {E['n_edges']} / {E['n_base']} / {p['n']} | {_f(sc['d'])} [{_f(sc['d_lo'])}, {_f(sc['d_hi'])}] "
                 f"({sc['n_orders_consistent']}/{sc['n_orders']} orders) | {_mo(p['median'])} | {_mo(p['iqr'][0])}-{_mo(p['iqr'][1])} | "
                 f"[{_mo(p['ci95_median'][0])}, {_mo(p['ci95_median'][1])}] | {_mo(st['primary_raw_pre_voltage']['median'])} | "
                 f"{_mo(st['primary_all_z']['median'])} | {_mo(lin.get('intercept'))} |")
    L += ["", "Window sensitivity (median mOhm, n; z >= z_min):", "",
          "| T | " + " | ".join(f"delta <= {w}" for w in e["window_sensitivity_s"]) + " |",
          "|---|" + "---|" * len(e["window_sensitivity_s"])]
    for T in TEMPS:
        W = J["edge"][str(T)]["stats"]["window"]
        L.append(f"| {T} | " + " | ".join(f"{_mo(W[f'{w:g}']['z_ge_min'].get('median'))} ({W[f'{w:g}']['z_ge_min'].get('n')})"
                                          for w in e["window_sensitivity_s"]) + " |")
    L += ["", "Dependence on |dI|, direction and SOC (primary edges; median mOhm (n)):", ""]
    for T in TEMPS:
        st = J["edge"][str(T)]["stats"]
        dI = "; ".join(f"[{q['lo']}, {q['hi']}) A: {_mo(q.get('median'))} ({q['n']})" for q in st["by_abs_dI"] if q["n"])
        dr = "; ".join(f"{k}: {_mo(v.get('median'))} ({v['n']})" for k, v in st["by_direction"].items() if v["n"])
        zz = "; ".join(f"z [{q['lo']}, {q['hi']}): {_mo(q.get('median'))} ({q['n']})" for q in st["by_z"] if q["n"])
        sp = st.get("spearman_R_vs_abs_dI", {})
        L.append(f"* **{T} C.** |dI|: {dI} (Spearman rho {_f(sp.get('rho'), 2)}, p {_f(sp.get('p'), 3)}). Direction: {dr}. "
                 f"SOC: {zz}; z < z_min: {_mo(st['knee_z_lt_min'].get('median'))} ({st['knee_z_lt_min']['n']}).")
    L += ["", "Comparison with the identified models (mOhm):", "",
          "| T | R0_edge | R0 TFO causal whole | R0 TFO knee-excl. | R0 FO | R0 2RC | R(1 s) TFO [95 %] | R(1 s) 2RC | "
          "R_edge / R0_TFO | R_edge / R(1 s) |", "|---|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        c = J["edge"][str(T)]["comparison"]
        L.append(f"| {T} | {_mo(c['R0_edge'])} | {_mo(c['R0_TFO_causal_full'])} | {_mo(c['R0_TFO_causal_knee'])} | "
                 f"{_mo(c['R0_FO_causal_full'])} | {_mo(c['R0_2RC_causal_full'])} | {_mo(c['R_1s_TFO_causal_full'])} "
                 f"[{_mo(c['R_1s_TFO_ci95'][0])}, {_mo(c['R_1s_TFO_ci95'][1])}] | {_mo(c['R_1s_2RC_causal_full'])} | "
                 f"{_f(c['ratio_R0_edge_over_R0_TFO'], 2)} | {_f(c['ratio_R0_edge_over_R1s_TFO'], 2)} |")
    L += ["", "Measured R(delta) against the continuous-time step responses of the identified (free-R0) fits "
          "(figures/draft_p1_edge_R0.pdf; mOhm at the bin centre):", "",
          "| T | delta bin (s) | edges median (n) | TFO | 2RC |", "|---|---|---|---|---|"]
    for T in TEMPS:
        E = J["edge"][str(T)]; mc = E["model_curves"]; d = np.array(mc["delta_s"])
        for q in E["stats"]["delta_curve"]:
            if q["n"] < 5 or q["lo"] not in (0.0, 0.2, 0.5, 0.8):
                continue
            i = int(np.argmin(np.abs(d - 0.5 * (q["lo"] + q["hi"]))))
            L.append(f"| {T} | [{_f(q['lo'], 2)}, {_f(q['hi'], 2)}) | {_mo(q['median'])} ({q['n']}) | {_mo(mc['TFO'][i])} | {_mo(mc['2RC'][i])} |")
    # ---- 2 edge fits
    L += ["", "## 2. Sensitivity: every model re-identified with R0 fixed at R0_edge(T)", "",
          "Same objective (whole-profile RMSE), bounds, LHS starts and TRF settings as the identification; CMA-ES check "
          f"({J['settings']['refit']['cmaes_check_runs']} runs); nesting enforced. Free-R0 fits (identification.json) are the reference.", "",
          "| T | model | RMSE (mV) | free-R0 RMSE | delta | alpha | lambda (1/s) | Rp | Cp | R(1 s) | R_dc | at / near bound | "
          "CMA-ES - TRF (mV) |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        for f in FAMS:
            F = J["edge_fits"][str(T)]["fits"][f]; th = F["theta"]
            L.append(f"| {T} | {f} | {_f(F['rmse_mV'])} | {_f(F['rmse_free_R0_mV'])} | {_f(F['delta_rmse_vs_free_R0_mV'])} | "
                     f"{_f(th.get('alpha'))} | {_f(th.get('lam'))} | {_f(th.get('Rp', th.get('R1')))} | "
                     f"{_f(th.get('Cp', th.get('tau1')))} | {_mo(F['step_response']['R_1s_Ohm'])} | {_mo(F['step_response']['R_dc_Ohm'])} | "
                     f"{','.join(F['at_bound']) or '-'} / {','.join(F['near_bound']) or '-'} | "
                     f"{_f(-F['optimizer_check']['cmaes_improves_trf_by_mV'])} |")
    L += ["", "(2RC: the Rp and Cp columns hold R1 and tau1.) TFO(edge R0) uncertainty: local-scale block bootstrap (TRF "
          "refits, two starts) and lambda profile (HAC n_eff):", "",
          "| T | alpha 95 % | lambda 95 % | Rp 95 % | Cp 95 % | draws lambda = 0 | refit RMSE 5/50/95 % | lambda-hat | "
          "LR_eff(lambda = 0) | by HAC bandwidth | profile interval |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        G = J["edge_fits"][str(T)]; b = G["bootstrap"]["stats"]; zt = G["lambda_profile"]["zero_test"]; ci = G["lambda_profile"]["ci_eff"]

        def bci(k):
            x = b[k]
            s_ = f"[{_f(x['ci95'][0])}, {_f(x['ci95'][1])}]"
            return s_ if x["ci_valid"] else s_ + f" (bound {100 * (x['frac_at_lower'] + x['frac_at_upper']):.0f} %)"
        L.append(f"| {T} | {bci('alpha')} | {bci('lam')} | {bci('Rp')} | {bci('Cp')} | "
                 f"{100 * G['bootstrap']['frac_lambda_at_0']:.0f} % | {'/'.join(_f(x, 1) for x in G['bootstrap']['rmse_quantiles_mV'])} | "
                 f"{_f(G['fits']['TFO']['theta']['lam'])} | {_f(zt['LR_eff'], 2)} | "
                 f"{', '.join(f'{k} s: {_f(v, 2)}' for k, v in zt['LR_eff_by_bandwidth'].items())} | "
                 f"[{_f(ci.get('lo'))}, {_f(ci.get('hi'))}{'+' if ci.get('hi_at_grid_edge') else ''}] |")
    return L


def report_lines_2(J: dict, M: dict | None) -> list[str]:
    L = ["", "## 3. Open-loop voltage accuracy of the three parameter sets", "",
         "RMSE (mV) averaged over 0/25/45 C (test groups: mean of the 50 % and 80 % starts first), whole profile / z >= 0.1 "
         "(Coulomb-counting z) / admissible interval (reference SOC in "
         f"{J['settings']['admissible_soc_interval']}). Model-fit claims use the whole profile and z >= 0.1; the admissible "
         "interval is the one on which certified claims are made.", ""]
    for sn in SETS:
        G = J["accuracy_groups"][sn]
        L += [f"**{sn}**", "", "| profile | " + " | ".join(FAMS) + " |", "|---|" + "---|" * len(FAMS)]
        for g in G:
            L.append(f"| {g} | " + " | ".join(f"{G[g][f]['rmse_mV']:.1f} / {G[g][f]['rmse_z_ge_knee_mV']:.1f} / "
                                               f"{G[g][f]['rmse_admissible_mV']:.1f}" for f in FAMS) + " |")
        w = J["test_wins"][sn]
        L += ["", f"Test ({w['n_files']} files) lowest-RMSE wins: " + ", ".join(f"{f} {w['rmse_wins'][f]}" for f in FAMS) +
              "; median RMSE " + ", ".join(f"{f} {w['median_rmse_mV'][f]:.1f}" for f in FAMS) + " mV.", ""]
    L.append(f"causal_full recomputed here vs identification.json: max |d RMSE| = {_f(J['consistency_max_abs_diff_rmse_vs_identification_json_mV'])} mV.")
    d = J["decision"]
    L += ["", "## 4. Parameter set for the observers (pre-declared rule, validation files only)", "",
          f"Rule (config identification_refined.decision_rule, declared before any computation): {d['rule']}.", "",
          "| alternative | family | RMSE z >= 0.1 default -> alt (mV) | improvement | RMSE whole default -> alt | worsening | "
          "admissible default -> alt | passes |", "|---|---|---|---|---|---|---|---|"]
    for A, rows in d["table"].items():
        for f, r in rows.items():
            L.append(f"| {A} | {f} | {r['rmse_z_ge_knee_default_mV']:.2f} -> {r['rmse_z_ge_knee_alt_mV']:.2f} | "
                     f"{100 * r['improvement_frac']:.1f} % | {r['rmse_whole_default_mV']:.2f} -> {r['rmse_whole_alt_mV']:.2f} | "
                     f"{100 * r['worsening_frac']:+.1f} % | {r['rmse_admissible_default_mV']:.2f} -> {r['rmse_admissible_alt_mV']:.2f} | {r['passes']} |")
    L += ["", f"**Decision: `{d['chosen']}`** (frozen {d['frozen_utc']}; test phase started {J['test_phase_started_utc']}). "
          "The chosen sets are in `results/identification_refined.json` -> `chosen_parameter_sets`. results/frozen_config.json "
          "is not written by this script (not owned by P1); the decision record above is the freeze for this study.", ""]
    if M:
        L += memory_lines(M)
    rt = J["runtime"]
    L += ["", "## Runtime", "",
          f"04b: {rt['main_wall_s']:.0f} s wall, main process {rt['main_process_s']:.0f} s, worker process time {rt['worker_process_s_sum']:.0f} s "
          f"({rt['max_workers']} workers)." + (f" 04c: {M['runtime']['main_wall_s']:.0f} s wall, main process "
                                               f"{M['runtime']['main_process_s']:.0f} s, worker process time "
                                               f"{M['runtime']['worker_process_s_sum']:.0f} s ({M['runtime']['max_workers']} workers)." if M else ""),
          "Machine shared with other experiments; times are load-dependent."]
    return L


def memory_lines(M: dict) -> list[str]:
    ps_ = M["parameter_set"]
    L = ["## 5. Memory-budget identification", "",
         f"Parameter set `{ps_['chosen']}` (objective window {ps_['window']}; R0 "
         f"{'fixed at R0_edge' if ps_['chosen'] == 'edge_R0' else 'free'}). {M['note']}. N_L = ceil(L/h). "
         "Bounds: B_p = Vbar_p0 + b_p I_max/(a_p + lambda^alpha); tempered = tempered.truncation_bound 'gamma'; untempered = "
         "same alpha, lambda = 0 (units V s^-alpha).", ""]
    for T in TEMPS:
        P = M["per_T"][str(T)]
        rows = P["rows"]
        ev = {str(q["L"]): q for q in P["lambda_evidence"]}
        L += [f"**{T} C**", "",
              "| L (s) | FO-trunc id / val (mV) | alpha FO | TFO-trunc id / val (mV) | alpha, lambda-hat TFO | LR_eff(0) | "
              "best grid lambda (id) | best config (val) | bound FO untempered | bound TFO tempered | ratio |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
        for Lm in M["L_s"]:
            fo = next(q for q in rows if q["L"] == Lm and q["config"] == "FO_trunc")
            tf = next(q for q in rows if q["L"] == Lm and q["config"] == "TFO_trunc")
            e_ = ev[str(Lm)]
            L.append(f"| {Lm} | {fo['identification']['rmse_mV']:.2f} / {fo['validation']['rmse_mV']:.2f} | {_f(fo['theta']['alpha'])} | "
                     f"{tf['identification']['rmse_mV']:.2f} / {tf['validation']['rmse_mV']:.2f} | {_f(tf['theta']['alpha'])}, "
                     f"{_f(tf['theta']['lam'])} | {_f(e_['LR_eff'], 2)} | {_f(e_['best_grid_lambda'])} | {e_['validation_best_config']} | "
                     f"{_f(fo['bounds']['trunc_untempered'])} | {_f(tf['bounds']['trunc_gamma'])} | "
                     f"{_f(tf['bounds'].get('ratio_gamma_over_untempered'), 2)} |")
        L += ["", "TFO-grid (lambda fixed): identification / validation RMSE (mV) and tempered bound:", "",
              "| L (s) | " + " | ".join(f"lambda = {v:g}" for v in M["lambda_grid"]) + " |", "|---|" + "---|" * len(M["lambda_grid"])]
        for Lm in M["L_s"]:
            cells = []
            for v in M["lambda_grid"]:
                q = next(q for q in rows if q["L"] == Lm and q["config"] == "TFO_grid" and q["lam_fixed"] == v)
                cells.append(f"{q['identification']['rmse_mV']:.2f} / {q['validation']['rmse_mV']:.2f} / {_f(q['bounds']['trunc_gamma'])}")
            L.append(f"| {Lm} | " + " | ".join(cells) + " |")
        atb = sorted({f"{q['config']}{'' if q['lam_fixed'] is None else '(' + format(q['lam_fixed'], 'g') + ')'}@{q['L']}: {','.join(q['at_bound'])}"
                      for q in rows if q["at_bound"]})
        L += ["", "At bound: " + ("; ".join(atb) if atb else "none") + ".", ""]
    return L


def make_report_and_figures(J: dict, A: dict):
    M = _load_mem()
    figs = [fig_edge(J, A)]
    if M:
        figs.append(fig_memory(M))
    L = report_lines(J, M) + report_lines_2(J, M)
    L += ["", "Figures (draft): " + ", ".join(f"`{Path(p).relative_to(ROOT).as_posix()}`" for p in figs) + "."]
    REP.mkdir(parents=True, exist_ok=True)
    with open(REP / "identification_refined_findings.md", "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    print("report written", flush=True)


if __name__ == "__main__":
    main()
