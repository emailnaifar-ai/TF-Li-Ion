"""E2: robustness of the frozen estimators on the 18 test files (FUDS / US06 / BJDST, SP2, 0/25/45 C).

Settings: config.yaml `robustness` (declared 2026-09-27 before the first run of this script), `estimators`,
`design_tuning.admissible_soc_interval`.  Every parameter and hyper-parameter comes from results/frozen_config.json
('methods' = primary memory budget 400 s); nothing is re-tuned.  Test files are loaded with
experiments.load_case(..., allow_splits=('test',), final_evaluation=True) (data.verify_file inside).

Cases (per file and method; 'nominal' initial SOC unless stated):
 (a) z0 = reference +- 0.20 (plus20 / minus20) and the nominal baseline;
 (b) current-sensor offset delta_I in {-50, -20, +20, +50} mA;
 (c) voltage noise std {1, 5, 10} mV;   (d) current noise std {10, 50} mA   (20 Monte-Carlo seeds each);
 (e) joint parameter scaling R0 | Rp (R1, R2) | Cp (tau1, tau2) x {0.8, 1.2}, alpha x {0.9, 1.1} (fractional
     models), every sign combination; the worst combination per method is reported;
 (f) capacity Q_n x {0.95, 1.05};   (g) parameters/OCV/Q_n/hyper-parameters of 25 C on the 0 and 45 C files.
Metrics: admissible post-convergence RMSE (reference SOC in [0.10, 0.95], t - t0 >= 600 s; PRIMARY) and the
whole-profile metrics of metrics.soc_metrics.  Bias theory: thm:robust(vi) / eq:m4b:steady (TFO, FOO) and the
Coulomb-counting drift.  Figure trajectories: the file declared in FIG_FILE (fixed before the first run).

Outputs: results/robustness.json, tables/tab_robustness.tex, figures/fig_robustness.pdf, reports/robustness_findings.md
Usage: python scripts/06b_robustness.py [--report-only] [--workers N]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import itertools
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES = ROOT / "results"
CACHE = ROOT / "scratch" / "robustness_cache"
TASK_VERSION = "E2-2026-09-27-b"          # b: review round 1 (config robustness.review_round_1)
FIG_FILE = "SP2_25C_FUDS_80SOC"          # trajectory panel of the figure (declared before the first run)
FIG_STRIDE = 10                           # stored trajectory samples every 10 s
FRACTIONAL = ("TFO", "FOO", "FOEKF")
TWO_RC = ("EKF2RC", "AEKF2RC")


# ---------------------------------------------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------------------------------------------
def cfg():
    c = D.load_config()
    return c, dict(c["robustness"]), dict(c["estimators"]), dict(c["design_tuning"])


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def code_hash() -> str:
    c, rb, est, dt = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([rb, est, dt["admissible_soc_interval"], c["validation"]], sort_keys=True).encode())
    h.update(TASK_VERSION.encode())
    h.update(json.dumps(c["validation_main"]["review_round_1"]["supplementary_methods"], sort_keys=True).encode())
    for f in ("src/tfso/observer.py", "src/tfso/benchmarks.py", "src/tfso/tempered.py", "src/tfso/experiments.py",
              "src/tfso/metrics.py", "src/tfso/model.py", "results/frozen_config.json", "results/capacity.json",
              "results/gain_design.json", "results/tuning.json"):
        h.update((ROOT / f).read_bytes())
    src = (ROOT / "scripts" / "06b_robustness.py").read_text(encoding="utf-8")
    h.update(src.split(chr(10) + "# === " + "ANALYSIS ===" + chr(10))[0].encode())   # compute part only (report edits keep the cache)
    return h.hexdigest()[:16]


_FZ = None
_OCV = {}


def frozen():
    global _FZ
    if _FZ is None:
        _FZ = load_json("frozen_config.json")
    return _FZ


def method_setup(method, T):
    """(params, hyper, FastOCV) of the frozen primary configuration at temperature T."""
    e = frozen()["methods"][method]["per_T"][str(int(T))]
    p = dict(e["params"])
    hy = dict(e.get("hyper", {}))
    if method == "CC":
        return p, hy, None
    key = (method, int(T))
    if key not in _OCV:
        _OCV[key] = O.as_fast_ocv(MD.AlignedOCV(int(T), E.q_id(int(T))), s=p["s"], dq=p["dq"])
    return p, hy, _OCV[key]


def diag_methods():
    """Review-round-1 diagnostic variants (config robustness.review_round_1.diagnostic_methods): name -> spec."""
    _, rb, _, _ = cfg()
    return dict(rb.get("review_round_1", {}).get("diagnostic_methods", {}))


def all_methods():
    _, rb, _, _ = cfg()
    return list(rb["methods"]) + list(diag_methods())


_GRID = {}


def grid_entry(T, lam, L):
    """Validation-derived TFO candidate (lam, L) at T: parameters/certificate from gain_design.json post_certificates,
    gains from the tuning.json grid (same equal-budget tuning as the frozen entries)."""
    key = (int(T), float(lam), int(L))
    if key not in _GRID:
        pc = [r for r in load_json("gain_design.json")["post_certificates"]
              if int(r["T"]) == int(T) and int(r["L"]) == int(L) and abs(float(r["lam"]) - lam) <= 1e-12 * lam]
        g = [r for r in load_json("tuning.json")["grid"] if r["method"] == "TFO" and int(r["T"]) == int(T)
             and int(r["L"]) == int(L) and abs(float(r["lam"]) - lam) <= 1e-12 * lam]
        assert len(pc) == 1 and len(g) == 1, (T, lam, L)
        pc, g = pc[0], g[0]
        _GRID[key] = dict(params={k: float(v) for k, v in pc["params"].items()},
                          hyper=dict(l1=float(g["best_values"]["l1"]), l2=float(g["best_values"]["l2"]), L_s=float(L),
                                     z_interval=pc["kappa"]["z_interval_obs"]),
                          certified=bool(pc["dc_sigma0"]["certified"]), h_l1_kappa2=float(pc["h_l1_kappa2"]),
                          validation_objective_pct=float(g["best_objective"]), row=g["row"])
    return _GRID[key]


def setup(name, T):
    """(estimator, params, hyper, FastOCV) of a frozen method or of a review diagnostic variant at temperature T."""
    dm = diag_methods()
    if name not in dm:
        p, hy, f = method_setup(name, T)
        return name, p, hy, f
    spec = dm[name]
    est = spec["estimator"]
    if est == "TFO":
        ge = grid_entry(T, float(spec["lam"]), int(spec["L_s"]))
        p, hy = dict(ge["params"]), dict(ge["hyper"])
        key = (name, int(T))
        if key not in _OCV:
            _OCV[key] = O.as_fast_ocv(MD.AlignedOCV(int(T), E.q_id(int(T))), s=p["s"], dq=p["dq"])
        return est, p, hy, _OCV[key]
    p, hy, f = method_setup(est, T)
    hy = json.loads(json.dumps(hy))
    if "override" in spec:
        hy["Q"][0] = float(spec["override"]["Q0"])
        hy["P0"][0] = float(spec["override"]["P00"])
    else:
        c = D.load_config()
        sup = c["validation_main"]["review_round_1"]["supplementary_methods"][name]
        hy.update(json.loads(json.dumps(sup["hyper"])))
    return est, p, hy, f


def q_ref(T):
    return float(load_json("capacity.json")["Q_ref_T_SP2"][str(int(T))]["Q_ref_Ah"])


# ---------------------------------------------------------------------------------------------------------------
# Scenario list (identical for every file; the temperature mismatch only on the 0 / 45 C files)
# ---------------------------------------------------------------------------------------------------------------
def param_combos(est):
    """(scenario, group, factors). Declared (group 'param'): fractional 2^4 (R0 | Rp | Cp x alpha), 2RC 2^3.
    Review round 1 (fractional only): 'param_rc' = the 2^3 R/C combinations with alpha x1.0 (the 2RC design) and
    'alpha' = alpha scaled alone."""
    _, rb, _, _ = cfg()
    ps, al = [float(v) for v in rb["param_scale"]], [float(v) for v in rb["alpha_scale"]]
    r1 = rb.get("review_round_1", {})
    if est in FRACTIONAL:
        out = [(f"param_R0x{a:g}_Rpx{b:g}_Cpx{c:g}_ax{fa:g}", "param", dict(R0=a, Rp=b, Cp=c, alpha=fa))
               for a, b, c, fa in itertools.product(ps, ps, ps, al)]
        if r1:
            out += [(f"prc_R0x{a:g}_Rpx{b:g}_Cpx{c:g}_ax1", "param_rc", dict(R0=a, Rp=b, Cp=c))
                    for a, b, c in itertools.product(ps, ps, ps)]
            out += [(f"alpha_{float(fa):g}", "alpha", dict(alpha=float(fa))) for fa in r1["alpha_only"]]
        return out
    if est in TWO_RC:
        return [(f"param_R0x{a:g}_Rpx{b:g}_Cpx{c:g}", "param", dict(R0=a, R1=b, R2=b, tau1=c, tau2=c))
                for a, b, c in itertools.product(ps, ps, ps)]
    return []                                       # CC has no model parameters (only Q_n, case f)


def scenarios(T, method):
    """List of dicts: scenario, group, level, z0, corruption, seeds (None = deterministic), factors, mismatch."""
    _, rb, _, _ = cfg()
    dm = diag_methods()
    est = dm[method]["estimator"] if method in dm else method
    out = [dict(scenario="baseline", group="baseline", level=0.0, z0="nominal")]
    for z in rb["z0_scenarios"]:
        if z != "nominal":
            out.append(dict(scenario=f"z0_{z}", group="z0", level=0.2 if z == "plus20" else -0.2, z0=z))
    for d in rb["current_offset_A"]:
        out.append(dict(scenario=f"bias_{1000 * d:+.0f}mA", group="bias", level=float(d), z0="nominal",
                        corruption=dict(I_offset=float(d))))
    if method in dm and dm[method].get("cases") == "benchmarks":
        keep = set(rb["review_round_1"]["diagnostic_cases_benchmarks"])
        return [sc for sc in out if sc["group"] in keep]
    for s in rb["voltage_noise_std_V"]:
        out.append(dict(scenario=f"vnoise_{1000 * s:.0f}mV", group="vnoise", level=float(s), z0="nominal",
                        corruption=dict(V_noise_std=float(s)), mc=True))
    for s in rb["current_noise_std_A"]:
        out.append(dict(scenario=f"inoise_{1000 * s:.0f}mA", group="inoise", level=float(s), z0="nominal",
                        corruption=dict(I_noise_std=float(s)), mc=True))
    for lab, grp, fac in param_combos(est):
        out.append(dict(scenario=lab, group=grp, level=lab, z0="nominal", factors=fac))
    for f in rb["capacity_factor"]:
        out.append(dict(scenario=f"cap_{float(f):g}", group="cap", level=float(f), z0="nominal", cap=float(f)))
    tm = rb["temperature_mismatch"]
    if int(T) in [int(v) for v in tm["file_T"]]:
        out.append(dict(scenario=f"temp_{int(tm['T_used'])}C", group="temp", level=int(tm["T_used"]), z0="nominal",
                        T_used=int(tm["T_used"])))
    return out


# ---------------------------------------------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------------------------------------------
def adm_metrics(t, e, zref):
    """Admissible-interval metrics (reference SOC in the admissible interval; post: t - t0 >= t_post)."""
    _, _, est, dt = cfg()
    lo, hi = dt["admissible_soc_interval"]
    tpost = float(est["post_convergence_t_s"])
    band = float(D.load_config()["validation"]["error_band_convergence"])
    adm = (zref >= lo) & (zref <= hi)
    post = (t - t[0]) >= tpost
    m = adm & post
    ee = e[m]
    out = dict(adm_n=int(ee.size))
    if ee.size == 0 or not np.all(np.isfinite(ee)):
        for k in ("rmse", "mae", "maxabs", "bias", "within1", "within2"):
            out[f"adm_{k}_pct"] = float("inf") if k in ("rmse", "mae", "maxabs") else float("nan")
    else:
        a = np.abs(ee)
        out.update(adm_rmse_pct=float(100 * np.sqrt(np.mean(ee * ee))), adm_mae_pct=float(100 * np.mean(a)),
                   adm_maxabs_pct=float(100 * np.max(a)), adm_bias_pct=float(100 * np.mean(ee)))
        for b in est["within_bands"]:
            out[f"adm_within{int(round(100 * b))}_pct"] = float(100 * np.mean(a <= b))
    # admissible convergence time: last admissible sample outside the band -> next admissible sample
    idx = np.flatnonzero(adm)
    bad = idx[~(np.abs(e[idx]) <= band)]
    if bad.size == 0:
        out["adm_conv_time_s"] = 0.0 if idx.size else float("nan")
    else:
        later = idx[idx > bad[-1]]
        out["adm_conv_time_s"] = float(t[later[0]] - t[0]) if later.size else float("inf")
    return out


def run_one(method, p, hy, f, case, sc, seed=None, extra=None, keep=False, name=None):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        rec = E.run_case(method, p, hy, case, z0_scenario=sc["z0"], ocv=f, corruption=sc.get("corruption"),
                         seed=seed, scenario=sc["scenario"], keep_series=True, extra=extra)
    s = rec.pop("_series")
    e = np.asarray(s["zhat"], float) - np.asarray(s["zref"], float)
    rec.update(adm_metrics(case.t, e, case.soc_ref))
    rec.update(group=sc["group"], level=sc["level"], duration_s=float(case.t[-1] - case.t[0]))
    # where the SOC clip is active (review round 1): clipped samples = zhat at a clip bound
    zlo, zhi = [float(v) for v in frozen()["soc_clip"]]
    zh, zr = np.asarray(s["zhat"], float), np.asarray(s["zref"], float)
    lo, hi = cfg()[3]["admissible_soc_interval"]
    cl_lo, cl_hi = zh <= zlo + 1e-12, zh >= zhi - 1e-12
    rec.update(clip_lo_n=int(cl_lo.sum()), clip_hi_n=int(cl_hi.sum()),
               clip_adm_n=int(((cl_lo | cl_hi) & (zr >= lo) & (zr <= hi)).sum()),
               clip_lo_zref_max=float(zr[cl_lo].max()) if cl_lo.any() else float("nan"),
               clip_hi_zref_min=float(zr[cl_hi].min()) if cl_hi.any() else float("nan"))
    if name is not None:
        rec.update(method=name, estimator=method)
    return rec, (e if keep else None)


# ---------------------------------------------------------------------------------------------------------------
# Bias theory (thm:robust(vi), eq:m4b:steady) for TFO / FOO
# ---------------------------------------------------------------------------------------------------------------
def bias_coefficient(method, p, hy, h=1.0):
    """A [Ohm] with (zhat - z)_ss = -(delta_I / kappa) A: implemented (M = mu_{h,L}(0)) and continuous (M = lam^a)."""
    c = O.model_constants(p)
    lam = 0.0 if method == "FOO" else float(p.get("lam", 0.0))
    N_L = int(math.ceil(float(hy["L_s"]) / h - 1e-9))
    args = (float(p["R0"]), c["ap"], c["bp"], float(hy["l1"]), float(hy["l2"]), float(p.get("eta", 1.0)),
            float(p["Qn"]), lam, float(p["alpha"]))
    A_impl = TM.bias_steady_state(1.0, 1.0, *args, h=h, N_L=N_L, I=0.0)
    A_cont = TM.bias_steady_state(1.0, 1.0, *args, h=None, N_L=None, I=0.0)
    M = TM.mu_hL(float(p["alpha"]), lam, 0.0, h, N_L)
    R_tot_impl = float(p["R0"]) + c["bp"] / (c["ap"] + M)
    R_tot_cont = float(p["R0"]) + c["bp"] / (c["ap"] + lam ** float(p["alpha"]))
    return dict(A_impl=float(A_impl), A_cont=float(A_cont), mu0=float(M), R_tot_impl=float(R_tot_impl),
                R_tot_cont=float(R_tot_cont), N_L=N_L, lam=lam)


def bias_compare(method, p, hy, f, case, dI, e_b, e_0, name=None):
    """Observed delta_e = e_biased - e_nominal vs the quasi-steady prediction on the admissible post window."""
    _, _, est, dt = cfg()
    lo, hi = dt["admissible_soc_interval"]
    t, zref = case.t, case.soc_ref
    m = (zref >= lo) & (zref <= hi) & ((t - t[0]) >= float(est["post_convergence_t_s"]))
    d_obs = (e_b - e_0)[m]
    out = dict(method=name or method, estimator=method, file=case.logical_id, T=case.T, dI=float(dI), n=int(m.sum()))
    if method in ("TFO", "FOO"):
        bc = bias_coefficient(method, p, hy)
        z_obs = 1.0 - (1.0 - zref[m]) * q_ref(case.T) / float(p["Qn"])
        kap = np.asarray(f.dU(z_obs), float)
        pred = -dI * bc["A_impl"] / kap
        pred_c = -dI * bc["A_cont"] / kap
        zi = hy.get("z_interval")
        k1, k2 = O.slope_bounds_fast(f, float(zi[0]), float(zi[1]))
        out.update(bc, pred_mean=float(np.mean(pred)), pred_cont_mean=float(np.mean(pred_c)),
                   pred_k1=float(-dI * bc["A_impl"] / k1), pred_k2=float(-dI * bc["A_impl"] / k2),
                   kappa1=float(k1), kappa2=float(k2),
                   rms_obs_minus_pred=float(np.sqrt(np.mean((d_obs - pred) ** 2))),
                   corr=float(np.corrcoef(d_obs, pred)[0, 1]) if d_obs.size > 2 and np.std(d_obs) > 0 else float("nan"),
                   t_cross_s=float(3600.0 * float(p["Qn"]) * abs(bc["A_impl"]) / (float(p.get("eta", 1.0)) * k1)))
    if method == "CC":
        te = float(t[-1] - t[0])
        out.update(drift_end_pred=float(float(p.get("eta", 1.0)) * dI * te / (3600.0 * float(p["Qn"]))),
                   drift_end_obs=float((e_b - e_0)[-1]))
    out.update(obs_mean=float(np.mean(d_obs)) if d_obs.size else float("nan"),
               obs_q05=float(np.quantile(d_obs, 0.05)) if d_obs.size else float("nan"),
               obs_q95=float(np.quantile(d_obs, 0.95)) if d_obs.size else float("nan"),
               obs_end=float((e_b - e_0)[-1]),
               obs_adm_end=float(d_obs[-1]) if d_obs.size else float("nan"),
               t_adm_end_s=float(t[m][-1] - t[0]) if d_obs.size else float("nan"))
    return out


# ---------------------------------------------------------------------------------------------------------------
# One file (worker task)
# ---------------------------------------------------------------------------------------------------------------
_DROP = ("z0_source", "seed_entropy", "N_L_requested", "n_history_samples", "bytes_state", "band", "t_post_s",
         "h_l1_kappa2_clip", "explicit_stable", "cpu_process_s", "cpu_per_sample_us", "wall_per_sample_us")


def file_task(lid):
    t_w0, t_c0 = time.perf_counter(), time.process_time()
    _, rb, _, _ = cfg()
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)
    if not case.meta["verify_passed"]:
        raise RuntimeError(f"{lid} failed data.verify_file")
    T = case.T
    seeds = [int(s) for s in rb["mc_seeds"]][: int(rb["mc_runs"])]
    recs, bias_rows, traj = [], [], {}
    stride = slice(None, None, FIG_STRIDE)
    if lid == FIG_FILE:
        traj = dict(t=(case.t - case.t[0])[stride].tolist(), zref=case.soc_ref[stride].tolist(), e={})
    for method in all_methods():
        est, p0, hy0, f0 = setup(method, T)
        e_nom = None
        for sc in scenarios(T, method):
            p, hy, f, extra = p0, hy0, f0, dict(group_label=sc["group"])
            if "factors" in sc:
                p, fac = E.perturb_params(p0, 0.0, factors=sc["factors"])
                extra.update({f"fac_{k}": v for k, v in fac.items()})
            if "cap" in sc:
                p = E.capacity_mismatch(p0, sc["cap"])
                extra["capacity_mismatch"] = sc["cap"]
            if "T_used" in sc:
                _, p, hy, f = setup(method, sc["T_used"])
                extra["temperature_mismatch"] = sc["T_used"]
            keep = sc["group"] in ("baseline", "bias", "z0")
            for seed in (seeds if sc.get("mc") else [None]):
                rec, e = run_one(est, p, hy, f, case, sc, seed=seed, extra=extra, keep=keep, name=method)
                if sc["group"] in ("baseline", "z0"):
                    base = e if sc["scenario"] == "baseline" else e_nom
                    for bd in rb["diagnostic_forgetting_time"]["bands"]:
                        rec[f"fgt{int(round(100 * bd))}_s"] = MX.convergence_time(case.t, e - base, float(bd))
                recs.append({k: v for k, v in rec.items() if k not in _DROP})
                if sc["scenario"] == "baseline":
                    e_nom = e
                if sc["group"] == "bias":
                    bias_rows.append(bias_compare(est, p, hy, f, case, sc["level"], e, e_nom, name=method))
                if traj and keep and method in rb["methods"]:
                    traj["e"].setdefault(sc["scenario"], {})[method] = np.round(e[stride], 6).tolist()
    return dict(file=lid, T=T, profile=case.profile, start_level=case.start_level, n=int(case.t.size),
                duration_s=float(case.t[-1] - case.t[0]), z_ref0=case.z_ref0, verify_passed=True,
                records=recs, bias=bias_rows, traj=traj,
                wall_s=time.perf_counter() - t_w0, process_s=time.process_time() - t_c0, pid=os.getpid())


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        v = float(o)
        return v if math.isfinite(v) else ("inf" if v > 0 else ("-inf" if v < 0 else "nan"))
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def unjson(v):
    if isinstance(v, str) and v in ("inf", "-inf", "nan"):
        return float(v)
    return v


def compute(workers):
    c, rb, _, _ = cfg()
    files = list(c["splits"]["test_dynamic"])
    assert len(files) == 18
    CACHE.mkdir(parents=True, exist_ok=True)
    ch = code_hash()
    out, todo = {}, []
    for lid in files:
        p = CACHE / f"{lid}.json"
        if p.exists():
            with open(p, "r", encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("code_hash") == ch:
                out[lid] = d
                continue
        todo.append(lid)
    print(f"[E2] code hash {ch}; cached {len(out)}, to run {len(todo)} (workers {workers})", flush=True)
    t0 = time.perf_counter()
    if todo:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for lid, d in zip(todo, ex.map(file_task, todo)):
                d["code_hash"] = ch
                with open(CACHE / f"{lid}.json", "w", encoding="utf-8") as fh:
                    json.dump(jsonable(d), fh)
                out[lid] = json.loads(json.dumps(jsonable(d)))
                print(f"[E2] {lid}: {len(d['records'])} runs, wall {d['wall_s']:.1f} s, process {d['process_s']:.1f} s",
                      flush=True)
    info = dict(code_hash=ch, wall_this_call_s=time.perf_counter() - t0, n_files_computed=len(todo), workers=workers)
    if todo:
        with open(CACHE / "_run_info.json", "w", encoding="utf-8") as fh:
            json.dump(dict(info, compute_wall_s=info["wall_this_call_s"], utc=datetime.now(timezone.utc).isoformat()), fh)
    return [out[l] for l in files], info


# === ANALYSIS ===
METRICS = ("adm_rmse_pct", "post_rmse_pct", "rmse_pct", "adm_maxabs_pct", "maxabs_pct", "adm_within2_pct",
           "within2_pct", "adm_within1_pct", "adm_conv_time_s", "conv_time_s", "vt_rmse_mV", "adm_bias_pct",
           "final_abs_err_pct", "fgt1_s", "fgt2_s", "z0_error")
PAIRED_METRICS = ("adm_rmse_pct", "post_rmse_pct", "adm_conv_time_s", "conv_time_s", "fgt1_s", "fgt2_s")
CONV = ("adm_conv_time_s", "conv_time_s", "fgt1_s", "fgt2_s")


def qstats(v):
    v = np.asarray([unjson(x) for x in v], float)
    v = v[~np.isnan(v)]
    if v.size == 0:
        return dict(n=0, median=float("nan"), q25=float("nan"), q75=float("nan"), n_inf=0)
    meth = "inverted_cdf" if np.any(np.isinf(v)) else "linear"
    q25, med, q75 = np.quantile(v, [0.25, 0.5, 0.75], method=meth)
    return dict(n=int(v.size), median=float(med), q25=float(q25), q75=float(q75), n_inf=int(np.sum(np.isinf(v))),
                mean=float(np.mean(v)) if np.all(np.isfinite(v)) else float("nan"))


def frame(results):
    import pandas as pd
    rows = []
    for d in results:
        for r in d["records"]:
            rows.append({k: unjson(v) for k, v in r.items()})
    return pd.DataFrame(rows)


def per_file(df):
    """One value per (scenario, method, file): the seed median for Monte-Carlo cases (+ seed IQR)."""
    g = df.groupby(["scenario", "group", "method", "file", "T"], dropna=False)
    agg = {}
    for m in METRICS:
        agg[m] = g[m].median()
        agg[m + "_seed_iqr"] = g[m].quantile(0.75) - g[m].quantile(0.25)
    agg["n_runs"] = g.size()
    import pandas as pd
    return pd.DataFrame(agg).reset_index()


def worst_param(pf, methods, kind="param"):
    """Per method: the parameter combination with the largest MEAN over files of the primary metric (declared rule).
    kind 'param' = declared design (fractional 2^4 incl. alpha, 2RC 2^3); 'param_rc' = R/C only (alpha x1.0; for the
    2RC filters identical to 'param'). The worst by the median over files is stored alongside."""
    out = {}
    dm = diag_methods()
    for m in methods:
        est = dm[m]["estimator"] if m in dm else m
        grp = "param_rc" if (kind == "param_rc" and est in FRACTIONAL) else "param"
        s = pf[(pf.group == grp) & (pf.method == m)]
        if s.empty:
            continue
        means = s.groupby("scenario")["adm_rmse_pct"].mean().sort_values()
        meds = s.groupby("scenario")["adm_rmse_pct"].median().sort_values()
        w = str(means.index[-1])
        ent = dict(worst=w, worst_mean=float(means.iloc[-1]), worst_median=float(meds[w]), best=str(means.index[0]),
                   best_mean=float(means.iloc[0]), median_over_combos=float(means.median()), n_combos=int(means.size),
                   worst_by_median=str(meds.index[-1]), worst_by_median_value=float(meds.iloc[-1]),
                   all_means={str(k): float(v) for k, v in means.items()}, group=grp)
        if est in FRACTIONAL and kind == "param":
            for fa in ("0.9", "1.1"):
                sub = means[[k for k in means.index if k.endswith(f"_ax{fa}")]]
                ent[f"worst_mean_alpha_x{fa}"] = float(sub.max()) if len(sub) else float("nan")
        out[m] = ent
    return out


def with_pseudo(pf, wps):
    """Adds pseudo-scenarios 'param_worst' / 'param_rc_worst' (each method's own worst combination)."""
    import pandas as pd
    parts = [pf]
    for name, wp in wps.items():
        for m, w in wp.items():
            s = pf[(pf.method == m) & (pf.scenario == w["worst"])].copy()
            s["scenario"], s["group"] = name, name
            parts.append(s)
    return pd.concat(parts, ignore_index=True)


def summaries(pf, methods, scen_order):
    out = {}
    for sc in scen_order:
        out[sc] = {}
        for m in methods:
            s = pf[(pf.scenario == sc) & (pf.method == m)]
            if s.empty:
                continue
            ent = {k: qstats(s[k].values) for k in METRICS}
            ent["seed_iqr_median"] = {k: float(np.nanmedian(s[k + "_seed_iqr"].values)) for k in METRICS
                                      if s["n_runs"].max() > 1}
            ent["n_files"] = int(s.file.nunique())
            ent["n_runs"] = int(s["n_runs"].sum())
            out[sc][m] = ent
    return out


def paired_vs_ref(pf, methods, scen_order, ref, durations):
    out = {}
    for sc in scen_order:
        out[sc] = {}
        a0 = pf[(pf.scenario == sc) & (pf.method == ref)].set_index("file")
        for m in methods:
            if m == ref:
                continue
            b = pf[(pf.scenario == sc) & (pf.method == m)].set_index("file")
            common = [f for f in a0.index if f in b.index]
            if not common:
                continue
            out[sc][m] = {}
            for k in PAIRED_METRICS:
                cen = (max(durations[f] for f in common) + 1.0) if k in CONV else None
                out[sc][m][k] = MX.paired_difference(b.loc[common, k].values.astype(float),
                                                     a0.loc[common, k].values.astype(float), censor_at=cen)
    return out


def degradation(pf, methods, scen_order):
    """Paired change of the primary metric vs the baseline, per method (files as units)."""
    out = {}
    for sc in scen_order:
        if sc == "baseline":
            continue
        out[sc] = {}
        for m in methods:
            a = pf[(pf.scenario == sc) & (pf.method == m)].set_index("file")
            b = pf[(pf.scenario == "baseline") & (pf.method == m)].set_index("file")
            common = [f for f in a.index if f in b.index]
            if common:
                out[sc][m] = MX.paired_difference(a.loc[common, "adm_rmse_pct"].values.astype(float),
                                                  b.loc[common, "adm_rmse_pct"].values.astype(float))
    return out


def bias_summary(results):
    import pandas as pd
    b = pd.DataFrame([{k: unjson(v) for k, v in r.items()} for d in results for r in d["bias"]])
    out = dict(per_method_dI={}, theory={}, cc={})
    for (m, dI), s in b.groupby(["method", "dI"]):
        out["per_method_dI"].setdefault(m, {})[f"{1000 * dI:+.0f}mA"] = dict(
            obs_mean_median_pct=float(100 * s.obs_mean.median()), obs_mean_q25_pct=float(100 * s.obs_mean.quantile(0.25)),
            obs_mean_q75_pct=float(100 * s.obs_mean.quantile(0.75)), obs_end_median_pct=float(100 * s.obs_end.median()),
            obs_adm_end_median_pct=float(100 * s.obs_adm_end.median()),
            n_files=int(s.file.nunique()))
    for m in [x for x in b.method.unique() if x in ("TFO", "FOO") or str(x).startswith("TFO_lam")]:
        s = b[b.method == m]
        ratio = (s.obs_mean / s.pred_mean).values
        ratio_c = (s.obs_mean / s.pred_cont_mean).values
        slope = float(np.sum(s.obs_mean * s.pred_mean) / np.sum(s.pred_mean ** 2))
        within = ((s.obs_mean - s.pred_k1) * (s.obs_mean - s.pred_k2) <= 0).values
        perT = {}
        for T, sT in s.groupby("T"):
            r0 = sT.iloc[0]
            perT[str(int(T))] = dict(A_impl_Ohm=float(r0.A_impl), A_cont_Ohm=float(r0.A_cont), mu0=float(r0.mu0),
                                     R_tot_impl_Ohm=float(r0.R_tot_impl), R_tot_cont_Ohm=float(r0.R_tot_cont),
                                     kappa1=float(r0.kappa1), kappa2=float(r0.kappa2), t_cross_s=float(r0.t_cross_s),
                                     ratio_obs_pred_median=float(np.median(sT.obs_mean / sT.pred_mean)))
        out["theory"][m] = dict(n=int(len(s)), ratio_obs_pred_median=float(np.median(ratio)),
                                ratio_obs_pred_q25=float(np.quantile(ratio, 0.25)),
                                ratio_obs_pred_q75=float(np.quantile(ratio, 0.75)),
                                ratio_obs_cont_median=float(np.median(ratio_c)), ls_slope_obs_on_pred=slope,
                                corr_time_median=float(np.nanmedian(s["corr"])),
                                rms_obs_minus_pred_median_pct=float(100 * np.median(s.rms_obs_minus_pred)),
                                frac_within_kappa_interval=float(np.mean(within)), per_T=perT)
    s = b[b.method == "CC"]
    out["cc"] = dict(max_abs_end_obs_minus_pred=float(np.max(np.abs(s.drift_end_obs - s.drift_end_pred))),
                     drift_end_pred_pct_by_dI={f"{1000 * dI:+.0f}mA": dict(
                         median=float(100 * sd.drift_end_pred.median()), min=float(100 * sd.drift_end_pred.min()),
                         max=float(100 * sd.drift_end_pred.max())) for dI, sd in s.groupby("dI")})
    return out, b


# ---------------------------------------------------------------------------------------------------------------
# Review round 1 analyses (config robustness.review_round_1)
# ---------------------------------------------------------------------------------------------------------------
def holm_table(P, methods, order, ref):
    """Holm over all (case, method) cells of the Wilcoxon p-values of the primary metric (main methods)."""
    cells = [(sc, m, P[sc][m]["adm_rmse_pct"]) for sc in order for m in methods
             if m != ref and m in P.get(sc, {})]
    ps = np.array([float(unjson(d["wilcoxon_p"])) for _, _, d in cells], float)
    k = ps.size
    order_idx = np.argsort(ps)
    adj = np.empty(k)
    run = 0.0
    for r, i in enumerate(order_idx):
        run = max(run, min(1.0, (k - r) * ps[i]))
        adj[i] = run
    flags = [(isinstance(unjson(d["ci_lo"]), float) and unjson(d["ci_lo"]) > 0) or
             (isinstance(unjson(d["ci_hi"]), float) and unjson(d["ci_hi"]) < 0) for _, _, d in cells]
    return dict(n_cells=int(k), n_ci_flags=int(sum(flags)), n_holm_005=int(np.sum(adj < 0.05)),
                n_ci_flags_and_holm=int(sum(1 for f, a in zip(flags, adj) if f and a < 0.05)),
                cells={f"{sc}|{m}": dict(p=float(p), p_holm=float(a), ci_flag=bool(f))
                       for (sc, m, _), p, a, f in zip(cells, ps, adj, flags)})


def equivalence(P, order, methods, margin):
    """'equivalent to TFO' when the 95 % CI of the paired median difference lies inside +-margin (% SOC)."""
    out = {}
    for m in methods:
        out[m] = {}
        for sc in order:
            d = P.get(sc, {}).get(m, {}).get("adm_rmse_pct")
            if d is None:
                continue
            lo, hi = unjson(d["ci_lo"]), unjson(d["ci_hi"])
            out[m][sc] = dict(median_diff=d["median_diff"], ci_lo=lo, ci_hi=hi, n_better=d["n_a_better"],
                              n_worse=d["n_b_better"], n=d["n"], wilcoxon_p=d["wilcoxon_p"],
                              equivalent=bool(lo > -margin and hi < margin), ci_excludes_0=bool(lo > 0 or hi < 0))
    return out


def per_T_paired(pf, methods, cases, ref):
    """Paired differences d = method - TFO of the primary metric per temperature (n = 6 files per T)."""
    out = {}
    for sc in cases:
        out[sc] = {}
        a0 = pf[(pf.scenario == sc) & (pf.method == ref)].set_index("file")
        for m in methods:
            if m == ref:
                continue
            b = pf[(pf.scenario == sc) & (pf.method == m)].set_index("file")
            common = [f for f in a0.index if f in b.index]
            if not common:
                continue
            d = (b.loc[common, "adm_rmse_pct"] - a0.loc[common, "adm_rmse_pct"]).astype(float)
            Ts = a0.loc[common, "T"]
            out[sc][m] = {str(int(T)): dict(n=int((Ts == T).sum()), median_diff=float(np.median(d[Ts == T])),
                                            n_better=int(np.sum(d[Ts == T] < 0)), n_worse=int(np.sum(d[Ts == T] > 0)))
                          for T in sorted(Ts.unique())}
    return out


def failures(pf, methods, order, thr):
    """Files above the failure threshold of the primary metric, per case and method (+ per-file maximum)."""
    out = {}
    for sc in order:
        out[sc] = {}
        for m in methods:
            s = pf[(pf.scenario == sc) & (pf.method == m)]
            if s.empty:
                continue
            base = pf[(pf.scenario == "baseline") & (pf.method == m)].set_index("file")["adm_rmse_pct"]
            v = s.set_index("file")["adm_rmse_pct"].astype(float)
            bad = v[~(v <= thr)].sort_values(ascending=False)
            out[sc][m] = dict(n_files=int(v.size), n_fail=int(bad.size), max=float(v.max()), argmax=str(v.idxmax()),
                              max_increase_vs_baseline=float((v - base.reindex(v.index)).max()),
                              argmax_increase=str((v - base.reindex(v.index)).idxmax()),
                              failed=[dict(file=str(f), value=float(x), baseline=float(base.get(f, np.nan)))
                                      for f, x in bad.items()])
    return out


def z0_detail(pf, methods, slow_s):
    """Nominal z0 error per file; forgetting-time counts for EVERY method; files where the z0 run beats nominal."""
    b = pf[(pf.scenario == "baseline") & (pf.method == "TFO")].set_index("file")
    out = dict(nominal_z0_error_pct={str(f): float(100 * v) for f, v in b["z0_error"].items()}, per_method={})
    for m in methods:
        base = pf[(pf.scenario == "baseline") & (pf.method == m)].set_index("file")["adm_rmse_pct"]
        ent = {}
        for sc in ("z0_plus20", "z0_minus20"):
            s = pf[(pf.scenario == sc) & (pf.method == m)].set_index("file")
            if s.empty:
                continue
            tf = np.array([float(unjson(x)) for x in s["fgt1_s"]], float)
            fin = tf[np.isfinite(tf)]
            d = (s["adm_rmse_pct"] - base.reindex(s.index)).astype(float)
            ent[sc] = dict(n=int(tf.size), n_slow=int(np.sum(~(tf <= slow_s))), n_never=int(np.sum(~np.isfinite(tf))),
                           max_finite_s=float(fin.max()) if fin.size else float("nan"),
                           n_better_than_nominal=int(np.sum(d < 0)), n_worse_than_nominal=int(np.sum(d > 0)),
                           max_increase=float(d.max()), argmax_increase=str(d.idxmax()))
        out["per_method"][m] = ent
    return out


def clip_stats(df, methods):
    out = {}
    for m in methods:
        s = df[df.method == m]
        if s.empty:
            continue
        # only estimators that actually clip (soc_clip_count > 0); CC does not clip, its values may leave the range
        act = s["soc_clip_count"].fillna(0) > 0
        s = s.assign(**{k: s[k].where(act, 0) for k in ("clip_lo_n", "clip_hi_n", "clip_adm_n")},
                     clip_lo_zref_max=s["clip_lo_zref_max"].where(act))
        on = (s["clip_lo_n"].fillna(0) + s["clip_hi_n"].fillna(0)) > 0
        zmax = s["clip_lo_zref_max"].astype(float)
        out[m] = dict(n_runs=int(len(s)), n_runs_clipped=int(on.sum()), frac_runs_clipped=float(on.mean()),
                      n_runs_clip_in_admissible=int((s["clip_adm_n"].fillna(0) > 0).sum()),
                      n_runs_upper_clip=int((s["clip_hi_n"].fillna(0) > 0).sum()),
                      max_zref_at_lower_clip=float(np.nanmax(zmax.values)) if np.any(np.isfinite(zmax.values)) else float("nan"),
                      n_runs_soc_clip_count=int((s["soc_clip_count"].fillna(0) > 0).sum()))
    return out


def load_cached():
    c, _, _, _ = cfg()
    files = list(c["splits"]["test_dynamic"])
    ch = code_hash()
    res = []
    for lid in files:
        with open(CACHE / f"{lid}.json", "r", encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("code_hash") != ch:
            raise RuntimeError(f"cache of {lid} is stale (hash {d.get('code_hash')} != {ch}); run without --report-only")
        res.append(d)
    info = dict(code_hash=ch, wall_this_call_s=0.0, n_files_computed=0, workers=0)
    ri = CACHE / "_run_info.json"
    if ri.exists():
        with open(ri, "r", encoding="utf-8") as fh:
            d = json.load(fh)
        if d.get("code_hash") == ch:
            info.update(last_compute_wall_s=d["compute_wall_s"], last_compute_workers=d["workers"], last_compute_utc=d["utc"])
    return res, info


def scenario_order(pf):
    groups = ["baseline", "z0", "bias", "vnoise", "inoise", "param_worst", "param_rc_worst", "alpha", "cap", "temp"]
    order = []
    for g in groups:
        sc = sorted(pf[pf.group == g].scenario.unique(), key=lambda x: (x.startswith("z0_minus"), _lev(x)))
        order += list(sc)
    return order


def _lev(sc):
    import re
    m = re.search(r"([+-]?\d+(\.\d+)?)", sc.split("_", 1)[-1]) if "_" in sc else None
    return float(m.group(1)) if m else 0.0


def finalize(results, run_info, t_w0, t_c0):
    c, rb, est, dt = cfg()
    methods = list(rb["methods"])
    r1 = rb["review_round_1"]
    allm = all_methods()
    df = frame(results)
    pf = per_file(df)
    wp = worst_param(pf, allm, "param")
    wprc = worst_param(pf, allm, "param_rc")
    pf2 = with_pseudo(pf, dict(param_worst=wp, param_rc_worst=wprc))
    order = scenario_order(pf2)
    durations = {d["file"]: d["duration_s"] for d in results}
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="All-NaN slice")     # seed IQR of deterministic-only diagnostics
        summ = summaries(pf2, allm, order)
    paired = paired_vs_ref(pf2, allm, order, rb["reference_method"], durations)
    degr = degradation(pf2, allm, order)
    bsum, brows = bias_summary(results)
    flags = dict(nonfinite_runs=int(df["nonfinite"].fillna(False).astype(bool).sum()),
                 positivity_violations_TFO_FOO=int((df[df.estimator.isin(["TFO", "FOO"])]["positivity_ok"] == False).sum()),  # noqa: E712
                 soc_clip_runs=int((df["soc_clip_count"].fillna(0) > 0).sum()),
                 soc_clip_runs_by_method={m: int((df[df.method == m]["soc_clip_count"].fillna(0) > 0).sum()) for m in allm})
    headline = ["baseline", "z0_plus20", "z0_minus20", "bias_-50mA", "bias_+50mA", "param_worst", "param_rc_worst",
                "cap_0.95", "temp_25C"]
    review = dict(
        settings=r1,
        holm=holm_table(paired, methods, order, rb["reference_method"]),
        equivalence=equivalence(paired, order, ["FOO"] + [m for m in allm if m.startswith("TFO_lam")],
                                float(r1["equivalence_margin_pct"])),
        per_T_paired=per_T_paired(pf2, allm, headline, rb["reference_method"]),
        failures=failures(pf2, allm, order, float(r1["failure_threshold_pct"])),
        z0=z0_detail(pf2, allm, float(r1["slow_forgetting_s"])),
        clip=clip_stats(df, allm),
        diagnostic_setup={m: dict(spec=diag_methods()[m], per_T={str(T): (dict(
            params=grid_entry(T, float(diag_methods()[m]["lam"]), int(diag_methods()[m]["L_s"]))["params"],
            hyper=grid_entry(T, float(diag_methods()[m]["lam"]), int(diag_methods()[m]["L_s"]))["hyper"],
            certified=grid_entry(T, float(diag_methods()[m]["lam"]), int(diag_methods()[m]["L_s"]))["certified"],
            validation_objective_pct=grid_entry(T, float(diag_methods()[m]["lam"]), int(diag_methods()[m]["L_s"]))[
                "validation_objective_pct"]) if diag_methods()[m]["estimator"] == "TFO" else dict(hyper=setup(m, T)[2]))
            for T in (0, 25, 45)}) for m in diag_methods()},
        prior_test_access=load_json("validation_main.json").get("prior_test_access"),
        archive="results/archive/E2_pre_review/MANIFEST.json")
    fig = figure_data(results, pf2, summ, brows, methods)
    timing = dict(per_file=[dict(file=d["file"], wall_s=d["wall_s"], process_s=d["process_s"], n_runs=len(d["records"]),
                                 pid=d.get("pid")) for d in results],
                  sum_worker_wall_s=float(sum(d["wall_s"] for d in results)),
                  sum_worker_process_s=float(sum(d["process_s"] for d in results)), **run_info)
    out = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), script="scripts/06b_robustness.py",
               task_version=TASK_VERSION, frozen_config=dict(code_hash=frozen()["code_hash"], frozen_utc=frozen()["frozen_utc"],
                                                            budget_s=frozen()["memory_budget_primary_s"]),
               settings=rb, admissible_soc_interval=dt["admissible_soc_interval"],
               t_post_s=float(est["post_convergence_t_s"]),
               primary="adm_rmse_pct: post-convergence SOC RMSE on the admissible reference-SOC interval (certified claims); whole-profile metrics alongside",
               files=[dict(file=d["file"], T=d["T"], profile=d["profile"], start_level=d["start_level"], n=d["n"],
                           duration_s=d["duration_s"], z_ref0=d["z_ref0"], verify_passed=d["verify_passed"]) for d in results],
               n_runs=int(len(df)), flags=flags, param_worst=wp, param_rc_worst=wprc, scenario_order=order, summary=summ,
               methods_main=methods, methods_diagnostic=list(diag_methods()), review_round_1=review,
               paired_vs_TFO=paired, degradation_vs_baseline=degr, bias_theory=bsum,
               per_file=pf2[["scenario", "method", "file", "T", "adm_rmse_pct", "post_rmse_pct", "adm_conv_time_s",
                             "conv_time_s", "adm_rmse_pct_seed_iqr", "n_runs"]].to_dict(orient="records"),
               bias_rows=brows.to_dict(orient="records"), figure=fig, timing=timing)
    timing["main_wall_s"] = time.perf_counter() - t_w0
    timing["main_process_s"] = time.process_time() - t_c0
    with open(RES / "robustness.json", "w", encoding="utf-8") as fh:
        json.dump(jsonable(out), fh, indent=1)
    out = json.loads(json.dumps(jsonable(out)))
    write_table(out)
    make_figure(out)
    write_report(out)
    print(f"[E2] done: {out['n_runs']} runs; wall {time.perf_counter() - t_w0:.1f} s, "
          f"main process {time.process_time() - t_c0:.1f} s, workers' process {timing['sum_worker_process_s']:.1f} s")


# ---------------------------------------------------------------------------------------------------------------
# Figure data, table, figure
# ---------------------------------------------------------------------------------------------------------------
def figure_data(results, pf, summ, brows, methods):
    fd = dict(fig_file=FIG_FILE)
    tr = next(d["traj"] for d in results if d["file"] == FIG_FILE)
    fd["traj"] = tr
    fd["conv"] = {sc: {m: pf[(pf.scenario == sc) & (pf.method == m)][["file", "adm_conv_time_s", "conv_time_s", "fgt1_s",
                                                                       "fgt2_s"]]
                       .to_dict(orient="records") for m in methods} for sc in ("z0_plus20", "z0_minus20")}
    lev = [("bias_-50mA", -50), ("bias_-20mA", -20), ("baseline", 0), ("bias_+20mA", 20), ("bias_+50mA", 50)]
    fd["bias_curve"] = {m: [dict(dI_mA=v, **{k: summ[sc][m]["adm_rmse_pct"][k] for k in ("median", "q25", "q75")})
                            for sc, v in lev] for m in methods}
    b = brows[brows.method.isin(["TFO", "FOO"])]
    fd["theory"] = b[["method", "file", "T", "dI", "obs_mean", "pred_mean", "pred_cont_mean", "pred_k1",
                      "pred_k2"]].to_dict(orient="records")
    return fd


def _stack(top, bottom):
    """Two-line table cell: median (with marker) above, (q25--q75) below in \\scriptsize."""
    return r"\begin{tabular}[t]{@{}c@{}}" + top + r"\\[-1pt]{\scriptsize " + bottom + r"}\end{tabular}"


def _cell(ent, pr, key="adm_rmse_pct", nd=2):
    st = ent[key]
    txt = f"{st['median']:.{nd}f}"
    if pr is not None:
        d = pr[key]
        if isinstance(d["ci_lo"], (int, float)) and d["ci_lo"] > 0:
            txt += r"$^{+}$"
        elif isinstance(d["ci_hi"], (int, float)) and d["ci_hi"] < 0:
            txt += r"$^{-}$"
    return _stack(txt, f"({st['q25']:.{nd}f}--{st['q75']:.{nd}f})")


def _conv_cell(ent, pr):
    st = ent["adm_conv_time_s"]
    med = st["median"]
    ms = r"n.c." if not isinstance(med, (int, float)) or not math.isfinite(med) else f"{med:.0f}"
    txt = f"{ms} [{st['n_inf']}/{st['n']}]"
    if pr is not None:
        d = pr["adm_conv_time_s"]
        if isinstance(d["ci_lo"], (int, float)) and d["ci_lo"] > 0:
            txt += r"$^{+}$"
        elif isinstance(d["ci_hi"], (int, float)) and d["ci_hi"] < 0:
            txt += r"$^{-}$"
    return txt


LABELS = {"baseline": "Nominal (baseline)", "z0_plus20": r"$z_0$ error $+0.20$", "z0_minus20": r"$z_0$ error $-0.20$",
          "param_worst": r"Parameters, declared worst of $2^4$ ($2^3$)",
          "param_rc_worst": r"Parameters $R_0,R_p,C_p$ only, worst of $2^3$",
          "alpha_0.9": r"$\alpha\times0.9$ (fractional only)", "alpha_1.1": r"$\alpha\times1.1$ (fractional only)",
          "temp_25C": r"25\,$^\circ$C model on 0/45\,$^\circ$C"}


def label_of(sc):
    if sc in LABELS:
        return LABELS[sc]
    g, v = sc.split("_", 1)
    if g == "bias":
        return rf"$\delta_I={v.replace('mA', '')}$\,mA"
    if g == "vnoise":
        return rf"$\sigma_V={v.replace('mV', '')}$\,mV"
    if g == "inoise":
        return rf"$\sigma_I={v.replace('mA', '')}$\,mA"
    if g == "cap":
        return rf"$\hat Q_n={v}\,Q_{{\mathrm{{id}}}}$"
    return sc


def tex_meth(m):
    return m.replace("EKF2RC", "EKF-2RC").replace("_lam1e-3", r"$_{\lambda=10^{-3}}$").replace("_lam1e-2", r"$_{\lambda=10^{-2}}$") \
            .replace("_qz", r"$_{q_z}$").replace("_textbook", r"$_{\mathrm{tb}}$")


def _eqv_cell(ent, eq):
    st = ent["adm_rmse_pct"]
    txt = f"{st['median']:.2f}" + (r"$^{\approx}$" if eq and eq["equivalent"] else "")
    return _stack(txt, f"({st['q25']:.2f}--{st['q75']:.2f})")


MHEAD = {"EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC"}


def _mh(m):
    """Column head of a method (display names of the manuscript)."""
    return MHEAD.get(m, m)


def write_table(out):
    methods = list(out["methods_main"])
    diag = list(out["methods_diagnostic"])
    ref = out["settings"]["reference_method"]
    S, P, R = out["summary"], out["paired_vs_TFO"], out["review_round_1"]
    r1 = R["settings"]
    nmc = int(out["settings"]["mc_runs"])
    lo, hi = out["admissible_soc_interval"]
    bs = P["baseline"]["FOO"]["adm_rmse_pct"]
    ntemp = S["temp_25C"]["TFO"]["n_files"]
    L = [r"% Generated by scripts/06b_robustness.py from results/robustness.json (do not edit by hand).",
         r"\begin{table*}[t]\centering\footnotesize\setlength{\tabcolsep}{3pt}",
         r"\caption{Robustness on the " + str(len(out["files"])) + r" test files (frozen configuration, memory budget "
         + f"{out['frozen_config']['budget_s']}" + r"~s). Entries: median (q25--q75) over files of the post-convergence SOC "
         r"RMSE (\% SOC; $t-t_0\ge" + f"{out['t_post_s']:.0f}" + r"$~s) on the admissible reference-SOC interval "
         + f"$[{lo:.2f},{hi:.2f}]$" + r"; for the noise cases the per-file value is the median over " + str(nmc)
         + r" Monte-Carlo seeds. $^{+}$/$^{-}$: the " + f"{100 * bs['ci_level']:.0f}" + r"\% percentile-bootstrap CI ("
         + f"{bs['n_boot']:,}".replace(",", r"\,") + r" resamples) of the paired median difference to TFO lies above/below "
         r"zero (unadjusted, descriptive; files treated as independent although they form three temperature clusters; "
         + f"{R['holm']['n_ci_flags']}" + r" flags, " + f"{R['holm']['n_holm_005']}" + r" cells significant after Holm "
         r"over " + f"{R['holm']['n_cells']}" + r" Wilcoxon tests). FOO column: $^{\approx}$ = equivalent to TFO (CI inside "
         + f"$\\pm{r1['equivalence_margin_pct']}$" + r"\% SOC). Parameter rows: worst combination selected on the test "
         r"files by the mean over files (the entry is the median over files of that combination; the CI ignores the "
         r"selection); the declared row includes $\alpha\times0.9/1.1$ for the fractional models (16 combinations vs 8), "
         r"the $R_0,R_p,C_p$-only row uses the same 8 combinations for all model classes. Temperature case: " + str(ntemp)
         + r" files. Lower block: admissible convergence time to $\pm2$\% SOC (s; median, [not converged/files]).}"
         r"\label{tab:robustness}",
         r"\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.2\textwidth}" + "c" * len(methods) + r"@{}}\toprule",
         "Case & " + " & ".join(_mh(m) for m in methods) + r" \\ \midrule"]
    for sc in out["scenario_order"]:
        if sc not in S or "TFO" not in S[sc]:
            continue
        row = [label_of(sc)]
        for m in methods:
            if m not in S[sc]:
                row.append("--")
            elif m == "FOO":
                row.append(_eqv_cell(S[sc][m], R["equivalence"]["FOO"].get(sc)))
            else:
                row.append(_cell(S[sc][m], None if m == ref else P.get(sc, {}).get(m)))
        L.append(" & ".join(row) + r" \\" + f" % src: results/robustness.json:summary.{sc}; paired_vs_TFO.{sc}; "
                 f"review_round_1.equivalence.FOO.{sc}")
        if sc in ("baseline", "z0_minus20", "bias_+50mA", "vnoise_10mV", "inoise_50mA", "alpha_1.1", "cap_1.05"):
            L.append(r"\addlinespace[2pt]")
    L.append(r"\midrule")
    for sc in ("baseline", "z0_plus20", "z0_minus20"):
        row = [label_of(sc) + r", $t_c$ (s)"]
        for m in methods:
            row.append(_conv_cell(S[sc][m], None if m == ref else P.get(sc, {}).get(m)))
        L.append(" & ".join(row) + r" \\" + f" % src: results/robustness.json:summary.{sc}.*.adm_conv_time_s")
    L += [r"\bottomrule\end{tabular}", r"\end{table*}", ""]
    # failures: files above the threshold and the per-file maximum
    thr = float(r1["failure_threshold_pct"])
    F = R["failures"]
    L += [r"\begin{table*}[t]\centering\footnotesize\setlength{\tabcolsep}{4pt}",
          r"\caption{Per-file failures behind Table~\ref{tab:robustness}: number of test files with admissible "
          r"post-convergence SOC RMSE above " + f"{thr:g}" + r"\% SOC / maximum over files (\% SOC). Individual failures "
          r"(file, value, own baseline) are listed in the code package (Code availability).}"
          r"\label{tab:robustness_fail}",
          r"\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.24\textwidth}" + "c" * len(methods) + r"@{}}\toprule",
          "Case & " + " & ".join(_mh(m) for m in methods) + r" \\ \midrule"]
    for sc in out["scenario_order"]:
        if sc not in F or "TFO" not in F[sc]:
            continue
        L.append(" & ".join([label_of(sc)] + [
            (f"{F[sc][m]['n_fail']}/{F[sc][m]['n_files']}\\,|\\,{F[sc][m]['max']:.2f}" if m in F[sc] else "--")
            for m in methods]) + r" \\" + f" % src: results/robustness.json:review_round_1.failures.{sc}")
    L += [r"\bottomrule\end{tabular}", r"\end{table*}", ""]
    # diagnostics (post hoc, not selected, not frozen)
    dcols = ["TFO"] + [m for m in diag if m.startswith("TFO_lam")] + ["FOEKF"] + [m for m in diag if m.startswith("FOEKF")] \
        + ["EKF2RC"] + [m for m in diag if m.startswith("EKF2RC")]
    L += [r"\begin{table*}[t]\centering\footnotesize\setlength{\tabcolsep}{3pt}",
          r"\caption{Post hoc diagnostics on the test files (not selected, not frozen). Same entries and "
          r"markers as Table~\ref{tab:robustness} (paired to TFO). TFO$_{\lambda}$: the validation-derived TFO candidates "
          r"with $\lambda=10^{-3}$ and $10^{-2}$ at the same " + f"{out['frozen_config']['budget_s']}" + r"~s memory (own "
          r"parameters and tuned gains, same tuning budget). FOEKF$_{q_z}$, EKF-2RC$_{q_z}$: frozen filters with the textbook "
          r"SOC-channel setting $q_z=10^{-10}$, $p_{z,0}=0.04$; EKF-2RC$_{\mathrm{tb}}$: full textbook noise setting.}"
          r"\label{tab:robustness_diag}",
          r"\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.17\textwidth}" + "c" * len(dcols) + r"@{}}\toprule",
          "Case & " + " & ".join(tex_meth(m) for m in dcols) + r" \\ \midrule"]
    for sc in out["scenario_order"]:
        if sc not in S or sc.startswith(("vnoise", "inoise")) or not any(m in S[sc] for m in diag):
            continue
        L.append(" & ".join([label_of(sc)] + [
            (_cell(S[sc][m], None if m == ref else P.get(sc, {}).get(m)) if m in S[sc] else "--") for m in dcols])
            + r" \\" + f" % src: results/robustness.json:summary.{sc}; paired_vs_TFO.{sc}")
    L += [r"\bottomrule\end{tabular}", r"\end{table*}"]
    (ROOT / "tables").mkdir(exist_ok=True)
    from tfso.texfix import finalize_table
    (ROOT / "tables" / "tab_robustness.tex").write_text(finalize_table(
        "\n".join(L), "results/robustness.json:settings (mc_runs, bootstrap), paired_vs_TFO (flags, Holm), "
        "summary.temp_25C (n_files)") + "\n", encoding="utf-8")


def _f(v):
    v = unjson(v)
    return float(v) if v is not None else float("nan")


def make_figure(out):
    from tfso import plotstyle as ps
    plt = ps.setup()
    methods = list(out["settings"]["methods"])
    fd = out["figure"]
    tr = fd["traj"]
    t_h = np.asarray(tr["t"], float) / 3600.0
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 112), layout="constrained")
    # (a), (b): SOC error on the declared file, z0 = reference +- 0.20
    for k, sc in enumerate(("z0_plus20", "z0_minus20")):
        ax = axs[0, k]
        for m in methods:
            st = ps.line(m, lw=1.0)
            ax.plot(t_h, 100 * np.asarray(tr["e"][sc][m], float), label=ps.LABEL[m], **st)
        ax.axhspan(-2, 2, color=ps.SHADE, zorder=0, lw=0)
        ax.axhline(0, color=ps.INK2, lw=0.6)
        ax.set_xlabel("time (h)")
        ax.set_ylabel(r"SOC error $\hat z - z$ (% SOC)")
        ax.set_ylim(-24, 24) if sc == "z0_plus20" else ax.set_ylim(-24, 24)
        ps.note(ax, ("$z_0$ error $+0.20$" if sc == "z0_plus20" else "$z_0$ error $-0.20$") + f"\n{fd['fig_file']}")
        ps.panel_label(ax, k)
    axs[0, 0].legend(ncol=2, loc="lower right", fontsize=6.5, handlelength=2.2)
    # (c): paired forgetting time t_f(1 %) over the 18 files (both z0 errors); never at the top
    ax = axs[0, 2]
    top = 3.0e4
    for i, m in enumerate(methods):
        for j, sc in enumerate(("z0_plus20", "z0_minus20")):
            vals = np.array([_f(r["fgt1_s"]) for r in fd["conv"][sc][m]], float)
            y = np.where(np.isfinite(vals), np.maximum(vals, 1.0), top)
            x = i + (j - 0.5) * 0.36 + np.linspace(-0.09, 0.09, y.size)
            ax.plot(x, y, **ps.points(m, marker="o" if j == 0 else "s", filled=(j == 0), ms=3.0))
            med = np.quantile(np.where(np.isfinite(vals), np.maximum(vals, 1.0), np.inf), 0.5, method="inverted_cdf")
            ax.plot([i + (j - 0.5) * 0.36 - 0.14, i + (j - 0.5) * 0.36 + 0.14], [min(med, top)] * 2, color=ps.INK, lw=1.2)
    ax.set_yscale("log")
    ax.axhline(1.5e4, color=ps.MUTED, lw=0.5, ls=":")
    ax.text(-0.4, top * 1.25, "never", ha="left", va="bottom", fontsize=6.5, color=ps.INK2)
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels([ps.LABEL[m] for m in methods], rotation=35, ha="right", rotation_mode="anchor")
    ax.set_ylabel(r"forgetting time $t_f(1\%)$ (s)")
    ax.set_ylim(0.7, top * 3)
    ax.set_title("filled $+0.20$, open $-0.20$; bar: median", fontsize=6.5, color=ps.INK2, loc="right")
    ps.panel_label(ax, 2)
    # (d): admissible RMSE vs current offset
    ax = axs[1, 0]
    for i, m in enumerate(methods):
        bc = fd["bias_curve"][m]
        x = np.array([r["dI_mA"] for r in bc], float) + (i - 2.5) * 1.3
        med = np.array([_f(r["median"]) for r in bc])
        lo, hi = np.array([_f(r["q25"]) for r in bc]), np.array([_f(r["q75"]) for r in bc])
        ax.errorbar(x, med, yerr=[med - lo, hi - med], capsize=0, elinewidth=0.6, label=ps.LABEL[m],
                    **ps.line(m, marker=True, lw=1.0, ms=3.2))
    ax.set_xlabel(r"current offset $\delta_I$ (mA)")
    ax.set_ylabel("admissible SOC RMSE (% SOC)")
    ax.set_xticks([-50, -20, 0, 20, 50])
    ps.note(ax, "median, IQR over 18 files", x=0.5, ha="center")
    ps.panel_label(ax, 3)
    # (e): SOC shift caused by the offset on the declared file: TFO, FOO vs CC drift
    ax = axs[1, 1]
    for m in ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC"):
        st = ps.line(m, lw=1.0)
        d = 100 * (np.asarray(tr["e"]["bias_+50mA"][m], float) - np.asarray(tr["e"]["baseline"][m], float))
        ax.plot(t_h, d, label=ps.LABEL[m], **st)
    th = [r for r in fd["theory"] if r["file"] == fd["fig_file"] and abs(r["dI"] - 0.05) < 1e-12 and r["method"] == "TFO"]
    if th:
        ax.axhline(100 * th[0]["pred_mean"], color=ps.INK2, lw=0.7, ls="--",
                   label="steady-state prediction,\nTFO (window mean)")
        ax.legend(handles=[ax.get_lines()[-1]], loc="lower right", fontsize=ps.FONT_PT["legend"] - 1,
                  handlelength=2.0)
        lo_, hi_ = ax.get_ylim()
        ax.set_ylim(lo_ - 0.3 * (hi_ - lo_), hi_)        # free band below the curves for the legend
    ax.axhline(0, color=ps.INK2, lw=0.6)
    ax.set_xlabel("time (h)")
    ax.set_ylabel(r"$\Delta e$ at $\delta_I=+50$ mA (% SOC)")
    ps.note(ax, fd["fig_file"], x=0.02, ha="left")
    ps.panel_label(ax, 4)
    # (f): observed vs predicted mean SOC shift (all files, all offsets)
    ax = axs[1, 2]
    lim = 0.0
    for m, mk in (("FOO", "s"), ("TFO", "o")):
        rows = [r for r in fd["theory"] if r["method"] == m]
        x = 100 * np.array([r["pred_mean"] for r in rows])
        y = 100 * np.array([r["obs_mean"] for r in rows])
        lim = max(lim, np.max(np.abs(np.concatenate([x, y]))))
        ax.plot(x, y, label=ps.LABEL[m], **ps.points(m, marker=mk, filled=(m == "TFO"), ms=2.4 if m == "TFO" else 4.2))
    lim *= 1.08
    ax.plot([-lim, lim], [-lim, lim], color=ps.INK2, lw=0.7, ls="--")
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_xlabel("predicted steady-state shift (% SOC)")
    ax.set_ylabel("observed mean shift (% SOC)")
    ax.legend(loc="lower right", fontsize=6.5)
    ps.note(ax, "18 files x 4 offsets\nadmissible window", x=0.02, ha="left")
    ps.panel_label(ax, 5)
    (ROOT / "figures").mkdir(exist_ok=True)
    ps.save(fig, ROOT / "figures" / "fig_robustness.pdf")
    ps.preview_png(ROOT / "figures" / "fig_robustness.pdf")
    plt.close(fig)



# ---------------------------------------------------------------------------------------------------------------
# Findings report (every number from results/robustness.json, frozen_config.json, capacity.json)
# ---------------------------------------------------------------------------------------------------------------
def _n(v, nd=2):
    v = unjson(v)
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "n/a"
    if isinstance(v, float) and math.isinf(v):
        return "never"  # noqa
    return f"{v:.{nd}f}"


def _pd(d, nd=2, unit=""):
    return f"{_n(d['median_diff'], nd)}{unit} [{_n(d['ci_lo'], nd)}, {_n(d['ci_hi'], nd)}]"


def _span(vals):
    return f"{min(vals):.3g}-{max(vals):.3g} (max/min {max(vals) / min(vals):.2f})"


def _short(f):
    return str(f).replace("SP2_", "").replace("SOC", "")


def _ci(d):
    return unjson(d["ci_lo"]), unjson(d["ci_hi"])


def _verdict(d):
    lo, hi = _ci(d)
    return "worse than TFO" if lo > 0 else ("better than TFO" if hi < 0 else "not distinguishable from TFO")


def _p(v):
    v = float(unjson(v))
    return f"{v:.1e}" if v < 1e-3 else f"{v:.3f}"


def write_report(out):
    rb, S, P, R = out["settings"], out["summary"], out["paired_vs_TFO"], out["review_round_1"]
    M = list(out["methods_main"])
    fz = frozen()
    cap = load_json("capacity.json")
    tm = out["timing"]
    bs = P["baseline"]["FOO"]["adm_rmse_pct"]
    lo, hi = out["admissible_soc_interval"]
    L = []
    w = L.append
    w("# E2 robustness findings (test files, frozen configuration)\n")
    w(f"Generated by `scripts/06b_robustness.py` ({out['generated_utc']}, task version {out['task_version']}); all numbers from "
      f"`results/robustness.json`. Frozen configuration `results/frozen_config.json` (code hash {out['frozen_config']['code_hash']}, "
      f"frozen {out['frozen_config']['frozen_utc']}, primary memory budget {out['frozen_config']['budget_s']} s); nothing was "
      "re-tuned. Settings: config `robustness` (declared before the first run) plus `robustness.review_round_1` (added after the "
      "E2 review; post hoc, no frozen value changed, nothing selected; pre-review outputs in `results/archive/E2_pre_review`).\n")
    key_findings(out, w)
    w("## Protocol\n")
    nf = len(out["files"])
    w(f"- {nf} test files (FUDS/US06/BJDST x 50/80 % SOC x 0/25/45 C), all pass `data.verify_file`; {out['n_runs']} runs; "
      f"methods {', '.join(M)} (frozen) and the post-hoc diagnostics {', '.join(out['methods_diagnostic'])}; paired differences "
      f"d = method - TFO with files as units ({100 * bs['ci_level']:.0f} % percentile bootstrap CI of the median difference, "
      f"{bs['n_boot']} resamples, seed {bs['seed']}; d > 0 means worse than TFO). The CIs are conditional on the {nf} files and "
      "treat them as independent, although they form three temperature clusters of six (one frozen parameter/gain set each; "
      "50/80 % SOC files of the same profile are near-replicates); per-temperature paired medians (n = 6) are given below. "
      f"The +/- markers are unadjusted descriptive flags: {R['holm']['n_ci_flags']} of {R['holm']['n_cells']} (case, method) cells "
      f"are flagged; {R['holm']['n_holm_005']} cells remain significant after Holm over the two-sided Wilcoxon p-values "
      f"({R['holm']['n_ci_flags_and_holm']} both).")
    w(f"- Monte-Carlo cases: {rb['mc_runs']} seeds {rb['mc_seeds'][0]}-{rb['mc_seeds'][-1]} (identical to config validation.seeds: "
      f"{rb['mc_seeds'] == D.load_config()['validation']['seeds']}; the same seed for every file, level and method: common random "
      "numbers). Per file the seed median is used; across files median (q25-q75).")
    w(f"- PRIMARY metric (certified claims): post-convergence SOC RMSE (t - t0 >= {out['t_post_s']:.0f} s) on the admissible "
      f"reference-SOC interval [{lo:.2f}, {hi:.2f}]. Whole-profile post-convergence RMSE and convergence times (+-2 %) are "
      f"reported alongside; the whole profile includes the end-of-discharge knee (z < {lo:.2f}), where every model-based method "
      "is outside the certified interval.")
    w(f"- Cost: sum over the {nf} worker tasks {tm['sum_worker_wall_s']:.0f} s wall / {tm['sum_worker_process_s']:.0f} s process; "
      + (f"{tm['last_compute_workers']} worker processes; the computing run took {tm['last_compute_wall_s']:.0f} s wall"
         if "last_compute_wall_s" in tm else f"{tm.get('workers')} worker processes")
      + f"; the analysis/report call {tm.get('main_wall_s', 0):.0f} s wall (main process {tm.get('main_process_s', 0):.0f} s).")
    fl, cl = out["flags"], R["clip"]
    w(f"- Flags: {fl['nonfinite_runs']} non-finite runs; {fl['positivity_violations_TFO_FOO']} TFO/FOO runs violate h l1 kappa2 "
      f"<= 1 on the clip range. SOC clip [{fz['soc_clip'][0]}, {fz['soc_clip'][1]}] active (runs with a clipped sample / runs): "
      + ", ".join(f"{m} {v['n_runs_clipped']}/{v['n_runs']} ({100 * v['frac_runs_clipped']:.0f} %)" for m, v in cl.items() if m in M)
      + ". Clipped samples inside the admissible interval: " + ", ".join(f"{m} {v['n_runs_clip_in_admissible']}" for m, v in cl.items())
      + " runs; upper clip: " + str(sum(v["n_runs_upper_clip"] for v in cl.values())) + " runs; largest reference SOC at a "
      "clipped sample over all runs: " + f"{max(float(unjson(v['max_zref_at_lower_clip'])) for v in cl.values() if math.isfinite(float(unjson(v['max_zref_at_lower_clip'])))):.3f}"
      + ". The clip therefore acts only in the knee below the admissible interval: it does not affect the primary metric, but it "
      "truncates the whole-profile metrics and the end-of-profile errors of the model-based methods.")
    pta = R.get("prior_test_access") or {}
    w(f"- Test access before the freeze (copied from results/validation_main.json prior_test_access): {pta.get('note', 'n/a')} "
      f"(identification_refined test phase started {pta.get('identification_refined_test_phase_started_utc')}, freeze "
      f"{pta.get('frozen_utc')}). E2 reads only frozen_config.json, capacity.json and (diagnostics only) gain_design.json / "
      "tuning.json, all validation-derived.")
    w("- E2 run history: the declared cases and the code of the pre-review run are archived in results/archive/E2_pre_review "
      "(MANIFEST.json). Between the first and that run, the only recorded change is the forgetting-time diagnostic "
      "(config robustness.diagnostic_forgetting_time, added after the first analysis); outputs of the first analysis were not "
      "archived, so no other difference can be verified. The robustness section of the archived config equals the declared "
      "section here (review_round_1 is new).\n")
    w("## Magnitudes and their support\n")
    w("- References.bib / literature_comparison.json hold NO verified sensor-accuracy specification (vendor sheets excluded; "
      "waag2014critical, lin2018theoretical, zhao2017observability support only the qualitative bias effect). The one "
      "quantitative anchor is shi2023robust: 0.2 A bias and 5 mA / 5 mV noise as test levels (abstract-level information).")
    vs = [1000 * v for v in rb["voltage_noise_std_V"]]
    ios = [1000 * abs(v) for v in rb["current_offset_A"]]
    w(f"- Voltage noise 5 mV: same level as shi2023robust. Other levels ({', '.join(f'{v:g}' for v in vs if v != 5)} mV): "
      "**sensitivity analysis**.")
    w(f"- Current offset +-{min(ios):g}/+-{max(ios):g} mA (below the 0.2 A of shi2023robust) and current noise "
      f"{'/'.join(f'{1000 * v:g}' for v in rb['current_noise_std_A'])} mA (above its 5 mA): **sensitivity analysis** (no cited "
      "sensor specification).")
    tf = [fz["methods"]["TFO"]["per_T"][str(T)]["params"] for T in (0, 25, 45)]
    qid = [cap["Q_id_T_SP2"][str(T)]["Q_id_Ah"] for T in (0, 25, 45)]
    qr = [cap["Q_ref_T_SP2"][str(T)]["Q_ref_Ah"] for T in (0, 25, 45)]
    w("- Parameters x" + "/".join(f"{v:g}" for v in rb["param_scale"]) + ", alpha x" + "/".join(f"{v:g}" for v in rb["alpha_scale"])
      + ", capacity x" + "/".join(f"{v:g}" for v in rb["capacity_factor"]) + ", 25 C model on 0/45 C: **sensitivity analyses**. "
      f"Context (frozen TFO over 0/25/45 C): R0 {_span([p['R0'] for p in tf])} Ohm, Rp {_span([p['Rp'] for p in tf])} "
      f"Ohm, Cp {_span([p['Cp'] for p in tf])}, alpha {_span([p['alpha'] for p in tf])}; Q_id {_span(qid)} Ah. The baseline itself "
      "carries a capacity mismatch Q_id/Q_ref - 1 = " + ", ".join(f"{100 * (a / b - 1):+.1f} %" for a, b in zip(qid, qr))
      + " (0/25/45 C), because the estimators use Q_id and the ground truth Q_ref.\n")
    w("## Table 6 (primary metric, % SOC, median over files; +/-: unadjusted CI flag of the paired difference to TFO; "
      "~: FOO equivalent to TFO within the margin; [k; max]: files above the failure threshold; per-file maximum)\n")
    thr = float(R["settings"]["failure_threshold_pct"])
    F = R["failures"]
    w("| Case | " + " | ".join(M) + " |")
    w("|---|" + "---|" * len(M))
    for sc in out["scenario_order"]:
        if "TFO" not in S.get(sc, {}):
            continue
        row = [sc]
        for m in M:
            if m not in S[sc]:
                row.append("--")
                continue
            v = _n(S[sc][m]["adm_rmse_pct"]["median"])
            if m == "FOO":
                v += "~" if R["equivalence"]["FOO"][sc]["equivalent"] else ""
            elif m != "TFO" and m in P.get(sc, {}):
                lo_, hi_ = _ci(P[sc][m]["adm_rmse_pct"])
                v += "+" if lo_ > 0 else ("-" if hi_ < 0 else "")
            v += f" [{F[sc][m]['n_fail']}; {F[sc][m]['max']:.1f}]"
            row.append(v)
        w("| " + " | ".join(row) + " |")
    w(f"\nFailure threshold {thr:g} % SOC (config validation_main.review_round_1). Whole-profile post-convergence RMSE (median "
      "over files): " + "; ".join(f"{sc}: " + ", ".join(f"{m} {_n(S[sc][m]['post_rmse_pct']['median'])}" for m in M if m in S[sc])
                                  for sc in ("baseline", "bias_+50mA", "bias_-50mA", "temp_25C")) + ".\n")
    report_sections(out, w)
    review_response(out, w)
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "robustness_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def key_findings(out, w):
    rb, S, P, B, D_, R = (out["settings"], out["summary"], out["paired_vs_TFO"], out["bias_theory"],
                          out["degradation_vs_baseline"], out["review_round_1"])
    fz = frozen()
    med = lambda sc, m, k="adm_rmse_pct": S[sc][m][k]["median"]                    # noqa: E731
    pm = B["per_method_dI"]
    th = B["theory"]["TFO"]
    main_sc = [sc for sc in out["scenario_order"] if "FOO" in P.get(sc, {})]
    eq = R["equivalence"]["FOO"]
    ds = [abs(eq[sc]["median_diff"]) for sc in main_sc]
    n_eq = sum(eq[sc]["equivalent"] for sc in main_sc)
    fav = [sc for sc in main_sc if eq[sc]["n_better"] > eq[sc]["n_worse"] and eq[sc]["ci_excludes_0"]]
    unf = [sc for sc in main_sc if eq[sc]["n_worse"] > eq[sc]["n_better"] and eq[sc]["ci_excludes_0"]]
    st = fz["methods"]["TFO"]["structure"]
    grid = D.load_config()["design_tuning"]["lambda_grid"]
    mu = {m: [v["mu0"] for v in B["theory"][m]["per_T"].values()] for m in B["theory"]}
    w("## Key findings\n")
    b0 = eq["baseline"]
    w(f"1. Tempering at the {st['L']} s budget is NOT resolved by the frozen comparison. The frozen TFO uses lambda = {st['lam']:g}, "
      f"the smallest positive value of the design grid {grid} (the unrestricted selection rule chose lambda = "
      f"{fz['proposed_rule']['primary']['lam']:g}), so exp(-lambda L) = {math.exp(-st['lam'] * st['L']):.3f} and the DC "
      f"conductance mu_(h,L)(0) is {', '.join(f'{v:.3f}' for v in mu['TFO'])} (TFO) against {', '.join(f'{v:.3f}' for v in mu['FOO'])} "
      f"(FOO) at 0/25/45 C. TFO and FOO are practically indistinguishable under every disturbance (|median(FOO - TFO)| <= "
      f"{max(ds):.3f} % SOC; equivalent within +-{R['settings']['equivalence_margin_pct']} % SOC in {n_eq} of {len(main_sc)} cases), "
      f"but the tiny difference is systematic: FOO is better (CI excludes 0) in {len(fav)} cases (baseline: {b0['n_better']}/{b0['n']} "
      f"files, Wilcoxon p = {_p(b0['wilcoxon_p'])}) and worse in {len(unf)} ({', '.join(unf) or 'none'}). The frozen pair "
      "therefore cannot say whether tempering changes robustness, and it gives no support for tempering.")
    for m in [x for x in out["methods_diagnostic"] if x.startswith("TFO_lam")]:
        cs = [sc for sc in main_sc if m in P.get(sc, {})]
        nw = sum(_ci(P[sc][m]["adm_rmse_pct"])[0] > 0 for sc in cs)
        nb = sum(_ci(P[sc][m]["adm_rmse_pct"])[1] < 0 for sc in cs)
        vo = [v["validation_objective_pct"] for v in R["diagnostic_setup"][m]["per_T"].values()]
        vf = [fz["methods"]["TFO"]["per_T"][T]["validation_objective_pct"] for T in ("0", "25", "45")]
        w(f"   Diagnostic {m} (validation-derived parameters and gains at L = {st['L']} s, mu0 "
          f"{', '.join(f'{v:.3f}' for v in mu.get(m, []))}; tuned validation objective, mean over T, {np.mean(vo):.3f} vs "
          f"frozen TFO {np.mean(vf):.3f}): worse than frozen TFO in {nw}, better in {nb} of {len(cs)} cases; " + "; ".join(
              f"{sc} {_n(med(sc, m))} (d = {_pd(P[sc][m]['adm_rmse_pct'])})" for sc in
              ("baseline", "z0_minus20", "bias_-50mA", "bias_+50mA", "param_rc_worst", "temp_25C") if m in S.get(sc, {})) + ".")
    lr = [x for x in out["methods_diagnostic"] if x.startswith("TFO_lam")]
    if lr:
        better = {m: [sc for sc in main_sc if m in P.get(sc, {}) and _ci(P[sc][m]["adm_rmse_pct"])[1] < 0] for m in lr}
        w("   Reading: a larger lambda at the same memory is never better than the frozen TFO" + (
            " except " + "; ".join(f"{m} in {', '.join(v)}" for m, v in better.items() if v) if any(better.values()) else "")
          + ", which agrees with the validation ranking. Within the tested grid, E2 gives no evidence that tempering improves "
          "robustness at this memory budget (a diagnostic on test files, not a selection).")
    w(f"2. Context: with an accurate z0 and an unbiased current sensor, plain Coulomb counting has the lowest primary RMSE of all "
      f"methods (baseline CC {_n(med('baseline', 'CC'))} against TFO {_n(med('baseline', 'TFO'))}, FOEKF {_n(med('baseline', 'FOEKF'))}, "
      f"EKF2RC {_n(med('baseline', 'EKF2RC'))}; the same in every white-noise case). Every model-based observer adds error on these "
      "files; its benefit over CC is conditional on initial-SOC or offset errors.")
    z = R["z0"]
    ze = z["nominal_z0_error_pct"]
    pz = z["per_method"]
    sl = R["settings"]["slow_forgetting_s"]
    w(f"3. Initial SOC error +-0.20. The 'nominal' baseline is itself an initial-error scenario: the nominal z0 error ranges from "
      f"{min(ze.values()):+.1f} to {max(ze.values()):+.1f} % SOC over the files (listed in (a)). TFO forgets the +-0.20 error on "
      f"every file (paired t_f(1 %) median {_n(med('z0_plus20', 'TFO', 'fgt1_s'), 0)} / {_n(med('z0_minus20', 'TFO', 'fgt1_s'), 0)} s, "
      f"maximum {max(pz['TFO'][sc]['max_finite_s'] for sc in pz['TFO']):.0f} s) and its primary RMSE hardly changes (paired "
      f"{_n(D_['z0_plus20']['TFO']['median_diff'])} / {_n(D_['z0_minus20']['TFO']['median_diff'])} % SOC). Files with t_f(1 %) > "
      f"{sl:.0f} s or never (+0.20 / -0.20): " + "; ".join(
          f"{m} {pz[m]['z0_plus20']['n_slow']} ({pz[m]['z0_plus20']['n_never']} never) / {pz[m]['z0_minus20']['n_slow']} "
          f"({pz[m]['z0_minus20']['n_never']} never)" for m in out["methods_main"]) + f" of {pz['TFO']['z0_plus20']['n']}. "
      f"The Kalman filters mostly forget within seconds (median FOEKF {_n(med('z0_plus20', 'FOEKF', 'fgt1_s'), 0)} s, EKF2RC "
      f"{_n(med('z0_plus20', 'EKF2RC', 'fgt1_s'), 0)} s). A slow or 'never' EKF2RC forgetting time does not necessarily "
      f"indicate a failed transient: EKF2RC ends on z0-dependent trajectories that differ from the (itself z0-affected) nominal "
      f"run; its primary RMSE is lower than nominal on {pz['EKF2RC']['z0_plus20']['n_better_than_nominal']} and higher on "
      f"{pz['EKF2RC']['z0_plus20']['n_worse_than_nominal']} files at +0.20, lower on {pz['EKF2RC']['z0_minus20']['n_better_than_nominal']} "
      f"and higher on {pz['EKF2RC']['z0_minus20']['n_worse_than_nominal']} at -0.20, i.e. its final trajectory depends on z0. "
      f"Worst single degradation: AEKF2RC at -0.20 on {_short(pz['AEKF2RC']['z0_minus20']['argmax_increase'])} "
      f"(+{pz['AEKF2RC']['z0_minus20']['max_increase']:.2f} % SOC against its own baseline; per-file max "
      f"{R['failures']['z0_minus20']['AEKF2RC']['max']:.2f} %). CC never forgets (primary RMSE {_n(med('z0_plus20', 'CC'))} / "
      f"{_n(med('z0_minus20', 'CC'))}).")
    fq = {m: [float(fz["methods"][m]["per_T"][T]["hyper"]["Q"][0]) for T in ("0", "25", "45")] for m in ("FOEKF", "EKF2RC", "AEKF2RC")}
    best50 = sorted(out["methods_main"], key=lambda m: med("bias_-50mA", m))
    tie = R["equivalence"]["FOO"]["bias_-50mA"]
    w(f"4. Current offset. The TFO SOC shift is bounded and follows thm:robust(vi)/eq:m4b:steady with the implemented DC "
      f"conductance (observed/predicted {_n(th['ratio_obs_pred_median'])}, IQR {_n(th['ratio_obs_pred_q25'])}-"
      f"{_n(th['ratio_obs_pred_q75'])}). Like for like at +50 mA (median over files, % SOC; admissible-window mean / last admissible "
      f"sample): TFO {_n(pm['TFO']['+50mA']['obs_mean_median_pct'])} / {_n(pm['TFO']['+50mA']['obs_adm_end_median_pct'])}, CC "
      f"{_n(pm['CC']['+50mA']['obs_mean_median_pct'])} / {_n(pm['CC']['+50mA']['obs_adm_end_median_pct'])}; the CC drift at the "
      f"profile end, eta delta_I t/(3600 Q_n), is {_n(B['cc']['drift_end_pred_pct_by_dI']['+50mA']['median'])} %. The tuned "
      f"FOEKF/EKF2RC/AEKF2RC have SOC process noise q_z = " + "; ".join(f"{m} {', '.join(f'{v:.0e}' for v in q)}" for m, q in fq.items())
      + " (0/25/45 C; search box 1e-14 to 1e-6), chosen on noise-free, unbiased validation files, which makes their SOC channel "
      f"close to Coulomb counting. With the textbook q_z = 1e-10, p_z = 0.04 (diagnostic), FOEKF at +50 / -50 mA gives "
      f"{_n(med('bias_+50mA', 'FOEKF_qz'))} / {_n(med('bias_-50mA', 'FOEKF_qz'))} (tuned {_n(med('bias_+50mA', 'FOEKF'))} / "
      f"{_n(med('bias_-50mA', 'FOEKF'))}), EKF2RC {_n(med('bias_+50mA', 'EKF2RC_qz'))} / {_n(med('bias_-50mA', 'EKF2RC_qz'))} "
      f"(tuned {_n(med('bias_+50mA', 'EKF2RC'))} / {_n(med('bias_-50mA', 'EKF2RC'))}; full textbook setting "
      f"{_n(med('bias_+50mA', 'EKF2RC_textbook'))} / {_n(med('bias_-50mA', 'EKF2RC_textbook'))}). The offset ranking of the Kalman "
      "FOEKF's offset sensitivity thus follows from its tuned q_z; EKF2RC's does not change with q_z alone but falls with the full "
      "textbook setting (measurement and RC-state noise too). For both, the offset ranking is conditional on the noise-free "
      "validation tuning and is not a property of the filter classes. The TFO baseline "
      f"error is negative (median over files of the per-file mean error {_n(med('baseline', 'TFO', 'adm_bias_pct'))} % SOC; mean over "
      f"files {_n(S['baseline']['TFO']['adm_bias_pct']['mean'])}) and its shift has the opposite sign to delta_I, so at -50 mA the "
      f"lowest median is {best50[0]} ({_n(med('bias_-50mA', best50[0]))})"
      + (f", tied with FOO (equivalent within the margin)" if best50[0] == "TFO" and tie["equivalent"] else
         (f", tied with TFO" if best50[0] == "FOO" and tie["equivalent"] else ""))
      + f", while at +50 mA TFO ({_n(med('bias_+50mA', 'TFO'))}) is worse than the Kalman filters.")
    nz = [x for x in out["scenario_order"] if x.startswith(("vnoise", "inoise"))]
    mx = {m: max(abs(D_[sc][m]["median_diff"]) for sc in nz) for m in out["methods_main"]}
    w("5. White sensor noise is negligible for TFO/FOO/FOEKF (largest paired change " + ", ".join(
        f"{m} {mx[m]:.3f}" for m in ("TFO", "FOEKF", "EKF2RC", "AEKF2RC")) + " % SOC).")
    wp, wr, F = out["param_worst"], out["param_rc_worst"], R["failures"]
    w(f"6. Model mismatch is the weak point of TFO/FOO. Like for like (R0, Rp, Cp only, the same 8 combinations for every model "
      f"class; worst selected on the test files by the mean over files, entry = median over files): " + ", ".join(
          f"{m} {_n(med('param_rc_worst', m))} (mean {wr[m]["worst_mean"]:.2f}; files > {float(R["settings"]["failure_threshold_pct"]):g} %: {F['param_rc_worst'][m]['n_fail']})"
          for m in ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC")) + ". The declared design adds alpha x0.9/1.1 for the "
      f"fractional models (16 combinations against 8): TFO {_n(med('param_worst', 'TFO'))} (mean {wp['TFO']['worst_mean']:.2f}; "
      f"worst with alpha x0.9 {wp['TFO']['worst_mean_alpha_x0.9']:.2f}, with alpha x1.1 {wp['TFO']['worst_mean_alpha_x1.1']:.2f}), "
      f"FOEKF {_n(med('param_worst', 'FOEKF'))}; alpha alone x0.9 / x1.1: TFO {_n(med('alpha_0.9', 'TFO'))} / "
      f"{_n(med('alpha_1.1', 'TFO'))}, FOEKF {_n(med('alpha_0.9', 'FOEKF'))} / {_n(med('alpha_1.1', 'FOEKF'))}. 25 C model on "
      f"0/45 C: TFO {_n(med('temp_25C', 'TFO'))} (FOEKF {_n(med('temp_25C', 'FOEKF'))}, EKF2RC {_n(med('temp_25C', 'EKF2RC'))}, CC "
      f"{_n(med('temp_25C', 'CC'))}; TFO files > {float(R["settings"]["failure_threshold_pct"]):g} %: {F['temp_25C']['TFO']['n_fail']}/{F['temp_25C']['TFO']['n_files']}). Capacity "
      f"+-5 % hardly affects TFO (paired change {_n(D_['cap_0.95']['TFO']['median_diff'])} / {_n(D_['cap_1.05']['TFO']['median_diff'])}) "
      f"but affects CC ({_n(D_['cap_0.95']['CC']['median_diff'])} / {_n(D_['cap_1.05']['CC']['median_diff'])}).")
    pt = R["per_T_paired"]
    w("7. The paired effects are heterogeneous across temperature (median d per 0/25/45 C, n = 6 each): " + "; ".join(
        f"{m} - TFO {sc}: " + " / ".join(f"{v['median_diff']:+.2f}" for v in pt[sc][m].values())
        for sc, m in (("baseline", "EKF2RC"), ("baseline", "FOEKF"), ("bias_+50mA", "FOEKF"), ("bias_-50mA", "EKF2RC")))
      + ". Pooled CIs over 18 files should be read with this clustering in mind.\n")


def report_sections(out, w):
    rb, S, P, B, D_, R = (out["settings"], out["summary"], out["paired_vs_TFO"], out["bias_theory"],
                          out["degradation_vs_baseline"], out["review_round_1"])
    M = list(out["methods_main"])
    q = lambda sc, m, k: S[sc][m][k]                                              # noqa: E731
    w("## (a) Initial SOC error +-0.20\n")
    ze = R["z0"]["nominal_z0_error_pct"]
    w("- Nominal z0 error (common reference OCV at the end-of-rest voltage minus reference SOC, % SOC): " + ", ".join(
        f"{_short(f)} {v:+.1f}" for f, v in ze.items()) + ".")
    for k, lab in (("fgt1_s", "Forgetting time t_f(1 %) (paired to the nominal run; median s [never/files], +0.20 / -0.20)"),
                   ("adm_conv_time_s", "Admissible convergence time to +-2 % (median s [not converged/files], +0.20 / -0.20 / nominal)")):
        w(f"- {lab}: " + ", ".join(
            f"{m} " + " / ".join(f"{_n(q(sc, m, k)['median'], 0)} [{q(sc, m, k)['n_inf']}]"
                                 for sc in (("z0_plus20", "z0_minus20") if k == "fgt1_s" else ("z0_plus20", "z0_minus20", "baseline")))
            for m in M) + ".")
    pz = R["z0"]["per_method"]
    w(f"- Per method (+0.20 / -0.20): files with t_f(1 %) > {R['settings']['slow_forgetting_s']:.0f} s or never, largest finite "
      "t_f, files where the z0 run has a LOWER / HIGHER primary RMSE than the nominal run: " + "; ".join(
          f"{m} " + " / ".join(f"{v['n_slow']}, {_n(v['max_finite_s'], 0)} s, {v['n_better_than_nominal']}/{v['n_worse_than_nominal']}"
                               for v in pz[m].values()) for m in M) + ". The 1000 s level is a descriptive cut only; Figure 9c shows "
      "the full distributions.")
    w("- The declared +-2 % convergence time of TFO equals its nominal-z0 value (" + _n(q("baseline", "TFO", "adm_conv_time_s")["median"], 0)
      + " s): it measures the model error late in the profile, not the initial transient.\n")
    w("## (b) Current-sensor offset\n")
    pm = B["per_method_dI"]
    w("- SOC shift e_biased - e_nominal, mean over the admissible post-convergence window / at its last sample (median over "
      "files, % SOC; the profile end is not used because the SOC clip at the knee masks it): " + "; ".join(f"{m}: " + ", ".join(
          f"{k} {_n(v['obs_mean_median_pct'])} / {_n(v['obs_adm_end_median_pct'])}" for k, v in pm[m].items())
          for m in list(M) + out["methods_diagnostic"] if m in pm) + ".")
    t = B["theory"]["TFO"]
    w(f"- TFO vs thm:robust(vi) with the implemented DC conductance M = mu_(h,L)(0) (eq:m4b:steady; local slope kappa(t) of "
      f"the observer's OCV): observed/predicted mean shift {_n(t['ratio_obs_pred_median'])} (IQR {_n(t['ratio_obs_pred_q25'])}-"
      f"{_n(t['ratio_obs_pred_q75'])}, n = {t['n']}), least-squares slope {_n(t['ls_slope_obs_on_pred'])}, median time "
      f"correlation {_n(t['corr_time_median'])}, median RMS(obs - pred) {_n(t['rms_obs_minus_pred_median_pct'])} % SOC; "
      f"{100 * t['frac_within_kappa_interval']:.0f} % of the file means lie inside [delta_I A/kappa2, delta_I A/kappa1]. "
      f"With the continuous-time value M = lambda^alpha the ratio is {_n(t['ratio_obs_cont_median'])}.")
    w("  Per T: " + "; ".join(
        f"{T} C: A = {_n(v['A_impl_Ohm'], 3)} Ohm (continuous {_n(v['A_cont_Ohm'], 3)}), R_tot = {_n(v['R_tot_impl_Ohm'], 3)} "
        f"(continuous {_n(v['R_tot_cont_Ohm'], 3)}) Ohm, mu0 = {_n(v['mu0'], 3)}, t_x = {_n(v['t_cross_s'], 0)} s"
        for T, v in t["per_T"].items()) + ".")
    for m in [x for x in B["theory"] if x != "TFO"]:
        t = B["theory"][m]
        w(f"- {m}: observed/predicted {_n(t['ratio_obs_pred_median'])} with M = mu_(h,L)(0) (mu0 = " + ", ".join(
            f"{_n(v['mu0'], 3)}" for v in t["per_T"].values()) + f" at 0/25/45 C); {_n(t['ratio_obs_cont_median'])} with the "
            "continuous value M = lambda^alpha (R_tot = " + ", ".join(f"{_n(v['R_tot_cont_Ohm'], 3)}" for v in t["per_T"].values())
          + " Ohm).")
    w("- For FOO (lambda = 0) the continuous value is M = 0: the 400 s memory, not lambda, sets the DC conductance of the frozen "
      "TFO and FOO.")
    cc = B["cc"]
    w(f"- Coulomb counting: the observed drift equals eta delta_I t/(3600 Q_n) to {cc['max_abs_end_obs_minus_pred']:.1e}; at the "
      "profile end it is " + ", ".join(f"{k}: {_n(v['median'])} % (range {_n(v['min'])} to {_n(v['max'])})"
                                       for k, v in cc["drift_end_pred_pct_by_dI"].items()) + ". Compare with the observers on "
      "the matched window statistics above, not with the profile-end value. t_x is the time after which the observer's bounded "
      "shift is smaller than the CC drift (thm:robust(vi), kappa = kappa1).\n")
    w("## (c), (d) Sensor noise\n")
    nz = [x for x in out["scenario_order"] if x.startswith(("vnoise", "inoise"))]
    top_v = [x for x in nz if x.startswith("vnoise")][-1]
    top_i = [x for x in nz if x.startswith("inoise")][-1]
    w(f"- {top_v}: change of the primary RMSE vs noise-free (paired median [CI], % SOC) " + ", ".join(
        f"{m} {_pd(D_[top_v][m])}" for m in M) + "; median seed IQR " + ", ".join(
        f"{m} {_n(S[top_v][m]['seed_iqr_median'].get('adm_rmse_pct'), 3)}" for m in M) + ".")
    w(f"- {top_i}: median seed IQR " + ", ".join(
        f"{m} {_n(S[top_i][m]['seed_iqr_median'].get('adm_rmse_pct'), 3)}" for m in M) + ".")
    w("- Largest |paired median change| over all " + str(len(nz)) + " noise cases: " + ", ".join(
        f"{m} {max(abs(D_[sc][m]['median_diff']) for sc in nz):.3f}" for m in M) + " % SOC.\n")
    w("## (e) Parameter perturbation\n")
    for key, lab in (("param_worst", "Declared design (fractional 2^4 incl. alpha, 2RC 2^3)"),
                     ("param_rc_worst", "R0/Rp/Cp only (2^3 for every model class; like for like)")):
        w(f"- {lab}. Worst combination by the mean over files (mean; median over files; median over combinations; worst by the "
          "median instead): " + "; ".join(
              f"{m} {v['worst'].replace('param_', '').replace('prc_', '')} ({v['worst_mean']:.2f}; {v['worst_median']:.2f}; "
              f"{v['median_over_combos']:.2f}; {v['worst_by_median'].replace('param_', '').replace('prc_', '')} "
              f"{v['worst_by_median_value']:.2f}; {v['n_combos']} combinations)" for m, v in out[key].items() if m in M) + ".")
    w("- The worst combination is selected on the test files; the paired CIs of the parameter rows do not account for that "
      "selection, and a maximum over 16 combinations is expected to exceed one over 8 even without any real difference.")
    w("- Alpha alone (fractional only; median over files): " + "; ".join(
        f"{m} x0.9 {_n(S['alpha_0.9'][m]['adm_rmse_pct']['median'])}, x1.1 {_n(S['alpha_1.1'][m]['adm_rmse_pct']['median'])}"
        for m in M if m in S.get("alpha_0.9", {})) + ". CC has no model parameters (unaffected).\n")
    w("## (f), (g) Capacity and temperature mismatch\n")
    for sc in [x for x in out["scenario_order"] if x.startswith(("cap_", "temp_"))]:
        w(f"- {sc}: change of the primary RMSE vs baseline (paired median [CI], % SOC) " + ", ".join(
            f"{m} {_pd(D_[sc][m])}" for m in M if m in D_[sc]) + ".")
    w("")
    w(f"## Per-file failures (primary RMSE above {R['settings']['failure_threshold_pct']:g} % SOC; value [own baseline])\n")
    F = R["failures"]
    for sc in out["scenario_order"]:
        items = [(m, F[sc][m]) for m in M if m in F.get(sc, {}) and F[sc][m]["n_fail"]]
        if items:
            w(f"- {sc}: " + "; ".join(f"{m} {v['n_fail']}/{v['n_files']}: " + ", ".join(
                f"{_short(x['file'])} {x['value']:.2f} [{x['baseline']:.2f}]" for x in v["failed"]) for m, v in items) + ".")
    w("- Largest per-file increase over the method's own baseline, z0 cases: " + "; ".join(
        f"{sc} {m} +{F[sc][m]['max_increase_vs_baseline']:.2f} ({_short(F[sc][m]['argmax_increase'])})"
        for sc in ("z0_plus20", "z0_minus20") for m in M if m != "CC") + ".\n")
    w("## Per-temperature paired differences (method - TFO, median over the 6 files of each T, primary metric; better/worse counts)\n")
    pt = R["per_T_paired"]
    w("| Case | Method | " + " | ".join(f"{T} C" for T in ("0", "25", "45")) + " |")
    w("|---|---|---|---|---|")
    for sc in pt:
        for m in [x for x in M if x in pt[sc]]:
            w(f"| {sc} | {m} | " + " | ".join(
                (f"{pt[sc][m][T]['median_diff']:+.2f} ({pt[sc][m][T]['n_better']}/{pt[sc][m][T]['n_worse']})" if T in pt[sc][m]
                 else "--") for T in ("0", "25", "45")) + " |")
    w("")
    w("## Post-hoc diagnostics (review round 1; not selected, not frozen)\n")
    diag = out["methods_diagnostic"]
    for m in diag:
        ds = R["diagnostic_setup"][m]
        extra = ""
        if "per_T" in ds and "certified" in next(iter(ds["per_T"].values())):
            extra = " certified at every T: " + str(all(v["certified"] for v in ds["per_T"].values())) + "; validation objective " + \
                ", ".join(f"{v['validation_objective_pct']:.3f}" for v in ds["per_T"].values()) + " (0/25/45 C)."
        w(f"- {m}: {ds['spec'].get('role', '')}; source {ds['spec'].get('source', '')}.{extra}")
    w("\n| Case | " + " | ".join(["TFO", "FOO"] + diag + ["FOEKF", "EKF2RC"]) + " |")
    w("|---|" + "---|" * (len(diag) + 4))
    for sc in out["scenario_order"]:
        if sc.startswith(("vnoise", "inoise")) or not any(m in S.get(sc, {}) for m in diag):
            continue
        cells = []
        for m in ["TFO", "FOO"] + diag + ["FOEKF", "EKF2RC"]:
            if m not in S[sc]:
                cells.append("--")
                continue
            v = _n(S[sc][m]["adm_rmse_pct"]["median"])
            if m != "TFO" and m in P.get(sc, {}):
                lo_, hi_ = _ci(P[sc][m]["adm_rmse_pct"])
                v += "+" if lo_ > 0 else ("-" if hi_ < 0 else "")
            cells.append(v)
        w(f"| {sc} | " + " | ".join(cells) + " |")
    w("")
    w("## Caveats\n")
    w("- The bias prediction is quasi-steady (constant current and slope in the theorem, local slope used here); the whole-profile "
      f"metrics include the knee z < {out['admissible_soc_interval'][0]:.2f} where the certificate does not apply. The forgetting "
      "time was added after the first analysis (config `robustness.diagnostic_forgetting_time`), and everything in "
      "`robustness.review_round_1` after the review; no choice depends on them. All magnitudes except 5 mV are sensitivity levels, "
      "not cited sensor specifications. Diagnostics are evaluated on test files and must not be used to select a configuration.\n")


def review_response(out, w):
    """Review response (round 1); every number from results/robustness.json."""
    S, P, R, B = out["summary"], out["paired_vs_TFO"], out["review_round_1"], out["bias_theory"]
    med = lambda sc, m: S[sc][m]["adm_rmse_pct"]["median"]                        # noqa: E731
    wp, wr, F, pz = out["param_worst"], out["param_rc_worst"], R["failures"], R["z0"]["per_method"]
    eq = R["equivalence"]["FOO"]
    pm = B["per_method_dI"]
    thr = float(R["settings"]["failure_threshold_pct"])
    w("## Review response (round 1)\n")
    w("Two reviews (one 'major issues', one 'minor issues'). Every item was checked against the data; all were accepted. No "
      "frozen parameter or hyper-parameter was changed (no benchmark was mis-configured: the Kalman q_z values lie inside the "
      "declared search box and were chosen by the declared equal-budget validation tuning), so frozen_config.json is unchanged. "
      "Additions are declared in config `robustness.review_round_1` (post hoc); the pre-review outputs are archived in "
      "results/archive/E2_pre_review. The full E2 computation was re-run (new cache hash " + out["timing"]["code_hash"] + ").\n")
    lam_rows = [m for m in out["methods_diagnostic"] if m.startswith("TFO_lam")]
    w("- R1.1 (tempering headline uninformative; FOO systematically better). Accepted. Key finding 1 now states that the frozen TFO "
      "sits at the grid floor lambda = 1e-4 while the selection rule preferred lambda = 0, that TFO and FOO are practically "
      f"indistinguishable but FOO is marginally and consistently better (baseline {eq['baseline']['n_better']}/{eq['baseline']['n']} "
      f"files), and that E2 therefore cannot decide the tempering question from the frozen pair. The FOO column uses an "
      f"equivalence margin of +-{R['settings']['equivalence_margin_pct']} % SOC instead of CI-exclusion markers. Added the "
      f"diagnostic {', '.join(lam_rows)} (validation-derived parameters and gains at the same 400 s memory, every case): see "
      "key finding 1 and the diagnostics table.")
    w(f"- R1.2 (unequal parameter design). Accepted. Added the like-for-like R0/Rp/Cp-only row (alpha x1.0, 8 combinations for every "
      f"model class): TFO {_n(med('param_rc_worst', 'TFO'))} (mean {wr['TFO']['worst_mean']:.2f}), FOEKF "
      f"{_n(med('param_rc_worst', 'FOEKF'))} (mean {wr['FOEKF']['worst_mean']:.2f}), EKF2RC {_n(med('param_rc_worst', 'EKF2RC'))}; "
      f"declared row TFO {_n(med('param_worst', 'TFO'))} (mean {wp['TFO']['worst_mean']:.2f}). Alpha alone is a separate "
      "fractional-only row. Caption, report and JSON state that the worst combination is selected on the test files by the mean "
      "(entry = median) and that the CI ignores the selection; the worst by the median is stored too.")
    w(f"- R1.3 (Kalman offset sensitivity is a tuning artefact). Accepted and quantified with a disclosed sensitivity analysis on "
      f"the offset and z0 cases (FOEKF_qz, EKF2RC_qz with q_z = 1e-10, p_z = 0.04; EKF2RC_textbook = the E1-declared textbook "
      f"setting): FOEKF +50 mA {_n(med('bias_+50mA', 'FOEKF_qz'))} (tuned {_n(med('bias_+50mA', 'FOEKF'))}), -50 mA "
      f"{_n(med('bias_-50mA', 'FOEKF_qz'))} (tuned {_n(med('bias_-50mA', 'FOEKF'))}); EKF2RC -50 mA {_n(med('bias_-50mA', 'EKF2RC_qz'))} "
      f"(tuned {_n(med('bias_-50mA', 'EKF2RC'))}). EKF2RC with the full textbook setting: "
      f"{_n(med('bias_+50mA', 'EKF2RC_textbook'))} / {_n(med('bias_-50mA', 'EKF2RC_textbook'))} at +50 / -50 mA. Key finding 4 now "
      "says the offset ranking of the Kalman filters is conditional on their noise-free validation tuning. No re-tuning: the tuning followed the declared protocol, and changing it on the "
      "basis of test results is not allowed.")
    w(f"- R1.4 (medians hide failures). Accepted. Every Table 6 cell carries [files > {thr:g} %; per-file maximum] "
      "(tables/tab_robustness.tex: separate table tab:robustness_fail), and all individual failures are listed with the "
      f"method's own baseline. The AEKF2RC z0 -0.20 case is named in key finding 3 (per-file maximum "
      f"{F['z0_minus20']['AEKF2RC']['max']:.2f} % on {_short(F['z0_minus20']['AEKF2RC']['argmax'])}).")
    w(f"- R1.5 (z0 framing). Accepted. The per-file nominal z0 error is listed; slow-forgetting counts are given for EVERY method "
      f"(TFO at -0.20: {pz['TFO']['z0_minus20']['n_slow']} files above {R['settings']['slow_forgetting_s']:.0f} s, maximum "
      f"{pz['TFO']['z0_minus20']['max_finite_s']:.0f} s; EKF2RC {pz['EKF2RC']['z0_minus20']['n_slow']}); the 'bimodal' wording is "
      "dropped, and the EKF2RC outcome is described as z0-dependent final trajectories (lower / higher primary RMSE than nominal on "
      f"{pz['EKF2RC']['z0_plus20']['n_better_than_nominal']} / {pz['EKF2RC']['z0_plus20']['n_worse_than_nominal']} files at +0.20). The forgetting time remains a post-hoc diagnostic.")
    w("- R1.6 / R2 (independence, multiplicity). Accepted. The protocol states that CIs are conditional on the 18 files and ignore "
      f"the temperature clustering; per-temperature paired medians (n = 6) are reported; markers are called unadjusted flags, "
      f"and Holm over the Wilcoxon p-values is reported ({R['holm']['n_holm_005']} of {R['holm']['n_cells']} cells significant).")
    w(f"- R1.7 / R2.1 (slow-forgetting counts transcribed wrongly, ambiguous format). Accepted; counts are now written per method "
      f"and sign: EKF2RC {pz['EKF2RC']['z0_plus20']['n_slow']} ({pz['EKF2RC']['z0_plus20']['n_never']} never) at +0.20 / "
      f"{pz['EKF2RC']['z0_minus20']['n_slow']} ({pz['EKF2RC']['z0_minus20']['n_never']} never) at -0.20; AEKF2RC "
      f"{pz['AEKF2RC']['z0_plus20']['n_slow']} ({pz['AEKF2RC']['z0_plus20']['n_never']}) / {pz['AEKF2RC']['z0_minus20']['n_slow']} "
      f"({pz['AEKF2RC']['z0_minus20']['n_never']}); TFO {pz['TFO']['z0_plus20']['n_slow']} / {pz['TFO']['z0_minus20']['n_slow']} "
      "(always finite).")
    w(f"- R1.8 / R2.9 (CC comparison mixed statistics). Accepted: window mean against window mean (TFO "
      f"{_n(pm['TFO']['+50mA']['obs_mean_median_pct'])} vs CC {_n(pm['CC']['+50mA']['obs_mean_median_pct'])}), last admissible sample "
      f"against last admissible sample (TFO {_n(pm['TFO']['+50mA']['obs_adm_end_median_pct'])} vs CC "
      f"{_n(pm['CC']['+50mA']['obs_adm_end_median_pct'])}); the profile-end CC drift is quoted separately as the formula check.")
    w(f"- R1.9 (CC best without z0/offset errors). Accepted: key finding 2 (baseline CC {_n(med('baseline', 'CC'))} vs TFO "
      f"{_n(med('baseline', 'TFO'))}).")
    w(f"- R2.2 ('mean -0.81'). Accepted: now 'median over files of the per-file mean error' "
      f"({_n(S['baseline']['TFO']['adm_bias_pct']['median'])}), with the mean over files ({_n(S['baseline']['TFO']['adm_bias_pct']['mean'])}).")
    w(f"- R2.3 (TFO not uniquely best at -50 mA). Accepted: TFO and FOO are reported as tied (FOO - TFO "
      f"{_pd(P['bias_-50mA']['FOO']['adm_rmse_pct'], 4)}).")
    w("- R2.4 ('respond identically'). Accepted: replaced by 'practically indistinguishable, statistically detectable, "
      "systematically favouring FOO' with the equivalence margin (key finding 1).")
    w("- R2.5 (mean-selected, median-reported worst case; 16 vs 8). Accepted; see R1.2.")
    w("- R2.6 (pre-freeze test access not disclosed in E2). Accepted: the protocol copies validation_main.json['prior_test_access'] "
      "programmatically.")
    w("- R2.7 (no archive of earlier E2 runs). Partly remediable: the pre-review E2 outputs and code are now archived with a "
      "manifest; the outputs of the analysis before the forgetting-time diagnostic were never archived, which the protocol states; "
      "the only recorded change between the two runs is that diagnostic.")
    w("- R2.8 (literal numbers in the report/table). Accepted: bootstrap size and seed, worker count, seed list identity, "
      "admissible interval, post-convergence time, memory budget, magnitudes and the number of temperature-case files are now "
      "formatted from robustness.json / config.")
    cl = R["clip"]
    w("- R2.10 (SOC clip rate understated). Accepted: the protocol reports the clip rate per method (TFO "
      f"{100 * cl['TFO']['frac_runs_clipped']:.0f} % of runs) and where it acts (clipped samples inside the admissible interval: "
      f"{sum(v['n_runs_clip_in_admissible'] for v in cl.values())} runs in total)"
      + ("; it therefore affects the whole-profile metrics only.\n" if sum(v["n_runs_clip_in_admissible"] for v in cl.values()) == 0
         else "; see the protocol.\n"))


# === MAIN ===
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report-only", action="store_true", help="use the cached per-file runs only")
    ap.add_argument("--compute-only", action="store_true")
    ap.add_argument("--workers", type=int, default=None)
    a = ap.parse_args()
    _, rb, _, _ = cfg()
    workers = min(int(a.workers or rb["max_workers"]), 2)
    t_w0, t_c0 = time.perf_counter(), time.process_time()
    results, run_info = compute(0 if a.report_only else workers) if not a.report_only else load_cached()
    if a.compute_only:
        print(f"[E2] compute wall {time.perf_counter() - t_w0:.1f} s, main process {time.process_time() - t_c0:.1f} s")
        return
    finalize(results, run_info, t_w0, t_c0)


if __name__ == "__main__":
    main()
