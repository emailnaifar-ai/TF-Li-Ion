"""Per-sample cost of every estimator on synthetic data (10 000 samples, h = 1 s).

Writes results/estimator_timing.json.  Clock: ``time.perf_counter`` (wall) over the estimation loop
only, one warm-up run then ``config estimators.timing.repeats`` timed repeats per configuration; the
MINIMUM (least-disturbed run) and the median with the inter-quartile range are reported.
``time.process_time`` is also recorded but has a 15.6 ms tick on Windows (1-4 ticks per 10 000-sample
run), so it is NOT used to rank methods.  Every method, Coulomb counting included, runs a per-sample
Python loop with one OCV evaluation per sample inside the timed region (the Kalman filters'
a-posteriori outputs are reconstructed outside it).  Synthetic plant: TFO model with config
estimators.synthetic_test parameters, DST-like current (experiments.synthetic_dst_current); the timing
does not depend on the data values.  Other analyses may run concurrently on this machine: absolute times
are indicative only; the machine load is not controlled.

Run from the project root:  python scripts/estimator_timing.py
"""
from __future__ import annotations

import json
import platform
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import experiments as E  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402
from tfso.data import load_config  # noqa: E402


def main(n_samples: int = 10000) -> dict:
    cfg = load_config()
    est = cfg["estimators"]
    syn = est["synthetic_test"]
    tcfg = est.get("timing", {})
    repeats, warmup = int(tcfg.get("repeats", 21)), int(tcfg.get("warmup", 1))
    h = 1.0
    p = dict(alpha=syn["alpha"], lam=syn["lam"], R0=syn["R0"], Rp=syn["Rp"], Cp=syn["Cp"], Qn=syn["Qn"], eta=1.0)
    p2 = dict(R0=syn["R0"], R1=0.015, tau1=12.0, R2=0.02, tau2=400.0, Qn=syn["Qn"], eta=1.0)

    def U(z):
        return 3.5 + 0.6 * np.asarray(z, float) + 0.05 * np.sin(2 * np.pi * np.asarray(z, float))

    def dU(z):
        return 0.6 + 0.1 * np.pi * np.cos(2 * np.pi * np.asarray(z, float))

    ocv = O.FastOCV(U, dU, **est["ocv_table"])
    case = E.make_synthetic_case(p, U, dU, N=n_samples, h=h, plant_N_L=3600)
    memories = [float(L) for L in cfg["observer"]["memory_L_s"] if L != "full"] + [None]
    runs = []
    for L in memories:
        runs.append(("TFO", p, dict(l1=0.03, l2=0.03, L_s=L)))
        runs.append(("FOO", dict(p, lam=0.0), dict(l1=0.03, l2=0.03, L_s=L)))
        runs.append(("FOEKF", dict(p, lam=0.0), dict(E.default_hyper("FOEKF", h), L_s=L)))
    runs += [("EKF2RC", p2, E.default_hyper("EKF2RC", h)), ("AEKF2RC", p2, E.default_hyper("AEKF2RC", h)),
             ("CC", p, {})]
    out = []
    for meth, par, hyp in runs:
        for _ in range(warmup):
            O.run_estimator(meth, par, hyp, case.I, case.V, h, 0.7, ocv)
        cpu, wall = [], []
        for _ in range(repeats):
            r = O.run_estimator(meth, par, hyp, case.I, case.V, h, 0.7, ocv)
            cpu.append(r["cpu_process_s"])
            wall.append(r["wall_s"])
        w = np.asarray(wall)
        fl = r["flags"]
        NL = fl.get("N_L_used") if meth in ("TFO", "FOO", "FOEKF") else None
        full = bool(fl.get("full_memory", False))
        rec = dict(method=meth, L_s=hyp.get("L_s"), N_L=NL, full_memory=full, n_samples=n_samples, repeats=repeats,
                   warmup=warmup, wall_s_min=float(w.min()), wall_s_median=float(np.median(w)),
                   wall_s_q25=float(np.quantile(w, 0.25)), wall_s_q75=float(np.quantile(w, 0.75)),
                   wall_per_sample_us_min=float(w.min()) / n_samples * 1e6,
                   wall_per_sample_us_median=float(np.median(w)) / n_samples * 1e6,
                   cpu_process_s_median=float(np.median(cpu)), cpu_process_s_values=[float(c) for c in cpu],
                   n_history_samples=r["n_history_samples"], bytes_state=r["bytes_state"],
                   ocv_evals_per_sample_in_loop=(0 if meth == "CC" else 1))
        if meth in ("TFO", "FOO") and not full:
            rec["cost_per_sample"] = TM.cost_per_sample(NL)
        out.append(rec)
        print(f"{meth:8s} N_L={str(NL) if not full else 'full':6s} wall min {rec['wall_s_min']:.4f} s  "
              f"median {rec['wall_s_median']:.4f} s  IQR [{rec['wall_s_q25']:.4f}, {rec['wall_s_q75']:.4f}]  "
              f"bytes {rec['bytes_state']}", flush=True)
    res = dict(description=__doc__.strip().splitlines()[0], generated_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               machine=dict(platform=platform.platform(), processor=platform.processor(), python=platform.python_version()),
               clock_note=("wall = time.perf_counter over the estimation loop, min / median / IQR over repeats after "
                           "warm-up (used for ranking, indicative only: machine load not controlled); cpu = "
                           "time.process_time, 15.6 ms resolution on Windows, NOT used for ranking"),
               bytes_rule=est.get("bytes_rule"), h_s=h, n_samples=n_samples, repeats=repeats, warmup=warmup,
               records=out)
    path = ROOT / "results" / "estimator_timing.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1)
    print("wrote", path)
    return res


if __name__ == "__main__":
    main()
