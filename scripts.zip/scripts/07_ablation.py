"""E3: ablation and sensitivity of the tempered fractional SOC observer (TFO) on the 18 test files.

Settings: config.yaml `ablation` (declared before the first run), `design_tuning`, `estimators`.  Everything that is
not being ablated is taken from results/frozen_config.json (never changed here).

Stage 1 (identification + validation files only; no test file is loaded):
  * re-identification at the frozen memory (L = 400 s) of TFO models with lambda FIXED at the identified value
    (identification_refined.json, full-memory causal_full fit) and at the relaxation-derived phenomenological median
    (relaxation_phenomenological.json), with the 04c TFO_grid protocol;
  * equal-budget gain tuning (design_tuning.tuning protocol, validation files) of every NEW model variant (identified /
    relaxation / at-memory lambda, RCL, TFGD and CMA-ES/TRF optimiser parameter sets), of the full-memory points of the
    memory curve and of the 'tuned_unconstrained' gain variant; certificates of every variant;
  * freeze: results/ablation.json['freeze'] (UTC time stamp) before stage 2.
Stage 2 (test files, experiments.load_case(..., final_evaluation=True)): every variant x 3 initial-SOC scenarios.
Stage 3: aggregation (whole-profile and admissible windows), paired differences vs the frozen TFO, figures
(fig_rmse_memory, fig_sensitivity, fig_params_temperature), tables/tab_ablation.tex, reports/ablation_findings.md.

Usage: python scripts/07_ablation.py [--report-only]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402


def _load(name, fname):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / fname)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


M5 = _load("design05", "05_design_tune.py")      # evaluate / certificate helpers of the freeze (reused unchanged)

RES = ROOT / "results"
OUT = RES / "ablation.json"
CACHE = RES / "ablation_runs"
TEMPS = (0, 25, 45)
TASK_VERSION = "E3-2026-09-27-b"        # b: review response (stats, extra variants, cache keys; see the report)
H1 = 1.0


def cfg():
    c = D.load_config()
    return c, dict(c["ablation"]), dict(c["design_tuning"]), dict(c["estimators"])


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def code_hash() -> str:
    c, ab, dt, est = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([ab, dt, est, c["identification_study"]["bounds"], c["memory_identification"], c["splits"],
                         c["dataset"]], sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("scripts/05_design_tune.py", "src/tfso/observer.py", "src/tfso/tempered.py",
              "src/tfso/experiments.py", "src/tfso/metrics.py", "src/tfso/model.py", "src/tfso/identify.py",
              "results/frozen_config.json", "results/identification_memory.json", "results/tuning.json",
              "results/identification_refined.json", "results/capacity.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def jsonable(o):
    return M5.jsonable(o)


def jdump(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(jsonable(obj), fh, indent=1)
    os.replace(tmp, path)


def spec_hash(obj) -> str:
    return hashlib.sha256(json.dumps(jsonable(obj), sort_keys=True, default=str).encode()).hexdigest()[:16]


def cache(name, fn=None, args=()):
    """Cached task result (results/ablation_runs/<name>), keyed by the code hash (config sections incl. splits and
    dataset, src/05 files, upstream results) AND a hash of the task arguments (variant/job specification), so a changed
    variant set or gain rule can never silently reuse old rows."""
    p = CACHE / name
    ch = code_hash() + "|" + spec_hash(list(args))
    if p.exists():
        with open(p, "r", encoding="utf-8") as fh:
            o = json.load(fh)
        if o.get("_code_hash") == ch:
            return o
    if fn is None:
        return None
    o = fn(*args)
    o = jsonable(o)
    o["_code_hash"] = ch
    jdump(o, p)
    return o


def num(v):
    """JSON number back to float ('inf' strings from jsonable)."""
    if isinstance(v, str):
        return float(v)
    return float("nan") if v is None else float(v)


# ---------------------------------------------------------------------------------------------------------------
# Parameter sets
# ---------------------------------------------------------------------------------------------------------------
def with_q(p, T):
    q = dict(p)
    q.update(Qn=E.q_id(T), eta=float(D.load_config()["dataset"]["coulombic_efficiency"]))
    return {k: float(v) for k, v in q.items()}


def frozen():
    fz = load_json("frozen_config.json")
    if not str(fz.get("status", "")).startswith("FROZEN"):
        raise RuntimeError("results/frozen_config.json is not FROZEN")
    return fz


def memory_rows(T):
    return load_json("identification_memory.json")["per_T"][str(T)]["rows"]


def mem_row(T, config, L, lam=None):
    for r in memory_rows(T):
        if r["config"] != config or r["L"] != L:
            continue
        if lam is not None and abs(float(r["lam_fixed"]) - lam) > 1e-12 * max(lam, 1e-300):
            continue
        return r
    raise KeyError((T, config, L, lam))


def lambda_identified(T):
    return float(load_json("identification_refined.json")["chosen_parameter_sets"][str(T)]["TFO"]["lam"])


def lambda_relaxation(T):
    s = load_json("relaxation_phenomenological.json")["summary"]["60"]
    return float(s[f"T{T}"]["tpl_lambda_s_inv"]["median"]), dict(s["all_primary"]["tpl_lambda_s_inv"]), \
        dict(s[f"T{T}"]["tpl_lambda_s_inv"])


# ---------------------------------------------------------------------------------------------------------------
# Stage 1a: re-identification at L = 400 s with lambda fixed (04c TFO_grid protocol)
# ---------------------------------------------------------------------------------------------------------------
def ident_task(T, lam, tag):
    from tfso import identify as ID
    from tfso import model as MD
    C4 = _load("memid04c", "04c_memory_identification.py")
    B4 = C4.B4
    c = D.load_config()
    s, mc, rc = dict(c["identification_study"]), dict(c["memory_identification"]), dict(c["identification_refined"])
    t0w, t0c = time.perf_counter(), time.process_time()
    L = int(frozen()["methods"]["TFO"]["structure"]["L"])
    R = load_json("identification_refined.json")
    if R["decision"]["chosen"] != "causal_full":
        raise RuntimeError("E3 assumes the causal_full parameter set (whole-profile objective, R0 free)")
    ref = R["chosen_parameter_sets"][str(T)]
    lid = B4.I4.id_file(T)
    vid = [l for l in c["splits"]["validation_dynamic"] if D.CATALOG[l]["temperature_C"] == T][0]
    Fi, Fv = B4.load_file(lid), B4.load_file(vid)
    Hi, Hv = Fi["H"], Fv["H"]
    I_max = float(max(np.max(np.abs(Hi.I[Hi.prof])), np.max(np.abs(Hv.I[Hv.prof]))))
    N_L = int(math.ceil(L / Hi.h))
    gi = MD.FFTGrid(Hi.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    gv = MD.FFTGrid(Hv.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    prob = ID.ProblemNL("TFO", Hi, Fi["ocv"], s["bounds"], fixed={"lam": float(lam)},
                        lam_scale=float(s["lambda_asinh_scale"]), grid=gi, timing="causal", mask=None, N_L=N_L)
    seed = int(mc["seeds_lhs"]) + 100 * TEMPS.index(T) + 10 * C4.CONFIGS.index("TFO_grid")
    starts = list(ID.lhs_starts(prob.p, int(s["multistart"]), seed))
    starts.append(prob.to_u(dict(ref["TFO"], lam=float(lam))))
    runs = []
    for u0 in starts:
        r = ID.run_trf(prob, u0, max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]))
        runs.append(dict(rmse_mV=r["rmse_mV"], theta=r["theta"], converged=r["converged"], nfev=r["nfev"]))
    b = min(runs, key=lambda q: q["rmse_mV"])
    th = {k: float(b["theta"][k]) for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")}
    p = MD.TFOParams(**th)
    zmin = float(s["knee_window"]["z_min"])
    adm = tuple(float(x) for x in rc["admissible_soc_interval"])
    ri = MD.simulate(p, Hi, Fi["ocv"], N_L=N_L, grid=gi, window=Hi.prof, timing="causal")["Vt"] - Hi.V[Hi.prof]
    rv = MD.simulate(p, Hv, Fv["ocv"], N_L=N_L, grid=gv, window=Hv.prof, timing="causal")["Vt"] - Hv.V[Hv.prof]
    at = []
    for k in ID.FAMILY_FREE["TFO"]:
        if k == "lam":
            continue
        u = ID.unit_position(k, th[k], s["bounds"], float(s["lambda_asinh_scale"]))
        if u <= 1e-6 or u >= 1 - 1e-6:
            at.append(k)
    return dict(T=T, lam_fixed=float(lam), tag=tag, L=L, N_L=N_L, theta=th, rmse_objective_mV=b["rmse_mV"],
                converged=b["converged"], start_rmse_mV=[q["rmse_mV"] for q in runs],
                warm_start_best=bool(runs[-1] is b), n_within_0p01mV=int(sum(q["rmse_mV"] <= b["rmse_mV"] + 0.01 for q in runs)),
                identification=C4.rmse3(ri, Hi.z[Hi.prof], Fi["soc_ref"], zmin, adm),
                validation=C4.rmse3(rv, Hv.z[Hv.prof], Fv["soc_ref"], zmin, adm), at_bound=at,
                bounds=C4.bounds_block("TFO", th, Hi, Fi["ocv"], L, N_L, I_max),
                files=dict(identification=lid, validation=vid, verified=bool(Fi["verified"] and Fv["verified"])),
                seed=seed, wall_s=time.perf_counter() - t0w, process_s=time.process_time() - t0c)


def ident_mem_task(T, lam, L, bset):
    """One identification_memory.json row (04c protocol: FO_trunc for lambda = 0, TFO_grid(lambda) otherwise) at
    (T, lambda, L), identification + validation files only, EVERY start kept.  bset 'original' = identification_study
    bounds (same seed and starts as 04c: reproduces the stored row); 'widened' = review_response.bounds_check.widened,
    with the original row's optimum as one extra start."""
    from tfso import identify as ID
    from tfso import model as MD
    C4 = _load("memid04c", "04c_memory_identification.py")
    B4 = C4.B4
    c = D.load_config()
    s, mc, rc = dict(c["identification_study"]), dict(c["memory_identification"]), dict(c["identification_refined"])
    t0w, t0c = time.perf_counter(), time.process_time()
    R = load_json("identification_refined.json")
    if R["decision"]["chosen"] != "causal_full":
        raise RuntimeError("E3 assumes the causal_full parameter set (whole-profile objective, R0 free)")
    ref = R["chosen_parameter_sets"][str(T)]
    B = {k: list(v) for k, v in s["bounds"].items()}
    if bset == "widened":
        B.update({k: [float(x) for x in v] for k, v in c["ablation"]["review_response"]["bounds_check"]["widened"].items()})
    lid = B4.I4.id_file(T)
    vid = [l for l in c["splits"]["validation_dynamic"] if D.CATALOG[l]["temperature_C"] == T][0]
    Fi, Fv = B4.load_file(lid), B4.load_file(vid)
    Hi, Hv = Fi["H"], Fv["H"]
    I_max = float(max(np.max(np.abs(Hi.I[Hi.prof])), np.max(np.abs(Hv.I[Hv.prof]))))
    N_L = C4.N_of(L, Hi.h)
    ls = float(s["lambda_asinh_scale"])
    gi = MD.FFTGrid(Hi.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    gv = MD.FFTGrid(Hv.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    cname, fam = ("FO_trunc", "FO") if lam == 0 else ("TFO_grid", "TFO")
    fixed = {} if lam == 0 else {"lam": float(lam)}
    prob = ID.ProblemNL(fam, Hi, Fi["ocv"], B, fixed=fixed, lam_scale=ls, grid=gi, timing=C4.TIMING, mask=None, N_L=N_L)
    seed = int(mc["seeds_lhs"]) + 100 * TEMPS.index(T) + 10 * C4.CONFIGS.index(cname)
    starts = list(ID.lhs_starts(prob.p, int(s["multistart"]), seed))
    warm = dict(ref["FO"] if fam == "FO" else ref["TFO"])
    if lam:
        warm["lam"] = float(lam)
    starts.append(prob.to_u(warm))
    orig = mem_row(T, cname, L, None if lam == 0 else float(lam))
    if bset == "widened":
        starts.append(prob.to_u(dict(orig["theta"])))
    runs = []
    for u0 in starts:
        r = ID.run_trf(prob, u0, max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]))
        runs.append(dict(rmse_mV=r["rmse_mV"], theta={k: float(v) for k, v in r["theta"].items()},
                         converged=r["converged"], nfev=r["nfev"]))
    b = min(runs, key=lambda q: q["rmse_mV"])
    zmin = float(s["knee_window"]["z_min"])
    adm = tuple(float(x) for x in rc["admissible_soc_interval"])

    def evalr(th):
        p = MD.TFOParams(**{k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})
        rv = MD.simulate(p, Hv, Fv["ocv"], N_L=N_L, grid=gv, window=Hv.prof, timing=C4.TIMING)["Vt"] - Hv.V[Hv.prof]
        return C4.rmse3(rv, Hv.z[Hv.prof], Fv["soc_ref"], zmin, adm)

    free = [k for k in ID.FAMILY_FREE[fam] if not (k == "lam" and lam)]

    def atb(th):
        return [k for k in free if not (0.0 + 1e-6 < ID.unit_position(k, th[k], B, ls) < 1.0 - 1e-6)]

    for q in runs:
        q["at_bound"] = atb(q["theta"])
    return dict(T=T, lam=float(lam), L=L, N_L=N_L, bset=bset, config=cname, bounds_used={k: B[k] for k in ("alpha", "Rp")},
                theta=dict(b["theta"]), rmse_objective_mV=b["rmse_mV"], at_bound=atb(b["theta"]), runs=runs,
                validation=evalr(b["theta"]), bounds=C4.bounds_block(fam, b["theta"], Hi, Fi["ocv"], L, N_L, I_max),
                original=dict(rmse_objective_mV=orig["rmse_objective_mV"], theta=orig["theta"], at_bound=orig["at_bound"]),
                files=dict(identification=lid, validation=vid, verified=bool(Fi["verified"] and Fv["verified"])),
                seed=seed, wall_s=time.perf_counter() - t0w, process_s=time.process_time() - t0c)


def _identmem_cached(args):
    T, lam, L, bset = args
    return cache(f"identmem_{bset}_{lam:g}_{L}_{T}.json", ident_mem_task, (T, lam, L, bset))


# ---------------------------------------------------------------------------------------------------------------
# Certificates (admissible-interval slope bounds of the variant's own aligned OCV; design_tuning.certificate)
# ---------------------------------------------------------------------------------------------------------------
def kappas_qfree(T, p):
    """Slope bounds on the admissible interval mapped WITHOUT the test-derived Q_ref (i.e. with Q_id only: the
    observer interval is the reference interval [0.10, 0.95] itself) -- review check of the upstream mapping."""
    lo, hi = (float(x) for x in cfg()[2]["admissible_soc_interval"])
    k1, k2 = O.slope_bounds_fast(M5.fast_ocv(T, p), lo, hi, n=int(cfg()[2]["kappa_grid_n"]))
    return float(k1), float(k2)


def certificate(T, p, lam, L_s, l1, l2, h=H1, Bp=None):
    alpha, ap = float(p["alpha"]), M5.ap_of(p)
    N_L = None if L_s is None else int(math.ceil(float(L_s) / h - 1e-9))
    kap = M5.kappas(T, p)
    k1, k2 = kap["kappa1"], kap["kappa2"]
    eps = float(cfg()[1]["eps_z"])
    mem = dict(memory_ez_bound=None, memory_certified=None, memory_note="full memory: no truncation" if N_L is None else
               "B_p not available for this variant")
    # lambda below identification_study.lambda_zero_report is treated as 0 (as in 04c); the exact tail sum needs
    # ~40/lambda terms and is not evaluated for 0 < lambda < 1e-5 (04c EXACT_MIN_LAM)
    lam_b = lam if lam >= float(cfg()[0]["identification_study"]["lambda_zero_report"]) else 0.0
    if N_L is not None and Bp is not None and 0.0 < lam_b < 1.0e-5:
        mem["memory_note"] = "0 < lambda < 1e-5: exact tail sum not evaluated"
    elif N_L is not None and Bp is not None and 0.0 < alpha < 1.0:
        try:
            tb = M5.truncation_soc_bounds(alpha, lam_b, ap, k1, k2, l2, h, N_L, float(Bp))
            mem = dict(memory_ez_bound=float(tb["ez_bound_exact"]), memory_certified=bool(tb["ez_bound_exact"] <= eps),
                       memory_note=f"exact discrete truncation SOC bound vs eps_z = {eps:g}")
        except Exception as exc:  # pragma: no cover
            mem["memory_note"] = f"bound failed: {exc}"
    qk1, qk2 = kappas_qfree(T, p)
    qd = M5.dc_explicit(alpha, lam, ap, qk1, qk2, l1, l2, 0.0, h, N_L)
    try:
        qlp = bool(TM.certify_gains_discrete(alpha, lam, ap, qk1, qk2, l1, l2, 0.0, h, N_L).lp)
    except Exception:  # pragma: no cover
        qlp = False
    qfree = dict(kappa1=qk1, kappa2=qk2, certified=bool(qd["ok"] and qlp))
    cs = M5.certified_set(alpha, lam, ap, k1, k2, h, N_L)
    dce = M5.dc_explicit(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
    try:
        c0 = TM.certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
        lp, lpm = bool(c0.lp), float(c0.lp_margin)
    except Exception as exc:  # pragma: no cover
        lp, lpm = False, float("nan")
    ss = None
    if dce["ok"]:
        try:
            ss = TM.sigma_star(alpha, lam, ap, k1, k2, l1, l2, h=h, N_L=N_L)
        except Exception:
            ss = None
    return dict(T=T, lam=lam, L_s=L_s, N_L=N_L, h=h, l1=float(l1), l2=float(l2), kappa1=k1, kappa2=k2,
                kappa2_clip=kap["kappa2_clip"], z_interval_obs=kap["z_interval_obs"], l1_max=cs["l1_max"],
                l2_sup=cs["l2_sup"], mu_hL0=cs["mu_hL0"], dc_margin=dce["margin"], positivity=dce["positivity"],
                h_l1_kappa2=h * l1 * k2, lp=lp, lp_margin=lpm, certified=bool(dce["ok"] and lp), sigma_star=ss,
                qfree=qfree, **mem)


def design_gains(T, p, lam, L_s, h=H1):
    """Default LMI design gains (design_task settings of scripts/05_design_tune.py)."""
    _, _, dt, est = cfg()
    N_L = None if L_s is None else int(math.ceil(float(L_s) / h - 1e-9))
    kap = M5.kappas(T, p)
    dflt = dict(est["defaults"]["TFO"])
    g = O.design_observer_gains(p, M5.fast_ocv(T, p), h, N_L, z_interval=tuple(kap["z_interval_obs"]),
                                lam_override=lam, l1max=dflt.get("l1max"), l2max=float(dflt["l2max"]),
                                margin=float(dflt["margin"]), tau_z_min=dflt.get("tau_z_min"), l2min=float(dflt["l2min"]))
    return None if g["l1"] is None else (float(g["l1"]), float(g["l2"]))


# ---------------------------------------------------------------------------------------------------------------
# Stage 1b: equal-budget tuning (design_tuning.tuning protocol of scripts/05_design_tune.py, generalised to explicit
# parameter sets and boxes; validation file of each temperature)
# ---------------------------------------------------------------------------------------------------------------
def tune_general(task):
    from scipy.stats import qmc
    _, _, dt, _ = cfg()
    tb = dt["tuning"]
    t0w, t0c = time.perf_counter(), time.process_time()
    method, T, p = task["method"], int(task["T"]), task["params"]
    sp = dict(dims=[tuple(d) for d in task["dims"]], params=p,
              fixed=dict(L_s=task["L_s"], z_interval=task["z_interval"]))
    d = len(sp["dims"])
    seed = int(tb["seed"]) + 1000 * TEMPS.index(T) + 10 * M5.METHOD_INDEX[task["seed_method"]]
    sob = qmc.Sobol(d, scramble=True, seed=seed).random_base2(6)[: int(tb["n_sobol"])]
    X = [M5.default_unit(method, sp, task["default_gains"])] + [list(map(float, x)) for x in sob]
    trace = []

    def run(x, stage):
        hy, v = M5.to_hyper(method, sp, x)
        ev = M5.evaluate(method, p, hy, T)
        trace.append(dict(stage=stage, x=[float(xi) for xi in x], values=v, objective=ev["objective"]))
        return ev["objective"]

    for i, x in enumerate(X):
        run(x, "default" if i == 0 else "sobol")
    fs = [tr["objective"] for tr in trace]
    ib = int(np.argmin(fs))
    xb, fb = list(trace[ib]["x"]), fs[ib]
    rng = np.random.default_rng(seed + 7)
    sig = float(tb["local_sigma0"])
    for _ in range(int(tb["n_local"])):
        xn = np.clip(np.asarray(xb) + sig * rng.standard_normal(d), 0.0, 1.0)
        fn = run(list(xn), "local")
        if fn < fb:
            xb, fb, sig = list(map(float, xn)), fn, sig * 1.5
        else:
            sig *= 0.7
    assert len(trace) == int(tb["budget_evals"])
    ib = int(np.argmin([tr["objective"] for tr in trace]))
    best = trace[ib]
    tol = float(tb["at_bound_unit_tol"])
    at_bound = [n for (n, _, _), xi in zip(sp["dims"], best["x"]) if xi <= tol or xi >= 1.0 - tol]
    return dict(key=task["key"], T=T, method=method, seed=seed, dims=task["dims"], n_evals=len(trace),
                best_stage=best["stage"], best_objective=best["objective"], best_values=best["values"],
                default_objective=trace[0]["objective"], default_gains=task["default_gains"], at_bound=at_bound,
                objectives=[tr["objective"] for tr in trace], wall_s=time.perf_counter() - t0w,
                process_s=time.process_time() - t0c)


def _tune_cached(task):
    return cache(f"tune_{task['key']}_{task['T']}.json", tune_general, (task,))


def _ident_cached(args):
    T, lam, tag = args
    return cache(f"ident_{tag}_{T}.json", ident_task, (T, lam, tag))


def run_pool(fn, tasks, workers):
    if workers <= 1 or len(tasks) <= 1:
        return [fn(t) for t in tasks]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, tasks, chunksize=1))


def cert_box(T, p, lam, L_s):
    kap = M5.kappas(T, p)
    N_L = None if L_s is None else int(math.ceil(float(L_s) / H1 - 1e-9))
    cs = M5.certified_set(float(p["alpha"]), lam, M5.ap_of(p), kap["kappa1"], kap["kappa2"], H1, N_L)
    dims = [["l1", math.log10(1e-5), math.log10(cs["l1_max"])], ["l2", math.log10(1e-4), math.log10(0.99 * cs["l2_sup"])]]
    return dims, kap


def tune_spec(key, T, p, lam, L_s, method="TFO", seed_method="TFO", dims=None, default_gains=None):
    d0, kap = cert_box(T, p, lam, L_s)
    dg = default_gains if default_gains is not None else design_gains(T, p, lam, L_s)
    if dg is None:
        dg = (10 ** (0.5 * (d0[0][1] + d0[0][2])), 10 ** (0.5 * (d0[1][1] + d0[1][2])))
    return dict(key=key, T=T, method=method, seed_method=seed_method, params=p, L_s=L_s,
                z_interval=kap["z_interval_obs"], dims=dims if dims is not None else d0, default_gains=list(dg))


# ---------------------------------------------------------------------------------------------------------------
# Stage 1: variants, tuning, certificates, freeze
# ---------------------------------------------------------------------------------------------------------------
def variant(group, label, method, T, p, lam, L_s, l1, l2, source, h=H1, T_params=None, extra=None, cert=True, Bp=None):
    Tp = T if T_params is None else T_params
    zi = M5.kappas(Tp, p)["z_interval_obs"]
    out = dict(group=group, label=label, method=method, T=T, T_params=Tp, params=p, lam=float(lam),
               hyper=dict(l1=float(l1), l2=float(l2), L_s=None if L_s is None else float(L_s), z_interval=zi),
               h=float(h), source=source, extra=extra or {})
    if cert:
        out["certificate"] = certificate(Tp, p, lam, L_s, float(l1), float(l2), h=h, Bp=Bp)
    return out


def stage1(workers):
    c, ab, dt, est = cfg()
    fz = frozen()
    t0w, t0c = time.perf_counter(), time.process_time()
    L0 = float(fz["methods"]["TFO"]["structure"]["L"])
    lam0 = float(fz["methods"]["TFO"]["structure"]["lam"])
    vfiles = {}
    for T in TEMPS:
        cs = M5.val_case(T)
        vfiles[str(T)] = dict(file=cs.logical_id, split=cs.split, verified=bool(cs.meta["verify_passed"]), n=int(cs.t.size))
    # ---- 1a re-identification with lambda fixed
    lam_rel = {T: lambda_relaxation(T) for T in TEMPS}
    itasks = [(T, lambda_identified(T), "identified") for T in TEMPS] + [(T, lam_rel[T][0], "relaxation") for T in TEMPS]
    ident = {(r["tag"], r["T"]): r for r in run_pool(_ident_cached, itasks, workers)}
    # ---- parameter sets of the new model variants
    R = load_json("identification_refined.json")
    IJ = load_json("identification.json")
    newp = {}
    eps = float(ab["rcl_alpha_eps"])
    for T in TEMPS:
        newp[("identified", T)] = (with_q(ident[("identified", T)]["theta"], T), "re-identified at L = 400 s, lambda fixed at identification_refined TFO lambda-hat")
        newp[("relaxation", T)] = (with_q(ident[("relaxation", T)]["theta"], T), "re-identified at L = 400 s, lambda fixed at the relaxation TPL median")
        newp[("identified_at_memory", T)] = (with_q(mem_row(T, "TFO_trunc", int(L0))["theta"], T), "identification_memory TFO_trunc at L = 400 s (lambda free)")
        rp = dict(R["chosen_parameter_sets"][str(T)]["RCL"])
        rp["alpha"] = 1.0 - eps
        newp[("rcl", T)] = (with_q(rp, T), "identification_refined chosen RCL (alpha = 1 -> 1 - eps)")
        runs = IJ["per_T"][str(T)]["TFO_optimizers"]["tfgd"]["runs"]
        rb = min(runs, key=lambda q: q["rmse_mV"])
        newp[("opt_tfgd", T)] = (with_q(rb["theta"], T), f"identification.json TFGD best run ({rb['rmse_mV']:.3f} mV)")
        ft = IJ["per_T"][str(T)]["fits"]["TFO"]
        newp[("opt_trf", T)] = (with_q(ft["theta"], T), f"identification.json fits.TFO ({ft['optimizer']}, {ft['rmse_mV']:.3f} mV)")
    # ---- tuning tasks
    tasks = []
    for (key, T), (p, _) in newp.items():
        tasks.append(tune_spec(key, T, p, float(p["lam"]), L0))
    lamg = [float(v) for v in dt["lambda_grid"]]
    for T in TEMPS:
        for lam in lamg:
            r = mem_row(T, "FO_trunc" if lam == 0 else "TFO_grid", "full", None if lam == 0 else lam)
            p = with_q(r["theta"], T)
            m = "FOO" if lam == 0 else "TFO"
            tasks.append(tune_spec(f"curve_{lam:g}_full", T, p, lam, None, method=m, seed_method=m))
    gd = load_json("gain_design.json")
    dmap = {(d["T"], float(d["lam"]), d["L"]): d for d in gd["design"]}
    gab = ab["gain_variants"]
    for T in TEMPS:
        pf = with_q(fz["methods"]["TFO"]["per_T"][str(T)]["params"], T)
        kap = M5.kappas(T, pf)
        dims = [["l1", math.log10(1e-5), math.log10(float(gab["unconstrained_l1_factor"]) / (H1 * kap["kappa2"]))],
                ["l2", math.log10(1e-4), math.log10(float(gab["unconstrained_l2_max"]))]]
        dg = dmap[(T, lam0, int(L0))]["design"]
        tasks.append(tune_spec("gain_unconstrained", T, pf, lam0, L0, dims=dims, default_gains=(dg["l1"], dg["l2"])))
    # ---- review response: 04c re-identification with a widened box (bounds check) and with the original box (all
    # starts kept: near-optimal restarts); identification + validation files only
    rr = ab["review_response"]
    bc, rst = rr["bounds_check"], rr["restarts"]

    def Lk(x):
        return x if x == "full" else int(x)

    mtasks = [(T, float(l), Lk(L), "widened") for T in TEMPS for l in bc["lambda"] for L in bc["L_s"]] + \
             [(T, float(l), Lk(L), "original") for T in TEMPS for l in rst["lambda"] for L in rst["L_s"]]
    t1 = time.perf_counter()
    identmem = {(r["bset"], int(r["T"]), float(r["lam"]), r["L"]): r for r in run_pool(_identmem_cached, mtasks, workers)}
    identmem_wall = time.perf_counter() - t1
    for (bs, T, lam, L), r in sorted(identmem.items(), key=str):
        if bs == "widened":
            m = "FOO" if lam == 0 else "TFO"
            tasks.append(tune_spec(f"wb_{lam:g}_{L}", T, with_q(r["theta"], T), lam, None if L == "full" else float(L),
                                   method=m, seed_method=m))
    t1 = time.perf_counter()
    tuned = {(r["key"], r["T"]): r for r in run_pool(_tune_cached, tasks, workers)}
    tune_wall = time.perf_counter() - t1
    # ---- variants
    V = {}
    tu = load_json("tuning.json")
    gmap = {(g["T"], float(g["lam"]), g["L"]): g for g in tu["grid"]}

    def add(key, T, v):
        V.setdefault(key, {})[str(T)] = v

    pcm = {(q["T"], float(q["lam"]), q["L"]): q for q in gd["post_certificates"]}
    bp_new = {("identified", T): ident[("identified", T)]["bounds"]["B_p_V"] for T in TEMPS}
    bp_new.update({("relaxation", T): ident[("relaxation", T)]["bounds"]["B_p_V"] for T in TEMPS})
    bp_new.update({("identified_at_memory", T): mem_row(T, "TFO_trunc", int(L0))["bounds"]["B_p_V"] for T in TEMPS})
    for T in TEMPS:
        f = fz["methods"]["TFO"]["per_T"][str(T)]
        pf, hf = with_q(f["params"], T), f["hyper"]
        l1f, l2f = float(hf["l1"]), float(hf["l2"])
        bpf = float(pcm[(T, lam0, int(L0))]["B_p_V"])
        add("frozen_TFO", T, variant("reference", "frozen TFO (lambda 1e-4, L 400 s)", "TFO", T, pf, lam0, L0, l1f, l2f,
                                     f["parameter_set"], Bp=bpf))
        g0 = fz["methods"]["FOO"]["per_T"][str(T)]
        add("lambda_zero", T, variant("lambda", "lambda = 0 (FO-trunc, frozen FOO)", "FOO", T, with_q(g0["params"], T), 0.0, L0,
                                      g0["hyper"]["l1"], g0["hyper"]["l2"], g0["parameter_set"],
                                      Bp=mem_row(T, "FO_trunc", int(L0))["bounds"]["B_p_V"]))
        for key, lab in (("identified", "lambda identified (full memory)"), ("relaxation", "lambda from relaxation (TPL median)"),
                         ("identified_at_memory", "lambda identified at L = 400 s"), ("rcl", "RCL (alpha = 1)"),
                         ("opt_tfgd", "parameters: TFGD best run"), ("opt_trf", "parameters: CMA-ES/TRF optimum")):
            p, src = newp[(key, T)]
            tr = tuned[(key, T)]
            grp = "lambda" if key in ("identified", "relaxation", "identified_at_memory") else (
                "structure" if key == "rcl" else "optimiser")
            add(key if grp != "lambda" else f"lambda_{key}", T, variant(grp, lab, "TFO", T, p, float(p["lam"]), L0,
                tr["best_values"]["l1"], tr["best_values"]["l2"], src, Bp=bp_new.get((key, T))))
        ab_m = fz["ablation_memory_TFO"][str(T)]
        for key, Ls, lab in (("memory_cert", ab_m["L_cert_s"], "certified memory L_cert"), ("memory_short", ab_m["L_short_s"], "L_short = L_cert/10 (memory bound not certified)"),
                             ("memory_full", None, "full memory")):
            add(key, T, variant("memory", lab, "TFO", T, pf, lam0, Ls, l1f, l2f, "frozen TFO; memory changed", Bp=bpf))
        dg = dmap[(T, lam0, int(L0))]["design"]
        cf = certificate(T, pf, lam0, L0, l1f, l2f)
        add("gain_lmi_design", T, variant("gains", "LMI design gains (untuned)", "TFO", T, pf, lam0, L0, dg["l1"], dg["l2"], "gain_design.json design", Bp=bpf))
        add("gain_l2_zero", T, variant("gains", "l2 = 0", "TFO", T, pf, lam0, L0, l1f, 0.0, "frozen l1", Bp=bpf))
        add("gain_l2_over", T, variant("gains", f"l2 = {gab['l2_over_factor']:g} l2_sup (uncertified)", "TFO", T, pf, lam0, L0, l1f,
                                       float(gab["l2_over_factor"]) * cf["l2_sup"], "frozen l1", Bp=bpf))
        add("gain_l1_positivity", T, variant("gains", f"l1 = {gab['l1_pos_factor']:g}/(h kappa2) (uncertified)", "TFO", T, pf, lam0, L0,
                                             float(gab["l1_pos_factor"]) / (H1 * cf["kappa2"]), l2f, "frozen l2", Bp=bpf))
        for fct in rr["l1_bandwidth_factors"]:
            add(f"gain_l1_f{float(fct):g}", T, variant("gains", f"l1 = {float(fct):g}/(h kappa2) (certified control)", "TFO", T, pf,
                                                       lam0, L0, float(fct) / (H1 * cf["kappa2"]), l2f, "frozen l2", Bp=bpf))
        tr = tuned[("gain_unconstrained", T)]
        add("gain_unconstrained", T, variant("gains", "tuned without certificate", "TFO", T, pf, lam0, L0, tr["best_values"]["l1"],
                                             tr["best_values"]["l2"], "equal-budget tuning, unconstrained box", Bp=bpf))
        for lam in lamg:
            m = "FOO" if lam == 0 else "TFO"
            for L in [int(x) for x in dt["L_grid_s"]]:
                r = mem_row(T, "FO_trunc" if lam == 0 else "TFO_grid", L, None if lam == 0 else lam)
                g = gmap[(T, lam, L)]
                add(f"curve_{lam:g}_{L}", T, variant("curve", f"lambda {lam:g}, L {L}", m, T, with_q(r["theta"], T), lam, L,
                                                     g["best_values"]["l1"], g["best_values"]["l2"], g["row"],
                                                     Bp=r["bounds"]["B_p_V"]))
            r = mem_row(T, "FO_trunc" if lam == 0 else "TFO_grid", "full", None if lam == 0 else lam)
            tr = tuned[(f"curve_{lam:g}_full", T)]
            add(f"curve_{lam:g}_full", T, variant("curve", f"lambda {lam:g}, full", m, T, with_q(r["theta"], T), lam, None,
                                                  tr["best_values"]["l1"], tr["best_values"]["l2"], "identification_memory full row"))
        sens = ab["sensitivity"]
        for dlt in sens["alpha_delta"]:
            pa = dict(pf)
            pa["alpha"] = max(float(sens["alpha_min"]), pf["alpha"] + float(dlt))
            add(f"alpha_{dlt:+g}", T, variant("sens_alpha", f"alpha {dlt:+g}", "TFO", T, pa, lam0, L0, l1f, l2f,
                                              f"frozen TFO, alpha {pf['alpha']:.3f} -> {pa['alpha']:.3f}"))
        for hh in [float(x) for x in sens["h_s"] if float(x) != H1]:
            N_L = int(math.ceil(L0 / hh - 1e-9))
            l1h = min(l1f, 1.0 / (hh * cf["kappa2"]))
            cs = M5.certified_set(pf["alpha"], lam0, M5.ap_of(pf), cf["kappa1"], cf["kappa2"], hh, N_L)
            l2h = min(l2f, 0.99 * cs["l2_sup"])
            add(f"h_{hh:g}", T, variant("sens_h", f"h = {hh:g} s", "TFO", T, pf, lam0, L0, l1h, l2h,
                                        f"frozen TFO, resampled to h = {hh:g} s", h=hh, Bp=bpf))
        # ---- review response: widened-box re-identified curve points (own equal-budget tuned gains)
        for lam in [float(x) for x in bc["lambda"]]:
            for L in [Lk(x) for x in bc["L_s"]]:
                r = identmem[("widened", T, lam, L)]
                tr = tuned[(f"wb_{lam:g}_{L}", T)]
                add(f"wb_{lam:g}_{L}", T, variant("bounds_check", f"widened box: lambda {lam:g}, L {L}", "FOO" if lam == 0 else "TFO",
                                                  T, with_q(r["theta"], T), lam, None if L == "full" else float(L),
                                                  tr["best_values"]["l1"], tr["best_values"]["l2"],
                                                  f"04c protocol, box alpha {r['bounds_used']['alpha']}, Rp {r['bounds_used']['Rp']}",
                                                  Bp=r["bounds"]["B_p_V"]))
        # ---- review response: distinct near-optimal restarts of the original 04c identification (row gains kept)
        for lam in [float(x) for x in rst["lambda"]]:
            for L in [int(x) for x in rst["L_s"]]:
                r = identmem[("original", T, lam, L)]
                g = gmap[(T, lam, L)]
                best = float(r["rmse_objective_mV"])
                cand = sorted([q for q in r["runs"] if q["rmse_mV"] <= best + float(rst["tol_mV"])], key=lambda q: q["rmse_mV"])
                keep = []
                for q in cand:
                    v = np.array([q["theta"][k] for k in ("alpha", "R0", "Rp", "Cp", "s", "dq")])
                    if all(np.max(np.abs(v - w) / np.maximum(np.abs(w), 1e-12)) > float(rst["distinct_rel"]) for w, _ in keep):
                        keep.append((v, q))
                    if len(keep) >= int(rst["max_distinct"]):
                        break
                for j, (_, q) in enumerate(keep):
                    add(f"rs_{lam:g}_{L}_{j}", T, variant("restarts", f"restart {j}: lambda {lam:g}, L {L}", "FOO" if lam == 0 else "TFO",
                                                          T, with_q(q["theta"], T), lam, L, g["best_values"]["l1"], g["best_values"]["l2"],
                                                          "04c original box, near-optimal start", cert=False,
                                                          extra=None))
                    V[f"rs_{lam:g}_{L}_{j}"][str(T)]["ident"] = dict(rmse_mV=q["rmse_mV"], d_rmse_mV=q["rmse_mV"] - best,
                                                                      at_bound=q["at_bound"])
        for Tu in TEMPS:
            if Tu == T:
                continue
            fu = fz["methods"]["TFO"]["per_T"][str(Tu)]
            add(f"Tused_{Tu}", T, variant("sens_T", f"parameters of {Tu} C", "TFO", T, with_q(fu["params"], Tu), lam0, L0,
                                          fu["hyper"]["l1"], fu["hyper"]["l2"], f"frozen TFO of {Tu} C", T_params=Tu,
                                          extra={"temperature_mismatch": Tu}))
    # ---- RCL weight check (alpha = 1 - eps vs the exact alpha = 1 weights)
    rcl_chk = {}
    for T in TEMPS:
        p = V["rcl"][str(T)]["params"]
        w = TM.gl_weights(p["alpha"], p["lam"], H1, int(L0))
        ex = np.zeros_like(w)
        ex[0], ex[1] = 1.0, -math.exp(-p["lam"] * H1)
        rcl_chk[str(T)] = float(np.max(np.abs(w - ex)))
    vsha = spec_hash(V)
    fu = now()
    if OUT.exists():                     # keep the first freeze time stamp of an unchanged variant set
        try:
            old = load_json("ablation.json").get("freeze", {})
            if old.get("variants_sha256") == vsha and old.get("frozen_utc"):
                fu = old["frozen_utc"]
        except Exception:  # pragma: no cover
            pass
    freeze = dict(frozen_utc=fu, status="FROZEN: every ablation variant below was identified/tuned on the "
                  "identification and validation files only; test files not yet loaded",
                  frozen_config_sha256=sha(RES / "frozen_config.json"), variants_sha256=vsha, variants=V)
    s1 = dict(validation_files=vfiles, identification=[ident[k] for k in sorted(ident)],
              lambda_relaxation={str(T): dict(median=lam_rel[T][0], all_primary=lam_rel[T][1], per_T=lam_rel[T][2]) for T in TEMPS},
              lambda_identified={str(T): lambda_identified(T) for T in TEMPS},
              tuning=[tuned[k] for k in sorted(tuned, key=str)], rcl_weight_check_max_abs=rcl_chk,
              identification_memory_review=[identmem[k] for k in sorted(identmem, key=str)],
              runtime=dict(wall_s=time.perf_counter() - t0w, main_process_s=time.process_time() - t0c, tune_wall_s=tune_wall,
                           identmem_wall_s=identmem_wall,
                           worker_process_s_sum=float(sum(r["process_s"] for r in tuned.values()) +
                                                      sum(r["process_s"] for r in ident.values()) +
                                                      sum(r["process_s"] for r in identmem.values()))))
    return freeze, s1


# ---------------------------------------------------------------------------------------------------------------
# Stage 2: test files (only after the freeze of stage 1 is on disk)
# ---------------------------------------------------------------------------------------------------------------
_FOCV = {}


def focv_for(T, p):
    k = (int(T), float(p["s"]), float(p["dq"]))
    if k not in _FOCV:
        _FOCV[k] = M5.fast_ocv(int(T), p)
    return _FOCV[k]


def check_freeze():
    fz = frozen()
    if not OUT.exists():
        raise PermissionError("results/ablation.json with the stage-1 freeze is required before any test file is loaded")
    J = load_json("ablation.json")
    fr = J.get("freeze", {})
    if not fr.get("frozen_utc") or not str(fr.get("status", "")).startswith("FROZEN"):
        raise PermissionError("ablation freeze missing")
    if fr.get("frozen_config_sha256") != sha(RES / "frozen_config.json"):
        raise PermissionError("frozen_config.json changed after the ablation freeze")
    if fr.get("variants_sha256") != spec_hash(fr.get("variants")):
        raise PermissionError("the stored freeze variants do not match their sha256")
    return fz, fr


def test_file_task(args):
    lid, jobs = args
    _, ab, _, _ = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)
    cases = {H1: case}
    rows = []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        for key, v in jobs:
            h = float(v["h"])
            if h not in cases:
                cases[h] = E.resample_case(case, h)
            cs = cases[h]
            f = focv_for(v["T_params"], v["params"])
            for sc in ab["scenarios"]:
                rec = E.run_case(v["method"], v["params"], dict(v["hyper"]), cs, z0_scenario=sc, ocv=f, keep_series=True,
                                 extra=dict(v.get("extra") or {}))
                s = rec.pop("_series")
                am = M5.admissible_metrics(cs.t, s["zhat"], s["zref"])
                rows.append(dict(variant=key, file=lid, T=case.T, profile=case.profile, start=case.start_level,
                                 scenario=sc, h=h, adm_rmse_pct=am["adm_rmse_pct"], adm_maxabs_pct=am.get("adm_maxabs_pct"),
                                 adm_within1_pct=am.get("adm_within1_pct"), adm_within2_pct=am.get("adm_within2_pct"),
                                 whole_post_rmse_pct=rec["post_rmse_pct"], whole_post_within1_pct=rec["post_within1_pct"],
                                 whole_post_within2_pct=rec["post_within2_pct"], whole_post_maxabs_pct=rec["post_maxabs_pct"],
                                 conv_time_s=rec["conv_time_s"], vt_rmse_mV=rec["vt_rmse_mV"],
                                 soc_clip_count=rec["soc_clip_count"], nonfinite=rec["nonfinite"],
                                 positivity_ok_clip=rec["positivity_ok"], wall_s=rec["wall_s"],
                                 duration_s=float(cs.t[-1] - cs.t[0]), n=int(cs.t.size)))
    return dict(file=lid, T=case.T, verified=bool(case.meta["verify_passed"]), n_samples=int(case.t.size),
                duration_s=float(case.t[-1] - case.t[0]), rows=rows, wall_s=time.perf_counter() - t0w,
                process_s=time.process_time() - t0c)


def _test_cached(args):
    return cache(f"test_{args[0]}.json", test_file_task, (args,))


def stage2(freeze, workers):
    c, ab, _, _ = cfg()
    check_freeze()
    V = freeze["variants"]
    files = list(c["splits"][ab["files"]])
    tasks = []
    for lid in files:
        T = int(D.CATALOG[lid]["temperature_C"])
        jobs = [(k, V[k][str(T)]) for k in sorted(V) if str(T) in V[k]]
        tasks.append((lid, jobs))
    t0 = time.perf_counter()
    res = run_pool(_test_cached, tasks, workers)
    return dict(files=[dict(file=r["file"], T=r["T"], verified=r["verified"], n_samples=r["n_samples"],
                            duration_s=r["duration_s"], wall_s=r["wall_s"], process_s=r["process_s"]) for r in res],
                rows=[row for r in res for row in r["rows"]], wall_s=time.perf_counter() - t0,
                worker_process_s_sum=float(sum(r["process_s"] for r in res)))


# ---------------------------------------------------------------------------------------------------------------
# Stage 3: aggregation
# ---------------------------------------------------------------------------------------------------------------
METRICS = ("adm_rmse_pct", "whole_post_rmse_pct", "adm_within2_pct", "adm_within1_pct", "whole_post_within2_pct",
           "adm_maxabs_pct")


def _mean(x):
    x = np.asarray([num(v) for v in x], float)
    return float(np.mean(x)) if x.size else float("nan")


FILE_T = {}


def strat_boot(d, T, stat, n_boot, seed, ci):
    """Temperature-stratified percentile bootstrap of stat(d): files are resampled WITHIN each temperature (the files of
    one temperature share a cell, a parameter set and a gain set, so the 18 pairs are not exchangeable across T)."""
    d, T = np.asarray(d, float), np.asarray(T)
    idx = [np.where(T == t)[0] for t in sorted(set(T.tolist()))]
    rng = np.random.default_rng(seed)
    draws = np.concatenate([d[ix[rng.integers(0, ix.size, size=(n_boot, ix.size))]] for ix in idx], axis=1)
    v = stat(draws, axis=1)
    q = 100.0 * (1.0 - ci) / 2.0
    return float(np.percentile(v, q)), float(np.percentile(v, 100.0 - q))


def pstats(a, b, T):
    """Paired comparison a - b over files: metrics.paired_difference (median, pooled bootstrap, Wilcoxon p) plus the
    temperature-stratified bootstrap intervals of the median and the mean, sign counts with a tie threshold, per-T
    means/counts and the verdict of config ablation.review_response.statistics."""
    rr = cfg()[1]["review_response"]
    sb, tie = rr["stratified_bootstrap"], float(rr["sign_tie_abs"])
    tol = float(cfg()[2]["structure_selection"]["tie_tol_pct"])
    out = MX.paired_difference(a, b)
    d = np.asarray(a, float) - np.asarray(b, float)
    T = np.asarray(T)
    ok = np.isfinite(d)
    d, T = d[ok], T[ok]
    out["strat_ci_median"] = strat_boot(d, T, np.median, int(sb["n_boot"]), int(sb["seed"]), float(sb["ci"]))
    out["strat_ci_mean"] = strat_boot(d, T, np.mean, int(sb["n_boot"]), int(sb["seed"]) + 1, float(sb["ci"]))
    out["n_pos"], out["n_neg"] = int(np.sum(d > tie)), int(np.sum(d < -tie))
    out["n_a_better"], out["n_b_better"] = out["n_neg"], out["n_pos"]
    out["per_T"] = {str(t): dict(mean=float(np.mean(d[T == t])), median=float(np.median(d[T == t])),
                                 n_pos=int(np.sum(d[T == t] > tie)), n_neg=int(np.sum(d[T == t] < -tie)),
                                 n=int(np.sum(T == t))) for t in sorted(set(T.tolist()))}
    pm = [v["mean"] for v in out["per_T"].values()]
    out["per_T_reversal"] = bool(pm and max(pm) >= tol and min(pm) <= -tol)
    lm, hm = out["strat_ci_median"]
    la, ha = out["strat_ci_mean"]
    if -tol < lm and hm < tol and -tol < la and ha < tol:
        v = "equivalent"
        if (lm > 0 and la > 0) or (hm < 0 and ha < 0):
            v += " (consistent sign)"
    elif lm > 0 and la > 0:
        v = "worse"
    elif hm < 0 and ha < 0:
        v = "better"
    else:
        v = "not resolved"
    out["verdict"] = v
    out["tol"] = tol
    return out


def summarise(rows, freeze):
    V = freeze["variants"]
    FILE_T.update({r["file"]: int(r["T"]) for r in rows})
    by = {}
    for r in rows:
        by.setdefault(r["variant"], []).append(r)
    ref = {(r["file"], r["scenario"]): r for r in by["frozen_TFO"]}
    out = {}
    for key, rs in by.items():
        s = dict(n_runs=len(rs), n_files=len({r["file"] for r in rs}))
        for m in METRICS:
            s[m] = _mean([r[m] for r in rs])
            s[m + "_by_T"] = {str(T): _mean([r[m] for r in rs if r["T"] == T]) for T in TEMPS if any(r["T"] == T for r in rs)}
        s["adm_rmse_pct_by_profile"] = {p: _mean([r["adm_rmse_pct"] for r in rs if r["profile"] == p])
                                        for p in sorted({r["profile"] for r in rs})}
        s["adm_rmse_pct_by_scenario"] = {sc: _mean([r["adm_rmse_pct"] for r in rs if r["scenario"] == sc])
                                         for sc in sorted({r["scenario"] for r in rs})}
        ct = np.asarray([num(r["conv_time_s"]) for r in rs])
        s["conv_time_median_s"] = float(np.median(ct))
        s["n_not_converged"] = int(np.sum(~np.isfinite(ct)))
        s["n_nonfinite"] = int(sum(bool(r["nonfinite"]) for r in rs))
        s["soc_clip_total"] = int(sum(int(r["soc_clip_count"]) for r in rs))
        s["wall_per_run_s_median"] = float(np.median([num(r["wall_s"]) for r in rs]))
        pair = {}
        files = sorted({r["file"] for r in rs})
        for m in ("adm_rmse_pct", "whole_post_rmse_pct"):
            a = [_mean([r[m] for r in rs if r["file"] == f]) for f in files]
            b = [_mean([ref[(f, sc)][m] for sc in sorted({r["scenario"] for r in rs if r["file"] == f})]) for f in files]
            pair[m] = pstats(a, b, [FILE_T[f] for f in files]) if key != "frozen_TFO" else None
        s["paired_vs_frozen_TFO"] = pair
        cert = [V[key][T].get("certificate") for T in V[key]]
        s["certified_all_T"] = bool(all(cc and cc["certified"] for cc in cert)) if all(cert) else None
        s["certified_by_T"] = {T: (V[key][T]["certificate"]["certified"] if V[key][T].get("certificate") else None) for T in V[key]}
        s["group"], s["label"] = V[key][next(iter(V[key]))]["group"], V[key][next(iter(V[key]))]["label"]
        out[key] = s
    return out


def curve_data(summary, freeze):
    _, _, dt, _ = cfg()
    lamg = [float(v) for v in dt["lambda_grid"]]
    Lfin = [int(v) for v in dt["L_grid_s"]]
    gd = load_json("gain_design.json")
    pcm = {(p["T"], float(p["lam"]), p["L"]): p for p in gd["post_certificates"]}
    eps = float(cfg()[1]["eps_z"])
    cur = {}
    for lam in lamg:
        keys = [f"curve_{lam:g}_{L}" for L in Lfin]
        kf = f"curve_{lam:g}_full"
        hor = {}
        for T in TEMPS:
            mr = [m for m in pcm[(T, lam, 400)]["memory_requirement"] if abs(m["eps_z"] - eps) < 1e-15][0]
            hor[str(T)] = (mr.get("L_z_star_s") if lam > 0 else None) if mr.get("defined") else None
            if lam == 0 and mr.get("defined"):
                hor[str(T) + "_log10_untempered"] = mr.get("log10_L_untempered_s")
        cur[f"{lam:g}"] = dict(lam=lam, L=Lfin, adm_mean=[summary[k]["adm_rmse_pct"] for k in keys],
                               whole_mean=[summary[k]["whole_post_rmse_pct"] for k in keys],
                               adm_by_T={str(T): [summary[k]["adm_rmse_pct_by_T"][str(T)] for k in keys] for T in TEMPS},
                               adm_full=summary[kf]["adm_rmse_pct"], whole_full=summary[kf]["whole_post_rmse_pct"],
                               adm_full_by_T={str(T): summary[kf]["adm_rmse_pct_by_T"][str(T)] for T in TEMPS},
                               certified_horizon_s=hor,
                               certified_by_L=[freeze["variants"][k]["0"]["certificate"]["certified"] and
                                               freeze["variants"][k]["25"]["certificate"]["certified"] and
                                               freeze["variants"][k]["45"]["certificate"]["certified"] for k in keys])
    # best lambda per L (mean adm) and difference best lambda > 0 minus lambda = 0
    best = []
    for i, L in enumerate(Lfin + ["full"]):
        vals = {lam: (cur[f"{lam:g}"]["adm_mean"][i] if L != "full" else cur[f"{lam:g}"]["adm_full"]) for lam in lamg}
        lb = min((l for l in lamg if l > 0), key=lambda l: vals[l])
        best.append(dict(L=L, best_lambda_pos=lb, best_pos_minus_zero=vals[lb] - vals[0.0],
                         argmin_lambda=min(lamg, key=lambda l: vals[l])))
    return dict(curves=cur, best_by_L=best, eps_z=eps)


EXTRA_PAIRS = [("opt_tfgd", "opt_trf"), ("memory_short", "memory_full"), ("memory_cert", "memory_full"),
               ("curve_0_800", "curve_0.001_full"), ("curve_0_1600", "curve_0.001_full"),
               ("curve_0_1600", "curve_0_400"), ("curve_0.001_full", "curve_0_full")]


def per_file_means(rows, key, m):
    d = {}
    for r in rows:
        if r["variant"] == key:
            d.setdefault(r["file"], []).append(num(r[m]))
    return {f: float(np.mean(v)) for f, v in d.items()}


def pair(rows, a, b, metrics=("adm_rmse_pct", "whole_post_rmse_pct")):
    out = {}
    for m in metrics:
        A, B = per_file_means(rows, a, m), per_file_means(rows, b, m)
        fs = sorted(set(A) & set(B))
        FILE_T.update({r["file"]: int(r["T"]) for r in rows if r["file"] in fs})
        out[m] = pstats([A[f] for f in fs], [B[f] for f in fs], [FILE_T[f] for f in fs])
    return out


def pairs_data(rows):
    """Paired differences that are not against the reference: the core question (every lambda > 0 minus lambda = 0 at
    the same memory, own re-identified model and own tuned gains) and the EXTRA_PAIRS."""
    _, _, dt, _ = cfg()
    Ls = [int(v) for v in dt["L_grid_s"]] + ["full"]
    core = {}
    for lam in [float(v) for v in dt["lambda_grid"] if float(v) > 0]:
        core[f"{lam:g}"] = {str(L): pair(rows, f"curve_{lam:g}_{L}", f"curve_0_{L}") for L in Ls}
    extra = {f"{a}__minus__{b}": pair(rows, a, b) for a, b in EXTRA_PAIRS}
    return dict(tempered_minus_untempered_same_L=core, extra=extra, L=[str(L) for L in Ls])


# ---------------------------------------------------------------------------------------------------------------
# Figure data (every plotted array is stored in results/ablation.json['figure_data'])
# ---------------------------------------------------------------------------------------------------------------
def params_T_data(J):
    IJ = load_json("identification.json")
    R = load_json("identification_refined.json")
    fz = frozen()
    out = dict(T=list(TEMPS), series={})

    def ser(name, fam, keys):
        d = {}
        for k in keys:
            pts, lo, hi, valid = [], [], [], []
            for T in TEMPS:
                pt = IJ["per_T"][str(T)]
                f = pt["fits"][fam]
                v = f["theta"].get(k) if k in f["theta"] else f["step_response"].get(k)
                st = pt["bootstrap"].get(f"{fam}_full", {}).get("stats", {}).get(k)
                pts.append(None if v is None else float(v))
                lo.append(float(st["ci95"][0]) if st else None)
                hi.append(float(st["ci95"][1]) if st else None)
                valid.append(bool(st["ci_valid"]) if st else None)
            d[k] = dict(value=pts, ci_lo=lo, ci_hi=hi, ci_valid=valid)
        out["series"][name] = d

    ser("TFO", "TFO", ["alpha", "lam", "R0", "R_1s_Ohm", "R_dc_Ohm", "Cp"])
    ser("FO", "FO", ["alpha", "R0", "R_1s_Ohm", "R_dc_Ohm", "Cp"])
    ser("2RC", "2RC", ["R0", "R_1s_Ohm", "R_dc_Ohm"])
    out["series"]["TFO_L400_frozen"] = {k: dict(value=[float(fz["methods"]["TFO"]["per_T"][str(T)]["params"][k]) for T in TEMPS])
                                         for k in ("alpha", "lam", "R0", "Cp")}
    out["series"]["R0_edge"] = dict(value=[float(R["edge"][str(T)]["comparison"]["R0_edge"]) for T in TEMPS],
                                    ci_lo=[float(R["edge"][str(T)]["comparison"]["R0_edge_ci95"][0]) for T in TEMPS],
                                    ci_hi=[float(R["edge"][str(T)]["comparison"]["R0_edge_ci95"][1]) for T in TEMPS])
    lr = J["stage1"]["lambda_relaxation"]
    out["series"]["lambda_relaxation"] = dict(value=[lr[str(T)]["median"] for T in TEMPS],
                                              q25=[lr[str(T)]["per_T"]["q25"] for T in TEMPS],
                                              q75=[lr[str(T)]["per_T"]["q75"] for T in TEMPS])
    out["sources"] = ("identification.json per_T fits (causal_full = identification_refined chosen_parameter_sets) and "
                      "bootstrap_v2 95 % percentile intervals (TFO_full/FO_full/2RC_full); identification_refined.json edge R0; "
                      "frozen_config.json TFO at L = 400 s; relaxation_phenomenological.json per-T TPL median [IQR]")
    return out


def sensitivity_data(J):
    S, V = J["summary"], J["freeze"]["variants"]
    cur = J["figure_data"]["memory"]["curves"]
    ab = cfg()[1]
    lam_pts = {}
    for key in ("lambda_identified", "lambda_relaxation", "lambda_identified_at_memory"):
        lam_pts[key] = dict(lam=[V[key][str(T)]["lam"] for T in TEMPS],
                            adm=[S[key]["adm_rmse_pct_by_T"][str(T)] for T in TEMPS])
    lamg = sorted(float(k) for k in cur)
    i400 = cur[f"{lamg[0]:g}"]["L"].index(400)
    lam_line = dict(lam=lamg, adm_by_T={str(T): [cur[f"{l:g}"]["adm_by_T"][str(T)][i400] for l in lamg] for T in TEMPS})
    deltas = [float(d) for d in ab["sensitivity"]["alpha_delta"]]
    dl = sorted(deltas + [0.0])
    akey = {0.0: "frozen_TFO", **{d: f"alpha_{d:+g}" for d in deltas}}
    alpha = dict(delta=dl, adm_by_T={str(T): [S[akey[d]]["adm_rmse_pct_by_T"][str(T)] for d in dl] for T in TEMPS},
                 alpha_used={str(T): [V[akey[d]][str(T)]["params"]["alpha"] for d in dl] for T in TEMPS},
                 certified={str(T): [V[akey[d]][str(T)]["certificate"]["certified"] for d in dl] for T in TEMPS})
    hs = [float(x) for x in ab["sensitivity"]["h_s"]]
    hkey = {h: ("frozen_TFO" if h == H1 else f"h_{h:g}") for h in hs}
    hd = dict(h=hs, adm_by_T={str(T): [S[hkey[h]]["adm_rmse_pct_by_T"][str(T)] for h in hs] for T in TEMPS},
              l1={str(T): [V[hkey[h]][str(T)]["hyper"]["l1"] for h in hs] for T in TEMPS},
              l2={str(T): [V[hkey[h]][str(T)]["hyper"]["l2"] for h in hs] for T in TEMPS},
              certified={str(T): [V[hkey[h]][str(T)]["certificate"]["certified"] for h in hs] for T in TEMPS},
              sigma_star={str(T): [V[hkey[h]][str(T)]["certificate"]["sigma_star"] for h in hs] for T in TEMPS})
    tm = {}
    for Tu in TEMPS:
        tm[str(Tu)] = [S["frozen_TFO"]["adm_rmse_pct_by_T"][str(T)] if T == Tu else
                       S[f"Tused_{Tu}"]["adm_rmse_pct_by_T"][str(T)] for T in TEMPS]
    return dict(lambda_L400=lam_line, lambda_points=lam_pts, alpha=alpha, h=hd,
                temperature=dict(file_T=list(TEMPS), adm_by_T_used=tm))


# ---------------------------------------------------------------------------------------------------------------
# Figures (draft, journal style)
# ---------------------------------------------------------------------------------------------------------------
LAM_STYLE = [("-", "o"), ("--", "s"), ("-.", "^"), (":", "v"), ((0, (5, 1.5, 1, 1.5)), "D"), ((0, (1, 1)), "P")]
X_FULL = 6.4e4


def fig_memory(fd, durations):
    from tfso import plotstyle as ps
    plt = ps.setup()
    cur = fd["curves"]
    lams = sorted(cur, key=lambda k: float(k))
    fig, axs = plt.subplots(2, 2, figsize=ps.figsize("text", 118), layout="constrained", sharex=True)
    panels = [("mean", "mean over 0/25/45 $^\\circ$C")] + [(str(T), f"{T} $^\\circ$C") for T in TEMPS]
    for k, (pk, title) in enumerate(panels):
        ax = axs.flat[k]
        for i, lk in enumerate(lams):
            cv = cur[lk]
            y = cv["adm_mean"] if pk == "mean" else cv["adm_by_T"][pk]
            yf = cv["adm_full"] if pk == "mean" else cv["adm_full_by_T"][pk]
            ls, mk = LAM_STYLE[i]
            lab = r"$\lambda=0$ (FO-trunc)" if float(lk) == 0 else rf"$\lambda={float(lk):g}$ s$^{{-1}}$"
            ax.plot(cv["L"], y, color=ps.SLOTS[i], ls=ls, marker=mk, mec="white", mew=0.5, lw=ps.LW["data"], label=lab)
            xf = durations["all"] if pk == "mean" else durations[pk]
            ax.plot([cv["L"][-1], xf], [y[-1], yf], color=ps.SLOTS[i], ls=":", lw=ps.LW["ref"])
            ax.plot([xf], [yf], color=ps.SLOTS[i], marker=mk, mfc="white", mec=ps.SLOTS[i], mew=1.0, ls="none")
            if pk != "mean":
                hz = cv["certified_horizon_s"].get(pk)
                if hz is not None and float(lk) > 0:
                    ax.plot([hz], [0.035], transform=ax.get_xaxis_transform(), marker="|", ms=9, mew=1.4,
                            color=ps.SLOTS[i], ls="none", clip_on=False)
        xf = durations["all"] if pk == "mean" else durations[pk]
        ax.axvline(xf, color=ps.MUTED, lw=ps.LW["ref"], ls=":")
        ax.text(xf * 1.08, 0.97, "full = profile length", rotation=90, transform=ax.get_xaxis_transform(),
                ha="left", va="top", color=ps.INK2, fontsize=ps.FONT_PT["base"] - 1)
        ax.axvline(400, color=ps.INK2, lw=ps.LW["ref"], ls="--")
        ax.set_xscale("log")
        ax.set_xlim(35, 4.0e4)
        ax.set_xticks([50, 100, 400, 1000, 3200, 1e4])
        ax.set_xticklabels(["50", "100", "400", "1000", "3200", "$10^4$"])
        ax.minorticks_off()
        ax.set_title(title, fontsize=ps.FONT_PT["label"])
        ps.panel_label(ax, k)
    for ax in axs[1]:
        ax.set_xlabel("memory horizon $L$ (s)")
    for ax in axs[:, 0]:
        ax.set_ylabel("test SOC RMSE, admissible (% SOC)")
    axs.flat[0].text(430, 0.97, "budget", transform=axs.flat[0].get_xaxis_transform(), color=ps.INK2,
                     fontsize=ps.FONT_PT["base"] - 1, va="top")
    axs.flat[0].text(0.27, 0.60, "open markers: full memory, drawn at\nthe median profile length; (b)-(d): axis\nticks = certified "
                                 "horizon $L_z^*$ ($\\varepsilon_z$ = 0.5 %)",
                     transform=axs.flat[0].transAxes, ha="left", va="top", color=ps.INK2, fontsize=ps.FONT_PT["base"] - 1.5)
    h_, l_ = axs.flat[0].get_legend_handles_labels()
    fig.legend(h_, l_, loc="outside lower center", ncol=6, fontsize=ps.FONT_PT["legend"] - 0.5)
    p = ps.save(fig, ROOT / "figures" / "fig_rmse_memory.pdf")
    plt.close(fig)
    return p


def fig_sensitivity(sd):
    from tfso import plotstyle as ps
    plt = ps.setup()
    fig, axs = plt.subplots(2, 2, figsize=ps.figsize("text", 112), layout="constrained")
    tn = {str(T): f"T{T}" for T in TEMPS}
    # (a) lambda at L = 400 s
    ax = axs[0, 0]
    lam = sd["lambda_L400"]["lam"]
    x0 = 3e-5
    xs = [x0 if l == 0 else l for l in lam]
    for T in TEMPS:
        ax.plot(xs, sd["lambda_L400"]["adm_by_T"][str(T)], label=f"{T} $^\\circ$C", **ps.line(tn[str(T)], marker=True))
    for key, mk, lab in (("lambda_identified", "*", "identified $\\hat\\lambda$"), ("lambda_relaxation", "D", "relaxation median")):
        for j, T in enumerate(TEMPS):
            pt = sd["lambda_points"][key]
            ax.plot([max(pt["lam"][j], x0)], [pt["adm"][j]], marker=mk, ms=7 if mk == "*" else 4.5, ls="none",
                    mfc="white", mec=ps.SERIES[tn[str(T)]]["color"], mew=1.0, label=lab if j == 0 else None)
    ax.set_xscale("log")
    ax.set_xticks([x0, 1e-4, 1e-3, 1e-2])
    ax.set_xticklabels(["0", "$10^{-4}$", "$10^{-3}$", "$10^{-2}$"])
    ax.minorticks_off()
    ax.set_xlabel(r"tempering rate $\lambda$ (s$^{-1}$), $L$ = 400 s")
    ax.set_ylabel("test SOC RMSE, admissible (% SOC)")
    ax.legend(loc="upper left", fontsize=ps.FONT_PT["legend"] - 0.5, ncol=2)
    # (b) alpha
    ax = axs[0, 1]
    for T in TEMPS:
        ax.plot(sd["alpha"]["delta"], sd["alpha"]["adm_by_T"][str(T)], label=f"{T} $^\\circ$C", **ps.line(tn[str(T)], marker=True))
    ax.set_xticks(sd["alpha"]["delta"])
    ax.set_xlabel(r"order perturbation $\Delta\alpha$ (frozen gains)")
    ax.set_ylabel("test SOC RMSE, admissible (% SOC)")
    # (c) h
    ax = axs[1, 0]
    for T in TEMPS:
        ax.plot(sd["h"]["h"], sd["h"]["adm_by_T"][str(T)], label=f"{T} $^\\circ$C", **ps.line(tn[str(T)], marker=True))
    ax.set_xscale("log")
    ax.set_xticks(sd["h"]["h"])
    ax.set_xticklabels([f"{h:g}" for h in sd["h"]["h"]])
    ax.minorticks_off()
    ax.set_xlabel("sampling interval $h$ (s), memory held in seconds")
    ax.set_ylabel("test SOC RMSE, admissible (% SOC)")
    ax.legend(loc="upper left")
    # (d) temperature mismatch
    ax = axs[1, 1]
    off = {0: -2.0, 25: 0.0, 45: 2.0}
    for Tu in TEMPS:
        y = sd["temperature"]["adm_by_T_used"][str(Tu)]
        st = ps.SERIES[tn[str(Tu)]]
        for j, T in enumerate(TEMPS):
            ax.plot([T + off[Tu]], [y[j]], marker=st["marker"], ms=5, ls="none", mec=st["color"], mew=1.0,
                    mfc=st["color"] if T == Tu else "white")
    from matplotlib.lines import Line2D
    hd = [Line2D([], [], marker=ps.SERIES[tn[str(Tu)]]["marker"], ms=5, ls="none", mec=ps.SERIES[tn[str(Tu)]]["color"],
                 mfc="white", mew=1.0, label=f"model of {Tu} $^\\circ$C") for Tu in TEMPS]
    ax.set_xticks(list(TEMPS))
    ax.set_xticklabels([f"{T} $^\\circ$C files" for T in TEMPS])
    ax.set_xlabel("filled marker = matched temperature (frozen TFO)")
    ax.set_ylabel("test SOC RMSE, admissible (% SOC)")
    ymax = max(max(v) for v in sd["temperature"]["adm_by_T_used"].values())
    ax.set_ylim(0, 1.35 * ymax)
    ax.legend(handles=hd, loc="upper center", ncol=3, fontsize=ps.FONT_PT["legend"] - 0.5, handletextpad=0.2,
              columnspacing=0.8)
    for k, ax in enumerate(axs.flat):
        ps.panel_label(ax, k)
    p = ps.save(fig, ROOT / "figures" / "fig_sensitivity.pdf")
    plt.close(fig)
    return p


def fig_params(pd_):
    from tfso import plotstyle as ps
    plt = ps.setup()
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 100), layout="constrained")
    T = np.asarray(TEMPS, float)
    S = pd_["series"]
    style = {"TFO": ("M_TF", -2.5), "FO": ("M_FO", 0.0), "2RC": ("M_2RC", 2.5)}
    names = {"TFO": "TFO (full memory)", "FO": "FO (full memory)", "2RC": "2RC"}
    panels = [("alpha", r"order $\alpha$", 1.0), ("lam", r"tempering rate $\lambda$ (s$^{-1}$)", 1.0),
              ("R0", r"$R_0$ (m$\Omega$)", 1e3), ("R_1s_Ohm", r"$R(1\,$s$)$ (m$\Omega$)", 1e3),
              ("R_dc_Ohm", r"$R_\mathrm{dc}$ (m$\Omega$)", 1e3), ("Cp", r"$C_p$ (F s$^{\alpha-1}$)", 1.0)]
    for k, (key, lab, sc) in enumerate(panels):
        ax = axs.flat[k]
        for fam, (sty, dx) in style.items():
            d = S[fam].get(key)
            if d is None:
                continue
            c = ps.SERIES[sty]["color"]
            for j in range(3):
                v = d["value"][j]
                if v is None:
                    continue
                lo, hi = d["ci_lo"][j], d["ci_hi"][j]
                if key == "lam":
                    v, lo, hi = max(v, 1e-7), (max(lo, 1e-7) if lo is not None else None), hi
                if lo is not None:
                    ax.plot([T[j] + dx] * 2, [lo * sc, hi * sc], color=c, lw=ps.LW["data"],
                            ls="-" if d["ci_valid"][j] else ":")
                ax.plot([T[j] + dx], [v * sc], marker=ps.SERIES[sty]["marker"], ms=4.5, color=c, mec="white", mew=0.5,
                        ls="none", label=names[fam] if j == 0 else None)
        if key in S["TFO_L400_frozen"]:
            v = np.asarray(S["TFO_L400_frozen"][key]["value"]) * sc
            ax.plot(T - 5.0, np.maximum(v, 1e-7) if key == "lam" else v, marker="x", ms=5, color=ps.INK, ls="none",
                    label="TFO frozen ($L$ = 400 s)")
        if key == "R0":
            e = S["R0_edge"]
            for j in range(3):
                ax.plot([T[j] + 5.0] * 2, [e["ci_lo"][j] * 1e3, e["ci_hi"][j] * 1e3], color=ps.REF_MARK["edge"]["color"], lw=ps.LW["data"])
            ax.plot(T + 5.0, np.asarray(e["value"]) * 1e3, ms=4.5, mec="white", mew=0.5, ls="none",
                    label="$R_0$ from current edges", **ps.REF_MARK["edge"])
        if key == "lam":
            r = S["lambda_relaxation"]
            for j in range(3):
                ax.plot([T[j] + 5.0] * 2, [r["q25"][j], r["q75"][j]], color=ps.REF_MARK["relaxation"]["color"], lw=ps.LW["data"])
            ax.plot(T + 5.0, r["value"], ms=4, mec="white", mew=0.5, ls="none",
                    label="relaxation TPL (median, IQR)", **ps.REF_MARK["relaxation"])
            ax.set_yscale("log")
            ax.set_ylim(5e-8, 0.1)
            ax.set_yticks([1e-7, 1e-5, 1e-3, 1e-1])
            ax.set_yticklabels([r"$\leq10^{-7}$", "$10^{-5}$", "$10^{-3}$", "$10^{-1}$"])
        if key == "Cp":
            ax.set_yscale("log")
            ps.plain_log_ticks(ax, "y", ticks=[5, 10, 20, 30, 50])
        ax.set_xticks(list(TEMPS))
        ax.set_xlim(-10, 55)
        ax.set_xlabel(r"temperature ($^\circ$C)")
        ax.set_ylabel(lab)
        ps.panel_label(ax, k)
    hs, ls_ = [], []
    for ax in axs.flat:
        for h_, l_ in zip(*ax.get_legend_handles_labels()):
            if l_ not in ls_:
                hs.append(h_)
                ls_.append(l_)
    from matplotlib.lines import Line2D
    hs.append(Line2D([], [], color=ps.INK2, lw=ps.LW["data"], ls=":"))
    ls_.append("interval not quotable (bound)")
    fig.legend(hs, ls_, loc="outside lower center", ncol=4, fontsize=ps.FONT_PT["legend"] - 0.5)
    p = ps.save(fig, ROOT / "figures" / "fig_params_temperature.pdf")
    plt.close(fig)
    return p


# ---------------------------------------------------------------------------------------------------------------
# Table 8 (tables/tab_ablation.tex)
# ---------------------------------------------------------------------------------------------------------------
TABLE_ROWS = [
    ("Reference", [("frozen_TFO", r"TFO, $\lambda=10^{-4}$\,s$^{-1}$, $L=400$\,s, tuned certified gains")]),
    ("(1) tempering rate, re-identified at $L=400$\\,s", [
        ("lambda_zero", r"$\lambda=0$ (FO-trunc)"),
        ("lambda_identified", r"$\lambda$ identified (full-memory fit)"),
        ("lambda_identified_at_memory", r"$\lambda$ identified at $L=400$\,s"),
        ("lambda_relaxation", r"$\lambda$ from relaxation (TPL median)")]),
    ("(2) memory (frozen model and gains)", [
        ("memory_cert", r"certified $L_\mathrm{cert}$ ($\varepsilon_z=0.5\,\%$)"),
        ("memory_short", r"$L_\mathrm{cert}/10$ (memory bound not certified)"),
        ("memory_full", r"full memory")]),
    ("(3) gains", [
        ("gain_lmi_design", r"LMI design gains (untuned, certified)"),
        ("gain_l2_zero", r"$l_2=0$ (certified)"),
        ("gain_l2_over", r"$l_2=2\,l_2^{\sup}$ (DC/LP violated)"),
        ("gain_l1_f0.3", r"$l_1=0.3/(h\kappa_2)$ (certified control)"),
        ("gain_l1_f0.9", r"$l_1=0.9/(h\kappa_2)$ (certified control)"),
        ("gain_l1_positivity", r"$l_1=1.5/(h\kappa_2)$ (positivity violated)"),
        ("gain_unconstrained", r"tuned without certificate")]),
    ("(4) fractional order", [("rcl", r"RCL observer ($\alpha=1$)")]),
    ("(5) identification optimiser", [
        ("opt_tfgd", r"TFGD best run"),
        ("opt_trf", r"CMA-ES/TRF optimum")]),
    ("(6) tempering at a fixed memory", [
        ("curve_0_3200", r"$\lambda=0$, $L=3200$\,s"),
        ("curve_0.0001_3200", r"$\lambda=10^{-4}$, $L=3200$\,s"),
        ("curve_0.001_3200", r"$\lambda=10^{-3}$, $L=3200$\,s"),
        ("curve_0.01_3200", r"$\lambda=10^{-2}$, $L=3200$\,s"),
        ("curve_0_full", r"$\lambda=0$, full memory"),
        ("curve_0.0001_full", r"$\lambda=10^{-4}$, full memory"),
        ("curve_0.001_full", r"$\lambda=10^{-3}$, full memory"),
        ("curve_0.01_full", r"$\lambda=10^{-2}$, full memory")]),
    ("Sensitivity (frozen TFO)", [
        ("alpha_-0.1", r"$\alpha-0.1$"), ("alpha_+0.1", r"$\alpha+0.1$"),
        ("h_2", r"$h=2$\,s"), ("h_5", r"$h=5$\,s"), ("h_10", r"$h=10$\,s"),
        ("Tused_0", r"model of 0\,$^\circ$C on 25/45\,$^\circ$C files"),
        ("Tused_25", r"model of 25\,$^\circ$C on 0/45\,$^\circ$C files"),
        ("Tused_45", r"model of 45\,$^\circ$C on 0/25\,$^\circ$C files")]),
]


def _f(v, nd=2):
    v = num(v)
    if not math.isfinite(v):
        return "--"
    return f"{v:.{nd}f}"


def _h2(a, b):
    """Two-line column head, braced so that it is also valid in a siunitx S column."""
    return r"{\begin{tabular}[b]{@{}c@{}}" + a + r"\\" + b + r"\end{tabular}}"


def write_table(J):
    """tables/tab_ablation.tex: booktabs, siunitx S columns, wrapped variant column and a two-line Delta cell, so the
    table fits the text width of the article class (0.8 in margins) without scaling."""
    S = J["summary"]
    s2 = "S[table-format=1.2]"
    L = [r"% Generated by scripts/07_ablation.py (write_table) from results/ablation.json -- do not edit by hand.",
         r"\begin{table}[t]", r"\centering\footnotesize\setlength{\tabcolsep}{2.5pt}",
         r"\caption{Ablation and sensitivity on the 18 test files (3 initial-SOC scenarios each). SOC RMSE in \% SOC after "
         r"$t-t_0\geq600$\,s: admissible window (reference SOC in $[0.10,0.95]$, primary) overall and per temperature, and "
         r"whole profile; within: share of admissible samples with $|e|\leq2\,\%$. $\Delta$: median over files of the "
         r"per-file admissible RMSE difference to the reference (mean over scenarios), 95\,\% temperature-stratified "
         r"bootstrap interval (the 6 files of a temperature share one cell, parameter and gain set); $+/-$: files worse/better; "
         r"verdict: E equivalent (both stratified intervals of median and mean inside $\pm0.01$\,\% SOC), W/B worse/better "
         r"(both exclude 0), -- not resolved. DC: (DC) at $\sigma=0$, $hl_1\kappa_2\leq1$ and LP at every temperature; "
         r"Mem.: truncation-induced SOC bound $\leq\varepsilon_z=0.5$\,\% (full: no truncation).}",
         r"\label{tab:ablation}",
         r"\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.255\textwidth}ccS[table-format=2.0]" + s2 * 5
         + r"S[table-format=2.1]ccc@{}}", r"\toprule",
         r"Variant & DC & Mem. & {$n$} & {Adm.} & {\SI{0}{\degreeCelsius}} & {\SI{25}{\degreeCelsius}} & "
         r"{\SI{45}{\degreeCelsius}} & {Whole} & " + _h2("Within", r"2\,\%") + r" & "
         + _h2(r"$\Delta$ adm.", r"{[95\,\% CI]}")[1:-1] + r" & $+/-$ & Verdict \\",
         r"\midrule"]
    for head, rows in TABLE_ROWS:
        L.append(r"\multicolumn{13}{@{}l}{\emph{" + head + r"}} \\")
        for key, lab in rows:
            s = S.get(key)
            if s is None:
                continue
            by = s["adm_rmse_pct_by_T"]
            cert = "--" if s["certified_all_T"] is None else ("yes" if s["certified_all_T"] else "no")
            pr = s["paired_vs_frozen_TFO"]["adm_rmse_pct"]
            vc = {"worse": "W", "better": "B", "equivalent": "E", "not resolved": "--"}
            if pr is None:
                dl, npn, vd = "--", "--", "--"
            else:
                dl = (f"{num(pr['median_diff']):+.3f} " + r"{\scriptsize "
                      + f"[{num(pr['strat_ci_median'][0]):+.3f}, {num(pr['strat_ci_median'][1]):+.3f}]" + "}"
                      ).replace("-", "$-$")
                npn, vd = f"{pr['n_pos']}/{pr['n_neg']}", vc[pr['verdict'].split(' (')[0]]
            mc = _memcert(J["freeze"]["variants"], key).replace("-", "--")
            cells = [_f(s['adm_rmse_pct']), _f(by.get('0')), _f(by.get('25')), _f(by.get('45')),
                     _f(s['whole_post_rmse_pct']), _f(s['adm_within2_pct'], 1)]
            cells = ["{--}" if c == "--" else c for c in cells]
            L.append(f"\\enspace {lab} & {cert} & {mc} & {s['n_files']} & " + " & ".join(cells)
                     + f" & {dl} & {npn} & {vd} \\\\ % src: results/ablation.json:summary.{key}")
    L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    p = ROOT / "tables" / "tab_ablation.tex"
    from tfso.texfix import finalize_table
    p.write_text(finalize_table("\n".join(L), "results/ablation.json:summary (all variants); settings (scenarios, "
                                "windows, eps_z)") + "\n", encoding="utf-8")
    return p


def write_outputs(J):
    fd = J["figure_data"]
    fd["sensitivity"] = sensitivity_data(J)
    fd["params_T"] = params_T_data(J)
    dur = {}
    for T in TEMPS:
        dur[str(T)] = float(np.median([f["duration_s"] for f in J["test"]["files"] if f["T"] == T]))
    fd["profile_duration_median_s"] = dict(dur, all=float(np.median([f["duration_s"] for f in J["test"]["files"]])))
    dur = fd["profile_duration_median_s"]
    figs = [fig_memory(fd["memory"], dur), fig_sensitivity(fd["sensitivity"]), fig_params(fd["params_T"])]
    from tfso import plotstyle as ps
    for p in figs:
        try:
            ps.preview_png(p)
        except Exception:  # pragma: no cover
            pass
    J["outputs"] = dict(figures=[str(Path(p).relative_to(ROOT)) for p in figs],
                        table=str(write_table(J).relative_to(ROOT)))
    fn = globals().get("write_report")
    if fn is not None:
        J["outputs"]["report"] = str(fn(J).relative_to(ROOT))


# ---------------------------------------------------------------------------------------------------------------
# Report: reports/ablation_findings.md (every number read from results/ablation.json)
# ---------------------------------------------------------------------------------------------------------------
def _g(v, nd=3):
    v = num(v)
    if not math.isfinite(v):
        return "inf" if v > 0 else "n/a"
    if v != 0 and (abs(v) < 1e-3 or abs(v) >= 1e5):
        return f"{v:.2e}"
    return f"{v:.{nd}f}"


def _pd(S, key, m="adm_rmse_pct"):
    return S[key]["paired_vs_frozen_TFO"][m]


def _ci(p, which="median"):
    lo, hi = p["strat_ci_" + which]
    return f"[{num(lo):+.3f}, {num(hi):+.3f}]"


def _pt(p):
    """per-T mean difference and files with d > 0, e.g. '0 C +0.162 (6/6)'."""
    return ", ".join(f"{T} C {v['mean']:+.3f} ({v['n_pos']}/{v['n']})" for T, v in p["per_T"].items())


def _pp(p, short=False):
    """median [stratified CI], mean [stratified CI], files worse/better, verdict (+ per-T means)."""
    s = (f"median {num(p['median_diff']):+.3f} {_ci(p)}, mean {num(p['mean_diff']):+.3f} {_ci(p, 'mean')}, "
         f"{p['n_pos']} worse / {p['n_neg']} better of {p['n']} files, {p['verdict']}")
    if not short:
        s += f"; per T: {_pt(p)}" + (" [per-T sign reversal]" if p.get("per_T_reversal") else "")
    return s


def _dstr(S, key, m="adm_rmse_pct", short=False):
    return _pp(_pd(S, key, m), short)


def _verdict(S, key, m="adm_rmse_pct"):
    return _pd(S, key, m)["verdict"]


def _v(p):
    return p["verdict"]


def _memcert(V, key):
    cs = [V[key][T].get("certificate") for T in V[key]]
    if not all(cs):
        return "-"
    if all(c["L_s"] is None for c in cs):
        return "full"
    m = [c.get("memory_certified") for c in cs]
    if any(x is None for x in m):
        return "-"
    return "yes" if all(m) else ("no" if not any(m) else "partly")


def _row(S, V, key, lab=None):
    s = S[key]
    by = s["adm_rmse_pct_by_T"]
    cert = "-" if s["certified_all_T"] is None else ("yes" if s["certified_all_T"] else "no")
    head = (f"| {lab or s['label']} | {cert} | {_memcert(V, key)} | {s['n_files']} | {_g(s['adm_rmse_pct'])} | "
            f"{_g(by.get('0'))} / {_g(by.get('25'))} / {_g(by.get('45'))} | {_g(s['whole_post_rmse_pct'])} | "
            f"{_g(s['adm_within2_pct'], 1)} |")
    if key == "frozen_TFO":
        return head + " - | - | - | - | - | reference |"
    p, pw = _pd(S, key), _pd(S, key, "whole_post_rmse_pct")
    per = " / ".join(f"{v['mean']:+.3f} ({v['n_pos']}/{v['n']})" for v in p["per_T"].values())
    return head + (f" {num(p['median_diff']):+.3f} {_ci(p)} | {num(p['mean_diff']):+.3f} {_ci(p, 'mean')} | "
                   f"{p['n_pos']}/{p['n_neg']} | {per}{' (reversal)' if p['per_T_reversal'] else ''} | "
                   f"{num(p['wilcoxon_p']):.2g} | {p['verdict']} (whole: {pw['verdict']}) |")


HDR = ("| variant | DC cert. | memory cert. (eps_z) | n files | adm. RMSE | 0 / 25 / 45 C | whole RMSE | within 2 % (adm.) | "
       "d median [strat. 95 % CI] | d mean [strat. 95 % CI] | files worse/better | per-T mean d (files worse/n) | "
       "Wilcoxon p | verdict adm. (whole) |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")


def run_count(J):
    from collections import Counter
    cnt = Counter(r["variant"] for r in J["test"]["rows"])
    by = Counter(cnt.values())
    return len(J["test"]["rows"]), " + ".join(f"{n} variants x {k} runs" for k, n in sorted(by.items(), reverse=True)), len(cnt)


def write_report(J):
    c, ab, dt, est = cfg()
    S, V, s1, fd = J["summary"], J["freeze"]["variants"], J["stage1"], J["figure_data"]
    tol = float(dt["structure_selection"]["tie_tol_pct"])
    ref = S["frozen_TFO"]
    files = J["test"]["files"]
    sb = ab["review_response"]["stratified_bootstrap"]
    nrun, rc, nvar = run_count(J)
    L = ["# Ablation and sensitivity of the tempered fractional observer (E3)", "",
         f"Generated by `scripts/07_ablation.py` from `results/ablation.json` ({J['generated_utc']}, code hash "
         f"{J['code_hash']}, config sha256 {J.get('config_yaml_sha256', '')[:12]}...). Settings: config `ablation` (declared "
         f"before the first run; `ablation.review_response` added before the re-run that answers the two reviews). "
         f"Everything not ablated is the frozen configuration (`results/frozen_config.json`, sha256 "
         f"{J['frozen_config_sha256'][:12]}..., unchanged by this task).", "",
         "## Protocol", "",
         f"* Stage 1 (identification and validation files only): re-identifications (lambda fixed at L = 400 s; the 04c "
         f"protocol with the original and with a widened box), equal-budget gain tuning of every new variant "
         f"({dt['tuning']['budget_evals']} validation evaluations each, the P2 protocol), certificates; frozen in "
         f"`results/ablation.json['freeze']` at {J['freeze']['frozen_utc']} (variants sha256 "
         f"{J['freeze'].get('variants_sha256', '')}), before any test file was loaded. Validation files verified: "
         f"{all(v['verified'] for v in s1['validation_files'].values())}.",
         f"* Stage 2: {len(files)} test files (all pass `data.verify_file`: {all(f['verified'] for f in files)}) x "
         f"{len(ab['scenarios'])} initial-SOC scenarios ({', '.join(ab['scenarios'])}): {nrun} runs = {rc} ({nvar} variants; "
         f"variants defined at only some temperatures have fewer files: the three temperature-mismatch variants run on the "
         f"12 files of the other temperatures, the near-optimal restart variants of section (7) only at their own "
         f"temperature; n is given in every row). "
         f"Test profile durations {_g(min(f['duration_s'] for f in files), 0)}-{_g(max(f['duration_s'] for f in files), 0)} s.",
         "* Metrics: PRIMARY for certified claims = admissible post-convergence SOC RMSE (t - t0 >= 600 s and reference SOC "
         "in [0.10, 0.95], the interval of the certificate's slope bounds); the whole-profile post-convergence RMSE is "
         "reported with every verdict. d = per-file (mean over the 3 scenarios) difference variant minus reference.",
         f"* Statistics: the files of one temperature share a cell, a parameter set and a gain set, so the pairs are "
         f"DEPENDENT within temperature and only three temperature clusters exist; every interval is a temperature-"
         f"stratified percentile bootstrap ({sb['n_boot']} draws, files resampled within each temperature) of the median "
         f"and of the mean of d; the Wilcoxon p (metrics.paired_difference) is shown for reference only. Verdict: "
         f"'equivalent' only if BOTH 95 % intervals lie inside +-{tol} % SOC (TOST-style; '(consistent sign)' when they "
         f"also exclude 0), 'worse'/'better' only if both intervals exclude 0 on the same side, otherwise 'not resolved'. "
         f"Per-T means with the number of files with d > 0 are given with every verdict; '(reversal)' flags per-T means "
         f">= +{tol} and <= -{tol} in the same comparison. Nothing here generalises beyond these 3 temperatures and one cell.",
         f"* DC cert. = (DC) at sigma = 0 with h l1 kappa2 <= 1 and the LP at every temperature of the variant; memory cert. = "
         f"exact discrete truncation-induced SOC bound <= eps_z = {ab['eps_z']} ('full' = no truncation; '-' = not computed).", "",
         f"Reference (frozen TFO, lambda = 1e-4 1/s, L = 400 s, tuned certified gains): admissible RMSE {_g(ref['adm_rmse_pct'])} "
         f"% SOC (0/25/45 C: {_g(ref['adm_rmse_pct_by_T']['0'])} / {_g(ref['adm_rmse_pct_by_T']['25'])} / "
         f"{_g(ref['adm_rmse_pct_by_T']['45'])}), whole-profile {_g(ref['whole_post_rmse_pct'])} % SOC, within +-2 % "
         f"{_g(ref['adm_within2_pct'], 1)} % of admissible samples.", ""]
    L += report_sections(J, S, V, s1, fd, tol)
    L += review_sections(J, S, V, s1, fd, tol)
    rt = J["runtime"]
    L += ["## Runtime", "",
          f"Main wall {_g(rt['main_wall_s'], 0)} s (stage 1 {_g(rt['stage1_wall_s'], 0)} s, of which review "
          f"re-identifications {_g(s1['runtime'].get('identmem_wall_s', 0), 0)} s; stage 2 {_g(rt['stage2_wall_s'], 0)} s), "
          f"main process {_g(rt['main_process_s'], 1)} s, summed worker process time {_g(rt['worker_process_s_sum'], 0)} s "
          f"({rt['workers']} workers; cached tasks keep their original times; machine shared with other experiments).",
          "", "Outputs: `results/ablation.json` (all runs, summaries, figure arrays), `tables/tab_ablation.tex`, "
          "`figures/fig_rmse_memory.pdf`, `figures/fig_sensitivity.pdf`, `figures/fig_params_temperature.pdf`."]
    L += review_response(J, S, V, s1, fd, tol)
    p = ROOT / "reports" / "ablation_findings.md"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p


def _core(PR):
    core = PR["tempered_minus_untempered_same_L"]
    return core, sorted(core, key=float), PR["L"]


def perT_cells(PR, T, tol):
    """(lambda, L) cells at temperature T: mean d, files favouring tempering (d < 0) / untempered (d > 0)."""
    core, lamp, Ls = _core(PR)
    out = []
    for l in lamp:
        for x in Ls:
            v = core[l][x]["adm_rmse_pct"]["per_T"][str(T)]
            out.append(dict(lam=l, L=x, mean=v["mean"], n_neg=v["n_neg"], n_pos=v["n_pos"], n=v["n"]))
    return out


def val_selected(J):
    """Validation-selected arms: lambda = 0 at the L (grid + full) with the lowest mean validation objective, and the
    lambda > 0 with the lowest mean validation objective at full memory (tuning.json grid + stage-1 full tunings)."""
    _, _, dt, _ = cfg()
    tu = load_json("tuning.json")
    g = {(q["T"], float(q["lam"]), q["L"]): q["best_objective"] for q in tu["grid"]}
    tf = {(q["key"], q["T"]): q["best_objective"] for q in J["stage1"]["tuning"]}
    lamg = [float(v) for v in dt["lambda_grid"]]
    obj0 = {str(L): float(np.mean([g[(T, 0.0, L)] for T in TEMPS])) for L in [int(v) for v in dt["L_grid_s"]]}
    obj0["full"] = float(np.mean([tf[("curve_0_full", T)] for T in TEMPS]))
    objf = {f"{l:g}": float(np.mean([tf[(f"curve_{l:g}_full", T)] for T in TEMPS])) for l in lamg if l > 0}
    L0 = min(obj0, key=obj0.get)
    lf = min(objf, key=objf.get)
    return dict(L0=L0, lam_full=lf, obj0=obj0, objf=objf)


def report_sections(J, S, V, s1, fd, tol):
    _, ab, dt, _ = cfg()
    gd = load_json("gain_design.json")
    pcm = {(p["T"], float(p["lam"]), p["L"]): p for p in gd["post_certificates"]}
    PR = J["pairs"]
    rows = J["test"]["rows"]
    L = []
    core, lamp, Ls = _core(PR)
    fin = [x for x in Ls if x != "full"]
    curh = fd["memory"]["curves"]
    hz_t = [num(curh[l]["certified_horizon_s"][str(T)]) for l in lamp for T in TEMPS]
    hz_u = [num(curh["0"]["certified_horizon_s"][f"{T}_log10_untempered"]) for T in TEMPS]
    L0 = int(frozen()["methods"]["TFO"]["structure"]["L"])
    vk = {v: sum(1 for l in lamp for x in Ls if _v(core[l][x]["adm_rmse_pct"]).startswith(v))
          for v in ("worse", "better", "equivalent", "not resolved")}
    # per-temperature summary of the core question
    bullets = []
    for T in TEMPS:
        cells = perT_cells(PR, T, tol)
        bf = [c for c in cells if c["L"] != "full"]
        neg = [c for c in bf if c["mean"] < 0]
        all_t = [c for c in cells if c["n_neg"] == c["n"]]
        big = [c for c in all_t if c["mean"] <= -tol]
        txt_neg = ", ".join(f"lambda {c['lam']}, L {c['L']}: {c['mean']:+.4f}" for c in neg)
        txt_all = ", ".join(f"lambda {c['lam']}, L {c['L']}" for c in all_t)
        txt_big = ", ".join(f"lambda {c['lam']}, L {c['L']}: {c['mean']:+.3f}" for c in big)
        s = (f"**{T} C:** tempering lowers the mean error at the same bounded L in {len(neg)} of {len(bf)} (lambda, L) "
             f"cells" + (f" ({txt_neg})" if neg else "") + f"; all {cells[0]['n']} files favour tempering in {len(all_t)} "
             f"cells (bounded or full memory)" + (f" ({txt_all})" if all_t else "") +
             (f", beyond the {tol} % SOC tie tolerance in {len(big)} ({txt_big})" if big else "") + ".")
        bullets.append(s)
    b400 = core[lamp[0]][str(L0)]["adm_rmse_pct"]
    ts = PR["extra"]["curve_0_1600__minus__curve_0.001_full"]["adm_rmse_pct"]
    vs = val_selected(J)
    vsp = pair(rows, f"curve_0_{vs['L0']}", f"curve_{vs['lam_full']}_full")["adm_rmse_pct"]
    onset = {}
    for T in TEMPS:
        cells = perT_cells(PR, T, tol)
        ok = [x for x in Ls if any(c["L"] == x and c["n_neg"] == c["n"] for c in cells)]
        onset[T] = ok[0] if ok else None
    short = [x for x in fin if all(onset[T] is None or Ls.index(x) < Ls.index(onset[T]) for T in TEMPS)]
    head = ("* **Does tempering lower the SOC error at a fixed memory budget? Not at short memories: at L <= "
            f"{short[-1] if short else '-'} s no lambda > 0 is better on all files at any temperature. It does, consistently, "
            "only at long memories: from " + ", ".join((f"L = {onset[T]} s" if onset[T] != "full" else "full memory") +
                                                       f" at {T} C" for T in TEMPS if onset[T]) +
            " (first L at which some lambda > 0 is better on all 6 files), i.e. where tempering stands in for the "
            "truncation of a long history.**")
    R7 = J["review"]
    scale = max([abs(r["mean"]) for r in R7["model_swap"]] + [r["soc_range"] or 0.0 for r in R7["restarts"]])
    gains = [(T, c) for T in TEMPS for c in perT_cells(PR, T, tol) if c["mean"] < 0 and c["n_neg"] == c["n"]]
    above = [(T, c) for T, c in gains if -c["mean"] > scale]
    L += ["## Answer in brief", "",
          head + " Each candidate has its own re-identified model and its own tuned gains. Per temperature (admissible "
          "window, mean d = lambda > 0 minus lambda = 0 at the same L; the whole profile agrees, section (6)):"] + [
          f"  * {b}" for b in bullets] + [
          f"  * Pooled over the 18 files the verdicts of the {len(lamp) * len(Ls)} cells are: " +
          ", ".join(f"{k} {n}" for k, n in vk.items()) + ". The pooled median is dominated by the 12 files at 25/45 C and "
          "must not be read as 'no effect at any temperature'. At the 400 s budget lambda = 1e-4 minus 0: " + _pp(b400) + ".",
          f"  * Scale: swapping one near-equivalent identified model for another at the same (lambda, L), or taking another "
          f"near-optimal restart, moves the per-T SOC RMSE by up to {_g(scale, 3)} % SOC (section (7)). Of the "
          f"{len(gains)} per-T cells in which tempering is better on every file, {len(above)} exceed that scale ("
          + ", ".join(f"{T} C lambda {c['lam']} L {c['L']}: {c['mean']:+.3f}" for T, c in above) + "); the others are "
          f"within the model-selection variability of the identified models.",
          f"* **Tempering chiefly buys a finite certified memory; where it lowers the error it stands in for a long or full "
          f"memory.** L_z*(0.5 %) = {_g(min(hz_t), 0)}-{_g(max(hz_t), 0)} s "
          f"for lambda = {lamp[0]}-{lamp[-1]} vs 10^{_g(min(hz_u), 1)}-10^{_g(max(hz_u), 1)} s untempered. At full memory "
          f"lambda > 0 lowers the error of the untempered full-memory observer ({_g(S['curve_0_full']['adm_rmse_pct'])} % SOC; "
          + "; ".join(f"lambda {l}: {_pp(core[l]['full']['adm_rmse_pct'], True)}" for l in lamp[:3]) + "). Truncation "
          f"without tempering vs tempering at full memory: post-hoc comparison of the two TEST minima (lambda = 0 at "
          f"L = 1600 s minus lambda = 1e-3 at full memory) {_pp(ts)}: it favours truncation at "
          f"{', '.join(T + ' C' for T, v in ts['per_T'].items() if v['mean'] < 0) or 'no temperature'} and full-memory "
          f"tempering at {', '.join(T + ' C' for T, v in ts['per_T'].items() if v['mean'] > 0) or 'no temperature'}. The "
          f"VALIDATION-selected arms are lambda = 0 at L = {vs['L0']} s and lambda = {vs['lam_full']} at full memory"
          + (" - the same two configurations, so the comparison is not an artefact of test-set selection."
             if (vs["L0"], vs["lam_full"]) == ("1600", "0.001") else f": {_pp(vsp)}."),
          f"* **Components that help (removing them is 'worse' in the stratified test):** the fractional order (RCL observer "
          f"{_dstr(S, 'rcl', short=True)}); memory itself (lambda = 0, L = 50 s minus L = {L0} s: "
          f"{_pp(pair(rows, 'curve_0_50', f'curve_0_{L0}')['adm_rmse_pct'], True)}); the model temperature (every "
          f"temperature-mismatch variant is worse).",
          f"* **Not shown to help:** the certificate constraint - it is INACTIVE at the tuned optimum (unconstrained tuning "
          f"ends inside the certified set: {_dstr(S, 'gain_unconstrained', short=True)}; l2 = 2 l2_sup at the tuned l1: "
          f"{_dstr(S, 'gain_l2_over', short=True)}); the l1 degradation at l1 = {ab['gain_variants']['l1_pos_factor']}/(h kappa2) "
          f"is a bandwidth effect already present inside the positivity bound (section (3)); the l2 injection (l2 = 0: "
          f"{_dstr(S, 'gain_l2_zero', short=True)}); tuning beyond the LMI design ({_dstr(S, 'gain_lmi_design', short=True)}); "
          f"any physically motivated lambda (identified: {_dstr(S, 'lambda_identified', short=True)}; relaxation: "
          f"{_dstr(S, 'lambda_relaxation', short=True)}); identifying the parameters at the observer's own memory "
          f"(contradicted by the memory ablation, section (7)).", ""]
    groups = [("(1) Tempering rate at L = 400 s, each model re-identified at that memory, own tuned gains",
               ["frozen_TFO", "lambda_zero", "lambda_identified", "lambda_identified_at_memory", "lambda_relaxation"]),
              ("(2) Memory (frozen TFO model and gains; only the memory changes)",
               ["frozen_TFO", "memory_cert", "memory_short", "memory_full"]),
              ("(3) Gains (frozen TFO model and memory)",
               ["frozen_TFO", "gain_lmi_design", "gain_l2_zero", "gain_l2_over"] +
               [f"gain_l1_f{float(f):g}" for f in ab["review_response"]["l1_bandwidth_factors"]] +
               ["gain_l1_positivity", "gain_unconstrained"]),
              ("(4) Fractional order and (5) identification optimiser (L = 400 s, own tuned gains)",
               ["frozen_TFO", "rcl", "opt_trf", "opt_tfgd"])]
    for title, keys in groups:
        L += [f"## {title}", "", HDR] + [_row(S, V, k) for k in keys] + [""]
        if keys[1] == "lambda_zero":
            lr = s1["lambda_relaxation"]
            L += [f"lambda values (1/s), 0/25/45 C: identified {', '.join(_g(V['lambda_identified'][str(T)]['lam']) for T in TEMPS)}; "
                  f"at memory {', '.join(_g(V['lambda_identified_at_memory'][str(T)]['lam']) for T in TEMPS)} "
                  f"(below {_g(1e-7)} = not resolved from 0); relaxation TPL median {', '.join(_g(lr[str(T)]['median']) for T in TEMPS)} "
                  f"(pooled median {_g(lr['0']['all_primary']['median'])}). Per T (mean d, files worse/n): identified "
                  f"{_pt(_pd(S, 'lambda_identified'))}; at memory {_pt(_pd(S, 'lambda_identified_at_memory'))}; relaxation "
                  f"{_pt(_pd(S, 'lambda_relaxation'))}. Re-identification at L = 400 s "
                  f"(identification / validation RMSE, mV; parameters at a bound of the box): " +
                  "; ".join(f"{r['tag']} {r['T']} C {_g(r['rmse_objective_mV'], 2)} / {_g(r['validation']['rmse_mV'], 2)} "
                            f"[{', '.join(r['at_bound']) or 'none'}]" for r in s1["identification"]) +
                  ". These fits are constrained optima (Rp at its 0.5 Ohm upper bound at 0/25 C, alpha at its 0.1 lower bound "
                  "at 45 C), like most rows of identification_memory.json (section (7)); the lambda comparison in (1) is "
                  "conditional on that box.", ""]
        if keys[1] == "memory_cert":
            am = gd["ablation_memory"]["primary"]
            durs = [f["duration_s"] for f in J["test"]["files"]]
            L += [f"L_cert = {', '.join(_g(V['memory_cert'][str(T)]['hyper']['L_s'], 0) for T in TEMPS)} s exceeds every test "
                  f"profile ({_g(min(durs), 0)}-{_g(max(durs), 0)} s), so the certified memory IS full memory on these records "
                  f"(identical results), and L_short = L_cert/10 = {', '.join(_g(V['memory_short'][str(T)]['hyper']['L_s'], 0) for T in TEMPS)} s "
                  f"is LONGER than the frozen 400 s memory. Truncation-induced SOC bound (exact discrete, % SOC) at L_cert / "
                  f"L_short / 400 s: " +
                  "; ".join(f"{T} C {_g(100 * num(am[str(T)]['bound_at_L_cert']['ez_bound_exact']), 2)} / "
                            f"{_g(100 * num(am[str(T)]['bound_at_L_short']['ez_bound_exact']), 1)} / "
                            f"{_g(100 * num(pcm[(T, 1e-4, 400)]['truncation_soc_bound']['ez_bound_exact']), 1)}" for T in TEMPS) +
                  ": only L_cert is memory-certified (column 'memory cert.'); the (DC) stability certificate holds at every "
                  "memory. The frozen parameters were identified WITH the 400 s truncated recursion; running them at another "
                  "memory is a mismatched pairing (section (7)). Short minus full: "
                  f"{_pp(PR['extra']['memory_short__minus__memory_full']['adm_rmse_pct'])}.",
                  f"Cost: {_g(S['frozen_TFO']['wall_per_run_s_median'], 3)} s (N_L = 400), "
                  f"{_g(S['memory_short']['wall_per_run_s_median'], 3)} s (L_short), {_g(S['memory_cert']['wall_per_run_s_median'], 3)} s "
                  f"(L_cert) and {_g(S['memory_full']['wall_per_run_s_median'], 3)} s (full) median wall time per test run; state "
                  f"bytes {TM.cost_per_sample(400)['bytes']} (N_L = 400) vs "
                  f"{', '.join(str(TM.cost_per_sample(int(V['memory_cert'][str(T)]['hyper']['L_s']))['bytes']) for T in TEMPS)} (L_cert) "
                  f"vs {8 * (2 * max(f['n_samples'] for f in J['test']['files']) + 8)} (full memory, longest test profile): on "
                  f"records shorter than L_cert the certified finite memory is more expensive than full memory; its advantage "
                  f"is a cost that stays bounded on records of any length.", ""]
        if keys[1] == "gain_lmi_design":
            fl = [float(f) for f in ab["review_response"]["l1_bandwidth_factors"]] + [float(ab["gain_variants"]["l1_pos_factor"])]
            kk = [f"gain_l1_f{f:g}" for f in fl[:-1]] + ["gain_l1_positivity"]
            L += ["Frozen gains l1 = " + ", ".join(_g(V["frozen_TFO"][str(T)]["hyper"]["l1"], 4) for T in TEMPS) +
                  " 1/(V s), l2 = " + ", ".join(_g(V["frozen_TFO"][str(T)]["hyper"]["l2"], 4) for T in TEMPS) +
                  " s^-alpha (0/25/45 C). l1 sweep at the frozen l2 (l1 = f/(h kappa2); f <= 1 is inside the positivity "
                  "bound, f = 1.5 violates it): " + "; ".join(
                      f"f = {f:g}: l1/l1_tuned = {', '.join(_g(V[k][str(T)]['hyper']['l1'] / V['frozen_TFO'][str(T)]['hyper']['l1'], 0) for T in TEMPS)}, "
                      f"DC cert. {S[k]['certified_all_T']}, adm. RMSE {_g(S[k]['adm_rmse_pct'])}" for f, k in zip(fl, kk)) +
                  f". The certified control f = {fl[-2]:g} vs the uncertified f = {fl[-1]:g}: "
                  f"{_pp(pair(rows, 'gain_l1_positivity', kk[-2])['adm_rmse_pct'])}. The error grows with the SOC-loop "
                  f"bandwidth inside the certified set; the step across h l1 kappa2 = 1 adds "
                  f"{_g(S['gain_l1_positivity']['adm_rmse_pct'] - S[kk[-2]]['adm_rmse_pct'])} % SOC to the "
                  f"{_g(S[kk[-2]]['adm_rmse_pct'] - S['frozen_TFO']['adm_rmse_pct'])} % SOC already lost at f = {fl[-2]:g}. "
                  f"The unconstrained tuning (box l1 <= {ab['gain_variants']['unconstrained_l1_factor']}/(h kappa2), l2 <= "
                  f"{ab['gain_variants']['unconstrained_l2_max']}) returned certified gains at every T: "
                  f"{S['gain_unconstrained']['certified_all_T']}: on these data the certificate is not binding and neither "
                  f"helps nor hurts accuracy.", ""]
        if keys[1] == "rcl":
            L += [f"TFGD minus CMA-ES/TRF parameters: {_pp(PR['extra']['opt_tfgd__minus__opt_trf']['adm_rmse_pct'])}. Both "
                  f"are full-memory fits run at L = 400 s (a mismatched memory pairing, section (7)). RCL: alpha = 1 limit "
                  f"evaluated at alpha = 1 - {ab['rcl_alpha_eps']:g} (max weight deviation "
                  f"{_g(max(s1['rcl_weight_check_max_abs'].values()))}).", ""]
    L += section6(J, S, V, fd, tol, pcm)
    return L


def section6(J, S, V, fd, tol, pcm):
    PR = J["pairs"]
    core, lamp, Ls = _core(PR)
    cur = fd["memory"]["curves"]
    L = ["## (6) Tempering at a fixed memory budget (Figure 7)", "",
         "Pooled: mean admissible SOC RMSE over the 54 test runs (% SOC) and, for lambda > 0, the median of d = lambda "
         "minus lambda = 0 at the same L with the pooled verdict (W worse, B better, E equivalent, - not resolved; "
         "stratified bootstrap).", "",
         "| L (s) | lambda = 0 | " + " | ".join(f"lambda = {l}" for l in lamp) + " |", "|---" * (2 + len(lamp)) + "|"]
    code = {"worse": "W", "better": "B", "equivalent": "E", "not resolved": "-"}
    for i, x in enumerate(Ls):
        m0 = cur["0"]["adm_full"] if x == "full" else cur["0"]["adm_mean"][i]
        cells = []
        for l in lamp:
            ml = cur[l]["adm_full"] if x == "full" else cur[l]["adm_mean"][i]
            p = core[l][x]["adm_rmse_pct"]
            cells.append(f"{_g(ml)} ({num(p['median_diff']):+.3f} {code[p['verdict'].split(' (')[0]]})")
        L.append(f"| {x} | {_g(m0)} | " + " | ".join(cells) + " |")
    L += ["", "Per temperature: mean d over the 6 files (% SOC) and the number of files on which tempering is WORSE "
          "(d > 0) / BETTER (d < 0); admissible window.", ""]
    for T in TEMPS:
        L += [f"{T} C:", "", "| L (s) | " + " | ".join(f"lambda = {l}" for l in lamp) + " |", "|---" * (1 + len(lamp)) + "|"]
        for x in Ls:
            cs = []
            for l in lamp:
                v = core[l][x]["adm_rmse_pct"]["per_T"][str(T)]
                cs.append(f"{v['mean']:+.4f} ({v['n_pos']}/{v['n_neg']})")
            L.append(f"| {x} | " + " | ".join(cs) + " |")
        L.append("")
    wh = {T: [c for l in lamp for x in Ls for c in [core[l][x]["whole_post_rmse_pct"]["per_T"][str(T)]]] for T in TEMPS}
    ad = {T: [c for l in lamp for x in Ls for c in [core[l][x]["adm_rmse_pct"]["per_T"][str(T)]]] for T in TEMPS}
    agree = {T: sum(1 for a, w in zip(ad[T], wh[T]) if np.sign(a["mean"]) == np.sign(w["mean"])) for T in TEMPS}
    L += [f"Whole-profile window: the per-T sign of the mean d agrees with the admissible window in " +
          ", ".join(f"{agree[T]}/{len(ad[T])} cells at {T} C" for T in TEMPS) + "; lambda = 1e-4 minus 0 (pooled, whole): " +
          "; ".join(f"L {x}: {_pp(core['0.0001'][x]['whole_post_rmse_pct'], True)}" for x in Ls if x in ("400", "1600", "full")) + ".",
          "",
          "Certified horizons L_z*(eps_z = 0.5 %) of each lambda row at L = 400 s with its tuned l2 (s, 0/25/45 C): " +
          "; ".join(f"lambda {l}: " + ", ".join(_g(cur[l]["certified_horizon_s"][str(T)], 0) for T in TEMPS) for l in lamp) +
          "; lambda = 0: log10 L = " + ", ".join(_g(cur["0"]["certified_horizon_s"].get(f"{T}_log10_untempered"), 1) for T in TEMPS) +
          f". Median test profile length {', '.join(_g(fd['profile_duration_median_s'][str(T)], 0) for T in TEMPS)} s; "
          f"lambda rows whose certified horizon exceeds the LONGEST test record at every T: "
          f"{', '.join(l for l in lamp if all(num(cur[l]['certified_horizon_s'][str(T)]) > max(f['duration_s'] for f in J['test']['files']) for T in TEMPS)) or 'none'} "
          "(for those, full memory is the shortest memory with the eps_z guarantee on these records; Figure 7 plots "
          "'full' at the median profile length). Worst lambda (highest mean) per L: " +
          ", ".join(f"L {x}: {max(lamp + ['0'], key=lambda l: cur[l]['adm_full'] if x == 'full' else cur[l]['adm_mean'][i])} "
                    f"({_g(max(cur[l]['adm_full'] if x == 'full' else cur[l]['adm_mean'][i] for l in lamp))})" for i, x in enumerate(Ls)) + ".",
          "Test minima (descriptive; no selection on test data): " +
          ", ".join(f"L {b['L']}: lambda {b['argmin_lambda']:g}" for b in fd["memory"]["best_by_L"] if b["argmin_lambda"] > 0) +
          "; lambda = 0 at every other L.",
          f"Truncation SOC bound at L = 400 s (exact discrete, % SOC, 0/25/45 C): lambda = 0 " +
          ", ".join(_g(100 * num(pcm[(T, 0.0, 400)]["truncation_soc_bound"]["ez_bound_exact"]), 0) for T in TEMPS) +
          "; lambda = 1e-4 " + ", ".join(_g(100 * num(pcm[(T, 1e-4, 400)]["truncation_soc_bound"]["ez_bound_exact"]), 1) for T in TEMPS) +
          " (neither certifies eps_z = 0.5 %; the measured errors are far below both bounds).", ""]
    sd = fd["sensitivity"]
    L += ["## Sensitivity (frozen TFO unless stated)", "", HDR] + [_row(S, V, k) for k in
          ("alpha_-0.1", "alpha_+0.1", "h_2", "h_5", "h_10", "Tused_0", "Tused_25", "Tused_45")] + [""]
    L += [f"* alpha +-0.1 (gains frozen, certificate still holds: "
          f"{all(all(v) for v in sd['alpha']['certified'].values())}): alpha used " +
          "; ".join(f"{T} C {', '.join(_g(a) for a in sd['alpha']['alpha_used'][str(T)])}" for T in TEMPS) +
          ". The error is sensitive to alpha with the other parameters held: a certified observer is not a robust one.",
          f"* h (memory in seconds, gains re-checked: l1, l2 unchanged by the h rule, certified at every h: "
          f"{all(all(v) for v in sd['h']['certified'].values())}; sigma* (1/s) at h = 10 s: " +
          ", ".join(_g(sd['h']['sigma_star'][str(T)][-1]) for T in TEMPS) + "). Verdicts vs h = 1 s: " +
          ", ".join(f"h = {k[2:]} s {_verdict(S, k)}" for k in ("h_2", "h_5", "h_10")) + ".",
          "* Temperature: the model of another temperature is 'worse' in every case (n = 12 files per row).", ""]
    P = fd["params_T"]["series"]
    L += ["## Temperature-dependent parameters (Figure 10)", "",
          "TFO (full memory, causal_full) with 95 % bootstrap intervals ('*' = interval not quotable: > 2.5 % of draws at a bound): " +
          "; ".join(f"{k} " + ", ".join(f"{_g(P['TFO'][k]['value'][j])} [{_g(P['TFO'][k]['ci_lo'][j])}, {_g(P['TFO'][k]['ci_hi'][j])}]"
                                        f"{'' if P['TFO'][k]['ci_valid'][j] else '*'}" for j in range(3))
                    for k in ("alpha", "lam", "R0", "R_1s_Ohm")) +
          ". Edge R0 (Ohm): " + ", ".join(_g(v, 4) for v in P["R0_edge"]["value"]) +
          ". Frozen TFO at L = 400 s: alpha " + ", ".join(_g(v) for v in P["TFO_L400_frozen"]["alpha"]["value"]) +
          ". The lambda intervals reach 0 at every temperature.", ""]
    L += ["## Caveats", "",
          "* Convergence time (+-2 %, whole profile) is 'never' in most runs of every variant because the end-of-discharge "
          f"region (reference SOC < 0.10) drives the error out of the band (reference: {S['frozen_TFO']['n_not_converged']}/54); "
          "the admissible window is the primary metric for that reason.",
          f"* SOC clipping at [-0.05, 1.05] is active near the cut-off in every variant (reference: {S['frozen_TFO']['soc_clip_total']} "
          "samples over 54 runs); it is outside the admissible window.",
          "* All hyper-parameters of the new variants were tuned on the validation files only and frozen before the test "
          "files were loaded; test-set differences between memories are descriptive and do not change the freeze.",
          "* Inherited from scripts/05_design_tune.py: the admissible observer interval behind kappa1/kappa2 (tuning boxes, "
          "l1_max, certificates) is mapped with Q_ref(T), the median throughput of the SP2 dynamic files at T, which include "
          "test files. Section (8) repeats every certificate with the Q_ref-free interval.", ""]
    return L


def review_data(J):
    """Numbers of the review sections (7)-(8), stored in results/ablation.json['review'] and read by the report."""
    _, ab, dt, _ = cfg()
    rr = ab["review_response"]
    rows, S, V, s1 = J["test"]["rows"], J["summary"], J["freeze"]["variants"], J["stage1"]
    tol = float(dt["structure_selection"]["tie_tol_pct"])
    out = {}
    out["pairing"] = {f"{a}__minus__{b}": pair(rows, a, b) for a, b in
                      (("memory_full", "curve_0.0001_full"), ("memory_short", "curve_0.0001_3200"),
                       ("opt_trf", "frozen_TFO"), ("frozen_TFO", "curve_0.0001_full"))}
    lamg = [float(v) for v in dt["lambda_grid"]]
    lsub = [l for l in lamg if l <= 1e-3]
    flat = []
    for T in TEMPS:
        for L in [int(v) for v in dt["L_grid_s"]] + ["full"]:
            v = [mem_row(T, "FO_trunc" if l == 0 else "TFO_grid", L, None if l == 0 else l)["rmse_objective_mV"] for l in lsub]
            z = [S[f"curve_{l:g}_{L}"]["adm_rmse_pct_by_T"][str(T)] for l in lsub]
            flat.append(dict(T=T, L=str(L), dV_mV=max(v) - min(v), dsoc_pct=max(z) - min(z)))
    out["flatness"] = dict(lambda_subset=lsub, rows=flat)
    ab_rows = []
    for T in TEMPS:
        for r in memory_rows(T):
            if r["config"] in ("FO_trunc", "TFO_grid"):
                ab_rows.append(dict(T=T, L=str(r["L"]), lam=0.0 if r["config"] == "FO_trunc" else float(r["lam_fixed"]),
                                    at_bound=list(r["at_bound"])))
    out["active_bounds"] = dict(n=len(ab_rows), n_at_bound=sum(1 for r in ab_rows if r["at_bound"]), rows=ab_rows)
    bc = rr["bounds_check"]
    im = {(r["bset"], int(r["T"]), float(r["lam"]), str(r["L"])): r for r in s1["identification_memory_review"]}
    wid, sign = [], []
    for T in TEMPS:
        for L in [str(x) for x in bc["L_s"]]:
            for l in [float(x) for x in bc["lambda"]]:
                r = im[("widened", T, l, L)]
                wid.append(dict(T=T, L=L, lam=l, rmse_mV=r["rmse_objective_mV"], rmse_orig_mV=r["original"]["rmse_objective_mV"],
                                at_bound=r["at_bound"], at_bound_orig=r["original"]["at_bound"],
                                Rp=r["theta"]["Rp"], alpha=r["theta"]["alpha"]))
                if l > 0:
                    po = pair(rows, f"curve_{l:g}_{L}", f"curve_0_{L}")["adm_rmse_pct"]["per_T"][str(T)]
                    pw = pair(rows, f"wb_{l:g}_{L}", f"wb_0_{L}")["adm_rmse_pct"]["per_T"][str(T)]
                    sign.append(dict(T=T, L=L, lam=l, orig=po, widened=pw,
                                     same_sign=bool(np.sign(po["mean"]) == np.sign(pw["mean"]))))
    out["widened"] = dict(bounds=bc["widened"], rows=wid, sign=sign)
    ms = []
    for T in TEMPS:
        for L in [str(x) for x in bc["L_s"]]:
            for l in [float(x) for x in bc["lambda"]]:
                p = pair(rows, f"wb_{l:g}_{L}", f"curve_{l:g}_{L}")["adm_rmse_pct"]["per_T"][str(T)]
                ms.append(dict(T=T, L=L, lam=l, mean=p["mean"],
                               dV_mV=im[("widened", T, l, L)]["rmse_objective_mV"] - im[("widened", T, l, L)]["original"]["rmse_objective_mV"]))
    out["model_swap"] = ms
    rs = []
    rst = rr["restarts"]
    for T in TEMPS:
        for l in [float(x) for x in rst["lambda"]]:
            for L in [int(x) for x in rst["L_s"]]:
                ks = [k for k in V if k.startswith(f"rs_{l:g}_{L}_") and str(T) in V[k]]
                z = [S[k]["adm_rmse_pct_by_T"][str(T)] for k in ks]
                r = im[("original", T, l, str(L))]
                rs.append(dict(T=T, lam=l, L=L, n_distinct=len(ks), soc_range=(max(z) - min(z)) if z else None,
                               reproduces_row=abs(r["rmse_objective_mV"] - r["original"]["rmse_objective_mV"]) < 1e-6,
                               n_within_tol=sum(1 for q in r["runs"] if q["rmse_mV"] <= r["rmse_objective_mV"] + float(rst["tol_mV"]))))
    out["restarts"] = rs
    qc = [(k, T, V[k][T]["certificate"]) for k in V for T in V[k] if V[k][T].get("certificate")]
    out["qfree"] = dict(n=len(qc), changed=[f"{k}@{T}" for k, T, c in qc if c["certified"] != c["qfree"]["certified"]],
                        kappa2_ratio={T: V["frozen_TFO"][T]["certificate"]["kappa2"] / V["frozen_TFO"][T]["certificate"]["qfree"]["kappa2"]
                                      for T in V["frozen_TFO"]},
                        kappa1_ratio={T: V["frozen_TFO"][T]["certificate"]["kappa1"] / V["frozen_TFO"][T]["certificate"]["qfree"]["kappa1"]
                                      for T in V["frozen_TFO"]})
    out["tol"] = tol
    return out


def review_sections(J, S, V, s1, fd, tol):
    R = J["review"]
    L = ["## (7) Model selection, parameter bounds and memory pairing", ""]
    pg = R["pairing"]
    L += ["**Memory pairing.** Mismatched minus matched parameter/memory pairings (admissible):",
          f"* frozen L = 400 s parameters run at full memory minus the full-memory re-identified lambda = 1e-4 model: "
          f"{_pp(pg['memory_full__minus__curve_0.0001_full']['adm_rmse_pct'])}.",
          f"* frozen parameters at L_short minus the lambda = 1e-4 model re-identified at 3200 s: "
          f"{_pp(pg['memory_short__minus__curve_0.0001_3200']['adm_rmse_pct'])}.",
          f"* full-memory CMA-ES/TRF parameters run at L = 400 s minus the frozen (identified at 400 s): "
          f"{_pp(pg['opt_trf__minus__frozen_TFO']['adm_rmse_pct'])}.",
          "Matching the identification memory to the observer memory is therefore NOT established as a component that "
          "helps: the per-T signs above differ between temperatures and between comparisons, and the per-T magnitudes (up "
          f"to {_g(max(abs(v['mean']) for p in pg.values() for v in p['adm_rmse_pct']['per_T'].values()), 3)} % SOC) exceed "
          "the tempering effects of (6) at L <= 1600 s. The best 18-file test score of the study "
          f"({min((k for k in S if S[k]['n_files'] == 18), key=lambda k: S[k]['adm_rmse_pct'])}, "
          f"{_g(min(s['adm_rmse_pct'] for s in S.values() if s['n_files'] == 18))} % SOC) is not a validation-selected "
          "configuration.", ""]
    fl = R["flatness"]["rows"]
    L += [f"**Flat voltage fit.** Across lambda in {R['flatness']['lambda_subset']} at a fixed L, the identification RMSE "
          f"varies by {_g(min(r['dV_mV'] for r in fl))}-{_g(max(r['dV_mV'] for r in fl))} mV while the per-T test SOC RMSE "
          f"varies by {_g(min(r['dsoc_pct'] for r in fl))}-{_g(max(r['dsoc_pct'] for r in fl))} % SOC (per (T, L): " +
          "; ".join(f"{r['T']} C L {r['L']}: {_g(r['dV_mV'], 3)} mV / {_g(r['dsoc_pct'], 3)} %" for r in fl) +
          "). SOC accuracy is only loosely tied to voltage-fit quality across near-equivalent identified models.", ""]
    ab_ = R["active_bounds"]
    L += [f"**Active parameter bounds.** {ab_['n_at_bound']} of {ab_['n']} FO_trunc/TFO_grid rows of "
          "identification_memory.json (the models of every Figure 7 point) end at a bound of the box (lambda columns 0 ... "
          "1e-2; '-' = interior):", "", "| T | L (s) | " + " | ".join(f"lambda = {l:g}" for l in sorted({r['lam'] for r in ab_['rows']})) + " |",
          "|---" * (2 + len({r['lam'] for r in ab_['rows']})) + "|"]
    lams = sorted({r["lam"] for r in ab_["rows"]})
    for T in TEMPS:
        for Lx in dict.fromkeys(r["L"] for r in ab_["rows"] if r["T"] == T):
            m = {r["lam"]: r for r in ab_["rows"] if r["T"] == T and r["L"] == Lx}
            L.append(f"| {T} | {Lx} | " + " | ".join(",".join(m[l]["at_bound"]) or "-" for l in lams) + " |")
    wd = R["widened"]
    L += ["", f"**Widened box** (alpha in {wd['bounds']['alpha']}, Rp in {wd['bounds']['Rp']} Ohm; 04c protocol, "
          "identification + validation files only, own equal-budget tuned gains). Identification RMSE change (mV) and "
          "parameters still at a bound:", "",
          "| T | L | " + " | ".join(f"lambda = {l:g}" for l in sorted({r['lam'] for r in wd['rows']})) + " |",
          "|---" * (2 + len({r['lam'] for r in wd['rows']})) + "|"]
    wl = sorted({r["lam"] for r in wd["rows"]})
    for T in TEMPS:
        for Lx in dict.fromkeys(r["L"] for r in wd["rows"] if r["T"] == T):
            m = {r["lam"]: r for r in wd["rows"] if r["T"] == T and r["L"] == Lx}
            L.append(f"| {T} | {Lx} | " + " | ".join(
                f"{m[l]['rmse_mV'] - m[l]['rmse_orig_mV']:+.3f}; {','.join(m[l]['at_bound']) or '-'} "
                f"(Rp {_g(m[l]['Rp'], 3)}, alpha {_g(m[l]['alpha'], 3)})" for l in wl) + " |")
    sg = wd["sign"]
    L += ["", f"Sign of the per-T mean d (lambda minus 0 at the same L) with the original vs the widened box: the same in "
          f"{sum(r['same_sign'] for r in sg)} of {len(sg)} (T, lambda, L) cells; " +
          "; ".join(f"{T} C: " + ", ".join(f"{r['lam']:g}/{r['L']} {r['orig']['mean']:+.3f} -> {r['widened']['mean']:+.3f}"
                                         for r in sg if r["T"] == T) for T in TEMPS) + ".", ""]
    ms = R["model_swap"]
    L += ["**Model-selection variability.** Swapping the original-box optimum for the widened-box optimum at the SAME "
          "(lambda, L) (identification RMSE change " + f"{_g(min(r['dV_mV'] for r in ms), 3)} to {_g(max(r['dV_mV'] for r in ms), 3)} mV) "
          "changes the per-T test SOC RMSE by " + "; ".join(
              f"{T} C: median |d| {_g(float(np.median([abs(r['mean']) for r in ms if r['T'] == T])), 3)}, max "
              f"{_g(max(abs(r['mean']) for r in ms if r['T'] == T), 3)} % SOC" for T in TEMPS) +
          ". Near-optimal restarts of the original 04c identification (objective within "
          f"{cfg()[1]['review_response']['restarts']['tol_mV']} mV): " + "; ".join(
              f"{r['T']} C lambda {r['lam']:g} L {r['L']}: {r['n_within_tol']} starts, {r['n_distinct']} distinct"
              + (f", SOC range {_g(r['soc_range'], 3)}" if r["n_distinct"] > 1 else "") for r in R["restarts"]) +
          f". The 04c rows are reproduced exactly: {all(r['reproduces_row'] for r in R['restarts'])}. The lambda effects of "
          "(6) should be read against this model-selection scale.", ""]
    q = R["qfree"]
    L += ["## (8) Certificates without the test-derived Q_ref", "",
          f"All {q['n']} (variant, T) certificates were recomputed with kappa1/kappa2 on the reference interval [0.10, 0.95] "
          f"itself (Q_id mapping only). kappa2(Q_ref) / kappa2(Q_id) = " +
          ", ".join(f"{T} C {_g(v, 4)}" for T, v in q["kappa2_ratio"].items()) + "; kappa1 ratio " +
          ", ".join(f"{_g(v, 4)}" for v in q["kappa1_ratio"].values()) + f". Certification verdicts that change: "
          f"{len(q['changed'])} ({', '.join(q['changed']) or 'none'}). The frozen tuning boxes are unchanged (frozen "
          f"configuration); the statement in capacity.json that Q_ref is never given to an estimator is inaccurate for the "
          f"certificate bookkeeping of scripts/05 and 07 and is flagged upstream.", ""]
    return L


def _old_rule(p):
    """first-version verdict (pooled bootstrap of the median; 'equivalent' if |median| < tol) -- for the review response."""
    md, lo, hi, tol = num(p["median_diff"]), num(p["ci_lo"]), num(p["ci_hi"]), float(p["tol"])
    return "equivalent" if abs(md) < tol else ("worse" if lo > 0 else ("better" if hi < 0 else "not resolved"))


def review_response(J, S, V, s1, fd, tol):
    R = J["review"]
    PR = J["pairs"]
    core, lamp, Ls = _core(PR)
    nrun, rc, nvar = run_count(J)
    c0 = [c for c in perT_cells(PR, 0, tol) if c["n_neg"] == c["n"]]
    sg = R["widened"]["sign"]
    ch = [f"{k}: {_old_rule(_pd(S, k))} -> {_verdict(S, k)}" for k in sorted(S)
          if k != "frozen_TFO" and not k.startswith(("curve_", "rs_", "wb_")) and _old_rule(_pd(S, k)) != _verdict(S, k)]
    L = ["## Review response", "",
         "Two reviews (statistics/fairness and traceability/leakage) were checked issue by issue; every point below was "
         "re-computed by this script from `results/ablation.json`, and the whole study was re-run end to end (stage 1 "
         "re-frozen, all test runs repeated) after the changes. No frozen hyper-parameter was changed.", "",
         "Fairness/statistics review:",
         f"1. *Pooling hides an opposite 0 C effect* - valid. The core question is now reported per temperature (Answer in "
         f"brief; per-T tables in (6); Figure 7 already has one panel per T). At 0 C all 6 files favour tempering in "
         f"{len(c0)} (lambda, L) cells ({', '.join(f'{c['lam']}/{c['L']}' for c in c0)}); the headline no longer says "
         f"'at any bounded memory' without the temperature qualifier.",
         f"2. *'equivalent' was not an equivalence test* - valid. Verdicts now need both stratified 95 % intervals (median "
         f"and mean) inside +-{tol} % SOC for 'equivalent' and both outside 0 for 'worse'/'better'; mean d, file counts, "
         f"per-T means, Wilcoxon p and a reversal flag are in every row. Verdicts (sections (1)-(5), sensitivity) that differ from the first version's rule on the same data: "
         f"{'; '.join(ch) if ch else 'none recorded'}.",
         "3. *'identified with the observer's memory helps' contradicted by the memory ablation* - valid. Removed from the "
         "components that help; section (7) gives the mismatched-minus-matched pairings per temperature, the voltage-fit "
         "flatness and the SOC change from swapping near-equivalent identified models, against which the lambda effects "
         "must be read.",
         f"4. *Active parameter bounds* - valid. Section (7) tabulates them ({R['active_bounds']['n_at_bound']}/"
         f"{R['active_bounds']['n']} rows) and re-identifies lambda in {cfg()[1]['review_response']['bounds_check']['lambda']} "
         f"x L in {cfg()[1]['review_response']['bounds_check']['L_s']} with a widened box (identification/validation files, "
         f"own equal-budget gains); the per-T sign of lambda minus 0 is unchanged in {sum(r['same_sign'] for r in sg)}/{len(sg)} "
         f"cells. In the widened box {sum(1 for r in R['widened']['rows'] if 'Rp' in r['at_bound'])}/{len(R['widened']['rows'])} "
         f"fits move Rp to its new 50 Ohm bound (and alpha below 0.1 at 45 C) for an identification-RMSE gain of at most "
         f"{_g(-min(r['rmse_mV'] - r['rmse_orig_mV'] for r in R['widened']['rows']), 3)} mV: the Rp direction is flat "
         f"(a_p -> 0, a near-integrating branch), so the bounds are a regularisation of an unidentified direction.",
         "5. *Positivity ablation measures bandwidth, not the certificate* - valid. Removed from the components that help; "
         "certified controls l1 = f/(h kappa2) with f in " + f"{cfg()[1]['review_response']['l1_bandwidth_factors']} "
         "separate bandwidth from the positivity violation (section (3)); the report states that the certificate is not "
         "active at the tuned optimum.",
         "6. *Dependent pairs / coarse bootstrap* - valid. Temperature-stratified bootstrap for every interval, dependence "
         "stated in the Protocol, no generalisation beyond 3 temperatures and one cell.",
         f"7. *'truncation does at least as well'* - valid. Re-worded as a post-hoc comparison of test minima, with per-T "
         f"signs, and complemented by the validation-selected arms (Answer in brief).",
         f"8. *Bookkeeping* - valid. Run count now {nrun} = {rc}, n per row; 'cert.' split into DC and memory (eps_z) "
         f"certificates; the L_short row relabelled.", "",
         "Traceability/leakage review:",
         "1. *Positivity item* - as fairness item 5.",
         f"2. *Q_ref in the admissible interval* - valid (inherited from 05). Not changed in the frozen boxes; every "
         f"certificate is recomputed without Q_ref in section (8): {len(R['qfree']['changed'])} verdict(s) change.",
         "3. *Cache key* - valid. The cache key now includes a hash of each task's arguments (the variant/job "
         "specification) and the splits/dataset config sections; the freeze stores a sha256 of its variants that stage 2 "
         "checks, and the first freeze time stamp is kept for an unchanged variant set; config.yaml and script sha256 are "
         "stored in the meta block.",
         "4. *Set iteration in summarise()* - valid. Scenarios are sorted; sign counts use |d| > 1e-12.",
         "5. *'72 x 18 x 3'* - valid; see fairness item 8.",
         f"6. *'lambda = 1e-2 about 1.87 everywhere'* - valid; section (6) gives the worst lambda per L with its value.",
         "7. *At-bound status of the lambda-fixed re-identifications* - valid; listed in section (1) with their effect.",
         "8. *'uncertified L_short' with cert. = yes* - valid; see fairness item 8 (L_short is also longer than 400 s).",
         "9. *Figure 7 'full' at 64 ks* - valid. 'full' is now plotted at each temperature's median profile length "
         "(open markers), left of the certified-horizon ticks where L_cert exceeds the record.",
         "10. *config.yaml edited during the run* - informational; the hash now covers the splits and dataset sections and "
         "the meta block records the sha256 of the whole config.yaml used by the run.", ""]
    return L


# ---------------------------------------------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------------------------------------------
def compute(workers):
    c, ab, dt, est = cfg()
    tw0, tc0 = time.perf_counter(), time.process_time()
    meta = dict(generated_utc=now(), script="scripts/07_ablation.py", code_hash=code_hash(), settings=ab,
                input_timing=O.INPUT_TIMING, frozen_config_sha256=sha(RES / "frozen_config.json"),
                config_yaml_sha256=sha(ROOT / "config" / "config.yaml"), script_sha256=sha(Path(__file__)))
    freeze, s1 = stage1(workers)
    jdump(dict(meta, freeze=freeze, stage1=s1, test_files_loaded=False), OUT)        # freeze on disk BEFORE stage 2
    print(f"[stage 1] frozen {freeze['frozen_utc']} ({s1['runtime']['wall_s']:.0f} s wall)", flush=True)
    s2 = stage2(freeze, workers)
    J = dict(meta, freeze=freeze, stage1=s1, test_files_loaded=True, test_started_after_freeze=True, test=s2)
    J["runtime"] = dict(main_wall_s=time.perf_counter() - tw0, main_process_s=time.process_time() - tc0,
                        stage1_wall_s=s1["runtime"]["wall_s"], stage2_wall_s=s2["wall_s"],
                        worker_process_s_sum=s1["runtime"]["worker_process_s_sum"] + s2["worker_process_s_sum"],
                        workers=workers, note="cached tasks report their original times; machine shared with other runs")
    jdump(J, OUT)
    return J


def finalize(J):
    J["summary"] = summarise(J["test"]["rows"], J["freeze"])
    J["figure_data"] = dict(memory=curve_data(J["summary"], J["freeze"]))
    J["pairs"] = pairs_data(J["test"]["rows"])
    J["review"] = review_data(J)
    fn = globals().get("write_outputs")
    if fn is not None:
        fn(J)
    jdump(J, OUT)
    return J


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report-only", action="store_true", help="regenerate summary/figures/table/report from the JSON")
    ap.add_argument("--compute-only", action="store_true", help="stages 1-2 only (no aggregation/report)")
    a = ap.parse_args()
    workers = int(cfg()[1]["max_workers"])
    J = load_json("ablation.json") if a.report_only else compute(workers)
    if a.compute_only:
        print("computed", now(), flush=True)
        return
    finalize(J)
    print("done", now(), flush=True)


if __name__ == "__main__":
    main()
