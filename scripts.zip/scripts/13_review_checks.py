"""Numerical checks behind the revision after the pre-submission review (no data are loaded, nothing is tuned).

Reads only saved results (results/frozen_config.json, results/gain_design.json, results/conservatism.json,
results/clustered_stats.json) and writes results/review_checks.json. Sections:

  operator   D^{alpha,lambda} 1 = lambda^alpha P(1-alpha, lambda t) (lower terminal 0), so the normalized operator
             D_n := D^{alpha,lambda} - lambda^alpha gives D_n 1 = -lambda^alpha Q(1-alpha, lambda t) != 0 for finite t;
             transfer-function identity of the two conventions at the frozen TFO parameters; real zero s* of the
             normalized element for a' < lambda^alpha (worked example) and the endpoint a' = lambda^alpha, whose GL
             free response is exactly V0 e^{-lambda t_n}.
  bounds     truncation-induced SOC bound of the frozen TFO at L = 400 s in three forms: exact discarded-weight tail
             (Corollary cor:m4b:memory(i), first inequality; the value in Table tab:conservatism), Gamma form and the
             closed form e^{-lambda L}/(lambda L^{1+alpha}) of Theorem thm:sampled(iii) of the paper.
  tail       discarded GL weight sum h^-alpha sum_{j>N_L} |omega_j^{(alpha,lambda)}| at N_L = 400 for TFO and FOO
             (untempered weights sum to one), and lambda^alpha at the identified orders.
  ratio      FOO/TFO ratio of the exact-tail bound split into B_p, tail and gain factors.
  stats      number of distinct temperature multisets of the hierarchical bootstrap (3 clusters).

Usage: python scripts/13_review_checks.py
"""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path

import mpmath as mp
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"


def gl_abs_weights(alpha: float, lam: float, h: float, n: int) -> np.ndarray:
    """|omega_j^{(alpha,lambda)}|, j = 0..n (omega_0 = 1)."""
    w = np.empty(n + 1)
    w[0] = 1.0
    d = math.exp(-lam * h)
    for j in range(1, n + 1):
        w[j] = w[j - 1] * (1.0 - (1.0 + alpha) / j) * d
    return np.abs(w)


def tail_sum(alpha: float, lam: float, h: float, n_l: int, n_max: int = 4_000_000) -> float:
    """h^-alpha sum_{j>N_L} |omega_j^{(alpha,lambda)}|, via the complement of the closed-form total."""
    x = math.exp(-lam * h)
    total = 1.0 - (1.0 - x) ** alpha  # sum_{j>=1} |omega_j| x^j (generating function)
    head = gl_abs_weights(alpha, lam, h, n_l)[1:].sum()
    return h ** (-alpha) * (total - head)


def main() -> None:
    fz = json.loads((RES / "frozen_config.json").read_text())
    gd = json.loads((RES / "gain_design.json").read_text())
    h = float(fz["h_s"])
    out: dict = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "script": "scripts/13_review_checks.py",
        "inputs": ["results/frozen_config.json", "results/gain_design.json", "results/conservatism.json",
                   "results/clustered_stats.json"],
    }

    # ---------------- operator ----------------
    op: dict = {}
    for T in ("0", "25", "45"):
        p = fz["methods"]["TFO"]["per_T"][T]["params"]
        al, lam = p["alpha"], p["lam"]
        la = lam ** al
        vals = {}
        for t in (100.0, 1000.0, 10000.0):
            P = float(mp.gammainc(1 - al, 0, lam * t, regularized=True))
            vals[str(int(t))] = {"D_tempered_of_1": la * P, "D_normalized_of_1": -la * (1 - P)}
        # transfer-function identity at a few s (paper element <-> normalized element with a' = a_p + lam^alpha)
        a_p = 1.0 / (p["Rp"] * p["Cp"])
        b_p = 1.0 / p["Cp"]
        a_prime = a_p + la
        rel = 0.0
        for s in (1e-6, 1e-3, 0.1, 1.0, 1j * 0.01, 0.05 + 0.2j):
            H1 = b_p / ((s + lam) ** al + a_p)
            H2 = b_p / ((s + lam) ** al - la + a_prime)
            rel = max(rel, abs(H1 - H2) / abs(H1))
        op[T] = {"alpha": al, "lam": lam, "lam_alpha": la, "values_at_t_s": vals,
                 "tf_identity_max_rel_diff": rel, "dc_gain_paper": b_p / (a_p + la), "dc_gain_normalized": b_p / a_prime}
    # worked example of the normalized-only class (a' < lam^alpha) and the endpoint a' = lam^alpha
    al, lam, ap = 0.5, 0.01, 0.05
    s_star = (lam ** al - ap) ** (1 / al) - lam
    den = (s_star + lam) ** al - lam ** al + ap
    n = 3000
    w = gl_abs_weights(al, lam, 1.0, n) * np.array([1.0] + [-1.0] * n)  # omega_j^{(al,lam)}: omega_0 = 1, others < 0
    W = np.cumsum(gl_abs_weights(al, 0.0, 1.0, n) * np.array([1.0] + [-1.0] * n))  # W_n = sum_{j<=n} omega_j
    V = np.empty(n + 1)
    V[0] = 1.0
    for k in range(1, n + 1):  # a_p = 0 (a' = lam^alpha): sum_j omega_j V_{k-j} - V0 e^{-lam t_k} W_k = 0
        V[k] = -np.dot(w[1:k + 1], V[k - 1::-1]) + V[0] * math.exp(-lam * k) * W[k]
    endpoint_dev = float(np.max(np.abs(V * np.exp(lam * np.arange(n + 1)) - 1.0)))
    op["normalized_example"] = {"alpha": al, "lam": lam, "a_prime": ap, "s_star": s_star, "den_at_s_star": den,
                                "endpoint_a_prime_eq_lam_alpha_max_abs_dev_of_V_exp_lam_t_from_1": endpoint_dev}
    out["operator"] = op

    # ---------------- bounds, tail, ratio ----------------
    pcs = {(x["T"], x["lam"]): x for x in gd["post_certificates"] if x["L"] == 400 and x["lam"] in (0.0, 1e-4)}
    L = 400.0
    bounds, tails, ratio = {}, {}, {}
    for T in (0, 25, 45):
        t = pcs[(T, 1e-4)]
        u = pcs[(T, 0.0)]
        al, lam = t["params"]["alpha"], t["params"]["lam"]
        c_al = al / math.gamma(2 - al)
        Bp = t["B_p_V"]
        g_hL = t["truncation_soc_bound"]["gamma_zp_hL"]
        g_h = t["truncation_soc_bound"]["gamma_zp_h"]
        tail_T = tail_sum(al, lam, h, 400)
        gamma_form = g_h * Bp * c_al * lam ** al * float(mp.gammainc(-al, lam * L))
        closed = g_h * Bp * c_al * math.exp(-lam * L) / (lam * L ** (1 + al))
        bounds[str(T)] = {
            "exact_tail_bound": g_hL * Bp * tail_T,
            "exact_tail_bound_saved": t["truncation_soc_bound"]["ez_bound_exact"],
            "gamma_form_bound": gamma_form,
            "gamma_form_bound_saved": t["truncation_soc_bound"]["ez_bound_chain"],
            "closed_form_bound_thm_sampled_iii": closed,
            "gamma_zp_hL": g_hL, "gamma_zp_h": g_h, "B_p_V": Bp, "C_alpha": c_al}
        alu = u["params"]["alpha"]
        tail_U = tail_sum(alu, 0.0, h, 400)
        tails[str(T)] = {
            "TFO": {"alpha": al, "lam": lam, "lam_alpha": lam ** al, "tail_sum_NL400": tail_T,
                    "total_tempered_mass": 1 - (1 - math.exp(-lam * h)) ** al},
            "FOO": {"alpha": alu, "lam": 0.0, "tail_sum_NL400": tail_U,
                    "check_equals_W_400": abs(tail_U - (1.0 - gl_abs_weights(alu, 0.0, h, 400)[1:].sum()))},
            "same_alpha_untempered_tail_NL400": tail_sum(al, 0.0, h, 400)}
        bu = u["truncation_soc_bound"]["ez_bound_exact"]
        bt = t["truncation_soc_bound"]["ez_bound_exact"]
        ratio[str(T)] = {
            "bound_ratio_FOO_over_TFO": bu / bt,
            "B_p_ratio": u["B_p_V"] / t["B_p_V"],
            "tail_ratio": tail_U / tail_T,
            "gain_ratio": u["truncation_soc_bound"]["gamma_zp_hL"] / g_hL,
            "log_share_B_p": math.log(u["B_p_V"] / t["B_p_V"]) / math.log(bu / bt),
            "B_p_FOO_V": u["B_p_V"], "B_p_TFO_V": t["B_p_V"],
            "Rp_FOO_ohm": u["params"]["Rp"], "Rp_TFO_ohm": t["params"]["Rp"]}
    out["bounds_L400"] = bounds
    out["tail_L400"] = tails
    out["ratio_FOO_over_TFO"] = ratio
    cs = json.loads((RES / "conservatism.json").read_text())
    out["conservatism_bound_saved"] = {T: cs["summary"]["TFO"][T]["bound"] for T in ("0", "25", "45")}

    # ---------------- stats ----------------
    out["hierarchical_distinct_temperature_multisets"] = math.comb(3 + 3 - 1, 3)
    (RES / "review_checks.json").write_text(json.dumps(out, indent=1, default=float))
    print(json.dumps(out, indent=1, default=float))


if __name__ == "__main__":
    main()
