"""P1 (2): memory-budget identification study (causal timing, parameter set chosen in results/identification_refined.json).

For L in config memory_identification.L_s (finite memories N_L = ceil(L/h) and full memory) and every temperature, the
identification file is re-fitted with the SAME finite-memory implicit GL scheme the observers use
(identify.ProblemNL -> model.simulate(N_L)):
    FO_trunc   lambda = 0, alpha, Rp, Cp, s, dq free (+ R0 if the chosen set leaves it free)
    TFO_trunc  lambda free
    TFO_grid   lambda fixed on memory_identification.lambda_grid
Reported per (T, L, configuration): identification-file RMSE (whole, z >= 0.1, admissible reference-SOC interval),
validation-file open-loop RMSE with the same N_L (same three windows), fitted parameters, bound flags, the plant bound
B_p and the truncation bounds (tempered.truncation_bound 'gamma' with f_sup = B_p, the untempered bound at the same
alpha, the exact discrete worst case).  Test files are never loaded.

Writes results/identification_memory.json (+ results/identification_memory_runs/ caches) and regenerates
reports/identification_refined_findings.md through scripts/04b_identify_refined.py.
Usage: python scripts/04c_memory_identification.py [--resume]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import identify as ID  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import tempered as TM  # noqa: E402

_spec = importlib.util.spec_from_file_location("ident04b", ROOT / "scripts" / "04b_identify_refined.py")
B4 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(B4)
I4 = B4.I4

RES = ROOT / "results"
OUT = RES / "identification_memory.json"
CACHE = RES / "identification_memory_runs"
TEMPS = (0, 25, 45)
CONFIGS = ("FO_trunc", "TFO_trunc", "TFO_grid")
TIMING = "causal"
LAM_ZERO = float(D.load_config()["identification_study"]["lambda_zero_report"])   # lambda reported (and bounded) as 0 below this
EXACT_MIN_LAM = 1.0e-5   # exact discrete worst case evaluated only for lambda = 0 or lambda >= this (cost ~40/lambda terms)
TASK_VERSION = "P1-memory-2026-09-27-a"


def cfg():
    c = D.load_config()
    return c, dict(c["identification_study"]), dict(c["memory_identification"]), dict(c["identification_refined"])


def refined() -> dict:
    with open(RES / "identification_refined.json", "r", encoding="utf-8") as fh:
        return json.load(fh)


def code_hash() -> str:
    c, s, m, r = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([s, m, r], sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("src/tfso/model.py", "src/tfso/identify.py", "src/tfso/tempered.py", "src/tfso/data.py", "src/tfso/ocv.py",
              "results/capacity.json", "results/ocv_fits.json"):
        h.update((ROOT / f).read_bytes())
    R = refined()
    h.update(json.dumps([R["decision"]["chosen"], R["chosen_parameter_sets"], R.get("R0_edge_Ohm")], sort_keys=True).encode())
    return h.hexdigest()[:16]


def N_of(L, h: float):
    return None if L == "full" else int(math.ceil(float(L) / h))


def chosen_treatment(R: dict) -> dict:
    ch = R["decision"]["chosen"]
    return dict(chosen=ch, window="knee" if ch == "causal_knee" else "full",
                R0_fixed={T: (float(R["R0_edge_Ohm"][str(T)]) if ch == "edge_R0" else None) for T in TEMPS})


def bounds_block(fam: str, th: dict, H: MD.History, ocv, L, N_L, I_max: float) -> dict:
    """B_p (plant bound) and the truncation bounds of one fitted configuration."""
    p = MD.TFOParams(**{k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})
    Vp = MD.simulate(p, H, ocv, N_L=N_L, window=slice(H.i0, H.i0 + 1), timing=TIMING)["Vp"]
    Vbar = float(abs(Vp[0]))
    Bp = float(TM.plant_bound(p.a_p, p.b_p, p.lam, p.alpha, I_max, Vbar))
    out = dict(I_max_A=I_max, Vbar_p0_V=Vbar, B_p_V=Bp, a_p=p.a_p, b_p=p.b_p)
    if L == "full" or not (0.0 < p.alpha < 1.0):
        out.update(trunc_gamma=None, trunc_untempered=None, trunc_exact_discrete=None,
                   note="full memory (no truncation)" if L == "full" else "alpha at 1: bounds not defined")
        return out
    Ls = float(L)
    # lambda below lambda_zero_report (1e-7) is reported as 0 and treated as 0 in the bounds; the exact discrete tail sum
    # (tempered.worst_case_remainder) needs ~40/lambda terms and is not evaluated for 0 < lambda < EXACT_MIN_LAM
    lam_b = p.lam if p.lam >= LAM_ZERO else 0.0
    exact = None if 0.0 < lam_b < EXACT_MIN_LAM else float(TM.worst_case_remainder(p.alpha, lam_b, H.h, int(N_L), Bp))
    out.update(lambda_used=lam_b, trunc_gamma=float(TM.truncation_bound(p.alpha, lam_b, Ls, Bp, "gamma")),
               trunc_untempered=float(TM.untempered_truncation_bound(p.alpha, Ls, Bp)),
               trunc_exact_discrete=exact,
               units="V s^-alpha (remainder of the GL operator; f_sup = B_p)")
    out["ratio_gamma_over_untempered"] = out["trunc_gamma"] / out["trunc_untempered"]
    return out


def rmse3(r: np.ndarray, z: np.ndarray, soc_ref: np.ndarray, zmin: float, adm) -> dict:
    m = z >= zmin
    a = (soc_ref >= adm[0]) & (soc_ref <= adm[1])
    f = lambda x: float(np.sqrt(np.mean(x ** 2)) * 1e3)
    return dict(rmse_mV=f(r), rmse_z_ge_knee_mV=f(r[m]), rmse_admissible_mV=f(r[a]))


def task_TL(T: int, L) -> dict:
    """All configurations at one (T, L)."""
    c, s, mc, rc = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    R = refined()
    tr = chosen_treatment(R)
    ref = R["chosen_parameter_sets"][str(T)]
    lid = I4.id_file(T)
    vid = [l for l in c["splits"]["validation_dynamic"] if D.CATALOG[l]["temperature_C"] == T][0]
    Fi, Fv = B4.load_file(lid), B4.load_file(vid)
    Hi, Hv = Fi["H"], Fv["H"]
    I_max = float(max(np.max(np.abs(Hi.I[Hi.prof])), np.max(np.abs(Hv.I[Hv.prof]))))
    N_L = N_of(L, Hi.h)
    B, ls = s["bounds"], float(s["lambda_asinh_scale"])
    zmin = float(s["knee_window"]["z_min"])
    adm = tuple(float(x) for x in rc["admissible_soc_interval"])
    mask = I4.knee_mask(Hi, s) if tr["window"] == "knee" else None
    gi = MD.FFTGrid(Hi.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    gv = MD.FFTGrid(Hv.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    base_fixed = {} if tr["R0_fixed"][T] is None else {"R0": tr["R0_fixed"][T]}
    specs = [("FO_trunc", "FO", None), ("TFO_trunc", "TFO", None)] + [("TFO_grid", "TFO", float(v)) for v in mc["lambda_grid"]]
    out = dict(T=T, L=L, N_L=N_L, window=tr["window"], chosen=tr["chosen"], R0_fixed=tr["R0_fixed"][T], fits=[])
    for cname, fam, lam in specs:
        fixed = dict(base_fixed)
        if lam is not None:
            fixed["lam"] = lam
        prob = ID.ProblemNL(fam, Hi, Fi["ocv"], B, fixed=fixed, lam_scale=ls, grid=gi, timing=TIMING, mask=mask, N_L=N_L)
        seed = int(mc["seeds_lhs"]) + 100 * TEMPS.index(T) + 10 * CONFIGS.index(cname)
        starts = list(ID.lhs_starts(prob.p, int(s["multistart"]), seed))
        warm = dict(ref["FO"] if fam == "FO" else ref["TFO"])
        if lam is not None:
            warm["lam"] = lam
        starts.append(prob.to_u(warm))
        runs = []
        for u0 in starts:
            r = ID.run_trf(prob, u0, max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]))
            runs.append(dict(rmse_mV=r["rmse_mV"], theta=r["theta"], converged=r["converged"], nfev=r["nfev"]))
        b = min(runs, key=lambda q: q["rmse_mV"])
        out["fits"].append(dict(config=cname, family=fam, lam_fixed=lam, best=b,
                                start_rmse_mV=[q["rmse_mV"] for q in runs], warm_start_best=bool(runs[-1] is b),
                                n_within_0p01mV=int(sum(q["rmse_mV"] <= b["rmse_mV"] + 0.01 for q in runs))))
    # nesting: FO_trunc and every TFO_grid point are feasible points of TFO_trunc at the same L
    ft = [f for f in out["fits"] if f["config"] == "TFO_trunc"][0]
    ft["nested_correction"] = None
    for f in out["fits"]:
        if f is not ft and f["best"]["rmse_mV"] < ft["best"]["rmse_mV"] - 1e-9:
            ft["best"] = dict(f["best"]); ft["nested_correction"] = f"from {f['config']} lam={f['lam_fixed']}"
    for f in out["fits"]:
        th = f["best"]["theta"]
        p = MD.TFOParams(**{k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})
        ri = MD.simulate(p, Hi, Fi["ocv"], N_L=N_L, grid=gi, window=Hi.prof, timing=TIMING)["Vt"] - Hi.V[Hi.prof]
        rv = MD.simulate(p, Hv, Fv["ocv"], N_L=N_L, grid=gv, window=Hv.prof, timing=TIMING)["Vt"] - Hv.V[Hv.prof]
        f["identification"] = rmse3(ri, Hi.z[Hi.prof], Fi["soc_ref"], zmin, adm)
        f["validation"] = rmse3(rv, Hv.z[Hv.prof], Fv["soc_ref"], zmin, adm)
        free = [k for k in ID.FAMILY_FREE[f["family"]] if k not in base_fixed and not (k == "lam" and f["lam_fixed"] is not None)]
        at, near = [], []
        for k in free:
            u = ID.unit_position(k, th[k], B, ls)
            if u <= 1e-6 or u >= 1 - 1e-6:
                at.append(k)
            elif u <= float(s["near_bound_unit_tol"]) or u >= 1 - float(s["near_bound_unit_tol"]):
                near.append(k)
        if "lam" in free and th["lam"] < float(s["lambda_zero_report"]) and "lam" not in at:
            at.append("lam")
        f["at_bound"], f["near_bound"] = at, near
        f["bounds"] = bounds_block(f["family"], th, Hi, Fi["ocv"], L, N_L, I_max)
        if f["config"] == "TFO_trunc":
            dep = I4.resid_dependence(ri if mask is None else ri[mask], s, Hi.h)
            f["tau_hac"] = dep["tau"]; f["n_scored"] = dep["n"]
    out.update(files=dict(identification=lid, validation=vid, verified=bool(Fi["verified"] and Fv["verified"])),
               wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)
    return out


def cache(name, obj=None):
    CACHE.mkdir(parents=True, exist_ok=True)
    p = CACHE / name
    if obj is not None:
        I4.jdump(dict(obj, code_hash=code_hash()), p)
        return obj
    if p.exists():
        with open(p, "r", encoding="utf-8") as fh:
            o = json.load(fh)
        if o.get("code_hash") == code_hash():
            return o
    return None


def _task(T, L):
    return cache(f"TL_{T}_{L}.json", task_TL(T, L))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--resume", action="store_true")
    a = ap.parse_args()
    tw0, tc0 = time.perf_counter(), time.process_time()
    c, s, mc, rc = cfg()
    Ls = list(mc["L_s"])
    res, futs = {}, {}
    with ProcessPoolExecutor(max_workers=int(mc["max_workers"])) as ex:
        for T in TEMPS:
            for L in Ls[::-1]:
                cached = cache(f"TL_{T}_{L}.json") if a.resume else None
                if cached is not None:
                    res[(T, L)] = cached
                else:
                    futs[(T, L)] = ex.submit(_task, T, L)
        for k, f in futs.items():
            res[k] = f.result()
            print(f"[done] {k}", flush=True)
    J = assemble(res, Ls, tw0, tc0)
    I4.jdump(J, OUT)
    B4.main_report_only()
    print(f"total wall {time.perf_counter() - tw0:.1f} s, main process {time.process_time() - tc0:.1f} s", flush=True)


def assemble(res: dict, Ls: list, tw0: float, tc0: float) -> dict:
    c, s, mc, rc = cfg()
    R = refined()
    cz = float(s["profile_v2"]["crit_zero"])
    J = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
             script="scripts/04c_memory_identification.py", code_hash=code_hash(), settings=mc, input_timing=TIMING,
             parameter_set=chosen_treatment(R), lambda_grid=mc["lambda_grid"], L_s=Ls,
             note=("finite memory = the observers' truncated implicit GL recursion (identify.ProblemNL -> model.simulate "
                   "N_L), applied over the whole warm-start record (end of CV -> profile end); validation = open loop on "
                   "SP2_<T>_DST_50SOC with the same N_L and warm start; test files not loaded"),
             per_T={})
    for T in TEMPS:
        rows = []
        for L in Ls:
            r = res[(T, L)]
            for f in r["fits"]:
                th = f["best"]["theta"]
                rows.append(dict(L=L, N_L=r["N_L"], config=f["config"], lam_fixed=f["lam_fixed"],
                                 theta={k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")},
                                 rmse_objective_mV=f["best"]["rmse_mV"], identification=f["identification"],
                                 validation=f["validation"], at_bound=f["at_bound"], near_bound=f["near_bound"],
                                 bounds=f["bounds"], converged=f["best"]["converged"],
                                 n_within_0p01mV=f["n_within_0p01mV"], warm_start_best=f["warm_start_best"],
                                 nested_correction=f.get("nested_correction"), tau_hac=f.get("tau_hac"),
                                 n_scored=f.get("n_scored")))
        # lambda evidence per L: TFO_trunc vs FO_trunc on the objective window
        ev = []
        for L in Ls:
            tf = [q for q in rows if q["L"] == L and q["config"] == "TFO_trunc"][0]
            fo = [q for q in rows if q["L"] == L and q["config"] == "FO_trunc"][0]
            grid = [q for q in rows if q["L"] == L and q["config"] == "TFO_grid"]
            LRn = 2 * tf["n_scored"] * math.log(fo["rmse_objective_mV"] / tf["rmse_objective_mV"])
            gb = min(grid, key=lambda q: q["rmse_objective_mV"])
            ev.append(dict(L=L, lambda_hat=tf["theta"]["lam"], alpha_hat=tf["theta"]["alpha"],
                           lambda_positive=bool(tf["theta"]["lam"] >= float(s["lambda_zero_report"])),
                           FO_minus_TFO_objective_mV=fo["rmse_objective_mV"] - tf["rmse_objective_mV"],
                           LR_nominal=LRn, LR_eff=LRn / tf["tau_hac"], excludes_0_eff=bool(LRn / tf["tau_hac"] > cz),
                           best_grid_lambda=gb["lam_fixed"], best_grid_minus_FO_objective_mV=gb["rmse_objective_mV"] - fo["rmse_objective_mV"],
                           validation_FO_minus_TFO_mV=fo["validation"]["rmse_mV"] - tf["validation"]["rmse_mV"],
                           validation_best_config=min((q for q in rows if q["L"] == L),
                                                      key=lambda q: q["validation"]["rmse_mV"])["config"] +
                           ("" if min((q for q in rows if q["L"] == L), key=lambda q: q["validation"]["rmse_mV"])["lam_fixed"] is None
                            else f" lam={min((q for q in rows if q['L'] == L), key=lambda q: q['validation']['rmse_mV'])['lam_fixed']:g}")))
        full_ref = {k: [q for q in rows if q["L"] == "full" and q["config"] == k][0]["rmse_objective_mV"] for k in ("FO_trunc", "TFO_trunc")}
        J["per_T"][str(T)] = dict(rows=rows, lambda_evidence=ev, full_memory_objective_mV=full_ref,
                                  files=res[(T, Ls[0])]["files"],
                                  task_wall_s=float(sum(res[(T, L)]["wall_s"] for L in Ls)),
                                  task_cpu_s=float(sum(res[(T, L)]["cpu_s"] for L in Ls)))
    J["runtime"] = dict(main_wall_s=time.perf_counter() - tw0, main_process_s=time.process_time() - tc0,
                        worker_process_s_sum=float(sum(J["per_T"][str(T)]["task_cpu_s"] for T in TEMPS)),
                        max_workers=int(mc["max_workers"]),
                        note="tasks read from cache report their original times")
    return J


if __name__ == "__main__":
    main()
