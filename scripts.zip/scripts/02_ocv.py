"""OCV-SOC identification from the SP1/SP3 incremental-OCV tests (regenerates everything from the raw data).

Writes
    results/ocv_fits.json     points, hysteresis, model comparison (LOPO + cross-cell), selected model per T,
                              temperature-model test, supported intervals, slope bounds + envelopes, Delta_U, review sensitivities, provenance
    results/ocv_curves.npz    dense-grid curves and slopes used by the figures
    figures/draft_ocv_soc.pdf   OCV points and fitted curves (draft; manuscript figure: scripts/09a_figs_ocv_relax.py)
    figures/draft_ocv_slope.pdf dU/dz on the observer axis with kappa_1, kappa_2 and the supported interval (draft)
    tables/tab_ocv.tex        slope bounds per temperature and interval (booktabs + siunitx)
    reports/ocv_findings.md   findings + review response (scripts/02b_ocv_report.py, from the JSON only)

Usage (from the project root):  python scripts/02_ocv.py
Leakage: only SP1/SP3 incremental-OCV files and the three initial-capacity files are used for the OCV; the
identification files SP2_{T}C_DST_80SOC are read only for their net Ah from full to cutoff (Q_axis = Q_id(T)).
Every raw read is logged (raw_file_reads in the JSON); no validation/test file is read (compute_capacity(include_dynamic=False)).
"""
from __future__ import annotations

import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import ocv as O  # noqa: E402

MV = 1e3


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, float):
        return None if not np.isfinite(o) else o
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, pd.DataFrame):
        return jsonable(o.to_dict(orient="records"))
    return o


# ----------------------------------------------------------------------------------------------
# Capacities and the observer axis
# ----------------------------------------------------------------------------------------------
def q_id_from_profile(lid: str, df: pd.DataFrame) -> dict:
    """Arbin net Ah removed from the end of CV (last step-3 sample) to the end of the profile (last step-7 sample)."""
    step = df[D.COL["step"]].to_numpy()
    Qc, Qd = df[D.COL["Qc"]].to_numpy(), df[D.COL["Qd"]].to_numpy()
    ia = int(np.where(step == 3)[0][-1])
    ie = int(np.where(step == int(D.load_config()["dataset"]["dynamic_profile_step_index"]))[0][-1])
    q = float((Qd[ie] - Qd[ia]) - (Qc[ie] - Qc[ia]))
    return dict(logical_id=lid, Q_id_Ah=q, anchor_row=ia, end_row=ie, V_end=float(df[D.COL["V"]].iloc[ie]),
                definition="(Discharge_Capacity - Charge_Capacity) from the last Step_Index 3 sample to the last "
                           "Step_Index 7 sample (Arbin columns)")


def q_axis_from_capacity_json(cfg_ocv: dict) -> dict | None:
    p = ROOT / "results" / "capacity.json"
    if not p.exists():
        return None
    cap = json.load(open(p, "r", encoding="utf-8"))
    for k in cfg_ocv["q_axis_capacity_json_keys"]:
        if k in cap and isinstance(cap[k], dict):
            out = {}
            for T, v in cap[k].items():
                if isinstance(v, dict):
                    for kk in ("Q_id_Ah", "Q_Ah", "Q_axis_Ah", "value_Ah"):
                        if kk in v:
                            out[str(T)] = float(v[kk])
                            break
                elif isinstance(v, (int, float)):
                    out[str(T)] = float(v)
            if out:
                return dict(key=k, values=out)
    return None


# ----------------------------------------------------------------------------------------------
# Model comparison at one temperature
# ----------------------------------------------------------------------------------------------
def restricted_stats(cc: dict, lo: float, hi: float) -> dict:
    """Cross-cell error statistics restricted to evaluation abscissae inside [lo, hi]."""
    e = np.concatenate([np.asarray(v["err_mV"])[(np.asarray(v["x_eval"]) >= lo - 1e-12) & (np.asarray(v["x_eval"]) <= hi + 1e-12)]
                        for k, v in cc.items() if "->" in k])
    if len(e) == 0:
        return dict(n=0, rmse_mV=None, max_abs_mV=None, x_range=[lo, hi])
    return dict(n=int(len(e)), rmse_mV=float(np.sqrt(np.mean(e**2))), max_abs_mV=float(np.abs(e).max()), x_range=[lo, hi])


def compare_methods(T: int, sets: dict, cfg_ocv: dict, core: tuple) -> dict:
    x = np.concatenate([s.x.to_numpy() for s in sets.values()])
    U = np.concatenate([s.U.to_numpy() for s in sets.values()])
    g = np.concatenate([[c] * len(s) for c, s in sets.items()])
    out = {}
    for meth in cfg_ocv["methods"]:
        t0 = time.time()
        hp, lopo_table = O.select_hp(meth, cfg_ocv, x, U, g)
        m = O.make_model(meth, hp).fit(x, U, g)
        best = [r for r in lopo_table if r["hp"] == hp][0]
        cc = O.cross_cell(meth, cfg_ocv, sets)
        out[meth] = dict(hp=hp, lopo=dict(n=best["n"], rmse_mV=best["rmse_mV"], max_abs_mV=best["max_abs_mV"]),
                         lopo_grid=[dict(hp=r["hp"], n=r["n"], rmse_mV=r["rmse_mV"]) for r in lopo_table],
                         cross_cell=cc, cross_cell_core=restricted_stats(cc, *core), monotone=O.monotone_check(m), in_sample=O.eval_on(m, pd.DataFrame(dict(x=x, U=U))),
                         params=m.params(), model=m, seconds=time.time() - t0)
        print(f"  [{T:2d} C] {meth:12s} hp={ {k: v for k, v in hp.items() if k in ('n_knots', 'lam', 'eps')} } "
              f"LOPO {best['rmse_mV']:.2f} mV  cross-cell {cc['pooled']['rmse_mV']:.2f} / max {cc['pooled']['max_abs_mV']:.2f} mV "
              f"core {out[meth]['cross_cell_core']['rmse_mV']:.2f} mV  monotone={out[meth]['monotone']['monotone']}  ({out[meth]['seconds']:.0f} s)")
    return out


def fit_selected(meth: str, cfg_ocv: dict, s: pd.DataFrame, cell_label="all", groups=None) -> tuple:
    g = np.array([cell_label] * len(s)) if groups is None else groups
    hp, _ = O.select_hp(meth, cfg_ocv, s.x.to_numpy(), s.U.to_numpy(), g)
    return O.make_model(meth, hp).fit(s.x.to_numpy(), s.U.to_numpy(), g), hp


def paired_score_ci(comp: dict, temps: list, a: str, b: str, rng, n_boot: int) -> dict:
    """Difference (a - b) of the selection score (mean over T of the pooled cross-cell RMSE) with a percentile
    bootstrap CI; evaluation points are resampled within each (T, direction) group, paired between the two methods
    (both are evaluated at the same points: the other cell's points inside the training cell's x-range)."""
    groups = []
    for T in temps:
        ca, cb = comp[str(T)][a]["cross_cell"], comp[str(T)][b]["cross_cell"]
        for k in ca:
            if "->" not in k:
                continue
            ea, eb = np.asarray(ca[k]["err_mV"]), np.asarray(cb[k]["err_mV"])
            paired = len(ea) == len(eb) and np.allclose(ca[k]["x_eval"], cb[k]["x_eval"])
            if not paired:
                raise RuntimeError(f"{a} vs {b} at {T} C {k}: evaluation points differ; paired test impossible")
            groups.append((T, ea, eb))

    def stat(idx):
        ra, rb = [], []
        for T in temps:
            sa = np.concatenate([g[1][i] ** 2 for g, i in zip(groups, idx) if g[0] == T])
            sb = np.concatenate([g[2][i] ** 2 for g, i in zip(groups, idx) if g[0] == T])
            ra.append(np.sqrt(sa.mean()))
            rb.append(np.sqrt(sb.mean()))
        return float(np.mean(ra) - np.mean(rb))

    obs = stat([np.arange(len(g[1])) for g in groups])
    boots = np.array([stat([rng.integers(0, len(g[1]), len(g[1])) for g in groups]) for _ in range(n_boot)])
    lo, hi = np.percentile(boots, [2.5, 97.5])
    ea = np.concatenate([g[1] for g in groups])
    eb = np.concatenate([g[2] for g in groups])
    d2 = ea ** 2 - eb ** 2
    return dict(diff_mV=obs, ci95_mV=[float(lo), float(hi)], tied=bool(lo <= 0.0 <= hi), n_points=int(len(ea)),
                n_points_b_better=int((np.abs(eb) < np.abs(ea)).sum()),
                largest_single_point_share_of_sq_diff=float(np.abs(d2).max() / max(np.abs(d2.sum()), 1e-300)),
                definition=f"score({a}) - score({b}); score = mean over T of pooled cross-cell RMSE (mV)")


def align_study(avg: dict, temps: list, cells: list, Qc25: dict, clos: dict, cfg_al: dict) -> dict:
    """Post-hoc alignment of the second cell's charge axis onto the first (x2 = (q2 + dq) / Q2): best free Q2 per T
    (dq = 0), best common Q2 over T, and free (Q2, dq) per T.  Objective: two-way PCHIP cross-cell RMSE inside the
    primary core x-range.  In-sample, 1-2 parameters on 12-23 points: an upper bound of what an axis error explains."""
    from scipy.optimize import minimize
    c1, c2 = cells
    Qlo, Qhi = [float(v) for v in cfg_al["Q_bounds_Ah"]]
    dlo, dhi = [float(v) for v in cfg_al["dq_bounds_Ah"]]
    Qg = np.arange(Qlo, Qhi + 1e-12, 0.0025)
    dg = np.arange(dlo, dhi + 1e-12, 0.002)
    out = {}
    common_obj = np.zeros(len(Qg))
    for T in temps:
        a1, a2 = avg[(T, c1)], avg[(T, c2)]
        core = (max(float(a.x[a.kind == "mean"].min()) for a in (a1, a2)),
                min(float(a.x[a.kind == "mean"].max()) for a in (a1, a2)))
        q2, U2 = a2.x.to_numpy() * Qc25[c2], a2.U.to_numpy()
        f = lambda Q, d: O.alignment_rmse(a1, q2, U2, Q, d, core) * MV  # noqa: E731
        base = f(Qc25[c2], 0.0)
        so = np.array([f(Q, 0.0) for Q in Qg])
        common_obj += so
        k = int(np.argmin(so))
        grid = np.array([[f(Q, d) for d in dg] for Q in Qg])
        i, j = np.unravel_index(int(np.argmin(grid)), grid.shape)
        r = minimize(lambda v: f(v[0], v[1]), x0=[Qg[i], dg[j]], method="Nelder-Mead",
                     options=dict(xatol=1e-5, fatol=1e-4))
        Qb, db = (float(r.x[0]), float(r.x[1])) if r.fun <= grid[i, j] else (float(Qg[i]), float(dg[j]))
        out[str(T)] = dict(core_x=list(core), primary_core_rmse_mV=base,
                           scale_only=dict(Q_Ah=float(Qg[k]), core_rmse_mV=float(so[k]), at_bound=bool(k in (0, len(Qg) - 1))),
                           scale_offset=dict(Q_Ah=Qb, dq_Ah=db, core_rmse_mV=float(min(r.fun, grid[i, j])),
                                             at_bound=bool(not (Qlo < Qb < Qhi and dlo < db < dhi))))
    kc = int(np.argmin(common_obj))
    for T in temps:
        a1, a2 = avg[(T, c1)], avg[(T, c2)]
        core = tuple(out[str(T)]["core_x"])
        out[str(T)]["common_scale"] = dict(Q_Ah=float(Qg[kc]), core_rmse_mV=float(
            O.alignment_rmse(a1, a2.x.to_numpy() * Qc25[c2], a2.U.to_numpy(), Qg[kc], 0.0, core) * MV))
    qcl = [clos[k]["q_final_full_Ah"] for k in clos if clos[k]["available"]]
    return dict(per_temperature=out, fixed_cell=c1, aligned_cell=c2,
                closure_error_range_Ah=[float(min(qcl)), float(max(qcl))],
                note=("x_SP3 = (q + dq) / Q_SP3 with SP1 fixed on its primary axis; objective = two-way PCHIP cross-cell RMSE "
                      "on the primary both-branch core range; in-sample fit of 1-2 parameters, so the RMSE is optimistic"))


def main() -> int:
    t_start = time.time()
    cfg = D.load_config()
    co = cfg["ocv"]
    temps = [int(T) for T in cfg["dataset"]["temperatures_C"]]
    cells = list(co["cells"])
    res_dir, fig_dir, tab_dir = D._path("results"), D._path("figures"), D._path("tables")
    for d in (res_dir, fig_dir, tab_dir):
        d.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ load + verify (every file used)
    used = [f"{c}_IC_OCV_{T}C" for c in cells for T in temps] + D.ids_by(test_type="initial_capacity") \
        + [f"SP2_{T}C_DST_80SOC" for T in temps]
    # review fix: every raw-file read of this stage is recorded (D.load_raw wrapped) and checked against `used`
    loaded, _load_raw = [], D.load_raw

    def _recording_load_raw(lid, *a, **k):
        loaded.append(lid)
        return _load_raw(lid, *a, **k)

    D.load_raw = _recording_load_raw
    dfs, verification = {}, {}
    for lid in used:
        dfs[lid] = D.load_raw(lid)
        chk = D.verify_file(lid, dfs[lid])  # raises DataVerificationError on failure
        verification[lid] = dict(passed=chk["passed"], md5_source=chk.get("md5_source"), n_rows=chk["n_rows"],
                                 split=D.CATALOG[lid]["split"])
        print(f"[verify] {lid:22s} OK ({D.CATALOG[lid]['split']})")

    # ------------------------------------------------------------------ capacities (recomputed from raw)
    # review fix: include_dynamic=False -- the SP2 dynamic files (incl. the validation/test splits) are NOT read here
    cap = D.compute_capacity({k: v for k, v in dfs.items() if "IC_OCV" in k or "INITCAP" in k}, include_dynamic=False)
    D.load_raw = _load_raw
    extra = sorted(set(loaded) - set(used))
    if extra:
        raise RuntimeError(f"files read but not verified/declared: {extra}")
    read_log = dict(n_load_raw_calls=len(loaded), files_read=sorted(set(loaded)),
                    splits_read=sorted({D.CATALOG[lid]["split"] for lid in loaded}),
                    all_read_files_verified=bool(set(loaded) <= set(verification)),
                    method="data.load_raw wrapped for the whole load + capacity stage; every call recorded")
    print(f"[leakage] {len(loaded)} raw reads, splits {read_log['splits_read']}")
    Qc25 = {c: float(cap["initial_capacity_1A_25C_Ah"][c]["Q_Ah"]) for c in cells}
    sp2 = cap["initial_capacity_1A_25C_Ah"]["SP2"]
    Q2 = float(sp2["Q_Ah"])
    Q2_pre = float(sp2["unlogged_pause"]["Q_before_pause_Ah"]) if "unlogged_pause" in sp2 else None
    cap_json = ROOT / "results" / "capacity.json"
    cap_check = None
    if cap_json.exists():
        cj = json.load(open(cap_json, "r", encoding="utf-8"))
        cap_check = {c: abs(cj["initial_capacity_1A_25C_Ah"][c]["Q_Ah"] - cap["initial_capacity_1A_25C_Ah"][c]["Q_Ah"])
                     for c in ("SP1", "SP2", "SP3")}
    qid = {str(T): q_id_from_profile(f"SP2_{T}C_DST_80SOC", dfs[f"SP2_{T}C_DST_80SOC"]) for T in temps}
    ext = q_axis_from_capacity_json(co)
    Q_axis = {}
    for T in temps:
        if ext is not None and str(T) in ext["values"]:
            Q_axis[str(T)] = ext["values"][str(T)]
        else:
            Q_axis[str(T)] = qid[str(T)]["Q_id_Ah"]
    axis = dict(
        x_definition="x = q / Q_cell,25, q = Ah removed from full (end of first CV of the file), Q_cell,25 = 25 C initial 1 A capacity",
        z_definition="z = 1 - q / Q_axis;  U(z; T, Q_axis) = OCV_T((1 - z) Q_axis / Q_SP2,25);  dU/dz = -OCV_T'(x) Q_axis / Q_SP2,25",
        Q_cell25_Ah=Qc25, Q_SP2_25C_Ah=Q2, Q_SP2_25C_before_pause_Ah=Q2_pre,
        Q_SP2_caveat=("SP2_INITCAP 1 A discharge contains an unlogged pause (wall clock advances, Test_Time does not); "
                      "2.0283 Ah total includes charge extracted after the recovery; the pre-pause value is the sensitivity case"),
        Q_axis_Ah=Q_axis, Q_axis_source=(f"results/capacity.json[{ext['key']}]" if ext else
                                         "computed here from the SP2 DST 80SOC files (capacity.json has no Q_id key yet)"),
        Q_id_computed=qid,
        Q_id_capacity_json_minus_computed_Ah=({T: Q_axis[T] - qid[T]["Q_id_Ah"] for T in Q_axis} if ext else None),
        capacity_recomputed_vs_results_capacity_json_abs_diff_Ah=cap_check,
    )
    print("[axis] Q_cell25", {c: round(v, 4) for c, v in Qc25.items()}, "Q_SP2,25", round(Q2, 4),
          "Q_axis", {T: round(v, 4) for T, v in Q_axis.items()})

    # ------------------------------------------------------------------ relaxed points, branches, hysteresis
    mtol = float(co["merge_tol_x"])
    rx = co["relaxation_extrapolation"]
    horizons = [float(h) for h in rx["horizons_s"]]
    h_env = float(rx["envelope_horizon_s"])
    pts, avg, gaps, clos, dis_sets, cc_sets, cc_gaps = {}, {}, {}, {}, {}, {}, {}
    full_sets, ext_pts, ext_avg, ext_gaps = {}, {}, {}, {}
    for T in temps:
        for c in cells:
            lid = f"{c}_IC_OCV_{T}C"
            p = O.classify_points(D.get_ocv_points(lid, dfs[lid], min_rest_s=float(co["min_rest_s"])), Qc25[c])
            pts[(T, c)] = p
            avg[(T, c)], gaps[(T, c)] = O.branch_average(p, merge_tol=mtol)
            if not O.is_strictly_decreasing(avg[(T, c)].U.to_numpy()):
                raise RuntimeError(f"{lid}: branch-averaged OCV points are not strictly decreasing in x")
            clos[(T, c)] = O.closure(p)
            dis_sets[(T, c)] = O.discharge_set(p)
            pe = O.closure_corrected(p, Qc25[c])
            cc_sets[(T, c)], cc_gaps[(T, c)] = O.branch_average(pe, merge_tol=mtol)
            cc_sets[(T, c)]["closure_factor"] = float(pe.closure_factor.iloc[0])
            for fc in ("first", "last"):
                full_sets[(fc, T, c)] = O.branch_average(p, merge_tol=mtol, full=fc)[0]
            segs = D.segments(lid, dfs[lid])
            for h in horizons:
                ph = O.extrapolate_rests(lid, dfs[lid], p, segs, float(rx["t_fit_from_s"]), h, V_col=D.COL["V"], t_col=D.COL["t"])
                ext_pts[(h, T, c)] = ph
                ext_avg[(h, T, c)], ext_gaps[(h, T, c)] = O.branch_average(ph, merge_tol=mtol)

    hyst = {}
    for T in temps:
        per = {}
        for c in cells:
            gp, ge = gaps[(T, c)], cc_gaps[(T, c)]
            k = int(np.argmax(np.abs(gp.gap_V)))
            per[c] = dict(n=int(len(gp)), max_abs_gap_mV=float(abs(gp.gap_V.iloc[k]) * MV), x_at_max=float(gp.x.iloc[k]),
                          mean_gap_mV=float(gp.gap_V.mean() * MV), min_gap_mV=float(gp.gap_V.min() * MV),
                          x_range=[float(gp.x.min()), float(gp.x.max())],
                          closure_corrected_max_abs_gap_mV=float(np.abs(ge.gap_V).max() * MV),
                          closure_factor_charge=float(cc_sets[(T, c)]["closure_factor"].iloc[0]),
                          points=gp.assign(gap_mV=gp.gap_V * MV)[["x", "gap_mV", "U_dis", "U_chg"]])
            ex = {}
            for h in horizons:
                p_h, g_h = ext_pts[(h, T, c)], ext_gaps[(h, T, c)]
                dd = p_h[p_h.branch == "discharge"].dV_extrap * MV
                dc = p_h[p_h.branch == "charge"].dV_extrap * MV
                ex[f"{h / 3600:.0f}h"] = dict(
                    mean_gap_mV=float(g_h.gap_V.mean() * MV), max_abs_gap_mV=float(np.abs(g_h.gap_V).max() * MV),
                    min_gap_mV=float(g_h.gap_V.min() * MV),
                    median_shift_discharge_mV=float(dd.median()), median_shift_charge_mV=float(dc.median()),
                    max_shift_discharge_mV=float(dd.max()), min_shift_charge_mV=float(dc.min()),
                    x_at_max_shift_discharge=float(p_h[p_h.branch == "discharge"].x.iloc[int(np.argmax(dd.to_numpy()))]))
            per[c]["relaxation_extrapolated"] = ex
            per[c]["dV_last_10min_median_abs_mV"] = float(np.median(np.abs(pts[(T, c)].dV_last_10min)) * MV)
            per[c]["dV_last_10min_max_abs_mV"] = float(np.max(np.abs(pts[(T, c)].dV_last_10min)) * MV)
        allg = np.concatenate([gaps[(T, c)].gap_V.to_numpy() for c in cells])
        hx = {}
        for h in horizons:
            ag = np.concatenate([ext_gaps[(h, T, c)].gap_V.to_numpy() for c in cells])
            hx[f"{h / 3600:.0f}h"] = dict(mean_gap_mV=float(ag.mean() * MV), max_abs_gap_mV=float(np.abs(ag).max() * MV),
                                          n_negative=int((ag < 0).sum()), n=int(len(ag)))
        hyst[str(T)] = dict(per_cell=per, max_abs_gap_mV=float(np.abs(allg).max() * MV),
                            mean_gap_mV=float(allg.mean() * MV), half_gap_max_mV=float(np.abs(allg).max() * MV / 2),
                            n_negative=int((allg < 0).sum()), n=int(len(allg)),
                            relaxation_extrapolated=hx,
                            label="apparent hysteresis after a 2 h rest (upper bound of the thermodynamic hysteresis: "
                                  "the rests are still drifting, discharge points upward and charge points downward)",
                            extrapolation_note=(f"log-time extrapolation of each rest (fit t >= {float(rx['t_fit_from_s']):.0f} s) "
                                                "to the horizon; overshoots for tempered tails (negative mean gaps at 24 h are "
                                                "the signature), so 24 h is a stress case and 6 h the bounded variant"),
                            definition="gap = U_charge_branch - U_discharge_branch at the branch_average abscissae (both "
                                       "branches PCHIP-interpolated within their own coverage)")

    # ------------------------------------------------------------------ model comparison (per T)
    comp = {}
    for T in temps:
        sets = {c: avg[(T, c)][["x", "U"]] for c in cells}
        core = (max(float(avg[(T, c)].x[avg[(T, c)].kind == "mean"].min()) for c in cells),
                min(float(avg[(T, c)].x[avg[(T, c)].kind == "mean"].max()) for c in cells))
        comp[str(T)] = compare_methods(T, sets, co, core)
    # selection: minimum mean cross-cell RMSE over temperatures among methods monotone at every temperature
    score = {}
    for meth in co["methods"]:
        mono = all(comp[str(T)][meth]["monotone"]["monotone"] for T in temps)
        mono_cc = all(comp[str(T)][meth]["cross_cell"][k]["monotone"]["monotone"]
                      for T in temps for k in comp[str(T)][meth]["cross_cell"] if "->" in k)
        score[meth] = dict(mean_cross_cell_rmse_mV=float(np.mean([comp[str(T)][meth]["cross_cell"]["pooled"]["rmse_mV"] for T in temps])),
                           max_cross_cell_abs_mV=float(np.max([comp[str(T)][meth]["cross_cell"]["pooled"]["max_abs_mV"] for T in temps])),
                           mean_cross_cell_core_rmse_mV=float(np.mean([comp[str(T)][meth]["cross_cell_core"]["rmse_mV"] for T in temps])),
                           mean_lopo_rmse_mV=float(np.mean([comp[str(T)][meth]["lopo"]["rmse_mV"] for T in temps])),
                           monotone_pooled_all_T=mono, monotone_cross_cell_fits_all_T=mono_cc)
    eligible = [m for m in co["methods"] if score[m]["monotone_pooled_all_T"]]
    sel = min(eligible, key=lambda m: score[m]["mean_cross_cell_rmse_mV"])
    best_per_T = {str(T): min([m for m in co["methods"] if comp[str(T)][m]["monotone"]["monotone"]],
                              key=lambda m: comp[str(T)][m]["cross_cell"]["pooled"]["rmse_mV"]) for T in temps}
    print(f"[select] {sel}  scores: " + ", ".join(f"{m} {score[m]['mean_cross_cell_rmse_mV']:.2f} mV" for m in score))

    # review: hyper-parameters at a grid edge (pooled and cross-cell fits)
    edges = {}
    for T in temps:
        for meth in co["methods"]:
            grid = O.hp_grid(meth, co)
            fl = {"pooled": O.grid_edge(comp[str(T)][meth]["hp"], grid)}
            for k, d in comp[str(T)][meth]["cross_cell"].items():
                if "->" in k:
                    fl[k] = O.grid_edge(d["hp"], grid)
            fl = {k: v for k, v in fl.items() if v}
            if fl:
                edges[f"{T}C/{meth}"] = fl
    for k, v in edges.items():
        print(f"[grid-edge] {k}: {v}")

    # review: statistical tie test of the selection (paired bootstrap) and raw discharge-branch comparison
    rng = np.random.default_rng(int(co["seed"]))
    ties = {m: paired_score_ci(comp, temps, m, sel, rng, int(co["n_boot"])) for m in eligible if m != sel}
    tied = [sel] + [m for m in eligible if m != sel and ties[m]["tied"]]
    raw_dis = {}
    for meth in co["methods"]:
        rr = {str(T): O.cross_cell(meth, co, {c: dis_sets[(T, c)][["x", "U"]] for c in cells})["pooled"] for T in temps}
        raw_dis[meth] = dict(per_temperature=rr, mean_rmse_mV=float(np.mean([rr[str(T)]["rmse_mV"] for T in temps])))
    print("[tie] " + ", ".join(f"{m} - {sel}: {d['diff_mV']:+.2f} mV CI [{d['ci95_mV'][0]:+.2f}, {d['ci95_mV'][1]:+.2f}]"
                               for m, d in ties.items()) + f"  -> tied set {tied}")
    print("[raw discharge sets] " + ", ".join(f"{m} {d['mean_rmse_mV']:.2f}" for m, d in raw_dis.items()))

    # ------------------------------------------------------------------ sensitivity: normalisation of the cell axis
    norm_alt = {"Q_cell25_initial_1A (primary)": Qc25,
                "Q_own_25C_incremental_OCV_total": {c: float(cap["incremental_ocv_total_discharge_Ah"][f"{c}_IC_OCV_25C"]["Q_total_discharge_arbin_Ah"]) for c in cells},
                "common_nominal": {c: float(cfg["dataset"]["cell_nominal_capacity_Ah"]) for c in cells}}
    qref_of = {"Q_SP2_25C": Q2, "nominal": float(cfg["dataset"]["cell_nominal_capacity_Ah"])}
    norm_sens, norm_models = {}, {}
    for name, Qn in norm_alt.items():
        rows = {}
        for T in temps:
            sets_n = {}
            for c in cells:
                pn = pts[(T, c)].copy()
                pn["x"] = pn["q_Ah"] / Qn[c]
                sets_n[c] = O.branch_average(pn, merge_tol=mtol)[0]
            core_n = (max(float(sets_n[c].x[sets_n[c].kind == "mean"].min()) for c in cells),
                      min(float(sets_n[c].x[sets_n[c].kind == "mean"].max()) for c in cells))
            ccn = O.cross_cell(sel, co, {c: sets_n[c][["x", "U"]] for c in cells})
            rows[str(T)] = dict(cross_cell=ccn["pooled"], cross_cell_core=restricted_stats(ccn, *core_n))
            if "primary" not in name:
                pool_n = pd.concat([sets_n[c][["x", "U"]] for c in cells], ignore_index=True)
                g_n = np.concatenate([[c] * len(sets_n[c]) for c in cells])
                nm = dict(pooled=fit_selected(sel, co, pool_n, groups=g_n)[0], Q_ref=qref_of[co["normalisation_Q_ref"][name]])
                for c in cells:
                    nm[f"{c}_only"] = fit_selected(sel, co, sets_n[c][["x", "U"]], c)[0]
                norm_models.setdefault(name, {})[T] = nm
        norm_sens[name] = dict(Q_Ah=Qn, Q_ref_for_z_mapping_Ah=qref_of[co["normalisation_Q_ref"][name]], per_temperature=rows)
    print("[normalisation] " + "; ".join(f"{k}: " + ", ".join(f"{T} C {v['per_temperature'][T]['cross_cell_core']['rmse_mV']:.1f}"
                                                                for T in v["per_temperature"]) + " mV (core)" for k, v in norm_sens.items()))
    # review: post-hoc charge-axis alignment of SP3 onto SP1 (scale and offset), in-sample
    align = align_study(avg, temps, cells, Qc25, clos, co["alignment"])
    print("[alignment] " + ", ".join(f"{T} C: {align['per_temperature'][str(T)]['scale_offset']['core_rmse_mV']:.2f} mV "
                                      f"(dq {align['per_temperature'][str(T)]['scale_offset']['dq_Ah']:+.3f} Ah)" for T in temps))

    # ------------------------------------------------------------------ selected model: pooled, per cell, sensitivities
    models, variants, reps = {}, {}, {}
    for T in temps:
        models[T] = comp[str(T)][sel]["model"]
        v = {}
        for c in cells:
            v[f"{c}_only"], _ = fit_selected(sel, co, avg[(T, c)][["x", "U"]], c)

        def pooled_fit(sets_T, meth=sel):
            pool = pd.concat([sets_T[c][["x", "U"]] for c in cells], ignore_index=True)
            g = np.concatenate([[c] * len(sets_T[c]) for c in cells])
            return fit_selected(meth, co, pool, groups=g)[0]

        v["discharge_branch"] = pooled_fit({c: dis_sets[(T, c)] for c in cells})
        v["closure_corrected_charge_branch"] = pooled_fit({c: cc_sets[(T, c)] for c in cells})
        for fc in ("first", "last"):
            v[f"full_{fc}_rest"] = pooled_fit({c: full_sets[(fc, T, c)] for c in cells})
        v[f"relax_extrap_{h_env / 3600:.0f}h"] = pooled_fit({c: ext_avg[(h_env, T, c)] for c in cells})
        variants[T] = v
        # representation variants: every method statistically tied with the selected one (pooled + per cell) and
        # the Akima-type interpolants through the same nodes
        r = {}
        for meth in tied:
            if meth == sel:
                continue
            r[f"{meth}_pooled"] = comp[str(T)][meth]["model"]
            for c in cells:
                r[f"{meth}_{c}_only"] = fit_selected(meth, co, avg[(T, c)][["x", "U"]], c)[0]
        for meth in co["representation_variants"]:
            r[f"{meth}_pooled"] = pooled_fit({c: avg[(T, c)] for c in cells}, meth)
        reps[T] = r

    # ------------------------------------------------------------------ temperature model test
    doms = [models[T].domain for T in temps]
    xc_lo, xc_hi = max(d[0] for d in doms), min(d[1] for d in doms)
    tt = {}
    Tref = 25
    others = [T for T in temps if T != Tref]
    rng_t = np.random.default_rng([int(co["seed"]), 1])

    def boot_diff(e_h, e_r):
        e_h, e_r = np.asarray(e_h), np.asarray(e_r)
        d = [np.sqrt(np.mean(e_h[rng_t.integers(0, len(e_h), len(e_h))] ** 2))
             - np.sqrt(np.mean(e_r[rng_t.integers(0, len(e_r), len(e_r))] ** 2)) for _ in range(int(co["n_boot"]))]
        lo, hi = np.percentile(d, [2.5, 97.5])
        obs = float(np.sqrt(np.mean(e_h ** 2)) - np.sqrt(np.mean(e_r ** 2)))
        status = "inconclusive" if lo <= 0.0 <= hi else ("fail" if obs > 0 else "pass")
        return dict(diff_mV=obs, ci95_mV=[float(lo), float(hi)], status=status)

    for Th in temps:
        use = [T for T in temps if T != Th]
        Ta, Tb = use
        pts_h = pd.concat([avg[(Th, c)][["x", "U"]] for c in cells], ignore_index=True)
        m = (pts_h.x >= xc_lo) & (pts_h.x <= xc_hi)
        xh = pts_h.x[m].to_numpy()
        Ua, Ub = models[Ta].predict(xh), models[Tb].predict(xh)
        pred = Ua + (Th - Ta) * (Ub - Ua) / (Tb - Ta)
        e = pred - pts_h.U[m].to_numpy()
        ref = restricted_stats(comp[str(Th)][sel]["cross_cell"], xc_lo, xc_hi)
        cc_h = comp[str(Th)][sel]["cross_cell"]
        e_ref = np.concatenate([np.asarray(v["err_mV"])[(np.asarray(v["x_eval"]) >= xc_lo - 1e-12) & (np.asarray(v["x_eval"]) <= xc_hi + 1e-12)]
                                for k, v in cc_h.items() if "->" in k]) / MV
        # symmetric variant: each cell's held-out points predicted from the OTHER cell's per-T models, against the
        # cross-cell reference (the other cell's model at Th) -- both sides use the other cell
        e_sym = []
        for c in cells:
            o = [cc for cc in cells if cc != c][0]
            a = avg[(Th, c)]
            mm = (a.x >= xc_lo) & (a.x <= xc_hi)
            xs = a.x[mm].to_numpy()
            pa, pb = variants[Ta][f"{o}_only"].predict(xs), variants[Tb][f"{o}_only"].predict(xs)
            e_sym.append(pa + (Th - Ta) * (pb - pa) / (Tb - Ta) - a.U[mm].to_numpy())
        e_sym = np.concatenate(e_sym)
        tt[str(Th)] = dict(dUdT_from=[Ta, Tb], n=int(m.sum()), n_outside_common_x=int((~m).sum()),
                           role="interpolation" if Ta < Th < Tb else "extrapolation",
                           rmse_mV=float(np.sqrt(np.mean(e**2)) * MV), max_abs_mV=float(np.max(np.abs(e)) * MV),
                           mean_mV=float(e.mean() * MV), per_T_model_cross_cell_rmse_mV=ref["rmse_mV"],
                           per_T_model_cross_cell_max_mV=ref["max_abs_mV"], per_T_reference_n=ref["n"],
                           reference_note="cross-cell errors of the per-T model restricted to the same common x range",
                           supported=bool(np.sqrt(np.mean(e**2)) * MV <= ref["rmse_mV"]),
                           bootstrap=boot_diff(e * MV, e_ref * MV),
                           symmetric=dict(rmse_mV=float(np.sqrt(np.mean(e_sym**2)) * MV), n=int(len(e_sym)),
                                          reference_rmse_mV=ref["rmse_mV"], bootstrap=boot_diff(e_sym * MV, e_ref * MV),
                                          note="held-out points of each cell predicted from the other cell's per-T models"),
                           x_eval=xh.tolist(), err_mV=(e * MV).tolist())
    xg_c = np.linspace(xc_lo, xc_hi, int(co["n_dense"]))
    Umat = np.vstack([models[T].predict(xg_c) for T in temps])
    Tv = np.array(temps, float)
    A = np.column_stack([np.ones_like(Tv), Tv - Tref])
    coef, *_ = np.linalg.lstsq(A, Umat, rcond=None)
    ls_res = Umat - A @ coef
    decision_unified = all(tt[str(T)]["supported"] for T in others)
    sig_fail = [T for T in tt if tt[T]["bootstrap"]["status"] == "fail"]
    seg = {}
    xm8 = xg_c <= float(co.get("pseudo_ocv_slope_x_max", 0.8))
    for i in range(len(temps) - 1):
        a, b = temps[i], temps[i + 1]
        sl = (models[b].predict(xg_c) - models[a].predict(xg_c)) / (b - a)
        dU = models[b].predict(xg_c) - models[a].predict(xg_c)
        seg[f"{a}-{b}"] = dict(slope_mV_per_K_range_x_le_0p8=[float(sl[xm8].min() * MV), float(sl[xm8].max() * MV)],
                               dU_mV_range_x_le_0p8=[float(dU[xm8].min() * MV), float(dU[xm8].max() * MV)])
    temperature = dict(
        rule=co["unified_temperature_rule"], common_x=[xc_lo, xc_hi], held_out=tt,
        ls_three_T=dict(dUdT_mV_per_K_range=[float(coef[1].min() * MV), float(coef[1].max() * MV)],
                        dUdT_mV_per_K_mean=float(coef[1].mean() * MV),
                        max_abs_residual_mV=float(np.abs(ls_res).max() * MV),
                        rms_residual_mV=float(np.sqrt(np.mean(ls_res**2)) * MV),
                        note="least-squares temperature slope of the 2 h pseudo-OCVs (branch means), NOT an entropic "
                             "coefficient: it is asymmetric between 0-25 and 25-45 C (see pseudo_ocv_slope_by_segment) and "
                             "contains the temperature dependence of the unrelaxed overpotential / apparent hysteresis"),
        pseudo_ocv_slope_by_segment=seg,
        max_abs_OCV_difference_between_T_mV={f"{a}-{b}": float(np.abs(models[a].predict(xg_c) - models[b].predict(xg_c)).max() * MV)
                                             for i, a in enumerate(temps) for b in temps[i + 1:]},
        unified_model_supported=decision_unified,
        significant_failures=sig_fail,
        decision=("unified linear-in-T model supported; per-T fits retained for the observer" if decision_unified else
                  "unified linear-in-T model NOT supported by the pre-declared held-out-temperature rule: separate "
                  "pseudo-OCV_T(x) at 0, 25 and 45 C are used (the observer runs at a fixed chamber temperature per file). "
                  "Significance (bootstrap): the rejection rests on the held-out temperature(s) listed in "
                  "significant_failures; the others are 'inconclusive' or 'pass'"),
    )
    print(f"[temperature] unified supported: {decision_unified}; " +
          ", ".join(f"{T} C held out RMSE {tt[T]['rmse_mV']:.2f} vs {tt[T]['per_T_model_cross_cell_rmse_mV']:.2f} mV "
                    f"({tt[T]['bootstrap']['status']}; symmetric {tt[T]['symmetric']['rmse_mV']:.2f}, "
                    f"{tt[T]['symmetric']['bootstrap']['status']})" for T in tt))

    # ------------------------------------------------------------------ supported intervals, slopes, Delta_U
    thr = float(co["flat_slope_threshold_V_per_soc"])
    knee = float(co["knee_z"])
    ext_name = f"relax_extrap_{h_env / 3600:.0f}h"
    per_T, curves = {}, {}
    for T in temps:
        Qa = Q_axis[str(T)]
        mdl = models[T]
        v, rp = variants[T], reps[T]
        ext_pc = {c: fit_selected(sel, co, ext_avg[(h_env, T, c)][["x", "U"]], c)[0] for c in cells}
        sup = [(float(avg[(T, c)].x.min()), float(avg[(T, c)].x.max())) for c in cells]
        both = [(float(avg[(T, c)].x[avg[(T, c)].kind == "mean"].min()), float(avg[(T, c)].x[avg[(T, c)].kind == "mean"].max())) for c in cells]
        x_sup = (max(s[0] for s in sup), min(s[1] for s in sup))
        x_both = (max(s[0] for s in both), min(s[1] for s in both))
        z_sup_raw = (float(O.x_to_z(x_sup[1], Qa, Q2)), float(O.x_to_z(x_sup[0], Qa, Q2)))
        z_sup = (max(0.0, z_sup_raw[0]), min(1.0, z_sup_raw[1]))
        z_both = (float(O.x_to_z(x_both[1], Qa, Q2)), float(min(1.0, O.x_to_z(x_both[0], Qa, Q2))))
        dom_c = (max(v[f"{c}_only"].domain[0] for c in cells), min(v[f"{c}_only"].domain[1] for c in cells))

        def delta_u(m1, m2, zz, Qr, slope):
            xx = O.z_to_x(zz, Qa, Qr)
            dom = (max(m1.domain[0], m2.domain[0]), min(m1.domain[1], m2.domain[1]))
            mc = (xx >= dom[0] - 1e-12) & (xx <= dom[1] + 1e-12)
            if not mc.any():
                return None
            dU = np.abs(m1.predict(xx[mc]) - m2.predict(xx[mc]))
            k = int(np.argmax(dU))
            return dict(max_mV=float(dU[k] * MV), z_at_max=float(zz[mc][k]), rms_mV=float(np.sqrt(np.mean(dU**2)) * MV),
                        fraction_evaluated=float(mc.mean()), equiv_soc_error_max=float(np.max(dU / slope[mc])))

        def interval_block(z_lo, z_hi, label):
            b = dict(label=label, **O.slope_bounds(mdl, z_lo, z_hi, Qa, Q2))
            zz = np.linspace(z_lo, z_hi, 2001)
            xx = O.z_to_x(zz, Qa, Q2)
            slope = O.soc_axis(mdl, zz, Qa, Q2)[1]
            b["x_interval"] = [float(xx.min()), float(xx.max())]
            b["inside_supported"] = bool(z_lo >= z_sup[0] - 1e-9 and z_hi <= z_sup[1] + 1e-9)
            b["inside_validated"] = b["inside_supported"]  # pre-review name (alias)
            b["fraction_below_supported_z"] = float(max(0.0, z_sup[0] - z_lo) / (z_hi - z_lo))
            b["inside_pooled_fit_domain"] = bool(xx.min() >= mdl.domain[0] - 1e-9 and xx.max() <= mdl.domain[1] + 1e-9)
            b["relaxation_axis_limited"] = bool(z_lo < knee)
            b["kappa2_at_interval_endpoint"] = bool(min(abs(b["z_at_kappa2"] - z_lo), abs(b["z_at_kappa2"] - z_hi)) < 1e-9)
            src = {"data": {k: O.slope_bounds(mv, z_lo, z_hi, Qa, Q2) for k, mv in v.items()}}
            if Q2_pre is not None:
                src["data"]["Q_ref_before_pause"] = O.slope_bounds(mdl, z_lo, z_hi, Qa, Q2_pre)
            src["data"][f"{ext_name}_per_cell_min"] = min((O.slope_bounds(ext_pc[c], z_lo, z_hi, Qa, Q2) for c in cells),
                                                           key=lambda e: e["kappa1_V_per_soc"])
            src["representation"] = {k: O.slope_bounds(mv, z_lo, z_hi, Qa, Q2) for k, mv in rp.items()}
            src["axis"] = {k: O.slope_bounds(nm[T]["pooled"], z_lo, z_hi, Qa, nm[T]["Q_ref"]) for k, nm in norm_models.items()}
            b["variants"] = {s: {k: dict(kappa1=e["kappa1_V_per_soc"], kappa2=e["kappa2_V_per_soc"], z_at_kappa2=e["z_at_kappa2"],
                                         monotone=bool(e["kappa1_V_per_soc"] > 0)) for k, e in d.items()} for s, d in src.items()}
            allk = [("primary", b["kappa1_V_per_soc"], b["kappa2_V_per_soc"])]
            for s, d in src.items():
                for k, e in d.items():
                    if e["kappa1_V_per_soc"] > 0:  # a non-monotone representation cannot serve as an OCV
                        allk.append((f"{s}:{k}", e["kappa1_V_per_soc"], e["kappa2_V_per_soc"]))
            k1 = min(allk, key=lambda r: r[1])
            k2 = max(allk, key=lambda r: r[2])
            b["kappa1_envelope_min_V_per_soc"], b["kappa1_envelope_argmin"] = float(k1[1]), k1[0]
            b["kappa2_envelope_max_V_per_soc"], b["kappa2_envelope_argmax"] = float(k2[2]), k2[0]
            for s, d in src.items():
                ok = [e for e in d.values() if e["kappa1_V_per_soc"] > 0]
                b[f"kappa1_min_{s}_variants"] = float(min(e["kappa1_V_per_soc"] for e in ok)) if ok else None
                b[f"kappa2_max_{s}_variants"] = float(max(e["kappa2_V_per_soc"] for e in ok)) if ok else None
            b["kappa2_per_cell"] = {c: dict(kappa2=src["data"][f"{c}_only"]["kappa2_V_per_soc"],
                                            z_at_kappa2=src["data"][f"{c}_only"]["z_at_kappa2"]) for c in cells}
            b["kappa1_data_upper_bound"] = {
                f"{c}_{kind}": O.min_secant_slope(s_.x.to_numpy(), s_.U.to_numpy(), z_lo, z_hi, Qa, Q2)
                for c in cells for kind, s_ in (("branch_averaged", avg[(T, c)]), ("discharge_raw", dis_sets[(T, c)]))}
            du = {"primary": delta_u(v[f"{cells[0]}_only"], v[f"{cells[1]}_only"], zz, Q2, slope),
                  ext_name: delta_u(ext_pc[cells[0]], ext_pc[cells[1]], zz, Q2, slope)}
            for k, nm in norm_models.items():
                du[f"axis:{k}"] = delta_u(nm[T][f"{cells[0]}_only"], nm[T][f"{cells[1]}_only"], zz, nm[T]["Q_ref"], slope)
            for meth in tied:
                if meth != sel:
                    du[f"representation:{meth}"] = delta_u(rp[f"{meth}_{cells[0]}_only"], rp[f"{meth}_{cells[1]}_only"], zz, Q2, slope)
            p0 = du["primary"]
            b["Delta_U_max_mV"], b["Delta_U_z_at_max"] = p0["max_mV"], p0["z_at_max"]
            b["Delta_U_rms_mV"], b["Delta_U_fraction_of_interval_evaluated"] = p0["rms_mV"], p0["fraction_evaluated"]
            b["Delta_U_equiv_soc_error_max"] = p0["equiv_soc_error_max"]
            b["Delta_U_variants"] = du
            vals = [d["max_mV"] for d in du.values() if d is not None]
            b["Delta_U_range_mV"] = [float(min(vals)), float(max(vals))]
            U0 = mdl.predict(xx)
            b["max_abs_U_primary_minus_discharge_branch_mV"] = float(np.abs(U0 - v["discharge_branch"].predict(xx)).max() * MV)
            b["max_abs_U_primary_minus_relax_extrap_mV"] = float(np.abs(U0 - v[ext_name].predict(xx)).max() * MV)
            if Q2_pre is not None:
                b["max_abs_U_shift_Q_ref_before_pause_mV"] = float(np.abs(U0 - mdl.predict(O.z_to_x(zz, Qa, Q2_pre))).max() * MV)
            return b

        blocks = [interval_block(z_sup[0], z_sup[1], "supported"), interval_block(z_both[0], z_both[1], "both_branch")]
        for zl, zh in co["candidate_z_intervals"]:
            blocks.append(interval_block(float(zl), float(zh), f"[{zl:.2f},{zh:.2f}]"))
        flat = O.flat_regions(mdl, z_sup[0], z_sup[1], Qa, Q2, thr)
        curv = {m: O.max_curvature(comp[str(T)][m]["model"], z_sup[0], z_sup[1], Qa, Q2) for m in co["methods"]}
        per_T[str(T)] = dict(
            method=sel, params=mdl.params(), hp=comp[str(T)][sel]["hp"], Q_axis_Ah=Qa,
            x_support_both_cells=list(x_sup), x_both_branches_both_cells=list(x_both),
            supported_z_interval=list(z_sup), supported_z_interval_unclipped=list(z_sup_raw),
            validated_z_interval=list(z_sup), validated_z_interval_unclipped=list(z_sup_raw),
            z_interval_both_branches=list(z_both),
            support_note=("'supported' (pre-review name 'validated'; alias kept) = covered by relaxed points of both cells, "
                          "NOT validated against held-out data. x_support: intersection over cells of [0 (after-CV anchor), last "
                          "relaxed discharge point]; x_both_branches: intersection of the ranges where charge and discharge "
                          "branches overlap (primary interval for kappa_2); the z interval is clipped to [0, 1] (z < 0 means "
                          "the OCV data extend below the SP2 DST cutoff state; z_lo > 0 means the cutoff state lies below the data)"),
            per_cell_domain_intersection_x=list(dom_c),
            cv=dict(cross_cell=comp[str(T)][sel]["cross_cell"]["pooled"], lopo=comp[str(T)][sel]["lopo"],
                    in_sample=comp[str(T)][sel]["in_sample"]),
            monotone=comp[str(T)][sel]["monotone"], intervals=blocks, flat_regions=flat,
            max_abs_d2Udz2_supported_by_method=curv,
            variant_params={k: mv.params() for k, mv in v.items()},
            representation_params={k: mv.params() for k, mv in rp.items()})
        # dense curves on the observer axis and on x
        zg = np.linspace(0.0, 1.0, int(co["n_dense"]))
        xg = np.linspace(mdl.domain[0], mdl.domain[1], int(co["n_dense"]))
        cur = dict(x=xg, U_x=mdl.predict(xg), dUdx=mdl.deriv(xg), z=zg)
        cur["U_z"], cur["dUdz"] = O.soc_axis(mdl, zg, Qa, Q2)
        for name, mv in v.items():
            cur[f"U_x_{name}"] = mv.predict(xg)
            cur[f"dUdz_{name}"] = O.soc_axis(mv, zg, Qa, Q2)[1]
        for name, mv in rp.items():
            cur[f"dUdz_rep_{name}"] = O.soc_axis(mv, zg, Qa, Q2)[1]
        for name, nm in norm_models.items():
            cur[f"dUdz_axis_{name.split(' ')[0]}"] = O.soc_axis(nm[T]["pooled"], zg, Qa, nm[T]["Q_ref"])[1]
        if Q2_pre is not None:
            cur["dUdz_Q_ref_before_pause"] = O.soc_axis(mdl, zg, Qa, Q2_pre)[1]
        xx = O.z_to_x(zg, Qa, Q2)
        cur["Delta_U_z"] = np.where((xx >= dom_c[0]) & (xx <= dom_c[1]),
                                    np.abs(v[f"{cells[0]}_only"].predict(xx) - v[f"{cells[1]}_only"].predict(xx)), np.nan)
        cur["x_of_z"] = xx
        for meth in co["methods"]:
            cur[f"U_x_method_{meth}"] = comp[str(T)][meth]["model"].predict(xg)
        curves[T] = cur
        vb, bb = blocks[0], blocks[1]
        print(f"[{T:2d} C] supported z [{z_sup[0]:.4f}, {z_sup[1]:.4f}]  kappa1 {vb['kappa1_V_per_soc']:.4f} "
              f"(envelope {vb['kappa1_envelope_min_V_per_soc']:.4f}, {vb['kappa1_envelope_argmin']})  kappa2 {vb['kappa2_V_per_soc']:.4f} "
              f"(envelope {vb['kappa2_envelope_max_V_per_soc']:.4f})  both-branch kappa2 {bb['kappa2_V_per_soc']:.4f}  "
              f"Delta_U {vb['Delta_U_max_mV']:.2f} mV (range {vb['Delta_U_range_mV'][0]:.1f}-{vb['Delta_U_range_mV'][1]:.1f})")

    # ------------------------------------------------------------------ save machine-readable results
    points_out = {}
    for (T, c), p in pts.items():
        ph = ext_pts[(h_env, T, c)]
        points_out.setdefault(str(T), {})[c] = dict(
            logical_id=f"{c}_IC_OCV_{T}C", Q_cell25_Ah=Qc25[c], closure=clos[(T, c)],
            relaxed=p[["cycle", "step", "direction", "branch", "q_Ah", "x", "U", "V_first", "rest_duration_s",
                       "dV_last_10min", "pulse_Ah", "pulse_I_mean"]].assign(
                dV_extrap_envelope_horizon_mV=ph.dV_extrap.to_numpy() * MV, b_mV_per_decade=ph.b_mV_per_decade.to_numpy()),
            branch_averaged=avg[(T, c)], discharge_set=dis_sets[(T, c)],
            closure_corrected_branch_averaged=cc_sets[(T, c)],
            relax_extrap_branch_averaged=ext_avg[(h_env, T, c)])
    repeat = {}
    for T in temps:
        rows = {c: dict(dU_full_points_mV=clos[(T, c)].get("dU_full_points_mV"), q_final_full_Ah=clos[(T, c)].get("q_final_full_Ah"),
                        min_gap_mV=hyst[str(T)]["per_cell"][c]["min_gap_mV"]) for c in cells}
        repeat[str(T)] = dict(per_cell=rows, core_cross_cell_rmse_mV=comp[str(T)][sel]["cross_cell_core"]["rmse_mV"])
    dfull = [abs(r["dU_full_points_mV"]) for d in repeat.values() for r in d["per_cell"].values() if r["dU_full_points_mV"] is not None]
    repeat_summary = dict(per_temperature=repeat, max_abs_dU_full_points_mV=float(max(dfull)),
                          n_negative_gaps_total=int(sum(hyst[str(T)]["n_negative"] for T in temps)),
                          note=("within-cell repeatability: the two after-CV rests of one file (start and end of the test, "
                                "same nominal state) differ by dU_full_points_mV; negative charge-minus-discharge gaps are "
                                "unphysical for a true hysteresis and indicate the noise/closure level"))
    comp_out = {T: {m: {k: vv for k, vv in d.items() if k != "model"} for m, d in cm.items()} for T, cm in comp.items()}
    res = dict(
        generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        script="scripts/02_ocv.py", module="src/tfso/ocv.py", config_section="ocv",
        files_used=verification, raw_file_reads=read_log, axis=axis, points=points_out, hysteresis=hyst,
        model_comparison=dict(per_temperature=comp_out, scores=score, best_per_temperature=best_per_T,
                              selection_rule=co["selection"], tie_rule=co["tie_rule"], tie_test=ties, tied_set=tied,
                              raw_discharge_set_cross_cell=raw_dis, grid_edge_flags=edges,
                              grid_edge_note=("hyper-parameters at the edge of their grid after the review extension; "
                                              "lam at its minimum is the (practically unpenalised) interpolation limit"),
                              spline_solver_status_counts=dict(O.SOLVER_STATUS),
                              core_note="cross_cell_core: errors restricted to x inside the both-branch overlap of both cells"),
        axis_normalisation_sensitivity=dict(method=sel, results=norm_sens,
                                            note="cross-cell errors of the selected method when x = q / Q with alternative per-cell Q"),
        axis_alignment=align,
        repeatability=repeat_summary,
        selected=dict(method=sel, per_temperature=per_T,
                      primary_ocv="mean of charge and discharge branches where both exist (branch_average); "
                                  "single-branch points outside the overlap; full point at x = 0 (mean of the after-CV rests)",
                      sensitivity=("data variants: per cell, discharge branch only, closure-corrected charge branch, first/last "
                                   f"after-CV rest as full point, rests log-extrapolated to {h_env / 3600:.0f} h, Q_SP2,25 before the "
                                   "unlogged pause; representation variants: methods tied with the selected one (pooled and per "
                                   "cell) and Akima/makima through the same nodes; axis variants: alternative cell normalisations"),
                      kappa_note=("kappa_1 is NOT identified by the data (point spacing ~0.1 in SOC): the data only bound it from "
                                  "above (kappa1_data_upper_bound = smallest secant slope); the observer's kappa_1 is a modelling "
                                  "assumption, reported as the envelope minimum over data, representation and axis variants")),
        temperature=temperature,
        leakage=("fits use only SP1/SP3 incremental-OCV relaxed points; capacities from the initial-capacity files "
                 "(data.compute_capacity(include_dynamic=False)); SP2 DST 80SOC (identification split) read only for "
                 "Q_axis = Q_id(T) cross-check; every raw read is logged in raw_file_reads (splits read: "
                 + ", ".join(read_log["splits_read"]) + ")"),
        runtime_s=None,
    )
    npz = {}
    for T, cur in curves.items():
        for k, a in cur.items():
            npz[f"T{T}_{k}"] = np.asarray(a, float)
        for c in cells:
            p = pts[(T, c)]
            for br in ("discharge", "charge", "full"):
                q = p[p.branch == br]
                npz[f"T{T}_{c}_{br}_x"] = q.x.to_numpy(float)
                npz[f"T{T}_{c}_{br}_U"] = q.U.to_numpy(float)
            a = avg[(T, c)]
            npz[f"T{T}_{c}_avg_x"] = a.x.to_numpy(float)
            npz[f"T{T}_{c}_avg_U"] = a.U.to_numpy(float)
            npz[f"T{T}_{c}_avg_resid_mV"] = (models[T].predict(a.x.to_numpy()) - a.U.to_numpy()) * MV
            npz[f"T{T}_{c}_gap_x"] = gaps[(T, c)].x.to_numpy(float)
            npz[f"T{T}_{c}_gap_mV"] = gaps[(T, c)].gap_V.to_numpy(float) * MV
            npz[f"T{T}_{c}_gap_extrap_x"] = ext_gaps[(h_env, T, c)].x.to_numpy(float)
            npz[f"T{T}_{c}_gap_extrap_mV"] = ext_gaps[(h_env, T, c)].gap_V.to_numpy(float) * MV
        vb = per_T[str(T)]["intervals"][0]
        npz[f"T{T}_supported_z"] = np.array(vb["z_interval"])
        npz[f"T{T}_validated_z"] = np.array(vb["z_interval"])
        npz[f"T{T}_kappa"] = np.array([vb["kappa1_V_per_soc"], vb["kappa2_V_per_soc"]])
        npz[f"T{T}_kappa_envelope"] = np.array([vb["kappa1_envelope_min_V_per_soc"], vb["kappa2_envelope_max_V_per_soc"]])
    np.savez_compressed(res_dir / "ocv_curves.npz", **npz)
    res["runtime_s"] = time.time() - t_start
    with open(res_dir / "ocv_fits.json", "w", encoding="utf-8") as fh:
        json.dump(jsonable(res), fh, indent=1)
    print(f"[write] {res_dir / 'ocv_fits.json'}  {res_dir / 'ocv_curves.npz'}")

    # ------------------------------------------------------------------ figures, table and report from the saved results
    make_figures(res_dir / "ocv_curves.npz", res_dir / "ocv_fits.json", fig_dir)
    make_table(res_dir / "ocv_fits.json", tab_dir / "tab_ocv.tex")
    import importlib.util
    spec = importlib.util.spec_from_file_location("ocv_report", ROOT / "scripts" / "02b_ocv_report.py")
    rep_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rep_mod)
    rep_mod.main()
    print(f"[done] {time.time() - t_start:.0f} s")
    return 0


# ----------------------------------------------------------------------------------------------
# Figures (draft; restyled centrally later).  Palette: validated default categorical slots 1-2
# (dataviz references/palette.md: first three slots pass all-pairs CVD checks on light surfaces).
# ----------------------------------------------------------------------------------------------
C_DIS, C_CHG, INK, MUTED, GRID, SHADE = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#dddcd7", "#ecebe7"
MARK = {"SP1": "o", "SP3": "^"}
METHOD_NAMES = {"pchip": "monotone PCHIP through branch-averaged points, mean of the two cells",
                "mono_spline": "monotone cubic smoothing spline", "combined": "combined model",
                "exp_cubic": "exponential-cubic model"}


def _style(ax):
    ax.grid(True, color=GRID, lw=0.5)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.tick_params(labelsize=7, color=MUTED)


def make_figures(npz_path: Path, json_path: Path, fig_dir: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7, "pdf.fonttype": 42,
                         "axes.edgecolor": MUTED, "axes.labelcolor": INK, "figure.facecolor": "white"})
    Z = np.load(npz_path)
    R = json.load(open(json_path, "r", encoding="utf-8"))
    temps = [int(t) for t in R["selected"]["per_temperature"]]
    cells = list(R["axis"]["Q_cell25_Ah"])

    fig, axs = plt.subplots(3, len(temps), figsize=(7.2, 6.6), sharex=True, gridspec_kw=dict(height_ratios=[2.2, 1, 1]))
    for j, T in enumerate(temps):
        a0, a1, a2 = axs[0, j], axs[1, j], axs[2, j]
        s = 1 - Z[f"T{T}_x"]
        a0.plot(s, Z[f"T{T}_U_x_discharge_branch"], color=MUTED, lw=0.9, ls="--", label="fit, discharge branch", zorder=2)
        a0.plot(s, Z[f"T{T}_U_x"], color=INK, lw=1.2, label="fit, branch mean (selected)", zorder=3)
        for c in cells:
            for br, col in (("discharge", C_DIS), ("charge", C_CHG), ("full", INK)):
                x, U = Z[f"T{T}_{c}_{br}_x"], Z[f"T{T}_{c}_{br}_U"]
                face = col if c == cells[0] else "white"
                mk = "s" if br == "full" else MARK[c]
                a0.plot(1 - x, U, ls="none", marker=mk, ms=4.2, mfc=face, mec=col, mew=0.9, zorder=4,
                        label=f"{c} {br}")
            a1.plot(1 - Z[f"T{T}_{c}_avg_x"], Z[f"T{T}_{c}_avg_resid_mV"], ls="none", marker=MARK[c], ms=4,
                    mfc=INK if c == cells[0] else "white", mec=INK, mew=0.8, label=c)
            a2.plot(1 - Z[f"T{T}_{c}_gap_x"], Z[f"T{T}_{c}_gap_mV"], lw=0.8, color=MUTED, marker=MARK[c], ms=4,
                    mfc=MUTED if c == cells[0] else "white", mec=MUTED, mew=0.8, label=f"{c}, 2 h rest")
            a2.plot(1 - Z[f"T{T}_{c}_gap_extrap_x"], Z[f"T{T}_{c}_gap_extrap_mV"], lw=0.8, color=MUTED, ls="--",
                    label=f"{c}, rests log-extrapolated")
        a1.axhline(0, color=MUTED, lw=0.6)
        a2.axhline(0, color=MUTED, lw=0.6)
        for a in (a0, a1, a2):
            _style(a)
            a.set_xlim(-0.03, 1.03)
        fig.text(a0.get_position().x0 + 0.5 * a0.get_position().width, 0.985, f"{T} °C", ha="center", va="top", fontsize=8)
        a2.set_xlabel(r"$1 - q/Q_{\mathrm{cell},25}$ (–)")
        if j == 0:
            a0.set_ylabel("Relaxed OCV (V)")
            a1.set_ylabel("Point − fit (mV)")
            a2.set_ylabel(r"Apparent $U_\mathrm{chg} - U_\mathrm{dis}$ (mV)")
    h, l = axs[0, 0].get_legend_handles_labels()
    h2, l2 = axs[2, 0].get_legend_handles_labels()
    fig.legend(h + h2, l + l2, loc="lower center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.0), fontsize=6.5)
    fig.tight_layout(rect=(0, 0.11, 1, 0.97))
    fig.savefig(fig_dir / "draft_ocv_soc.pdf")
    plt.close(fig)

    fig, axs = plt.subplots(1, len(temps), figsize=(7.2, 2.7), sharey=True)
    for j, T in enumerate(temps):
        a = axs[j]
        z = Z[f"T{T}_z"]
        zl, zh = Z[f"T{T}_supported_z"]
        e1, e2 = Z[f"T{T}_kappa_envelope"]
        k1, k2 = Z[f"T{T}_kappa"]
        a.axvspan(zl, zh, color=SHADE, lw=0, zorder=0, label="supported interval")
        for c, ls in zip(cells, (":", "-.")):
            a.plot(z, Z[f"T{T}_dUdz_{c}_only"], color=MUTED, lw=0.8, ls=ls, label=f"{c}-only fit")
        for rk in [k for k in Z.files if k.startswith(f"T{T}_dUdz_rep_") and k.endswith("_pooled") and "akima" not in k]:
            a.plot(z, Z[rk], color=MUTED, lw=0.9, ls="--", label="tied representation (pooled)")
        a.plot(z, Z[f"T{T}_dUdz"], color=INK, lw=1.2, label="selected fit")
        a.axhline(e1, color=C_DIS, lw=0.7, ls=":", label=r"$\kappa_1$ envelope")
        a.axhline(e2, color=C_CHG, lw=0.7, ls=":", label=r"$\kappa_2$ envelope")
        a.axhline(k1, color=C_DIS, lw=0.9, ls="--", label=r"$\kappa_1$ (min)")
        a.axhline(k2, color=C_CHG, lw=0.9, ls="--", label=r"$\kappa_2$ (max)")
        a.text(0.98, k1, f"κ1 = {k1:.3f}", ha="right", va="bottom", fontsize=6.5, color=INK)
        a.text(0.98, k2, f"κ2 = {k2:.2f}", ha="right", va="bottom", fontsize=6.5, color=INK)
        zb = R["selected"]["per_temperature"][str(T)]["z_interval_both_branches"]
        for zv in zb:
            a.axvline(zv, color=MUTED, lw=0.6, ls=(0, (1, 2)), label="both-branch limits" if zv == zb[0] else None)
        a.set_ylim(0, 1.08 * max(max(float(np.nanmax(Z[f"T{t}_dUdz"])), float(Z[f"T{t}_kappa_envelope"][1])) for t in temps))
        a.set_xlim(0, 1)
        _style(a)
        a.set_xlabel(r"SOC $z = 1 - q/Q_\mathrm{id}(T)$ (–)")
        a.text(0.5, 0.97, f"{T} °C", transform=a.transAxes, ha="center", va="top", fontsize=8,
               bbox=dict(facecolor="white", edgecolor="none", pad=1.0))
        if j == 0:
            a.set_ylabel(r"$\mathrm{d}U/\mathrm{d}z$ (V per unit SOC)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=5, frameon=False, bbox_to_anchor=(0.5, 0.0), fontsize=6.5)
    fig.tight_layout(rect=(0, 0.16, 1, 1))
    fig.savefig(fig_dir / "draft_ocv_slope.pdf")
    plt.close(fig)
    print(f"[write] {fig_dir / 'draft_ocv_soc.pdf'}  {fig_dir / 'draft_ocv_slope.pdf'}")


def make_table(json_path: Path, out: Path) -> None:
    R = json.load(open(json_path, "r", encoding="utf-8"))
    sel = R["selected"]
    lines = [
        "% Generated by scripts/02_ocv.py from results/ocv_fits.json -- do not edit by hand.",
        r"\begin{table}[t]", r"\centering", r"\small",
        r"\caption{OCV slope bounds on the SOC axis $z$ of the observer, Eq.~\eqref{eq:ocv:axis}, for the selected OCV "
        r"representation (" + METHOD_NAMES.get(sel["method"], sel["method"]) + r"). $\kappa_1 = \min \partial U_{\mathrm{oc}}/\partial z$, "
        r"$\kappa_2 = \max \partial U_{\mathrm{oc}}/\partial z$ in \si{\volt} per unit SOC (divide by 100 for \si{\volt} per "
        r"percent SOC); `env.': envelope over data variants (cell, branch, closure correction, full-point rest, rests "
        r"log-extrapolated to \SI{6}{\hour}, $Q_{\mathrm{ref}}$), statistically tied representations and cell normalisations; "
        r"$\kappa_1$ is not identified by the data (point spacing about 0.1 in SOC) and is a modelling assumption. "
        r"Cross-cell RMSE: fit on one cell, predict the other. Hysteresis: maximum apparent gap between the charge and "
        r"discharge branches after the \SI{2}{\hour} rest over both cells (an upper bound: the rests are not fully relaxed). "
        r"$\Delta U$: maximum cell-to-cell OCV difference over the interval, primary axis [range over variants].} "
        r"% src: results/ocv_fits.json:selected.per_temperature, hysteresis",
        r"\label{tab:ocv}",
        r"\begin{tabular}{S[table-format=2.0] l S[table-format=1.3] S[table-format=1.3] S[table-format=1.2] S[table-format=1.2] "
        r"S[table-format=2.1] S[table-format=2.1] l}",
        r"\toprule",
        r"{$T$ (\si{\celsius})} & {Interval in $z$} & {$\kappa_1$} & {$\kappa_1$ env.} & {$\kappa_2$} & {$\kappa_2$ env.} & "
        r"{\begin{tabular}[b]{@{}c@{}}Cross-cell\\RMSE (\si{\milli\volt})\end{tabular}} & {Hyst.\ (\si{\milli\volt})} & {$\Delta U$ (\si{\milli\volt})} \\",
        r"\midrule",
    ]
    used_marks = set()
    for i, (T, d) in enumerate(sel["per_temperature"].items()):
        cv = d["cv"]["cross_cell"]["rmse_mV"]
        hy = R["hysteresis"][T]["max_abs_gap_mV"]
        for k, b in enumerate(d["intervals"]):
            zl, zh = b["z_interval"]
            if b["label"] == "supported":
                lab = f"[{zl:.3f}, {zh:.3f}]$^\\dagger$"
                used_marks.add("dagger")
            elif b["label"] == "both_branch":
                lab = f"[{zl:.3f}, {zh:.3f}]$^\\ddagger$"
                used_marks.add("ddagger")
            else:
                lab = f"[{zl:.2f}, {zh:.2f}]"
                if not b["inside_supported"]:
                    lab += r"$^\ast$"
                    used_marks.add("ast")
            if b["relaxation_axis_limited"]:
                lab += r"$^\S$"
                used_marks.add("S")
            du = (rf"\num{{{b['Delta_U_max_mV']:.1f}}} [\num{{{b['Delta_U_range_mV'][0]:.0f}}}--"
                  rf"\num{{{b['Delta_U_range_mV'][1]:.0f}}}]")
            lines.append(" & ".join([T if k == 0 else "{}", lab, f"{b['kappa1_V_per_soc']:.3f}",
                                     f"{b['kappa1_envelope_min_V_per_soc']:.3f}", f"{b['kappa2_V_per_soc']:.2f}",
                                     f"{b['kappa2_envelope_max_V_per_soc']:.2f}",
                                     f"{cv:.1f}" if k == 0 else "{}", f"{hy:.1f}" if k == 0 else "{}", du]) + r" \\"
                         + f" % src: results/ocv_fits.json:selected.per_temperature.{T}.intervals[{k}]"
                         + (f"; selected.per_temperature.{T}.cv.cross_cell.rmse_mV; hysteresis.{T}.max_abs_gap_mV" if k == 0 else ""))
        if i < len(sel["per_temperature"]) - 1:
            lines.append(r"\midrule")
    notes = {"dagger": r"$^\dagger$ supported interval: covered by relaxed points of both cells.",
             "ddagger": r"$^\ddagger$ both-branch interval: charge and discharge branches of both cells (primary for $\kappa_2$).",
             "ast": r"$^\ast$ extends beyond the supported interval (OCV extrapolated by the fitted model there).",
             "S": r"$^\S$ reaches the knee ($z < 0.1$): values limited by incomplete relaxation and the choice of charge axis."}
    lines += [r"\bottomrule", r"\end{tabular}"]
    lines += [r"\par\footnotesize " + " ".join(notes[m] for m in ("dagger", "ddagger", "ast", "S") if m in used_marks)]
    lines += [r"\end{table}", ""]
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"[write] {out}")


if __name__ == "__main__":
    sys.exit(main())
