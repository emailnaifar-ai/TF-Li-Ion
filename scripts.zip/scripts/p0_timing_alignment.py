"""P0 input-timing alignment: every estimator, run open loop, reproduces the identified model.

Each estimator of tfso.observer / tfso.benchmarks is run with its injection gains (TFO/FOO: l1 = l2 = 0) or
Kalman gains (FOEKF/EKF2RC/AEKF2RC: Q = 0, P0 = 0, Sage-Husa floors 0) forced to zero, on
SP2_25C_DST_50SOC (validation split), with the parameter set of its family identified on SP2_25C_DST_80SOC
(results/identification.json, per_T.25.fits: TFO -> TFO; FO -> FOO and FOEKF; 2RC -> EKF2RC and AEKF2RC;
Q_n = Q_id(25) for all, CC included), and compared with tfso.model.simulate(..., timing='causal') of the same
parameter set (direct recursion and FFT).  Pass criterion: max |V_t,estimator - V_t,model| <= 1e-9 V for every
method, memory and scenario (config: none; tolerance fixed by the task).

Scenarios
  warm      : full record from the end of CV (model.build_history; z0 = model z_0, V_p,0 = 0), i.e. exactly the
              simulation used by the identification; residuals on the whole record and on the profile window.
  cold      : the harness case (experiments.load_case: the profile on the 1 s grid, estimator cold start with
              V_p = 0 and an empty memory) against model.simulate on the same profile-only record (z0 = the
              warm-start model SOC at the profile start).
  regrid_h  : the harness re-gridded case (experiments.resample_case, h = 2, 5, 10 s, I_out = 1 s grid current at
              t_k) against model.simulate on the coarse grid with the dynamics driven causally by the coarse
              held current and the output current I_out (model timing 'causal_point_output' with
              I_point := I_out; this checks the harness I_out logic, not a new model).
Memory: full and N_L = config estimators.defaults.TFO.memory_L_s / h (fractional families only).
For information the voltage difference between the superseded anticipating convention ('implicit_forward',
the previous TFO/FOO/FOEKF implementation; EKF2RC/AEKF2RC/CC were already causal) and 'causal' is also
reported for the fractional methods (same parameters).

Writes results/timing_alignment.json.  Single process.  Run from the project root:
    python scripts/p0_timing_alignment.py
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import model as M  # noqa: E402
from tfso import observer as O  # noqa: E402

FILE = "SP2_25C_DST_50SOC"
T = 25
TOL = 1e-9
FAMILY = {"TFO": "TFO", "FOO": "FO", "FOEKF": "FO", "EKF2RC": "2RC", "AEKF2RC": "2RC", "CC": None}
FRACTIONAL = ("TFO", "FOO", "FOEKF")


def code_hash() -> str:
    h = hashlib.sha256()
    for f in ("observer.py", "benchmarks.py", "experiments.py", "model.py", "tempered.py"):
        h.update((ROOT / "src" / "tfso" / f).read_bytes())
    h.update(Path(__file__).read_bytes())
    return h.hexdigest()[:16]


def zero_gain_hyper(method: str, N_L):
    if method in ("TFO", "FOO"):
        return dict(l1=0.0, l2=0.0, N_L=N_L)
    if method == "FOEKF":
        return dict(Q=[0.0, 0.0], R=1e-4, P0=[0.0, 0.0], N_L=N_L, discretisation="implicit")
    if method == "EKF2RC":
        return dict(Q=[0.0, 0.0, 0.0], R=1e-4, P0=[0.0, 0.0, 0.0])
    if method == "AEKF2RC":
        return dict(Q=[0.0, 0.0, 0.0], R=1e-4, P0=[0.0, 0.0, 0.0], Q_min=[0.0, 0.0, 0.0], R_min=1e-8)
    return {}


def model_params(theta: dict, family: str):
    th = dict(theta)
    if family == "2RC":
        return M.TwoRCParams(**{k: th[k] for k in ("R0", "R1", "tau1", "R2", "tau2", "s", "dq")})
    return M.TFOParams(**{k: th.get(k, 0.0) for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})


def mx(a) -> float:
    a = np.asarray(a, float)
    return float(np.max(np.abs(a))) if a.size else 0.0


def compare(method, pm, est_params, hist, aocv, I_out, z0, N_L, timing_model, window, scenario):
    """One estimator run (open loop) against model.simulate (direct and FFT) on the History `hist`."""
    hy = zero_gain_hyper(method, N_L)
    t_c, t_w = time.process_time(), time.perf_counter()
    r = O.run_estimator(method, est_params, hy, hist.I, hist.V, hist.h, z0, aocv, I_out=I_out)
    est_wall, est_cpu = time.perf_counter() - t_w, time.process_time() - t_c
    row = dict(method=method, family=FAMILY[method], scenario=scenario, h_s=hist.h, N=int(hist.I.size),
               N_L=N_L, full_memory=bool(r["flags"].get("full_memory", N_L is None)),
               max_abs_dz=mx(r["zhat"] - hist.z), max_abs_dz_window=mx((r["zhat"] - hist.z)[window]),
               estimator_wall_s=est_wall, estimator_process_s=est_cpu,
               soc_clip_count=int(r["flags"].get("soc_clip_count", 0)))
    if method == "CC":
        row.update(max_abs_residual_V=0.0, note="CC has no voltage output; SOC residual only")
        return row
    t_w = time.perf_counter()
    nl = N_L if method in FRACTIONAL else None
    md = M.simulate(pm, hist, aocv, method="direct", N_L=nl, timing=timing_model)
    mf = M.simulate(pm, hist, aocv, method="fft", N_L=nl, timing=timing_model)
    row["model_wall_s"] = time.perf_counter() - t_w
    dV = r["Vt_prior"] - md["Vt"]
    row.update(max_abs_residual_V=mx(dV), max_abs_residual_window_V=mx(dV[window]),
               max_abs_residual_fft_V=mx(r["Vt_prior"] - mf["Vt"]),
               max_abs_residual_aposteriori_V=mx(r["Vt_hat"] - md["Vt"]),
               max_abs_dVp_V=mx(r["Vp_hat"] - md["Vp"]),
               model_vs_measured_rmse_window_mV=1e3 * float(np.sqrt(np.mean((md["Vt"] - hist.V)[window] ** 2))))
    if timing_model == "causal" and method in FRACTIONAL:       # previous TFO/FOO/FOEKF code = 'implicit_forward'
        old = M.simulate(pm, hist, aocv, method="fft", N_L=nl, timing="implicit_forward")
        dO = (old["Vt"] - md["Vt"])[window]
        row.update(superseded_implicit_forward_max_abs_dV_window_mV=1e3 * mx(dO),
                   superseded_implicit_forward_rms_dV_window_mV=1e3 * float(np.sqrt(np.mean(dO ** 2))))
    return row


def coarse_history(case, z_start, Qn):
    beta = 1.0 / (3600.0 * Qn)
    z = z_start + np.concatenate([[0.0], np.cumsum(case.h * beta * case.I[:-1])])
    Iout = case.I if case.I_out is None else case.I_out
    return M.History(case.logical_id, case.T, case.h, Qn, case.t - case.t[0], np.asarray(case.I, float),
                     np.asarray(case.V, float), z, 0, {}, I_point=np.asarray(Iout, float))


def main() -> dict:
    t0w, t0c = time.perf_counter(), time.process_time()
    cfg = D.load_config()
    L_s = float(cfg["estimators"]["defaults"]["TFO"]["memory_L_s"])
    hs = [float(v) for v in cfg["estimators"]["resampling"]["h_s"] if float(v) != 1.0]
    df = D.load_raw(FILE)
    chk = D.verify_file(FILE, df)
    J = json.loads((ROOT / "results" / "identification.json").read_text(encoding="utf-8"))
    timing_id = J["settings"]["input_timing"]["primary"]
    if timing_id != "causal" or O.INPUT_TIMING != timing_id:
        raise RuntimeError(f"identification timing {timing_id!r} != estimator timing {O.INPUT_TIMING!r}")
    fits = J["per_T"][str(T)]["fits"]
    Qn = E.q_id(T)
    aocv = M.AlignedOCV(T, Qn)
    hist = M.build_history(FILE, Qn, df=df)
    case = E.load_case(FILE)                                   # validation split guard
    i0 = hist.i0
    grid = dict(max_abs_I_case_vs_history_A=mx(case.I[:-1] - hist.I[i0:-1]),
                max_abs_V_case_vs_history_V=mx(case.V - hist.V[i0:]),
                last_sample_I_case_vs_history_A=float(case.I[-1] - hist.I[-1]),
                n_history=int(i0), n_profile=int(case.t.size))
    rows = []
    for method, fam in FAMILY.items():
        theta = fits[fam]["theta"] if fam else fits["TFO"]["theta"]
        pm = model_params(theta, fam or "TFO")
        est_params = dict(pm.to_dict(), Qn=Qn, eta=1.0)
        mems = [None, int(math.ceil(L_s / 1.0 - 1e-9))] if method in FRACTIONAL else [None]
        for N_L in mems:
            # warm: the identification simulation (record from the end of CV)
            rw = compare(method, pm, est_params, hist, aocv, None, float(hist.z[0]), N_L, "causal",
                         hist.prof, "warm")
            rw["max_abs_residual_profile_V"] = rw.pop("max_abs_residual_window_V", 0.0)
            rows.append(rw)
            # cold: the harness case (profile only, cold start)
            zc = float(hist.z[i0]) + np.concatenate([[0.0], np.cumsum(case.h * case.I[:-1] / (3600.0 * Qn))])
            hc = M.History(FILE, T, case.h, Qn, case.t, case.I, case.V, zc, 0, {}, I_point=case.I.copy())
            rows.append(compare(method, pm, est_params, hc, aocv, None, float(hc.z[0]), N_L, "causal",
                                slice(0, None), "cold"))
            # re-gridded harness cases
            for h in hs:
                c = E.resample_case(case, h)
                hh = coarse_history(c, float(hist.z[i0]), Qn)
                nlh = None if N_L is None else int(math.ceil(L_s / h - 1e-9))
                rows.append(compare(method, pm, est_params, hh, aocv, hh.I_point, float(hh.z[0]), nlh,
                                    "causal_point_output", slice(0, None), f"regrid_h{h:g}"))
            print(f"{method:8s} N_L={N_L}: warm {rows[-2 - len(hs)]['max_abs_residual_V']:.2e} V, "
                  f"cold {rows[-1 - len(hs)]['max_abs_residual_V']:.2e} V", flush=True)
    worst = max(r["max_abs_residual_V"] for r in rows)
    worst_fft = max(r.get("max_abs_residual_fft_V", 0.0) for r in rows)
    worst_z = max(r["max_abs_dz"] for r in rows)
    per_method = {m: dict(max_abs_residual_V=max(r["max_abs_residual_V"] for r in rows if r["method"] == m),
                          max_abs_dz=max(r["max_abs_dz"] for r in rows if r["method"] == m))
                  for m in FAMILY}
    wall, cpu = time.perf_counter() - t0w, time.process_time() - t0c
    out = dict(generated_utc=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"), code_hash=code_hash(),
               file=FILE, split=case.split, verify_passed=bool(chk["passed"]), T=T, Q_id_Ah=Qn,
               identification_file=J["per_T"][str(T)]["identification_file"], identification_timing=timing_id,
               estimator_timing=O.INPUT_TIMING,
               convention="u_n = I_{n-1} (current held on [t_{n-1}, t_n)) drives SOC and every polarisation branch; "
                          "output R0 I_n with the grid current I_n (re-gridded: I_out = 1 s grid current at t_k)",
               families=FAMILY, zero_gain_hyper={m: zero_gain_hyper(m, "N_L") for m in FAMILY},
               memory_L_s=L_s, regrid_h_s=hs, tolerance_V=TOL, grid_check=grid, rows=rows, per_method=per_method,
               max_abs_residual_V=worst, max_abs_residual_fft_V=worst_fft, max_abs_dz=worst_z,
               passed=bool(worst <= TOL and worst_fft <= TOL and chk["passed"]),
               wall_s=wall, process_s=cpu, workers=1,
               note="Vt residual = one-step-ahead (a-priori) estimator output minus the model output; with zero gains "
                    "the a-posteriori output is identical. FastOCV table (config estimators.ocv_table) vs AlignedOCV "
                    "contributes <= ~3e-10 V.")
    (ROOT / "results" / "timing_alignment.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    print(f"max |dVt| = {worst:.3e} V (fft {worst_fft:.3e}), max |dz| = {worst_z:.3e}; passed {out['passed']}; "
          f"wall {wall:.1f} s, process {cpu:.1f} s")
    return out


if __name__ == "__main__":
    main()
