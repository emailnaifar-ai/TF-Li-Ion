"""Conservatism of the certified truncation-induced SOC-error bound at L = 400 s (post-hoc diagnostic).

For the frozen TFO (lambda = 1e-4 1/s, N_L = 400, frozen parameters and gains of results/frozen_config.json) and,
as the untempered counterpart, the frozen FOO (lambda = 0, N_L = 400), the certified bound of the implemented
recursion (Corollary S1.7.9(i), 05_design_tune.truncation_soc_bounds 'ez_bound_exact')

    B = gamma_zp^(h,L)(kappa1, kappa2) x h^-alpha sum_{j>N_L} |omega_j| x B_p

is compared with the ACTUAL truncation-induced SOC deviation d_n = zhat_400,n - zhat_full,n of the SAME frozen
parameters and gains run once with N_L = 400 and once with full memory (18 test records x 3 initial-SOC scenarios).
The ratio B / A (A = max |d_n| on the admissible window t - t0 >= 600 s, z_ref in [0.10, 0.95]) is split into
multiplicative factors that telescope exactly (per run):

  (a)  F_a  = B_p / S,                     S = max_n |Vhat_p,n| of the full-memory observer (plant-model variant too)
  (b1) F_b1 = W_tail S / max_n A_n,        A_n = h^-alpha sum_{N_L<j<=n} |omega_j| |Vhat_p,n-j|   (finite record,
                                           magnitude profile of Vhat_p under the discarded weights)
       (split: F_b1_len = W_tail / sum_{N_L<j<=N-1}|omega_j| h^-alpha, F_b1_mag = the rest)
  (b2) F_b2 = max_n A_n / max_n |R_n|,     R_n = h^-alpha sum_{N_L<j<=n} omega_j Vhat_p,n-j   (sign cancellation)
  (c1) F_c1 = gamma_cmp / gamma_dc(kappa1) comparison-system coupling term l2 kappa2 (gamma_dc(k) = 1/(k(a_p+mu0)))
  (c2) F_c2 = kappa_med / kappa1           worst-case slope vs median slope visited (dU/dz at zhat_full, window)
  (d1) F_d1 = gamma_dc(kappa_med) max|R| / max|d_lti|   static gain x peak input vs the LTI recursion at kappa_med
                                           driven by the actual R (dynamic attenuation)
  (d2) F_d2 = max|d_lti| / max_n |d_n|     LTI at kappa_med vs the actual (slope-varying) transmission
  (w)  F_w  = max_n |d_n| / A              whole record vs admissible window

The deviation d obeys EXACTLY the linear error recursion of prop:m4b:errorrec with the secant slopes
kappa_n = (U(zhat_400) - U(zhat_full))/(zhat_400 - zhat_full) and input R_n (checked: 'closure').  (e) The
consistency residual r_n = D_h V_p(t_n) + a_p V_p(t_n) - b_p u_n of the continuous-time element (exact V_p from
the step-response integral tempered.tempered_step_integral, piecewise-constant current) is reported for scale; it
does not depend on L and does not enter d_n.

Test records are used although nothing is tuned or selected here: post-hoc diagnostic only.
Outputs: results/conservatism.json, reports/conservatism_findings.md.   Usage: python scripts/11_conservatism.py
[--workers 2] [--report-only]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from scipy.signal import fftconvolve

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES = ROOT / "results"
REP = ROOT / "reports"
OUT = RES / "conservatism.json"
TEMPS = (0, 25, 45)
METHODS = ("TFO", "FOO")          # frozen entries; FOO = untempered counterpart (lambda = 0, own parameters/gains)
SCEN = ("nominal", "plus20", "minus20")
TASK_VERSION = "C1-2026-09-28-a"
IMPULSE_LEN = 40000
FACTORS = ("F_a", "F_b1", "F_b2", "F_c1", "F_c2", "F_d1", "F_d2", "F_w")


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def code_hash() -> str:
    h = hashlib.sha256()
    for f in ("scripts/11_conservatism.py", "src/tfso/observer.py", "src/tfso/tempered.py", "src/tfso/model.py",
              "src/tfso/experiments.py", "results/frozen_config.json", "results/gain_design.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def frozen():
    fz = load_json("frozen_config.json")
    if not str(fz.get("status", "")).startswith("FROZEN"):
        raise PermissionError("frozen_config.json is not FROZEN")
    return fz


def post_certificate(gd, T, lam, L=400):
    for pc in gd["post_certificates"]:
        if int(pc["T"]) == int(T) and abs(float(pc["lam"]) - lam) <= 1e-12 and pc["L"] == L:
            return pc
    raise KeyError((T, lam, L))


def admissible():
    return tuple(float(x) for x in D.load_config()["identification_refined"]["admissible_soc_interval"])


# ---------------------------------------------------------------------------------------------------------------
# Linear algebra of the truncation residual and of the error recursion
# ---------------------------------------------------------------------------------------------------------------
def tail_conv(om_tail, x, N):
    """sum_{N_L<j<=n} om_tail_j x_{n-j}, n = 0..N-1 (om_tail zero for j <= N_L)."""
    return fftconvolve(om_tail, x)[:N]


def delta_recursion(alpha, lam, ap, l1, l2, h, NL, kap, R):
    """Error recursion of prop:m4b:errorrec (memory N_L, no other inputs, zero initial state) driven by the
    truncation residual R [V s^-alpha] with slopes kap (array or scalar): returns (dz, dp).
    dz_n = dz_{n-1} - h l1 (k_{n-1} dz_{n-1} + dp_{n-1});
    (1 + h^a (ap + l2)) dp_n = -sum_{1<=j<=N_L} omega_j dp_{n-j} + h^a (R_n - l2 k_n dz_n)."""
    N = R.size
    k = np.full(N, float(kap)) if np.ndim(kap) == 0 else np.asarray(kap, float)
    om = TM.gl_weights(alpha, lam, h, NL)
    wrev = om[1:][::-1].copy()
    ha = h ** alpha
    den = 1.0 + ha * (ap + l2)
    dz = np.zeros(N)
    dp = np.zeros(N)
    buf = np.zeros(2 * NL)
    pos = 1 % NL                                  # dp_0 = 0 already in the buffer
    Rl, kl = R.tolist(), k.tolist()
    dot = np.dot
    z, p = 0.0, 0.0
    for n in range(1, N):
        z = z - h * l1 * (kl[n - 1] * z + p)
        mem = float(dot(wrev, buf[pos:pos + NL]))
        p = (-mem + ha * (Rl[n] - l2 * kl[n] * z)) / den
        buf[pos] = p
        buf[pos + NL] = p
        pos = (pos + 1) % NL
        dz[n], dp[n] = z, p
    return dz, dp


def lti_impulse(alpha, lam, ap, l1, l2, h, NL, kap, n=IMPULSE_LEN):
    """Response of dz to a unit pulse R_1 = 1 [V s^-alpha] at constant slope kap: (DC gain, l1 norm)."""
    R = np.zeros(n)
    R[1] = 1.0
    dz, _ = delta_recursion(alpha, lam, ap, l1, l2, h, NL, kap, R)
    return float(np.sum(dz)), float(np.sum(np.abs(dz))), float(abs(dz[-1]) / max(np.max(np.abs(dz)), 1e-300))


def exact_polarisation(alpha, lam, ap, bp, I, h):
    """Continuous-time element V_p(t_n) for the piecewise-constant current I_k on [t_k, t_{k+1}), V_p(0) = 0:
    V_n = b_p sum_{k=1}^{n} I_{n-k} [S(kh) - S((k-1)h)], S = tempered.tempered_step_integral."""
    N = I.size
    S = TM.tempered_step_integral(alpha, lam, ap, h * np.arange(N))
    dS = np.diff(S)
    V = np.zeros(N)
    V[1:] = bp * fftconvolve(I, dS)[:N - 1]
    return V


def _stats(x):
    x = np.asarray(x, float)
    return dict(max=float(np.max(np.abs(x))), rms=float(np.sqrt(np.mean(x * x))),
                p99=float(np.quantile(np.abs(x), 0.99)))


# ---------------------------------------------------------------------------------------------------------------
# One test record: both methods, three scenarios
# ---------------------------------------------------------------------------------------------------------------
def file_task(lid):
    t0w, t0c = time.perf_counter(), time.process_time()
    fz = frozen()
    gd = load_json("gain_design.json")
    case = E.load_case(lid, allow_splits=("test",), final_evaluation=True)     # data.verify_file inside
    if not case.meta["verify_passed"]:
        raise RuntimeError(f"{lid} failed data.verify_file")
    T, h, N = case.T, float(case.h), case.t.size
    lo, hi = admissible()
    tpost = float(D.load_config()["estimators"]["post_convergence_t_s"])
    win = ((case.t - case.t[0]) >= tpost) & (case.soc_ref >= lo) & (case.soc_ref <= hi)
    u = MD.drive(case.I, 1)                    # causal input u_n = I_{n-1}
    runs, plant = [], {}
    for meth in METHODS:
        e = fz["methods"][meth]["per_T"][str(T)]
        p, hy = dict(e["params"]), dict(e["hyper"])
        alpha, lam = float(p["alpha"]), (float(p["lam"]) if meth == "TFO" else 0.0)
        ap, bp = 1.0 / (float(p["Rp"]) * float(p["Cp"])), 1.0 / float(p["Cp"])
        l1, l2 = float(hy["l1"]), float(hy["l2"])
        NL = int(e["N_L"])
        k1, k2 = float(e["kappa1"]), float(e["kappa2"])
        pc = post_certificate(gd, T, lam)
        Bp = float(pc["B_p_V"])
        mu0 = TM.mu_hL(alpha, lam, 0.0, h, NL)
        g_cmp = TM.soc_gain(alpha, lam, ap, k1, k2, l2, h=h, N_L=NL)
        W_tail = TM.worst_case_remainder(alpha, lam, h, NL, 1.0)                  # h^-a sum_{j>N_L}|omega_j|
        bound = g_cmp * W_tail * Bp
        om = TM.gl_weights(alpha, lam, h, N)
        om_tail = om.copy()
        om_tail[:NL + 1] = 0.0
        W_rec = h ** (-alpha) * float(np.sum(np.abs(om_tail)))                      # discarded weights in record
        focv = O.as_fast_ocv(MD.AlignedOCV(T, E.q_id(T)), s=p["s"], dq=p["dq"])
        # plant model (discrete GL, full memory; identified form) and the continuous-time element
        Vp_d = MD.polarisation_fft(alpha, lam, ap, bp, u, h)
        Vp_c = exact_polarisation(alpha, lam, ap, bp, case.I, h)
        R_d = h ** (-alpha) * tail_conv(om_tail, Vp_d, N)
        A_d = h ** (-alpha) * tail_conv(np.abs(om_tail), np.abs(Vp_d), N)
        r = h ** (-alpha) * fftconvolve(om, Vp_c)[:N] + ap * Vp_c - bp * u         # consistency residual
        r[0] = 0.0
        pl = dict(method=meth, alpha=alpha, lam=lam, a_p=ap, b_p=bp, l1=l1, l2=l2, N_L=NL, kappa1=k1, kappa2=k2,
                  B_p_V=Bp, mu_hL0=mu0, gamma_cmp=g_cmp, W_tail=W_tail, W_tail_record=W_rec, bound=bound,
                  bound_paper_check=float(pc["truncation_soc_bound"]["ez_bound_exact"]),
                  plant_max_Vp=float(np.max(np.abs(Vp_d))), plant_max_Vp_cont=float(np.max(np.abs(Vp_c))),
                  plant_max_Vp_disc_minus_cont=float(np.max(np.abs(Vp_d - Vp_c))),
                  plant_max_R=float(np.max(np.abs(R_d))), plant_max_A=float(np.max(A_d)),
                  r_consistency=_stats(r[1:]), r_consistency_window=_stats(r[win]))
        pl["F_a_plant"] = Bp / pl["plant_max_Vp"]
        pl["F_b1_plant"] = W_tail * pl["plant_max_Vp"] / pl["plant_max_A"]
        pl["F_b2_plant"] = pl["plant_max_A"] / pl["plant_max_R"]
        pl["F_b_plant"] = pl["F_b1_plant"] * pl["F_b2_plant"]
        pl["r_over_R_plant"] = pl["r_consistency"]["max"] / pl["plant_max_R"]
        pl["gamma_cmp_r_max"] = g_cmp * pl["r_consistency"]["max"]
        plant[meth] = pl
        for sc in SCEN:
            hyF = dict(hy)
            hyF["L_s"] = None
            hyF.pop("N_L", None)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                rL = E.run_case(meth, p, hy, case, z0_scenario=sc, ocv=focv, keep_series=True)
                rF = E.run_case(meth, p, hyF, case, z0_scenario=sc, ocv=focv, keep_series=True)
            sL, sF = rL.pop("_series"), rF.pop("_series")
            if rL["N_L_used"] != NL or not rF["full_memory"]:
                raise RuntimeError("memory settings not as intended")
            zL, zF = np.asarray(sL["zhat"], float), np.asarray(sF["zhat"], float)
            VpF = np.asarray(sF["Vp_hat"], float)
            d = zL - zF
            zmin, zmax = O.SOC_CLIP
            clipped = np.flatnonzero((zL <= zmin) | (zL >= zmax) | (zF <= zmin) | (zF >= zmax))
            nc = int(clipped[0]) if clipped.size else N           # unclipped horizon: the recursion is linear on [0, nc)
            R = h ** (-alpha) * tail_conv(om_tail, VpF, N)
            Aabs = h ** (-alpha) * tail_conv(np.abs(om_tail), np.abs(VpF), N)
            UL, UF = focv.U(zL), focv.U(zF)
            dUF = focv.dU(zF)
            sec = np.where(np.abs(d) > 1e-12, (UL - UF) / np.where(np.abs(d) > 1e-12, d, 1.0), dUF)
            dz_lin, _ = delta_recursion(alpha, lam, ap, l1, l2, h, NL, sec[:nc], R[:nc])
            k_med = float(np.median(dUF[win]))
            k_med_all = float(np.median(dUF[:nc]))
            dz_lti, _ = delta_recursion(alpha, lam, ap, l1, l2, h, NL, k_med, R[:nc])
            dc, l1n, tail_ratio = lti_impulse(alpha, lam, ap, l1, l2, h, NL, k_med)
            g_dc_k1 = 1.0 / (k1 * (ap + mu0))
            g_dc_med = 1.0 / (k_med * (ap + mu0))
            S = float(np.max(np.abs(VpF[:nc])))
            Amax, Rmax = float(np.max(Aabs[:nc])), float(np.max(np.abs(R[:nc])))
            D_all, D_lti = float(np.max(np.abs(d[:nc]))), float(np.max(np.abs(dz_lti)))
            A_adm, rms_adm = float(np.max(np.abs(d[win]))), float(np.sqrt(np.mean(d[win] ** 2)))
            rec = dict(file=lid, T=T, profile=case.profile, start_level=case.start_level, method=meth, scenario=sc,
                       N=N, n_window=int(win.sum()), z0=rL["z0"], bound=bound,
                       dev_max_window=A_adm, dev_rms_window=rms_adm, dev_max_record=D_all,
                       dev_final=float(abs(d[-1])), dev_mean_window=float(np.mean(d[win])),
                       gap_total=bound / A_adm,
                       S_hat=S, B_p_V=Bp, W_tail=W_tail, W_tail_record=W_rec, A_max=Amax, R_max=Rmax,
                       R_rms=float(np.sqrt(np.mean(R[:nc] ** 2))), R_final=float(R[nc - 1]),
                       R_plant_max=pl["plant_max_R"], R_hat_over_R_plant=Rmax / pl["plant_max_R"],
                       S_hat_over_S_plant=S / pl["plant_max_Vp"],
                       kappa1=k1, kappa2=k2, kappa_med_window=k_med, kappa_med_record=k_med_all,
                       kappa_min_window=float(np.min(dUF[win])), kappa_max_window=float(np.max(dUF[win])),
                       kappa_q10_window=float(np.quantile(dUF[win], 0.1)),
                       frac_kappa_below_1p5k1=float(np.mean(dUF[win] <= 1.5 * k1)),
                       gamma_cmp=g_cmp, gamma_dc_kappa1=g_dc_k1, gamma_dc_kappa_med=g_dc_med,
                       lti_dc_gain=abs(dc), lti_l1_gain=l1n, lti_impulse_tail_ratio=tail_ratio,
                       dev_lti_max=D_lti,
                       closure_max_abs=float(np.max(np.abs(dz_lin - d[:nc]))),
                       closure_rel=float(np.max(np.abs(dz_lin - d[:nc])) / max(D_all, 1e-300)),
                       n_unclipped=nc, n_window_after_clip=int(np.sum(win[nc:])),
                       dev_max_record_incl_clipped=float(np.max(np.abs(d))),
                       soc_clip_L=rL["soc_clip_count"], soc_clip_F=rF["soc_clip_count"],
                       adm_post_rmse_L_pct=None, whole_rmse_L_pct=rL["rmse_pct"], whole_rmse_F_pct=rF["rmse_pct"])
            e_L, e_F = zL - case.soc_ref, zF - case.soc_ref
            rec["adm_post_rmse_L_pct"] = float(100 * np.sqrt(np.mean(e_L[win] ** 2)))
            rec["adm_post_rmse_F_pct"] = float(100 * np.sqrt(np.mean(e_F[win] ** 2)))
            rec.update(F_a=Bp / S, F_b1=W_tail * S / Amax, F_b2=Amax / Rmax, F_c1=g_cmp / g_dc_k1,
                       F_c2=k_med / k1, F_d1=g_dc_med * Rmax / D_lti, F_d2=D_lti / D_all, F_w=D_all / A_adm)
            rec["F_b"] = rec["F_b1"] * rec["F_b2"]
            rec["F_b1_len"] = W_tail / W_rec                     # discarded weights beyond the record length
            rec["F_b1_mag"] = W_rec * S / Amax                   # |Vhat_p| under the discarded weights vs its peak
            rec["F_input"] = rec["F_a"] * rec["F_b"]             # B_p W_tail / max|R|: a-priori residual size
            rec["F_gain"] = g_cmp * Rmax / D_all                 # comparison gain vs actual peak transmission
            rec["F_c"] = rec["F_c1"] * rec["F_c2"]
            rec["F_d"] = rec["F_d1"] * rec["F_d2"]
            rec["product"] = float(np.prod([rec[f] for f in FACTORS]))
            rec["product_rel_err"] = abs(rec["product"] / rec["gap_total"] - 1.0)
            rec["transmission_actual"] = D_all / Rmax              # actual peak-to-peak, residual -> SOC
            rec["gain_ratio_cmp_over_actual"] = g_cmp / rec["transmission_actual"]
            rec["r_max_over_R_max"] = pl["r_consistency"]["max"] / Rmax
            runs.append(rec)
    return dict(file=lid, T=T, profile=case.profile, runs=runs, plant=plant,
                wall_s=time.perf_counter() - t0w, cpu_s=time.process_time() - t0c)


# ---------------------------------------------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------------------------------------------
RUN_KEYS = ("bound", "dev_max_window", "dev_rms_window", "dev_max_record", "gap_total") + FACTORS + (
    "F_b", "F_c", "F_d", "F_b1_len", "F_b1_mag", "F_input", "F_gain", "product", "S_hat", "S_hat_over_S_plant", "R_max", "R_hat_over_R_plant", "A_max",
    "kappa_med_window", "kappa_min_window", "kappa_q10_window", "frac_kappa_below_1p5k1", "gamma_cmp",
    "gamma_dc_kappa1", "gamma_dc_kappa_med", "lti_dc_gain", "lti_l1_gain", "dev_lti_max", "transmission_actual",
    "gain_ratio_cmp_over_actual", "closure_rel", "r_max_over_R_max", "adm_post_rmse_L_pct", "adm_post_rmse_F_pct",
    "dev_mean_window")
PLANT_KEYS = ("plant_max_Vp", "plant_max_Vp_cont", "plant_max_Vp_disc_minus_cont", "plant_max_R", "F_a_plant",
              "F_b1_plant", "F_b2_plant", "F_b_plant", "r_over_R_plant", "gamma_cmp_r_max")


def mmr(vals):
    v = np.asarray([x for x in vals if x is not None], float)
    return dict(median=float(np.median(v)), min=float(np.min(v)), max=float(np.max(v)), n=int(v.size))


def summarise(files):
    runs = [r for f in files for r in f["runs"]]
    out = {}
    for meth in METHODS:
        om = {}
        for T in TEMPS + ("pooled",):
            rr = [r for r in runs if r["method"] == meth and (T == "pooled" or r["T"] == T)]
            pp = [f["plant"][meth] for f in files if (T == "pooled" or f["T"] == T)]
            s = {k: mmr([r[k] for r in rr]) for k in RUN_KEYS}
            s.update({k: mmr([p[k] for p in pp]) for k in PLANT_KEYS})
            s["r_consistency_max"] = mmr([p["r_consistency"]["max"] for p in pp])
            s["r_consistency_rms"] = mmr([p["r_consistency"]["rms"] for p in pp])
            s["r_consistency_p99"] = mmr([p["r_consistency"]["p99"] for p in pp])
            s["product_of_median_factors"] = float(np.prod([s[f]["median"] for f in FACTORS]))
            s["max_product_rel_err"] = float(max(r["product_rel_err"] for r in rr))
            s["n_runs"] = len(rr)
            if T != "pooled":
                p0 = pp[0]
                s["constants"] = {k: p0[k] for k in ("alpha", "lam", "a_p", "b_p", "l1", "l2", "N_L", "kappa1",
                                                     "kappa2", "B_p_V", "mu_hL0", "gamma_cmp", "W_tail", "bound",
                                                     "bound_paper_check")}
                s["W_tail_record"] = mmr([p["W_tail_record"] for p in pp])
            om[str(T)] = s
        out[meth] = om
    # untempered / tempered ratios per T (medians)
    comp = {}
    for T in TEMPS:
        a, b = out["TFO"][str(T)], out["FOO"][str(T)]
        comp[str(T)] = dict(bound_ratio_FOO_over_TFO=b["constants"]["bound"] / a["constants"]["bound"],
                            dev_ratio_FOO_over_TFO_median=b["dev_max_window"]["median"] / a["dev_max_window"]["median"],
                            gap_ratio_FOO_over_TFO_median=b["gap_total"]["median"] / a["gap_total"]["median"])
    by_profile = {}
    for meth in METHODS:
        by_profile[meth] = {}
        for T in TEMPS:
            for pr in ("FUDS", "US06", "BJDST"):
                rr = [r for r in runs if r["method"] == meth and r["T"] == T and r["profile"] == pr]
                by_profile[meth][f"{T}_{pr}"] = dict(gap_total=mmr([r["gap_total"] for r in rr]),
                                                      dev_max_window=mmr([r["dev_max_window"] for r in rr]))
    return out, comp, by_profile


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return f if math.isfinite(f) else ("inf" if f > 0 else ("-inf" if f < 0 else "nan"))
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def compute(workers):
    t0w, t0c = time.perf_counter(), time.process_time()
    files = list(D.load_config()["splits"]["test_dynamic"])
    if workers <= 1:
        res = [file_task(f) for f in files]
    else:
        with ProcessPoolExecutor(max_workers=workers) as ex:
            res = list(ex.map(file_task, files, chunksize=1))
    summ, comp, byp = summarise(res)
    J = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
             script="scripts/11_conservatism.py", code_hash=code_hash(), task_version=TASK_VERSION,
             status="POST-HOC DIAGNOSTIC on the 18 test records (nothing tuned or selected; frozen parameters and gains)",
             definitions=dict(
                 bound="gamma_zp^(h,L)(kappa1,kappa2) x h^-alpha sum_{j>N_L}|omega_j| x B_p (= gain_design.json "
                       "post_certificates[T, lam, L=400].truncation_soc_bound.ez_bound_exact) [SOC fraction]",
                 deviation="d_n = zhat(N_L=400) - zhat(full memory), same frozen parameters, gains, z0, data",
                 window="t - t0 >= estimators.post_convergence_t_s and reference SOC in "
                        "identification_refined.admissible_soc_interval",
                 gap_total="bound / max_window |d_n| = F_a F_b1 F_b2 F_c1 F_c2 F_d1 F_d2 F_w (exact per run)",
                 record_maxima="over the unclipped horizon n < n_unclipped (first sample at which either run hits the "
                               "SOC clip; the observer is linear in d only before it)",
                 kappa="dU/dz of the frozen OCV at zhat_full; secant slopes for the closure check",
                 gamma_dc="1/(kappa (a_p + mu_{h,L}(0))): DC gain of the linear recursion at constant slope",
                 plant="model.polarisation_fft (identified discrete GL form, full memory, causal input, V_p(0) = 0); "
                       "continuous element via tempered.tempered_step_integral",
                 r_consistency="r_n = h^-alpha sum_j omega_j V_p(t_{n-j}) + a_p V_p(t_n) - b_p u_n of the continuous "
                               "element (eq:m4b:residuals), V s^-alpha"),
             files=res, summary=summ, untempered_vs_tempered=comp, by_profile=byp,
             runtime=dict(wall_s=time.perf_counter() - t0w, cpu_main_s=time.process_time() - t0c,
                          worker_wall_s_sum=float(sum(r["wall_s"] for r in res)), workers=workers))
    J = jsonable(J)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(J, fh, indent=1)
    return J


# ---------------------------------------------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------------------------------------------
LABELS = [
    ("F_a", "(a) B_p / max abs Vhat_p"),
    ("F_b1", "(b1) tail sum x max abs Vhat_p / max_n sum abs(omega_j) abs(Vhat_p)"),
    ("F_b1_len", "- of which: tail beyond the record length"),
    ("F_b1_mag", "- of which: Vhat_p below its peak under the tail"),
    ("F_b2", "(b2) sign cancellation in R_L"),
    ("F_c1", "(c1) l2 kappa2 coupling in gamma_zp"),
    ("F_c2", "(c2) median slope visited / kappa1"),
    ("F_d1", "(d1) static gain x max abs R vs LTI response at median slope"),
    ("F_d2", "(d2) LTI at median slope vs actual transmission"),
    ("F_w", "(w) whole record vs admissible window"),
    ("F_input", "a x b: a-priori residual size B_p W_tail / max abs R"),
    ("F_gain", "c x d: gamma_zp / actual peak transmission"),
]


def fm(s, k, scale=1.0, nd=3):
    d = s[k]
    f = lambda v: f"{v * scale:.{nd}g}"
    return f"{f(d['median'])} [{f(d['min'])}, {f(d['max'])}]"


def row(lab, vals):
    return f"| {lab} | " + " | ".join(vals) + " |"


def report(J):
    S = J["summary"]
    L = ["# Conservatism of the certified truncation bound at L = 400 s", "",
         f"Generated {J['generated_utc']} by `scripts/11_conservatism.py` (code hash {J['code_hash']}); all numbers "
         "from `results/conservatism.json` (keys `summary.<method>.<T>.<key>` with median, min, max over runs; "
         "per-run values in `files[*].runs`).", "",
         "**Status: post-hoc diagnostic on the 18 test records x 3 initial-SOC scenarios.** Nothing is tuned or "
         "selected here: the frozen TFO (lambda = 1e-4 1/s, N_L = 400) and, as the untempered counterpart, the frozen "
         "FOO (lambda = 0, N_L = 400) are run with their frozen parameters and gains, once with N_L = 400 and once "
         "with full memory. Test records are used only because nothing is fitted.", "",
         "## Definitions", "",
         "* Certified bound B = gamma_zp^(h,L)(kappa1, kappa2) x h^-alpha sum_{j>N_L} |omega_j| x B_p (Corollary "
         "S1.7.9(i); equals `gain_design.json` post_certificates ez_bound_exact, checked per temperature).",
         "* Actual truncation-induced deviation d_n = zhat_400,n - zhat_full,n (same parameters, gains, z0 and data). "
         "A = max |d_n| on the admissible window (t - t0 >= 600 s, reference SOC in [0.10, 0.95]).",
         "* gap = B / A = F_a F_b1 F_b2 F_c1 F_c2 F_d1 F_d2 F_w, exactly per run (largest relative error of the "
         f"product {max(S[m]['pooled']['max_product_rel_err'] for m in METHODS):.1e}). The median of the gap is not "
         "the product of the median factors (both are given).",
         "* d obeys exactly the linear error recursion of prop:m4b:errorrec with secant slopes and input "
         "R_n = h^-alpha sum_{N_L<j<=n} omega_j Vhat_p,n-j of the full-memory estimate: largest relative closure "
         f"error {max(S[m]['pooled']['closure_rel']['max'] for m in METHODS):.1e}. Record maxima are taken before the "
         "first SOC-clip sample of either run (clipping occurs only after the admissible window).",
         "* gamma_dc(kappa) = 1/(kappa (a_p + mu_{h,L}(0))) is the DC gain of that recursion at a constant slope; "
         "its impulse response was one-signed in every run (l1 norm equal to the DC gain).",
         "* (e) r_n is the consistency residual of eq:m4b:residuals for the continuous-time element with the same "
         "parameters (exact response to the piecewise-constant current); it does not depend on L and does not enter d.",
         ""]
    for meth in METHODS:
        s = {T: S[meth][str(T)] for T in TEMPS}
        title = "lambda = 1e-4 1/s" if meth == "TFO" else "lambda = 0, untempered counterpart"
        L += [f"## {meth} ({title})", "", "Median [min, max] over 6 records x 3 scenarios per temperature.", "",
              "| quantity | 0 C | 25 C | 45 C |", "|---|---|---|---|",
              row("certified bound B (% SOC)", [f"{s[T]['constants']['bound'] * 100:.1f}" for T in TEMPS]),
              row("actual max abs d on window (% SOC)", [fm(s[T], "dev_max_window", 100) for T in TEMPS]),
              row("actual RMS d on window (% SOC)", [fm(s[T], "dev_rms_window", 100) for T in TEMPS]),
              row("mean d on window (% SOC)", [fm(s[T], "dev_mean_window", 100) for T in TEMPS]),
              row("total gap B / A", [fm(s[T], "gap_total") for T in TEMPS])]
        L += [row(lab, [fm(s[T], k) for T in TEMPS]) for k, lab in LABELS]
        L += [row("product of the median factors", [f"{s[T]['product_of_median_factors']:.3g}" for T in TEMPS]),
              row("B_p (V) / max abs Vhat_p (V)",
                  [f"{s[T]['constants']['B_p_V']:.3g} / {s[T]['S_hat']['median']:.3g}" for T in TEMPS]),
              row("kappa1 / median kappa visited (V)",
                  [f"{s[T]['constants']['kappa1']:.3g} / {s[T]['kappa_med_window']['median']:.3g}" for T in TEMPS]),
              row("gamma_zp / gamma_dc(median kappa) / max abs d / max abs R (V^-1 s^alpha)",
                  [f"{s[T]['constants']['gamma_cmp']:.3g} / {s[T]['gamma_dc_kappa_med']['median']:.3g} / "
                   f"{s[T]['transmission_actual']['median']:.3g}" for T in TEMPS]),
              row("max abs R_L[Vhat_p] (mV s^-alpha)", [fm(s[T], "R_max", 1e3) for T in TEMPS]),
              row("admissible post RMSE vs reference, N_L = 400 / full (% SOC)",
                  [f"{s[T]['adm_post_rmse_L_pct']['median']:.3g} / {s[T]['adm_post_rmse_F_pct']['median']:.3g}"
                   for T in TEMPS]), ""]
        L += ["Plant-model variant and consistency residual (6 records per temperature):", "",
              "| quantity | 0 C | 25 C | 45 C |", "|---|---|---|---|",
              row("(a) B_p / max abs V_p of the identified plant model", [fm(s[T], "F_a_plant") for T in TEMPS]),
              row("(b) tail sum x max abs V_p / max abs R_L[V_p]", [fm(s[T], "F_b_plant") for T in TEMPS]),
              row("max abs difference, discrete model - continuous element (mV)",
                  [fm(s[T], "plant_max_Vp_disc_minus_cont", 1e3) for T in TEMPS]),
              row("(e) sup abs r_n (mV s^-alpha)", [fm(s[T], "r_consistency_max", 1e3) for T in TEMPS]),
              row("(e) RMS r_n (mV s^-alpha)", [fm(s[T], "r_consistency_rms", 1e3) for T in TEMPS]),
              row("(e) sup abs r_n / max abs R_L[V_p]", [fm(s[T], "r_over_R_plant") for T in TEMPS]),
              row("(e) gamma_zp x sup abs r_n (% SOC)", [fm(s[T], "gamma_cmp_r_max", 100) for T in TEMPS]), ""]
    c = J["untempered_vs_tempered"]
    L += ["## Tempered versus untempered at L = 400 s", "",
          "| T | bound FOO / TFO | actual max abs d, FOO / TFO (medians) | gap FOO / TFO (medians) |",
          "|---|---|---|---|"]
    L += [f"| {T} C | {c[str(T)]['bound_ratio_FOO_over_TFO']:.3g} | {c[str(T)]['dev_ratio_FOO_over_TFO_median']:.3g}"
          f" | {c[str(T)]['gap_ratio_FOO_over_TFO_median']:.3g} |" for T in TEMPS]
    L += ["", "## Interpretation", "", interpretation(J), "",
          f"Runtime {J['runtime']['wall_s']:.0f} s wall with {J['runtime']['workers']} workers."]
    (REP / "conservatism_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def interpretation(J):
    S = J["summary"]
    t = {T: S["TFO"][str(T)] for T in TEMPS}
    f = {T: S["FOO"][str(T)] for T in TEMPS}
    c = J["untempered_vs_tempered"]

    def md(s, k):
        return s[k]["median"]

    def fv(v):
        return f"{v:.2f}" if abs(v) < 10 else f"{v:.0f}"

    def rng(k, src, scale=1.0):
        a = [scale * md(src[T], k) for T in TEMPS]
        return f"{fv(min(a))}-{fv(max(a))}"

    devs = ", ".join(f"{100 * md(t[T], 'dev_max_window'):.2g}" for T in TEMPS)
    means = ", ".join(f"{100 * md(t[T], 'dev_mean_window'):.2g}" for T in TEMPS)
    b_rat = [c[str(T)]["bound_ratio_FOO_over_TFO"] for T in TEMPS]
    d_rat = [c[str(T)]["dev_ratio_FOO_over_TFO_median"] for T in TEMPS]
    return (
        f"For the frozen TFO the certified bound exceeds the actual truncation-induced deviation by a median factor of "
        f"{rng('gap_total', t)} per temperature (single runs {min(t[T]['gap_total']['min'] for T in TEMPS):.3g} to "
        f"{max(t[T]['gap_total']['max'] for T in TEMPS):.3g}). The actual deviation is not small: its maximum on the "
        f"admissible window has medians of {devs} % SOC at 0, 25 and 45 C, with window means of {means} % SOC (a "
        f"slowly varying offset), so the 400 s memory would not meet a 0.5 % truncation target even without any "
        f"conservatism. (The paper's factor of 15 to 39 compares the bound with the measured SOC error, a different "
        f"quantity.) Because the "
        f"parameters were identified at L = 400 s, this deviation is the difference between two implementations of "
        f"the same fitted model, not an error with respect to the cell. Most of the gap is in the a-priori size of "
        f"the residual (a x b, medians {rng('F_input', t)}): B_p, the steady state at the largest current, is "
        f"{rng('F_a', t)} times the largest polarisation reached, and the absolute tail sum weights that peak over "
        f"the whole infinite tail, whereas the discarded window sees a polarisation averaged over thousands of "
        f"seconds (b1, {rng('F_b1', t)}; the part of the tail beyond the record length is only "
        f"{rng('F_b1_len', t)}). Sign cancellation plays no role (b2, {rng('F_b2', t)}): the discarded memory "
        f"averages the polarisation over long stretches dominated by the net discharge, so the remainder keeps one "
        f"sign and is close to its absolute sum. The gain chain "
        f"is tight (c x d, {rng('F_gain', t)}): the worst slope kappa1 costs a factor {rng('F_c2', t)} against the "
        f"median slope visited, but the transmission actually realised exceeds the LTI gain at the median slope, "
        f"presumably because the deviation accumulates in low-slope stretches (d2, {rng('F_d2', t)}); the l2 kappa2 coupling (c1) and "
        f"the dynamic attenuation (d1) each stay within 10 %. The consistency residual r_n reaches "
        f"{rng('r_over_R_plant', t)} of the peak truncation remainder but is spiky (RMS about one fifth of its sup); "
        f"it does not enter d. For the untempered FOO the gap is {rng('gap_total', f)}, and almost all of the extra "
        f"conservatism is in the input chain (a x b, {rng('F_input', f)}): B_p = b_p I_max / a_p is a DC level the "
        f"slow untempered element never approaches, and much of the untempered tail lies beyond the record lengths "
        f"(b1_len {rng('F_b1_len', f)}). Tempering lowers the certified bound by a factor {min(b_rat):.3g}-"
        f"{max(b_rat):.3g} but the actual deviation only by a factor {min(d_rat):.3g}-{max(d_rat):.3g} on these "
        f"records: at 400 s the certified advantage of tempering is mostly an advantage of the bound, not of the "
        f"implemented recursion.")


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--report-only", action="store_true")
    a = ap.parse_args()
    J = load_json("conservatism.json") if a.report_only else compute(min(max(a.workers, 1), 2))
    report(J)
    print(f"wrote {OUT} and {REP / 'conservatism_findings.md'}")


if __name__ == "__main__":
    main()
