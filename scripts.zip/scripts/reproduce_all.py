"""Run the whole pipeline (scripts 00 ... 09) in order, after checking the data files; log the runtime of every step.

Modes
    python scripts/reproduce_all.py                    full run: every analysis from the data (recorded step wall
                                                        times sum to about 2.7 h on the machine of results/machine.json;
                                                        not measured end to end; see README_pipeline.md)
    python scripts/reproduce_all.py --skip-heavy       full run, but the steps with a measured wall time above
                                                        10 min (03, 04, 04b, 04c, 08) are replaced by their
                                                        from-results variant (figures/tables/reports from results/)
    python scripts/reproduce_all.py --from-results     no analysis is re-run: every step rebuilds its tables, figures
                                                        and reports from results/*.json|npz (06b needs its per-file
                                                        cache in scratch/robustness_cache; skipped if absent).
                                                        In the public copy, whose result archives omit the measured
                                                        CALCE channels, steps 03, 04 and 06 are skipped and step 09
                                                        skips the two figures drawn from those channels
    add --dry-run to print the plan and the checks without running anything
    add --with-aux to include the auxiliary checks (P0 timing alignment, estimator timing and review checks)
    add --no-data-check to skip the md5 check of the data files (the existence check is always made)

The data check (data_manifest.json): every CALCE archive in dataset/, every extracted workbook in
data_raw/<archive>/ (md5), every processed CSV in data_processed/ (md5). Missing extracted workbooks are extracted
from the archives with --extract. The data are not redistributed (README.md, section 2).

Runtime log: reports/reproduce_log.json (per step: command, return code, wall time from time.perf_counter, and the
CPU time of the child process from os.times, which is 0 on Windows where os.times does not report child processes).
Wall times depend on the machine load.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable

# step id, script, full-run arguments, from-results arguments (None = skipped in that mode), heavy (> 10 min wall)
STEPS = [
    ("00", "00_convert_raw.py", [], None, False),
    ("01", "01_audit.py", [], ["--tables-only"], False),
    ("02", "02_ocv.py", [], None, False),                      # 02 calls 02b; from results: 02b + 09 (fig/table)
    ("02b", "02b_ocv_report.py", None, [], False),
    ("03", "03_relaxation.py", [], ["--from-results"], True),
    ("04", "04_identify.py", ["--resume"], ["--from-results"], True),
    ("04b", "04b_identify_refined.py", ["--resume"], ["--from-results"], True),
    ("04c", "04c_memory_identification.py", ["--resume"], None, True),
    ("05", "05_design_tune.py", [], ["--report-only"], False),
    ("06", "06_validate.py", [], ["--report-only"], False),
    ("06b", "06b_robustness.py", [], ["--report-only"], False),
    ("07", "07_ablation.py", [], ["--report-only"], False),
    ("08", "08_cost.py", [], ["--outputs"], True),
    ("09", "09_figures_tables.py", [], [], False),
]
# from-results steps that redraw figures from the measured CALCE channels of the result archives; the public copy
# of the archives omits these channels (scripts/make_release.py), so the steps are skipped there with a message
NEEDS_MEASURED = {"03", "04", "06"}
MEASURED_PROBE = {"results/relaxation_curves.npz": "fits__SP1_IC_OCV_0C__t_full",
                  "results/identification_arrays.npz": "acc__SP2_0C_DST_80SOC__t",
                  "results/validation_series.npz": "SP2_25C_FUDS_80SOC|t_V"}
AUX = [("p0", "p0_timing_alignment.py", []), ("est_t", "estimator_timing.py", []),
       ("est_c", "estimator_review_checks.py", []), ("est_n", "estimators_notes_build.py", [])]


def md5(p: Path) -> str:
    h = hashlib.md5()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def measured_stripped() -> list[str]:
    """Result archives without the measured CALCE channels (public copy); empty in the authors' project."""
    out = []
    for f, key in MEASURED_PROBE.items():
        p = ROOT / f
        if p.exists():
            with zipfile.ZipFile(p) as zf:
                if key + ".npy" not in zf.namelist():
                    out.append(f)
    return out


def check_data(verify_md5: bool, extract: bool) -> list[str]:
    """Problems with the data files listed in data_manifest.json (empty list = all present and matching)."""
    man = ROOT / "data_manifest.json"
    if not man.exists():
        return ["data_manifest.json missing (run scripts/00_convert_raw.py after placing the archives in dataset/)"]
    M = json.loads(man.read_text(encoding="utf-8"))
    probs = []
    if M.get("n_files") != len(M.get("files", {})):
        probs.append(f"manifest n_files={M.get('n_files')} but {len(M.get('files', {}))} entries")
    for lid, e in M["files"].items():
        z = ROOT / "dataset" / e["source_zip"]
        wb = ROOT / "data_raw" / e["source_folder"] / e["source_workbook"]
        csv = ROOT / e["processed_csv"]
        if not wb.exists() and z.exists() and extract:
            with zipfile.ZipFile(z) as zf:
                zf.extract(e["source_workbook"], wb.parent)
        if not z.exists():
            probs.append(f"{lid}: archive dataset/{e['source_zip']} missing")
        if not wb.exists():
            probs.append(f"{lid}: workbook {wb.relative_to(ROOT)} missing (use --extract)")
        elif verify_md5 and md5(wb) != e["source_md5"]:
            probs.append(f"{lid}: workbook md5 differs from the manifest")
        if not csv.exists():
            probs.append(f"{lid}: {e['processed_csv']} missing (run step 00)")
        elif verify_md5 and md5(csv) != e["csv_md5"]:
            probs.append(f"{lid}: CSV md5 differs from the manifest")
    return probs


def plan(mode: str, skip_heavy: bool, with_aux: bool) -> list[tuple[str, str, list, str]]:
    out = []
    for sid, scr, full, fromres, heavy in STEPS:
        if mode == "from-results" or (skip_heavy and heavy):
            if fromres is None:
                continue
            out.append((sid, scr, fromres, "from-results"))
        elif full is not None:
            out.append((sid, scr, full, "full"))
    if with_aux and mode == "full":
        i = [k for k, s in enumerate(out) if s[0] == "05"][0]        # after identification, before the design
        out[i:i] = [(sid, scr, args, "aux") for sid, scr, args in AUX]
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--from-results", action="store_true")
    g.add_argument("--skip-heavy", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--with-aux", action="store_true")
    ap.add_argument("--no-data-check", action="store_true")
    ap.add_argument("--extract", action="store_true", help="extract missing workbooks from dataset/*.zip")
    ap.add_argument("--keep-going", action="store_true", help="continue after a failed step")
    a = ap.parse_args()
    mode = "from-results" if a.from_results else "full"
    steps = plan(mode, a.skip_heavy, a.with_aux)
    print(f"mode: {mode}{' (skip heavy)' if a.skip_heavy else ''}; python {sys.version.split()[0]}; root {ROOT}")
    t0 = time.perf_counter()
    probs = check_data(verify_md5=not a.no_data_check, extract=a.extract)   # extraction is data preparation, also done in a dry run
    print(f"data check ({'existence' if a.no_data_check else 'existence + md5'}, {time.perf_counter() - t0:.1f} s): "
          + ("ok" if not probs else f"{len(probs)} problem(s)"))
    for p in probs[:20]:
        print("  -", p)
    if mode == "full" and probs and not a.dry_run:
        print("the full run needs the data files; stop")
        return 2
    res_missing = [s for s in ("results/identification.json", "results/frozen_config.json",
                               "results/validation_main.json", "results/ablation.json", "results/cost.json",
                               "results/robustness.json") if not (ROOT / s).exists()]
    if mode == "from-results" and res_missing:
        print("missing results for --from-results:", ", ".join(res_missing))
        return 2
    rob_cache = (ROOT / "scratch" / "robustness_cache").exists()
    stripped = measured_stripped()
    if stripped:
        print("measured CALCE channels absent from " + ", ".join(stripped) + " (public copy): the from-results "
              "variants of steps " + ", ".join(sorted(NEEDS_MEASURED)) + " are skipped and step 09 skips "
              "fig:relax and fig:vmodel; run the full pipeline after downloading the data to rebuild them")
    log = dict(started_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), mode=mode,
               skip_heavy=a.skip_heavy, python=sys.version.split()[0], data_problems=probs, steps=[])
    for sid, scr, args, kind in steps:
        cmd = [PY, str(Path("scripts") / scr)] + list(args)
        if sid == "06b" and kind == "from-results" and not rob_cache:
            print(f"[{sid}] skipped: scratch/robustness_cache absent (tab/fig rebuilt by step 09 from robustness.json)")
            log["steps"].append(dict(step=sid, command=" ".join(cmd[1:]), skipped="no per-file cache"))
            continue
        if sid in NEEDS_MEASURED and kind == "from-results" and stripped:
            print(f"[{sid}] skipped: needs the measured CALCE channels (tables rebuilt by step 09 from results/)")
            log["steps"].append(dict(step=sid, command=" ".join(cmd[1:]), skipped="measured channels absent"))
            continue
        print(f"[{sid}] {kind:12s} {' '.join(cmd[1:])}", flush=True)
        if a.dry_run:
            continue
        w0, c0 = time.perf_counter(), os.times()
        r = subprocess.run(cmd, cwd=ROOT)
        w1, c1 = time.perf_counter(), os.times()
        rec = dict(step=sid, command=" ".join(cmd[1:]), kind=kind, returncode=r.returncode, wall_s=round(w1 - w0, 2),
                   child_cpu_s=round((c1.children_user - c0.children_user) + (c1.children_system - c0.children_system), 2))
        log["steps"].append(rec)
        print(f"[{sid}] rc={r.returncode} wall {rec['wall_s']:.1f} s", flush=True)
        if r.returncode != 0 and not a.keep_going:
            break
    if a.dry_run:
        print(f"dry run: {len(steps)} step(s) planned, nothing executed")
        return 0 if (mode == "from-results" or not probs) else 2
    log["total_wall_s"] = round(time.perf_counter() - t0, 2)
    out = ROOT / "reports" / "reproduce_log.json"
    out.write_text(json.dumps(log, indent=1), encoding="utf-8")
    print(f"total wall {log['total_wall_s']:.1f} s; log: {out.relative_to(ROOT)}")
    return 0 if all(s.get("returncode", 0) == 0 for s in log["steps"]) else 1


if __name__ == "__main__":
    sys.exit(main())
