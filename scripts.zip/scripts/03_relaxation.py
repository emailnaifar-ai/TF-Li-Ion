"""Relaxation-tail study (tempering hypothesis): phenomenological tail laws + mechanistic tempered
fractional element on the 2 h rests after 1 A pulses of the six SP1/SP3 incremental-OCV files.

Writes
    results/relaxation_phenomenological.json   per-segment fits (5 laws, 4 windows) + summaries
    results/relaxation_mechanistic.json        per-file tempered fractional element vs references + summaries
    results/relaxation_curves.npz              every array plotted in the figures
    figures/draft_relax_fits.pdf, figures/draft_relax_lambda.pdf, figures/draft_relax_acf.pdf   (draft figures; the manuscript
    figures fig_relax.pdf and fig_relax_acf.pdf are built by scripts/09a_figs_ocv_relax.py)
    tables/tab_relax_ic.tex, tables/tab_relax_params.tex
    reports/relaxation_findings.md             generated from the two JSON files (no hand-typed numbers)

Usage (project root):  python scripts/03_relaxation.py            # fit + figures + tables + report
                       python scripts/03_relaxation.py --from-results   # figures + tables + report only
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")          # one BLAS thread per worker process

import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import relaxation as R  # noqa: E402

RES = ROOT / "results"
FIG = ROOT / "figures"
TAB = ROOT / "tables"
REP = ROOT / "reports"
if os.environ.get("TFSO_RELAX_SMOKE"):      # code-path smoke test: never touch the project outputs
    RES = FIG = TAB = REP = Path(os.environ["TFSO_RELAX_SMOKE"])
PHEN_JSON = RES / "relaxation_phenomenological.json"
MECH_JSON = RES / "relaxation_mechanistic.json"
CURVES = RES / "relaxation_curves.npz"
T_K = {0: 273.15, 25: 298.15, 45: 318.15}
R_GAS = 8.314462618


def jdump(obj, path: Path) -> None:
    def conv(o):
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, np.bool_):
            return bool(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        raise TypeError(type(o))
    path.write_text(json.dumps(obj, indent=1, default=conv), encoding="utf-8")


def q3(x) -> dict:
    x = np.asarray([v for v in x if v is not None and np.isfinite(v)], float)
    if len(x) == 0:
        return dict(n=0, median=None, q25=None, q75=None)
    return dict(n=int(len(x)), median=float(np.median(x)), q25=float(np.percentile(x, 25)),
                q75=float(np.percentile(x, 75)))


# ======================================================================================================
# Stage 1: fits (parallel over files)
# ======================================================================================================
def run_fits() -> tuple[list, dict, dict]:
    s = R.settings()
    ids = D.load_config()["splits"]["ocv_and_relaxation"]
    for lid in ids:                                  # verification before any analysis (also in workers)
        D.verify_file(lid)
    t0 = time.time()
    out, syn = {}, None
    n_workers = min(7, os.cpu_count() or 1)
    try:
        with ProcessPoolExecutor(max_workers=n_workers) as ex:
            fut = {lid: ex.submit(R.run_file, lid, i) for i, lid in enumerate(ids)}
            fsyn = ex.submit(R.synthetic_control, s["synthetic_control"]["file"], s)
            for lid, f in fut.items():
                try:
                    out[lid] = f.result()
                except Exception as e:            # a killed worker breaks the pool: redo sequentially below
                    print(f"worker for {lid} failed ({type(e).__name__}); will rerun sequentially", flush=True)
            try:
                syn = fsyn.result()
            except Exception as e:
                print(f"synthetic-control worker failed ({type(e).__name__}); will rerun sequentially", flush=True)
    except Exception as e:
        print(f"process pool failed ({type(e).__name__}); falling back to sequential runs", flush=True)
    for i, lid in enumerate(ids):                  # identical seeds, so the results do not depend on the path
        if lid not in out:
            out[lid] = R.run_file(lid, i)
    if syn is None:
        syn = R.synthetic_control(s["synthetic_control"]["file"], s)
    # review 1/2: synthetic control at the FITTED shared-gain parameters, quantised at the file's ADC step
    sc = s["synthetic_control"]
    jobs = {}
    for lid in sc["fitted_parameter_files"]:
        a = out[lid][0]["mechanistic"]["shared_gain"]["tfo"]["all"]
        jobs[lid] = dict(alpha=a["alpha"], log10_a=a["log10_a"], b_mV_per_A=a["b_mV_per_A"],
                         lambdas_s_inv=list(sc["fitted_lambdas_s_inv"]), quantise=True)
    syn_fit = {}
    try:
        with ProcessPoolExecutor(max_workers=max(1, min(n_workers, len(jobs)))) as ex:
            fut = {lid: ex.submit(R.synthetic_control, lid, s, p_, f"fitted_{lid}") for lid, p_ in jobs.items()}
            for lid, f in fut.items():
                try:
                    syn_fit[lid] = f.result()
                except Exception as e:
                    print(f"fitted synthetic control {lid} failed ({type(e).__name__}); rerun sequentially", flush=True)
    except Exception as e:
        print(f"process pool failed ({type(e).__name__}); sequential fitted synthetic controls", flush=True)
    for lid, p_ in jobs.items():
        if lid not in syn_fit:
            syn_fit[lid] = R.synthetic_control(lid, s, p_, f"fitted_{lid}")
    syn = dict(syn, fitted=[syn_fit[lid] for lid in jobs])
    files = [out[lid][0] for lid in ids]
    curves = {}
    for lid in ids:
        for k, v in out[lid][1].items():
            curves[f"{lid}__{k}"] = v
    wall = time.time() - t0
    return files, curves, dict(synthetic=syn, wall_s=wall, n_workers=n_workers)


def kernel_checks(s: dict, mech: list) -> dict:
    """Mode bank vs direct Mittag-Leffler at generic parameters and at every fitted parameter set."""
    sets = [(0.5, 1e-2, 0.0), (0.5, 1e-2, 3e-4), (0.8, 5e-2, 1e-4), (0.97, 2e-3, 1e-3), (0.3, 1e-4, 1e-4),
            (0.6, 1e-3, 2e-3), (0.05, 1e-3, 1e-4), (0.1, 1e-2, 0.0)]
    for f in mech:
        for var in ("shared_gain", "free_gain"):
            a = f["mechanistic"][var]["tfo"]["all"]
            sets.append((round(a["alpha"], 6), float(10 ** a["log10_a"]), float(a["lambda_s_inv"])))
            b = f["mechanistic"][var]["alpha_bound_sensitivity"]
            sets.append((round(b["alpha"], 6), float(10 ** b["log10_a"]), float(b["lambda_s_inv"])))
            for k, band in f["mechanistic"][var]["tfo"].items():     # review 2: SOC-band and branch fits too
                if k != "all":
                    sets.append((round(band["alpha"], 6), float(10 ** band["log10_a"]), float(band["lambda_s_inv"])))
    n_generic = 8
    sets = list(dict.fromkeys(sets))
    kc = R.verify_kernel(s, sets, np.array(s["mechanistic"]["kernel_check_tau_s"], float))
    fit_ = kc["checks"][n_generic:]
    kc.update(n_generic_sets=n_generic, max_rel_err_l1_fitted=max(x["rel_err_l1_bank_plus_tails"] for x in fit_),
              max_frac_l1_outside_bank_fitted=max(x["frac_l1_outside_bank"] for x in fit_),
              max_rel_err_kernel_fitted=max(x["max_rel_err_kernel"] for x in fit_))
    return kc


# ======================================================================================================
# Stage 2: summaries
# ======================================================================================================
def _rows(files: list, t0key: str) -> list[dict]:
    rows = []
    for f in files:
        for e in f["phenomenological"]:
            o = e["fits"][t0key]
            rows.append(dict(file=f["logical_id"], cell=f["cell"], T=f["temperature_C"], **e["meta"], o=o))
    return rows


def _group_summary(rows: list[dict], thr: float, with_boot: bool, s: dict | None = None) -> dict:
    M = R.MODELS
    s = s or R.settings()
    strong = float(s["decision_rules"]["strong_delta_bic"])
    alpha_t = float(s["decision_rules"]["alpha_test"])
    d = dict(n=len(rows))
    if not rows:
        return d
    d["wins_aicc"] = {m: sum(r["o"]["best_aicc"] == m for r in rows) for m in M}
    d["wins_bic"] = {m: sum(r["o"]["best_bic"] == m for r in rows) for m in M}
    d["frac_wins_bic"] = {m: d["wins_bic"][m] / len(rows) for m in M}
    d["mean_akaike_weight"] = {m: float(np.mean([r["o"]["models"][m]["akaike_weight"] for r in rows])) for m in M}
    for ic in ("bic", "aicc"):
        for other in ("PL", "2EXP", "SEXP", "EXP"):
            v = [r["o"]["models"]["TPL"][ic] - r["o"]["models"][other][ic] for r in rows]
            d[f"delta_{ic}_TPL_minus_{other}"] = q3(v) | dict(frac_negative=float(np.mean(np.array(v) < 0)),
                                                             frac_below_minus10=float(np.mean(np.array(v) < -strong)))
    # review 1: Delta-BIC per subsample point (removes the linear scaling with the arbitrary subsample size)
    d["delta_bic_per_point_TPL_minus_PL"] = q3([(r["o"]["models"]["TPL"]["bic"] - r["o"]["models"]["PL"]["bic"]) / r["o"]["n_sub"] for r in rows])
    d["rmse_mV"] = {m: q3([r["o"]["models"][m]["rmse_mV"] for r in rows]) for m in M}
    d["max_abs_err_mV"] = {m: q3([r["o"]["models"][m]["max_abs_err_mV"] for r in rows]) for m in M}
    d["rmse_full_mV"] = {m: q3([r["o"]["models"][m]["rmse_full_mV"] for r in rows]) for m in M}
    d["acf_lag1"] = {m: q3([r["o"]["models"][m]["acf_lag1"] for r in rows]) for m in M}
    d["frac_ljung_box_p_below_0p05"] = {m: float(np.mean([r["o"]["models"][m]["ljung_box_p"] < alpha_t for r in rows])) for m in M}
    d["abs_vinf_minus_last_mV"] = {m: q3([abs(r["o"]["models"][m]["vinf_minus_last_mV"]) for r in rows]) for m in ("PL", "TPL")}
    d["n_nesting_violations"] = int(sum(not (r["o"]["nesting"]["tpl_le_pl"] and r["o"]["nesting"]["twoexp_le_exp"]) for r in rows))
    d["n_tpl_nest_fallback"] = int(sum(r["o"]["nesting"]["tpl_nest_fallback"] for r in rows))
    lam = np.array([r["o"]["tpl_lambda"]["lambda_hat_reported"] for r in rows])
    d["tpl_lambda_s_inv"] = q3(lam) | dict(frac_zero=float(np.mean(lam < thr)))
    d["tpl_inverse_lambda_s"] = q3([1 / x for x in lam if x >= thr])
    d["tpl_beta"] = q3([r["o"]["models"]["TPL"]["params"]["beta"] for r in rows])
    d["frac_lambda_t_end_ge_1"] = float(np.mean([r["o"]["tpl_lambda"]["lambda_t_end"] >= 1 for r in rows]))
    cv = [abs(r["o"]["tpl_lambda"]["corr_vinf_lambda"]) for r in rows if r["o"]["tpl_lambda"]["corr_vinf_lambda"] is not None]
    d["abs_corr_vinf_lambda"] = q3(cv) | dict(frac_above=float(np.mean(np.array(cv) > float(s["decision_rules"]["corr_confound"]))))
    if "profile_ci95" in rows[0]["o"]["tpl_lambda"]:
        tl = [r["o"]["tpl_lambda"] for r in rows]
        d["frac_profile_ci_excludes_zero"] = float(np.mean([x["profile_excludes_zero"] for x in tl]))
        d["frac_profile_ci_excludes_zero_cc384"] = float(np.mean([x["profile_excludes_zero_cc384"] for x in tl]))
        d["n_profile_multimodal"] = int(sum(x["profile_ci95"]["n_intervals"] > 1 for x in tl))
        d["frac_profile_lower_t_end_ge_1"] = float(np.mean([x["profile_ci95"]["lower"] * r["o"]["t_end_s"] >= 1 for x, r in zip(tl, rows)]))
        d["frac_profile_upper_censored"] = float(np.mean([x["profile_ci95"]["upper_censored_at_bound"] for x in tl]))
        d["frac_lr_tpl_vs_pl_p_below_0p05"] = float(np.mean([x["lr_p_chibar"] < alpha_t for x in tl]))
    if with_boot:
        bo = [r["o"]["tpl_lambda"]["bootstrap"] for r in rows]
        nu = [r["o"]["tpl_lambda"]["null_pl"] for r in rows]
        d["frac_bootstrap_ci_excludes_zero"] = float(np.mean([b["excludes_zero"] for b in bo]))
        d["frac_bootstrap_lower_t_end_ge_1"] = float(np.mean(
            [b["lambda_ci95"][0] * r["o"]["t_end_s"] >= 1 for b, r in zip(bo, rows)]))
        d["bootstrap_ci_width_rel"] = q3([(b["lambda_ci95"][1] - b["lambda_ci95"][0]) / r["o"]["tpl_lambda"]["lambda_hat_s_inv"]
                                          for b, r in zip(bo, rows) if r["o"]["tpl_lambda"]["lambda_hat_s_inv"] >= thr])
        d["bootstrap_block_s"] = q3([b["block"]["block_s"] for b in bo])
        d["tpl_resid_acf_at_120s"] = q3([b["block"]["acf_at_120s"] for b in bo])
        d["tpl_resid_smoothed_acf_at_120s"] = q3([b["block"]["acf_smoothed_at_120s"] for b in bo])
        d["tpl_resid_decorrelation_lag_s"] = q3([b["block"]["decorrelation_lag_s"] for b in bo])
        d["null_block_s"] = q3([x["block"]["block_s"] for x in nu])
        d["frac_null_calibrated_p_below_alpha"] = float(np.mean([x["p_calibrated"] < alpha_t for x in nu]))
        d["null_frac_dbic_below_strong"] = dict(mean=float(np.mean([x["frac_null_dbic_below_strong"] for x in nu])),
                                                max=float(np.max([x["frac_null_dbic_below_strong"] for x in nu])))
        d["null_dbic_q05"] = q3([x["dbic_null_q05"] for x in nu])
        dtp = np.array([r["o"]["models"]["TPL"]["bic"] - r["o"]["models"]["PL"]["bic"] for r in rows])
        pc = np.array([x["p_calibrated"] for x in nu])
        d["n_dbic_below_strong"] = int(np.sum(dtp < -strong))
        d["n_dbic_below_strong_and_calibrated"] = int(np.sum((dtp < -strong) & (pc < alpha_t)))
        d["tpl_true_frac_dbic_below_strong"] = q3([b["tpl_true_frac_dbic_below_strong"] for b in bo])
    return d


def _design_summary(files: list, s: dict) -> dict:
    """Review 1: BIC ranking of the primary rests under every t0 and every subsample design."""
    t0m = str(int(s["t0_s"]))
    thr = s["lambda_zero_threshold_s_inv"]
    cc = float(s["decision_rules"]["corr_confound"])
    strong = float(s["decision_rules"]["strong_delta_bic"])
    recs = [e for f in files for e in f["phenomenological"] if e["meta"]["primary"]]
    out = {}

    def summ(items):
        wins = {m: sum(x["best_bic"] == m for x in items) for m in R.MODELS}
        top = max(wins, key=wins.get)
        dp = [x["dbic_TPL_minus"]["PL"] for x in items]
        cv = [abs(x["corr_vinf_lambda"]) for x in items if x.get("corr_vinf_lambda") is not None]
        return dict(n=len(items), wins_bic=wins, top=top, frac_top=wins[top] / len(items), frac_tpl=wins["TPL"] / len(items),
                    n_sub=q3([x["n_sub"] for x in items]), dbic_TPL_minus_PL=q3(dp),
                    dbic_per_point_TPL_minus_PL=q3([v / x["n_sub"] for v, x in zip(dp, items)]),
                    frac_dbic_TPL_minus_PL_below_strong=float(np.mean(np.array(dp) < -strong)),
                    tpl_lambda_median=float(np.median([x["tpl_lambda_s_inv"] if x["tpl_lambda_s_inv"] >= thr else 0.0 for x in items])),
                    frac_abs_corr_vinf_lambda_above=float(np.mean(np.array(cv) > cc)) if cv else None,
                    n_nesting_violations=int(sum(not x.get("nesting_ok", True) for x in items)))

    def as_design(o):
        return dict(n_sub=o["n_sub"], best_bic=o["best_bic"],
                    dbic_TPL_minus={m: o["models"]["TPL"]["bic"] - o["models"][m]["bic"] for m in R.MODELS if m != "TPL"},
                    tpl_lambda_s_inv=o["tpl_lambda"]["lambda_hat_s_inv"], corr_vinf_lambda=o["tpl_lambda"]["corr_vinf_lambda"],
                    nesting_ok=o["nesting"]["tpl_le_pl"] and o["nesting"]["twoexp_le_exp"])
    t0s = sorted({float(s["t0_s"])} | {float(x) for x in s["t0_sensitivity_s"]})
    out["by_t0"] = {str(int(t)): summ([as_design(e["fits"][str(int(t))]) for e in recs]) for t in t0s}
    main_name = "log" + str(int(s["n_subsample"]))
    out["by_design_at_main_t0"] = {main_name: out["by_t0"][t0m]}
    for dz in s["design_sensitivity"]:
        out["by_design_at_main_t0"][dz] = summ([e["designs"][dz] for e in recs])
    keys = list(out["by_design_at_main_t0"])
    same = []
    for e in recs:
        winners = {e["fits"][t0m]["best_bic"]} | {e["designs"][k]["best_bic"] for k in keys[1:]}
        same.append(len(winners) == 1)
    out["frac_same_winner_all_designs"] = float(np.mean(same))
    out["designs_order"] = keys
    return out


def _holm(pvals: dict) -> dict:
    k = [x for x in pvals if pvals[x] is not None]
    order = sorted(k, key=lambda x: pvals[x])
    m = len(order)
    adj, run = {}, 0.0
    for i, key in enumerate(order):
        run = max(run, min(1.0, (m - i) * pvals[key]))
        adj[key] = run
    return adj


def _pairs_test(a: list, b: list) -> dict:
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = dict(n_pairs=int(len(a)))
    if len(a) >= 5 and np.any(a != b):
        w = stats.wilcoxon(a, b)
        d.update(wilcoxon_p=float(w.pvalue))
    d.update(median_diff=float(np.median(a - b)) if len(a) else None,
             median_ratio=float(np.median(a[(a > 0) & (b > 0)] / b[(a > 0) & (b > 0)])) if np.any((a > 0) & (b > 0)) else None)
    return d


def summarise_phen(files: list, s: dict) -> dict:
    thr = s["lambda_zero_threshold_s_inv"]
    t0s = [str(int(s["t0_s"]))] + [str(int(x)) for x in s["t0_sensitivity_s"]]
    out = {}
    for t0 in t0s:
        rows = _rows(files, t0)
        prim = [r for r in rows if r["primary"]]
        main = t0 == t0s[0]
        g = dict(all_primary=_group_summary(prim, thr, main, s),
                 flagged=_group_summary([r for r in rows if not r["primary"]], thr, main, s))
        for T in (0, 25, 45):
            g[f"T{T}"] = _group_summary([r for r in prim if r["T"] == T], thr, main, s)
        for br in ("discharge", "charge"):
            g[f"branch_{br}"] = _group_summary([r for r in prim if r["branch"] == br], thr, main, s)
            for T in (0, 25, 45):
                g[f"T{T}_{br}"] = _group_summary([r for r in prim if r["branch"] == br and r["T"] == T], thr, main, s)
        for c in ("SP20-1", "SP20-3"):
            g[f"cell_{c}"] = _group_summary([r for r in prim if r["cell"] == c], thr, main, s)
        out[t0] = g
    # ---- interpretation tests on the main window ---------------------------------------------------
    rows = [r for r in _rows(files, t0s[0]) if r["primary"]]
    lam = lambda r: r["o"]["tpl_lambda"]["lambda_hat_reported"]  # noqa: E731
    beta = lambda r: r["o"]["models"]["TPL"]["params"]["beta"]  # noqa: E731
    tests = {}
    groups = [[lam(r) for r in rows if r["T"] == T] for T in (0, 25, 45)]
    kw = stats.kruskal(*groups)
    tests["lambda_vs_T_kruskal"] = dict(H=float(kw.statistic), p=float(kw.pvalue),
                                        medians={str(T): float(np.median(gv)) for T, gv in zip((0, 25, 45), groups)})
    sp = stats.spearmanr([1 / T_K[r["T"]] for r in rows], [lam(r) for r in rows])
    tests["lambda_vs_invT_spearman"] = dict(rho=float(sp.statistic), p=float(sp.pvalue))
    sp = stats.spearmanr([r["soc_label"] for r in rows], [lam(r) for r in rows])
    tests["lambda_vs_soc_spearman"] = dict(rho=float(sp.statistic), p=float(sp.pvalue))
    for T in (0, 25, 45):
        rr = [r for r in rows if r["T"] == T]
        sp = stats.spearmanr([r["soc_label"] for r in rr], [lam(r) for r in rr])
        tests[f"lambda_vs_soc_spearman_T{T}"] = dict(rho=float(sp.statistic), p=float(sp.pvalue), n=len(rr))
    # cells: SP1 vs SP3 paired by (T, branch, ordinal of the rest within the branch)
    def key(r, rr):
        same = [x for x in rr if x["file"] == r["file"] and x["branch"] == r["branch"]]
        same.sort(key=lambda x: x["seg_index"])
        return (r["T"], r["branch"], [x["seg_index"] for x in same].index(r["seg_index"]))
    k1 = {key(r, rows): r for r in rows if r["cell"] == "SP20-1"}
    k3 = {key(r, rows): r for r in rows if r["cell"] == "SP20-3"}
    common = sorted(set(k1) & set(k3))
    tests["cells_SP1_vs_SP3_lambda"] = _pairs_test([lam(k1[k]) for k in common], [lam(k3[k]) for k in common])
    tests["cells_SP1_vs_SP3_beta"] = _pairs_test([beta(k1[k]) for k in common], [beta(k3[k]) for k in common])
    for T in (0, 25, 45):
        cT = [k for k in common if k[0] == T]
        tests[f"cells_SP1_vs_SP3_lambda_T{T}"] = _pairs_test([lam(k1[k]) for k in cT], [lam(k3[k]) for k in cT])
    # branches: discharge rest vs charge rest at the nearest SOC label (|dx| <= 0.03) in the same file
    pa, pb, pba, pbb, pf = [], [], [], [], []
    for f in files:
        rr = [r for r in rows if r["file"] == f["logical_id"]]
        dis = [r for r in rr if r["branch"] == "discharge"]
        cha = [r for r in rr if r["branch"] == "charge"]
        for r in dis:
            if not cha:
                break
            c = min(cha, key=lambda x: abs(x["soc_label"] - r["soc_label"]))
            if abs(c["soc_label"] - r["soc_label"]) <= 0.03:
                pa.append(lam(r)); pb.append(lam(c)); pba.append(beta(r)); pbb.append(beta(c)); pf.append(f["logical_id"])
    tests["branches_discharge_vs_charge_lambda"] = _pairs_test(pa, pb)
    tests["branches_discharge_vs_charge_beta"] = _pairs_test(pba, pbb)
    # ---- review 1: multiplicity correction over the rest-level tests, and file-clustered tests ------------
    fam = dict(T_kruskal=tests["lambda_vs_T_kruskal"]["p"], invT_spearman=tests["lambda_vs_invT_spearman"]["p"],
               SOC_spearman=tests["lambda_vs_soc_spearman"]["p"],
               cells_lambda=tests["cells_SP1_vs_SP3_lambda"].get("wilcoxon_p"),
               cells_beta=tests["cells_SP1_vs_SP3_beta"].get("wilcoxon_p"),
               branch_lambda=tests["branches_discharge_vs_charge_lambda"].get("wilcoxon_p"),
               branch_beta=tests["branches_discharge_vs_charge_beta"].get("wilcoxon_p"))
    tests["multiplicity"] = dict(method=s["decision_rules"]["multiplicity"], raw=fam, adjusted=_holm(fam),
                                 bonferroni={k: min(1.0, v * len([x for x in fam.values() if x is not None]))
                                             for k, v in fam.items() if v is not None})
    rng = np.random.default_rng(np.random.SeedSequence(int(s["seed"]), spawn_key=(4242,)))
    per = {}
    for f in files:
        rr = [r for r in rows if r["file"] == f["logical_id"]]
        per[f["logical_id"]] = (np.array([r["soc_label"] for r in rr]), np.array([lam(r) for r in rr]))
    rho = {k: float(stats.spearmanr(x, y).statistic) for k, (x, y) in per.items()}
    stat = float(np.mean(list(rho.values())))
    n_perm = int(s["null_calibration"].get("n_perm", 5000))
    null = np.empty(n_perm)
    for i in range(n_perm):
        null[i] = np.mean([stats.spearmanr(x, rng.permutation(y)).statistic for x, y in per.values()])
    tests["lambda_vs_soc_file_clustered"] = dict(
        statistic="mean over files of the within-file Spearman rho(x, lambda); null: lambda permuted within each file",
        per_file_rho=rho, mean_rho=stat, n_files_negative=int(sum(v < 0 for v in rho.values())), n_perm=n_perm,
        p=float((1 + np.sum(np.abs(null) >= abs(stat))) / (1 + n_perm)))
    pf_ = np.array(pf)
    dmed = {k: float(np.median(np.array(pa)[pf_ == k] - np.array(pb)[pf_ == k])) for k in dict.fromkeys(pf)}
    v = np.array(list(dmed.values()))
    signs = np.array(np.meshgrid(*[[-1, 1]] * len(v))).reshape(len(v), -1).T
    null_b = np.abs((signs * v).mean(axis=1))
    tests["branches_lambda_file_clustered"] = dict(
        statistic="mean over files of the within-file median (lambda_discharge - lambda_charge); exact sign-flip over files",
        per_file_median_diff=dmed, n_files_positive=int(np.sum(v > 0)),
        p=float(np.mean(null_b >= abs(v.mean()) - 1e-15)), min_attainable_p=float(2 / 2 ** len(v)))
    tests["clustered_multiplicity"] = dict(adjusted=_holm(dict(SOC=tests["lambda_vs_soc_file_clustered"]["p"],
                                                                branch=tests["branches_lambda_file_clustered"]["p"])))
    out["tests_main_window"] = tests
    out["design_sensitivity"] = _design_summary(files, s)
    return out


def _boot_arr(f, var, key):
    return np.array(f["mechanistic"][var]["bootstrap"][f"samples_{key}"], float)


def summarise_mech(files: list, s: dict) -> dict:
    thr = s["lambda_zero_threshold_s_inv"]
    out = {}
    for var in ("shared_gain", "free_gain"):
        v = {}
        per = {}
        for f in files:
            m = f["mechanistic"][var]
            a = m["tfo"]["all"]
            ref = m["reference"]
            per[f["logical_id"]] = dict(
                T=f["temperature_C"], cell=f["cell"], alpha=a["alpha"], lambda_s_inv=a["lambda_s_inv"],
                inverse_lambda_s=(1 / a["lambda_s_inv"]) if a["lambda_s_inv"] >= thr else None,
                inverse_lambda_h=(1 / a["lambda_s_inv"] / 3600) if a["lambda_s_inv"] >= thr else None,
                lambda_profile_ci95=[a["lambda_profile_ci95"]["lower"], a["lambda_profile_ci95"]["upper"]],
                lambda_boot_ci95=[m["bootstrap"]["lambda_s_inv"][0], m["bootstrap"]["lambda_s_inv"][2]],
                alpha_boot_ci95=[m["bootstrap"]["alpha"][0], m["bootstrap"]["alpha"][2]],
                alpha_at_bound=a["alpha_at_bound"], rmse_mV=a["rmse_mV"],
                dbic_vs_untempered=a["bic"] - a["untempered"]["bic"], daicc_vs_untempered=a["aicc"] - a["untempered"]["aicc"],
                lr_vs_untempered=a["lr_tempered_vs_untempered"],
                dbic_vs_rc_alpha1=a["bic"] - ref["rc"]["bic"], daicc_vs_rc_alpha1=a["aicc"] - ref["rc"]["aicc"],
                dbic_vs_2rc=a["bic"] - ref["two_rc"]["bic"], daicc_vs_2rc=a["aicc"] - ref["two_rc"]["aicc"],
                best_bic_model=min((("TFO", a["bic"]), ("TFO_lambda0", a["untempered"]["bic"]), ("RC_alpha1", ref["rc"]["bic"]),
                                    ("2RC", ref["two_rc"]["bic"])), key=lambda x: x[1])[0],
                alpha_sensitivity=dict(alpha=m["alpha_bound_sensitivity"]["alpha"],
                                       lambda_s_inv=m["alpha_bound_sensitivity"]["lambda_s_inv"],
                                       dbic_vs_bounded=m["alpha_bound_sensitivity"]["bic"] - a["bic"],
                                       log10_a=m["alpha_bound_sensitivity"]["log10_a"],
                                       log10_a_at_bound=m["alpha_bound_sensitivity"]["log10_a_at_bound"],
                                       alpha_at_bound=m["alpha_bound_sensitivity"]["alpha_at_bound"],
                                       a_flatness_rel_sse_change=m["alpha_bound_sensitivity"].get("a_flatness_rel_sse_change"),
                                       lambda_profile_ci95=[m["alpha_bound_sensitivity"]["lambda_profile_ci95"]["lower"],
                                                            m["alpha_bound_sensitivity"]["lambda_profile_ci95"]["upper"]],
                                       lambda_profile_excludes_zero=m["alpha_bound_sensitivity"]["lambda_profile_ci95"]["excludes_zero"],
                                       lr_p_chibar=m["alpha_bound_sensitivity"]["lr_tempered_vs_untempered"]["p_chibar"],
                                       dbic_vs_2rc=m["alpha_bound_sensitivity"]["bic"] - ref["two_rc"]["bic"]),
                log10_a=a["log10_a"], log10_a_at_bound=a["log10_a_at_bound"], lambda_refined=a.get("lambda_refined"),
                lambda_profile_excludes_zero=a["lambda_profile_ci95"]["excludes_zero"],
                lambda_profile_intervals=a["lambda_profile_ci95"]["intervals"],
                a_flatness_rel_sse_change=m["a_flatness"]["rel_sse_change"],
                boot_frac_log10_a_at_bound=m["bootstrap"].get("frac_log10_a_at_bound"),
                bands={k: dict(lambda_s_inv=b["lambda_s_inv"], ci=[b["lambda_profile_ci95"]["lower"], b["lambda_profile_ci95"]["upper"]],
                               alpha=b["alpha"], n_seg=b["n_seg"])
                       for k, b in m["tfo"].items() if k != "all"},
                residual_acf_median_lag1=m["residual_acf"]["median_lag1"])
            if var == "shared_gain":
                per[f["logical_id"]].update(R_p_Ohm=a["R_p_Ohm"], C_p=a["C_p"], R_dc_Ohm=a["R_dc_Ohm"],
                                            R_p_identified=a["R_p_identified"], char_time_s=a["char_time_s"],
                                            R_dc_boot_ci95=[m["bootstrap"]["R_dc_Ohm"][0], m["bootstrap"]["R_dc_Ohm"][2]],
                                            R_p_boot_ci95=[m["bootstrap"]["R_p_Ohm"][0], m["bootstrap"]["R_p_Ohm"][2]],
                                            C_p_boot_ci95=[m["bootstrap"]["C_p"][0], m["bootstrap"]["C_p"][2]],
                                            jacobian=m["jacobian"])
        v["per_file"] = per
        v["best_bic_counts"] = {k: sum(p["best_bic_model"] == k for p in per.values()) for k in ("TFO", "TFO_lambda0", "RC_alpha1", "2RC")}
        v["n_files_lambda_profile_excludes_zero"] = sum(p["lambda_profile_excludes_zero"] for p in per.values())
        v["n_files_lr_p_below_alpha"] = sum(p["lr_vs_untempered"]["p_chibar"] < float(s["decision_rules"]["alpha_test"]) for p in per.values())
        v["n_files_log10_a_at_bound"] = sum(p["log10_a_at_bound"] for p in per.values())
        v["n_files_sensitivity_log10_a_at_bound"] = sum(p["alpha_sensitivity"]["log10_a_at_bound"] for p in per.values())
        v["n_files_sensitivity_lambda_profile_excludes_zero"] = sum(p["alpha_sensitivity"]["lambda_profile_excludes_zero"] for p in per.values())
        v["n_files_sensitivity_2rc_preferred"] = sum(p["alpha_sensitivity"]["dbic_vs_2rc"] > 0 for p in per.values())
        v["n_files_lambda_boot_excludes_zero"] = sum(p["lambda_boot_ci95"][0] >= thr for p in per.values())
        v["n_files_alpha_at_bound"] = sum(p["alpha_at_bound"] for p in per.values())
        # Arrhenius-type fit of ln(lambda) vs 1/T (per cell and pooled), bootstrap over the file replicates
        arr = {}
        for cell in ("SP20-1", "SP20-3", "pooled"):
            fs = [f for f in files if cell == "pooled" or f["cell"] == cell]
            lamh = np.array([f["mechanistic"][var]["tfo"]["all"]["lambda_s_inv"] for f in fs])
            x = np.array([1 / T_K[f["temperature_C"]] for f in fs])
            d = dict(n_points=len(fs), n_lambda_zero=int(np.sum(lamh < thr)))
            if np.all(lamh >= thr) and len(set(x)) >= 2:
                sl, ic, rv, pv, se = stats.linregress(x, np.log(lamh))
                B = np.stack([_boot_arr(f, var, "lambda") for f in fs])        # (files, n_boot)
                ok = np.all(B >= thr, axis=0)
                sb = [stats.linregress(x, np.log(B[:, j])).slope for j in np.flatnonzero(ok)]
                d.update(slope_K=float(sl), Ea_kJ_mol=float(-sl * R_GAS / 1000), ols_se_Ea_kJ_mol=float(se * R_GAS / 1000) if len(fs) > 2 else None,
                         r2=float(rv ** 2), frac_boot_all_lambda_positive=float(ok.mean()),
                         Ea_boot_ci95_kJ_mol=[float(-np.percentile(sb, 97.5) * R_GAS / 1000), float(-np.percentile(sb, 2.5) * R_GAS / 1000)] if len(sb) >= 20 else None)
            else:
                d["note"] = "lambda-hat below the resolvable threshold for at least one temperature; no Arrhenius fit"
            arr[cell] = d
        v["arrhenius_lambda"] = arr
        # alpha vs T
        v["alpha_vs_T"] = {f["logical_id"]: [f["temperature_C"], f["mechanistic"][var]["tfo"]["all"]["alpha"],
                                            *[f["mechanistic"][var]["bootstrap"]["alpha"][i] for i in (0, 2)]] for f in files}
        # cells: bootstrap difference of lambda and alpha per temperature
        cells = {}
        for T in (0, 25, 45):
            f1 = [f for f in files if f["cell"] == "SP20-1" and f["temperature_C"] == T][0]
            f3 = [f for f in files if f["cell"] == "SP20-3" and f["temperature_C"] == T][0]
            dl = _boot_arr(f1, var, "lambda") - _boot_arr(f3, var, "lambda")
            da = _boot_arr(f1, var, "alpha") - _boot_arr(f3, var, "alpha")
            cells[str(T)] = dict(lambda_SP1=f1["mechanistic"][var]["tfo"]["all"]["lambda_s_inv"],
                                 lambda_SP3=f3["mechanistic"][var]["tfo"]["all"]["lambda_s_inv"],
                                 diff_lambda_ci95=[float(x) for x in np.percentile(dl, [2.5, 97.5])],
                                 diff_alpha_ci95=[float(x) for x in np.percentile(da, [2.5, 97.5])])
        v["cells_SP1_vs_SP3"] = cells
        # branches: overlap of profile intervals of the discharge- and charge-branch fits
        br = {}
        for f in files:
            t = f["mechanistic"][var]["tfo"]
            if "branch_discharge" in t and "branch_charge" in t:
                cd, cc = t["branch_discharge"]["lambda_profile_ci95"], t["branch_charge"]["lambda_profile_ci95"]
                br[f["logical_id"]] = dict(lambda_discharge=t["branch_discharge"]["lambda_s_inv"], ci_discharge=[cd["lower"], cd["upper"]],
                                           lambda_charge=t["branch_charge"]["lambda_s_inv"], ci_charge=[cc["lower"], cc["upper"]],
                                           alpha_discharge=t["branch_discharge"]["alpha"], alpha_charge=t["branch_charge"]["alpha"],
                                           intervals_overlap=bool(cd["lower"] <= cc["upper"] and cc["lower"] <= cd["upper"]))
        v["branches"] = br
        out[var] = v
    return out


def fig_arrays(files: list, curves: dict, s: dict) -> dict:
    """Arrays for the fits figure: representative rest of every file, fits on a fine log grid."""
    out = {}
    for f in files:
        lid = f["logical_id"]
        p = f"{lid}__rep_"
        tf, yf = curves[p + "t_full"], curves[p + "y_full"]
        tg = np.geomspace(tf[0], tf[-1], 400)
        out[f"fits__{lid}__t_full"] = tf
        out[f"fits__{lid}__V_full_mV"] = yf
        out[f"fits__{lid}__t_sub"] = curves[p + "t_sub"]
        out[f"fits__{lid}__V_sub_mV"] = curves[p + "y_sub"]
        out[f"fits__{lid}__t_grid"] = tg
        for m in R.MODELS:
            th, c = curves[p + f"theta_{m}"], curves[p + f"c_{m}"]
            out[f"fits__{lid}__{m}_grid_mV"] = R.predict(m, th, c, tg)
            out[f"fits__{lid}__{m}_Vinf_mV"] = np.array(c[0])
            out[f"fits__{lid}__{m}_resid_sub_mV"] = curves[p + "y_sub"] - R.predict(m, th, c, curves[p + "t_sub"])
        out[f"fits__{lid}__seg_index"] = np.array(f["representative_seg_index"])
    # lambda figure: per-segment TPL lambda with bootstrap CI (main window), and mechanistic per file
    key = str(int(s["t0_s"]))
    cols = dict(file=[], T=[], cell=[], branch=[], soc=[], lam=[], lo=[], hi=[], plo=[], phi=[], primary=[])
    for fi, f in enumerate(files):
        for e in f["phenomenological"]:
            o = e["fits"][key]["tpl_lambda"]
            cols["file"].append(fi); cols["T"].append(f["temperature_C"]); cols["cell"].append(1 if f["cell"] == "SP20-1" else 3)
            cols["branch"].append(0 if e["meta"]["branch"] == "discharge" else 1); cols["soc"].append(e["meta"]["soc_label"])
            cols["lam"].append(o["lambda_hat_reported"]); cols["lo"].append(o["bootstrap"]["lambda_ci95"][0])
            cols["hi"].append(o["bootstrap"]["lambda_ci95"][1]); cols["plo"].append(o["profile_ci95"]["lower"])
            cols["phi"].append(o["profile_ci95"]["upper"]); cols["primary"].append(int(e["meta"]["primary"]))
    for k, v in cols.items():
        out[f"lam__seg_{k}"] = np.array(v)
    for var in ("shared_gain", "free_gain"):
        mt, ml, mlo, mhi, mc = [], [], [], [], []
        bt, bl, blo, bhi, bc, bb = [], [], [], [], [], []
        for f in files:
            m = f["mechanistic"][var]
            mt.append(f["temperature_C"]); mc.append(1 if f["cell"] == "SP20-1" else 3)
            ml.append(m["tfo"]["all"]["lambda_s_inv"]); mlo.append(m["bootstrap"]["lambda_s_inv"][0]); mhi.append(m["bootstrap"]["lambda_s_inv"][2])
            for bi, band in enumerate(("soc_high", "soc_medium", "soc_low")):
                if band in m["tfo"]:
                    b = m["tfo"][band]
                    bt.append(f["temperature_C"]); bc.append(1 if f["cell"] == "SP20-1" else 3); bb.append(bi)
                    bl.append(b["lambda_s_inv"]); blo.append(b["lambda_profile_ci95"]["lower"]); bhi.append(b["lambda_profile_ci95"]["upper"])
        for k, v in dict(T=mt, cell=mc, lam=ml, lo=mlo, hi=mhi).items():
            out[f"lam__mech_{var}_{k}"] = np.array(v)
        for k, v in dict(T=bt, cell=bc, band=bb, lam=bl, lo=blo, hi=bhi).items():
            out[f"lam__band_{var}_{k}"] = np.array(v)
    # ACF figure: median residual ACF per model and temperature (primary rests, main window)
    for T in (0, 25, 45):
        for m in R.MODELS:
            A = [e["fits"][key]["models"][m]["acf"] for f in files if f["temperature_C"] == T
                 for e in f["phenomenological"] if e["meta"]["primary"]]
            A = np.array(A)
            out[f"acf__T{T}__{m}_median"] = np.median(A, axis=0)
            out[f"acf__T{T}__{m}_q25"] = np.percentile(A, 25, axis=0)
            out[f"acf__T{T}__{m}_q75"] = np.percentile(A, 75, axis=0)
        mA = [f["mechanistic"]["shared_gain"]["residual_acf"]["acf_median"] for f in files if f["temperature_C"] == T]
        out[f"acf__T{T}__mech_shared_median"] = np.median(np.array(mA), axis=0)
        mA = [f["mechanistic"]["free_gain"]["residual_acf"]["acf_median"] for f in files if f["temperature_C"] == T]
        out[f"acf__T{T}__mech_free_median"] = np.median(np.array(mA), axis=0)
        out[f"acf__T{T}__n_segments"] = np.array(sum(e["meta"]["primary"] for f in files if f["temperature_C"] == T
                                                     for e in f["phenomenological"]))
    return out


def save_all(files: list, curves: dict, extra: dict) -> None:
    s = R.settings()
    cfg = D.load_config()
    meta = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                script="scripts/03_relaxation.py", module="src/tfso/relaxation.py",
                files=cfg["splits"]["ocv_and_relaxation"], settings={k: v for k, v in s.items()},
                t_definition="t = time since the last sample under current (data.get_relaxations); window [t0, end of rest]",
                likelihood_caveat=("Gaussian iid likelihood on the log-spaced subsample; residuals are autocorrelated and "
                                   "quantised at the ADC step, so AICc/BIC rank models but nominal p-values and "
                                   "profile intervals are optimistic"),
                wall_time_s=extra["wall_s"], n_workers=extra.get("n_workers"))
    phen = dict(meta=meta, summary=summarise_phen(files, s),
                segments=[dict(logical_id=f["logical_id"], cell=f["cell"], temperature_C=f["temperature_C"],
                               verification_passed=f["verification_passed"], n_rests=f["n_rests"], n_primary=f["n_primary"],
                               runtime_s=f["runtime_s"], rests=f["phenomenological"]) for f in files])
    kc = kernel_checks(s, files)
    mech = dict(meta=meta | dict(quadrature=dict(n_nodes=kc["n_nodes"], lumped_low_node=True, r_min=kc["r_min"],
                                                 r_max=kc["r_max"], du=kc["du"])),
                kernel_verification=kc, summary=summarise_mech(files, s), synthetic_control=extra["synthetic"],
                files=[dict(logical_id=f["logical_id"], cell=f["cell"], temperature_C=f["temperature_C"], **f["mechanistic"])
                       for f in files])
    jdump(phen, PHEN_JSON)
    jdump(mech, MECH_JSON)
    arrays = dict(curves)
    arrays.update(fig_arrays(files, curves, s))
    np.savez_compressed(CURVES, **{k: np.asarray(v) for k, v in arrays.items()})



# ======================================================================================================
# Stage 3: draft figures (vector PDF) - every plotted array is read from results/relaxation_curves.npz
# ======================================================================================================
# Categorical slots of the validated reference palette (dataviz skill, references/palette.md), light mode,
# fixed order; lines use the adjacent-pair rule, the scatter panels use only slots 1-3 (all-pairs safe).
SERIES = {"PL": "#2a78d6", "EXP": "#eb6834", "TPL": "#1baf7a", "2EXP": "#eda100", "SEXP": "#e87ba4"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
BRANCH = {0: "#2a78d6", 1: "#eb6834"}
TCOL = {0: "#2a78d6", 25: "#eb6834", 45: "#1baf7a"}
CELL_MARK = {1: "o", 3: "s"}


def _style():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7,
                         "legend.fontsize": 7, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
                         "ytick.color": INK2, "axes.linewidth": 0.6, "grid.color": GRID, "grid.linewidth": 0.5,
                         "grid.linestyle": "-", "axes.grid": True, "figure.facecolor": "white",
                         "axes.facecolor": "white", "savefig.facecolor": "white", "lines.linewidth": 1.2,
                         "pdf.fonttype": 42, "axes.spines.top": False, "axes.spines.right": False})
    return plt


def _panel_tag(ax, k):
    ax.text(-0.02, 1.02, f"({chr(97 + k)})", transform=ax.transAxes, ha="right", va="bottom", fontsize=8, color=INK)


def make_figures(phen: dict, mech: dict, A: dict) -> None:
    plt = _style()
    files = [f["logical_id"] for f in phen["segments"]]
    Tof = {f["logical_id"]: f["temperature_C"] for f in phen["segments"]}
    cellof = {f["logical_id"]: f["cell"] for f in phen["segments"]}
    # ---------------- fig_relax_fits -----------------------------------------------------------------
    show = [lid for T in (0, 25, 45) for lid in files if Tof[lid] == T and cellof[lid] == "SP20-1"]
    models = ("PL", "EXP", "TPL", "2EXP")
    fig, axs = plt.subplots(3, 3, figsize=(7.0, 6.2))
    for j, lid in enumerate(show):
        p = f"fits__{lid}__"
        tf, yf, ts, ys, tg = A[p + "t_full"], A[p + "V_full_mV"], A[p + "t_sub"], A[p + "V_sub_mV"], A[p + "t_grid"]
        vinf = float(A[p + "TPL_Vinf_mV"])
        ax = axs[0, j]
        ax.plot(tf, yf, color=INK2, lw=2.0, alpha=0.35, label="measured (full resolution)")
        for m in models:
            ax.plot(tg, A[p + f"{m}_grid_mV"], color=SERIES[m], lw=1.2, label=m)
        ax.set_ylabel(r"$V - V(t_\mathrm{end})$ (mV)" if j == 0 else "")
        ax.set_xlabel("time since current interruption (s)")
        ax = axs[1, j]
        ax.loglog(ts, np.abs(ys - vinf), "o", ms=2.5, color=INK2, mfc="white", mew=0.6, label="measured (subsample)")
        for m in models:
            ax.loglog(tg, np.abs(A[p + f"{m}_grid_mV"] - vinf), color=SERIES[m], lw=1.2)
        ax.set_ylabel(r"$|V - \hat V_\infty^{\mathrm{TPL}}|$ (mV)" if j == 0 else "")
        ax = axs[2, j]
        for m in models:
            ax.semilogx(ts, A[p + f"{m}_resid_sub_mV"], "-", color=SERIES[m], lw=0.9)
        ax.axhline(0, color=INK2, lw=0.6)
        ax.set_ylabel("residual (mV)" if j == 0 else "")
        ax.set_xlabel("time since current interruption (s)")
        seg = int(A[p + "seg_index"])
        axs[0, j].text(0.98, 0.04, f"{Tof[lid]} °C, SP20-1, rest {seg + 1}", transform=axs[0, j].transAxes,
                       ha="right", va="bottom", fontsize=7, color=INK2)
    for k, ax in enumerate(axs.ravel()):
        _panel_tag(ax, k)
    h, l_ = axs[0, 0].get_legend_handles_labels()
    h2, l2 = axs[1, 0].get_legend_handles_labels()
    fig.legend(h + h2, l_ + l2, loc="upper center", ncol=6, frameon=False, bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(rect=(0, 0, 1, 0.965))
    fig.savefig(FIG / "draft_relax_fits.pdf")
    plt.close(fig)
    # ---------------- fig_relax_lambda ---------------------------------------------------------------
    fig = plt.figure(figsize=(7.0, 5.0))
    gs = fig.add_gridspec(2, 3)
    thr = float(phen["meta"]["settings"]["lambda_zero_threshold_s_inv"])
    lin = thr
    T_ = A["lam__seg_T"]; prim = A["lam__seg_primary"] == 1
    for j, T in enumerate((0, 25, 45)):
        ax = fig.add_subplot(gs[0, j])
        for br in (0, 1):
            for c in (1, 3):
                m = (T_ == T) & (A["lam__seg_branch"] == br) & (A["lam__seg_cell"] == c) & prim
                if not m.any():
                    continue
                y = A["lam__seg_lam"][m]
                err = np.vstack([y - A["lam__seg_lo"][m], A["lam__seg_hi"][m] - y]).clip(min=0)
                ax.errorbar(A["lam__seg_soc"][m], y, yerr=err, fmt=CELL_MARK[c], ms=4, color=BRANCH[br],
                            mfc=BRANCH[br] if c == 1 else "white", mew=0.8, elinewidth=0.7, capsize=0,
                            label=f"{'discharge' if br == 0 else 'charge'} rests, {'SP20-1' if c == 1 else 'SP20-3'}")
        ax.axhline(1 / 7200.0, color=INK2, lw=0.6)
        ax.text(0.02, 1 / 7200.0 * 1.15, r"$1/t_\mathrm{end}$", fontsize=6.5, color=INK2, transform=ax.get_yaxis_transform())
        ax.set_yscale("symlog", linthresh=lin)
        ax.set_ylim(-0.1 * lin, 0.08)
        ax.set_xlabel("SOC label $x$ (own capacity)")
        ax.set_ylabel(r"TPL $\hat\lambda$ (s$^{-1}$)" if j == 0 else "")
        ax.text(0.98, 0.97, f"{T} °C", transform=ax.transAxes, ha="right", va="top", fontsize=7, color=INK2)
        _panel_tag(ax, j)
        if j == 0:
            fig.legend(*ax.get_legend_handles_labels(), loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.0))
    ax = fig.add_subplot(gs[1, 0:2])
    for vi, var in enumerate(("shared_gain", "free_gain")):
        for c in (1, 3):
            m = A[f"lam__mech_{var}_cell"] == c
            x = A[f"lam__mech_{var}_T"][m] + (-3 if c == 1 else 3) + (-1 if vi == 0 else 1)
            y = A[f"lam__mech_{var}_lam"][m]
            err = np.vstack([y - A[f"lam__mech_{var}_lo"][m], A[f"lam__mech_{var}_hi"][m] - y]).clip(min=0)
            ax.errorbar(x, y, yerr=err, fmt=CELL_MARK[c], ms=5, color=TCOL[0] if vi == 0 else TCOL[25],
                        mfc=(TCOL[0] if vi == 0 else TCOL[25]) if c == 1 else "white", mew=0.8, elinewidth=0.8, capsize=0,
                        label=f"element, {'shared gain' if vi == 0 else 'free gain per rest'}, {'SP20-1' if c == 1 else 'SP20-3'}")
    ax.axhline(1 / 7200.0, color=INK2, lw=0.6)
    ax.set_yscale("symlog", linthresh=lin)
    ax.set_ylim(-0.1 * lin, 0.08)
    ax.set_xticks([0, 25, 45])
    ax.set_xlabel("chamber temperature (°C)")
    ax.set_ylabel(r"element $\hat\lambda$ (s$^{-1}$), cluster bootstrap 95 %")
    ax.legend(loc="upper left", frameon=False, fontsize=6.5)
    _panel_tag(ax, 3)
    ax = fig.add_subplot(gs[1, 2])
    xc = {0: 5 / 6, 1: 0.5, 2: 1 / 6}
    for T in (0, 25, 45):
        for c in (1, 3):
            m = (A["lam__band_shared_gain_T"] == T) & (A["lam__band_shared_gain_cell"] == c)
            if not m.any():
                continue
            x = np.array([xc[int(b)] for b in A["lam__band_shared_gain_band"][m]]) + (T - 25) / 600 + (0.01 if c == 3 else -0.01)
            y = A["lam__band_shared_gain_lam"][m]
            err = np.vstack([y - A["lam__band_shared_gain_lo"][m], A["lam__band_shared_gain_hi"][m] - y]).clip(min=0)
            ax.errorbar(x, y, yerr=err, fmt=CELL_MARK[c], ms=4, color=TCOL[T], mfc=TCOL[T] if c == 1 else "white",
                        mew=0.8, elinewidth=0.7, capsize=0, label=f"{T} °C" if c == 1 else None)
    ax.axhline(1 / 7200.0, color=INK2, lw=0.6)
    ax.set_yscale("symlog", linthresh=lin)
    ax.set_ylim(-0.1 * lin, 0.08)
    ax.set_xticks([1 / 6, 0.5, 5 / 6]); ax.set_xticklabels(["low", "medium", "high"])
    ax.set_xlabel("SOC band (element, shared gain)")
    ax.set_ylabel(r"$\hat\lambda$ (s$^{-1}$), profile 95 %")
    ax.legend(loc="upper left", frameon=False, fontsize=6.5)
    _panel_tag(ax, 4)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig(FIG / "draft_relax_lambda.pdf")
    plt.close(fig)
    # ---------------- fig_relax_acf ------------------------------------------------------------------
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.5), sharey=True)
    for j, T in enumerate((0, 25, 45)):
        ax = axs[j]
        lags = np.arange(len(A[f"acf__T{T}__PL_median"]))
        for m in R.MODELS:
            ax.plot(lags, A[f"acf__T{T}__{m}_median"], color=SERIES[m], lw=1.2, label=m)
        ax.fill_between(lags, A[f"acf__T{T}__TPL_q25"], A[f"acf__T{T}__TPL_q75"], color=SERIES["TPL"], alpha=0.12, lw=0)
        ax.plot(lags, A[f"acf__T{T}__mech_shared_median"], color=INK, lw=1.0, label="element (shared gain)")
        ax.plot(lags, A[f"acf__T{T}__mech_free_median"], color=INK2, lw=1.0, ls=(0, (1, 1)), label="element (free gain)")
        n = int(A[f"acf__T{T}__n_segments"])
        ax.axhline(0, color=INK2, lw=0.6)
        ax.set_xlabel("lag (subsample points)")
        ax.text(0.98, 0.95, f"{T} °C, {n} rests", transform=ax.transAxes, ha="right", va="top", fontsize=7, color=INK2)
        _panel_tag(ax, j)
    axs[0].set_ylabel("residual autocorrelation (median)")
    fig.legend(*axs[0].get_legend_handles_labels(), loc="upper center", ncol=7, frameon=False, bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=(0, 0, 1, 0.9))
    fig.savefig(FIG / "draft_relax_acf.pdf")
    plt.close(fig)


# ======================================================================================================
# Stage 4: LaTeX tables
# ======================================================================================================
def _num(x, nd=2, sci=False):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "--"
    if sci:
        if x == 0:
            return "0"
        e = int(np.floor(np.log10(abs(x))))
        return f"{x / 10 ** e:.{nd}f}\\times10^{{{e}}}"
    return f"{x:.{nd}f}"


def _sig(x, n=3):
    """siunitx number with n significant digits (math minus, scientific form for very small/large values)."""
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "--"
    if x == 0:
        return r"\num{0}"
    e = int(np.floor(np.log10(abs(x))))
    if e < -2 or e > 4:
        return rf"\num{{{x:.{n - 1}e}}}"
    nd = max(n - 1 - e, 0)
    return rf"\num{{{x:.{nd}f}}}"


def _fix(x, nd):
    """siunitx number with nd decimals."""
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "--"
    return rf"\num{{{x:.{nd}f}}}"


def _cellname(lid):
    return ("SP1" if lid.startswith("SP1") else "SP3") + r", \SI{" + lid.rsplit("_", 1)[1][:-1] + r"}{\celsius}"


def make_tables(phen: dict, mech: dict, A: dict) -> None:
    key = str(int(phen["meta"]["settings"]["t0_s"]))
    S = phen["summary"][key]
    M = R.MODELS
    st = phen["meta"]["settings"]
    PJ = "results/relaxation_phenomenological.json"
    MJ = "results/relaxation_mechanistic.json"
    # ---------------- tab_relax_ic ----------------------------------------------------------------------------------
    lines = ["% generated by scripts/03_relaxation.py -- do not edit by hand",
             r"\begin{table*}[t]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{2.5pt}",
             r"\caption{Tail-law comparison on the \SI{2}{\hour} rests after \SI{1}{\ampere} pulses (SP1 and SP3 "
             r"incremental-OCV files; primary rests; window $[\SI{" + key + r"}{\second}, t_{\mathrm{end}}]$; "
             rf"$n_{{\mathrm{{s}}}} = {int(st['n_subsample'])}$ log-spaced points). Win counts by AICc and BIC (Gaussian iid "
             r"likelihood) and median $\Delta\mathrm{BIC}$ of TPL with interquartile range (negative values favour TPL).} "
             f"% src: {PJ}:meta.settings.t0_s, n_subsample",
             r"\label{tab:relax_ic}",
             r"\begin{tabular}{@{}lr" + "r" * 5 + "r" * 5 + "ll@{}}", r"\toprule",
             r" & & \multicolumn{5}{c}{AICc wins} & \multicolumn{5}{c}{BIC wins} & "
             r"\multicolumn{2}{c}{median $\Delta\mathrm{BIC}$ [IQR]} \\",
             r"\cmidrule(lr){3-7}\cmidrule(lr){8-12}\cmidrule(l){13-14}",
             r"Group & $n$ & " + " & ".join(M) + " & " + " & ".join(M)
             + r" & TPL$\,-\,$PL & TPL$\,-\,$2EXP \\", r"\midrule"]
    for g, name in (("T0", r"\SI{0}{\celsius}"), ("T25", r"\SI{25}{\celsius}"), ("T45", r"\SI{45}{\celsius}"),
                    ("branch_discharge", "discharge rests"), ("branch_charge", "charge rests"),
                    ("all_primary", "all")):
        d = S[g]
        a, b = d["delta_bic_TPL_minus_PL"], d["delta_bic_TPL_minus_2EXP"]
        lines.append(f"{name} & {d['n']} & " + " & ".join(str(d["wins_aicc"][m]) for m in M) + " & "
                     + " & ".join(str(d["wins_bic"][m]) for m in M)
                     + f" & {_sig(a['median'])} [{_sig(a['q25'])}, {_sig(a['q75'])}]"
                     + f" & {_sig(b['median'])} [{_sig(b['q25'])}, {_sig(b['q75'])}] \\\\"
                     + f" % src: {PJ}:summary.{key}.{g}.wins_aicc, wins_bic, delta_bic_TPL_minus_PL, delta_bic_TPL_minus_2EXP")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""]
    (TAB / "tab_relax_ic.tex").write_text("\n".join(lines), encoding="utf-8")
    # ---------------- tab_relax_design ------------------------------------------------------------------------------
    DS = phen["summary"]["design_sensitivity"]
    dr = st["decision_rules"]
    rob = ", ".join(str(int(v)) for v in dr["robust_t0_s"])
    D_ = [r"% generated by scripts/03_relaxation.py -- do not edit by hand",
          r"\begin{table}[t]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{3.5pt}",
          r"\caption{Sensitivity of the tail-law ranking to the window start $t_0$ and to the subsample design "
          r"(primary rests; BIC). Declared design: $t_0 = \SI{" + key + r"}{\second}$, "
          + str(int(st["n_subsample"])) + r" log-spaced points. $\Delta\mathrm{BIC}$ scales with the number of points "
          r"$n_{\mathrm{s}}$; the value per point does not. Declared rule for a supported TPL law: a BIC win in at least "
          r"\SI{" + _num(100 * dr["majority_frac"], 0) + r"}{\percent} of the rests in the declared design, and TPL the most "
          r"frequent BIC winner at every $t_0 \in \{" + rob + r"\}\,\si{\second}$ and in every subsample design.} "
          f"% src: {PJ}:meta.settings.t0_s, n_subsample, decision_rules.majority_frac, robust_t0_s",
          r"\label{tab:relax_design}", r"\begin{tabular}{@{}lrlrrrr@{}}", r"\toprule",
          r"Design & $n_{\mathrm{s}}$ & Top law (share) & TPL share & Median $\Delta\mathrm{BIC}_{\mathrm{TPL-PL}}$ "
          r"& Per point & $|\rho_{\mathrm{GN}}(V_\infty,\lambda)| > " + _num(dr["corr_confound"], 1) + r"$ \\",
          r"\midrule"]

    def _row(label, d, src):
        return (rf"{label} & {d['n_sub']['median']:.0f} & {d['top']} (\SI{{{100 * d['frac_top']:.0f}}}{{\percent}}) & "
                rf"\SI{{{100 * d['frac_tpl']:.0f}}}{{\percent}} & {_sig(d['dbic_TPL_minus_PL']['median'])} & "
                rf"{_sig(d['dbic_per_point_TPL_minus_PL']['median'])} & "
                rf"\SI{{{100 * d['frac_abs_corr_vinf_lambda_above']:.0f}}}{{\percent}} \\ % src: {src}")

    for k, d in DS["by_t0"].items():
        D_.append(_row(rf"$t_0 = \SI{{{k}}}{{\second}}$, log{int(st['n_subsample'])}", d,
                       f"{PJ}:summary.design_sensitivity.by_t0.{k}"))
    D_.append(r"\midrule")
    for k, d in DS["by_design_at_main_t0"].items():
        D_.append(_row(rf"$t_0 = \SI{{{key}}}{{\second}}$, {k}", d,
                       f"{PJ}:summary.design_sensitivity.by_design_at_main_t0.{k}"))
    D_ += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    (TAB / "tab_relax_design.tex").write_text("\n".join(D_), encoding="utf-8")
    # ---------------- tab_relax_params ------------------------------------------------------------------------------
    per = mech["summary"]["shared_gain"]["per_file"]
    perf = mech["summary"]["free_gain"]["per_file"]
    nbm = int(st["mechanistic"]["n_boot"])
    lla = st["mechanistic"]["log10_a"][0]
    ids = list(per)
    outside = [lid for lid in ids
               if not (per[lid]["R_dc_boot_ci95"][0] <= per[lid]["R_dc_Ohm"] <= per[lid]["R_dc_boot_ci95"][1])]
    L = ["% generated by scripts/03_relaxation.py -- do not edit by hand",
         r"\begin{table*}[t]", r"\centering", r"\footnotesize", r"\setlength{\tabcolsep}{4pt}",
         r"\caption{Tempered fractional polarisation element fitted per file (shared $\alpha$, $\lambda$, $a_p$, $b_p$; "
         r"one OCV level per rest; primary rests). Estimates with \SI{95}{\percent} cluster-bootstrap intervals over rests "
         rf"({nbm} replicates), printed under the estimates. "
         r"$R_{\mathrm{dc}} = b_p/(a_p+\lambda^\alpha)$ is the direct-current gain of the element; $R_p = b_p/a_p$ is "
         r"reported only when $\log_{10}a_p$ is not on its lower bound (" + _fix(lla, 0) + r"); otherwise the element acts as a "
         r"tempered constant-phase element and $R_p$ is not identified (n.i.). "
         r"$\Delta\mathrm{BIC} < 0$ favours the tempered element over the untempered element ($\lambda = 0$), a single "
         r"relaxation mode ($\alpha = 1$) and two relaxation modes (2RC); positive values favour the reference model. "
         r"Last row: $\hat\lambda$ with a free gain per rest (shape-only variant) and its profile-likelihood "
         r"\SI{95}{\percent} set (boundary-consistent critical value).} "
         f"% src: {MJ}:summary.shared_gain.per_file, free_gain.per_file; {PJ}:meta.settings.mechanistic.n_boot, log10_a",
         r"\label{tab:relax_params}"]

    def _cell(est, lo=None, hi=None):
        if lo is None:
            return est
        return r"\begin{tabular}[t]{@{}c@{}}" + est + r"\\[-1pt]{\scriptsize [" + lo + ", " + hi + r"]}\end{tabular}"

    L += [r"\begin{tabular}{@{}l" + "c" * len(ids) + "@{}}", r"\toprule",
          " & " + " & ".join(_cellname(lid) for lid in ids) + r" \\", r"\midrule"]
    SG = f"{MJ}:summary.shared_gain.per_file.*"
    rows = [
        (r"$\alpha$", lambda p, q, lid: _cell(_fix(p["alpha"], 2) + (r"$^\ddagger$" if p["alpha_at_bound"] else ""),
                                              _fix(p["alpha_boot_ci95"][0], 2), _fix(p["alpha_boot_ci95"][1], 2)),
         f"{SG}.alpha, alpha_boot_ci95, alpha_at_bound"),
        (r"$\lambda$ (\si{\per\second})", lambda p, q, lid: _cell(_sig(p["lambda_s_inv"], 2), _sig(p["lambda_boot_ci95"][0], 2),
                                                                   _sig(p["lambda_boot_ci95"][1], 2)),
         f"{SG}.lambda_s_inv, lambda_boot_ci95"),
        (r"$\log_{10}a_p$", lambda p, q, lid: _cell(_fix(p["log10_a"], 2) + (r"$^\dagger$" if p["log10_a_at_bound"] else "")),
         f"{SG}.log10_a, log10_a_at_bound"),
        (r"$R_{\mathrm{dc}}$ (\si{\ohm})", lambda p, q, lid: _cell(_fix(p["R_dc_Ohm"], 3) + (r"$^\S$" if lid in outside else ""),
                                                                    _fix(p["R_dc_boot_ci95"][0], 3), _fix(p["R_dc_boot_ci95"][1], 3)),
         f"{SG}.R_dc_Ohm, R_dc_boot_ci95"),
        (r"$R_p$ (\si{\ohm})", lambda p, q, lid: _cell(_fix(p["R_p_Ohm"], 3) if p["R_p_identified"] else "n.i."),
         f"{SG}.R_p_Ohm, R_p_identified"),
        (r"RMSE (\si{\milli\volt})", lambda p, q, lid: _cell(_fix(p["rmse_mV"], 2)), f"{SG}.rmse_mV"),
        (r"$\Delta\mathrm{BIC}_{\lambda=0}$", lambda p, q, lid: _cell(_fix(p["dbic_vs_untempered"], 1)),
         f"{SG}.dbic_vs_untempered"),
        (r"$\Delta\mathrm{BIC}_{\alpha=1}$", lambda p, q, lid: _cell(_fix(p["dbic_vs_rc_alpha1"], 1)),
         f"{SG}.dbic_vs_rc_alpha1"),
        (r"$\Delta\mathrm{BIC}_{\mathrm{2RC}}$", lambda p, q, lid: _cell(_fix(p["dbic_vs_2rc"], 1)), f"{SG}.dbic_vs_2rc"),
        (r"$\lambda$, free gain (\si{\per\second})",
         lambda p, q, lid: _cell(_sig(q["lambda_s_inv"], 2), _sig(q["lambda_profile_ci95"][0], 2),
                                 _sig(q["lambda_profile_ci95"][1], 2)),
         f"{MJ}:summary.free_gain.per_file.*.lambda_s_inv, lambda_profile_ci95"),
    ]
    for name, fn, src in rows:
        L.append(name + " & " + " & ".join(fn(per[lid], perf[lid], lid) for lid in ids) + r" \\ % src: " + src)
    note = (r"$^\ddagger$ $\alpha$ on its lower bound " + _fix(st["mechanistic"]["alpha"][0], 2)
            + r"; $^\dagger$ $\log_{10}a_p$ on its lower bound (fit flat in $a_p$ below it).")
    if outside:
        note += (r" $^\S$ The percentile interval does not contain the estimate; percentile intervals need not do so "
                 r"when the bootstrap distribution is skewed, for example by parameter bounds.")
    L += [r"\bottomrule", r"\end{tabular}", r"\par\smallskip{\footnotesize " + note + "}",
          r"\end{table*}", ""]
    (TAB / "tab_relax_params.tex").write_text("\n".join(L), encoding="utf-8")


# ======================================================================================================
# Stage 5: findings report (every number read from the two JSON files)
# ======================================================================================================
def _g(x, nd=3):
    """Compact number formatting for the report."""
    if x is None:
        return "n/a"
    if isinstance(x, (bool, np.bool_)):
        return "yes" if x else "no"
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    x = float(x)
    if not np.isfinite(x):
        return "n/a"
    if x == 0:
        return "0"
    if abs(x) < 1e-2 or abs(x) >= 1e4:
        return f"{x:.{max(nd - 1, 1)}e}"
    return f"{x:.{nd}g}"


def _pct(x):
    return "n/a" if x is None else f"{100 * float(x):.0f} %"


def _iqr(d):
    return f"{_g(d['median'])} [{_g(d['q25'])}, {_g(d['q75'])}]"


def _bib_fields() -> dict:
    """What the bibliography can support: number of entries and of abstract/note fields (review 2)."""
    import re
    bib = ROOT / "References.bib"
    if not bib.exists():      # public repository: the manuscript bibliography is not shipped; keep the saved counts
        rep = ROOT / "reports" / "relaxation_findings.md"
        m = re.search(r"References\.bib: (\d+) entries, (\d+) abstract fields, (\d+) note fields",
                      rep.read_text(encoding="utf-8") if rep.exists() else "")
        n = [int(g) for g in m.groups()] if m else [None] * 3
        return dict(n_entries=n[0], n_abstract=n[1], n_note=n[2])
    txt = bib.read_text(encoding="utf-8", errors="replace")
    return dict(n_entries=len(re.findall(r"^\s*@\w+\s*\{", txt, flags=re.M)),
                n_abstract=len(re.findall(r"\babstract\s*=", txt, flags=re.I)),
                n_note=len(re.findall(r"\bnote\s*=", txt, flags=re.I)))


def _ctx(phen: dict, mech: dict, A: dict) -> dict:
    """Every quantity the report needs, read from the two JSON files (and the plotted arrays)."""
    c = {}
    st = c["st"] = phen["meta"]["settings"]
    c["rules"] = st["decision_rules"]
    c["thr"] = st["lambda_zero_threshold_s_inv"]
    c["t0"] = str(int(st["t0_s"]))
    S = c["S"] = phen["summary"]
    c["P"] = S[c["t0"]]["all_primary"]
    c["F"] = S[c["t0"]]["flagged"]
    c["tests"] = S["tests_main_window"]
    c["DS"] = S["design_sensitivity"]
    c["t0s"] = list(c["DS"]["by_t0"])
    c["n_all"] = sum(f["n_rests"] for f in phen["segments"])
    c["n_prim"] = sum(f["n_primary"] for f in phen["segments"])
    c["MS"], c["MF"] = mech["summary"]["shared_gain"], mech["summary"]["free_gain"]
    c["nf"] = len(c["MS"]["per_file"])
    c["kv"] = mech["kernel_verification"]
    c["syn"] = mech["synthetic_control"]
    c["bib"] = _bib_fields()
    steps = []
    for k, v in A.items():             # voltage resolution from the plotted full-resolution rests
        if k.startswith("fits__") and k.endswith("__V_full_mV"):
            d = np.diff(np.unique(np.round(v, 6)))
            steps.append(float(d[d > 1e-6].min()))
    c["q_mV"] = float(np.median(steps))
    c["pulse_s"] = q3([e["meta"].get("pulse_duration_s") for f in phen["segments"] for e in f["rests"] if e["meta"]["primary"]])
    c["rest_s"] = q3([e["meta"]["rest_duration_s"] for f in phen["segments"] for e in f["rests"] if e["meta"]["primary"]])
    return c


def _top(d: dict) -> str:
    return max(d, key=d.get)


def _syn_rows(syn: dict) -> list[tuple[str, dict, dict]]:
    """(label, settings, result at lambda_true = 0) for the declared and the fitted-parameter controls."""
    out = []
    for blk in [syn] + list(syn.get("fitted", [])):
        r0 = [r for r in blk["results"] if r["lambda_true"] == 0]
        if r0:
            lab = "declared" if blk.get("tag", "declared") == "declared" else f"fitted {blk['file']}"
            out.append((lab, blk, r0[0]))
    return out


def _report_A(c: dict, w) -> None:
    st, rules, t0, S, P, F, tests, DS = c["st"], c["rules"], c["t0"], c["S"], c["P"], c["F"], c["tests"], c["DS"]
    strong, al = rules["strong_delta_bic"], rules["alpha_test"]
    w("## A. Phenomenological tail laws (one fit per rest)\n")
    w(f"Main window (t0 = {t0} s, {P['n']} primary rests). BIC wins: " + ", ".join(f"{m} {P['wins_bic'][m]}" for m in R.MODELS)
      + f" (TPL {_pct(P['frac_wins_bic']['TPL'])}; declared majority rule {_pct(rules['majority_frac'])}); AICc wins: "
      + ", ".join(f"{m} {P['wins_aicc'][m]}" for m in R.MODELS) + ".")
    for o in ("PL", "2EXP", "SEXP", "EXP"):
        d = P[f"delta_bic_TPL_minus_{o}"]
        w(f"* Delta-BIC TPL - {o}: median [IQR] {_iqr(d)}; negative in {_pct(d['frac_negative'])}, below -{_g(strong)} in {_pct(d['frac_below_minus10'])} of rests.")
    w(f"* Delta-BIC TPL - PL per subsample point: median [IQR] {_iqr(P['delta_bic_per_point_TPL_minus_PL'])}. Delta-BIC grows about linearly with "
      "the number of subsample points (design table below), so the Kass-Raftery thresholds are not calibrated for these autocorrelated residuals.")
    w(f"* PL-null calibration (per rest, {st['null_calibration']['n_null']} parametric replicates: PL fit + moving-block resampled full-resolution PL "
      f"residuals, block median {_g(P['null_block_s']['median'])} s): under the null, Delta-BIC TPL - PL < -{_g(strong)} in {_pct(P['null_frac_dbic_below_strong']['mean'])} "
      f"of replicates on average (max {_pct(P['null_frac_dbic_below_strong']['max'])} for one rest). Observed Delta-BIC < -{_g(strong)} in {P['n_dbic_below_strong']} rests, of which "
      f"{P['n_dbic_below_strong_and_calibrated']} also have a calibrated p < {_g(al)}; calibrated p < {_g(al)} in {_pct(P['frac_null_calibrated_p_below_alpha'])} of all primary rests. "
      f"TPL-generated replicates (block bootstrap) give Delta-BIC < -{_g(strong)} in a median {_pct(P['tpl_true_frac_dbic_below_strong']['median'])} of replicates.")
    w("* Median RMSE (mV): " + ", ".join(f"{m} {_g(P['rmse_mV'][m]['median'])}" for m in R.MODELS)
      + "; median max |error| (mV): " + ", ".join(f"{m} {_g(P['max_abs_err_mV'][m]['median'])}" for m in R.MODELS) + ".")
    w("* Residual lag-1 autocorrelation (median): " + ", ".join(f"{m} {_g(P['acf_lag1'][m]['median'], 2)}" for m in R.MODELS)
      + f"; Ljung-Box ({st['ljung_box_lags']} lags) p < {_g(al)} in " + ", ".join(f"{m} {_pct(P['frac_ljung_box_p_below_0p05'][m])}" for m in R.MODELS) + " of rests.")
    w("* Per temperature, BIC wins of TPL / median Delta-BIC TPL-PL / TPL-2EXP: " + "; ".join(
        f"{T} C: {S[t0][f'T{T}']['wins_bic']['TPL']}/{S[t0][f'T{T}']['n']}, {_g(S[t0][f'T{T}']['delta_bic_TPL_minus_PL']['median'])}, "
        f"{_g(S[t0][f'T{T}']['delta_bic_TPL_minus_2EXP']['median'])}" for T in (0, 25, 45))
      + ". Per branch: " + "; ".join(f"{b} {S[t0][f'branch_{b}']['wins_bic']['TPL']}/{S[t0][f'branch_{b}']['n']}, "
                                    f"{_g(S[t0][f'branch_{b}']['delta_bic_TPL_minus_PL']['median'])}" for b in ("discharge", "charge")) + ".")
    w(f"* Nesting (TPL starts from the PL optimum, 2EXP from the EXP optimum): {P['n_nesting_violations']} violations of SSE_TPL <= SSE_PL or "
      f"SSE_2EXP <= SSE_EXP; the PL point was the TPL optimum in {P['n_tpl_nest_fallback']} rests.")
    w(f"* Flagged rests (not in the summaries, {F['n']}): TPL BIC wins {F['wins_bic']['TPL']}, median Delta-BIC TPL-PL {_g(F['delta_bic_TPL_minus_PL']['median'])}.\n")
    w(f"**Window and design sensitivity** (primary rests, BIC; the same winner under all {len(DS['designs_order'])} subsample designs at t0 = {t0} s in "
      f"{_pct(DS['frac_same_winner_all_designs'])} of rests):\n")
    w("| design | median n | top law (share) | TPL share | median dBIC TPL-PL | per point | abs corr(V_inf, lambda) > " + _g(rules["corr_confound"]) + " | median lambda-hat 1/s |")
    w("|---|---|---|---|---|---|---|---|")
    rows = [(f"t0 = {k} s, log{st['n_subsample']}", d) for k, d in DS["by_t0"].items()] + \
           [(f"t0 = {t0} s, {k}", d) for k, d in DS["by_design_at_main_t0"].items() if k != DS["designs_order"][0]]
    for lab, d in rows:
        w(f"| {lab} | {_g(d['n_sub']['median'])} | {d['top']} ({_pct(d['frac_top'])}) | {_pct(d['frac_tpl'])} | {_g(d['dbic_TPL_minus_PL']['median'])} | "
          f"{_g(d['dbic_per_point_TPL_minus_PL']['median'])} | {_pct(d['frac_abs_corr_vinf_lambda_above'])} | {_g(d['tpl_lambda_median'])} |")
    w("")
    lam = P["tpl_lambda_s_inv"]
    w(f"**TPL lambda (an effective curvature of the tail inside the window, see caveats).** Median [IQR] {_g(lam['median'])} [{_g(lam['q25'])}, {_g(lam['q75'])}] 1/s; "
      f"lambda-hat = 0 in {_pct(lam['frac_zero'])}; 1/lambda (non-zero) median [IQR] {_g(P['tpl_inverse_lambda_s']['median'])} [{_g(P['tpl_inverse_lambda_s']['q25'])}, "
      f"{_g(P['tpl_inverse_lambda_s']['q75'])}] s = {_g(P['tpl_inverse_lambda_s']['median'] / 3600)} h.")
    w(f"* lambda = 0 rejected: profile likelihood (dev(0) > {_g(st['profile_crit'])}, equivalent to the chi-bar-square LR test) {_pct(P['frac_profile_ci_excludes_zero'])} "
      f"(pre-review definition, connected component at 3.84: {_pct(P['frac_profile_ci_excludes_zero_cc384'])}; {P['n_profile_multimodal']} rests have a multimodal profile "
      f"whose confidence set is a union of intervals); PL-null calibrated LR {_pct(P['frac_null_calibrated_p_below_alpha'])}; "
      f"block-bootstrap percentile interval ({st['n_boot']} replicates) {_pct(P['frac_bootstrap_ci_excludes_zero'])}.")
    w(f"* Bootstrap blocks are chosen per rest from the ACF of the {_g(st['block_bootstrap']['smooth_s'])} s-smoothed full-resolution TPL residual (first lag below "
      f"{_g(st['block_bootstrap']['acf_threshold'])}, at least {_g(st['block_bootstrap']['min_block_s'])} s, at most {_pct(st['block_bootstrap']['max_block_frac_window'])} of the window): "
      f"decorrelation lag median [IQR] {_iqr(P['tpl_resid_decorrelation_lag_s'])} s, block {_iqr(P['bootstrap_block_s'])} s; residual ACF at 120 s: raw "
      f"{_iqr(P['tpl_resid_acf_at_120s'])}, smoothed {_iqr(P['tpl_resid_smoothed_acf_at_120s'])}.")
    w(f"* lambda-hat * t_end >= 1 in {_pct(P['frac_lambda_t_end_ge_1'])}; bootstrap lower bound * t_end >= 1 in {_pct(P['frac_bootstrap_lower_t_end_ge_1'])}; "
      f"median relative width of the bootstrap interval {_g(P['bootstrap_ci_width_rel']['median'])}.")
    w(f"* Confounding with the OCV level: |corr(V_inf, lambda)| (Gauss-Newton) median {_g(P['abs_corr_vinf_lambda']['median'], 2)}, above "
      f"{_g(rules['corr_confound'])} in {_pct(P['abs_corr_vinf_lambda']['frac_above'])} of rests; |V_inf - V(t_end)| median {_g(P['abs_vinf_minus_last_mV']['TPL']['median'])} mV "
      f"for TPL vs {_g(P['abs_vinf_minus_last_mV']['PL']['median'])} mV for PL (TPL places the asymptote near the last sample, so lambda and the "
      "extrapolated OCV trade off).")
    w("* Median lambda-hat by window start: " + ", ".join(f"t0 = {k} s: {_g(DS['by_t0'][k]['tpl_lambda_median'])}" for k in c["t0s"]) + " 1/s.")
    w(f"* The tail follows a {_g(c['pulse_s']['median'])} s pulse (median) and carries the unfinished relaxations of all earlier pulses; for a power-law "
      "memory the finite pulse alone produces a crossover of the order of the pulse duration inside the window, which TPL can absorb as an apparent "
      "cutoff. lambda-hat is therefore not an impulse-response tempering rate.\n")
    mt, cl = tests["multiplicity"], tests
    w("**Stability (main window).** Rest-level tests (raw p; Holm-adjusted over " + str(len(mt["adjusted"])) + " tests): "
      f"temperature Kruskal-Wallis p = {_g(mt['raw']['T_kruskal'])} ({_g(mt['adjusted']['T_kruskal'])}), medians "
      + ", ".join(f"{k} C {_g(v)}" for k, v in tests["lambda_vs_T_kruskal"]["medians"].items())
      + f" 1/s; SOC Spearman rho = {_g(tests['lambda_vs_soc_spearman']['rho'], 2)}, p = {_g(mt['raw']['SOC_spearman'])} ({_g(mt['adjusted']['SOC_spearman'])}); per T: "
      + ", ".join(f"{T} C rho {_g(tests[f'lambda_vs_soc_spearman_T{T}']['rho'], 2)} (p {_g(tests[f'lambda_vs_soc_spearman_T{T}']['p'])})" for T in (0, 25, 45))
      + f"; cells ({tests['cells_SP1_vs_SP3_lambda']['n_pairs']} matched rests) median ratio {_g(tests['cells_SP1_vs_SP3_lambda']['median_ratio'])}, "
      f"p = {_g(mt['raw']['cells_lambda'])} ({_g(mt['adjusted']['cells_lambda'])}); branches ({tests['branches_discharge_vs_charge_lambda']['n_pairs']} pairs) median ratio "
      f"{_g(tests['branches_discharge_vs_charge_lambda']['median_ratio'])}, p = {_g(mt['raw']['branch_lambda'])} ({_g(mt['adjusted']['branch_lambda'])}). "
      f"File-clustered tests: SOC (mean within-file rho {_g(cl['lambda_vs_soc_file_clustered']['mean_rho'], 2)}, negative in "
      f"{cl['lambda_vs_soc_file_clustered']['n_files_negative']}/{len(cl['lambda_vs_soc_file_clustered']['per_file_rho'])} files) p = {_g(cl['lambda_vs_soc_file_clustered']['p'])}; "
      f"branches (sign-flip over files, {cl['branches_lambda_file_clustered']['n_files_positive']}/{len(cl['branches_lambda_file_clustered']['per_file_median_diff'])} files "
      f"discharge > charge) p = {_g(cl['branches_lambda_file_clustered']['p'])} (smallest attainable {_g(cl['branches_lambda_file_clustered']['min_attainable_p'])}).\n")
    parts = []
    for lab, blk, r0 in _syn_rows(c["syn"]):
        se = blk["settings"]
        parts.append(f"{lab} (alpha {_g(se['alpha'], 2)}, log10 a {_g(se['log10_a'], 3)}, b {_g(se['b_mV_per_A'])} mV A^-1 s^-alpha, "
                     f"{_g(se['noise_mV'])} mV iid noise" + (f", quantised at {_g(blk['quantisation_step_mV'])} mV" if blk.get("quantisation_step_mV") else "")
                     + f"): BIC winner {_top(r0['bic_wins'])} in {r0['bic_wins'][_top(r0['bic_wins'])]}/{r0['n_rests']}, TPL lambda-hat median "
                     f"{_g(r0['tpl_lambda_median'])} 1/s, median Delta-BIC TPL - PL {_g(r0['median_dbic_tpl_pl'])}")
    w("**Synthetic control** (untempered element, lambda = 0, driven by the measured current and fitted exactly like the data): " + "; ".join(parts)
      + f". Measured rests: top law {_top(P['wins_bic'])}, then " + ", ".join(m for m in sorted(P['wins_bic'], key=P['wins_bic'].get, reverse=True)[1:3]) + ".\n")


def _report_B(c: dict, w) -> None:
    st, MS, MF, kv, thr, nf = c["st"], c["MS"], c["MF"], c["kv"], c["thr"], c["nf"]
    w("## B. Mechanistic tempered fractional element (per file, full current history)\n")
    n_generic = sum(1 for x in kv["checks"] if x["alpha"] in (0.05, 0.1))
    w(f"Mode bank: {kv['n_nodes']} trapezoid nodes in u = ln r on [{_g(kv['r_min'])}, {_g(kv['r_max'])}] 1/s (nominal du = {kv['du']}) plus one lumped "
      f"node carrying the spectral mass below r_min at rate lambda; exact zero-order-hold integrator per mode. Kernel vs direct Mittag-Leffler "
      f"(mpmath series, Talbot inversion where the series is impractical) at tau = {', '.join(_g(x) for x in st['mechanistic']['kernel_check_tau_s'])} s, "
      f"{len(kv['checks'])} parameter sets (generic sets plus every per-file, branch, SOC-band and widened-alpha fit; bootstrap replicates not included): "
      f"max relative error {_g(kv['max_rel_err_kernel'])} for tau >= {_g(kv['valid_tau_min_s'])} s (tolerance {_g(kv['tol'])}); below that the bank, which omits rates "
      f"above r_max, is not valid (max error {_g(kv['max_rel_err_kernel_below_valid_tau'])} at tau = {_g(min(st['mechanistic']['kernel_check_tau_s']))} s; all fits use t >= "
      f"{c['t0']} s). L1 norm (bank + analytic tails) vs 1/(a + lambda^alpha): max relative error {_g(kv['max_rel_err_l1_fitted'])} over the fitted sets "
      f"({_g(kv['max_rel_err_l1'])} including the generic alpha <= 0.1 sets, whose mass below e^-100 1/s is not represented); the L1 mass outside the bank "
      f"[r_min, r_max] is up to {_pct(kv['max_frac_l1_outside_bank_fitted'])} for the fitted sets (carried by the lumped low node and by rates above r_max, "
      "which only matter for tau of order 1 s).\n")
    w("| file | alpha [boot 95 %] | lambda 1/s [profile set] [boot 95 %] | log10 a | R_dc Ohm [boot 95 %] | RMSE mV | dBIC vs lambda=0 / alpha=1 / 2RC | best BIC | lambda free gain [profile set] |")
    w("|---|---|---|---|---|---|---|---|---|")
    for lid, p in MS["per_file"].items():
        q = MF["per_file"][lid]
        sets = " U ".join(f"[{_g(a)}, {_g(b)}]" for a, b in p["lambda_profile_intervals"])
        setsf = " U ".join(f"[{_g(a)}, {_g(b)}]" for a, b in q["lambda_profile_intervals"])
        w(f"| {lid} | {_g(p['alpha'])}{' (bound)' if p['alpha_at_bound'] else ''} [{_g(p['alpha_boot_ci95'][0])}, {_g(p['alpha_boot_ci95'][1])}] | {_g(p['lambda_s_inv'])} "
          f"{sets} [{_g(p['lambda_boot_ci95'][0])}, {_g(p['lambda_boot_ci95'][1])}] | {_g(p['log10_a'])}{' (bound)' if p['log10_a_at_bound'] else ''} | "
          f"{_g(p['R_dc_Ohm'])} [{_g(p['R_dc_boot_ci95'][0])}, {_g(p['R_dc_boot_ci95'][1])}] | {_g(p['rmse_mV'])} | "
          f"{_g(p['dbic_vs_untempered'])} / {_g(p['dbic_vs_rc_alpha1'])} / {_g(p['dbic_vs_2rc'])} | {p['best_bic_model']} | {_g(q['lambda_s_inv'])} {setsf} |")
    w("")
    al = c["rules"]["alpha_test"]
    w(f"* Best model by BIC, shared gain: " + ", ".join(f"{k} {v}" for k, v in MS["best_bic_counts"].items())
      + "; free gain per rest (shape-only): " + ", ".join(f"{k} {v}" for k, v in MF["best_bic_counts"].items()) + ".")
    w(f"* lambda = 0 rejected (shared gain): profile {MS['n_files_lambda_profile_excludes_zero']}/{nf}, cluster bootstrap {MS['n_files_lambda_boot_excludes_zero']}/{nf}, "
      f"chi-bar LR p < {_g(al)} {MS['n_files_lr_p_below_alpha']}/{nf} (p: " + ", ".join(f"{_g(p['lr_vs_untempered']['p_chibar'], 2)}" for p in MS["per_file"].values())
      + f"); free gain: profile {MF['n_files_lambda_profile_excludes_zero']}/{nf} (" + ", ".join(k for k, p in MF["per_file"].items() if p["lambda_profile_excludes_zero"])
      + f"), bootstrap {MF['n_files_lambda_boot_excludes_zero']}/{nf}, LR p < {_g(al)} {MF['n_files_lr_p_below_alpha']}/{nf}.")
    w(f"* log10 a on its lower bound {_g(st['mechanistic']['log10_a'][0])} in {MS['n_files_log10_a_at_bound']}/{nf} files (shared gain; "
      + ", ".join(k for k, p in MS["per_file"].items() if p["log10_a_at_bound"]) + "); lowering log10 a by "
      f"{_g(st['mechanistic']['a_flatness_offset'])} changes the SSE by at most {_g(max(abs(p['a_flatness_rel_sse_change']) for p in MS['per_file'].values() if p['log10_a_at_bound']) if MS['n_files_log10_a_at_bound'] else float('nan'))} "
      f"(relative), so there a is not identified and the element is a tempered constant-phase element. Bootstrap replicates with log10 a on the bound: "
      + ", ".join(f"{_pct(p['boot_frac_log10_a_at_bound'])}" for p in MS["per_file"].values()) + ".")
    w("* R_p = b/a is reported only where a is identified: " + "; ".join(f"{k} " + (f"{_g(p['R_p_Ohm'])} Ohm" if p["R_p_identified"] else "not identified")
                                                                    for k, p in MS["per_file"].items())
      + ". Characteristic time a^(-1/alpha): " + ", ".join(f"{'>= ' if p['log10_a_at_bound'] else ''}{_g(p['char_time_s'])}" for p in MS["per_file"].values())
      + " s ('>=': a on its bound), compared with 2 h rests. The DC gain R_dc = b/(a + lambda^alpha) is given in the table.")
    w(f"* alpha on the lower bound {st['mechanistic']['alpha'][0]} in {MS['n_files_alpha_at_bound']}/{nf} files (shared) and {MF['n_files_alpha_at_bound']}/{nf} (free). "
      f"Refit with alpha in {st['mechanistic']['alpha_sensitivity']} (still bounded in a): alpha-hat "
      + ", ".join(f"{_g(p['alpha_sensitivity']['alpha'], 2)}" for p in MS["per_file"].values())
      + "; Delta-BIC vs the bounded fit " + ", ".join(f"{_g(p['alpha_sensitivity']['dbic_vs_bounded'])}" for p in MS["per_file"].values())
      + f"; log10 a on its bound in {MS['n_files_sensitivity_log10_a_at_bound']}/{nf}; lambda-hat " + ", ".join(f"{_g(p['alpha_sensitivity']['lambda_s_inv'])}" for p in MS["per_file"].values())
      + f" 1/s with profile set excluding 0 in {MS['n_files_sensitivity_lambda_profile_excludes_zero']}/{nf} (LR p " + ", ".join(f"{_g(p['alpha_sensitivity']['lr_p_chibar'], 2)}" for p in MS["per_file"].values())
      + f"); 2RC still preferred in {MS['n_files_sensitivity_2rc_preferred']}/{nf}.")
    rm = [p["rmse_mV"] for p in MS["per_file"].values()]
    ptpl = c["P"]["rmse_mV"]["TPL"]["median"]
    w(f"* Misspecification: shared-gain RMSE {_g(min(rm))}-{_g(max(rm))} mV = {_g(min(rm) / ptpl, 2)}-{_g(max(rm) / ptpl, 2)} x the median per-rest TPL RMSE "
      f"({_g(ptpl)} mV); element residual lag-1 autocorrelation (median over rests) " + ", ".join(f"{_g(p['residual_acf_median_lag1'], 2)}" for p in MS["per_file"].values())
      + ". The element BIC/LR comparisons are therefore dominated by misspecification and have little power for lambda.")
    cc = [abs(p["jacobian"]["corr_core"][i][j]) for p in MS["per_file"].values() for i in range(4) for j in range(i + 1, 4)]
    cn = [v for p in MS["per_file"].values() for v in p["jacobian"]["max_abs_corr_with_ocv_nuisance"].values()]
    w(f"* Jacobian correlations among (alpha, lambda, R_p, C_p): |r| median {_g(float(np.median(cc)), 2)}, max {_g(max(cc), 3)}; max |r| with an OCV "
      f"nuisance level: median {_g(float(np.median(cn)), 2)}, max {_g(max(cn), 3)}.")
    bands = [(k, b) for p in MS["per_file"].values() for k, b in p["bands"].items() if k.startswith("soc_")]
    bex = [(k, b) for k, b in bands if b["ci"][0] >= thr]
    w(f"* SOC bands (shared gain): the lambda profile set excludes 0 in {len(bex)}/{len(bands)} band fits"
      + (" (" + ", ".join(f"{k.replace('soc_', '')} {_g(b['lambda_s_inv'])}" for k, b in bex) + " 1/s)" if bex else "")
      + f"; largest band lambda-hat {_g(max(b['lambda_s_inv'] for _, b in bands))} 1/s. Branches: profile sets of discharge- and charge-branch fits overlap in "
      f"{sum(v['intervals_overlap'] for v in MS['branches'].values())}/{len(MS['branches'])} files (shared gain) and "
      f"{sum(v['intervals_overlap'] for v in MF['branches'].values())}/{len(MF['branches'])} (free gain). lambda-hat is refined by a bounded 1-D search between grid nodes in "
      f"{sum(bool(p['lambda_refined']) for p in MS['per_file'].values())}/{nf} files (the others have lambda-hat at a node, 0 included).")
    w("* Cells, bootstrap 95 % interval of lambda(SP20-1) - lambda(SP20-3) (shared gain): " + "; ".join(
        f"{T} C [{_g(v['diff_lambda_ci95'][0])}, {_g(v['diff_lambda_ci95'][1])}]" for T, v in MS["cells_SP1_vs_SP3"].items()) + ".")
    arr = MS["arrhenius_lambda"]
    w("* Arrhenius ln(lambda) vs 1/T (shared gain): " + "; ".join(
        f"{k}: " + ((f"Ea = {_g(d['Ea_kJ_mol'])} kJ/mol, " + (f"bootstrap 95 % [{_g(d['Ea_boot_ci95_kJ_mol'][0])}, {_g(d['Ea_boot_ci95_kJ_mol'][1])}]"
                     if d.get("Ea_boot_ci95_kJ_mol") else "no bootstrap interval (too few replicates with all lambda* > 0)")
                     + f" (all lambda* > 0 in {_pct(d['frac_boot_all_lambda_positive'])} of replicates)")
                    if "Ea_kJ_mol" in d else f"not fitted ({d.get('n_lambda_zero', 0)} of {d['n_points']} lambda-hat below threshold)") for k, d in arr.items()) + ".\n")


def _verdicts(c: dict) -> dict:
    """Verdict labels and their inputs, computed from the results with the declared decision rules."""
    st, rules, P, DS, tests, MS, MF, nf = c["st"], c["rules"], c["P"], c["DS"], c["tests"], c["MS"], c["MF"], c["nf"]
    al, maj = rules["alpha_test"], rules["majority_frac"]
    v = {}
    rob = [str(int(x)) for x in rules["robust_t0_s"]]
    top_main = _top(P["wins_bic"])
    tops_t0 = {k: DS["by_t0"][k]["top"] for k in rob if k in DS["by_t0"]}
    tops_des = {k: d["top"] for k, d in DS["by_design_at_main_t0"].items()}
    v["q1_inputs"] = dict(top_main=top_main, frac_tpl=P["frac_wins_bic"]["TPL"], tops_t0=tops_t0, tops_des=tops_des)
    if top_main == "TPL" and P["frac_wins_bic"]["TPL"] >= maj and all(x == "TPL" for x in tops_t0.values()) and all(x == "TPL" for x in tops_des.values()):
        v["q1"] = "SUPPORTED"
    elif top_main == "TPL":
        v["q1"] = "INCONCLUSIVE / window- and design-dependent"
    else:
        v["q1"] = "NOT SUPPORTED"
    calib, low, conf = P["frac_null_calibrated_p_below_alpha"], P["frac_bootstrap_lower_t_end_ge_1"], P["abs_corr_vinf_lambda"]["frac_above"]
    v["q2"] = ("YES" if (calib >= maj and low >= maj and conf < maj) else
               "ONLY AS AN APPARENT, WINDOW-DEPENDENT CUTOFF" if calib >= maj else "NO")
    adj, cl = tests["multiplicity"]["adjusted"], tests["clustered_multiplicity"]["adjusted"]
    raw = tests["multiplicity"]["raw"]
    robust = any(adj.get(k, 1) < al and cl.get(j, 1) < al for k, j in (("SOC_spearman", "SOC"), ("branch_lambda", "branch")))
    nominal = any((raw.get(k) or 1) < al for k in ("SOC_spearman", "branch_lambda", "T_kruskal", "cells_lambda"))
    v["q3"] = "NO (lambda varies)" if robust else ("NOT ESTABLISHED" if nominal else "NO INSTABILITY DETECTED (stability not demonstrated)")
    ratios = [p["rmse_mV"] / P["rmse_mV"]["TPL"]["median"] for p in MS["per_file"].values()]
    v["mech_ratio"] = (min(ratios), max(ratios))
    misspec = min(ratios) > rules["mech_misspec_rmse_ratio"]
    if MS["best_bic_counts"]["TFO"] >= rules["mech_support_min_files"]:
        v["q4"] = "SUPPORTED"
    elif misspec:
        v["q4"] = "INCONCLUSIVE (the shared linear element is misspecified)"
    else:
        v["q4"] = "NOT SUPPORTED"
    syn0 = [r0["tpl_lambda_median"] for _, _, r0 in _syn_rows(c["syn"])]
    elem_zero = nf - MS["n_files_lambda_boot_excludes_zero"]
    v["q5"] = ("NOT SUPPORTED / NOT IDENTIFIABLE" if (elem_zero >= maj * nf or MS["n_files_log10_a_at_bound"] > 0) and any(x >= c["thr"] for x in syn0)
               else "UNDETERMINED")
    return v


def _report_verdicts(c: dict, v: dict, w) -> None:
    st, rules, P, DS, tests, MS, MF, nf, t0 = c["st"], c["rules"], c["P"], c["DS"], c["tests"], c["MS"], c["MF"], c["nf"], c["t0"]
    al = rules["alpha_test"]
    w("## Verdicts\n")
    qi = v["q1_inputs"]
    des = DS["by_design_at_main_t0"]
    syn = _syn_rows(c["syn"])
    w(f"1. **Tempered power law vs references (phenomenological): {v['q1']}.** TPL is the most frequent BIC winner at t0 = {t0} s but wins "
      f"{P['wins_bic']['TPL']}/{P['n']} rests ({_pct(qi['frac_tpl'])}; declared rule: at least {_pct(rules['majority_frac'])}, and top winner at t0 in "
      f"{{{', '.join(str(int(x)) for x in rules['robust_t0_s'])}}} s and in every subsample design). Top law by t0: "
      + ", ".join(f"{k} s {d['top']} ({_pct(d['frac_top'])})" for k, d in DS["by_t0"].items())
      + f"; TPL share across the {len(des)} designs at t0 = {t0} s: {_pct(min(d['frac_tpl'] for d in des.values()))}-{_pct(max(d['frac_tpl'] for d in des.values()))}. "
      "A TPL advantage over PL is not evidence of tempering: rests generated by the UNtempered element give median Delta-BIC TPL - PL of "
      + ", ".join(f"{_g(r0['median_dbic_tpl_pl'])} ({lab})" for lab, _, r0 in syn) + ".")
    w(f"2. **Is the phenomenological lambda identifiable inside 2 h? {v['q2']}.** An apparent cutoff (lambda > 0) passes the PL-null calibrated LR test "
      f"(p < {_g(al)}) in {_pct(P['frac_null_calibrated_p_below_alpha'])} of rests (profile set excludes 0: {_pct(P['frac_profile_ci_excludes_zero'])}; "
      f"ACF-block bootstrap: {_pct(P['frac_bootstrap_ci_excludes_zero'])}), but the cutoff lies confidently inside the window (bootstrap lower bound * t_end >= 1) in "
      f"{_pct(P['frac_bootstrap_lower_t_end_ge_1'])}, |corr(V_inf, lambda)| > {_g(rules['corr_confound'])} in {_pct(P['abs_corr_vinf_lambda']['frac_above'])}, and median "
      f"lambda-hat moves from {_g(DS['by_t0'][c['t0s'][0]]['tpl_lambda_median'])} (t0 = {c['t0s'][0]} s) to {_g(DS['by_t0'][c['t0s'][-1]]['tpl_lambda_median'])} 1/s "
      f"(t0 = {c['t0s'][-1]} s). lambda is an effective tail curvature inside the window, shaped by the {_g(c['pulse_s']['median'])} s pulse history, not a material rate.")
    adj, raw, cl = tests["multiplicity"]["adjusted"], tests["multiplicity"]["raw"], tests
    w(f"3. **Is lambda stable across SOC, branch, temperature and cells? {v['q3']}.** Holm-adjusted rest-level p: SOC {_g(adj['SOC_spearman'])}, branch "
      f"{_g(adj['branch_lambda'])}, temperature {_g(adj['T_kruskal'])}, cells {_g(adj['cells_lambda'])} (raw {_g(raw['SOC_spearman'])}, {_g(raw['branch_lambda'])}, "
      f"{_g(raw['T_kruskal'])}, {_g(raw['cells_lambda'])}); file-clustered p: SOC {_g(cl['lambda_vs_soc_file_clustered']['p'])}, branch "
      f"{_g(cl['branches_lambda_file_clustered']['p'])}. The tests are run on a parameter confounded with V_inf and dependent on t0, so neither stability nor "
      "instability of a material property is shown.")
    lo, hi = v["mech_ratio"]
    w(f"4. **Mechanistic tempered element: {v['q4']}.** BIC prefers 2RC in {MS['best_bic_counts']['2RC']}/{nf} files (shared gain) and "
      f"{MF['best_bic_counts']['2RC']}/{nf} (free gain), also after widening alpha ({MS['n_files_sensitivity_2rc_preferred']}/{nf}); the shared-gain RMSE is "
      f"{_g(lo, 2)}-{_g(hi, 2)} x the per-rest TPL RMSE. lambda = 0 is rejected by the cluster bootstrap in {MS['n_files_lambda_boot_excludes_zero']}/{nf} (shared) and "
      f"{MF['n_files_lambda_boot_excludes_zero']}/{nf} (free) files, by the chi-bar LR at p < {_g(al)} in {MS['n_files_lr_p_below_alpha']}/{nf} (shared) and "
      f"{MF['n_files_lr_p_below_alpha']}/{nf} (free), and by the profile in {MS['n_files_lambda_profile_excludes_zero']}/{nf} (shared) and "
      f"{MF['n_files_lambda_profile_excludes_zero']}/{nf} (free); alpha is on its lower bound in {MS['n_files_alpha_at_bound']}/{nf} and log10 a in "
      f"{MS['n_files_log10_a_at_bound']}/{nf} files (R_p not identified there).")
    ar = MS["arrhenius_lambda"]
    arr_ok = [k for k, d in ar.items() if "Ea_kJ_mol" in d and d.get("Ea_boot_ci95_kJ_mol") and (d["Ea_boot_ci95_kJ_mol"][0] > 0 or d["Ea_boot_ci95_kJ_mol"][1] < 0)]
    c["arr_txt"] = (("an Arrhenius slope excluding 0 is obtained for " + ", ".join(arr_ok)) if arr_ok else
                    "no Arrhenius fit excludes a zero activation energy (lambda-hat at 0 for some temperatures, or bootstrap interval spanning 0)")
    b = c["bib"]
    w(f"5. **lambda as an inverse diffusion time: {v['q5']}.** Element lambda-hat <= {_g(max(p['lambda_s_inv'] for p in MS['per_file'].values()))} 1/s "
      f"(shared gain), cluster-bootstrap interval reaching 0 in {nf - MS['n_files_lambda_boot_excludes_zero']}/{nf} files; the untempered element gives TPL "
      "lambda-hat of " + ", ".join(f"{_g(r0['tpl_lambda_median'])} ({lab})" for lab, _, r0 in syn)
      + f" 1/s against a data median of {_g(P['tpl_lambda_s_inv']['median'])} 1/s, so the phenomenological cutoff cannot be read as 1/(diffusion time). "
      f"Temperature: {c['arr_txt']}. No literature comparison was made: References.bib ({b['n_entries']} entries) holds {b['n_abstract']} abstract and {b['n_note']} note "
      "fields, i.e. metadata only.\n")


def _report_negative(c: dict, v: dict, w) -> None:
    st, rules, P, DS, MS, MF, nf = c["st"], c["rules"], c["P"], c["DS"], c["MS"], c["MF"], c["nf"]
    w("## Negative or inconclusive results\n")
    t0s = c["t0s"]
    acfT = {T: c["S"][c["t0"]][f"T{T}"]["acf_lag1"]["TPL"]["median"] for T in (0, 25, 45)}
    Tmax = max(acfT, key=acfT.get)
    neg = [f"The TPL advantage is window- and design-dependent: TPL wins {DS['by_t0'][t0s[-1]]['wins_bic']['TPL']}/{P['n']} rests at t0 = {t0s[-1]} s, the top law "
           "changes with t0 (" + ", ".join(f"{k} s: {d['top']}" for k, d in DS["by_t0"].items()) + f"), and only {_pct(DS['frac_same_winner_all_designs'])} of rests keep "
           "their BIC winner across the subsample designs.",
           f"Delta-BIC magnitudes scale with the subsample size; under a PL null with realistic residual blocks, 'very strong' TPL wins occur in "
           f"{_pct(P['null_frac_dbic_below_strong']['mean'])} of replicates on average.",
           f"TPL residuals are still autocorrelated (Ljung-Box p < {_g(rules['alpha_test'])} in {_pct(P['frac_ljung_box_p_below_0p05']['TPL'])} of rests; lag-1 median "
           f"{_g(P['acf_lag1']['TPL']['median'], 2)}; largest at {Tmax} C, median {_g(acfT[Tmax], 2)}).",
           f"lambda is confounded with the extrapolated OCV level (|corr| > {_g(rules['corr_confound'])} in {_pct(P['abs_corr_vinf_lambda']['frac_above'])} of rests) and the "
           f"cutoff is inside the window with confidence in only {_pct(P['frac_bootstrap_lower_t_end_ge_1'])} of rests.",
           f"Stability of lambda across SOC, branch, temperature and cells: {v['q3']} (verdict 3).",
           "Synthetic control: rests generated by the untempered element are won by " + ", ".join(
               f"{_top(r0['bic_wins'])} ({lab})" for lab, _, r0 in _syn_rows(c["syn"])) + f", while the measured rests are won by {_top(P['wins_bic'])} "
           "most often: the element does not reproduce the SHAPE of the measured tails, and a TPL win is not evidence of a tempered element.",
           f"Mechanistic element: {v['q4']}; 2RC is preferred in {MS['best_bic_counts']['2RC']}/{nf} files.",
           f"alpha is at the lower bound {st['mechanistic']['alpha'][0]} in {MS['n_files_alpha_at_bound']}/{nf} files; with the wider alpha range log10 a sits on its "
           f"bound in {MS['n_files_sensitivity_log10_a_at_bound']}/{nf} files, so the sensitivity fit is still bound-constrained.",
           f"R_p is not identified in {nf - sum(p['R_p_identified'] for p in MS['per_file'].values())}/{nf} files (a on its bound); (alpha, lambda, R_p, C_p) are "
           "coupled with each other and with the OCV nuisance levels.",
           f"Temperature dependence of lambda: {c['arr_txt']}.",
           f"No temperature channel: temperatures are chamber set points; the {_g(c['q_mV'])} mV voltage step limits the late-time tail where the relaxation is smallest."]
    for x in neg:
        w(f"* {x}")


def _report_review(c: dict, v: dict, w) -> None:
    st, rules, P, DS, tests, MS, MF, kv, nf, t0 = (c["st"], c["rules"], c["P"], c["DS"], c["tests"], c["MS"], c["MF"], c["kv"],
                                                    c["nf"], c["t0"])
    des = DS["by_design_at_main_t0"]
    syn = _syn_rows(c["syn"])
    adj = tests["multiplicity"]["adjusted"]
    w("\n## Review response (round 1)\n")
    w("Two reviews (R1: statistics; R2: reproducibility and physics). Every issue was checked against the re-run; numbers below are read from the "
      "regenerated JSON files.\n")
    items = [
        ("R1.1 / R2.3 (major) verdict 1 rests on a plurality below majority_frac and flips with t0", "Accepted",
         f"TPL wins {P['wins_bic']['TPL']}/{P['n']} ({_pct(P['frac_wins_bic']['TPL'])}) at t0 = {t0} s; top law by t0: "
         + ", ".join(f"{k} s {d['top']}" for k, d in DS["by_t0"].items()) + ".",
         f"majority_frac is applied; t0 = 30 and 120 s added (config t0_sensitivity_s) and a declared robustness rule (decision_rules.robust_t0_s, "
         f"design_sensitivity); verdict 1 is now '{v['q1']}' and states the synthetic-control result in the verdict line."),
        ("R1.2 (major) Delta-BIC scales with the subsample size; Kass-Raftery threshold uncalibrated", "Accepted",
         "median Delta-BIC TPL - PL by design: " + ", ".join(f"{k} {_g(d['dbic_TPL_minus_PL']['median'])}" for k, d in des.items())
         + f"; per point: " + ", ".join(f"{_g(d['dbic_per_point_TPL_minus_PL']['median'])}" for d in des.values())
         + f". PL-null false 'very strong' rate {_pct(P['null_frac_dbic_below_strong']['mean'])} (max {_pct(P['null_frac_dbic_below_strong']['max'])}).",
         f"per-rest PL-null parametric block bootstrap ({st['null_calibration']['n_null']} replicates, ACF-chosen blocks) with calibrated p; win fractions for "
         "4 extra designs; Delta-BIC per point reported; new table tab_relax_design.tex."),
        ("R1.3 / R2.4 (major/minor) profile interval = connected component; 3.84 vs chi-bar cutoff", "Accepted",
         f"lambda = 0 excluded: {_pct(P['frac_profile_ci_excludes_zero'])} with dev(0) > {_g(st['profile_crit'])} vs {_pct(P['frac_profile_ci_excludes_zero_cc384'])} with the old "
         f"definition; {P['n_profile_multimodal']} rests have a multimodal confidence set; chi-bar LR p < {_g(rules['alpha_test'])}: {_pct(P['frac_lr_tpl_vs_pl_p_below_0p05'])}.",
         "profile_interval returns the confidence SET (union of intervals) at the boundary-consistent critical value (config profile_crit), and "
         "'excludes 0' = dev(0) > crit, identical to the chi-bar LR decision; same for the mechanistic profiles."),
        ("R1.4 (major) 120 s bootstrap blocks too short; percentile interval blind to the lambda = 0 mode", "Accepted",
         f"TPL residual decorrelation lag median {_g(P['tpl_resid_decorrelation_lag_s']['median'])} s; smoothed ACF at 120 s median "
         f"{_g(P['tpl_resid_smoothed_acf_at_120s']['median'], 2)}; bootstrap with ACF blocks (median {_g(P['bootstrap_block_s']['median'])} s) excludes 0 in "
         f"{_pct(P['frac_bootstrap_ci_excludes_zero'])}; PL-null calibrated LR in {_pct(P['frac_null_calibrated_p_below_alpha'])}.",
         "block length chosen per rest from the ACF (config relaxation_study.block_bootstrap; relaxation.bootstrap.block_len_s kept but superseded); "
         "the lambda > 0 question is answered by the null-constrained (PL) bootstrap of the LR statistic."),
        ("R1.5 (major) V_inf and lambda confounded", "Accepted (joint profile not added)",
         f"|corr(V_inf, lambda)| > {_g(rules['corr_confound'])} in {_pct(P['abs_corr_vinf_lambda']['frac_above'])} (designs: "
         + ", ".join(f"{_pct(d['frac_abs_corr_vinf_lambda_above'])}" for d in des.values())
         + f"); |V_inf - V(t_end)| TPL {_g(P['abs_vinf_minus_last_mV']['TPL']['median'])} mV vs PL {_g(P['abs_vinf_minus_last_mV']['PL']['median'])} mV.",
         "correlation and offsets reported; lambda described as an effective tail curvature inside the window; stability tests re-run with "
         "file clustering and Holm correction and verdict 3 states the confounding."),
        ("R1.6 / R2.1 (major) log10 a on its bound; R_p = b/a is a bound artefact; DC gain is b/(a + lambda^alpha)", "Accepted",
         f"log10 a on the bound in {MS['n_files_log10_a_at_bound']}/{nf} files; SSE change when a is lowered 1000x: "
         + ", ".join(f"{_g(p['a_flatness_rel_sse_change'])}" for p in MS["per_file"].values()) + "; bootstrap replicates on the bound: "
         + ", ".join(f"{_pct(p['boot_frac_log10_a_at_bound'])}" for p in MS["per_file"].values()) + ".",
         "R_dc reported with bootstrap interval; R_p printed only when a is identified ('n.i.' otherwise); bound flags in the table and the report; "
         "the fit is shown to be flat in a below the bound (tempered-CPE limit), so widening the bound would not change the fit."),
        ("R1.7 / R2.4 (major/minor) verdict 4 cites the bootstrap selectively; no power under misspecification", "Accepted",
         f"files (of {nf}) rejecting lambda = 0, shared / free gain: LR p < {_g(rules['alpha_test'])} {MS['n_files_lr_p_below_alpha']} / {MF['n_files_lr_p_below_alpha']}, profile "
         f"{MS['n_files_lambda_profile_excludes_zero']} / {MF['n_files_lambda_profile_excludes_zero']}, cluster bootstrap {MS['n_files_lambda_boot_excludes_zero']} / "
         f"{MF['n_files_lambda_boot_excludes_zero']}; RMSE ratio {_g(v['mech_ratio'][0], 2)}-{_g(v['mech_ratio'][1], 2)}.",
         f"verdict 4 reports all three tests for both variants and is labelled '{v['q4']}' by a declared rule (decision_rules.mech_misspec_rmse_ratio)."),
        ("R1.8a (minor) nesting violation SSE_TPL > SSE_PL", "Accepted",
         f"after the fix: {P['n_nesting_violations']} violations; PL point is the TPL optimum in {P['n_tpl_nest_fallback']} rests.",
         "fit_all starts TPL from (beta_PL, 0) and 2EXP from (tau_EXP, upper bound) and falls back to the nested point."),
        ("R1.8b / R2.7 (minor) synthetic control: iid noise, alpha = 0.5, no PL/TPL controls", "Accepted (TPL-vs-PL only)",
         "fitted-parameter controls: " + "; ".join(f"{lab}: winner {_top(r0['bic_wins'])} {r0['bic_wins'][_top(r0['bic_wins'])]}/{r0['n_rests']}, TPL lambda-hat "
                                                   f"{_g(r0['tpl_lambda_median'])}" for lab, _, r0 in syn)
         + f"; TPL-true replicates give Delta-BIC < -{_g(rules['strong_delta_bic'])} in a median {_pct(P['tpl_true_frac_dbic_below_strong']['median'])}.",
         "element control repeated at the fitted shared-gain parameters with ADC quantisation (config fitted_parameter_files); per-rest PL-null and "
         "TPL-true block bootstraps give false and true TPL-over-PL rates; a 5-law ranking of bootstrap replicates was not run (cost)."),
        ("R1.8c (minor) stability tests ignore clustering and multiplicity", "Accepted",
         f"Holm-adjusted p: SOC {_g(adj['SOC_spearman'])}, branch {_g(adj['branch_lambda'])}; file-clustered p: SOC "
         f"{_g(tests['lambda_vs_soc_file_clustered']['p'])}, branch {_g(tests['branches_lambda_file_clustered']['p'])}.",
         f"Holm correction over {len(adj)} tests and within-file permutation / file sign-flip tests; verdict 3 is now '{v['q3']}'."),
        ("R2.2 (major) widened-alpha refit still bound in a; its lambda not reported", "Accepted",
         f"widened fit: log10 a on the bound in {MS['n_files_sensitivity_log10_a_at_bound']}/{nf}; lambda-hat "
         + ", ".join(f"{_g(p['alpha_sensitivity']['lambda_s_inv'])}" for p in MS["per_file"].values())
         + f" 1/s; profile set excludes 0 in {MS['n_files_sensitivity_lambda_profile_excludes_zero']}/{nf}.",
         "lambda-hat, profile set, LR p and bound flags of the widened fit are reported; the report states that it is still bounded in a."),
        ("R2.5 (minor) hand-typed constants and unconditional conclusions", "Accepted",
         f"worker count {c['n_workers']}, bootstrap sizes, block settings, Ljung-Box lags and kernel taus are now read from the JSON meta/settings.",
         "all verdict labels and negative-result sentences are computed from the results with declared rules (new decision_rules keys)."),
        ("R2.6 (minor) literature check could not find anything", "Accepted",
         f"References.bib: {c['bib']['n_entries']} entries, {c['bib']['n_abstract']} abstract fields, {c['bib']['n_note']} note fields.",
         "the sentence now says that no literature comparison was made."),
        ("R2.8 (minor) finite-pulse / history superposition not discussed", "Accepted (text; no pulse-convolved TPL fit)",
         f"median pulse duration {_g(c['pulse_s']['median'])} s; median 1/lambda {_g(P['tpl_inverse_lambda_s']['median'])} s.",
         "caveat added to section A and verdict 2; 'apparent cutoff' wording."),
        ("R2.9 (minor) mechanistic lambda-hat on a grid node", "Accepted",
         f"refined by a bounded 1-D search in {sum(bool(p['lambda_refined']) for p in MS['per_file'].values())}/{nf} files (shared gain); the others are at the "
         "lambda = 0 node or no interior improvement was found.",
         "MechFile._refine_lambda replaces the parabola step (config mechanistic.lambda_refine_xatol)."),
        ("R2.10 (minor) documentation: node count, L1 mass outside bank, tau validity, parameter-set coverage, alpha split", "Accepted",
         f"{kv['n_nodes']} nodes; max L1 mass outside the bank (fitted sets) {_pct(kv['max_frac_l1_outside_bank_fitted'])}; kernel error {_g(kv['max_rel_err_kernel'])} for tau >= "
         f"{_g(kv['valid_tau_min_s'])} s and {_g(kv['max_rel_err_kernel_below_valid_tau'])} below; {len(kv['checks'])} parameter sets.",
         "config comment fixed; tau = 1 s added to the check and the valid range stated; branch and SOC-band fits included; the alpha >= 0.19 split removed."),
        ("R2.11 (minor) caption and units", "Accepted (key kept)",
         "the alpha = 1 reference is a single relaxation mode; b is in mV A^-1 s^-alpha.",
         "caption fixed; 'b_units' field added next to b_mV_per_A (key kept for compatibility); free-gain profile set added to the table."),
    ]
    for i, (iss, dec, ev, ch) in enumerate(items, 1):
        w(f"{i}. **{iss}.** {dec}. Evidence: {ev} Change: {ch}")
    w("\nNo issue was rejected. Not done: a joint (V_inf, lambda) profile (the Gauss-Newton correlation is reported instead) and a TPL fit on the "
      "pulse-convolved form.")


def write_report(phen: dict, mech: dict, A: dict) -> None:
    c = _ctx(phen, mech, A)
    c["n_workers"] = phen["meta"].get("n_workers")
    st, thr, t0 = c["st"], c["thr"], c["t0"]
    L = []
    w = L.append
    w("# Relaxation-tail study: is the post-interruption voltage relaxation a tempered power-law memory?\n")
    w(f"Generated by `scripts/03_relaxation.py` from `results/relaxation_phenomenological.json` and "
      f"`results/relaxation_mechanistic.json` ({phen['meta']['generated_utc']}); all numbers below are read from those files. "
      f"Fitting wall time {_g(phen['meta']['wall_time_s'] / 60, 3)} min ({len(phen['segments'])} files in parallel, {c['n_workers']} worker processes). "
      "Revised after review round 1 (response at the end).\n")
    w("## Data, rules and caveats\n")
    w(f"* Rests: {c['n_all']} two-hour rests after 1 A pulses in the six SP20-1/SP20-3 incremental-OCV files (`data.get_relaxations`; "
      f"post-CV rests are never returned). Exclusion rule (config `relaxation_study.exclusion_rule`): the rest after the last discharge "
      f"pulse of each file and rests after pulses with < {_g(100 * st['short_pulse_frac'])} % of the file's median pulse charge "
      f"(voltage-limited pulses) are flagged ({c['n_all'] - c['n_prim']} rests) and excluded from all summaries and from the mechanistic fits; "
      f"{c['n_prim']} primary rests remain. All files passed `data.verify_file`.")
    w(f"* Declared window [t0, t_end] with t0 = {t0} s and t_end = end of rest; fits on {st['n_subsample']} log-spaced samples (nearest measured points). "
      f"Sensitivity: t0 = {', '.join(str(x) for x in st['t0_sensitivity_s'])} s and subsample designs {', '.join(st['design_sensitivity'])}.")
    w(f"* Likelihood: Gaussian iid on the subsample. Residuals remain autocorrelated and the voltage is quantised (smallest step {_g(c['q_mV'])} mV), so "
      "AICc/BIC rank models but their magnitudes and nominal p-values are optimistic; the TPL-vs-PL evidence is calibrated per rest by a PL-null "
      "parametric block bootstrap, and intervals use moving blocks chosen from the residual ACF (phenomenological) or the cluster bootstrap over "
      f"rests (mechanistic). The lambda = 0 null lies on the boundary: LR p-values use the 50:50 chi-bar-square mixture and profile confidence sets "
      f"the matching critical value {_g(st['profile_crit'])}.")
    w(f"* lambda values below {_g(thr)} 1/s (1/lambda > {_g(1 / thr / 86400, 3)} days) are reported as 0 (not resolvable).\n")
    _report_A(c, w)
    _report_B(c, w)
    v = _verdicts(c)
    _report_verdicts(c, v, w)
    _report_negative(c, v, w)
    w("\nFigures: `figures/fig_relax.pdf`, `figures/fig_relax_acf.pdf` (manuscript, scripts/09a_figs_ocv_relax.py); drafts `figures/draft_relax_fits.pdf`, `figures/draft_relax_lambda.pdf`, `figures/draft_relax_acf.pdf`; tables: `tables/tab_relax_ic.tex`, "
      "`tables/tab_relax_design.tex`, `tables/tab_relax_params.tex`; plotted arrays in `results/relaxation_curves.npz`.")
    _report_review(c, v, w)
    (REP / "relaxation_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")




def main() -> None:
    t0 = time.time()
    for p in (RES, FIG, TAB, REP):
        p.mkdir(exist_ok=True)
    if "--from-results" not in sys.argv:
        files, curves, extra = run_fits()
        save_all(files, curves, extra)
        print(f"fits done in {time.time() - t0:.1f} s")
    phen = json.loads(PHEN_JSON.read_text(encoding="utf-8"))
    mech = json.loads(MECH_JSON.read_text(encoding="utf-8"))
    arrays = dict(np.load(CURVES))
    for fn in ("make_figures", "make_tables", "write_report"):
        if fn in globals():
            globals()[fn](phen, mech, arrays)
    print(f"total {time.time() - t0:.1f} s")


if __name__ == "__main__":
    main()
