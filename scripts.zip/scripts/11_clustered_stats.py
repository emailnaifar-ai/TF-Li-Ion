"""Clustered statistics of the paired SOC differences (review 1, item 4). No estimator is re-run.

Input  : results/validation_main.json (records: per-run admissible post-convergence SOC RMSE under the reference
         Q_ref(T) and the q_ref_sensitivity cases Q_ref - u_Q, Q_ref + u_Q, observer axis; files: reference-SOC
         band at profile end).
Output : results/clustered_stats.json, reports/clustered_stats_findings.md,
         tables/paper_tab_stats.tex (main paper), tables/supp_tab_stats_full.tex (supplement).

Unit of inference = test file (18 files = 3 temperatures x 3 profiles x 2 start levels); file value = mean over the
3 initial-SOC scenarios.  d_f = TFO - comparator (positive = TFO worse), metric adm_post_rmse_pct (% SOC).
  (1) descriptive effect sizes per temperature and per profile (median, mean, range, sign counts);
  (2) temperature-stratified bootstrap (files resampled within temperature) and two-level hierarchical bootstrap
      (temperatures resampled with replacement, then files within each drawn temperature) of the pooled mean and
      median difference; percentile intervals; n_boot, seed, ci = config estimators.bootstrap; a fresh
      numpy default_rng(seed) per (contrast, case, scheme) (common random numbers across contrasts);
  (3) exact sign-flip permutation tests: file level (all 2^18 sign vectors; flipping within temperature gives the
      same group because each file is flipped independently; statistic = pooled mean, equivalently the
      equal-weight mean of the per-temperature means) and temperature level (2^3 = 8 sign vectors of the three
      per-temperature means; minimum attainable p = 1/8 = 0.125 one-sided, 0.25 two-sided);
  (4) capacity sensitivity: the same statistics under Q_ref - u_Q, Q_ref + u_Q and the observer axis;
  (5) reference-SOC band at profile end (files[].soc_band_end.linear) versus |d_f|.
Usage (project root): python scripts/11_clustered_stats.py [--tables-only]
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import data as D  # noqa: E402

RES, TAB, REP = ROOT / "results", ROOT / "tables", ROOT / "reports"
SRC = "results/validation_main.json"
TEMPS = (0, 25, 45)
PROFILES = ("FUDS", "US06", "BJDST")
METRIC = "adm_post_rmse_pct"
CASES = ("Q_ref", "Q_minus", "Q_plus", "obs_axis")
CASE_LABEL = {"Q_ref": "Q_ref", "Q_minus": "Q_ref - u_Q", "Q_plus": "Q_ref + u_Q", "obs_axis": "observer axis"}
# contrast name -> (method A, method B); d = A - B
CONTRASTS = {
    "FOO": ("TFO", "FOO"), "FOEKF": ("TFO", "FOEKF"), "EKF2RC": ("TFO", "EKF2RC"),
    "AEKF2RC": ("TFO", "AEKF2RC"), "CC": ("TFO", "CC"),
    # supplementary tempering contrasts (frozen L = 1600 s entries; pure lambda contrast with fixed gains)
    "L1600:TFO-FOO": ("TFO_L1600", "FOO_L1600"), "lam:TFO-TFO(lam=0)": ("TFO", "TFO_lam0"),
}
PRIMARY = ("FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC")
LABEL = {"FOO": "FOO", "FOEKF": "FOEKF", "EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC", "CC": "CC",
         "L1600:TFO-FOO": "TFO(1600) - FOO(1600)", "lam:TFO-TFO(lam=0)": "TFO - TFO(lambda:=0)"}
ALPHA = 0.05
TOL = 1e-12


def run_value(r: dict, case: str) -> float:
    return float(r[METRIC] if case == "Q_ref" else r["q_ref_sensitivity"][case][METRIC])


def file_table(V: dict):
    """Ordered file list (T, profile, start level) and per-(method, case) file values (mean over scenarios)."""
    files = sorted(V["files"], key=lambda f: (TEMPS.index(f["T"]), PROFILES.index(f["profile"]), f["start_level"]))
    names = [f["file"] for f in files]
    acc: dict = {}
    for r in V["records"]:
        for case in CASES:
            acc.setdefault((r["method"], case, r["file"]), []).append(run_value(r, case))
    vals = {}
    for (m, case, fn), v in acc.items():
        if len(v) != 3 or not np.all(np.isfinite(v)):
            raise ValueError(f"{m} {case} {fn}: expected 3 finite scenario values, got {v}")
        vals[(m, case, fn)] = float(np.mean(v))
    return files, names, vals


def describe(d: np.ndarray) -> dict:
    return dict(n=int(d.size), median=float(np.median(d)), mean=float(np.mean(d)), min=float(np.min(d)),
                max=float(np.max(d)), n_tfo_worse=int(np.sum(d > TOL)), n_tfo_better=int(np.sum(d < -TOL)))


def quant(x: np.ndarray, ci: float) -> list:
    return [float(v) for v in np.quantile(x, [(1 - ci) / 2, 1 - (1 - ci) / 2], method="linear")]


def boot_stratified(M: np.ndarray, n_boot: int, seed: int, ci: float) -> dict:
    """M: (3 temperatures, 6 files). Resample the 6 files within each temperature (with replacement)."""
    rng = np.random.default_rng(seed)
    nt, nf = M.shape
    idx = rng.integers(0, nf, size=(n_boot, nt, nf))
    X = M[np.arange(nt)[None, :, None], idx].reshape(n_boot, nt * nf)
    return dict(scheme="stratified", n_boot=n_boot, seed=seed, ci_level=ci,
                mean_ci=quant(X.mean(axis=1), ci), median_ci=quant(np.median(X, axis=1), ci))


def boot_hierarchical(M: np.ndarray, n_boot: int, seed: int, ci: float) -> dict:
    """Two-level: draw 3 temperatures with replacement, then 6 files with replacement within each drawn one."""
    rng = np.random.default_rng(seed)
    nt, nf = M.shape
    ti = rng.integers(0, nt, size=(n_boot, nt))
    fi = rng.integers(0, nf, size=(n_boot, nt, nf))
    X = M[ti[:, :, None], fi].reshape(n_boot, nt * nf)
    return dict(scheme="hierarchical", n_boot=n_boot, seed=seed, ci_level=ci,
                mean_ci=quant(X.mean(axis=1), ci), median_ci=quant(np.median(X, axis=1), ci),
                n_distinct_temperature_multisets=10)


def sign_flip_exact(d: np.ndarray) -> dict:
    """Exact sign-flip test over all 2^n sign vectors; statistics = mean and median of the flipped differences."""
    n = d.size
    k = np.arange(2 ** n, dtype=np.int64)
    S = 1.0 - 2.0 * ((k[:, None] >> np.arange(n)[None, :]) & 1)
    out = dict(n=int(n), n_configurations=int(2 ** n))
    for name, stat in (("mean", lambda X: X.mean(axis=1)), ("median", lambda X: np.median(X, axis=1))):
        t = stat(S * d[None, :])
        t0 = float(stat(d[None, :])[0])
        tol = TOL * max(1.0, abs(t0))
        out[name] = dict(observed=t0, p_two_sided=float(np.mean(np.abs(t) >= abs(t0) - tol)),
                         p_one_sided_tfo_worse=float(np.mean(t >= t0 - tol)),
                         p_one_sided_tfo_better=float(np.mean(t <= t0 + tol)))
    return out


def sign_flip_temperature(m3: np.ndarray) -> dict:
    """Exact sign flip of the three per-temperature mean differences (8 configurations)."""
    r = sign_flip_exact(np.asarray(m3, float))["mean"]
    r["p_one_sided_observed_direction"] = r["p_one_sided_tfo_worse" if r["observed"] > 0 else "p_one_sided_tfo_better"]
    r.update(n_configurations=8, min_attainable_p_one_sided=0.125, min_attainable_p_two_sided=0.25,
             per_temperature_means=[float(v) for v in m3])
    return r


def summarise(M: np.ndarray, groups: dict, bs: dict) -> dict:
    d = M.reshape(-1)
    per_T = {str(T): describe(M[i]) for i, T in enumerate(TEMPS)}
    per_P = {p: describe(d[np.array(groups["profile"]) == p]) for p in PROFILES}
    strat = boot_stratified(M, bs["n_boot"], bs["seed"], bs["ci"])
    hier = boot_hierarchical(M, bs["n_boot"], bs["seed"], bs["ci"])
    perm = sign_flip_exact(d)
    permT = sign_flip_temperature(M.mean(axis=1))
    med_T = [per_T[str(T)]["median"] for T in TEMPS]
    same_sign_T = bool(all(v > TOL for v in med_T) or all(v < -TOL for v in med_T))
    excl = lambda c: bool(c[0] > 0 or c[1] < 0)  # noqa: E731
    significant = bool(excl(strat["mean_ci"]) and perm["mean"]["p_two_sided"] < ALPHA)
    return dict(pooled=describe(d), per_temperature=per_T, per_profile=per_P, stratified=strat, hierarchical=hier,
                sign_flip_file=perm, sign_flip_temperature=permT, median_by_T_same_sign=same_sign_T,
                stratified_mean_ci_excludes_0=excl(strat["mean_ci"]),
                stratified_median_ci_excludes_0=excl(strat["median_ci"]),
                hierarchical_mean_ci_excludes_0=excl(hier["mean_ci"]),
                hierarchical_median_ci_excludes_0=excl(hier["median_ci"]),
                significant=significant,
                significant_median=bool(excl(strat["median_ci"]) and perm["median"]["p_two_sided"] < ALPHA),
                significance_rule="stratified 95 % CI of the mean excludes 0 AND exact file-level sign-flip p "
                                  "(two-sided, mean) < 0.05; median rule: the same with the median",
                file_differences=[float(v) for v in d])


def band_comparison(files: list, M: np.ndarray) -> dict:
    """|d_f| versus the file's reference-SOC band at profile end (both in % SOC)."""
    b = np.array([100.0 * f["soc_band_end"]["linear"] for f in files]).reshape(M.shape)
    a = np.abs(M)
    ratio = a / b
    return dict(n_files_abs_diff_below_band=int(np.sum(a < b)), n_files=int(a.size),
                max_ratio_abs_diff_to_band=float(ratio.max()), median_ratio_abs_diff_to_band=float(np.median(ratio)),
                pooled_abs_median_diff=float(abs(np.median(M))), pooled_abs_mean_diff=float(abs(np.mean(M))),
                pooled_mean_below_min_band=bool(abs(np.mean(M)) < b.min()),
                per_temperature={str(T): dict(abs_median_diff=float(abs(np.median(M[i]))),
                                              band_min=float(b[i].min()), band_max=float(b[i].max()),
                                              n_files_abs_diff_below_band=int(np.sum(a[i] < b[i])))
                                 for i, T in enumerate(TEMPS)})


def verdict(res: dict) -> dict:
    """Robust = per-temperature median difference of the same sign in all 12 cells (3 T x 4 reference cases)."""
    cells = {f"{c}|T={T}": res[c]["per_temperature"][str(T)]["median"] for c in CASES for T in TEMPS}
    pos = [k for k, v in cells.items() if v > TOL]
    neg = [k for k, v in cells.items() if v < -TOL]
    sign_robust = not pos or not neg
    sig = [c for c in CASES if res[c]["significant"]]
    sig_med = [c for c in CASES if res[c]["significant_median"]]
    pooled_signs = {c: int(np.sign(res[c]["pooled"]["mean"])) for c in CASES}
    direction = "TFO worse" if len(pos) >= len(neg) else "TFO better"
    if sign_robust and len(sig) == len(CASES):
        label = "robust"
        text = f"{direction} at all three temperatures under all four reference cases; significant under all four"
    elif sign_robust:
        label = "sign robust, significance not robust"
        lost = [CASE_LABEL[c] for c in CASES if c not in sig]
        text = (f"{direction} at all three temperatures under all four reference cases; not significant under "
                + ", ".join(lost))
    else:
        label = "not robust"
        minority = neg if len(pos) >= len(neg) else pos
        text = f"per-temperature sign changes ({direction} in the majority); opposite sign in " + ", ".join(minority)
    return dict(label=label, text=text, direction=direction, n_cells_tfo_worse=len(pos), n_cells_tfo_better=len(neg),
                opposite_sign_cells=(neg if len(pos) >= len(neg) else pos), significant_cases=sig,
                significant_cases_median_rule=sig_med,
                pooled_mean_sign_by_case=pooled_signs,
                pooled_mean_sign_constant=len(set(pooled_signs.values())) == 1,
                nominal_same_sign_all_T=res["Q_ref"]["median_by_T_same_sign"])


def crosscheck(V: dict, name: str, res: dict) -> dict | None:
    """Pooled file-level median against validation_main.json paired[] (reference TFO only)."""
    a, b = CONTRASTS[name]
    if a != "TFO":
        return None
    out = {}
    for c in CASES:
        key = METRIC if c == "Q_ref" else f"{METRIC}@{c}"
        hit = [p for p in V["paired"] if p["reference"] == "TFO" and p["comparator"] == b and p["metric"] == key
               and p["unit"] == "file" and p["group"] == "all"]
        if hit:
            out[c] = dict(paired_median=hit[0]["median_diff"], paired_mean=hit[0]["mean_diff"],
                          wilcoxon_p=hit[0]["wilcoxon_p"],
                          abs_dev_median=abs(hit[0]["median_diff"] - res[c]["pooled"]["median"]),
                          abs_dev_mean=abs(hit[0]["mean_diff"] - res[c]["pooled"]["mean"]))
    return out or None


def compute() -> dict:
    cfg = D.load_config()
    bsc = cfg["estimators"]["bootstrap"]
    bs = dict(n_boot=int(bsc["n_boot"]), seed=int(bsc["seed"]), ci=float(bsc["ci"]))
    raw = (RES / "validation_main.json").read_bytes()
    V = json.loads(raw)
    files, names, vals = file_table(V)
    T_of = [f["T"] for f in files]
    if [T_of.count(T) for T in TEMPS] != [6, 6, 6]:
        raise ValueError("expected 6 test files per temperature")
    groups = dict(T=T_of, profile=[f["profile"] for f in files])
    out = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
               script="scripts/11_clustered_stats.py",
               source=dict(file=SRC, sha256=hashlib.sha256(raw).hexdigest(), generated_utc=V["generated_utc"],
                           code_hash=V["code_hash"]),
               settings=dict(metric=METRIC, unit="file (mean over the 3 initial-SOC scenarios)", n_files=len(files),
                             difference="TFO minus comparator (positive = TFO worse), % SOC",
                             bootstrap=dict(bs, source="config estimators.bootstrap", interval="percentile",
                                            rng="numpy default_rng(seed), fresh per (contrast, case, scheme)"),
                             cases={c: CASE_LABEL[c] for c in CASES},
                             robust_rule="per-temperature median difference of the same sign in all 3 T x 4 "
                                         "reference cases; 'significant' per case = stratified 95 % CI of the mean "
                                         "excludes 0 and exact file-level sign-flip p (two-sided) < 0.05",
                             hierarchical_note="3 temperature clusters: only 10 distinct temperature multisets, so "
                                               "the hierarchical interval mainly reflects between-temperature "
                                               "heterogeneity and is coarse",
                             band="files[].soc_band_end.linear x 100 (reference-SOC uncertainty at profile end)"),
               files=[dict(file=f["file"], T=f["T"], profile=f["profile"], start_level=f["start_level"],
                           soc_band_end_pct=100.0 * f["soc_band_end"]["linear"]) for f in files],
               band_range_pct=[100.0 * min(f["soc_band_end"]["linear"] for f in files),
                               100.0 * max(f["soc_band_end"]["linear"] for f in files)],
               contrasts={})
    for name, (a, b) in CONTRASTS.items():
        res = dict(method_a=a, method_b=b, label=LABEL[name], primary=name in PRIMARY)
        for c in CASES:
            M = np.array([vals[(a, c, fn)] - vals[(b, c, fn)] for fn in names]).reshape(len(TEMPS), 6)
            res[c] = summarise(M, groups, bs)
            if c == "Q_ref":
                res["band"] = band_comparison(files, M)
        res["verdict"] = verdict(res)
        res["crosscheck_validation_main_paired"] = crosscheck(V, name, res)
        out["contrasts"][name] = res
    out["file_order"] = names
    return out


# ----------------------------------------------------------------------------------------------- formatting
HEAD = "% Generated by scripts/11_clustered_stats.py from results/clustered_stats.json -- do not edit by hand.\n"
J = "results/clustered_stats.json"
TEX_LABEL = {"FOO": "FOO", "FOEKF": "FOEKF", "EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC", "CC": "CC",
             "L1600:TFO-FOO": r"TFO$_{1600}$ vs FOO$_{1600}$", "lam:TFO-TFO(lam=0)": r"TFO vs TFO($\lambda{:=}0$)"}
TEX_CASE = {"Q_ref": r"$Q_\mathrm{ref}$", "Q_minus": r"$Q_\mathrm{ref}-u_Q$", "Q_plus": r"$Q_\mathrm{ref}+u_Q$",
            "obs_axis": r"obs.\ axis"}


def f3(x: float) -> str:
    s = f"{x:.3f}"
    return "0.000" if s == "-0.000" else s


def t3(x: float) -> str:
    s = f3(x)
    return s.replace("-", "$-$") if s.startswith("-") else s


def tci(v: float, ci: list) -> str:
    return f"{t3(v)} [{t3(ci[0])}, {t3(ci[1])}]"


def pnum(p: float) -> str:
    return rf"\num{{{p:.1e}}}" if p < 1e-3 else f"{p:.3f}"


def ptxt(p: float) -> str:
    return f"{p:.1e}" if p < 1e-3 else f"{p:.3f}"


def yn(b: bool) -> str:
    return "yes" if b else "no"


def ici(ci: list) -> str:
    return f"[{t3(ci[0])}, {t3(ci[1])}]"


def main_table(o: dict) -> str:
    """Main-paper table (revision 2): per-temperature medians, stratified and hierarchical intervals and the
    pooled mean under the capacity case Q_ref - u_Q (the case in which the benchmark contrasts lose
    significance). Pooled p-values are left to the supplement table (review 1, item 4)."""
    rows = []
    for n in ("FOO", "FOEKF", "EKF2RC", "AEKF2RC"):
        r, q, qm = o["contrasts"][n], o["contrasts"][n]["Q_ref"], o["contrasts"][n]["Q_minus"]
        med = " & ".join(f3(q["per_temperature"][str(T)]["median"]) for T in TEMPS)
        rows.append(
            f"{TEX_LABEL[n]} & {med} & {tci(q['pooled']['median'], q['stratified']['median_ci'])} & "
            f"{tci(q['pooled']['mean'], q['stratified']['mean_ci'])} & "
            f"{ici(q['hierarchical']['mean_ci'])} & "
            f"{tci(qm['pooled']['mean'], qm['stratified']['mean_ci'])} \\\\ "
            f"% src: {J}:contrasts[{n}].Q_ref.per_temperature[0,25,45].median, .pooled.median/.mean, "
            f".stratified.median_ci/.mean_ci, .hierarchical.mean_ci; "
            f"contrasts[{n}].Q_minus.pooled.mean, .stratified.mean_ci")
    nb = o["settings"]["bootstrap"]["n_boot"]
    return HEAD + r"""\begin{table}[t]\centering\footnotesize
\caption{Temperature-clustered paired differences of the SOC RMSE, TFO minus comparator}\label{tab:stats}
\setlength{\tabcolsep}{3pt}
\begin{tabular}{@{}lS[table-format=-1.3]S[table-format=-1.3]S[table-format=-1.3]llll@{}}
\toprule
 & \multicolumn{3}{c}{Median by temperature} & \multicolumn{3}{c}{Pooled over 18 files, $Q_{\mathrm{ref}}$ [\SI{95}{\percent} CI]} & \multicolumn{1}{c}{$Q_{\mathrm{ref}}-u_{Q}$} \\
\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(l){8-8}
Comparator & {\SI{0}{\celsius}} & {\SI{25}{\celsius}} & {\SI{45}{\celsius}} & Median, strat. & Mean, strat. & Mean, hier. & Mean, strat. \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\par\smallskip\parbox{\linewidth}{\scriptsize Admissible post-convergence SOC RMSE (\si{\percent} SOC); file value = mean over the three initial-SOC scenarios; positive: TFO worse. Strat.: files resampled within temperature; hier.: temperatures, then files (interval of the mean; indicative only, since three clusters give 10 distinct temperature resamples); percentile intervals, \num{""" + f"{nb}" + r"""} draws. CC: Table~\ref{tab:soc}; sign-flip tests and all reference cases: Supplementary Section~\suppref{sec:B:clustered}. $Q_{\mathrm{ref}}-u_{Q}$: reference capacity lowered by its uncertainty.}
\end{table}
"""


def o_band(o: dict, T: int) -> str:
    b = o["contrasts"]["FOO"]["band"]["per_temperature"][str(T)]
    return rf"\multicolumn{{1}}{{c}}{{{b['band_min']:.1f}--{b['band_max']:.1f}}}"


def supp_tables(o: dict) -> str:
    A, B, C = [], [], []
    for n in CONTRASTS:
        r = o["contrasts"][n]
        q = r["Q_ref"]
        A.append(rf"\multicolumn{{6}}{{@{{}}l}}{{\emph{{{TEX_LABEL[n]}}}}} \\")
        for key, lab in [(str(T), rf"\SI{{{T}}}{{\celsius}}") for T in TEMPS] + [(p, p) for p in PROFILES]:
            grp = "per_temperature" if key in q["per_temperature"] else "per_profile"
            g = q[grp][key]
            A.append(f"\\quad {lab} & {f3(g['median'])} & {f3(g['mean'])} & {f3(g['min'])} & {f3(g['max'])} & "
                     f"{g['n_tfo_worse']}/{g['n_tfo_better']} \\\\ % src: {J}:contrasts[{n}].Q_ref.{grp}[{key}]")
        B.append(rf"\multicolumn{{9}}{{@{{}}l}}{{\emph{{{TEX_LABEL[n]}}}: {r['verdict']['label']}}} \\")
        for c in CASES:
            x = r[c]
            med = " & ".join(f3(x["per_temperature"][str(T)]["median"]) for T in TEMPS)
            B.append(f"\\quad {TEX_CASE[c]} & {med} & {tci(x['pooled']['mean'], x['stratified']['mean_ci'])} & "
                     f"[{t3(x['hierarchical']['mean_ci'][0])}, {t3(x['hierarchical']['mean_ci'][1])}] & "
                     f"{tci(x['pooled']['median'], x['stratified']['median_ci'])} & "
                     f"{pnum(x['sign_flip_file']['mean']['p_two_sided'])} & "
                     f"{x['sign_flip_temperature']['p_one_sided_observed_direction']:.3f} \\\\ "
                     f"% src: {J}:contrasts[{n}].{c}.per_temperature[*].median, .stratified, .hierarchical, "
                     f".sign_flip_file.mean.p_two_sided, .sign_flip_temperature.p_one_sided_observed_direction")
        b = r["band"]
        C.append(f"{TEX_LABEL[n]} & "
                 + " & ".join(f3(b["per_temperature"][str(T)]["abs_median_diff"]) for T in TEMPS)
                 + f" & {b['n_files_abs_diff_below_band']}/{b['n_files']} & {b['max_ratio_abs_diff_to_band']:.2f} \\\\ "
                 f"% src: {J}:contrasts[{n}].band")
    bands = " & ".join(o_band(o, T) for T in TEMPS)
    return HEAD + r"""\begin{table}[!htbp]\centering\footnotesize
\caption{Per-stratum paired differences of the SOC RMSE under the nominal reference capacity}\label{tab:supp_stats_strata}
\begin{tabular}{@{}lS[table-format=-2.3]S[table-format=-2.3]S[table-format=-2.3]S[table-format=-2.3]c@{}}
\toprule
Stratum ($n=6$) & {Median} & {Mean} & {Min} & {Max} & {TFO worse/better} \\
\midrule
""" + "\n".join(A) + r"""
\bottomrule
\end{tabular}
\par\smallskip\parbox{\linewidth}{\scriptsize TFO minus the named method; admissible post-convergence SOC RMSE (\si{\percent} SOC); file value = mean over the three initial-SOC scenarios. Descriptive only.}
\end{table}

\begin{table}[!htbp]\centering\scriptsize
\caption{Clustered bootstrap and sign-flip tests under the four reference-capacity cases}\label{tab:supp_stats_capacity}
\setlength{\tabcolsep}{1.8pt}
\begin{tabular}{@{}lS[table-format=-2.3]S[table-format=-2.3]S[table-format=-2.3]lllcS[table-format=1.3]@{}}
\toprule
 & \multicolumn{3}{c}{Median by temperature} & \multicolumn{3}{c}{Pooled [\SI{95}{\percent} CI]} & \multicolumn{2}{c}{Sign-flip $p$} \\
\cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(l){8-9}
Reference & {\SI{0}{\celsius}} & {\SI{25}{\celsius}} & {\SI{45}{\celsius}} & Mean, stratified & Hierarchical & Median, stratified & {File} & {$T$ level} \\
\midrule
""" + "\n".join(B) + r"""
\bottomrule
\end{tabular}
\par\smallskip\parbox{\linewidth}{\scriptsize Positive: TFO worse. File-level $p$: exact two-sided test of the mean over $2^{18}$ sign vectors. $T$-level $p$: one-sided test (in the observed direction) of the three per-temperature means over $2^3$ sign vectors, minimum attainable 0.125. The hierarchical interval rests on three temperature clusters (10 distinct multisets) and is coarse. Label after each name: sign of the per-temperature medians across the 12 temperature--reference cells.}
\end{table}

\begin{table}[!htbp]\centering\footnotesize
\caption{Paired differences against the reference-SOC uncertainty band at profile end}\label{tab:supp_stats_band}
\begin{tabular}{@{}lS[table-format=2.3]S[table-format=2.3]S[table-format=2.3]cS[table-format=1.2]@{}}
\toprule
 & \multicolumn{3}{c}{$|$Median difference$|$ (\si{\percent} SOC)} & {Files with} & {Max} \\
\cmidrule(lr){2-4}
Comparator & {\SI{0}{\celsius}} & {\SI{25}{\celsius}} & {\SI{45}{\celsius}} & {$|d|<$ band} & {$|d|/$band} \\
\midrule
Band (\si{\percent} SOC) & """ + bands + r""" & {--} & {--} \\ % src: """ + J + r""":contrasts[FOO].band.per_temperature[*].band_min/band_max
""" + "\n".join(C) + r"""
\bottomrule
\end{tabular}
\par\smallskip\parbox{\linewidth}{\scriptsize Band: per-file reference-SOC uncertainty at profile end from $u_Q$ and the current-channel offset; $d$: per-file difference under $Q_\mathrm{ref}$.}
\end{table}
"""


# ----------------------------------------------------------------------------------------------- CC, report, main
def cc_by_scenario(o: dict) -> dict:
    """TFO - CC per scenario (CC cannot correct an initial SOC error, so the pooled CC contrast mixes two regimes)."""
    V = json.loads((RES / "validation_main.json").read_text(encoding="utf-8"))
    val = {(r["method"], r["file"], r["scenario"]): float(r[METRIC]) for r in V["records"] if r["method"] in ("TFO", "CC")}
    names = o["file_order"]
    cfg = o["settings"]["bootstrap"]
    out = {}
    for sc in ("nominal", "plus20", "minus20"):
        M = np.array([val[("TFO", f, sc)] - val[("CC", f, sc)] for f in names]).reshape(len(TEMPS), 6)
        out[sc] = dict(pooled=describe(M.reshape(-1)),
                       per_temperature={str(T): describe(M[i]) for i, T in enumerate(TEMPS)},
                       stratified=boot_stratified(M, cfg["n_boot"], cfg["seed"], cfg["ci"]),
                       sign_flip_file=sign_flip_exact(M.reshape(-1))["mean"])
    return out


def nm(n: str) -> str:
    return f"TFO vs {LABEL[n]}" if n in PRIMARY else LABEL[n]


def line(n: str, x: dict) -> str:
    med = ", ".join(f"{T} C {f3(x['per_temperature'][str(T)]['median'])}" for T in TEMPS)
    return (f"per-T median {med}; pooled median {f3(x['pooled']['median'])} (stratified CI "
            f"[{f3(x['stratified']['median_ci'][0])}, {f3(x['stratified']['median_ci'][1])}]); mean "
            f"{f3(x['pooled']['mean'])} (stratified [{f3(x['stratified']['mean_ci'][0])}, "
            f"{f3(x['stratified']['mean_ci'][1])}], hierarchical [{f3(x['hierarchical']['mean_ci'][0])}, "
            f"{f3(x['hierarchical']['mean_ci'][1])}]); sign-flip p (mean) {ptxt(x['sign_flip_file']['mean']['p_two_sided'])}, "
            f"(median) {ptxt(x['sign_flip_file']['median']['p_two_sided'])}; T-level one-sided p (observed direction) "
            f"{x['sign_flip_temperature']['p_one_sided_observed_direction']:.3f}; TFO worse/better in "
            f"{x['pooled']['n_tfo_worse']}/{x['pooled']['n_tfo_better']} files")


def report(o: dict) -> str:
    C = o["contrasts"]
    L = ["# Clustered statistics of the paired SOC differences (review 1, item 4)", "",
         f"Generated by `scripts/11_clustered_stats.py` ({o['generated_utc']}) from `{SRC}` (generated "
         f"{o['source']['generated_utc']}, sha256 {o['source']['sha256'][:16]}). No estimator was re-run.", "",
         "Metric: admissible post-convergence SOC RMSE (% SOC). Unit = test file (n = 18; 6 per temperature, 6 per "
         "profile); file value = mean over the 3 initial-SOC scenarios. d = TFO - comparator (positive = TFO worse). "
         f"Bootstrap: {o['settings']['bootstrap']['n_boot']} draws, seed {o['settings']['bootstrap']['seed']} "
         "(config estimators.bootstrap), percentile 95 % intervals; stratified = files resampled within temperature; "
         "hierarchical = 3 temperatures drawn with replacement, then 6 files within each. Exact sign-flip tests: file "
         "level over all 2^18 sign vectors (flipping within temperature gives the same group); temperature level over "
         "2^3 = 8 vectors of the per-temperature means (minimum attainable p = 0.125 one-sided, 0.25 two-sided). "
         "Pooled medians and means reproduce `validation_main.json` paired[] exactly (max deviation "
         f"{max(v['abs_dev_median'] for c in C.values() if c['crosscheck_validation_main_paired'] for v in c['crosscheck_validation_main_paired'].values()):.1e}).",
         "", "Robust = per-temperature median difference of the same sign at 0, 25 and 45 C under all four reference "
         "cases (Q_ref, Q_ref - u_Q, Q_ref + u_Q, observer axis). Significant (per case) = stratified 95 % CI of the "
         "mean excludes 0 and file-level sign-flip p < 0.05 (mean rule); the median rule is reported next to it.", "",
         "## Key findings", ""]
    rob = [n for n in CONTRASTS if C[n]["verdict"]["label"] == "robust"]
    L.append("1. **Robust conclusions:** " + (", ".join(f"{nm(n)} ({C[n]['verdict']['text']})" for n in rob)
                                                if rob else "none") + ". "
             + ", ".join(nm(n) for n in CONTRASTS if n not in rob)
             + ": the per-temperature median changes sign in at least one temperature-reference cell (listed below).")
    k = 2
    for n in CONTRASTS:
        v = C[n]["verdict"]
        sig = ", ".join(CASE_LABEL[c] for c in v["significant_cases"]) or "none"
        sigm = ", ".join(CASE_LABEL[c] for c in v["significant_cases_median_rule"]) or "none"
        opp = ", ".join(v["opposite_sign_cells"]) or "none"
        L.append(f"{k}. **{nm(n)}** ({v['label']}). Q_ref: {line(n, C[n]['Q_ref'])}. Same sign at all T under "
                 f"Q_ref: {yn(v['nominal_same_sign_all_T'])}. Significant (mean rule) under: {sig}; (median rule) "
                 f"under: {sigm}. Opposite-sign cells: {opp}.")
        k += 1
    cc = o["cc_by_scenario"]
    L.append(f"{k}. **CC contrast by scenario.** TFO - CC nominal: median {f3(cc['nominal']['pooled']['median'])}, mean "
             f"{f3(cc['nominal']['pooled']['mean'])} (stratified CI [{f3(cc['nominal']['stratified']['mean_ci'][0])}, "
             f"{f3(cc['nominal']['stratified']['mean_ci'][1])}]), TFO worse/better in "
             f"{cc['nominal']['pooled']['n_tfo_worse']}/{cc['nominal']['pooled']['n_tfo_better']} files, sign-flip p "
             f"{ptxt(cc['nominal']['sign_flip_file']['p_two_sided'])}; +0.20: median {f3(cc['plus20']['pooled']['median'])}; "
             f"-0.20: median {f3(cc['minus20']['pooled']['median'])}. The robust TFO advantage over CC comes from the "
             "+-0.20 initial-SOC errors, which open-loop CC cannot correct; from the nominal initial SOC it does not hold.")
    k += 1
    b = C["FOO"]["band"]["per_temperature"]
    L.append(f"{k}. **Reference-SOC band.** Band at profile end {o['band_range_pct'][0]:.2f}-{o['band_range_pct'][1]:.2f} % SOC "
             f"(0 C {b['0']['band_min']:.2f}-{b['0']['band_max']:.2f}, 25 C {b['25']['band_min']:.2f}-{b['25']['band_max']:.2f}, "
             f"45 C {b['45']['band_min']:.2f}-{b['45']['band_max']:.2f}). Files with |d| below the file's band: "
             + ", ".join(f"{LABEL[n]} {C[n]['band']['n_files_abs_diff_below_band']}/18 (max |d|/band "
                         f"{C[n]['band']['max_ratio_abs_diff_to_band']:.2f})" for n in CONTRASTS)
             + ". Contrasts with at least one file above its band: "
             + (", ".join(nm(n) for n in CONTRASTS if C[n]["band"]["n_files_abs_diff_below_band"] < 18) or "none")
             + ". The band bounds the reference error of each method's RMSE, "
               "not of the paired difference, which is why the capacity cases above are needed; they show that the "
               "sub-band differences can change sign.")
    L += ["", "## Capacity sensitivity (per-temperature medians and pooled statistics)", "",
          "| contrast | reference | median 0 / 25 / 45 C | mean [stratified] | mean [hierarchical] | median [stratified] | p file (mean) | p T-level (1-sided, observed direction) | sig. mean / median |",
          "|---|---|---|---|---|---|---|---|---|"]
    for n in CONTRASTS:
        for c in CASES:
            x = C[n][c]
            L.append(f"| {LABEL[n]} | {CASE_LABEL[c]} | " + " / ".join(f3(x["per_temperature"][str(T)]["median"]) for T in TEMPS)
                     + f" | {f3(x['pooled']['mean'])} [{f3(x['stratified']['mean_ci'][0])}, {f3(x['stratified']['mean_ci'][1])}]"
                     f" | [{f3(x['hierarchical']['mean_ci'][0])}, {f3(x['hierarchical']['mean_ci'][1])}]"
                     f" | {f3(x['pooled']['median'])} [{f3(x['stratified']['median_ci'][0])}, {f3(x['stratified']['median_ci'][1])}]"
                     f" | {ptxt(x['sign_flip_file']['mean']['p_two_sided'])} | {x['sign_flip_temperature']['p_one_sided_observed_direction']:.3f}"
                     f" | {yn(x['significant'])} / {yn(x['significant_median'])} |")
    L += ["", "## Per-stratum effect sizes under Q_ref (descriptive)", "",
          "| contrast | stratum | median | mean | min | max | TFO worse/better |", "|---|---|---|---|---|---|---|"]
    for n in CONTRASTS:
        q = C[n]["Q_ref"]
        for key in [str(T) for T in TEMPS] + list(PROFILES):
            g = q["per_temperature"].get(key) or q["per_profile"][key]
            lab = f"{key} C" if key.isdigit() else key
            L.append(f"| {LABEL[n]} | {lab} | {f3(g['median'])} | {f3(g['mean'])} | {f3(g['min'])} | {f3(g['max'])} | "
                     f"{g['n_tfo_worse']}/{g['n_tfo_better']} |")
    L += ["", "## Limitations", "",
          "- One dynamic cell (SP2) at three chamber temperatures: cross-profile and cross-temperature evidence, not "
          "cross-cell. Files of one cell share the cell's parameters and the reference capacity per temperature.",
          "- Three temperature clusters: the hierarchical bootstrap has only 10 distinct temperature multisets and the "
          "temperature-level sign-flip test cannot reach p < 0.125 (one-sided). Neither can establish a population "
          "effect over temperatures; they show how much the pooled statistics depend on between-temperature spread.",
          "- The file-level sign-flip test treats the 18 files as exchangeable under the null (symmetry of d within "
          "each file); two start levels of the same profile and temperature are not independent in practice.",
          "- The mean rule is sensitive to benchmark failures (EKF-2RC at 25 C, AEKF-2RC at 45 C); the median rule "
          "is reported next to it. No multiplicity adjustment across the 7 contrasts x 4 reference cases.",
          "- Supplementary contrasts (TFO(1600) vs FOO(1600), TFO vs TFO(lambda:=0)) come from the post hoc "
          "diagnostic entries of validation_main.json; nothing is selected from them.", ""]
    return "\n".join(L)


def main() -> None:
    if "--tables-only" in sys.argv:  # rebuild the tables from the saved JSON (no bootstrap)
        o = json.loads((RES / "clustered_stats.json").read_text(encoding="utf-8"))
        (TAB / "paper_tab_stats.tex").write_text(main_table(o), encoding="utf-8")
        (TAB / "supp_tab_stats_full.tex").write_text(supp_tables(o), encoding="utf-8")
        print("tables rebuilt from", J)
        return
    o = compute()
    o["cc_by_scenario"] = cc_by_scenario(o)
    (RES / "clustered_stats.json").write_text(json.dumps(o, indent=1), encoding="utf-8")
    o = json.loads((RES / "clustered_stats.json").read_text(encoding="utf-8"))  # tables/report from the saved JSON
    (TAB / "paper_tab_stats.tex").write_text(main_table(o), encoding="utf-8")
    (TAB / "supp_tab_stats_full.tex").write_text(supp_tables(o), encoding="utf-8")
    (REP / "clustered_stats_findings.md").write_text(report(o), encoding="utf-8")
    for n in CONTRASTS:
        print(f"{LABEL[n]:24s} {o['contrasts'][n]['verdict']['label']}")


if __name__ == "__main__":
    main()
