"""Build the public reproducibility package (the content of https://github.com/emailnaifar-ai/TF-Li-Ion).

The public repository holds the reproducibility package only: code (src/, scripts/, tests/), configuration (config/),
saved results (results/), generated figures and tables (figures/, tables/), analysis reports (reports/), the two
compiled technical reports (technical_report/*.pdf, complete proofs and extended results), the data
manifest and the environment files, plus the repository files kept in release_files/ (README.md, LICENSE,
CITATION.cff, .gitignore), which replace the project README and .gitignore at the top of the copy.

Never shipped:
    data:        dataset/ (the 21 CALCE archives), data_raw/, data_processed/  (CALCE records are not redistributed)
    working:     scratch/, archive_long/, submission/, github/, release_files/ (copied to the top instead),
                 __pycache__/, .pytest_cache/, *.pyc, LaTeX build files
    manuscript:  manuscript.tex/.pdf, paper/, manuscript_parts/, supplementary/, supplementary_*.tex/.pdf,
                 nomenclature.tex, References.bib (the paper is under review and is distributed by the journal)
    reports on the writing of the manuscript (theory status, final/units audits, condensation map, short-paper claims
                 map, supplement Part A closure log) and the manuscript build helper scripts/12_supp_refs.py, listed in
                 EXCLUDE_FILES
    the per-temperature post-identification caches results/identification_runs/post_* (they hold the measured
                 voltage and current; 04_identify.py --resume recomputes them from the data)

Measured signals. Three result archives contain resampled subsets of the measured CALCE signals (1 s grid):
    results/identification_arrays.npz   acc__<record>__Vmeas, __I, __t      (draft identification figures)
    results/validation_series.npz       <record>|V_meas, <record>|t_V         (voltage-fit figures)
    results/relaxation_curves.npz       rest-voltage curves and residuals     (relaxation figures)
By default the copy of these archives omits the measured channels (MEASURED). The figures drawn from the measured
channels are rebuilt after the CALCE records have been downloaded and the analysis steps re-run (README, section 6).

Signals derived from the measured current. The coulomb-counted SOC trajectories on the 1 s grid (reference SOC
zref*, estimates zhat|*, including coulomb counting) give back the measured current through I = -Q dz/dt, and the
model output voltages Vt_* / acc__*__V contain it through the ohmic term. The public copy therefore
    - keeps the SOC trajectories of validation_series.npz (t_soc, zref*, zhat|*) on a 60 s grid only (DECIMATE,
      every 60th sample), so that at most 60 s mean currents can be derived from them;
    - drops the model output voltages (validation_series <record>|Vt_*, identification_arrays acc__*__V) and the
      reference SOC of the identification records (acc__*__z); they are used only with the measured voltage;
    - adds the median |SOC error| envelope of article Fig. 3(b), computed from the 1 s trajectories
      (keys paper_fig3_env|*; a median over 36 runs, from which no record can be recovered);
    - removes the 10 s reference SOC of the robustness figure record (robustness.json figure.traj.zref; not plotted);
    - redraws figures/fig_soc_test.pdf and figures/paper_fig3_soc.pdf from the 60 s trajectories, so the shipped
      PDFs equal a data-free rebuild and hold no 1 s SOC path.
Every other array (estimation errors, fitted parameters, statistics, fit grids) is kept. --keep-measured copies
the archives and figures unchanged (only if the CALCE terms allow redistribution).

Usage (project root):
    python scripts/make_release.py                 # write RELEASE_MANIFEST.txt (file list with sizes) only
    python scripts/make_release.py --out github    # rebuild github/ (keeps github/.git), measured channels stripped
"""
from __future__ import annotations

import argparse
import fnmatch
import os
import re
import shutil
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TOP_FILES = ["environment.yml", "requirements.txt", "data_manifest.json", "RELEASE_MANIFEST.txt"]
TOP_DIRS = ["config", "figures", "tables", "src", "scripts", "results", "reports", "tests", "technical_report"]
REPO_FILES = ROOT / "release_files"          # README.md, LICENSE, CITATION.cff, .gitignore of the repository
EXCLUDE_DIRS = {"dataset", "data_raw", "data_processed", "scratch", "archive_long", "submission", "github",
                "__pycache__", ".pytest_cache"}
EXCLUDE_GLOBS = ["*.pyc", "*.aux", "*.log", "*.bbl", "*.blg", "*.out", "*.toc", "*.synctex.gz", "*.fls",
                 "*.fdb_latexmk", "Thumbs.db", ".DS_Store", "*.tmp", "~$*"]
EXCLUDE_FILES = ["reports/F_theory_status.md", "reports/L_final_technical_audit.md", "reports/audit_units.md",
                 "reports/theory_condensation_map.md", "reports/claims_to_evidence_short.md",
                 "results/identification_runs/post_*", "reports/reproduce_log.json", "reports/review_response.md",
                 "reports/supp_partA_closure.md", "scripts/12_supp_refs.py"]
MEASURED = {  # archive -> key patterns of measured channels (voltage, current, time of the CALCE records)
    "results/identification_arrays.npz": ["*__Vmeas", "*__I", "*__t"],
    "results/validation_series.npz": ["*|V_meas", "*|t_V"],
    "results/relaxation_curves.npz": ["*_full*", "*V_sub_mV", "*t_sub", "*rep_y_*", "*rep_t_*", "*resid_sub_mV"],
}
DERIVED_DROP = {  # archive -> model outputs driven by the measured current (used only with the measured voltage)
    "results/identification_arrays.npz": ["acc__*__V", "acc__*__z"],
    "results/validation_series.npz": ["*|Vt_*"],
}
DECIMATE = {"results/validation_series.npz": ["*|t_soc", "*|zref", "*|zref_*", "*|zhat|*"]}   # 1 s -> 60 s grid
DECIMATE_STEP = 60
JSON_DROP = {"results/robustness.json": '"zref"', "results/archive/E2_pre_review/robustness.json": '"zref"'}
REDRAW = ["figures/fig_soc_test.pdf", "figures/paper_fig3_soc.pdf"]   # redrawn in the copy from the 60 s grid
TEXT_EXT = {".py", ".md", ".json", ".txt", ".tex", ".yaml", ".yml", ".cff", ".csv", ".gitignore", ""}
ABS_PATH = re.compile(r"[A-Za-z]:(?:\\\\|\\|/)(?:Users|a)(?:\\\\|\\|/)[^\"'\s,;)]*")   # Windows user/CI paths
MAX_BYTES = 50 * 1024 * 1024


def excluded(rel: str) -> bool:
    parts = rel.split("/")
    return (bool(EXCLUDE_DIRS & set(parts)) or any(fnmatch.fnmatch(parts[-1], g) for g in EXCLUDE_GLOBS)
            or any(fnmatch.fnmatch(rel, g) for g in EXCLUDE_FILES))


def release_files() -> list[Path]:
    out = [ROOT / f for f in TOP_FILES if (ROOT / f).exists()]
    for d in TOP_DIRS:
        for p in sorted((ROOT / d).rglob("*")):
            if p.is_file() and not excluded(p.relative_to(ROOT).as_posix()):
                out.append(p)
    return out


def _match(k: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(k, p) for p in patterns)


def fig3_envelope_arrays(z) -> dict:
    """Median |SOC error| envelope of article Fig. 3(b) from the 1 s trajectories (same code as the figure)."""
    import importlib.util
    import json
    spec = importlib.util.spec_from_file_location("paper_figures", ROOT / "scripts" / "10_paper_figures.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    with open(ROOT / "results" / "validation_main.json", encoding="utf-8") as fh:
        files = [f["file"] for f in json.load(fh)["files"]]
    t, med = mod.fig3_envelope(z, files)
    out = {f"{mod.ENV3_KEY}|t": t}
    out.update({f"{mod.ENV3_KEY}|med|{m}": v for m, v in med.items()})
    return out


def strip_npz(src: Path, dst: Path, rel: str) -> tuple[int, int, int]:
    """Copy an archive without the measured channels and the current-derived model outputs, with the SOC
    trajectories decimated to DECIMATE_STEP samples (see the module docstring)."""
    z = np.load(src, allow_pickle=False)
    drop = MEASURED.get(rel, []) + DERIVED_DROP.get(rel, [])
    dec = DECIMATE.get(rel, [])
    keep, n_dec = {}, 0
    for k in z.files:
        if _match(k, drop):
            continue
        if dec and _match(k, dec):
            keep[k] = z[k][::DECIMATE_STEP]
            n_dec += 1
        else:
            keep[k] = z[k]
    if rel == "results/validation_series.npz":
        keep.update(fig3_envelope_arrays(z))
    np.savez_compressed(dst, **keep)
    return len(z.files), len(keep), n_dec


def drop_json_list(q: Path, key: str) -> int:
    """Remove the list-valued entry `key` (e.g. "zref": [...]) from a JSON file written with indent=1, as text."""
    s = q.read_text(encoding="utf-8")
    pat = re.compile(r"\n[ ]*" + re.escape(key) + r": \[[^\[\]]*\],?")
    s2, n = pat.subn("", s)
    if n:
        q.write_text(s2, encoding="utf-8", newline="")
    return n


def redraw_soc_figures(dst: Path) -> None:
    """Redraw fig_soc_test.pdf (09_figures_tables, fig:soc) and paper_fig3_soc.pdf in the copy from its archives."""
    import subprocess
    code = ("import importlib.util, sys; sys.argv = ['09']; "
            "s = importlib.util.spec_from_file_location('f09', 'scripts/09_figures_tables.py'); "
            "m = importlib.util.module_from_spec(s); s.loader.exec_module(m); "
            "[r[2]() for r in m.FIGURES if r[0] == 'fig:soc']")
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")          # no __pycache__ in the copy
    subprocess.run([sys.executable, "-c", code], cwd=dst, check=True, env=env)
    subprocess.run([sys.executable, "scripts/10_paper_figures.py", "--only", "3"], cwd=dst, check=True, env=env)


def sanitise(q: Path) -> int:
    """Replace absolute Windows user/CI paths (e.g. numpy build metadata in results/machine.json) in a text file."""
    if q.suffix.lower() not in TEXT_EXT:
        return 0
    try:
        s = q.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return 0
    n, s2 = 0, s
    for r in (str(ROOT).replace("\\", "\\\\"), str(ROOT), ROOT.as_posix()):   # project root (JSON-escaped first)
        n += s2.count(r)
        s2 = s2.replace(r, ".")
    s2, k = ABS_PATH.subn("<absolute path removed>", s2)
    n += k
    if n:
        q.write_text(s2, encoding="utf-8", newline="")
    return n


def scrub_pdf(q: Path) -> int:
    """Remove the pdfTeX /PTEX.* keys (they record the absolute path of every included PDF figure) from a PDF."""
    if q.suffix.lower() != ".pdf" or b"PTEX." not in q.read_bytes():
        return 0
    import fitz                                  # PyMuPDF (requirements.txt)
    d, n = fitz.open(q), 0
    for x in range(1, d.xref_length()):
        try:
            keys = d.xref_get_keys(x)
        except Exception:
            continue
        for k in keys:
            if k.startswith("PTEX."):
                d.xref_set_key(x, k, "null")
                n += 1
    tmp = q.with_name(q.name + ".scrub")
    d.save(tmp, garbage=3, deflate=True)
    d.close()
    tmp.replace(q)
    return n


def prepare_out(dst: Path) -> bool:
    """Empty the output folder (keeping a .git folder) if it is new, empty or a previous release copy."""
    bad = [ROOT / d for d in TOP_DIRS] + [ROOT / d for d in ("dataset", "data_raw", "data_processed", "src")]
    if dst == ROOT or dst in ROOT.parents or any(dst == b or b in dst.parents for b in bad):
        print(f"refusing to write the release into {dst}")
        return False
    if dst.exists() and any(dst.iterdir()) and not (dst / "RELEASE_MANIFEST.txt").exists():
        print(f"{dst} is not empty and is not a previous release copy (no RELEASE_MANIFEST.txt); stop")
        return False
    dst.mkdir(parents=True, exist_ok=True)
    for p in dst.iterdir():
        if p.name == ".git":
            continue
        shutil.rmtree(p, onexc=_keep_locked_dir) if p.is_dir() else p.unlink()
    return True


def _keep_locked_dir(func, path, exc) -> None:
    """rmtree error handler: leave an (emptied) directory that the OS refuses to remove (e.g. held open by a
    synchronisation client on Windows); files are still deleted and the copy refills the directory."""
    if func is os.rmdir and isinstance(exc, PermissionError):
        return
    raise exc


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", default=None, help="copy the release files to this directory (e.g. github)")
    ap.add_argument("--keep-measured", action="store_true",
                    help="copy the archives with measured channels unchanged (default: strip them)")
    ap.add_argument("--strip-measured", action="store_true", help="(default; kept for compatibility)")
    a = ap.parse_args()
    files = release_files()
    repo = sorted(p for p in REPO_FILES.iterdir() if p.is_file()) if REPO_FILES.exists() else []
    strip = not a.keep_measured
    lines = ["# Release file list (generated by scripts/make_release.py). Excluded directories: "
             + ", ".join(sorted(EXCLUDE_DIRS)) + "; manuscript sources and PDFs; files: " + ", ".join(EXCLUDE_FILES)
             + "; patterns: " + ", ".join(EXCLUDE_GLOBS) + ".",
             "# Measured CALCE channels " + ("removed from: " if strip else "KEPT in: ") + ", ".join(MEASURED)
             + (f"; current-derived model outputs dropped and SOC trajectories on a {DECIMATE_STEP} s grid; "
                "robustness.json figure.traj.zref removed; " + ", ".join(REDRAW) + " redrawn from the 60 s grid"
                if strip else "") + " (sizes below are those of the project copies).",
             "# Repository files from release_files/: " + ", ".join(p.name for p in repo)]
    lines += [f"{p.relative_to(ROOT).as_posix()}\t{p.stat().st_size}" for p in files if p.name != "RELEASE_MANIFEST.txt"]
    (ROOT / "RELEASE_MANIFEST.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    files = release_files()
    print(f"RELEASE_MANIFEST.txt: {len(files) + len(repo)} files, "
          f"{sum(p.stat().st_size for p in files + repo) / 1e6:.1f} MB before stripping")
    if not a.out:
        return 0
    dst_root = Path(a.out)
    dst_root = (dst_root if dst_root.is_absolute() else ROOT / dst_root).resolve()
    if not prepare_out(dst_root):
        return 1
    n_sub = 0
    for p in files:
        rel = p.relative_to(ROOT).as_posix()
        q = dst_root / rel
        q.parent.mkdir(parents=True, exist_ok=True)
        if strip and rel in MEASURED:
            n0, n1, nd = strip_npz(p, q, rel)
            print(f"stripped {rel}: {n0} -> {n1} arrays ({nd} SOC trajectories on a {DECIMATE_STEP} s grid)")
        else:
            shutil.copy2(p, q)
            if strip and rel in JSON_DROP:
                print(f"{rel}: removed {drop_json_list(q, JSON_DROP[rel])} x {JSON_DROP[rel]} (figure trajectory)")
    for p in repo:
        shutil.copy2(p, dst_root / p.name)
    if strip:
        redraw_soc_figures(dst_root)
        print("redrawn from the 60 s SOC trajectories:", ", ".join(REDRAW))
    for q in dst_root.rglob("*"):
        if q.is_file() and ".git" not in q.relative_to(dst_root).parts:
            n_sub += sanitise(q)
            n_sub += scrub_pdf(q)
    big = [q for q in dst_root.rglob("*") if q.is_file() and q.stat().st_size > MAX_BYTES]
    tot = sum(q.stat().st_size for q in dst_root.rglob("*") if q.is_file() and ".git" not in q.parts)
    print(f"copied to {dst_root}: {sum(1 for q in dst_root.rglob('*') if q.is_file() and '.git' not in q.parts)} files, "
          f"{tot / 1e6:.1f} MB; absolute paths replaced (text files, PDF /PTEX keys): {n_sub}; files > 50 MB: {len(big)}")
    return 1 if big else 0


if __name__ == "__main__":
    sys.exit(main())
