"""P2: observer design sets, structure selection, equal-budget tuning and the freeze of every hyper-parameter.

Validation files only (splits.validation_dynamic = SP2_*_DST_50SOC, loaded through experiments.load_case with its
validation-only guard; every file passes data.verify_file).  Settings: config.yaml `design_tuning` (declared before
the first run), `estimators`, `validation`.  Parameter sets: results/identification_memory.json (TFO_grid / FO_trunc
rows, parameter set causal_full) and results/identification_refined.json chosen_parameter_sets (2RC).

Stages
------
1. Design sets per temperature and candidate (lambda, L): slope bounds kappa1/kappa2 of the candidate's own aligned
   OCV on the admissible reference-SOC interval mapped to the observer axis (and on the clip range), the certified
   (l1, l2) set at sigma = 0, the default LMI design (tempered.design_gains via observer.design_observer_gains)
   with an independent LMI audit (solver status, margin, a-posteriori eigenvalues), sigma*, the memory rule
   L_z*(eps_z) of cor:m4b:memory and the untempered requirement.
2. Structure selection (pre-declared rule, design gains): proposed (lambda*, L*), TFO (lambda > 0), FOO (lambda = 0),
   FOEKF memory, for L_budget = 400 s (primary) and 3200 s (secondary).
3. Equal-budget tuning (80 objective evaluations per method and temperature: default + 63 Sobol + 16 (1+1)-ES) of
   TFO, FOO, FOEKF, EKF2RC, AEKF2RC; CC evaluated.  Supplementary: TFO/FOO gains tuned for every (lambda, L <= 3200).
4. Post-analysis of the tuned TFO/FOO (certificate, LMI, sigma*, truncation bounds, ablation horizons) and the freeze:
   results/gain_design.json, results/tuning.json, results/frozen_config.json, tables/tab_hyper.tex,
   reports/tuning_findings.md, figures/draft_p2_*.pdf.

Usage: python scripts/05_design_tune.py [--report-only]
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import json
import math
import sys
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import experiments as E  # noqa: E402
from tfso import metrics as MX  # noqa: E402
from tfso import model as MD  # noqa: E402
from tfso import observer as O  # noqa: E402
from tfso import tempered as TM  # noqa: E402

RES = ROOT / "results"
TEMPS = (0, 25, 45)
METHOD_INDEX = {"TFO": 1, "FOO": 2, "FOEKF": 3, "EKF2RC": 4, "AEKF2RC": 5, "CC": 6}
TASK_VERSION = "P2-2026-09-27-a"


# ---------------------------------------------------------------------------------------------------------------
# Configuration and inputs
# ---------------------------------------------------------------------------------------------------------------
def cfg():
    c = D.load_config()
    return c, dict(c["design_tuning"]), dict(c["estimators"])


def load_json(name):
    with open(RES / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def code_hash() -> str:
    c, dt, est = cfg()
    h = hashlib.sha256()
    h.update(json.dumps([dt, est, c["validation"]], sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("scripts/05_design_tune.py", "src/tfso/observer.py", "src/tfso/benchmarks.py", "src/tfso/tempered.py",
              "src/tfso/experiments.py", "src/tfso/metrics.py", "results/identification_memory.json",
              "results/identification_refined.json", "results/capacity.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def admissible_obs_interval(T):
    """Admissible reference-SOC interval mapped to the observer axis: z = 1 - (1 - z_ref) Q_ref(T)/Q_id(T)."""
    _, dt, _ = cfg()
    cap = load_json("capacity.json")
    Qref = float(cap["Q_ref_T_SP2"][str(T)]["Q_ref_Ah"])
    Qid = E.q_id(T)
    lo, hi = dt["admissible_soc_interval"]
    return (1.0 - (1.0 - lo) * Qref / Qid, 1.0 - (1.0 - hi) * Qref / Qid), Qref, Qid


def memory_row(T, lam, L):
    """Row of identification_memory.json: FO_trunc for lambda = 0, TFO_grid(lambda) otherwise; L int or 'full'."""
    rows = load_json("identification_memory.json")["per_T"][str(T)]["rows"]
    for r in rows:
        if r["L"] != L:
            continue
        if lam == 0.0 and r["config"] == "FO_trunc":
            return r
        if lam > 0.0 and r["config"] == "TFO_grid" and abs(float(r["lam_fixed"]) - lam) <= 1e-12 * lam:
            return r
    raise KeyError((T, lam, L))


def row_id(T, lam, L):
    cfgname = "FO_trunc" if lam == 0.0 else "TFO_grid"
    return f"identification_memory.json:per_T[{T}].rows[config={cfgname}, lam_fixed={lam:g}, L={L}]"


def params_from_row(r, T):
    p = dict(r["theta"])
    p.update(Qn=E.q_id(T), eta=float(D.load_config()["dataset"]["coulombic_efficiency"]))
    return p


def params_2rc(T):
    p = dict(load_json("identification_refined.json")["chosen_parameter_sets"][str(T)]["2RC"])
    p.update(Qn=E.q_id(T), eta=float(D.load_config()["dataset"]["coulombic_efficiency"]))
    return p


_OCV = {}
_CASES = {}


def aligned_ocv(T):
    if T not in _OCV:
        _OCV[T] = MD.AlignedOCV(T, E.q_id(T))
    return _OCV[T]


def fast_ocv(T, p):
    return O.as_fast_ocv(aligned_ocv(T), s=p["s"], dq=p["dq"])


def val_case(T):
    if T not in _CASES:
        lid = f"SP2_{T}C_DST_50SOC"
        assert lid in D.load_config()["splits"]["validation_dynamic"]
        c = E.load_case(lid)            # validation-only guard; data.verify_file inside
        if not c.meta["verify_passed"]:
            raise RuntimeError(f"{lid} failed data.verify_file")
        _CASES[T] = c
    return _CASES[T]


def ap_of(p):
    return 1.0 / (float(p["Rp"]) * float(p["Cp"]))


# ---------------------------------------------------------------------------------------------------------------
# Metric and one evaluation (three initial-SOC scenarios)
# ---------------------------------------------------------------------------------------------------------------
def admissible_metrics(t, zhat, zref):
    _, dt, est = cfg()
    lo, hi = dt["admissible_soc_interval"]
    tpost = float(est["post_convergence_t_s"])
    e = np.asarray(zhat, float) - np.asarray(zref, float)
    post = (t - t[0]) >= tpost
    adm = (zref >= lo) & (zref <= hi)
    m = post & adm
    out = {}
    for key, mask in (("adm", m), ("adm_all_t", adm)):
        ee = e[mask]
        if ee.size == 0 or not np.all(np.isfinite(ee)):
            out[f"{key}_rmse_pct"] = float("inf")
            continue
        out[f"{key}_rmse_pct"] = float(100 * np.sqrt(np.mean(ee * ee)))
        if key == "adm":
            out["adm_maxabs_pct"] = float(100 * np.max(np.abs(ee)))
            for b in est["within_bands"]:
                out[f"adm_within{int(round(100 * b))}_pct"] = float(100 * np.mean(np.abs(ee) <= b))
            out["adm_n"] = int(ee.size)
    return out


def evaluate(method, params, hyper, T):
    """Mean over the scenarios of the admissible post-convergence RMSE (+ per-scenario records)."""
    _, dt, _ = cfg()
    case = val_case(T)
    focv = fast_ocv(T, params) if method != "CC" else None
    per = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        for sc in dt["scenarios"]:
            rec = E.run_case(method, params, hyper, case, z0_scenario=sc, ocv=focv, keep_series=True)
            s = rec.pop("_series")
            am = admissible_metrics(case.t, s["zhat"], s["zref"])
            per[sc] = dict(am, post_rmse_pct=rec["post_rmse_pct"], rmse_pct=rec["rmse_pct"],
                           conv_time_s=rec["conv_time_s"], vt_rmse_mV=rec["vt_rmse_mV"],
                           soc_clip_count=rec["soc_clip_count"], positivity_ok_clip=rec["positivity_ok"],
                           z0=rec["z0"], wall_s=rec["wall_s"])
    vals = [per[sc]["adm_rmse_pct"] for sc in dt["scenarios"]]
    obj = float(np.mean(vals)) if all(np.isfinite(vals)) else float("inf")
    whole = [per[sc]["post_rmse_pct"] for sc in dt["scenarios"]]
    return dict(objective=obj, whole_post_rmse_pct=float(np.mean(whole)) if all(np.isfinite(whole)) else float("inf"),
                per_scenario=per)


# ---------------------------------------------------------------------------------------------------------------
# Certificate, LMI audit, memory rule
# ---------------------------------------------------------------------------------------------------------------
def kappas(T, p):
    (zlo, zhi), _, _ = admissible_obs_interval(T)
    f = fast_ocv(T, p)
    k1, k2 = O.slope_bounds_fast(f, zlo, zhi, n=int(cfg()[1]["kappa_grid_n"]))
    c1, c2 = O.slope_bounds_fast(f, *O.SOC_CLIP, n=int(cfg()[1]["kappa_grid_n"]))
    return dict(z_interval_obs=[zlo, zhi], kappa1=k1, kappa2=k2, kappa1_clip=c1, kappa2_clip=c2,
                clip_range=list(O.SOC_CLIP))


def envelope_kappa(T):
    """kappa1 envelope min / kappa2 envelope max of reports/ocv_findings (results/ocv_fits.json, interval [0.10,0.95])."""
    for iv in load_json("ocv_fits.json")["selected"]["per_temperature"][str(T)]["intervals"]:
        if iv["label"] == "[0.10,0.95]":
            return float(iv["kappa1_envelope_min_V_per_soc"]), float(iv["kappa2_envelope_max_V_per_soc"])
    raise KeyError(T)


def certified_set(alpha, lam, ap, k1, k2, h, N_L):
    """Certified (l1, l2) set at sigma = 0: 0 < l1 <= 1/(h k2), 0 <= l2 < k1 (ap + mu_{h,L}(0))/(k2 - k1)."""
    mu0 = TM.mu_hL(alpha, lam, 0.0, h, N_L)
    return dict(mu_hL0=mu0, l1_max=1.0 / (h * k2), l2_sup=k1 * (ap + mu0) / (k2 - k1))


def dc_explicit(alpha, lam, ap, k1, k2, l1, l2, sigma, h, N_L):
    """Explicit (DC) margin (l1 k1 - sigma_h)(ap + l2 + mu) - l1 l2 k2 and positivity."""
    sh = TM.sigma_h(sigma, h)
    mu = TM.mu_hL(alpha, lam, sigma, h, N_L)
    m1 = l1 * k1 - sh
    return dict(margin=float(m1 * (ap + l2 + mu) - l1 * l2 * k2), m1=float(m1), positivity=bool(h * l1 * k2 <= 1.0),
                ok=bool(m1 > 0 and m1 * (ap + l2 + mu) > l1 * l2 * k2 and h * l1 * k2 <= 1.0))


def lmi_fixed_gains(M, strict_tol):
    """Diagonal Lyapunov LMI for a FIXED comparison matrix: max t s.t. He(P M) <= -t I, p1 + p2 = 1 (Clarabel).
    Returns status, t*, P and the a-posteriori max eigenvalue of He(P M)."""
    import cvxpy as cp
    p = cp.Variable(2)
    t = cp.Variable()
    He = cp.bmat([[2 * M[0, 0] * p[0], M[0, 1] * p[0] + M[1, 0] * p[1]],
                  [M[0, 1] * p[0] + M[1, 0] * p[1], 2 * M[1, 1] * p[1]]])
    prob = cp.Problem(cp.Maximize(t), [He + t * np.eye(2) << 0, p >= 1e-9, cp.sum(p) == 1, t <= 10.0])
    try:
        prob.solve(solver=cp.CLARABEL)
    except Exception as exc:  # pragma: no cover
        return dict(status=f"error: {exc}", t=None, P=None, max_eig=None, strict_ok=False)
    if p.value is None:
        return dict(status=str(prob.status), t=None, P=None, max_eig=None, strict_ok=False)
    P = np.diag(np.asarray(p.value, float))
    ev = float(np.max(np.linalg.eigvalsh(P @ M + M.T @ P)))
    return dict(status=str(prob.status), t=float(t.value), P=[float(P[0, 0]), float(P[1, 1])], max_eig=ev,
                strict_ok=bool(ev <= -strict_tol))


def lmi_design_audit(alpha, lam, ap, k1, k2, h, N_L, l1max, l2max, sigma, strict_tol):
    """Re-solve the design LMI of tempered._lmi_margin at sigma (status, margin, recovered gains) and verify the
    strict inequality a posteriori with the recovered P and gains."""
    import cvxpy as cp
    S, mu = TM.sigma_h(sigma, h), TM.mu_hL(alpha, lam, sigma, h, N_L)
    p, y, t = cp.Variable(2), cp.Variable(2), cp.Variable()
    L11, L12, L22 = 2 * (S * p[0] - k1 * y[0]), y[0] + k2 * y[1], -2 * ((ap + mu) * p[1] + y[1])
    cons = [cp.bmat([[L11 + t, L12], [L12, L22 + t]]) << 0, p >= 1e-9, cp.sum(p) == 1, y[0] >= 0,
            y[0] <= l1max * p[0], y[1] >= 0, y[1] <= l2max * p[1], t <= 10.0, h * k2 * y[0] <= p[0]]
    prob = cp.Problem(cp.Maximize(t), cons)
    prob.solve(solver=cp.CLARABEL)
    if p.value is None:
        return dict(status=str(prob.status), sigma=sigma)
    pv, yv = np.asarray(p.value), np.asarray(y.value)
    l1, l2 = float(yv[0] / pv[0]), float(max(yv[1], 0.0) / pv[1])
    M = TM.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, sigma, h=h, N_L=N_L)
    P = np.diag(pv)
    ev = float(np.max(np.linalg.eigvalsh(P @ M + M.T @ P)))
    return dict(status=str(prob.status), sigma=float(sigma), t=float(t.value), l1=l1, l2=l2, P=[float(v) for v in pv],
                max_eig_He=ev, strict_ok=bool(ev <= -strict_tol), solver_stats=dict(
                    solve_time_s=getattr(prob.solver_stats, "solve_time", None),
                    iters=getattr(prob.solver_stats, "num_iters", None)))


def log10_untempered_horizon(gamma0, Bp, eps, alpha):
    """log10 of (gamma0 B_p/(eps Gamma(2-alpha)))^(1/alpha) (cor:m4b:memory (iii)); overflow-safe."""
    return (math.log10(gamma0 * Bp / (eps * math.gamma(2.0 - alpha)))) / alpha


def truncation_soc_bounds(alpha, lam, ap, k1, k2, l2, h, N_L, Bp):
    """Truncation-induced ultimate SOC error bounds at memory N_L [SOC fraction]:
    (i) gamma_zp^(h,L) x exact discrete worst case of |R_L| (valid for every lambda >= 0);
    (ii) gamma_zp^(h) x Gamma-form bound (lambda > 0) or gamma_zp^0 x untempered bound (lambda = 0)."""
    out = {}
    try:
        g_hL = TM.soc_gain(alpha, lam, ap, k1, k2, l2, h=h, N_L=N_L)
    except ValueError:
        g_hL = float("nan")
    wc = TM.worst_case_remainder(alpha, lam, h, N_L, Bp)
    out.update(gamma_zp_hL=g_hL, RL_worst_exact=wc, ez_bound_exact=g_hL * wc)
    if lam > 0:
        try:
            g_h = TM.soc_gain(alpha, lam, ap, k1, k2, l2, h=h, N_L=None)
        except ValueError:
            g_h = float("nan")
        tb = float(TM.truncation_bound(alpha, lam, N_L * h, Bp, "gamma"))
        out.update(gamma_zp_h=g_h, RL_gamma_bound=tb, ez_bound_chain=g_h * tb)
    else:
        try:
            g0 = TM.soc_gain(alpha, 0.0, ap, k1, k2, l2)
        except ValueError:
            g0 = float("nan")
        tb = float(TM.untempered_truncation_bound(alpha, N_L * h, Bp))
        out.update(gamma_zp_0=g0, RL_untempered_bound=tb, ez_bound_chain=g0 * tb)
    return out


def memory_requirement(alpha, lam, ap, k1, k2, l2, h, Bp, eps_list):
    """L_z*(eps_z) of cor:m4b:memory (ii) for lambda > 0 (min(L*, L_b*) and L_Gamma*), untempered (iii) for 0."""
    out = []
    for eps in eps_list:
        if lam > 0:
            try:
                g_h = TM.soc_gain(alpha, lam, ap, k1, k2, l2, h=h, N_L=None)
            except ValueError:
                out.append(dict(eps_z=eps, defined=False))
                continue
            mr = TM.memory_rule(alpha, lam, Bp, eps / g_h, form="rule", h=h)
            L = float(mr["L_rule"])
            chk = truncation_soc_bounds(alpha, lam, ap, k1, k2, l2, h, int(math.ceil(L / h - 1e-12)), Bp)
            out.append(dict(eps_z=eps, defined=True, gamma_zp_h=g_h, eps_p=eps / g_h, L_z_star_s=L,
                            L_Gamma_star_s=float(mr["L_Gamma_star"]), N_L=int(math.ceil(L / h - 1e-12)),
                            log10_L_untempered_same_alpha=log10_untempered_horizon(
                                TM.soc_gain(alpha, 0.0, ap, k1, k2, l2), Bp, eps, alpha)
                            if k1 * (ap + l2) > l2 * k2 else None,
                            check_ez_exact_at_L=chk["ez_bound_exact"], check_ok=bool(chk["ez_bound_exact"] <= eps)))
        else:
            if not k1 * (ap + l2) > l2 * k2:
                out.append(dict(eps_z=eps, defined=False))
                continue
            g0 = TM.soc_gain(alpha, 0.0, ap, k1, k2, l2)
            out.append(dict(eps_z=eps, defined=True, gamma_zp_0=g0,
                            log10_L_untempered_s=log10_untempered_horizon(g0, Bp, eps, alpha)))
    return out


# ---------------------------------------------------------------------------------------------------------------
# Stage 1-2: design sets and structure-selection evaluations (design gains, no tuning)
# ---------------------------------------------------------------------------------------------------------------
def design_task(args):
    """One (T, lambda, L) candidate: slope bounds, certified set, default LMI design + audit, certificate checks,
    memory requirement, validation objective with the design gains."""
    T, lam, L = args
    c, dt, est = cfg()
    h = float(dt["h_s"])
    tol = float(dt["lmi"]["strict_tol"])
    t0w, t0c = time.perf_counter(), time.process_time()
    r = memory_row(T, lam, L)
    p = params_from_row(r, T)
    alpha, ap = float(p["alpha"]), ap_of(p)
    N_L = None if L == "full" else int(math.ceil(float(L) / h - 1e-9))
    kap = kappas(T, p)
    k1, k2 = kap["kappa1"], kap["kappa2"]
    cs = certified_set(alpha, lam, ap, k1, k2, h, N_L)
    dflt = dict(est["defaults"]["TFO"])
    focv = fast_ocv(T, p)
    g = O.design_observer_gains(p, focv, h, N_L, z_interval=tuple(kap["z_interval_obs"]), lam_override=lam,
                                l1max=dflt.get("l1max"), l2max=float(dflt["l2max"]), margin=float(dflt["margin"]),
                                tau_z_min=dflt.get("tau_z_min"), l2min=float(dflt["l2min"]))
    out = dict(T=T, lam=lam, L=L, N_L=N_L, row=row_id(T, lam, L), alpha=alpha, a_p=ap, b_p=1.0 / float(p["Cp"]),
               R0=float(p["R0"]), Rp=float(p["Rp"]), Cp=float(p["Cp"]), s=float(p["s"]), dq=float(p["dq"]),
               B_p_V=float(r["bounds"]["B_p_V"]) if r.get("bounds") else None,
               row_at_bound=r.get("at_bound"), kappa=kap, certified_set=cs)
    if g["l1"] is None:
        out.update(design=dict(feasible=False), certified=False, objective=float("inf"))
        return out
    l1, l2 = float(g["l1"]), float(g["l2"])
    l1m = g["design"]["l1max_eff"]
    # independent audit of the LMI at the design rate (before any l2 floor) and a-posteriori checks of the final gains
    sig_lmi = TM.design_gains(alpha, lam, ap, k1, k2, h=h, N_L=N_L, l1max=l1m, l2max=float(dflt["l2max"]),
                              margin=float(dflt["margin"]))
    audit = lmi_design_audit(alpha, lam, ap, k1, k2, h, N_L, l1m, float(dflt["l2max"]),
                             float(sig_lmi["sigma_cert"]) if sig_lmi else 0.0, tol)
    cert0 = TM.certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
    sstar = TM.sigma_star(alpha, lam, ap, k1, k2, l1, l2, h=h, N_L=N_L)
    M0 = TM.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, 0.0, h=h, N_L=N_L)
    fix0 = lmi_fixed_gains(M0, tol)
    fixs = None
    if sstar is not None and sstar > 0:
        fixs = lmi_fixed_gains(TM.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, 0.9 * sstar, h=h, N_L=N_L), tol)
    dce = dc_explicit(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
    certified = bool(cert0.certified and cert0.lp and dce["ok"])
    out["design"] = dict(feasible=True, l1=l1, l2=l2, l1max_eff=l1m, sigma_design=g["sigma_cert"],
                         l2_raised_to_l2min=bool(g["design"].get("l2_raised_to_l2min", False)),
                         lmi_sigma_cert=float(sig_lmi["sigma_cert"]) if sig_lmi else None,
                         lmi_l1=float(sig_lmi["l1"]) if sig_lmi else None,
                         lmi_l2=float(sig_lmi["l2"]) if sig_lmi else None, lmi_audit=audit)
    out.update(certified=certified, dc_sigma0=dict(explicit=cert0.explicit, lp=cert0.lp, lp_margin=cert0.lp_margin,
                                                   positivity=cert0.positivity, explicit_margin=dce["margin"]),
               sigma_star=sstar, lmi_fixed_sigma0=fix0, lmi_fixed_0p9_sigma_star=fixs,
               h_l1_kappa2=h * l1 * k2, h_l1_kappa2_clip=h * l1 * kap["kappa2_clip"])
    if out["B_p_V"] is not None:
        out["memory_requirement_design_l2"] = memory_requirement(alpha, lam, ap, k1, k2, l2, h, out["B_p_V"],
                                                                 dt["eps_z"])
        if N_L is not None:
            out["truncation_soc_bound_design_l2"] = truncation_soc_bounds(alpha, lam, ap, k1, k2, l2, h, N_L,
                                                                          out["B_p_V"])
    hyper = dict(l1=l1, l2=l2, L_s=None if L == "full" else float(L), z_interval=kap["z_interval_obs"])
    ev = evaluate("FOO" if lam == 0.0 else "TFO", p, hyper, T)
    out.update(objective=ev["objective"], whole_post_rmse_pct=ev["whole_post_rmse_pct"],
               per_scenario=ev["per_scenario"], wall_s=time.perf_counter() - t0w, process_s=time.process_time() - t0c)
    return out


def foekf_default_task(args):
    T, L = args
    c, dt, est = cfg()
    r = memory_row(T, 0.0, L)
    p = params_from_row(r, T)
    hyper = E.default_hyper("FOEKF", float(dt["h_s"]))
    hyper["L_s"] = None if L == "full" else float(L)
    ev = evaluate("FOEKF", p, hyper, T)
    return dict(T=T, L=L, row=row_id(T, 0.0, L), objective=ev["objective"],
                whole_post_rmse_pct=ev["whole_post_rmse_pct"], per_scenario=ev["per_scenario"])


def select_structure(cands, lam_set, budget, tie_tol):
    """Pre-declared rule on mean-over-T objectives: candidates (lam, L) with L <= budget, certified at every T;
    ties within tie_tol of the minimum -> smallest L, then lower objective."""
    table = {}
    for (lam, L), per_T in cands.items():
        if lam not in lam_set or L == "full" or L > budget:
            continue
        ok = all(per_T[T].get("certified", True) for T in TEMPS)
        objs = [per_T[T]["objective"] for T in TEMPS]
        table[(lam, L)] = dict(lam=lam, L=L, certified_all_T=ok, mean_objective=float(np.mean(objs)),
                               per_T_objective=objs)
    elig = [v for v in table.values() if v["certified_all_T"] and np.isfinite(v["mean_objective"])]
    if not elig:
        return dict(winner=None, candidates=list(table.values()))
    best = min(v["mean_objective"] for v in elig)
    tied = [v for v in elig if v["mean_objective"] <= best + tie_tol]
    win = sorted(tied, key=lambda v: (v["L"], v["mean_objective"]))[0]
    return dict(winner=dict(lam=win["lam"], L=win["L"], mean_objective=win["mean_objective"]),
                best_objective=best, tied=[(v["lam"], v["L"], v["mean_objective"]) for v in tied],
                candidates=sorted(table.values(), key=lambda v: v["mean_objective"]))


# ---------------------------------------------------------------------------------------------------------------
# Stage 3: equal-budget tuning
# ---------------------------------------------------------------------------------------------------------------
KF_DIMS = {"FOEKF": ["q_z", "q_Vp", "R", "p_z", "p_Vp"],
           "EKF2RC": ["q_z", "q_V1", "q_V2", "R", "p_z", "p_V1", "p_V2"],
           "AEKF2RC": ["q_z", "q_V1", "q_V2", "R", "p_z", "p_V1", "p_V2", "one_minus_b"]}


def method_space(method, T, lam=None, L=None):
    """Search space (log10 box), parameter set, fixed hyper-parameters and the default point for one tuning task."""
    c, dt, est = cfg()
    h = float(dt["h_s"])
    tb = dt["tuning"]
    if method in ("TFO", "FOO"):
        r = memory_row(T, lam, L)
        p = params_from_row(r, T)
        N_L = int(math.ceil(float(L) / h - 1e-9))
        kap = kappas(T, p)
        cs = certified_set(float(p["alpha"]), lam, ap_of(p), kap["kappa1"], kap["kappa2"], h, N_L)
        dims = [("l1", math.log10(1e-5), math.log10(cs["l1_max"])),
                ("l2", math.log10(1e-4), math.log10(0.99 * cs["l2_sup"]))]
        fixed = dict(L_s=float(L), z_interval=kap["z_interval_obs"])
        return dict(dims=dims, params=p, fixed=fixed, row=row_id(T, lam, L), kappa=kap, certified_set=cs, N_L=N_L)
    if method == "FOEKF":
        r = memory_row(T, 0.0, L)
        p = params_from_row(r, T)
        box = tb["boxes"]["FOEKF"]
        dims = [(k, float(box[k][0]), float(box[k][1])) for k in KF_DIMS["FOEKF"]]
        fixed = dict(L_s=float(L), **tb["fixed"]["FOEKF"])
        return dict(dims=dims, params=p, fixed=fixed, row=row_id(T, 0.0, L))
    if method in ("EKF2RC", "AEKF2RC"):
        p = params_2rc(T)
        box = tb["boxes"][method]
        dims = [(k, float(box[k][0]), float(box[k][1])) for k in KF_DIMS[method]]
        fixed = dict(tb["fixed"].get(method, {}))
        return dict(dims=dims, params=p, fixed=fixed, row=f"identification_refined.json:chosen_parameter_sets[{T}][2RC]")
    raise ValueError(method)


def to_hyper(method, sp, x):
    v = {d[0]: 10.0 ** (d[1] + float(xi) * (d[2] - d[1])) for d, xi in zip(sp["dims"], x)}
    hy = dict(sp["fixed"])
    if method in ("TFO", "FOO"):
        hy.update(l1=v["l1"], l2=v["l2"])
    elif method == "FOEKF":
        hy.update(Q=[v["q_z"], v["q_Vp"]], R=v["R"], P0=[v["p_z"], v["p_Vp"]])
    else:
        hy.update(Q=[v["q_z"], v["q_V1"], v["q_V2"]], R=v["R"], P0=[v["p_z"], v["p_V1"], v["p_V2"]])
        if method == "AEKF2RC":
            hy["b"] = 1.0 - v["one_minus_b"]
    return hy, v


def default_unit(method, sp, design_gains=None):
    """Default point in unit coordinates (TFO/FOO: the default LMI design gains; KF: estimators.defaults), clipped."""
    d = E.default_hyper(method, float(cfg()[1]["h_s"])) if method not in ("TFO", "FOO") else {}
    if method in ("TFO", "FOO"):
        val = dict(l1=design_gains[0], l2=design_gains[1])
    elif method == "FOEKF":
        val = dict(q_z=d["Q"][0], q_Vp=d["Q"][1], R=d["R"], p_z=d["P0"][0], p_Vp=d["P0"][1])
    else:
        val = dict(q_z=d["Q"][0], q_V1=d["Q"][1], q_V2=d["Q"][2], R=d["R"], p_z=d["P0"][0], p_V1=d["P0"][1],
                   p_V2=d["P0"][2])
        if method == "AEKF2RC":
            val["one_minus_b"] = 1.0 - float(d["b"])
    x = [(math.log10(val[n]) - lo) / (hi - lo) for n, lo, hi in sp["dims"]]
    return [min(1.0, max(0.0, xi)) for xi in x]


def tune_task(args):
    """Equal-budget tuning of one method at one temperature: 1 default + n_sobol Sobol + n_local (1+1)-ES evaluations."""
    from scipy.stats import qmc
    method, T, lam, L, design_gains, tag = args
    c, dt, est = cfg()
    tb = dt["tuning"]
    t0w, t0c = time.perf_counter(), time.process_time()
    sp = method_space(method, T, lam, L)
    d = len(sp["dims"])
    seed = int(tb["seed"]) + 1000 * TEMPS.index(T) + 10 * METHOD_INDEX[method]
    sob = qmc.Sobol(d, scramble=True, seed=seed).random_base2(6)[: int(tb["n_sobol"])]
    X = [default_unit(method, sp, design_gains)] + [list(map(float, x)) for x in sob]
    trace = []

    def run(x, stage):
        hy, v = to_hyper(method, sp, x)
        ev = evaluate(method, sp["params"], hy, T)
        trace.append(dict(stage=stage, x=[float(xi) for xi in x], values=v, objective=ev["objective"],
                          whole_post_rmse_pct=ev["whole_post_rmse_pct"],
                          adm_rmse_by_scenario=[ev["per_scenario"][s]["adm_rmse_pct"] for s in dt["scenarios"]]))
        return ev["objective"]

    for i, x in enumerate(X):
        run(x, "default" if i == 0 else "sobol")
    fs = [tr["objective"] for tr in trace]
    ib = int(np.argmin(fs))
    xb, fb = list(trace[ib]["x"]), fs[ib]
    rng = np.random.default_rng(seed + 7)
    sig = float(tb["local_sigma0"])
    for _ in range(int(tb["n_local"])):
        xn = np.clip(np.asarray(xb) + sig * rng.standard_normal(d), 0.0, 1.0)
        fn = run(list(xn), "local")
        if fn < fb:
            xb, fb, sig = list(map(float, xn)), fn, sig * 1.5
        else:
            sig *= 0.7
    assert len(trace) == int(tb["budget_evals"])
    ib = int(np.argmin([tr["objective"] for tr in trace]))
    best = trace[ib]
    hy, v = to_hyper(method, sp, best["x"])
    tol = float(tb["at_bound_unit_tol"])
    at_bound = [n for (n, _, _), xi in zip(sp["dims"], best["x"]) if xi <= tol or xi >= 1.0 - tol]
    best_eval = evaluate(method, sp["params"], hy, T)
    return dict(method=method, T=T, lam=lam, L=L, tag=tag, row=sp["row"], seed=seed,
                dims=[dict(name=n, log10_lo=lo, log10_hi=hi) for n, lo, hi in sp["dims"]],
                n_evals=len(trace), best_index=ib, best_stage=best["stage"], best_objective=best["objective"],
                best_values=v, best_hyper=hy, at_bound=at_bound, default_objective=trace[0]["objective"],
                best_per_scenario=best_eval["per_scenario"], best_whole_post_rmse_pct=best_eval["whole_post_rmse_pct"],
                trace=trace, kappa=sp.get("kappa"), certified_set=sp.get("certified_set"),
                wall_s=time.perf_counter() - t0w, process_s=time.process_time() - t0c)


def cc_task(T):
    p = params_from_row(memory_row(T, 0.0, 400), T)
    ev = evaluate("CC", p, {}, T)
    return dict(method="CC", T=T, objective=ev["objective"], whole_post_rmse_pct=ev["whole_post_rmse_pct"],
                per_scenario=ev["per_scenario"])


def run_pool(fn, tasks, workers):
    if workers <= 1:
        return [fn(t) for t in tasks]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, tasks, chunksize=1))


# ---------------------------------------------------------------------------------------------------------------
# Stage 4: post-analysis of tuned TFO / FOO gains
# ---------------------------------------------------------------------------------------------------------------
def post_certificate(T, lam, L, l1, l2):
    c, dt, est = cfg()
    h = float(dt["h_s"])
    tol = float(dt["lmi"]["strict_tol"])
    r = memory_row(T, lam, L)
    p = params_from_row(r, T)
    alpha, ap = float(p["alpha"]), ap_of(p)
    N_L = int(math.ceil(float(L) / h - 1e-9))
    kap = kappas(T, p)
    k1, k2 = kap["kappa1"], kap["kappa2"]
    cert0 = TM.certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
    dce = dc_explicit(alpha, lam, ap, k1, k2, l1, l2, 0.0, h, N_L)
    sstar = TM.sigma_star(alpha, lam, ap, k1, k2, l1, l2, h=h, N_L=N_L)
    fix0 = lmi_fixed_gains(TM.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, 0.0, h=h, N_L=N_L), tol)
    fixs = lmi_fixed_gains(TM.comparison_matrix(alpha, lam, ap, k1, k2, l1, l2, 0.9 * sstar, h=h, N_L=N_L), tol) \
        if sstar else None
    cert_s = TM.certify_gains_discrete(alpha, lam, ap, k1, k2, l1, l2, sstar, h, N_L) if sstar else None
    # the clip-range certificate (reported, not required)
    cclip = TM.certify_gains_discrete(alpha, lam, ap, kap["kappa1_clip"], kap["kappa2_clip"], l1, l2, 0.0, h, N_L)
    # sensitivity: ocv_findings envelope (results/ocv_fits.json, interval [0.10,0.95] of the observer axis) widened
    # with the candidate's own bounds: kappa1_env = min(envelope min, kappa1), kappa2_env = max(envelope max, kappa2)
    ek1, ek2 = envelope_kappa(T)
    ek1, ek2 = min(ek1, k1), max(ek2, k2)
    cenv = TM.certify_gains_discrete(alpha, lam, ap, ek1, ek2, l1, l2, 0.0, h, N_L)
    senv = TM.sigma_star(alpha, lam, ap, ek1, ek2, l1, l2, h=h, N_L=N_L)
    Bp = float(r["bounds"]["B_p_V"])
    out = dict(T=T, lam=lam, L=L, N_L=N_L, row=row_id(T, lam, L), params={k: float(v) for k, v in p.items()},
               a_p=ap, b_p=1.0 / float(p["Cp"]), B_p_V=Bp, kappa=kap, l1=l1, l2=l2,
               certified_set=certified_set(alpha, lam, ap, k1, k2, h, N_L),
               dc_sigma0=dict(certified=cert0.certified, explicit=cert0.explicit, lp=cert0.lp,
                              lp_margin=cert0.lp_margin, positivity=cert0.positivity, explicit_margin=dce["margin"]),
               h_l1_kappa2=h * l1 * k2, h_l1_kappa2_clip=h * l1 * kap["kappa2_clip"],
               certified_on_clip_range=bool(cclip.certified),
               envelope_sensitivity=dict(kappa1=ek1, kappa2=ek2, certified=bool(cenv.certified), sigma_star=senv),
               sigma_star=sstar, dc_at_sigma_star=dict(certified=cert_s.certified, lp_margin=cert_s.lp_margin)
               if cert_s else None, lmi_fixed_sigma0=fix0, lmi_fixed_0p9_sigma_star=fixs,
               truncation_soc_bound=truncation_soc_bounds(alpha, lam, ap, k1, k2, l2, h, N_L, Bp),
               memory_requirement=memory_requirement(alpha, lam, ap, k1, k2, l2, h, Bp, dt["eps_z"]),
               bytes_state=TM.cost_per_sample(N_L)["bytes"], macs_per_sample=TM.cost_per_sample(N_L)["macs"])
    return out


def ablation_horizons(pc):
    """Certified finite memory L_cert = ceil(L_z*(eps_z_primary)) and a shorter uncertified L_short = floor(L_cert/10)
    for the frozen TFO parameters and gains (config design_tuning.ablation_memory)."""
    c, dt, est = cfg()
    h = float(dt["h_s"])
    eps = float(dt["eps_z_primary"])
    mr = [m for m in pc["memory_requirement"] if abs(m["eps_z"] - eps) < 1e-15][0]
    if pc["lam"] == 0.0 or not mr.get("defined"):
        return dict(defined=False, reason="lambda = 0 (untempered horizon) or gain undefined", memory_requirement=mr)
    Lc = float(math.ceil(mr["L_z_star_s"]))
    Ls = float(max(1.0, math.floor(Lc / 10.0)))
    p = pc["params"]
    alpha, lam, ap = p["alpha"], pc["lam"], pc["a_p"]
    k1, k2, l2 = pc["kappa"]["kappa1"], pc["kappa"]["kappa2"], pc["l2"]
    bc = truncation_soc_bounds(alpha, lam, ap, k1, k2, l2, h, int(Lc / h), pc["B_p_V"])
    bs = truncation_soc_bounds(alpha, lam, ap, k1, k2, l2, h, int(Ls / h), pc["B_p_V"])
    # (DC) with the frozen gains at the ablation memories
    dcc = dc_explicit(alpha, lam, ap, k1, k2, pc["l1"], l2, 0.0, h, int(Lc / h))
    dcs = dc_explicit(alpha, lam, ap, k1, k2, pc["l1"], l2, 0.0, h, int(Ls / h))
    return dict(defined=True, eps_z=eps, L_cert_s=Lc, L_short_s=Ls, bound_at_L_cert=bc, bound_at_L_short=bs,
                L_cert_certified=bool(bc["ez_bound_exact"] <= eps and dcc["ok"]),
                L_short_uncertified=bool(bs["ez_bound_exact"] > eps and bs.get("ez_bound_chain", np.inf) > eps),
                dc_L_cert=dcc, dc_L_short=dcs)


# ---------------------------------------------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------------------------------------------
def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return f if math.isfinite(f) else ("inf" if f > 0 else ("-inf" if f < 0 else "nan"))
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    return o


def dump(obj, name):
    with open(RES / name, "w", encoding="utf-8") as fh:
        json.dump(jsonable(obj), fh, indent=1)


# ---------------------------------------------------------------------------------------------------------------
# Main computation
# ---------------------------------------------------------------------------------------------------------------
def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def compute(workers):
    c, dt, est = cfg()
    t0w, t0c = time.perf_counter(), time.process_time()
    started = now()
    vfiles = {}
    for T in TEMPS:
        cs = val_case(T)
        vfiles[T] = dict(file=cs.logical_id, split=cs.split, verified=bool(cs.meta["verify_passed"]), n=int(cs.t.size),
                         z_ref0=cs.z_ref0)
    lamg = [float(v) for v in dt["lambda_grid"]]
    Lfin = [int(v) for v in dt["L_grid_s"]]
    Lg = Lfin + ["full"]
    tie = float(dt["structure_selection"]["tie_tol_pct"])
    # ---- stage 1-2: design sets with the default design gains
    t1 = time.perf_counter()
    drecs = run_pool(design_task, [(T, lam, L) for T in TEMPS for lam in lamg for L in Lg], workers)
    cand = {}
    for d in drecs:
        cand.setdefault((d["lam"], d["L"]), {})[d["T"]] = d
    frecs = run_pool(foekf_default_task, [(T, L) for T in TEMPS for L in Lg], workers)
    fcand = {}
    for d in frecs:
        fcand.setdefault((0.0, d["L"]), {})[d["T"]] = d
    stage12_wall = time.perf_counter() - t1
    selection = {}
    for bname, B in (("primary", int(dt["L_budget_s"])), ("secondary", int(dt["L_budget_secondary_s"]))):
        selection[bname] = dict(budget_s=B, proposed=select_structure(cand, set(lamg), B, tie),
                                TFO=select_structure(cand, {l for l in lamg if l > 0}, B, tie),
                                FOO=select_structure(cand, {0.0}, B, tie),
                                FOEKF=select_structure(fcand, {0.0}, B, tie))
    selection_utc = now()
    # ---- stage 3: equal-budget tuning (TFO/FOO for every (lambda, L) candidate, FOEKF at the selected memories,
    #      EKF2RC, AEKF2RC); the frozen TFO/FOO entries are the grid entries at the selected structures
    t3 = time.perf_counter()
    tasks = []
    for T in TEMPS:
        for lam in lamg:
            for L in Lfin:
                dg = cand[(lam, L)][T]["design"]
                tasks.append(("FOO" if lam == 0.0 else "TFO", T, lam, L, (dg["l1"], dg["l2"]), "grid"))
    fo_L = sorted({selection[b]["FOEKF"]["winner"]["L"] for b in selection})
    for T in TEMPS:
        for L in fo_L:
            tasks.append(("FOEKF", T, 0.0, L, None, f"L{L}"))
        tasks.append(("EKF2RC", T, None, None, None, "-"))
        tasks.append(("AEKF2RC", T, None, None, None, "-"))
    tres = run_pool(tune_task, tasks, workers)
    stage3_wall = time.perf_counter() - t3
    cc = [cc_task(T) for T in TEMPS]
    grid = {(r["T"], r["lam"], r["L"]): r for r in tres if r["tag"] == "grid"}
    # reproducibility: re-run the primary TFO task at 25 C in this process
    selT = selection["primary"]["TFO"]["winner"]
    dg = cand[(selT["lam"], selT["L"])][25]["design"]
    rep = tune_task(("TFO", 25, selT["lam"], selT["L"], (dg["l1"], dg["l2"]), "repro"))
    repro = dict(T=25, lam=selT["lam"], L=selT["L"], best_objective_rerun=rep["best_objective"],
                 best_objective_grid=grid[(25, selT["lam"], selT["L"])]["best_objective"])
    # ---- tuned-gain selection (sensitivity, not used): same rule on the tuned objectives
    tcand = {}
    for (T, lam, L), r in grid.items():
        tcand.setdefault((lam, L), {})[T] = dict(objective=r["best_objective"], certified=True)
    sens = {b: dict(budget_s=selection[b]["budget_s"],
                    proposed=select_structure(tcand, set(lamg), selection[b]["budget_s"], tie),
                    TFO=select_structure(tcand, {l for l in lamg if l > 0}, selection[b]["budget_s"], tie),
                    FOO=select_structure(tcand, {0.0}, selection[b]["budget_s"], tie)) for b in selection}
    # ---- stage 4: certificates of every tuned TFO/FOO candidate and ablation horizons
    t4 = time.perf_counter()
    pcs = run_pool(post_task, [(T, lam, L, grid[(T, lam, L)]["best_values"]["l1"], grid[(T, lam, L)]["best_values"]["l2"])
                               for (T, lam, L) in grid], workers)
    post = {(p["T"], p["lam"], p["L"]): p for p in pcs}
    ablation = {}
    for b in selection:
        w = selection[b]["TFO"]["winner"]
        ablation[b] = {T: ablation_horizons(post[(T, w["lam"], w["L"])]) for T in TEMPS}
    stage4_wall = time.perf_counter() - t4
    wT = selection["primary"]["TFO"]["winner"]
    diag = run_pool(diag_task, [(T, wT["lam"], wT["L"], grid[(T, wT["lam"], wT["L"])]["best_values"]["l1"])
                                for T in TEMPS], workers)
    all_certified = all(p["dc_sigma0"]["certified"] for p in pcs)
    runtime = dict(main_wall_s=time.perf_counter() - t0w, main_process_s=time.process_time() - t0c,
                   stage12_wall_s=stage12_wall, stage3_wall_s=stage3_wall, stage4_wall_s=stage4_wall,
                   worker_process_s_sum=float(sum(d["process_s"] for d in drecs) + sum(r["process_s"] for r in tres)),
                   workers=workers, note="worker process times summed over the design and tuning tasks")
    meta = dict(generated_utc=now(), started_utc=started, script="scripts/05_design_tune.py", code_hash=code_hash(),
                settings=dt, validation_files=vfiles, test_files_loaded=False, input_timing=O.INPUT_TIMING)
    gd = dict(meta, selection_utc=selection_utc, design=[d for d in drecs], foekf_default=frecs, selection=selection,
              post_certificates=list(post.values()), all_tuned_candidates_certified=all_certified,
              ablation_memory=ablation, runtime=runtime)
    tu = dict(meta, selection_utc=selection_utc, tuning=[r for r in tres if r["tag"] != "grid"],
              grid=list(grid.values()), cc=cc, reproducibility=repro, tuned_gain_selection_sensitivity=sens,
              uncertified_l2_diagnostic=diag,
              runtime=runtime)
    dump(gd, "gain_design.json")
    dump(tu, "tuning.json")
    return gd, tu


def diag_task(args):
    """'Price of the certificate' (reported only): frozen primary TFO structure at T, l1 in the declared set (the
    tuned value and fixed values), l2 on a grid reaching far outside the certified set."""
    T, lam, L, l1_tuned = args
    c, dt, est = cfg()
    h = float(dt["h_s"])
    dg = dt["diagnostic_uncertified_l2"]
    r = memory_row(T, lam, L)
    p = params_from_row(r, T)
    kap = kappas(T, p)
    N_L = int(math.ceil(float(L) / h - 1e-9))
    rows = []
    for l1 in dg["l1"]:
        l1v = float(l1_tuned) if l1 == "tuned" else float(l1)
        for l2 in dg["l2"]:
            ev = evaluate("FOO" if lam == 0.0 else "TFO", p, dict(l1=l1v, l2=float(l2), L_s=float(L),
                                                                 z_interval=kap["z_interval_obs"]), T)
            dce = dc_explicit(float(p["alpha"]), lam, ap_of(p), kap["kappa1"], kap["kappa2"], l1v, float(l2), 0.0, h, N_L)
            rows.append(dict(l1=l1v, l1_label=str(l1), l2=float(l2), objective=ev["objective"], certified=dce["ok"]))
    return dict(T=T, lam=lam, L=L, rows=rows)


def post_task(args):
    T, lam, L, l1, l2 = args
    return post_certificate(T, lam, L, l1, l2)


# ---------------------------------------------------------------------------------------------------------------
# Freeze: results/frozen_config.json
# ---------------------------------------------------------------------------------------------------------------
def _num(v):
    return float(v) if isinstance(v, (int, float)) else (float("inf") if v == "inf" else float("nan"))


def frozen_choice(gd, tu, budget):
    """Frozen TFO/FOO/FOEKF entries of one memory budget (grid / tuning records)."""
    sel = gd["selection"][budget]
    grid = {(g["T"], g["lam"], g["L"]): g for g in tu["grid"]}
    post = {(p["T"], p["lam"], p["L"]): p for p in gd["post_certificates"]}
    out = {}
    for meth in ("TFO", "FOO"):
        w = sel[meth]["winner"]
        per_T = {}
        for T in TEMPS:
            g, pc = grid[(T, w["lam"], w["L"])], post[(T, w["lam"], w["L"])]
            per_T[str(T)] = dict(parameter_set=g["row"], params=pc["params"], lam=w["lam"], L_s=float(w["L"]),
                                 N_L=pc["N_L"], hyper=dict(l1=g["best_values"]["l1"], l2=g["best_values"]["l2"],
                                                           L_s=float(w["L"]), z_interval=pc["kappa"]["z_interval_obs"]),
                                 kappa1=pc["kappa"]["kappa1"], kappa2=pc["kappa"]["kappa2"],
                                 kappa1_clip=pc["kappa"]["kappa1_clip"], kappa2_clip=pc["kappa"]["kappa2_clip"],
                                 certified=pc["dc_sigma0"]["certified"], sigma_star=pc["sigma_star"],
                                 validation_objective_pct=g["best_objective"], at_bound=g["at_bound"],
                                 bytes_state=pc["bytes_state"])
        out[meth] = dict(structure=w, per_T=per_T)
    wf = sel["FOEKF"]["winner"]
    tun = {(r["method"], r["T"], r["tag"]): r for r in tu["tuning"]}
    per_T = {}
    for T in TEMPS:
        r = tun[("FOEKF", T, f"L{wf['L']}")]
        per_T[str(T)] = dict(parameter_set=r["row"], params={k: float(v) for k, v in
                                                          params_from_row(memory_row(T, 0.0, wf["L"]), T).items()},
                             hyper=r["best_hyper"], validation_objective_pct=r["best_objective"], at_bound=r["at_bound"])
    out["FOEKF"] = dict(structure=wf, per_T=per_T)
    return out


def write_frozen(gd, tu, keep_stamps=False):
    """Write results/frozen_config.json. keep_stamps (--report-only): keep the generated_utc and frozen_utc of the
    existing file, so that a rebuild from the saved results does not move the recorded freeze time (README, section 8)."""
    c, dt, est = cfg()
    tun = {(r["method"], r["T"], r["tag"]): r for r in tu["tuning"]}
    prim, sec = frozen_choice(gd, tu, "primary"), frozen_choice(gd, tu, "secondary")
    methods = dict(prim)
    for meth in ("EKF2RC", "AEKF2RC"):
        methods[meth] = dict(per_T={str(T): dict(parameter_set=tun[(meth, T, "-")]["row"],
                                                 params={k: float(v) for k, v in params_2rc(T).items()},
                                                 hyper=tun[(meth, T, "-")]["best_hyper"],
                                                 validation_objective_pct=tun[(meth, T, "-")]["best_objective"],
                                                 at_bound=tun[(meth, T, "-")]["at_bound"]) for T in TEMPS})
    methods["CC"] = dict(per_T={str(T): dict(params=dict(Qn=E.q_id(T), eta=float(c["dataset"]["coulombic_efficiency"])),
                                             hyper={}) for T in TEMPS})
    abl = {}
    for T in TEMPS:
        a = gd["ablation_memory"]["primary"][str(T)]
        base = prim["TFO"]["per_T"][str(T)]
        if a.get("defined"):
            abl[str(T)] = dict(L_cert_s=a["L_cert_s"], L_short_s=a["L_short_s"],
                               certified_hyper=dict(base["hyper"], L_s=a["L_cert_s"]),
                               short_hyper=dict(base["hyper"], L_s=a["L_short_s"]),
                               L_cert_certified=a["L_cert_certified"], L_short_uncertified=a["L_short_uncertified"],
                               note="frozen TFO parameters and gains; only the memory differs")
    fz = dict(generated_utc=now(), frozen_utc=now(), script="scripts/05_design_tune.py", code_hash=gd["code_hash"],
              status="FROZEN: every hyper-parameter below was selected on the validation files only; test files may "
                     "now be evaluated (experiments.load_case(..., allow_splits=('test',), final_evaluation=True))",
              h_s=float(dt["h_s"]), input_timing=O.INPUT_TIMING,
              parameter_set_decision=load_json("identification_refined.json")["decision"].get("chosen", "causal_full"),
              memory_budget_primary_s=int(dt["L_budget_s"]), memory_budget_secondary_s=int(dt["L_budget_secondary_s"]),
              admissible_soc_interval_reference=dt["admissible_soc_interval"],
              metrics=dict(primary=dt["metric"], t_post_s=float(est["post_convergence_t_s"]),
                           convergence_band=float(c["validation"]["error_band_convergence"]),
                           within_bands=est["within_bands"]),
              initial_soc_scenarios=est["initial_soc_scenarios"], nominal_z0_ocv=est["nominal_z0_ocv"],
              cold_start=est["cold_start"], soc_clip=est["soc_clip"], ocv_table=est["ocv_table"],
              h_scaling=est["h_scaling"],
              seeds=dict(project=int(c["project"]["seed"]), tuning=int(dt["tuning"]["seed"]),
                         validation_mc=c["validation"]["seeds"], bootstrap=est["bootstrap"]),
              proposed_rule=dict(primary=gd["selection"]["primary"]["proposed"]["winner"],
                                 secondary=gd["selection"]["secondary"]["proposed"]["winner"],
                                 rule=dt["structure_selection"]["rule"]),
              methods=methods, secondary_budget_3200=dict(TFO=sec["TFO"], FOO=sec["FOO"], FOEKF=sec["FOEKF"]),
              ablation_memory_TFO=abl, tuning_budget_evals=int(dt["tuning"]["budget_evals"]))
    if keep_stamps and (RES / "frozen_config.json").exists():
        old = load_json("frozen_config.json")
        fz.update({k: old[k] for k in ("generated_utc", "frozen_utc") if k in old})
    dump(fz, "frozen_config.json")
    return fz


# ---------------------------------------------------------------------------------------------------------------
# Table: tables/tab_hyper.tex
# ---------------------------------------------------------------------------------------------------------------
def tex_num(v, digits=3):
    v = _num(v) if not isinstance(v, (int, float)) else float(v)
    if not math.isfinite(v):
        return "--"
    if v == 0:
        return "0"
    e = int(math.floor(math.log10(abs(v))))
    if -2 <= e <= 3:
        return f"{v:.{max(0, digits - 1 - e)}f}"
    m = v / 10 ** e
    return f"${m:.{digits - 1}f}\\times10^{{{e}}}$"


def storage_bytes(method, entry, T):
    """bytes_state of one nominal run with the frozen hyper-parameters (validation file; state size only)."""
    p = dict(entry["params"])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        rec = E.run_case(method, p, dict(entry["hyper"]), val_case(T), z0_scenario="nominal",
                         ocv=fast_ocv(T, p) if method != "CC" else None)
    return int(rec["bytes_state"]), float(rec["wall_per_sample_us"])


def _hdr2(a, b):
    """Two-line column head, braced so that it is also valid in a siunitx S column."""
    return r"{\begin{tabular}[b]{@{}c@{}}" + a + r"\\" + b + r"\end{tabular}}"


def write_table(fz, gd):
    """tables/tab_hyper.tex (article class, 0.8 in margins, no scaling): budget as a group row, siunitx S columns for
    the plain-decimal columns, braced cells for the scientific-notation and non-numeric entries."""
    post = {(p["T"], p["lam"], p["L"]): p for p in gd["post_certificates"]}
    S = r"S[table-format=1.3]"
    L1 = []
    L1.append("% Generated by scripts/05_design_tune.py (write_table) from results/frozen_config.json and "
              "results/gain_design.json -- do not edit by hand.")
    L1.append(r"\begin{table}[t]\centering\footnotesize\setlength{\tabcolsep}{3.5pt}")
    L1.append(r"\caption{Frozen observer hyper-parameters and implementation settings (selected and tuned on the "
              r"validation records only). Sampling $h=\SI{" + f"{fz['h_s']:g}" + r"}{\second}$; memory $N_L=\lceil L/h\rceil$; cold "
              r"start ($\hat V_{p,0}=0$, empty memory buffer); $\kappa_1,\kappa_2$ (\si{\volt} per unit SOC): min/max of "
              r"$\mathrm{d}U_{\mathrm{oc}}/\mathrm{d}z$ of each model's aligned OCV on the admissible reference-SOC interval "
              r"$[0.10,0.95]$ mapped to the observer axis; certified set at $\sigma=0$: $0<l_1\le 1/(h\kappa_2)$, "
              r"$0\le l_2<\bar l_2=\kappa_1(a_p+\mu_{h,L}(0))/(\kappa_2-\kappa_1)$; $\sigma^\ast$: supremum of the rates "
              r"certified by (DC) (end point of a floating-point bisection; (DC) holds for every $\sigma<\sigma^\ast$); "
              r"$l_1$ in \si{\per\volt\per\second}, $l_2$ in $\si{\second}^{-\alpha}$. $\mathbf{Q}$, $R$, $\mathbf{P}_0$: "
              r"process-noise covariance, measurement-noise variance and initial error covariance of the Kalman filters; "
              r"$b$: fading factor. Operation counts and state storage of all estimators: Table~\ref{tab:cost}.}\label{tab:hyper}")
    L1.append(r"\begin{tabular}{@{}lS[table-format=2.0]S[table-format=4.0]r" + S * 3 + "rr" + S + r"r@{}}\toprule")
    L1.append(r"Method & " + _hdr2("$T$", r"(\si{\degreeCelsius})") + " & " + _hdr2("$L$", r"(\si{\second})") + " & "
              + _hdr2(r"$\lambda$", r"(\si{\per\second})")[1:-1] + r" & {$\alpha$} & "
              r"{$\kappa_1$} & {$\kappa_2$} & $l_1$ & $l_2$ & {$\bar l_2$} & "
              + _hdr2(r"$\sigma^\ast$", r"(\si{\per\second})")[1:-1] + r" \\")
    for bname, key, blk in (("400", "methods", fz["methods"]), ("3200", "secondary_budget_3200", fz["secondary_budget_3200"])):
        L1.append(r"\midrule")
        L1.append(r"\multicolumn{11}{@{}l}{\emph{Memory budget \SI{" + bname + r"}{\second}}} \\")
        for meth in ("TFO", "FOO"):
            for T in TEMPS:
                e = blk[meth]["per_T"][str(T)]
                pc = post[(T, e["lam"], int(e["L_s"]))]
                L1.append(f"{meth} & {T} & {int(e['L_s'])} & {tex_num(e['lam'])} & "
                          f"{tex_num(e['params']['alpha'])} & {tex_num(e['kappa1'])} & {tex_num(e['kappa2'])} & "
                          f"{tex_num(e['hyper']['l1'])} & {tex_num(e['hyper']['l2'])} & "
                          f"{tex_num(pc['certified_set']['l2_sup'])} & {tex_num(e['sigma_star'])} " + r"\\"
                          + f" % src: results/frozen_config.json:{key}.{meth}.per_T.{T}; "
                            f"results/gain_design.json:post_certificates[T={T}].certified_set.l2_sup")
    L1.append(r"\bottomrule\end{tabular}")
    L1.append(r"\par\vspace{6pt}")
    L1.append(r"\begin{tabular}{@{}lS[table-format=2.0]S[table-format=3.0]lllS[table-format=1.4]@{}}"
              r"\toprule")
    L1.append(r"Method & " + _hdr2("$T$", r"(\si{\degreeCelsius})") + " & " + _hdr2("$L$", r"(\si{\second})")
              + r" & $\mathrm{diag}\,\mathbf{Q}$ & " + _hdr2("$R$", r"(\si{\volt\squared})")[1:-1] + r" & "
              r"$\mathrm{diag}\,\mathbf{P}_0$ & {$b$} \\ \midrule")
    for meth in ("TFO", "FOO", "FOEKF", "EKF2RC", "AEKF2RC", "CC"):
        for T in TEMPS:
            e = fz["methods"][meth]["per_T"][str(T)]
            hy = e["hyper"]
            Ls = hy.get("L_s")
            q = ", ".join(tex_num(v, 2) for v in hy["Q"]) if "Q" in hy else "--"
            p0 = ", ".join(tex_num(v, 2) for v in hy["P0"]) if "P0" in hy else "--"
            rr = tex_num(hy["R"], 2) if "R" in hy else "--"
            bb = tex_num(hy["b"], 4) if "b" in hy else "{--}"
            lab = {"EKF2RC": "EKF-2RC", "AEKF2RC": "AEKF-2RC"}.get(meth, meth)
            L1.append(f"{lab} & {T} & {int(Ls) if Ls else '{--}'} & {q} & {rr} & {p0} & {bb} " + r"\\"
                      + f" % src: results/frozen_config.json:methods.{meth}.per_T.{T}.hyper")
    L1.append(r"\bottomrule\end{tabular}")
    L1.append(r"\end{table}")
    (ROOT / "tables" / "tab_hyper.tex").write_text("\n".join(L1) + "\n", encoding="utf-8")

# ---------------------------------------------------------------------------------------------------------------
# Figures (draft, journal style) - plotted arrays stored in results/tuning.json['figure_data']
# ---------------------------------------------------------------------------------------------------------------
def figure_data(gd, tu, fz):
    c, dt, est = cfg()
    lamg = [float(v) for v in dt["lambda_grid"]]
    Lfin = [int(v) for v in dt["L_grid_s"]]
    dmap = {(d["T"], d["lam"], d["L"]): d for d in gd["design"]}
    gmap = {(g["T"], g["lam"], g["L"]): g for g in tu["grid"]}
    sel = {}
    for lam in lamg:
        sel[str(lam)] = dict(L=Lfin,
                             design_mean=[float(np.mean([_num(dmap[(T, lam, L)]["objective"]) for T in TEMPS]))
                                          for L in Lfin],
                             tuned_mean=[float(np.mean([_num(gmap[(T, lam, L)]["best_objective"]) for T in TEMPS]))
                                         for L in Lfin],
                             design_full=float(np.mean([_num(dmap[(T, lam, "full")]["objective"]) for T in TEMPS])))
    cert = {}
    for T in TEMPS:
        e = fz["methods"]["TFO"]["per_T"][str(T)]
        g = gmap[(T, e["lam"], int(e["L_s"]))]
        cs = g["certified_set"]
        cert[str(T)] = dict(l1=[tr["values"]["l1"] for tr in g["trace"]], l2=[tr["values"]["l2"] for tr in g["trace"]],
                            objective=[_num(tr["objective"]) for tr in g["trace"]],
                            stage=[tr["stage"] for tr in g["trace"]],
                            l1_box=[10 ** g["dims"][0]["log10_lo"], 10 ** g["dims"][0]["log10_hi"]],
                            l2_box=[10 ** g["dims"][1]["log10_lo"], 10 ** g["dims"][1]["log10_hi"]],
                            l1_max_cert=cs["l1_max"], l2_sup_cert=cs["l2_sup"],
                            tuned=[e["hyper"]["l1"], e["hyper"]["l2"]], lam=e["lam"], L=e["L_s"])
    return dict(selection_curves=sel, certified_set_TFO_primary=cert, L_budget_s=int(dt["L_budget_s"]))


def make_figures(fd):
    from tfso import plotstyle as ps
    plt = ps.setup()
    from matplotlib.colors import LogNorm
    lams = list(fd["selection_curves"].keys())
    fig, axs = plt.subplots(1, 2, figsize=ps.figsize("text", 62), layout="constrained", sharey=True)
    marks = ["o", "s", "^", "v", "D", "P"]
    dashes = ["-", "--", "-.", ":", (0, (5, 1.5, 1, 1.5)), (0, (1, 1))]
    for k, (key, title) in enumerate((("design_mean", "default LMI design gains"), ("tuned_mean", "tuned gains (80 evaluations each)"))):
        ax = axs[k]
        for i, lam in enumerate(lams):
            cv = fd["selection_curves"][lam]
            lab = r"$\lambda=0$ (FOO)" if float(lam) == 0 else rf"$\lambda={float(lam):g}$ s$^{{-1}}$"
            ax.plot(cv["L"], cv[key], color=ps.SLOTS[i], ls=dashes[i], marker=marks[i], mec="white", mew=0.5,
                    lw=ps.LW["data"], label=lab)
        ax.axvline(fd["L_budget_s"], color=ps.INK2, lw=ps.LW["ref"], ls="--")
        ax.text(fd["L_budget_s"] * 1.06, 0.02, "memory budget", transform=ax.get_xaxis_transform(), color=ps.INK2,
                fontsize=ps.FONT_PT["base"], va="bottom")
        ax.set_xscale("log")
        ax.set_xlabel("memory length $L$ (s)")
        ax.set_title(title, fontsize=ps.FONT_PT["label"])
        ps.panel_label(ax, k)
    axs[0].set_ylabel("validation SOC RMSE (% SOC)\nmean over $T$ and $z_0$ scenarios")
    axs[1].legend(loc="upper right", ncol=2)
    p1 = ps.save(fig, ROOT / "figures" / "draft_p2_selection.pdf")
    plt.close(fig)
    fig, axs = plt.subplots(1, 3, figsize=ps.figsize("text", 60), layout="constrained")
    allo = [v for T in fd["certified_set_TFO_primary"].values() for v in T["objective"] if math.isfinite(v)]
    norm = LogNorm(vmin=min(allo), vmax=max(allo))
    for k, (T, cs) in enumerate(fd["certified_set_TFO_primary"].items()):
        ax = axs[k]
        ax.fill_between([cs["l1_box"][0], cs["l1_max_cert"]], cs["l2_box"][0], cs["l2_sup_cert"], color=ps.SHADE, lw=0)
        ax.plot([cs["l1_max_cert"]] * 2, [cs["l2_box"][0], cs["l2_sup_cert"]], color=ps.INK2, lw=ps.LW["ref"])
        ax.plot([cs["l1_box"][0], cs["l1_max_cert"]], [cs["l2_sup_cert"]] * 2, color=ps.INK2, lw=ps.LW["ref"])
        sc = ax.scatter(cs["l1"], cs["l2"], c=cs["objective"], cmap="Blues_r", norm=norm, s=12, edgecolors="white",
                        linewidths=0.3)
        ax.plot(*cs["tuned"], marker="*", ms=9, color=ps.INK, mec="white", mew=0.6, ls="none")
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel(r"$l_1$ (V$^{-1}$ s$^{-1}$)")
        ax.set_title(f"{T} $^\\circ$C: $\\lambda={cs['lam']:g}$ s$^{{-1}}$, $L={cs['L']:g}$ s", fontsize=ps.FONT_PT["label"])
        ps.panel_label(ax, k)
    axs[0].set_ylabel(r"$l_2$ (s$^{-\alpha}$)")
    cb = fig.colorbar(sc, ax=axs, shrink=0.9)
    cb.set_label("validation SOC RMSE (% SOC)")
    p2 = ps.save(fig, ROOT / "figures" / "draft_p2_certified_set.pdf")
    plt.close(fig)
    for p in (p1, p2):
        try:
            ps.preview_png(p)
        except Exception:  # pragma: no cover
            pass
    return [str(p1.relative_to(ROOT)), str(p2.relative_to(ROOT))]


# ---------------------------------------------------------------------------------------------------------------
# Report: reports/tuning_findings.md (every number read from the JSON files)
# ---------------------------------------------------------------------------------------------------------------
def f3(v, nd=3):
    v = _num(v) if not isinstance(v, (int, float)) else float(v)
    if not math.isfinite(v):
        return "inf" if v > 0 else "nan"
    if v != 0 and (abs(v) < 1e-3 or abs(v) >= 1e5):
        return f"{v:.{nd - 1}e}"
    return f"{v:.{nd}f}" if abs(v) < 10 else f"{v:.{max(nd - 2, 1)}f}"


def lamstr(lam):
    return "0" if float(lam) == 0 else f"{float(lam):g}"


def report_design(gd, fz):
    c, dt, est = cfg()
    out = []
    post = {(p["T"], p["lam"], p["L"]): p for p in gd["post_certificates"]}
    out.append("## 1. Slope bounds, certified sets and certificates\n")
    out.append("kappa1/kappa2 = min/max of dU/dz of each candidate's OWN aligned OCV (identified s, dq) on the admissible "
               "reference-SOC interval [0.10, 0.95] mapped to the observer axis z = 1 - (1 - z_ref) Q_ref/Q_id; clip-range "
               "values on [-0.05, 1.05] (the estimators' SOC clip) and the ocv_findings envelope (sensitivity) are "
               "reported alongside. Certified set at sigma = 0 (finite N_L): 0 < l1 <= 1/(h kappa2), "
               "0 <= l2 < l2_sup = kappa1 (a_p + mu_{h,L}(0))/(kappa2 - kappa1).\n")
    out.append("| budget | method | T | observer interval | kappa1 | kappa2 | kappa1 / kappa2 clip | envelope kappa1 / kappa2 "
               "| l1 max | l2_sup | l1 | l2 | (DC) margin | LP margin | sigma* (1/s) | h l1 kappa2 (clip) | certified: adm / clip / envelope |")
    out.append("|" + "---|" * 17)
    for bname, blk in (("400 s", fz["methods"]), ("3200 s", fz["secondary_budget_3200"])):
        for meth in ("TFO", "FOO"):
            for T in TEMPS:
                e = blk[meth]["per_T"][str(T)]
                pc = post[(T, e["lam"], int(e["L_s"]))]
                k = pc["kappa"]
                env = pc["envelope_sensitivity"]
                out.append(f"| {bname} | {meth} (lambda {lamstr(e['lam'])}, L {int(e['L_s'])}) | {T} | "
                           f"[{f3(k['z_interval_obs'][0])}, {f3(k['z_interval_obs'][1])}] | {f3(k['kappa1'])} | "
                           f"{f3(k['kappa2'])} | {f3(k['kappa1_clip'])} / {f3(k['kappa2_clip'])} | {f3(env['kappa1'])} / "
                           f"{f3(env['kappa2'])} | {f3(pc['certified_set']['l1_max'])} | {f3(pc['certified_set']['l2_sup'])} | "
                           f"{pc['l1']:.3g} | {pc['l2']:.3g} | {f3(pc['dc_sigma0']['explicit_margin'])} | "
                           f"{f3(pc['dc_sigma0']['lp_margin'])} | {f3(pc['sigma_star'])} | {f3(pc['h_l1_kappa2'])} "
                           f"({f3(pc['h_l1_kappa2_clip'])}) | {pc['dc_sigma0']['certified']} / "
                           f"{pc['certified_on_clip_range']} / {env['certified']} |")
    ks = [(d["kappa"]["kappa1"], d["kappa"]["kappa2"]) for d in gd["design"]]
    out.append(f"\nOver all {len(ks)} design candidates (3 T x 6 lambda x 8 memories) kappa1 ranges "
               f"{f3(min(k[0] for k in ks))}-{f3(max(k[0] for k in ks))} and kappa2 {f3(min(k[1] for k in ks))}-"
               f"{f3(max(k[1] for k in ks))} V per unit SOC (the aligned OCV differs slightly per refit).\n")
    # LMI numerics
    des = [d for d in gd["design"] if d["design"].get("feasible")]
    aud = [d["design"]["lmi_audit"] for d in des]
    st = {}
    for a in aud:
        st[a["status"]] = st.get(a["status"], 0) + 1
    pcs = gd["post_certificates"]
    fx = [p["lmi_fixed_sigma0"] for p in pcs] + [d["lmi_fixed_sigma0"] for d in des]
    fs = {}
    for a in fx:
        fs[a["status"]] = fs.get(a["status"], 0) + 1
    fxs = [p["lmi_fixed_0p9_sigma_star"] for p in pcs if p.get("lmi_fixed_0p9_sigma_star")]
    out.append("**LMI / LP numerics (Clarabel via CVXPY; scipy HiGHS for the LP).**\n")
    out.append(f"* Default design (tempered.design_gains, diagonal LMI with bisection on sigma), {len(des)}/{len(gd['design'])} "
               f"candidates feasible. Independent re-solve of the design LMI at the returned rate: statuses {st}; "
               f"margin t* in [{f3(min(a['t'] for a in aud))}, {f3(max(a['t'] for a in aud))}] (bisection stops at the "
               f"feasibility edge, so t* ~ 0 is expected); a-posteriori max eig He(P M) in "
               f"[{f3(min(a['max_eig_He'] for a in aud))}, {f3(max(a['max_eig_He'] for a in aud))}]; strict "
               f"(<= -{dt['lmi']['strict_tol']:g}) in {sum(a['strict_ok'] for a in aud)}/{len(aud)} (the others sit at the "
               f"bisection feasibility edge within the solver tolerance; the gains actually used are certified by the explicit "
               f"inequality, the LP and the fixed-gain LMI below). The design gains "
               f"then have l2 raised to l2min in {sum(d['design']['l2_raised_to_l2min'] for d in des)}/{len(des)} "
               "candidates and are re-certified.")
    out.append(f"* Final gains (design gains of every candidate and tuned gains of every grid candidate, {len(fx)} "
               f"gain pairs): explicit (DC) at sigma = 0 holds in {sum(d['dc_sigma0']['explicit'] for d in des) + sum(p['dc_sigma0']['explicit'] for p in pcs)}"
               f"/{len(fx)}, the LP certificate in {sum(d['dc_sigma0']['lp'] for d in des) + sum(p['dc_sigma0']['lp'] for p in pcs)}"
               f"/{len(fx)} (explicit and LP agree in every case: "
               f"{all(d['dc_sigma0']['explicit'] == d['dc_sigma0']['lp'] for d in des) and all(p['dc_sigma0']['explicit'] == p['dc_sigma0']['lp'] for p in pcs)}), "
               f"positivity h l1 kappa2 <= 1 in {sum(d['dc_sigma0']['positivity'] for d in des) + sum(p['dc_sigma0']['positivity'] for p in pcs)}/{len(fx)}.")
    out.append(f"* Fixed-gain diagonal Lyapunov LMI He(P M_(h,L)(0)) <= -t I: statuses {fs}; t* min "
               f"{f3(min(a['t'] for a in fx if a['t'] is not None))}; max eig max {f3(max(a['max_eig'] for a in fx if a['max_eig'] is not None))}; "
               f"strict in {sum(a['strict_ok'] for a in fx)}/{len(fx)}. At 0.9 sigma*: strict in "
               f"{sum(a['strict_ok'] for a in fxs)}/{len(fxs)}.")
    out.append(f"* All tuned grid candidates certified at sigma = 0 on the admissible interval: "
               f"{gd['all_tuned_candidates_certified']}.\n")
    return out


def report_memory(gd, fz):
    c, dt, est = cfg()
    out = []
    Lb = int(dt["L_budget_s"])
    eps_p = float(dt["eps_z_primary"])
    dmap = {(d["T"], d["lam"], d["L"]): d for d in gd["design"]}
    post = {(p["T"], p["lam"], p["L"]): p for p in gd["post_certificates"]}
    out.append("## 2. Memory selection rule (cor:m4b:memory) and the untempered requirement\n")
    out.append(f"B_p = Vbar_p0 + b_p I_max/(a_p + lambda^alpha) of the parameter row (identification_memory.json); "
               f"gamma_zp^(h) = 1/(kappa1 (a_p + l2 + mu_h(0)) - l2 kappa2); eps_p = eps_z/gamma_zp^(h); "
               f"L_z* = min(L*, L_b*) (tempered.memory_rule). Parameters of the lambda row at L = {Lb} s with the "
               f"design gain l2 (left) and with the tuned l2 of that candidate (right). 'check' = the exact discrete "
               f"bound gamma_zp^(h,L) x worst-case |R_L| at N_L = ceil(L_z*) is <= eps_z. lambda = 0: log10 of the "
               f"untempered horizon (gamma_zp^0 B_p/(eps_z Gamma(2 - alpha)))^(1/alpha) in s.\n")
    out.append("| T | lambda (1/s) | alpha | B_p (V) | L_z*(0.5 %) design l2 (s) | L_z*(0.1 %) design l2 (s) | check | "
               "L_z*(0.5 %) tuned l2 (s) | L_z*(0.1 %) tuned l2 (s) | untempered log10 L (0.5 %) at same alpha |")
    out.append("|" + "---|" * 10)
    for T in TEMPS:
        for lam in [float(v) for v in dt["lambda_grid"]]:
            d = dmap[(T, lam, Lb)]
            pc = post[(T, lam, Lb)]
            md = {m["eps_z"]: m for m in d.get("memory_requirement_design_l2", [])}
            mt = {m["eps_z"]: m for m in pc["memory_requirement"]}
            if lam == 0.0:
                a = md.get(eps_p, {})
                out.append(f"| {T} | 0 | {f3(d['alpha'])} | {f3(d['B_p_V'])} | untempered: 10^{f3(a.get('log10_L_untempered_s'))} | "
                           f"10^{f3(md.get(min(md), {}).get('log10_L_untempered_s'))} | - | "
                           f"10^{f3(mt.get(eps_p, {}).get('log10_L_untempered_s'))} | "
                           f"10^{f3(mt.get(min(mt), {}).get('log10_L_untempered_s'))} | - |")
            else:
                a, b = md.get(eps_p, {}), md.get(min(md), {})
                ta, tb = mt.get(eps_p, {}), mt.get(min(mt), {})
                out.append(f"| {T} | {lamstr(lam)} | {f3(d['alpha'])} | {f3(d['B_p_V'])} | {f3(a.get('L_z_star_s'))} | "
                           f"{f3(b.get('L_z_star_s'))} | {a.get('check_ok')}/{b.get('check_ok')} | {f3(ta.get('L_z_star_s'))} | "
                           f"{f3(tb.get('L_z_star_s'))} | {f3(a.get('log10_L_untempered_same_alpha'))} |")
    out.append("\nTruncation-induced ultimate SOC error bound at the frozen memories (tuned gains): (i) exact "
               "gamma_zp^(h,L) x sum_{j>N_L}|omega_j| B_p h^-alpha (all lambda), (ii) the Gamma chain (lambda > 0) or the "
               "untempered chain (lambda = 0); % SOC.\n")
    out.append("| budget | method | T | lambda | L (s) | gamma_zp^(h,L) | bound (i) % | bound (ii) % | certified for eps_z = 0.5 %? |")
    out.append("|" + "---|" * 9)
    for bname, blk in (("400 s", fz["methods"]), ("3200 s", fz["secondary_budget_3200"])):
        for meth in ("TFO", "FOO"):
            for T in TEMPS:
                e = blk[meth]["per_T"][str(T)]
                tb_ = post[(T, e["lam"], int(e["L_s"]))]["truncation_soc_bound"]
                out.append(f"| {bname} | {meth} | {T} | {lamstr(e['lam'])} | {int(e['L_s'])} | {f3(tb_['gamma_zp_hL'])} | "
                           f"{f3(100 * _num(tb_['ez_bound_exact']))} | {f3(100 * _num(tb_['ez_bound_chain']))} | "
                           f"{_num(tb_['ez_bound_exact']) <= eps_p} |")
    out.append("")
    return out


def _winner(s):
    w = s.get("winner")
    return "none" if not w else f"lambda = {lamstr(w['lam'])} 1/s, L = {w['L']} s (mean {f3(w['mean_objective'])} % SOC)"


def report_selection(gd, tu, fd):
    c, dt, est = cfg()
    out = []
    out.append("## 3. Structure selection (pre-declared rule, design gains, validation files)\n")
    out.append(f"Rule: {dt['structure_selection']['rule']}. Tie tolerance {dt['structure_selection']['tie_tol_pct']} % SOC. "
               f"Gains: {dt['structure_selection']['gains']}. Metric: {dt['metric']}. Selection written at "
               f"{gd['selection_utc']} (before any tuning evaluation).\n")
    Ls = fd["selection_curves"][list(fd["selection_curves"])[0]]["L"]
    for key, title in (("design_mean", "design gains"), ("tuned_mean", "tuned gains (supplementary grid, 80 evaluations per candidate)")):
        out.append(f"Mean over T and scenarios of the admissible post-convergence SOC RMSE (% SOC), {title}:\n")
        out.append("| lambda (1/s) | " + " | ".join(f"L = {L}" for L in Ls) + (" | full |" if key == "design_mean" else " |"))
        out.append("|" + "---|" * (len(Ls) + 1 + (key == "design_mean")))
        for lam, cv in fd["selection_curves"].items():
            row = f"| {lamstr(lam)} | " + " | ".join(f3(v) for v in cv[key])
            out.append(row + (f" | {f3(cv['design_full'])} |" if key == "design_mean" else " |"))
        out.append("")
    for b in ("primary", "secondary"):
        s = gd["selection"][b]
        out.append(f"* **Budget L <= {s['budget_s']} s** - unrestricted winner (lambda = 0 included): {_winner(s['proposed'])}; "
                   f"tied set {[(lamstr(a), L, round(m, 4)) for a, L, m in s['proposed'].get('tied', [])]}. "
                   f"TFO (lambda > 0): {_winner(s['TFO'])}. FOO (lambda = 0): {_winner(s['FOO'])}. "
                   f"FOEKF memory (default covariances): {_winner(s['FOEKF'])}.")
    for b in ("primary", "secondary"):
        s = tu["tuned_gain_selection_sensitivity"][b]
        out.append(f"* Sensitivity (same rule on tuned objectives, budget {s['budget_s']} s; not used): unrestricted "
                   f"{_winner(s['proposed'])}; TFO {_winner(s['TFO'])}; FOO {_winner(s['FOO'])}.")
    out.append("")
    return out


def report_tuning(tu):
    c, dt, est = cfg()
    tb = dt["tuning"]
    out = []
    out.append("## 4. Equal-budget tuning (validation file of each temperature)\n")
    out.append(f"Budget per method and temperature: {tb['budget_evals']} objective evaluations = 1 default + {tb['n_sobol']} "
               f"scrambled Sobol points + {tb['n_local']} (1+1)-ES steps (sigma0 {tb['local_sigma0']} in the unit box); one "
               f"evaluation = the three initial-SOC scenarios on the validation file; objective = their mean admissible "
               f"post-convergence SOC RMSE. Seeds {tb['seed']} + 1000 T_index + 10 method_index. TFO/FOO search the "
               f"certified rectangle (log10 box, l2 up to 0.99 l2_sup); Kalman filters search the declared log10 boxes. "
               f"'at bound' = tuned unit coordinate within {tb['at_bound_unit_tol']} of a box face.\n")
    grid = {(g["T"], g["lam"], g["L"]): g for g in tu["grid"]}
    fz = load_json("frozen_config.json")
    rows = []
    for meth in ("TFO", "FOO"):
        for T in TEMPS:
            e = fz["methods"][meth]["per_T"][str(T)]
            rows.append(grid[(T, e["lam"], int(e["L_s"]))])
    rows += [r for r in tu["tuning"] if r["tag"] != "repro"]
    out.append("| method | T | structure | default obj. | tuned obj. (% SOC) | nominal / +0.20 / -0.20 | whole-profile post RMSE | "
               "best from | tuned values | at bound | evals | wall / process (s) |")
    out.append("|" + "---|" * 12)
    for r in rows:
        struct = f"lambda {lamstr(r['lam'])}, L {r['L']}" if r["method"] in ("TFO", "FOO", "FOEKF") else "-"
        ps_ = r["best_per_scenario"]
        vals = ", ".join(f"{k} {_num(v):.3g}" for k, v in r["best_values"].items())
        out.append(f"| {r['method']} | {r['T']} | {struct} | {f3(r['default_objective'])} | {f3(r['best_objective'])} | "
                   f"{' / '.join(f3(ps_[s]['adm_rmse_pct']) for s in dt['scenarios'])} | {f3(r['best_whole_post_rmse_pct'])} | "
                   f"{r['best_stage']} | {vals} | {', '.join(r['at_bound']) or '-'} | {r['n_evals']} | "
                   f"{f3(r['wall_s'], 1)} / {f3(r['process_s'], 1)} |")
    for r in tu["cc"]:
        ps_ = r["per_scenario"]
        out.append(f"| CC | {r['T']} | - | - | {f3(r['objective'])} | "
                   f"{' / '.join(f3(ps_[s]['adm_rmse_pct']) for s in dt['scenarios'])} | {f3(r['whole_post_rmse_pct'])} | "
                   f"- | none | - | 0 | - |")
    means = {}
    for r in rows:
        means.setdefault(r["method"] + ("" if r["method"] not in ("FOEKF",) else f" (L {r['L']})"), []).append(_num(r["best_objective"]))
    out.append("\nMean tuned objective over T: " + "; ".join(f"{k} {f3(np.mean(v))}" for k, v in means.items() if len(v) == 3)
               + f"; CC {f3(np.mean([_num(r['objective']) for r in tu['cc']]))} % SOC.")
    ab = [(r["method"], r["T"], r["at_bound"]) for r in rows if r["at_bound"]]
    out.append(f"\nTuned values on a search bound: {ab if ab else 'none'}.")
    rp = tu["reproducibility"]
    out.append(f"\nReproducibility: the primary TFO tuning at 25 C re-run in the main process gives {f3(rp['best_objective_rerun'], 6)} "
               f"vs {f3(rp['best_objective_grid'], 6)} % SOC in the worker.\n")
    return out


def report_frozen(gd, tu, fz):
    out = ["## 5. Frozen configuration and memory ablation\n"]
    out.append(f"results/frozen_config.json written {fz['frozen_utc']} (code hash {fz['code_hash']}); h = {fz['h_s']} s, "
               f"input timing {fz['input_timing']}, parameter set {fz['parameter_set_decision']}, memory budget "
               f"{fz['memory_budget_primary_s']} s (secondary {fz['memory_budget_secondary_s']} s). Proposed-rule winner "
               f"(primary): {fz['proposed_rule']['primary']}; (secondary): {fz['proposed_rule']['secondary']}.\n")
    out.append("| T | L_cert (s) | L_short (s) | e_z bound at L_cert (%) | e_z bound at L_short (%) | L_cert certified | L_short uncertified |")
    out.append("|---|---|---|---|---|---|---|")
    for T in TEMPS:
        a = gd["ablation_memory"]["primary"][str(T)]
        if not a.get("defined"):
            out.append(f"| {T} | undefined | - | - | - | - | - |")
            continue
        out.append(f"| {T} | {a['L_cert_s']:g} | {a['L_short_s']:g} | {f3(100 * _num(a['bound_at_L_cert']['ez_bound_exact']))} | "
                   f"{f3(100 * _num(a['bound_at_L_short']['ez_bound_exact']))} | {a['L_cert_certified']} | {a['L_short_uncertified']} |")
    rt = gd["runtime"]
    out.append(f"\n## 6. Runtime\n\nMain wall {f3(rt['main_wall_s'], 1)} s, main process {f3(rt['main_process_s'], 1)} s; "
               f"stage 1-2 wall {f3(rt['stage12_wall_s'], 1)} s, stage 3 wall {f3(rt['stage3_wall_s'], 1)} s, stage 4 wall "
               f"{f3(rt['stage4_wall_s'], 1)} s; summed worker process time {f3(rt['worker_process_s_sum'], 1)} s "
               f"({rt['workers']} workers). Machine shared with other experiments.\n")
    return out


def report_decisions(gd, tu, fz):
    """Decision list with the evidence numbers, all read from the JSON files."""
    c, dt, est = cfg()
    s1, s2 = gd["selection"]["primary"], gd["selection"]["secondary"]
    grid = {(g["T"], g["lam"], g["L"]): g for g in tu["grid"]}
    Lb = int(dt["L_budget_s"])
    d_tfo = s1["TFO"]["winner"]["mean_objective"] - s1["FOO"]["winner"]["mean_objective"]
    # tuned-gain gap (best lambda > 0 minus lambda = 0) at every L
    lams = [float(v) for v in dt["lambda_grid"]]
    gaps = []
    for L in [int(v) for v in dt["L_grid_s"]]:
        m = {lam: np.mean([_num(grid[(T, lam, L)]["best_objective"]) for T in TEMPS]) for lam in lams}
        best_pos = min((v, lam) for lam, v in m.items() if lam > 0)
        gaps.append((L, best_pos[1], best_pos[0] - m[0.0]))
    tun = [r for r in tu["tuning"] if r["tag"] != "repro"]
    meanobj = {}
    for meth in ("TFO", "FOO"):
        meanobj[meth] = np.mean([fz["methods"][meth]["per_T"][str(T)]["validation_objective_pct"] for T in TEMPS])
    for meth in ("FOEKF", "EKF2RC", "AEKF2RC"):
        meanobj[meth] = np.mean([_num(fz["methods"][meth]["per_T"][str(T)]["validation_objective_pct"]) for T in TEMPS])
    dg = tu.get("uncertified_l2_diagnostic", [])
    abl = gd["ablation_memory"]["primary"]
    nmax = max(v["n"] for v in gd["validation_files"].values())
    out = ["## Decisions (all selections on the validation files; evidence in the sections below)\n"]
    pcs = gd["post_certificates"]
    out.append(f"1. **Certificate interval and slope bounds.** kappa1/kappa2 are taken from each candidate's own aligned OCV on "
               f"the admissible reference-SOC interval [0.10, 0.95] mapped to the observer axis (Section 1). All tuned "
               f"TFO/FOO candidates certified there (DC at sigma = 0 and h l1 kappa2 <= 1): "
               f"{gd['all_tuned_candidates_certified']} ({len(pcs)} candidates); also certified with the clip-range bounds in "
               f"{sum(p['certified_on_clip_range'] for p in pcs)}/{len(pcs)} and with the ocv_findings envelope in "
               f"{sum(p['envelope_sensitivity']['certified'] for p in pcs)}/{len(pcs)}.")
    out.append(f"2. **Structure (pre-declared rule, design gains, L <= {Lb} s).** The unrestricted winner is "
               f"{_winner(s1['proposed'])}: tempering does NOT improve the validation SOC RMSE at the primary memory budget. "
               f"The best tempered configuration, lambda = {lamstr(s1['TFO']['winner']['lam'])} 1/s at L = "
               f"{s1['TFO']['winner']['L']} s, is {f3(d_tfo)} % SOC worse (within the {dt['structure_selection']['tie_tol_pct']} % "
               f"tie tolerance) and is frozen as the TFO entering the comparison; FOO = {_winner(s1['FOO'])}. "
               f"Secondary budget {s2['budget_s']} s: unrestricted {_winner(s2['proposed'])}; TFO {_winner(s2['TFO'])}.")
    mono = [L for L in [int(v) for v in dt["L_grid_s"]]
            if all(np.mean([_num(grid[(T, a, L)]["best_objective"]) for T in TEMPS])
                   < np.mean([_num(grid[(T, b, L)]["best_objective"]) for T in TEMPS]) for a, b in zip(lams[:-1], lams[1:]))]
    neg = [L for L, lam, g in gaps if g < 0]
    out.append("3. **Tuned-gain check (not used for selection).** With gains tuned per candidate at the equal budget, the best "
               "lambda > 0 minus lambda = 0 (mean over T, % SOC) is " +
               ", ".join(f"L {L}: {f3(g)} (lambda {lamstr(lam)})" for L, lam, g in gaps) +
               f". The tuned objective increases strictly with lambda at L = {mono} s; a lambda > 0 beats lambda = 0 only at "
               f"L = {neg if neg else 'none'} s, which exceeds the primary budget.")
    out.append(f"4. **Equal-budget tuning.** Mean tuned objective over T (% SOC): " +
               "; ".join(f"{k} {f3(v)}" for k, v in meanobj.items()) +
               f"; CC {f3(np.mean([_num(r['objective']) for r in tu['cc']]))}. TFO and FOO gain little from tuning "
               "(the default design gains are near the optimum); the Kalman filters gain a lot. Search-bound hits are listed "
               "in Section 4 and are limitations of the declared boxes, not of the budget.")
    if dg:
        best_in = {d["T"]: min(r["objective"] for r in d["rows"] if r["certified"]) for d in dg}
        best_all = {d["T"]: min(r["objective"] for r in d["rows"]) for d in dg}
        out.append("5. **Price of the certificate (diagnostic).** Allowing l2 far outside the certified set lowers the best "
                   "TFO objective on the diagnostic grid by " +
                   ", ".join(f"{T} C: {f3(best_in[T] - best_all[T])}" for T in TEMPS) +
                   " % SOC (certified best minus overall best on the grid), so the certified set is not what limits TFO/FOO.")
    if all(a.get("defined") for a in abl.values()):
        out.append(f"6. **Memory ablation horizons (frozen TFO).** L_cert (eps_z = {100 * float(dt['eps_z_primary']):g} % SOC) = "
                   + ", ".join(f"{T} C: {abl[str(T)]['L_cert_s']:g} s" for T in TEMPS) +
                   f"; L_short = L_cert/10 = " + ", ".join(f"{abl[str(T)]['L_short_s']:g} s" for T in TEMPS) +
                   f". The certified horizons exceed the longest validation profile ({nmax} samples), i.e. for the "
                   "frozen lambda they coincide with full memory on these profiles; the primary L = "
                   f"{s1['TFO']['winner']['L']} s memory is NOT certified for any eps_z <= 0.5 % (Section 2).")
    out.append("")
    return out


def report_diag(tu):
    dg = tu.get("uncertified_l2_diagnostic", [])
    if not dg:
        return []
    c, dt, est = cfg()
    l2s = [float(v) for v in dt["diagnostic_uncertified_l2"]["l2"]]
    out = ["### Diagnostic: l2 outside the certified set (frozen primary TFO; reported only)\n",
           "Objective (% SOC); * = certified at sigma = 0.\n",
           "| T | l1 | " + " | ".join(f"l2 = {v:g}" for v in l2s) + " |", "|" + "---|" * (len(l2s) + 2)]
    for d in dg:
        for lab in dt["diagnostic_uncertified_l2"]["l1"]:
            rr = [r for r in d["rows"] if r["l1_label"] == str(lab)]
            out.append(f"| {d['T']} | {rr[0]['l1']:.3g} | " + " | ".join(
                f"{f3(r['objective'])}{'*' if r['certified'] else ''}" for r in rr) + " |")
    out.append("")
    return out


def write_report_and_figures(gd, tu, fz):
    fd = figure_data(gd, tu, fz)
    tu = dict(tu)
    tu["figure_data"] = fd
    dump(tu, "tuning.json")
    figs = make_figures(fd)
    vf = gd["validation_files"]
    L = [f"# Observer design, structure selection and equal-budget tuning (P2)\n",
         f"Generated by `scripts/05_design_tune.py` from `results/gain_design.json`, `results/tuning.json` and "
         f"`results/frozen_config.json` ({gd['generated_utc']}, code hash {gd['code_hash']}). Validation files only: "
         + ", ".join(f"{v['file']} (verified {v['verified']}, {v['n']} samples)" for v in vf.values())
         + f"; test files loaded: {gd['test_files_loaded']}. Figures (draft): {', '.join('`' + f + '`' for f in figs)}.\n"]
    L += report_decisions(gd, tu, fz)
    L += report_design(gd, fz)
    L += report_memory(gd, fz)
    L += report_selection(gd, tu, fd)
    L += report_tuning(tu)
    L += report_diag(tu)
    L += report_frozen(gd, tu, fz)
    (ROOT / "reports" / "tuning_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------------------------------------------
def finalize(gd, tu, keep_stamps=False):
    fz = write_frozen(gd, tu, keep_stamps=keep_stamps)
    write_table(fz, gd)
    fn = globals().get("write_report_and_figures")
    if fn is not None:
        fn(gd, tu, fz)
    return fz


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report-only", action="store_true", help="regenerate freeze/table/report/figures from the JSON")
    a = ap.parse_args()
    workers = int(cfg()[1]["max_workers"])
    if a.report_only:
        gd, tu = load_json("gain_design.json"), load_json("tuning.json")
    else:
        compute(workers)
        gd, tu = load_json("gain_design.json"), load_json("tuning.json")   # JSON round trip (string keys)
    finalize(gd, tu, keep_stamps=a.report_only)
    print("done", now())


if __name__ == "__main__":
    main()
