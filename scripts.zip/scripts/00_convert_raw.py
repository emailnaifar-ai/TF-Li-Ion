"""Idempotent rebuild of data_processed/ from data_raw/ and creation of data_manifest.json.

Usage (from the project root):
    python scripts/00_convert_raw.py [--force] [--ids ID1 ID2 ...]

For each logical id in tfso.data.CATALOG the Arbin workbook is read (all chunked data sheets
concatenated in order, exact duplicate rows at sheet boundaries dropped) and written as one CSV.
A workbook is skipped when the manifest already records its md5 and the CSV md5 matches (so
re-running is cheap).  The manifest records md5s, sizes, sheets, row counts, Info-sheet text and
the logical-id mapping.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true", help="rebuild every CSV even when md5s match")
    ap.add_argument("--ids", nargs="*", default=None, help="subset of logical ids")
    args = ap.parse_args()

    old = D._manifest() or {"files": {}}
    files = dict(old.get("files", {}))
    ids = args.ids or D.LOGICAL_IDS
    out_dir = D._path("data_processed")
    out_dir.mkdir(parents=True, exist_ok=True)
    n_built = n_skipped = 0
    for lid in ids:
        ent = D.CATALOG[lid]
        wb = Path(ent["source_workbook_path"])
        csv = Path(ent["processed_csv"])
        if not wb.exists():
            print(f"[MISSING] {lid}: {wb}")
            continue
        src_md5 = D.md5sum(wb)
        prev = files.get(lid)
        if (not args.force and prev and prev.get("source_md5") == src_md5 and csv.exists()
                and D.md5sum(csv) == prev.get("csv_md5")):
            print(f"[skip ] {lid:24s} up to date ({prev['n_rows']} rows)")
            n_skipped += 1
            continue
        t0 = time.time()
        df, meta = D.read_workbook(wb)
        df.to_csv(csv, index=False)
        files[lid] = dict(
            logical_id=lid, cell=ent["cell"], temperature_C=ent["temperature_C"], test_type=ent["test_type"],
            profile=ent["profile"], start_soc_label=ent["start_soc_label"], split=ent["split"],
            source_zip=ent["source_zip"], source_folder=ent["source_folder"], source_workbook=ent["source_workbook"],
            source_md5=src_md5, source_size_bytes=os.path.getsize(wb),
            processed_csv=os.path.relpath(csv, ROOT).replace("\\", "/"), csv_md5=D.md5sum(csv),
            csv_size_bytes=os.path.getsize(csv),
            sheets=meta["sheets"], data_sheets=meta["data_sheets"], rows_per_sheet=meta["rows_per_sheet"],
            n_rows_raw=meta["n_rows_raw"], n_rows=meta["n_rows"],
            chunk_duplicate_rows_dropped=meta["chunk_duplicate_rows_dropped"],
            columns=list(df.columns), info_test_name=meta["info_test_name"], info_channel=meta["info_channel"],
            info_schedule_file=meta["info_schedule_file"], info_start_datetime=meta["info_start_datetime"],
            info_rows=meta["info_rows"], info_channels_listed=meta["info_channels_listed"],
            data_sheet_channel=meta["data_sheet_channel"],
            test_time_first_s=float(df["Test_Time(s)"].iloc[0]), test_time_last_s=float(df["Test_Time(s)"].iloc[-1]),
            step_indices=sorted(int(x) for x in df["Step_Index"].unique()), n_cycles=int(df["Cycle_Index"].max()),
        )
        n_built += 1
        print(f"[build] {lid:24s} {meta['n_rows_raw']:7d} raw rows -> {meta['n_rows']:7d} "
              f"(dropped {len(meta['chunk_duplicate_rows_dropped'])}) sheets={meta['data_sheets']} {time.time() - t0:5.1f} s")
    manifest = dict(
        generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        generator="scripts/00_convert_raw.py", n_files=len(files),
        columns=D.COLUMNS, chunk_rows_per_sheet=D.CHUNK_ROWS,
        note=("CSV = concatenation of the chunked data sheets in order; the last row of each chunk sheet is "
              "repeated as the first row of the next sheet in the Arbin export and has been dropped."),
        files={k: files[k] for k in D.LOGICAL_IDS if k in files},
    )
    with open(D.MANIFEST_PATH, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=1, default=str)
    print(f"\nmanifest: {D.MANIFEST_PATH}  files={len(manifest['files'])}  built={n_built}  skipped={n_skipped}")
    tot_raw = sum(f["n_rows_raw"] for f in manifest["files"].values())
    tot = sum(f["n_rows"] for f in manifest["files"].values())
    print(f"total rows: {tot_raw} raw -> {tot} after chunk de-duplication")
    return 0


if __name__ == "__main__":
    sys.exit(main())
