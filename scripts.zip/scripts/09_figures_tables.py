"""Every manuscript figure and table from the saved results (results/*.json, results/*.npz); no experiment is re-run.

Figures (label -> file; builder; saved results read):
    fig:architecture  figures/fig_architecture.tex      hand-written TikZ (checked, not generated)
    fig:relax         figures/fig_relax.pdf             09a_figs_ocv_relax.fig_relax   relaxation_phenomenological.json, relaxation_curves.npz
    fig:relax_acf     figures/fig_relax_acf.pdf         09a_figs_ocv_relax.fig_relax_acf (same sources; not in the contract)
    fig:ocv           figures/fig_ocv.pdf              09a_figs_ocv_relax.fig_ocv     ocv_fits.json, ocv_curves.npz
    fig:vmodel        figures/fig_vt_model.pdf          06_validate.fig_vt             validation_main.json, validation_series.npz
    fig:optimizers    figures/fig_ident_optimizers.pdf  fig_optimizers (this file)     identification.json, identification_arrays.npz
    fig:params_T      figures/fig_params_temperature.pdf 07_ablation.fig_params        ablation.json (+ identification_*.json via 07)
    fig:soc           figures/fig_soc_test.pdf          06_validate.fig_soc            validation_main.json, validation_series.npz
    fig:envelopes     figures/fig_error_envelopes.pdf   06_validate.fig_envelopes      validation_main.json, validation_series.npz
    fig:rmse_memory   figures/fig_rmse_memory.pdf       07_ablation.fig_memory         ablation.json
    fig:cost          figures/fig_cost_memory.pdf       08_cost.make_figure            cost.json
    fig:robustness    figures/fig_robustness.pdf        06b_robustness.make_figure     robustness.json
    fig:resid_acf     figures/fig_resid_acf.pdf         06_validate.fig_acf            validation_main.json, validation_series.npz
    fig:sensitivity   figures/fig_sensitivity.pdf       07_ablation.fig_sensitivity    ablation.json
Tables: the table writers of the analysis scripts (01 tables_only, 02 make_table, 03 make_tables, 04 make_tables,
05 write_table, 06 write_table, 06b write_table, 07 write_table, 08 write_table), called on the saved results.
tab_literature.tex is hand-written (literature data, reports/literature_comparison.json) and only checked.
tab_claims.tex is hand-written in the Integrate phase (claims-to-evidence map; reports/claims_to_evidence.md) and
only checked. tab_hyper no longer carries a storage column (state storage: tab_cost), so no data file is read.
Unit typesetting and wording of the generated tables: src/tfso/texfix.py (finalize_table).

One figure code path: the analysis scripts keep their figure functions and this script imports them, so a figure
is identical whether it is built here or at the end of its analysis script (04_identify delegates its optimiser
figure to fig_optimizers below). Style: src/tfso/plotstyle.py.

Usage (project root):
    python scripts/09_figures_tables.py                  # all figures and tables
    python scripts/09_figures_tables.py --only figures   # or: --only tables
    python scripts/09_figures_tables.py --png DIR        # also 200 dpi PNG previews of every figure in DIR
    python scripts/09_figures_tables.py --list           # contract (label, file, builder, sources), no output written
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from tfso import plotstyle as ps  # noqa: E402

RES, FIG, TAB = ROOT / "results", ROOT / "figures", ROOT / "tables"
TEMPS = (0, 25, 45)
OPTS = ("tfgd", "trf", "de", "cmaes")
OPT_SERIES = {"tfgd": "TFGD", "trf": "TRF", "de": "DE", "cmaes": "CMAES"}
_MODS: dict = {}


def script(name: str):
    """Import scripts/<name>.py once (module names start with digits, so importlib is used)."""
    if name not in _MODS:
        spec = importlib.util.spec_from_file_location("s" + name.replace("-", "_"), ROOT / "scripts" / f"{name}.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _MODS[name] = mod
    return _MODS[name]


def js(name: str) -> dict:
    with open(RES / name, encoding="utf-8") as fh:
        return json.load(fh)


# ================================================================================================================
# fig:optimizers (consolidated here from scripts/04_identify.py, now in the journal style)
# ================================================================================================================
def fig_optimizers(J: dict | None = None, A: dict | None = None, out: Path | None = None) -> Path:
    """Final and best-so-far voltage RMSE of the four optimisers (TFO model, identification files), log-log."""
    J = js("identification.json") if J is None else J
    A = dict(np.load(RES / "identification_arrays.npz")) if A is None else A
    out = FIG / "fig_ident_optimizers.pdf" if out is None else Path(out)
    plt = ps.setup()
    fig, axs = plt.subplots(2, 3, figsize=ps.figsize("text", 112), layout="constrained",
                            gridspec_kw=dict(height_ratios=[0.8, 1.0]))
    for j, T in enumerate(TEMPS):
        P = J["per_T"][str(T)]
        best = min(P["TFO_optimizers"][o]["best_rmse_mV"] for o in OPTS)
        ax = axs[0, j]
        rng = np.random.default_rng(0)                                # fixed jitter (presentation only)
        for i, o in enumerate(OPTS):
            v = np.asarray(A[f"final__{T}__{o}"], float)
            s = ps.SERIES[OPT_SERIES[o]]
            ax.plot(i + rng.uniform(-0.17, 0.17, v.size), v - best + 1e-3, ls="none", marker=s["marker"], ms=3.8,
                    mfc=s["color"], mec="white", mew=0.5, zorder=3)
        ax.set_yscale("log")
        ax.set_xticks(range(len(OPTS)))
        ax.set_xticklabels([ps.LABEL[OPT_SERIES[o]] for o in OPTS])
        ax.set_xlim(-0.5, len(OPTS) - 0.5)
        ax.grid(axis="x", visible=False)
        ax.set_title(f"{T} °C (best RMSE {best:.2f} mV)")
        if j == 0:
            ax.set_ylabel("final RMSE − best\n+ 1 µV (mV)")
        ps.panel_label(ax, j)
        ax = axs[1, j]
        for o in OPTS:
            s = ps.SERIES[OPT_SERIES[o]]
            for r, run in enumerate(P["TFO_optimizers"][o]["runs"]):
                tr = np.asarray(A[f"trace__{T}__{o}__{r}"], float)
                if tr.size:
                    x = np.append(tr[:, 0], run["nfev"])
                    y = np.append(tr[:, 1], tr[-1, 1]) - best + 1e-3
                    ax.step(x, y, where="post", color=s["color"], ls=s["ls"], lw=0.7, alpha=0.75,
                            label=ps.LABEL[OPT_SERIES[o]] if (r == 0 and j == 0) else None)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("objective evaluations (-)")
        if j == 0:
            ax.set_ylabel("best-so-far RMSE − best\n+ 1 µV (mV)")
        ps.panel_label(ax, 3 + j)
    h, lab = axs[1, 0].get_legend_handles_labels()
    for hh in h:
        hh.set_alpha(1.0)
        hh.set_linewidth(ps.LW["data"])
    fig.legend(h, lab, loc="outside upper center", ncol=4)
    p = ps.save(fig, out)
    plt.close(fig)
    return p


# ================================================================================================================
# Builders of the other figures (imported figure functions, saved results only)
# ================================================================================================================
def _fig09a(which: str) -> Path:
    plt = ps.setup()
    p = getattr(script("09a_figs_ocv_relax"), which)(plt)
    plt.close("all")
    return p


def _fig06(which: str) -> Path:
    m = script("06_validate")
    J, Z = m.load_outputs()
    getattr(m, which)(J, Z)
    return {"fig_vt": FIG / "fig_vt_model.pdf", "fig_soc": FIG / "fig_soc_test.pdf",
            "fig_envelopes": FIG / "fig_error_envelopes.pdf", "fig_acf": FIG / "fig_resid_acf.pdf"}[which]


def _ablation_figure_data() -> tuple[dict, dict]:
    """The figure data of scripts/07_ablation.py write_outputs (without its table and report)."""
    m = script("07_ablation")
    J = js("ablation.json")
    fd = J["figure_data"]
    fd["sensitivity"] = m.sensitivity_data(J)
    fd["params_T"] = m.params_T_data(J)
    dur = {str(T): float(np.median([f["duration_s"] for f in J["test"]["files"] if f["T"] == T])) for T in TEMPS}
    dur["all"] = float(np.median([f["duration_s"] for f in J["test"]["files"]]))
    return fd, dur


def _fig07(which: str) -> Path:
    m = script("07_ablation")
    fd, dur = _ablation_figure_data()
    if which == "fig_memory":
        return m.fig_memory(fd["memory"], dur)
    if which == "fig_sensitivity":
        return m.fig_sensitivity(fd["sensitivity"])
    return m.fig_params(fd["params_T"])


def _fig06b() -> Path:
    script("06b_robustness").make_figure(js("robustness.json"))
    return FIG / "fig_robustness.pdf"


def _fig08() -> Path:
    script("08_cost").make_figure(js("cost.json"))
    return FIG / "fig_cost_memory.pdf"


def _check_tex(path: str) -> Path:
    p = ROOT / path
    if not p.exists():
        raise FileNotFoundError(path)
    return p


VS = ["results/validation_main.json", "results/validation_series.npz"]
FIGURES = [  # label, file, builder, sources, code
    ("fig:architecture", "figures/fig_architecture.tex", lambda: _check_tex("figures/fig_architecture.tex"), [],
     "hand-written TikZ"),
    ("fig:relax", "figures/fig_relax.pdf", lambda: _fig09a("fig_relax"),
     ["results/relaxation_phenomenological.json", "results/relaxation_curves.npz"], "09a_figs_ocv_relax.fig_relax"),
    ("fig:relax_acf", "figures/fig_relax_acf.pdf", lambda: _fig09a("fig_relax_acf"),
     ["results/relaxation_phenomenological.json", "results/relaxation_curves.npz"],
     "09a_figs_ocv_relax.fig_relax_acf"),
    ("fig:ocv", "figures/fig_ocv.pdf", lambda: _fig09a("fig_ocv"),
     ["results/ocv_fits.json", "results/ocv_curves.npz", "config/config.yaml"], "09a_figs_ocv_relax.fig_ocv"),
    ("fig:vmodel", "figures/fig_vt_model.pdf", lambda: _fig06("fig_vt"), VS, "06_validate.fig_vt"),
    ("fig:optimizers", "figures/fig_ident_optimizers.pdf", lambda: fig_optimizers(),
     ["results/identification.json", "results/identification_arrays.npz"], "09_figures_tables.fig_optimizers"),
    ("fig:params_T", "figures/fig_params_temperature.pdf", lambda: _fig07("fig_params"),
     ["results/ablation.json", "results/identification.json", "results/identification_refined.json",
      "results/frozen_config.json", "results/relaxation_phenomenological.json"], "07_ablation.fig_params"),
    ("fig:soc", "figures/fig_soc_test.pdf", lambda: _fig06("fig_soc"), VS, "06_validate.fig_soc"),
    ("fig:envelopes", "figures/fig_error_envelopes.pdf", lambda: _fig06("fig_envelopes"), VS,
     "06_validate.fig_envelopes"),
    ("fig:rmse_memory", "figures/fig_rmse_memory.pdf", lambda: _fig07("fig_memory"), ["results/ablation.json"],
     "07_ablation.fig_memory"),
    ("fig:cost", "figures/fig_cost_memory.pdf", _fig08, ["results/cost.json"], "08_cost.make_figure"),
    ("fig:robustness", "figures/fig_robustness.pdf", _fig06b, ["results/robustness.json"],
     "06b_robustness.make_figure"),
    ("fig:resid_acf", "figures/fig_resid_acf.pdf", lambda: _fig06("fig_acf"), VS, "06_validate.fig_acf"),
    ("fig:sensitivity", "figures/fig_sensitivity.pdf", lambda: _fig07("fig_sensitivity"), ["results/ablation.json"],
     "07_ablation.fig_sensitivity"),
]


# ================================================================================================================
# Tables (writers of the analysis scripts on the saved results)
# ================================================================================================================
def _tab01():
    script("01_audit").tables_only()


def _tab02():
    script("02_ocv").make_table(RES / "ocv_fits.json", TAB / "tab_ocv.tex")


def _tab03():
    m = script("03_relaxation")
    m.make_tables(js("relaxation_phenomenological.json"), js("relaxation_mechanistic.json"),
                  dict(np.load(RES / "relaxation_curves.npz")))


TABLES = [  # labels, file(s), writer, sources, code
    (["tab:dataset_inventory", "tab:split_assignment"], ["tables/tab_dataset_inventory.tex",
                                                          "tables/tab_split_assignment.tex"], _tab01,
     ["results/dataset_inventory.json"], "01_audit.write_tables"),
    (["tab:ocv"], ["tables/tab_ocv.tex"], _tab02, ["results/ocv_fits.json"], "02_ocv.make_table"),
    (["tab:relax_ic", "tab:relax_params", "tab:relax_design"],
     ["tables/tab_relax_ic.tex", "tables/tab_relax_params.tex", "tables/tab_relax_design.tex"], _tab03,
     ["results/relaxation_phenomenological.json", "results/relaxation_mechanistic.json",
      "results/relaxation_curves.npz"], "03_relaxation.make_tables"),
    (["tab:params", "tab:vmodel"], ["tables/tab_params.tex", "tables/tab_vmodel.tex"],
     lambda: script("04_identify").make_tables(js("identification.json"), TAB), ["results/identification.json"],
     "04_identify.make_tables"),
    (["tab:hyper"], ["tables/tab_hyper.tex"],
     lambda: script("05_design_tune").write_table(js("frozen_config.json"), js("gain_design.json")),
     ["results/frozen_config.json", "results/gain_design.json"],
     "05_design_tune.write_table"),
    (["tab:soc_results"], ["tables/tab_soc_results.tex"],
     lambda: script("06_validate").write_table(js("validation_main.json")), ["results/validation_main.json"],
     "06_validate.write_table"),
    (["tab:robustness", "tab:robustness_fail", "tab:robustness_diag"], ["tables/tab_robustness.tex"],
     lambda: script("06b_robustness").write_table(js("robustness.json")), ["results/robustness.json"],
     "06b_robustness.write_table"),
    (["tab:cost"], ["tables/tab_cost.tex"], lambda: script("08_cost").write_table(js("cost.json")),
     ["results/cost.json"], "08_cost.write_table"),
    (["tab:ablation"], ["tables/tab_ablation.tex"], lambda: script("07_ablation").write_table(js("ablation.json")),
     ["results/ablation.json"], "07_ablation.write_table"),
    (["tab:literature"], ["tables/tab_literature.tex"], lambda: _check_tex("tables/tab_literature.tex"),
     ["reports/literature_comparison.json"], "hand-written (checked only)"),
    (["tab:claims", "tab:claims_cont"], ["tables/tab_claims.tex"], lambda: _check_tex("tables/tab_claims.tex"),
     ["reports/claims_to_evidence.md"], "hand-written in the Integrate phase (checked only)"),
]


# Probe keys of the measured CALCE channels (voltage/time); the public copy of the archives omits them
# (scripts/make_release.py, MEASURED), so the two figures drawn from them are skipped there with a message.
MEASURED_PROBE = {"relaxation_curves.npz": "fits__SP1_IC_OCV_0C__t_full",
                  "identification_arrays.npz": "acc__SP2_0C_DST_80SOC__t",
                  "validation_series.npz": "SP2_25C_FUDS_80SOC|t_V"}


def measured_stripped() -> list:
    """Result archives from which the measured CALCE channels were removed (empty in the authors' project)."""
    out = []
    for f, key in MEASURED_PROBE.items():
        if (RES / f).exists() and key not in np.load(RES / f, allow_pickle=False).files:
            out.append(f)
    return out


def _sources_ok(srcs: list) -> list:
    return [s for s in srcs if "*" not in s and " " not in s and not (ROOT / s).exists()]


def check_labels() -> list:
    """Every table file carries the contract labels; returns the problems found."""
    bad = []
    for labels, files, _, _, code in TABLES:
        txt = "".join((ROOT / f).read_text(encoding="utf-8") for f in files if (ROOT / f).exists())
        if not txt:
            if "Integrate" not in code:
                bad.append(f"missing {files}")
            continue
        bad += [f"{lab} not in {files}" for lab in labels if f"\\label{{{lab}}}" not in txt]
        if "\\resizebox" in txt:
            bad.append(f"{files}: resizebox used")
    return bad


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--only", choices=("figures", "tables"), default=None)
    ap.add_argument("--png", default=None, help="directory for 200 dpi PNG previews of the figures")
    ap.add_argument("--list", action="store_true", help="print the contract and the source check, write nothing")
    a = ap.parse_args()
    missing = sorted({s for row in FIGURES for s in _sources_ok(row[3])}
                     | {s for row in TABLES for s in _sources_ok(row[3])})
    if a.list:
        for lab, f, _, src, code in FIGURES:
            print(f"{lab:18s} {f:38s} {code:34s} {', '.join(src)}")
        for labs, fs, _, src, code in TABLES:
            print(f"{'/'.join(labs):18s} {', '.join(fs):38s} {code:34s} {', '.join(src)}")
        print("missing sources:", missing or "none")
        return 0
    if missing:
        print("missing saved results:", ", ".join(missing))
        return 1
    log, skipped = [], []
    if a.only in (None, "figures"):
        for lab, f, build, _, code in FIGURES:
            t0 = time.perf_counter()
            try:
                p = Path(build())
            except KeyError as e:
                stripped = measured_stripped()
                if not stripped:
                    raise
                skipped.append(lab)
                print(f"[figure] {lab:18s} SKIPPED: needs the measured CALCE channels, absent from "
                      f"{', '.join(stripped)} ({e}); download the data and re-run the analysis (README)", flush=True)
                continue
            log.append((lab, f, time.perf_counter() - t0))
            print(f"[figure] {lab:18s} {p.relative_to(ROOT)}  ({log[-1][2]:.1f} s, {code})", flush=True)
            if a.png and p.suffix == ".pdf":
                d = Path(a.png)
                d.mkdir(parents=True, exist_ok=True)
                ps.preview_png(p, out=d / (p.stem + ".png"))
    if a.only in (None, "tables"):
        for labs, fs, write, _, code in TABLES:
            t0 = time.perf_counter()
            write()
            print(f"[table ] {'/'.join(labs):18s} {', '.join(fs)}  ({time.perf_counter() - t0:.1f} s, {code})",
                  flush=True)
        bad = check_labels()
        print("table label check:", "ok" if not bad else "; ".join(bad))
        if bad and any("Integrate" not in b for b in bad):
            return 1
    if skipped:
        print(f"figures skipped (measured CALCE channels not in the result archives): {', '.join(skipped)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
