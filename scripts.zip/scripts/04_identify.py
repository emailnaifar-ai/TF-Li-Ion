"""Model identification study: TFO / FO / FO(alpha_TFO) / RCL / 2RC voltage models on SP2 dynamic data.

Splits (config splits): identification = SP2_{0,25,45}C_DST_80SOC (fit), validation = SP2_*_DST_50SOC (evaluation
only; no hyper-parameter of this study is tuned), test = 18 FUDS/US06/BJDST files (evaluation only).

Primary analysis: input timing 'causal' (every dynamic branch of every family driven by the current held on
[t_{n-1}, t_n); src/tfso/model.py TIMING), objective = RMSE over the whole profile window.
Sensitivity analyses (review 2026-09-27): three other input-timing conventions (TRF multistart, all families), the
knee-excluded window z >= z_min (all families, lambda/alpha profiles, bootstrap), R_p upper bound relaxed (TFO),
bootstrap block length.

Writes
    results/identification.json            all runs, fits, sensitivity, uncertainty, accuracy, verdicts
    results/identification_arrays.npz      every plotted array (traces, profiles, bootstrap draws, residual ACFs, V_t)
    results/identification_runs/*.json|npz per-task caches (with a config/code hash; --resume reuses matching caches)
    figures/fig_ident_optimizers.pdf, fig_ident_profile.pdf, fig_ident_corr.pdf, fig_ident_params_T.pdf,
    figures/fig_ident_timing.pdf, fig_vmodel_fit.pdf, fig_vmodel_acf.pdf, fig_vmodel_rmse.pdf
    tables/tab_params.tex, tables/tab_vmodel.tex
    reports/identification_findings.md     generated from results/identification.json (+ the review-response section)

Usage (project root):  python scripts/04_identify.py [--resume] [--from-results] [--smoke DIR]
    --from-results regenerates figures, tables and the report from identification.json + identification_arrays.npz
    only (no cache is read).
"""
from __future__ import annotations

import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse
import hashlib
import json
import math
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfso import data as D  # noqa: E402
from tfso import identify as ID  # noqa: E402
from tfso import model as MD  # noqa: E402

RES, FIG, TAB, REP = ROOT / "results", ROOT / "figures", ROOT / "tables", ROOT / "reports"
TEMPS = (0, 25, 45)
FAMS = ("TFO", "FO", "FO_alphaTFO", "RCL", "2RC")
OPTS = ("tfgd", "trf", "de", "cmaes")
SMOKE = os.environ.get("TFSO_IDENT_SMOKE") or None
TASK_VERSION = "2026-09-27-review-2"


def outdirs():
    if SMOKE:
        p = Path(SMOKE)
        return p, p, p, p
    return RES, FIG, TAB, REP


def cachedir() -> Path:
    d = outdirs()[0] / "identification_runs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def jconv(o):
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    raise TypeError(type(o))


def jdump(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=1, default=jconv)


def cfg():
    c = D.load_config()
    s = dict(c["identification_study"])
    if SMOKE:
        s = json.loads(json.dumps(s))
        s["eval_budget"], s["multistart"], s["trf_max_nfev"] = 60, 2, 60
        s["bootstrap_v2"]["n_boot"], s["bootstrap_v2"]["n_boot_sensitivity"] = 2, 2
        s["profile_v2"]["lambda_grid"] = [0.0, 1e-4, 1e-2]
        s["profile_v2"]["alpha_grid"] = [0.5, 1.0]
        s["profile_v2"]["max_nfev"] = 60
    return c, s


def primary_timing() -> str:
    return cfg()[1]["input_timing"]["primary"]


def sens_timings() -> list[str]:
    return list(cfg()[1]["input_timing"]["sensitivity"])


def code_hash() -> str:
    """Hash of the study settings, the model/identification/data code, the upstream result files and TASK_VERSION."""
    _, s = cfg()
    h = hashlib.sha256()
    h.update(json.dumps(s, sort_keys=True, default=str).encode())
    h.update(TASK_VERSION.encode())
    for f in ("src/tfso/model.py", "src/tfso/identify.py", "src/tfso/tempered.py", "src/tfso/data.py", "src/tfso/ocv.py",
              "results/capacity.json", "results/ocv_fits.json"):
        h.update((ROOT / f).read_bytes())
    return h.hexdigest()[:16]


def q_id(T: int) -> float:
    with open(RES / "capacity.json", "r", encoding="utf-8") as fh:
        return float(json.load(fh)["Q_id_T_SP2"][str(T)]["Q_id_Ah"])


def load(lid: str) -> tuple[MD.History, MD.AlignedOCV, dict]:
    """verify_file (raises on failure) + warm-start history with Q_id(T) + aligned OCV at the file's T."""
    df = D.load_raw(lid)
    chk = D.verify_file(lid, df=df)
    T = int(D.CATALOG[lid]["temperature_C"])
    Q = q_id(T)
    c, s = cfg()
    H = MD.build_history(lid, Q, h=float(s["h_s"]), df=df)
    ocv = MD.AlignedOCV(T, Q, extrapolation=s["ocv_extrapolation"])
    return H, ocv, dict(logical_id=lid, verified=bool(chk["passed"]), split=D.CATALOG[lid].get("split"))


def id_file(T: int) -> str:
    c = D.load_config()
    return [l for l in c["splits"]["identification_dynamic"] if D.CATALOG[l]["temperature_C"] == T][0]


def knee_mask(H: MD.History, s: dict) -> np.ndarray:
    return H.z[H.prof] >= float(s["knee_window"]["z_min"])


def window_mask(H, s, window):
    return None if window == "full" else knee_mask(H, s)


def thin_trace(tr, k=200):
    if len(tr) <= k:
        return tr
    idx = np.unique(np.round(np.linspace(0, len(tr) - 1, k)).astype(int))
    return [tr[i] for i in idx]


def resid_dependence(r: np.ndarray, s: dict, h: float) -> dict:
    """AR(1) and Bartlett-HAC effective sample sizes of a residual series."""
    nc = s["neff"]
    out = dict(n=int(r.size), ar1=ID.neff_ar1(r), hac=ID.neff_hac(r, int(nc["bandwidth_s"] / h)),
               hac_sensitivity={str(b): ID.neff_hac(r, int(b / h)) for b in nc["sensitivity_bandwidth_s"]})
    out["tau"] = out["hac"]["tau"]
    return out


def bounds_with(s: dict, override: dict | None):
    B = json.loads(json.dumps(s["bounds"]))
    for k, v in (override or {}).items():
        B[k] = v
    return B


# ======================================================================================
# Worker tasks (each writes a cache with the code hash)
# ======================================================================================
ABBR = {"causal": "c", "implicit_forward": "if", "legacy_mixed": "lm", "causal_point_output": "cp", "full": "F",
        "knee": "K", "rp_relaxed": "rpx", "": ""}


def cache_name(kind: str, **kw) -> str:
    """Short file names (Windows MAX_PATH): values abbreviated, keys sorted."""
    return kind + "_" + "_".join(str(ABBR.get(kw[k], kw[k])) for k in sorted(kw) if str(ABBR.get(kw[k], kw[k]))) + ".json"


def save_cache(name: str, obj: dict):
    obj = dict(obj, code_hash=code_hash())
    jdump(obj, cachedir() / name)
    return obj


def load_cache(name: str):
    p = cachedir() / name
    if p.exists():
        with open(p, "r", encoding="utf-8") as fh:
            o = json.load(fh)
        if o.get("code_hash") == code_hash():
            return o
        print(f"[cache] {name}: code/config hash mismatch -> recomputed", flush=True)
    return None


def task_runs(T: int, fam: str, opt: str, timing: str, window: str, fixed: dict | None = None,
              bounds_override: dict | None = None, label: str = "") -> dict:
    """Multistart runs of one optimiser for one model family at one temperature (identification file)."""
    c, s = cfg()
    lid = id_file(T)
    H, ocv, ver = load(lid)
    B = bounds_with(s, bounds_override)
    mask = window_mask(H, s, window)
    prob = ID.Problem(fam, H, ocv, B, fixed=fixed, lam_scale=float(s["lambda_asinh_scale"]), timing=timing, mask=mask)
    ti, fi = TEMPS.index(T), FAMS.index(fam)
    lhs_seed = int(s["seeds"]["lhs"]) + 100 * ti + fi
    starts = ID.lhs_starts(prob.p, int(s["multistart"]), lhs_seed)
    tc, budget = c["identification"]["tfgd"], int(s["eval_budget"])
    st = s["tfgd"]
    runs = []
    for r, u0 in enumerate(starts):
        if opt == "trf":
            out = ID.run_trf(prob, u0, max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]),
                             xtol=float(c["identification"]["trf"]["xtol"]), ftol=float(c["identification"]["trf"]["ftol"]))
        elif opt == "tfgd":
            out = ID.run_tfgd(prob, u0, float(tc["order_nu"]), float(tc["tempering_lambda_g"]), float(tc["step"]),
                              int(tc["max_iter"]), float(tc["tol_rel"]), budget, armijo_c=float(st["armijo_c"]),
                              backtrack=float(st["backtrack_factor"]), max_backtracks=int(st["max_backtracks"]),
                              fd_step=float(st["fd_step"]), stall_window=int(st["stall_window"]))
        elif opt == "de":
            dc = c["identification"]["de"]
            out = ID.run_de(prob, int(s["seeds"]["de"]) + r, budget, popsize=int(dc["popsize"]), tol=float(dc["tol"]),
                            strategy=dc["strategy"])
        elif opt == "cmaes":
            cc = c["identification"]["cmaes"]
            out = ID.run_cmaes(prob, u0, int(s["seeds"]["cmaes"]) + r, budget, sigma0=float(cc["sigma0"]),
                               popsize=int(cc["popsize"]))
        out.update(run=r, start_u=[float(x) for x in u0], lhs_seed=lhs_seed, optimizer=opt)
        out["trace"] = thin_trace(out["trace"])
        runs.append(out)
    b = min(runs, key=lambda q: q["rmse_mV"])
    rr = prob.model_V(b["theta"]) - prob.target
    res = dict(T=T, family=fam, optimizer=opt, timing=timing, window=window, label=label, file=ver, free=prob.free,
               fixed=prob.fixed, bounds=B, n_scored=prob.n, runs=runs, best_residual=resid_dependence(rr, s, H.h))
    return save_cache(cache_name("runs", T=T, fam=fam, opt=opt, timing=timing, window=window, label=label), res)


def best_of(runs: list[dict]) -> dict:
    return min(runs, key=lambda r: r["rmse_mV"])


def task_profile(T: int, window: str, pname: str, theta_hat: dict) -> dict:
    """Profile likelihood of lambda or alpha (TFO, primary timing) on the given window; LR with iid and HAC n_eff."""
    c, s = cfg()
    t0 = time.perf_counter()
    tm = primary_timing()
    H, ocv, _ = load(id_file(T))
    B, ls = s["bounds"], float(s["lambda_asinh_scale"])
    mask = window_mask(H, s, window)
    g = MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    pc = s["profile_v2"]
    prob = ID.Problem("TFO", H, ocv, B, lam_scale=ls, grid=g, timing=tm, mask=mask)
    r_hat = prob.model_V(theta_hat) - prob.target
    dep = resid_dependence(r_hat, s, H.h)
    n, tau = dep["n"], dep["tau"]
    rmse_hat = float(np.sqrt(np.mean(r_hat ** 2)) * 1e3)
    gv = pc["lambda_grid"] if pname == "lam" else pc["alpha_grid"]
    extra = pc["extra_starts_lambda"] if pname == "lam" else pc["extra_starts_alpha"]
    rows = ID.profile_likelihood("TFO", H, ocv, B, theta_hat, pname, gv, lam_scale=ls, fft_grid=g,
                                 max_nfev=int(pc["max_nfev"]), diff_step=float(s["trf_diff_step"]), timing=tm, mask=mask,
                                 extra_starts=extra)
    rm = min(min(r["rmse_mV"] for r in rows), rmse_hat)
    for r in rows:
        r["LR_nominal"] = 2 * n * math.log(r["rmse_mV"] / rm)
        r["LR_eff"] = r["LR_nominal"] / tau
        r["LR_eff_ar1"] = r["LR_nominal"] * dep["ar1"]["n_eff"] / n
    vals = [r["value"] for r in rows]
    zc = float(pc["crit_zero"]) if pname == "lam" else None
    ci_eff = ID.profile_interval(vals, [r["LR_eff"] for r in rows], float(pc["crit_interior"]), log=pname == "lam", zero_crit=zc)
    ci_nom = ID.profile_interval(vals, [r["LR_nominal"] for r in rows], float(pc["crit_interior"]), log=pname == "lam", zero_crit=zc)
    out = dict(T=T, window=window, pname=pname, theta_hat=theta_hat, rmse_hat_mV=rmse_hat, rmse_min_mV=rm,
               profile_found_lower=bool(rm < rmse_hat - 1e-6), dependence=dep, rows=rows, ci_eff=ci_eff, ci_nominal=ci_nom,
               n_unconverged=int(sum(not r["converged"] for r in rows)),
               n_best_from_cold_start=int(sum(r["best_start"].startswith("cold") for r in rows)),
               crit_interior=float(pc["crit_interior"]), crit_zero=zc, wall_s=time.perf_counter() - t0)
    if pname == "lam":
        r0 = [r for r in rows if r["value"] == 0.0][0]
        out["zero_test"] = dict(LR_nominal=r0["LR_nominal"], LR_eff=r0["LR_eff"], LR_eff_ar1=r0["LR_eff_ar1"],
                                rmse_at_0_mV=r0["rmse_mV"], delta_rmse_mV=r0["rmse_mV"] - rm,
                                excludes_0_eff=bool(r0["LR_eff"] > zc), excludes_0_nominal=bool(r0["LR_nominal"] > zc),
                                excludes_0_ar1=bool(r0["LR_eff_ar1"] > zc))
    return save_cache(cache_name("profile", T=T, window=window, p=pname), out)


BOOT_SPECS = [  # name, family, window, block key, n key, two starts
    ("TFO_full", "TFO", "full", "block_s", "n_boot", True),
    ("FO_full", "FO", "full", "block_s", "n_boot", False),
    ("2RC_full", "2RC", "full", "block_s", "n_boot", False),
    ("TFO_knee", "TFO", "knee", "block_s", "n_boot", True),
    ("TFO_full_L0", "TFO", "full", 0, "n_boot_sensitivity", True),
    ("TFO_full_L1", "TFO", "full", 1, "n_boot_sensitivity", True),
]


def derived(fam: str, th: dict, tm: str, h: float = 1.0) -> dict:
    if fam == "2RC":
        p = MD.TwoRCParams(**{k: th[k] for k in ("R0", "R1", "tau1", "R2", "tau2", "s", "dq")})
    else:
        p = MD.TFOParams(**{k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})
    return MD.step_response(p, tm, h)


def task_boot(T: int, spec_i: int, theta_hat: dict) -> dict:
    """Local-scale circular block bootstrap of the residuals (config bootstrap_v2) with TRF refits."""
    c, s = cfg()
    t0 = time.perf_counter()
    name, fam, window, bkey, nkey, two = BOOT_SPECS[spec_i]
    bc = s["bootstrap_v2"]
    L_s = float(bc["block_s"]) if bkey == "block_s" else float(bc["block_sensitivity_s"][bkey])
    nb = int(bc[nkey])
    tm = primary_timing()
    H, ocv, _ = load(id_file(T))
    B, ls = s["bounds"], float(s["lambda_asinh_scale"])
    mask = window_mask(H, s, window)
    g = None if fam == "2RC" else MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    fixed = {"lam": 0.0} if fam == "FO" else None
    pf = ID.Problem(fam, H, ocv, B, fixed=fixed, lam_scale=ls, grid=g, timing=tm, mask=mask)
    Vhat = pf.model_V(theta_hat)
    e = pf.target - Vhat
    zw = H.z[H.prof] if mask is None else H.z[H.prof][mask]
    sig, table = ID.local_scale(e, zw, int(bc["n_scale_bins"]))
    L = int(round(L_s / H.h))
    rng = np.random.default_rng(int(s["seeds"]["bootstrap"]) + 1000 * TEMPS.index(T) + 10 * spec_i)
    th2 = None
    if two:
        th2 = dict(theta_hat, lam=float(bc["extra_start_lambda"]) if theta_hat["lam"] < 1e-4 else 0.0)
    draws, rms, conv, from2, der = [], [], [], [], []
    for b in range(nb):
        Vs = Vhat + ID.wild_block_resample(e, sig, L, rng)
        pb = ID.Problem(fam, H, ocv, B, fixed=fixed, lam_scale=ls, V_target=Vs, grid=g, timing=tm, mask=mask)
        cands = [theta_hat] + ([th2] if th2 is not None else [])
        best, k2 = None, False
        for k, th0 in enumerate(cands):
            rr = ID.run_trf(pb, pb.to_u(th0), max_nfev=int(s["trf_max_nfev"]), diff_step=float(s["trf_diff_step"]))
            if best is None or rr["rmse_mV"] < best["rmse_mV"] - 1e-9:
                best, k2 = rr, k == 1
        t_ = dict(best["theta"])
        if fam == "2RC":
            t_ = MD.TwoRCParams(**{k: t_[k] for k in ("R0", "R1", "tau1", "R2", "tau2", "s", "dq")}).sorted().to_dict()
        draws.append(t_); rms.append(best["rmse_mV"]); conv.append(best["converged"]); from2.append(k2)
        der.append(derived(fam, t_, tm, H.h))
    keys = [k for k in draws[0] if k in ID.FAMILY_FREE[fam]]
    tol = float(bc["at_bound_unit_tol"])
    stats = {}
    for k in keys + ["R_1s_Ohm", "R_dc_Ohm", "R_0s_Ohm"]:
        v = np.array([d[k] for d in draws]) if k in keys else np.array([d[k] for d in der])
        st = dict(ci95=[float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))], median=float(np.median(v)))
        if k in keys:
            u = np.array([ID.unit_position(k, x, B, ls) for x in v])
            st["frac_at_lower"] = float(np.mean(u <= tol)); st["frac_at_upper"] = float(np.mean(u >= 1 - tol))
        else:
            st["frac_at_lower"] = st["frac_at_upper"] = 0.0
        st["ci_valid"] = bool(st["frac_at_lower"] + st["frac_at_upper"] <= float(bc["max_frac_at_bound_for_ci"]))
        stats[k] = st
    rmse_hat = float(np.sqrt(np.mean(e ** 2)) * 1e3)
    out = dict(T=T, spec=name, family=fam, window=window, block_s=L_s, n_boot=nb, two_starts=two,
               scale_table=table, stats=stats, draws={k: [d[k] for d in draws] for k in keys},
               derived_draws={k: [d[k] for d in der] for k in ("R_0s_Ohm", "R_1s_Ohm", "R_dc_Ohm")},
               rmse_mV=rms, rmse_hat_mV=rmse_hat, rmse_quantiles_mV=[float(np.percentile(rms, q)) for q in (5, 50, 95)],
               n_converged=int(sum(conv)), n_best_from_second_start=int(sum(from2)), wall_s=time.perf_counter() - t0)
    return save_cache(cache_name("boot", T=T, spec=name), out)


def task_diag(T: int, th_full: dict, th_knee: dict) -> dict:
    """Residual structure of the primary TFO fit and Jacobian correlations (whole and knee-excluded windows)."""
    c, s = cfg()
    tm = primary_timing()
    H, ocv, _ = load(id_file(T))
    B, ls = s["bounds"], float(s["lambda_asinh_scale"])
    g = MD.FFTGrid(H.I.size, int(s["fft"]["oversample"]), float(s["fft"]["r_pow_M"]))
    out = dict(T=T)
    names = ["alpha", "lam", "R0", "Rp", "Cp", "s", "dq"]
    tolu = float(s["near_bound_unit_tol"])
    for window, th in (("full", th_full), ("knee", th_knee)):
        mask = window_mask(H, s, window)
        prob = ID.Problem("TFO", H, ocv, B, lam_scale=ls, grid=g, timing=tm, mask=mask)
        r = prob.model_V(th) - prob.target
        d = dict(dependence=resid_dependence(r, s, H.h))
        a = ID.acf(r, 2000)
        d["acf_at_lag_s"] = {str(k): float(a[k]) for k in (1, 30, 180, 360, 720)}
        if window == "full":
            z = H.z[H.prof]
            dec = np.array_split(np.arange(r.size), 10)
            d["rms_by_time_decile_mV"] = [float(np.sqrt(np.mean(r[i] ** 2)) * 1e3) for i in dec]
            kz = z < float(s["knee_window"]["z_min"])
            d["share_SSE_below_knee"] = float(np.sum(r[kz] ** 2) / np.sum(r ** 2))
            d["frac_samples_below_knee"] = float(kz.mean())
        J = ID.jacobian_natural("TFO", H, ocv, B, th, names, lam_scale=ls, grid=g, timing=tm, mask=mask)
        cj = ID.correlation_from_J(J)
        upos = {n: ID.unit_position(n, th[n], B, ls) for n in names}
        free = [n for n in names if tolu < upos[n] < 1 - tolu]
        cf = ID.correlation_from_J(J[:, [names.index(n) for n in free]])
        d["jacobian"] = dict(names=names, corr_all=cj["corr"], cond_all=cj["cond_scaled"], free=free,
                             active_or_near_bound=[n for n in names if n not in free], corr_free=cf["corr"],
                             cond_free=cf["cond_scaled"], weakest_direction_free=cf["weakest_direction"])
        out[window] = d
        out[f"acf_{window}"] = a[:721]
    np.savez_compressed(cachedir() / f"diag_{T}C.npz", acf_full=out.pop("acf_full"), acf_knee=out.pop("acf_knee"))
    return save_cache(cache_name("diag", T=T), out)


def evaluate(fam: str, theta: dict, H: MD.History, ocv: MD.AlignedOCV, s: dict, timing: str, grid=None,
             full_stats: bool = True):
    """Open-loop accuracy on the profile window (reference-SOC-free: Coulomb counting with Q_id from the anchor)."""
    prob = ID.Problem(fam, H, ocv, s["bounds"], fixed={k: theta[k] for k in ("alpha", "lam") if fam != "2RC"},
                      grid=grid, timing=timing, lam_scale=float(s["lambda_asinh_scale"]))
    V = prob.model_V(theta)
    r = V - H.V[H.prof]
    m = knee_mask(H, s)
    if not full_stats:
        return dict(rmse_mV=float(np.sqrt(np.mean(r ** 2)) * 1e3),
                    rmse_z_ge_knee_mV=float(np.sqrt(np.mean(r[m] ** 2)) * 1e3)), None
    a = s["accuracy"]
    st, acf = ID.residual_stats(r, int(a["ljung_box_lags"]), a["quantiles"], int(a["acf_max_lag"] / H.h))
    st["rmse_z_ge_knee_mV"] = float(np.sqrt(np.mean(r[m] ** 2)) * 1e3)
    st["max_abs_z_ge_knee_mV"] = float(np.max(np.abs(r[m])) * 1e3)
    st["frac_samples_z_below_knee"] = float(1 - m.mean())
    st["frac_ocv_extrapolated"] = ocv.frac_outside(H.z[H.prof], theta["s"], theta["dq"])
    return st, dict(V=V.astype(np.float32), acf=acf.astype(np.float32))


def task_post(T: int, fits: dict) -> dict:
    """Unit checks and open-loop accuracy on all SP2 dynamic files at T.
    fits: {'primary': {fam: theta}, '<timing>': {fam: theta} (sensitivity), 'knee': {fam: theta}}."""
    c, s = cfg()
    t0 = time.perf_counter()
    tm = primary_timing()
    fs = s["fft"]
    files = [l for l in (c["splits"]["identification_dynamic"] + c["splits"]["validation_dynamic"] + c["splits"]["test_dynamic"])
             if D.CATALOG[l]["temperature_C"] == T]
    loaded = {l: load(l) for l in files}
    lid = id_file(T)
    uc = MD.unit_check(loaded[lid][0], oversample=int(fs["oversample"]), r_pow_M=float(fs["r_pow_M"]),
                       tol=float(fs["validation_tol_V"]))
    # identified parameter sets (all families), full memory and N_L = unit_check_N_L, primary and M4b timings,
    # on the identification record and on the longest test record at T
    test_l = max((l for l in files if loaded[l][2]["split"] == "test"), key=lambda l: loaded[l][0].I.size)
    cases = []
    for fam in FAMS:
        th = fits["primary"][fam]
        for timing in (tm, "implicit_forward"):
            if fam == "2RC":
                cases.append(dict(label=fam, params=MD.TwoRCParams(**{k: th[k] for k in ("R0", "R1", "tau1", "R2", "tau2", "s", "dq")}),
                                  N_L=None, timing=timing))
                continue
            p = MD.TFOParams(**{k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})
            for NL in [None] + [int(x) for x in s["unit_check_N_L"]]:
                cases.append(dict(label=fam, params=p, N_L=NL, timing=timing))
    uci = MD.unit_check_identified([loaded[lid][0], loaded[test_l][0]], cases,
                                   {lid: loaded[lid][1], test_l: loaded[test_l][1]}, tol=float(fs["validation_tol_V"]),
                                   oversample=int(fs["oversample"]), r_pow_M=float(fs["r_pow_M"]))
    acc, acc_sens, arrays, fileinfo = {}, {}, {}, {}
    for l in files:
        Hl, ocvl, ver = loaded[l]
        g = MD.FFTGrid(Hl.I.size, int(fs["oversample"]), float(fs["r_pow_M"]))
        fileinfo[l] = dict(ver, profile=D.CATALOG[l].get("profile"), start_soc=D.CATALOG[l].get("start_soc_label"),
                           n_profile=int(Hl.meta["n_profile"]), n_history=int(Hl.meta["n_history"]),
                           z_profile_start=Hl.meta["z_profile_start"], z_profile_end=Hl.meta["z_profile_end"],
                           history_steps_s=Hl.meta["history_steps"])
        acc[l], acc_sens[l] = {}, {}
        arrays[f"{l}__t"] = Hl.t[Hl.prof].astype(np.float32)
        arrays[f"{l}__Vmeas"] = Hl.V[Hl.prof].astype(np.float32)
        arrays[f"{l}__I"] = Hl.I[Hl.prof].astype(np.float32)
        arrays[f"{l}__z"] = Hl.z[Hl.prof].astype(np.float32)
        for fam in FAMS:
            st, arr = evaluate(fam, fits["primary"][fam], Hl, ocvl, s, tm, grid=None if fam == "2RC" else g)
            acc[l][fam] = st
            arrays[f"{l}__{fam}__V"] = arr["V"]
            arrays[f"{l}__{fam}__acf"] = arr["acf"]
        for key, fset in fits.items():
            if key == "primary":
                continue
            timing = tm if key == "knee" else key
            acc_sens[l][key] = {fam: evaluate(fam, fset[fam], Hl, ocvl, s, timing, grid=None if fam == "2RC" else g,
                                              full_stats=False)[0] for fam in FAMS}
    np.savez_compressed(cachedir() / f"post_{T}C.npz", **arrays)
    res = dict(T=T, unit_check=uc, unit_check_identified=uci, accuracy=acc, accuracy_sensitivity=acc_sens,
               files=fileinfo, wall_s=time.perf_counter() - t0)
    return save_cache(cache_name("post", T=T), res)


# ======================================================================================
# Orchestration
# ======================================================================================
def run_pool(jobs: dict, resume: bool, nw: int) -> dict:
    """jobs: {key: (cache_name, fn, args, kwargs)} -> {key: result}; cached results with a matching hash are reused
    when resume is set."""
    out, futs = {}, {}
    with ProcessPoolExecutor(max_workers=nw) as ex:
        for k, (cn, fn, a, kw) in jobs.items():
            cached = load_cache(cn) if resume else None
            if cached is not None:
                out[k] = cached
            else:
                futs[k] = ex.submit(fn, *a, **kw)
        for k, f in futs.items():
            out[k] = f.result()
            print(f"[done] {k}", flush=True)
    return out


def runs_job(T, fam, opt, timing, window, fixed=None, bounds_override=None, label=""):
    return (cache_name("runs", T=T, fam=fam, opt=opt, timing=timing, window=window, label=label), task_runs,
            (T, fam, opt, timing, window), dict(fixed=fixed, bounds_override=bounds_override, label=label))


def nested_best(R: dict) -> dict:
    """Best fit per family of one (timing, window) set, enforcing the nesting FO_alphaTFO c FO c TFO and RCL c TFO:
    a nested family's better optimum is a feasible point of the larger family (recorded as nested_correction)."""
    B = {f: dict(best_of(R[f]["runs"]), nested_correction=None) for f in R}
    for small, big, fix in (("FO_alphaTFO", "FO", {"lam": 0.0}), ("FO", "TFO", {"lam": 0.0}), ("RCL", "TFO", {"alpha": 1.0})):
        if small in B and big in B and B[small]["rmse_mV"] < B[big]["rmse_mV"]:
            B[big] = dict(B[small], theta=dict(B[small]["theta"], **fix), nested_correction=f"from {small}")
    return B


def compute(resume: bool) -> dict:
    c, s = cfg()
    t_start = time.perf_counter()
    nw = int(s["max_workers"])
    tm, sens = primary_timing(), sens_timings()
    relax = {"Rp": [s["bounds"]["Rp"][0], float(s["sensitivity_rp_relaxed_upper_Ohm"])]}
    # ---- phase 1: optimiser comparison (primary), other families, timing sensitivity, knee window, Rp relaxed
    j1 = {}
    for T in (45, 25, 0):
        for o in ("de", "cmaes", "tfgd", "trf"):
            j1[(T, "TFO", o, tm, "full", "")] = runs_job(T, "TFO", o, tm, "full")
    for T in TEMPS:
        for f in ("FO", "RCL", "2RC"):
            j1[(T, f, "trf", tm, "full", "")] = runs_job(T, f, "trf", tm, "full")
        for timing in sens:
            for f in ("TFO", "FO", "RCL", "2RC"):
                j1[(T, f, "trf", timing, "full", "")] = runs_job(T, f, "trf", timing, "full")
        for f in ("TFO", "FO", "RCL", "2RC"):
            j1[(T, f, "trf", tm, "knee", "")] = runs_job(T, f, "trf", tm, "knee")
        j1[(T, "TFO", "trf", tm, "full", "rp_relaxed")] = runs_job(T, "TFO", "trf", tm, "full", bounds_override=relax,
                                                                   label="rp_relaxed")
    R1 = run_pool(j1, resume, nw)
    t_phase1 = time.perf_counter() - t_start
    sets = [(tm, "full")] + [(x, "full") for x in sens] + [(tm, "knee")]

    def famruns(T, timing, window):
        d = {f: R1[(T, f, "trf", timing, window, "")] for f in ("FO", "RCL", "2RC")}
        if (timing, window) == (tm, "full"):
            d["TFO"] = dict(R1[(T, "TFO", "trf", tm, "full", "")],
                            runs=[r for o in OPTS for r in R1[(T, "TFO", o, tm, "full", "")]["runs"]])
        else:
            d["TFO"] = R1[(T, "TFO", "trf", timing, window, "")]
        return d
    # ---- phase 2: FO with alpha fixed to the TFO estimate of the same set
    j2 = {}
    for T in TEMPS:
        for (timing, window) in sets:
            b = nested_best(famruns(T, timing, window))["TFO"]
            j2[(T, timing, window)] = runs_job(T, "FO_alphaTFO", "trf", timing, window,
                                               fixed={"alpha": b["theta"]["alpha"], "lam": 0.0})
    R2 = run_pool(j2, resume, nw)
    bests = {}
    for T in TEMPS:
        for (timing, window) in sets:
            d = famruns(T, timing, window)
            d["FO_alphaTFO"] = R2[(T, timing, window)]
            bests[(T, timing, window)] = nested_best(d)
    # ---- phase 3: profiles, bootstrap, diagnostics, accuracy
    j3 = {}
    for T in TEMPS:
        for window in ("full", "knee"):
            th = bests[(T, tm, window)]["TFO"]["theta"]
            for pn in ("lam", "alpha"):
                j3[("profile", T, window, pn)] = (cache_name("profile", T=T, window=window, p=pn), task_profile,
                                                  (T, window, pn, th), {})
        for i, spec in enumerate(BOOT_SPECS):
            th = bests[(T, tm, spec[2])][spec[1]]["theta"]
            j3[("boot", T, spec[0])] = (cache_name("boot", T=T, spec=spec[0]), task_boot, (T, i, th), {})
        j3[("diag", T)] = (cache_name("diag", T=T), task_diag,
                           (T, bests[(T, tm, "full")]["TFO"]["theta"], bests[(T, tm, "knee")]["TFO"]["theta"]), {})
        fits = {"primary": {f: bests[(T, tm, "full")][f]["theta"] for f in FAMS}}
        for timing in sens:
            fits[timing] = {f: bests[(T, timing, "full")][f]["theta"] for f in FAMS}
        fits["knee"] = {f: bests[(T, tm, "knee")][f]["theta"] for f in FAMS}
        j3[("post", T)] = (cache_name("post", T=T), task_post, (T, fits), {})
    R3 = run_pool(j3, resume, nw)
    runtime = dict(total_wall_s=time.perf_counter() - t_start, phase1_wall_s=t_phase1, max_workers=nw,
                   resumed=bool(resume), note="wall/CPU times are machine- and load-dependent (shared machine)")
    return assemble(R1, bests, R3, sets, runtime)


# ======================================================================================
# Assembly (identification.json)
# ======================================================================================
def bound_flags(fam: str, th: dict, B: dict, ls: float, tolu: float) -> tuple[list, list]:
    at, near = [], []
    for k in ID.FAMILY_FREE[fam]:
        if fam == "FO_alphaTFO" and k == "alpha":
            continue
        u = ID.unit_position(k, th[k], B, ls)
        if u <= 1e-6 or u >= 1 - 1e-6:
            at.append(k)
        elif u <= tolu or u >= 1 - tolu:
            near.append(k)
    return at, near


def fit_record(fam, b, runs, B, s, timing, full=True):
    ls, tolu = float(s["lambda_asinh_scale"]), float(s["near_bound_unit_tol"])
    th = dict(b["theta"])
    if fam == "2RC":
        th = MD.TwoRCParams(**{k: th[k] for k in ("R0", "R1", "tau1", "R2", "tau2", "s", "dq")}).sorted().to_dict()
    at, near = bound_flags(fam, th, B, ls, tolu)
    if fam != "2RC" and "lam" in ID.FAMILY_FREE[fam] and th["lam"] < float(s["lambda_zero_report"]) and "lam" not in at:
        at.append("lam")
    fit = dict(theta=th, rmse_mV=b["rmse_mV"], optimizer=b.get("optimizer"), run=b.get("run"), converged=b.get("converged"),
               nested_correction=b.get("nested_correction"), at_bound=at, near_bound=near,
               step_response=derived(fam, th, timing))
    if fam != "2RC":
        p = MD.TFOParams(**{k: th[k] for k in ("alpha", "lam", "R0", "Rp", "Cp", "s", "dq")})
        fit["derived"] = dict(a_p=p.a_p, b_p=p.b_p, R_dc_Ohm=p.dc_resistance())
        if fam == "RCL":
            fit["derived"]["rcl_effective"] = MD.rcl_effective(p)
    if runs is not None and full:
        fr = np.array([r["rmse_mV"] for r in runs])
        fit["multistart"] = dict(n=len(runs), best=float(fr.min()), median=float(np.median(fr)),
                                 n_within_0p01mV=int((fr <= fr.min() + 0.01).sum()),
                                 n_converged=int(sum(r["converged"] for r in runs)),
                                 runs=[dict(rmse_mV=r["rmse_mV"], theta=r["theta"], nfev=r["nfev"], wall_s=r["wall_s"],
                                            cpu_s=r["cpu_s"], converged=r["converged"], message=r["message"]) for r in runs])
    elif runs is not None:
        fr = np.array([r["rmse_mV"] for r in runs])
        fit["multistart"] = dict(n=len(runs), best=float(fr.min()), n_within_0p01mV=int((fr <= fr.min() + 0.01).sum()))
    return fit


def assemble(R1, bests, R3, sets, runtime) -> dict:
    c, s = cfg()
    tc = c["identification"]["tfgd"]
    tm = primary_timing()
    B = s["bounds"]
    J = dict(generated_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), script="scripts/04_identify.py",
             code_hash=code_hash(), config_section="identification_study", settings=s,
             input_timing=dict(primary=tm, sensitivity=sens_timings(), definitions=MD.TIMING),
             tfgd_hyper=dict(nu=tc["order_nu"], lambda_g=tc["tempering_lambda_g"], eta=tc["step"], max_iter=tc["max_iter"],
                             tol_rel=tc["tol_rel"], N_g=int(math.ceil(8 / float(tc["tempering_lambda_g"])))),
             runtime=runtime, Q_id_Ah={str(T): q_id(T) for T in TEMPS},
             warm_start=("SOC z = 1 and V_p = 0 ASSUMED at the last sample of the CV step (step 3); Coulomb counting with "
                         "Q_id(T), eta = 1 through the rest (step 4), the pre-profile 1 A discharge (step 5), the rest "
                         "(step 6) and the profile (step 7); only the profile window is scored"),
             per_T={})
    thr_near = float(s["near_bound_unit_tol"])
    for T in TEMPS:
        P = dict(identification_file=id_file(T))
        opt = {}
        for o in OPTS:
            Rr = R1[(T, "TFO", o, tm, "full", "")]["runs"]
            f = np.array([r["rmse_mV"] for r in Rr])
            opt[o] = dict(runs=Rr, best_rmse_mV=float(f.min()), median_rmse_mV=float(np.median(f)),
                          worst_rmse_mV=float(f.max()), n_stopped_by_criterion=int(sum(r["converged"] for r in Rr)),
                          mean_nfev=float(np.mean([r["nfev"] for r in Rr])),
                          total_wall_s=float(sum(r["wall_s"] for r in Rr)), total_cpu_s=float(sum(r["cpu_s"] for r in Rr)))
        gbest = min(v["best_rmse_mV"] for v in opt.values())
        for o in OPTS:
            opt[o]["n_within_0p01mV_of_global"] = int(sum(r["rmse_mV"] <= gbest + 0.01 for r in opt[o]["runs"]))
            opt[o]["n_within_1pct_of_global"] = int(sum(r["rmse_mV"] <= gbest * 1.01 for r in opt[o]["runs"]))
        tf = opt["tfgd"]["runs"]
        stall = []
        for r in tf:
            far = r["converged"] and r["rmse_mV"] > gbest + 0.01
            pol = [k for k in ("Rp", "Cp", "alpha") if k in r["theta"] and
                   (lambda u: u <= thr_near or u >= 1 - thr_near)(ID.unit_position(k, r["theta"][k], B, float(s["lambda_asinh_scale"])))]
            stall.append(dict(run=r["run"], stopped_by_tolerance=r["converged"], far_from_best=bool(far),
                              degenerate_plateau=bool(far and ("Cp" in pol or "Rp" in pol)), params_at_bound=pol,
                              excess_mV=r["rmse_mV"] - gbest))
        opt["tfgd"]["stall_labels"] = stall
        opt["tfgd"]["mean_armijo_trials_per_iter"] = float(np.mean([r["mean_armijo_trials_per_iter"] for r in tf]))
        opt["tfgd"]["mean_evals_per_iter"] = float(np.mean([r["mean_evals_per_iter"] for r in tf]))
        opt["tfgd"]["median_restarts"] = float(np.median([r["restarts"] for r in tf]))
        P["TFO_optimizers"] = opt
        P["TFO_best_optimizer"] = min(OPTS, key=lambda o: opt[o]["best_rmse_mV"])
        # ---- primary fits
        bb = bests[(T, tm, "full")]
        runs_of = {"TFO": None, "FO_alphaTFO": None}
        fits = {}
        for f in FAMS:
            runs = None if f == "TFO" else (R1[(T, f, "trf", tm, "full", "")]["runs"] if f != "FO_alphaTFO" else None)
            fits[f] = fit_record(f, bb[f], runs, B, s, tm)
        P["fits"] = fits
        prof = {w: {pn: R3[("profile", T, w, pn)] for pn in ("lam", "alpha")} for w in ("full", "knee")}
        # ---- sensitivity: timing, knee, Rp relaxed
        sens = {}
        for (timing, window) in sets:
            key = timing if window == "full" else "knee"
            bset = bests[(T, timing, window)]
            ff = {f: fit_record(f, bset[f], None, B, s, timing) for f in FAMS}
            src = (R1[(T, "TFO", P["TFO_best_optimizer"], tm, "full", "")] if (timing, window) == (tm, "full")
                   else R1[(T, "TFO", "trf", timing, window, "")])
            dep = src["best_residual"]
            n = dep["n"]
            LRn = 2 * n * math.log(ff["FO"]["rmse_mV"] / ff["TFO"]["rmse_mV"])
            sens[key] = dict(timing=timing, window=window, fits=ff, n_scored=n, tau_hac=dep["tau"], tau_ar1=dep["ar1"]["tau_s_units"],
                             lambda_LR_nominal_at_0=LRn, lambda_LR_eff_at_0=LRn / dep["tau"],
                             lambda_excludes_0=bool(LRn / dep["tau"] > float(s["profile_v2"]["crit_zero"])),
                             best_family=min(FAMS, key=lambda f: ff[f]["rmse_mV"]),
                             TFO_minus_FO_mV=ff["TFO"]["rmse_mV"] - ff["FO"]["rmse_mV"],
                             TFO_minus_2RC_mV=ff["TFO"]["rmse_mV"] - ff["2RC"]["rmse_mV"], LR_source="TFO vs FO multistart fits")
            if timing == tm:
                # the primary sets use the lambda-profile test (same HAC tau as the profile); consistency of the FO fit
                zt = prof[window]["lam"]["zero_test"]
                sens[key].update(lambda_LR_nominal_at_0=zt["LR_nominal"], lambda_LR_eff_at_0=zt["LR_eff"],
                                 lambda_excludes_0=zt["excludes_0_eff"], LR_source="lambda profile (zero_test)",
                                 FO_fit_minus_profile_at_0_mV=ff["FO"]["rmse_mV"] - zt["rmse_at_0_mV"])
        rr = R1[(T, "TFO", "trf", tm, "full", "rp_relaxed")]
        Bx = rr["bounds"]
        brx = best_of(rr["runs"])
        sens["rp_relaxed"] = dict(bounds_Rp=Bx["Rp"], fit=fit_record("TFO", brx, None, Bx, s, tm),
                                  delta_vs_primary_mV=brx["rmse_mV"] - fits["TFO"]["rmse_mV"])
        P["sensitivity"] = sens
        # ---- uncertainty
        P["profile"] = prof
        P["bootstrap"] = {spec[0]: {k: v for k, v in R3[("boot", T, spec[0])].items() if k not in ("draws", "derived_draws")}
                          for spec in BOOT_SPECS}
        P["bootstrap_draws"] = {spec[0]: dict(R3[("boot", T, spec[0])]["draws"], **R3[("boot", T, spec[0])]["derived_draws"])
                                for spec in BOOT_SPECS}
        P["diagnostics"] = {k: v for k, v in R3[("diag", T)].items() if k != "code_hash"}
        post = R3[("post", T)]
        for k in ("unit_check", "unit_check_identified", "accuracy", "accuracy_sensitivity", "files"):
            P[k] = post[k]
        P["post_wall_s"] = post["wall_s"]
        # ---- lambda verdict (primary: knee-excluded window, HAC n_eff)
        zt = {w: prof[w]["lam"]["zero_test"] for w in ("full", "knee")}
        bf = {w: float(np.mean(np.array(R3[("boot", T, f"TFO_{w}")]["draws"]["lam"]) < float(s["lambda_zero_report"])))
              for w in ("full", "knee")}
        P["lambda_verdict"] = dict(
            rule=("lambda is declared identifiable (lambda = 0 rejected) when the HAC-n_eff profile LR at lambda = 0 exceeds "
                  "the chi-bar-square boundary value on the KNEE-EXCLUDED window (primary); the whole-window test, the "
                  "timing sensitivity and the bootstrap fraction of draws at lambda = 0 are reported alongside"),
            lambda_hat_full=fits["TFO"]["theta"]["lam"], lambda_hat_knee=sens["knee"]["fits"]["TFO"]["theta"]["lam"],
            zero_test=zt, ci_eff={w: prof[w]["lam"]["ci_eff"] for w in ("full", "knee")},
            ci_nominal={w: prof[w]["lam"]["ci_nominal"] for w in ("full", "knee")},
            bootstrap_frac_lambda_at_0=bf,
            timing_sensitivity={k: sens[k]["lambda_excludes_0"] for k in sens if k not in ("knee", "rp_relaxed")},
            identifiable=bool(zt["knee"]["excludes_0_eff"]),
            robust=bool(zt["knee"]["excludes_0_eff"] == zt["full"]["excludes_0_eff"]))
        cz = float(s["profile_v2"]["crit_zero"])
        bws = {w: {str(b): zt[w]["LR_nominal"] / v["tau"] for b, v in prof[w]["lam"]["dependence"]["hac_sensitivity"].items()}
               for w in ("full", "knee")}
        for w in ("full", "knee"):
            bws[w][str(s["neff"]["bandwidth_s"])] = zt[w]["LR_eff"]
        tests = [x > cz for w in bws for x in bws[w].values()] + list(P["lambda_verdict"]["timing_sensitivity"].values())
        P["lambda_verdict"]["LR_eff_by_bandwidth"] = bws
        P["lambda_verdict"]["n_tests_rejecting_0"] = int(sum(tests))
        P["lambda_verdict"]["n_tests"] = len(tests)
        P["lambda_verdict"]["status"] = ("identifiable (robust)" if all(tests) else
                                         "identifiable (primary test only)" if P["lambda_verdict"]["identifiable"] else
                                         "not identifiable; weak, non-robust evidence" if any(tests) else "not identifiable")
        J["per_T"][str(T)] = P
    J["verdicts"] = verdicts(J)
    return J


def verdicts(J) -> dict:
    v = {}
    for T in TEMPS:
        P = J["per_T"][str(T)]
        v[str(T)] = dict(
            lambda_identifiable=P["lambda_verdict"]["identifiable"], lambda_robust=P["lambda_verdict"]["robust"],
            lambda_status=P["lambda_verdict"]["status"],
            lambda_hat=P["lambda_verdict"]["lambda_hat_full"], TFO_at_bound=P["fits"]["TFO"]["at_bound"],
            TFO_near_bound=P["fits"]["TFO"]["near_bound"], best_optimizer=P["TFO_best_optimizer"],
            optimizer_best_rmse={o: P["TFO_optimizers"][o]["best_rmse_mV"] for o in OPTS},
            best_family_identification=min(FAMS, key=lambda f: P["fits"][f]["rmse_mV"]),
            best_family_by_set={k: q["best_family"] for k, q in P["sensitivity"].items() if "best_family" in q},
            rmse_identification={f: P["fits"][f]["rmse_mV"] for f in FAMS},
            TFO_minus_FO_mV=P["fits"]["TFO"]["rmse_mV"] - P["fits"]["FO"]["rmse_mV"],
            TFO_minus_FOalpha_mV=P["fits"]["TFO"]["rmse_mV"] - P["fits"]["FO_alphaTFO"]["rmse_mV"],
            TFO_minus_2RC_mV=P["fits"]["TFO"]["rmse_mV"] - P["fits"]["2RC"]["rmse_mV"])

    def wins_of(getter):
        wins, vals = {f: 0 for f in FAMS}, {f: [] for f in FAMS}
        for T in TEMPS:
            P = J["per_T"][str(T)]
            for l in P["files"]:
                if P["files"][l]["split"] != "test":
                    continue
                a = getter(P, l)
                wins[min(FAMS, key=lambda f: a[f]["rmse_mV"])] += 1
                for f in FAMS:
                    vals[f].append(a[f]["rmse_mV"])
        return dict(rmse_wins=wins, median_rmse_mV={f: float(np.median(x)) for f, x in vals.items()},
                    n_files=int(sum(wins.values())))
    v["test"] = wins_of(lambda P, l: P["accuracy"][l])
    keys = list(J["per_T"]["0"]["accuracy_sensitivity"][J["per_T"]["0"]["identification_file"]].keys())
    v["test_sensitivity"] = {k: wins_of(lambda P, l, k=k: P["accuracy_sensitivity"][l][k]) for k in keys}
    return v


# ======================================================================================
# npz (built from the caches in compute mode only)
# ======================================================================================
def save_arrays(J: dict) -> dict:
    A = {}
    for T in TEMPS:
        P = J["per_T"][str(T)]
        pz = np.load(cachedir() / f"post_{T}C.npz")
        for k in pz.files:
            A[f"acc__{k}"] = pz[k]
        dz = np.load(cachedir() / f"diag_{T}C.npz")
        for k in dz.files:
            A[f"diag__{T}__{k}"] = dz[k]
        for o in OPTS:
            for r in P["TFO_optimizers"][o]["runs"]:
                A[f"trace__{T}__{o}__{r['run']}"] = np.array(r["trace"], float).reshape(-1, 2)
            A[f"final__{T}__{o}"] = np.array([r["rmse_mV"] for r in P["TFO_optimizers"][o]["runs"]])
        for w in ("full", "knee"):
            for pn in ("lam", "alpha"):
                rows = P["profile"][w][pn]["rows"]
                for k in ("value", "rmse_mV", "LR_eff", "LR_nominal", "converged"):
                    A[f"profile__{T}__{w}__{pn}__{k}"] = np.array([r[k] for r in rows], float)
        A[f"corr_free__{T}"] = np.array(P["diagnostics"]["full"]["jacobian"]["corr_free"])
        for spec, d in P["bootstrap_draws"].items():
            for k, vals in d.items():
                A[f"boot__{T}__{spec}__{k}"] = np.array(vals, float)
        # timing sensitivity: identification RMSE per family and convention
        keys = [k for k in P["sensitivity"] if k not in ("knee", "rp_relaxed")]
        A[f"timing__{T}__rmse"] = np.array([[P["sensitivity"][k]["fits"][f]["rmse_mV"] for f in FAMS] for k in keys])
        A[f"timing__{T}__keys"] = np.array(keys)
        # temperature-dependence panel data (estimate, 2.5 %, 97.5 %, ci_valid) per series
    for name, spec, fitget in (("TFO_full", "TFO_full", lambda P: P["fits"]["TFO"]),
                               ("TFO_knee", "TFO_knee", lambda P: P["sensitivity"]["knee"]["fits"]["TFO"]),
                               ("FO_full", "FO_full", lambda P: P["fits"]["FO"])):
        for pn in PT_PARAMS:
            rows = []
            for T in TEMPS:
                P = J["per_T"][str(T)]
                F = fitget(P)
                e = F["step_response"][pn] if pn.startswith("R_") else F["theta"][pn]
                st = P["bootstrap"][spec]["stats"].get(pn)
                if st is None:
                    rows.append([e, np.nan, np.nan, 0.0])
                else:
                    rows.append([e, st["ci95"][0], st["ci95"][1], float(st["ci_valid"])])
            A[f"paramsT__{name}__{pn}"] = np.array(rows, float)
    np.savez_compressed(outdirs()[0] / "identification_arrays.npz", **A)
    return A


PT_PARAMS = ("alpha", "lam", "R0", "Cp", "R_1s_Ohm", "R_dc_Ohm", "s", "dq")


def main():
    global SMOKE
    ap = argparse.ArgumentParser()
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--from-results", action="store_true")
    ap.add_argument("--smoke", default=None)
    a = ap.parse_args()
    if a.smoke:
        SMOKE = a.smoke
        os.environ["TFSO_IDENT_SMOKE"] = a.smoke
    res, fig, tab, rep = outdirs()
    jpath = res / "identification.json"
    if a.from_results:
        with open(jpath, "r", encoding="utf-8") as fh:
            J = json.load(fh)
        A = dict(np.load(res / "identification_arrays.npz"))
    else:
        J = compute(a.resume)
        if a.resume and jpath.exists():
            with open(jpath, "r", encoding="utf-8") as fh:
                old = json.load(fh).get("runtime", {})
            full = old.get("full_run_wall_s", old.get("total_wall_s") if not old.get("resumed") else None)
            if full is not None:
                J["runtime"]["full_run_wall_s"] = full
        jdump(J, jpath)
        with open(jpath, "r", encoding="utf-8") as fh:      # canonical (JSON) form for all outputs
            J = json.load(fh)
        save_arrays(J)
        A = dict(np.load(res / "identification_arrays.npz"))
    make_all(J, A, fig, tab, rep)
    print(f"runtime {J['runtime']['total_wall_s']:.0f} s; outputs in {res}, {fig}, {tab}, {rep}")


# ======================================================================================
# Figures (draft, vector PDF; every plotted array is in results/identification_arrays.npz)
# ======================================================================================
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e6e5e1"
FCOL = {"TFO": "#2a78d6", "FO": "#eb6834", "FO_alphaTFO": "#1baf7a", "RCL": "#eda100", "2RC": "#e87ba4"}
FLAB = {"TFO": "TFO", "FO": "FO ($\\lambda$=0)", "FO_alphaTFO": "FO ($\\alpha=\\alpha_{TFO}$)", "RCL": "RCL ($\\alpha$=1)",
        "2RC": "2RC"}
OCOL = {"tfgd": "#2a78d6", "trf": "#eb6834", "de": "#1baf7a", "cmaes": "#eda100"}
OLAB = {"tfgd": "TFGD", "trf": "TRF", "de": "DE", "cmaes": "CMA-ES"}
FMARK = {"TFO": "o", "FO": "s", "FO_alphaTFO": "D", "RCL": "^", "2RC": "v"}
TLAB = {"causal": "causal (primary)", "implicit_forward": "implicit forward (M4b)", "legacy_mixed": "legacy mixed",
        "causal_point_output": "causal, point $I$ in $R_0I$"}
WCOL = {"full": "#2a78d6", "knee": "#eb6834"}
WLAB = {"full": "whole profile", "knee": "$z\\geq z_{min}$ (knee excluded)"}


def _style():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7,
                         "legend.fontsize": 7, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
                         "ytick.color": INK2, "axes.linewidth": 0.6, "grid.color": GRID, "grid.linewidth": 0.5,
                         "axes.grid": True, "figure.facecolor": "white", "axes.facecolor": "white",
                         "savefig.facecolor": "white", "lines.linewidth": 1.2, "pdf.fonttype": 42,
                         "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False})
    return plt


def _tag(ax, k):
    ax.text(-0.02, 1.03, f"({chr(97 + k)})", transform=ax.transAxes, ha="right", va="bottom", fontsize=8, color=INK)


def _win(w, tend):
    return (w[0], w[1]) if w[0] >= 0 else (tend + w[0], tend + w[1])


def make_figures(J: dict, A: dict, fig: Path):
    plt = _style()
    fig.mkdir(parents=True, exist_ok=True)
    s = J["settings"]
    # ---- optimisers: journal-style figure built by scripts/09_figures_tables.py (single code path) -------
    import importlib.util
    _spec = importlib.util.spec_from_file_location("figs09", Path(__file__).resolve().parent / "09_figures_tables.py")
    _m09 = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_m09)
    _m09.fig_optimizers(J, A, fig / "fig_ident_optimizers.pdf")
    plt = _style()
    # ---- profiles (LR with HAC n_eff, both windows) -------------------------------------
    pc = s["profile_v2"]
    f, axs = plt.subplots(2, 3, figsize=(7.2, 4.6))
    for j, T in enumerate(TEMPS):
        for i, pn in enumerate(("lam", "alpha")):
            ax = axs[i, j]
            for w in ("full", "knee"):
                x = A[f"profile__{T}__{w}__{pn}__value"]; y = A[f"profile__{T}__{w}__{pn}__LR_eff"]
                cv = A[f"profile__{T}__{w}__{pn}__converged"].astype(bool)
                ax.plot(x, y, "-", color=WCOL[w], lw=1.0, label=WLAB[w])
                ax.scatter(x[cv], y[cv], s=12, color=WCOL[w], edgecolor="white", lw=0.4, zorder=3)
                if (~cv).any():
                    ax.scatter(x[~cv], y[~cv], s=12, facecolor="white", edgecolor=WCOL[w], lw=0.8, zorder=3)
            ax.axhline(pc["crit_interior"], color=INK2, lw=0.8, ls="--")
            if pn == "lam":
                ax.axhline(pc["crit_zero"], color=INK2, lw=0.8, ls=":")
                ax.set_xscale("symlog", linthresh=1e-6); ax.set_xlim(0, 0.08); ax.set_xlabel("$\\lambda$ (1/s), fixed")
                ax.set_title(f"{T} °C", fontsize=8, color=INK)
            else:
                ax.set_xlabel("$\\alpha$, fixed")
            ax.set_yscale("symlog", linthresh=1.0); ax.set_ylim(bottom=0)
            if j == 0:
                ax.set_ylabel("profile LR / $\\tau_{HAC}$")
            _tag(ax, 3 * i + j)
    f.text(0.5, 0.005, "dashed: $\\chi^2_1$ 95 % (interval); dotted: $\\bar\\chi^2$ 95 % (test of $\\lambda$=0); "
           "hollow: refit not converged", ha="center", va="bottom", fontsize=6.5, color=INK2)
    h_, l_ = axs[0, 0].get_legend_handles_labels()
    f.legend(h_, l_, loc="upper center", ncol=2, fontsize=6.5)
    f.tight_layout(rect=(0, 0.03, 1, 0.95)); f.savefig(fig / "fig_ident_profile.pdf"); plt.close(f)
    # ---- correlation (free parameters only) ------------------------------------------
    from matplotlib.colors import LinearSegmentedColormap
    cm = LinearSegmentedColormap.from_list("div", ["#2a78d6", "#f0efec", "#e34948"])
    lab = {"alpha": "$\\alpha$", "lam": "$\\lambda$", "R0": "$R_0$", "Rp": "$R_p$", "Cp": "$C_p$", "s": "$s$",
           "dq": "$\\delta q$"}
    f, axs = plt.subplots(1, 3, figsize=(7.2, 2.6))
    for j, T in enumerate(TEMPS):
        jj = J["per_T"][str(T)]["diagnostics"]["full"]["jacobian"]
        names = jj["free"]
        C = A[f"corr_free__{T}"]
        ax = axs[j]; ax.grid(False)
        im = ax.imshow(C, cmap=cm, vmin=-1, vmax=1)
        for a_ in range(len(names)):
            for b_ in range(len(names)):
                ax.text(b_, a_, f"{C[a_, b_]:.2f}", ha="center", va="center", fontsize=4.5, color=INK)
        ax.set_xticks(range(len(names))); ax.set_yticks(range(len(names)))
        ax.set_xticklabels([lab[n] for n in names]); ax.set_yticklabels([lab[n] for n in names])
        ax.set_title(f"{T} °C (cond {jj['cond_free']:.1e})", fontsize=8)
        _tag(ax, j)
    f.colorbar(im, ax=list(axs), shrink=0.8, label="correlation (free parameters)")
    f.savefig(fig / "fig_ident_corr.pdf", bbox_inches="tight"); plt.close(f)
    # ---- temperature-dependent parameters -------------------------------------------------
    ylab = {"alpha": "$\\alpha$ (–)", "lam": "$\\lambda$ (1/s)", "R0": "$R_0$ (Ω)", "Cp": "$C_p$ (F s$^{\\alpha-1}$)",
            "R_1s_Ohm": "$R(1\\,s)$ (Ω)", "R_dc_Ohm": "$R_{dc}$ (Ω)", "s": "axis scale $s$ (–)", "dq": "axis shift $\\delta q$ (Ah)"}
    ser = (("TFO_full", -2.0, FCOL["TFO"], "o", "TFO, whole profile"), ("TFO_knee", 0.0, "#1baf7a", "D", "TFO, knee excluded"),
           ("FO_full", 2.0, FCOL["FO"], "s", "FO ($\\lambda$=0), whole profile"))
    f, axs = plt.subplots(2, 4, figsize=(7.2, 3.9))
    for k, pn in enumerate(PT_PARAMS):
        ax = axs.flat[k]
        for name, d, col, mk, lb in ser:
            if name == "FO_full" and pn == "lam":
                continue
            M = A[f"paramsT__{name}__{pn}"]
            x = np.array(TEMPS) + d
            ax.plot(x, M[:, 0], "-", color=col, lw=0.9)
            for i in range(len(TEMPS)):
                if M[i, 3] > 0.5:
                    ax.errorbar(x[i], M[i, 0], yerr=[[max(M[i, 0] - M[i, 1], 0)], [max(M[i, 2] - M[i, 0], 0)]], fmt=mk,
                                color=col, ms=4, mec="white", mew=0.5, capsize=2, lw=1.0)
                else:
                    ax.plot(x[i], M[i, 0], mk, color=col, ms=4, mfc="white", mew=0.9)
            ax.plot([], [], mk + "-", color=col, ms=4, label=lb)
        if pn == "lam":
            ax.set_yscale("symlog", linthresh=1e-6)
        elif pn in ("R0", "Cp"):
            ax.set_yscale("log")
        ax.set_xticks(TEMPS); ax.set_xlabel("T (°C)"); ax.set_title(ylab[pn], fontsize=7.5, color=INK)
        _tag(ax, k)
    h_, l_ = axs.flat[0].get_legend_handles_labels()
    f.legend(h_, l_, loc="upper center", ncol=3, fontsize=6.5)
    f.text(0.5, 0.005, "whiskers: 95 % local-scale block-bootstrap interval; hollow marker: > 2.5 % of draws at a bound "
           "(no interval quoted)", ha="center", va="bottom", fontsize=6.5, color=INK2)
    f.tight_layout(rect=(0, 0.03, 1, 0.94)); f.savefig(fig / "fig_ident_params_T.pdf"); plt.close(f)
    # ---- timing sensitivity --------------------------------------------------------------
    f, axs = plt.subplots(1, 3, figsize=(7.2, 2.4))
    for j, T in enumerate(TEMPS):
        ax = axs[j]
        keys = [str(k) for k in A[f"timing__{T}__keys"]]
        Mx = A[f"timing__{T}__rmse"]
        for i, fam in enumerate(FAMS):
            ax.scatter(Mx[:, i], np.arange(len(keys)) + (i - 2) * 0.1, s=16, marker=FMARK[fam], color=FCOL[fam],
                       edgecolor="white", lw=0.4, zorder=3, label=FLAB[fam])
        ax.set_yticks(range(len(keys)))
        ax.set_yticklabels([TLAB[k] for k in keys] if j == 0 else [""] * len(keys), fontsize=6.5)
        ax.invert_yaxis(); ax.set_xlabel("identification RMSE (mV)"); ax.set_title(f"{T} °C", fontsize=8)
        _tag(ax, j)
    h_, l_ = axs[0].get_legend_handles_labels()
    f.legend(h_, l_, loc="upper center", ncol=5, fontsize=6.5)
    f.tight_layout(rect=(0, 0, 1, 0.88)); f.savefig(fig / "fig_ident_timing.pdf"); plt.close(f)
    # ---- measured vs modelled -------------------------------------------------------------
    wins = s["accuracy"]["transient_windows_s"]
    f, axs = plt.subplots(3, 3, figsize=(7.2, 6.4))
    for i, T in enumerate(TEMPS):
        l = J["per_T"][str(T)]["identification_file"]
        t, Vm = A[f"acc__{l}__t"], A[f"acc__{l}__Vmeas"]
        for j in range(3):
            ax = axs[i, j]
            if j == 0:
                m, fams, sc = np.ones(t.size, bool), ("TFO", "2RC"), 3600.0
            else:
                w0, w1 = _win(wins[j - 1], float(t[-1]))
                m, fams, sc = (t >= w0) & (t <= w1), FAMS, 1.0
            ax.plot(t[m] / sc, Vm[m], color=INK, lw=1.6 if j else 0.6, alpha=0.35 if j else 0.8, label="measured")
            for fam in fams:
                ax.plot(t[m] / sc, A[f"acc__{l}__{fam}__V"][m], color=FCOL[fam], lw=0.8, label=FLAB[fam])
            if j == 0:
                ax.set_xlabel("time from profile start (h)"); ax.set_ylabel(f"{T} °C: $V_t$ (V)")
                for w in wins:
                    w0, w1 = _win(w, float(t[-1]))
                    ax.axvspan(w0 / 3600, w1 / 3600, color=GRID, alpha=0.8, lw=0)
            else:
                ax.set_xlabel("time from profile start (s)")
            _tag(ax, 3 * i + j)
            if i == 0 and j in (0, 1):
                ax.legend(loc="lower left", fontsize=6, ncol=1 if j == 0 else 2)
    f.tight_layout(); f.savefig(fig / "fig_vmodel_fit.pdf"); plt.close(f)
    # ---- residual ACF -----------------------------------------------------------------
    f, axs = plt.subplots(1, 3, figsize=(7.2, 2.4), sharey=True)
    for j, T in enumerate(TEMPS):
        l = J["per_T"][str(T)]["identification_file"]
        ax = axs[j]
        for fam in FAMS:
            a = A[f"acc__{l}__{fam}__acf"]
            ax.plot(np.arange(a.size), a, color=FCOL[fam], lw=1.0, label=FLAB[fam])
        ax.axhline(0, color=INK2, lw=0.6)
        ax.set_xlabel("lag (s)"); ax.set_title(f"{T} °C, identification file", fontsize=8)
        if j == 0:
            ax.set_ylabel("residual ACF"); ax.legend(loc="upper right", fontsize=6)
        _tag(ax, j)
    f.tight_layout(); f.savefig(fig / "fig_vmodel_acf.pdf"); plt.close(f)
    # ---- RMSE per file ------------------------------------------------------------------
    f, axs = plt.subplots(2, 3, figsize=(7.2, 5.0))
    for j, T in enumerate(TEMPS):
        P = J["per_T"][str(T)]
        files = sorted(P["accuracy"], key=lambda l: (["identification", "validation", "test"].index(P["files"][l]["split"]), l))
        for i, key in enumerate(("rmse_mV", "rmse_z_ge_knee_mV")):
            ax = axs[i, j]
            for k, fam in enumerate(FAMS):
                v = [P["accuracy"][l][fam][key] for l in files]
                ax.scatter(v, np.arange(len(files)) + (k - 2) * 0.12, s=14, marker=FMARK[fam], color=FCOL[fam],
                           edgecolor="white", lw=0.4, label=FLAB[fam], zorder=3)
            ax.set_yticks(range(len(files)))
            ax.set_yticklabels([l.replace(f"SP2_{T}C_", "") + {"identification": " (id)", "validation": " (val)",
                                                              "test": ""}[P["files"][l]["split"]] for l in files], fontsize=6)
            ax.invert_yaxis()
            ax.set_xlabel("RMSE (mV)" if i == 0 else f"RMSE, z ≥ {s['knee_window']['z_min']:g} (mV)")
            if i == 0:
                ax.set_title(f"{T} °C", fontsize=8)
            _tag(ax, 3 * i + j)
    h_, l_ = axs[0, 0].get_legend_handles_labels()
    f.legend(h_, l_, loc="upper center", ncol=5, fontsize=6.5)
    f.tight_layout(rect=(0, 0, 1, 0.95)); f.savefig(fig / "fig_vmodel_rmse.pdf"); plt.close(f)


# ======================================================================================
# Tables
# ======================================================================================
def fnum(v) -> str:
    if v is None or not np.isfinite(v):
        return "--"
    if v == 0:
        return "0"
    a = abs(v)
    if a >= 1e4 or a < 1e-2:
        m, e = f"{v:.2e}".split("e")
        return f"${m}\\times10^{{{int(e)}}}$"
    txt = f"{v:.3g}" if a < 100 else f"{v:.0f}"
    return "$-$" + txt[1:] if txt.startswith("-") else txt      # typographic minus in the LaTeX tables


PLATEX = {"alpha": ("$\\alpha$", "--"), "lam": ("$\\lambda$", "s$^{-1}$"), "R0": ("$R_0$", "$\\Omega$"),
          "Rp": ("$R_p$", "$\\Omega$"), "Cp": ("$C_p$", "F\\,s$^{\\alpha-1}$"), "R1": ("$R_1$", "$\\Omega$"),
          "tau1": ("$\\tau_1$", "s"), "R2": ("$R_2$", "$\\Omega$"), "tau2": ("$\\tau_2$", "s"),
          "s": ("$s$", "--"), "dq": ("$\\delta q$", "Ah"), "R_1s_Ohm": ("$R(\\SI{1}{\\second})$", "$\\Omega$"),
          "R_dc_Ohm": ("$R_{\\mathrm{tot}}$", "$\\Omega$")}  # total DC resistance: R0 + DC gain of the branches
FTEX = {"TFO": "TFO", "FO": "FO ($\\lambda=0$)", "FO_alphaTFO": "FO ($\\alpha=\\hat\\alpha_{\\mathrm{TFO}}$)",
        "RCL": "RCL ($\\alpha=1$)", "2RC": "2RC"}
BOOT_OF = {"TFO": "TFO_full", "FO": "FO_full", "2RC": "2RC_full"}


def ci_text(P, fam, n, tex=True):
    """'[lo, hi]' for a valid percentile interval, 'bound x %' when too many draws sit at a bound, '' otherwise."""
    if fam not in BOOT_OF or n not in P["bootstrap"][BOOT_OF[fam]]["stats"]:
        return ""
    st = P["bootstrap"][BOOT_OF[fam]]["stats"][n]
    f = fnum if tex else (lambda x: f"{x:.3g}")
    if st["ci_valid"]:
        return f" [{f(st['ci95'][0])}, {f(st['ci95'][1])}]"
    pct = "\\%" if tex else "%"
    return f" (bound {100 * (st['frac_at_lower'] + st['frac_at_upper']):.0f}{pct})"


def vmodel_groups(J: dict) -> dict:
    """{group: {T: {fam: stats}}}: mean over the files of a group (test: the 50 % and 80 % starts)."""
    out = {}
    for gname, pred in (("DST 80 % (identification)", lambda f: f["split"] == "identification"),
                        ("DST 50 % (validation)", lambda f: f["split"] == "validation"),
                        ("FUDS (test)", lambda f: f["split"] == "test" and f["profile"] == "FUDS"),
                        ("US06 (test)", lambda f: f["split"] == "test" and f["profile"] == "US06"),
                        ("BJDST (test)", lambda f: f["split"] == "test" and f["profile"] == "BJDST")):
        out[gname] = {}
        for T in TEMPS:
            P = J["per_T"][str(T)]
            ls = [l for l in P["accuracy"] if pred(P["files"][l])]
            out[gname][T] = {fam: {k: float(np.mean([P["accuracy"][l][fam][k] for l in ls]))
                                   for k in ("rmse_mV", "rmse_z_ge_knee_mV", "max_abs_mV", "acf_lag1", "mae_mV")}
                             for fam in FAMS}
    return out


PUNIT = {"alpha": "", "lam": " (\\si{\\per\\second})", "R0": " (\\si{\\ohm})", "Rp": " (\\si{\\ohm})",
         "Cp": " ($\\si{\\farad}\\,\\si{\\second}^{\\alpha-1}$)", "R1": " (\\si{\\ohm})", "tau1": " (\\si{\\second})",
         "R2": " (\\si{\\ohm})", "tau2": " (\\si{\\second})", "s": "", "dq": " (\\si{\\Ah})",
         "R_1s_Ohm": " (\\si{\\ohm})", "R_dc_Ohm": " (\\si{\\ohm})"}


def bnum(v) -> str:
    """Compact box-bound label for tab_params (plain decimals; exact powers of ten as 10^k)."""
    if v is None or not np.isfinite(v):
        return "--"
    if v >= 1e4 and abs(np.log10(v) - round(np.log10(v))) < 1e-12:
        return f"$10^{{{int(round(np.log10(v)))}}}$"
    if v == 0 or 1e-3 <= abs(v) < 1e4:
        return ("$-$" + f"{-v:g}") if v < 0 else f"{v:g}"
    return fnum(v)


def make_tables(J: dict, tab: Path):
    """tables/tab_params.tex and tables/tab_vmodel.tex, laid out for the article class with 0.8 in margins (no
    scaling): model name as a group row, unit in the parameter column; tab_vmodel with siunitx S columns."""
    tab.mkdir(parents=True, exist_ok=True)
    s = J["settings"]
    B = s["bounds"]
    bc = s["bootstrap_v2"]
    src = "% src: results/identification.json:per_T.{0,25,45}.fits"
    degc = [f"{{\\SI{{{T}}}{{\\degreeCelsius}}}}" for T in TEMPS]
    L = ["% generated by scripts/04_identify.py (make_tables) from results/identification.json -- do not edit",
         "\\begin{table*}[t]\\centering\\footnotesize\\setlength{\\tabcolsep}{2.4pt}",
         "\\caption{Identified parameters (identification records SP2\\_\\{0,25,45\\}C\\_DST\\_80SOC, voltage RMSE over the "
         "profile, causal input timing). TFO, FO and 2RC: \\SI{95}{\\percent} local-scale circular block-bootstrap intervals "
         f"(block \\SI{{{bc['block_s']:g}}}{{\\second}}, {bc['n_boot']} TRF refits); `bound x\\,\\%' = x\\,\\% of the draws at a box bound "
         "(no percentile interval quoted). FO($\\hat\\alpha_{\\mathrm{TFO}}$) and RCL: point estimates (RCL: $a_p$ and "
         "$\\lambda$ enter only through $a_p+\\lambda$). $R(\\SI{1}{\\second})$: discrete step response one sample after a "
         "current step; $R_{\\mathrm{tot}}$: total DC resistance, $R_0+b_p/(a_p+\\lambda^{\\alpha})$ for the fractional "
         "models and $R_0+R_1+R_2$ for 2RC; bounds: box bounds of the identification.}",
         "\\label{tab:params}",
         "\\begin{tabular}{@{}ll" + "l" * len(TEMPS) + "@{}}", "\\toprule",
         "Parameter (unit) & Bounds & " + " & ".join(degc) + " \\\\"]
    for fam in FAMS:
        L += ["\\midrule", f"\\multicolumn{{{2 + len(TEMPS)}}}{{@{{}}l}}{{\\emph{{{FTEX[fam]}}}}} \\\\"]
        names = ID.FAMILY_FREE[fam] + ["R_1s_Ohm", "R_dc_Ohm"]
        for n in names:
            if n.startswith("R_"):
                bnd = "--"
            else:
                lo, hi = ID.bounds_of(n, B)
                bnd = f"[{bnum(lo)}, {bnum(hi)}]"
            cells = []
            for T in TEMPS:
                P = J["per_T"][str(T)]
                F = P["fits"][fam]
                v = F["step_response"][n] if n.startswith("R_") else F["theta"][n]
                cells.append(fnum(v) + ci_text(P, fam, n))
            L.append(f"\\enspace {PLATEX[n][0]}{PUNIT[n]} & {bnd} & " + " & ".join(cells) + f" \\\\ {src}.{fam}.{n}")
        if fam == "RCL":
            cells = [fnum(J["per_T"][str(T)]["fits"]["RCL"]["derived"]["rcl_effective"]["tau_s"]) for T in TEMPS]
            L.append("\\enspace $1/(a_p+\\lambda)$ (\\si{\\second}) & -- & " + " & ".join(cells)
                     + f" \\\\ {src}.RCL.derived.rcl_effective.tau_s")
        cells = [f"{J['per_T'][str(T)]['fits'][fam]['rmse_mV']:.2f}" for T in TEMPS]
        L.append("\\enspace RMSE (\\si{\\milli\\volt}) & -- & " + " & ".join(cells) + f" \\\\ {src}.{fam}.rmse_mV")
    L += ["\\bottomrule", "\\end{tabular}", "\\end{table*}"]
    (tab / "tab_params.tex").write_text("\n".join(L) + "\n", encoding="utf-8")
    G = vmodel_groups(J)
    zm = s["knee_window"]["z_min"]
    nT = len(TEMPS)
    L = ["% generated by scripts/04_identify.py (make_tables) from results/identification.json -- do not edit",
         "\\begin{table*}[t]\\centering\\footnotesize",
         "\\caption{Open-loop voltage-model accuracy (causal input timing; SOC by Coulomb counting with "
         "$Q_{\\mathrm{id}}(T)$ from the end of CV). RMSE in mV over the whole profile and over "
         f"$z\\ge {zm:g}$; test rows: mean over the 50\\,\\% and 80\\,\\% starts; bold: lowest whole-profile RMSE.}}",
         "\\label{tab:vmodel}",
         "\\begin{tabular}{@{}ll" + "S[table-format=2.1]" * (2 * nT) + "@{}}", "\\toprule",
         f" & & \\multicolumn{{{nT}}}{{c}}{{Whole profile}} & \\multicolumn{{{nT}}}{{c}}{{$z\\ge{zm:g}$}} \\\\",
         f"\\cmidrule(lr){{3-{2 + nT}}}\\cmidrule(l){{{3 + nT}-{2 + 2 * nT}}}",
         "Profile (split) & Model & " + " & ".join(degc) + " & " + " & ".join(degc) + " \\\\", "\\midrule"]
    for gi, (gname, rows) in enumerate(G.items()):
        best = {T: min(rows[T][f]["rmse_mV"] for f in FAMS) for T in TEMPS}
        for k, fam in enumerate(FAMS):
            c1 = [("{\\bfseries %.1f}" if abs(rows[T][fam]["rmse_mV"] - best[T]) < 1e-12 else "%.1f")
                  % rows[T][fam]["rmse_mV"] for T in TEMPS]
            c2 = [f"{rows[T][fam]['rmse_z_ge_knee_mV']:.1f}" for T in TEMPS]
            glab = gname.replace(" %", "\\,\\%") if k == 0 else ""
            L.append(f"{glab} & {FTEX[fam]} & " + " & ".join(c1) + " & " + " & ".join(c2)
                     + f" \\\\ % src: results/identification.json:per_T.{{0,25,45}}.accuracy.<group files>.{fam}")
        L.append("\\midrule" if gi < len(G) - 1 else "\\bottomrule")
    L += ["\\end{tabular}", "\\end{table*}"]
    from tfso.texfix import finalize_table
    (tab / "tab_vmodel.tex").write_text(finalize_table("\n".join(L)) + "\n", encoding="utf-8")


# ======================================================================================
# Report (all numbers read from the JSON)
# ======================================================================================
def _ci(c):
    if c is None or c.get("empty"):
        return "empty"
    lo = f"{c['lo']:.3g}" + ("-" if c.get("lo_at_grid_edge") and c["lo"] > 0 else "")
    hi = f"{c['hi']:.3g}" + ("+" if c.get("hi_at_grid_edge") else "")
    return f"[{lo}, {hi}]"


def make_report(J: dict, rep: Path):
    rep.mkdir(parents=True, exist_ok=True)
    s, hy, V = J["settings"], J["tfgd_hyper"], J["verdicts"]
    PT = lambda T: J["per_T"][str(T)]  # noqa: E731
    tm = J["input_timing"]["primary"]
    zmin = s["knee_window"]["z_min"]
    nfiles = sum(len(PT(T)["files"]) for T in TEMPS)
    p_tfo = len(ID.FAMILY_FREE["TFO"])
    nms = s["multistart"]
    L = ["# Model identification: TFO, FO, FO(alpha_TFO), RCL and 2RC voltage models", "",
         f"Generated by `scripts/04_identify.py` from `results/identification.json` ({J['generated_utc']}, code hash "
         f"{J['code_hash']}); every number is read from that file. Runtime of the full computation "
         f"{J['runtime'].get('full_run_wall_s', J['runtime']['total_wall_s']) / 60:.0f} min wall, "
         f"{J['runtime']['max_workers']} workers (machine- and load-dependent).", "",
         "## 1. Set-up",
         f"* Identification SP2_{{0,25,45}}C_DST_80SOC; validation and 18 test files only evaluated; all {nfiles} files pass "
         f"`data.verify_file`: {all(f['verified'] for T in TEMPS for f in PT(T)['files'].values())}. Q_n = Q_id(T) = " +
         "/".join(f"{J['Q_id_Ah'][str(T)]:.4f}" for T in TEMPS) + " Ah (0/25/45 C). Warm start from the end of CV "
         "(z = 1, V_p = 0 ASSUMED) through rest, 1 A discharge, rest and profile; only the profile is scored.",
         f"* **Input timing**, one convention for all branches: primary `{tm}` (u_n = I_{{n-1}}, current held on "
         "[t_{n-1}, t_n)); sensitivity `implicit_forward` (u_n = I_n, as eq:m4b:observer), `legacy_mixed` (first run: "
         "fractional I_n, 2RC I_{n-1}), `causal_point_output` (point current in R0 I).",
         f"* Objective: RMSE over the profile (sensitivity: z >= {zmin:g} only). Coordinates: log, asinh(lambda/"
         f"{s['lambda_asinh_scale']:g}), linear (alpha, s, dq).",
         f"* FFT vs direct recursion: {len(PT(0)['unit_check']['rows'])} generic sets, max |dV_p| "
         f"{max(PT(T)['unit_check']['max_err_V'] for T in TEMPS):.1e} V; identified sets of all families (full memory and "
         f"N_L = {', '.join(str(x) for x in s['unit_check_N_L'])}; both timings) on the identification and the longest test "
         f"record, {sum(len(PT(T)['unit_check_identified']['rows']) for T in TEMPS)} cases: max |dV_t| "
         f"{max(PT(T)['unit_check_identified']['max_err_V'] for T in TEMPS):.1e} V (tolerance {s['fft']['validation_tol_V']:g} V).", ""]
    L += ["## 2. Input-timing sensitivity (identification RMSE, mV; TRF multistart)", "",
          "| T | timing | TFO | FO | 2RC | RCL | best | TFO R0 (Ohm) | LR_eff(lambda=0) |", "|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        for k, q in PT(T)["sensitivity"].items():
            if k in ("knee", "rp_relaxed"):
                continue
            ff = q["fits"]
            L.append(f"| {T} | {k} | {ff['TFO']['rmse_mV']:.3f} | {ff['FO']['rmse_mV']:.3f} | {ff['2RC']['rmse_mV']:.3f} | "
                     f"{ff['RCL']['rmse_mV']:.3f} | {q['best_family']} | {ff['TFO']['theta']['R0']:.4f} | {q['lambda_LR_eff_at_0']:.2f} |")
    L += ["", "LR_eff = LR/tau_HAC (lambda = 0 rejected if > "
          f"{s['profile_v2']['crit_zero']:.2f}). R_p bound relaxed to {s['sensitivity_rp_relaxed_upper_Ohm']:g} Ohm: RMSE "
          + ", ".join(f"{PT(T)['sensitivity']['rp_relaxed']['delta_vs_primary_mV']:+.3f}" for T in TEMPS) + " mV.", ""]
    L += [f"## 3. Optimiser comparison (TFO, {tm}, {p_tfo} parameters, {nms} LHS starts)",
          f"TFGD nu = {hy['nu']}, lambda_g = {hy['lambda_g']}, eta = {hy['eta']} (a priori; the mV objective unit fixes the "
          f"step scale), N_g = {hy['N_g']}; budget {s['eval_budget']} evaluations, TRF <= {s['trf_max_nfev']}. TFGD per "
          f"iteration: 2p = {2 * p_tfo} evaluations + 1 per Armijo trial, O(N_g p) memory. 'stopped' = own rule met.", "",
          "| T | optimiser | best | median | worst (mV) | within 0.01 mV / 1 % | stopped | mean evals |", "|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        for o in OPTS:
            q = PT(T)["TFO_optimizers"][o]
            L.append(f"| {T} | {OLAB[o]} | {q['best_rmse_mV']:.3f} | {q['median_rmse_mV']:.3f} | {q['worst_rmse_mV']:.3f} | "
                     f"{q['n_within_0p01mV_of_global']} / {q['n_within_1pct_of_global']} | {q['n_stopped_by_criterion']} | {q['mean_nfev']:.0f} |")
    tfl = {T: PT(T)["TFO_optimizers"]["tfgd"] for T in TEMPS}
    L += ["", "TFGD (0/25/45 C): Armijo trials per iteration " + "/".join(f"{tfl[T]['mean_armijo_trials_per_iter']:.1f}" for T in TEMPS) +
          ", evaluations per iteration " + "/".join(f"{tfl[T]['mean_evals_per_iter']:.1f}" for T in TEMPS) +
          ", median memory restarts (disclosed modification: Armijo failure clears the memory, plain-gradient fallback) " +
          "/".join(f"{tfl[T]['median_restarts']:.0f}" for T in TEMPS) + "; tolerance stops > 0.01 mV above the best " +
          "/".join(f"{sum(x['far_from_best'] for x in tfl[T]['stall_labels'])}" for T in TEMPS) + ", of which on a degenerate "
          "R_p/C_p-at-bound plateau " + "/".join(f"{sum(x['degenerate_plateau'] for x in tfl[T]['stall_labels'])}" for T in TEMPS) +
          ". Best optimiser: " + "/".join(OLAB[PT(T)["TFO_best_optimizer"]] for T in TEMPS) + ".", ""]
    L += [f"## 4. Selected fits ({tm}, whole profile; full parameter sets and intervals: tables/tab_params.tex)", "",
          "| T | model | RMSE (mV) | alpha | lambda (1/s) | R0 (Ohm) | R(1 s) (Ohm) | R_dc (Ohm) | at / near bound |",
          "|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        P = PT(T)
        for fam in FAMS:
            F = P["fits"][fam]
            th = F["theta"]
            al = f"{th['alpha']:.3f}" if fam != "2RC" else "-"
            la = f"{th['lam']:.3g}" if fam in ("TFO", "RCL") else "-"
            L.append(f"| {T} | {fam} | {F['rmse_mV']:.3f} | {al} | {la} | {th['R0']:.4f} | "
                     f"{F['step_response']['R_1s_Ohm']:.4f}{ci_text(P, fam, 'R_1s_Ohm', False)} | "
                     f"{F['step_response']['R_dc_Ohm']:.4f}{ci_text(P, fam, 'R_dc_Ohm', False)} | "
                     f"{', '.join(F['at_bound']) or '-'} / {', '.join(F['near_bound']) or '-'} |")
    L += ["", "R(k s) = discrete step response k s after the onset of a current step, same definition for every family; "
          "[95 % bootstrap].", ""]
    L += ["## 5. Identifiability of lambda and alpha (TFO)", "",
          "| T | window | lambda-hat | LR_eff / LR_iid at 0 | RMSE(0) - min (mV) | lambda 95 % | alpha-hat | alpha 95 % | unconv. / cold-best rows |",
          "|---|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        P = PT(T)
        for w in ("full", "knee"):
            pl, pa = P["profile"][w]["lam"], P["profile"][w]["alpha"]
            zt = pl["zero_test"]
            L.append(f"| {T} | {w} | {pl['theta_hat']['lam']:.3g} | {zt['LR_eff']:.2f} / {zt['LR_nominal']:.1f} | "
                     f"{zt['delta_rmse_mV']:.3f} | {_ci(pl['ci_eff'])} | {pa['theta_hat']['alpha']:.3f} | {_ci(pa['ci_eff'])} | "
                     f"{pl['n_unconverged'] + pa['n_unconverged']} / {pl['n_best_from_cold_start'] + pa['n_best_from_cold_start']} |")
    dg = {T: PT(T)["diagnostics"]["full"] for T in TEMPS}
    bc = s["bootstrap_v2"]
    L += ["", f"Profile intervals: HAC n_eff, LR crossings interpolated (log10 lambda), chi2_1 {s['profile_v2']['crit_interior']:.2f} "
          f"for interval ends, chi-bar-square {s['profile_v2']['crit_zero']:.2f} only for lambda = 0; '+'/'-': the set reaches "
          f"the grid edge. Residual dependence (whole profile): tau AR(1) / HAC ({s['neff']['bandwidth_s']:g} s) = " +
          ", ".join(f"{dg[T]['dependence']['ar1']['tau_s_units']:.1f} / {dg[T]['dependence']['tau']:.1f}" for T in TEMPS) +
          "; ACF(360 s) " + "/".join(f"{dg[T]['acf_at_lag_s']['360']:.2f}" for T in TEMPS) + f"; share of SSE from z < {zmin:g}: " +
          "/".join(f"{dg[T]['share_SSE_below_knee'] * 100:.0f} %" for T in TEMPS) + " (" +
          "/".join(f"{dg[T]['frac_samples_below_knee'] * 100:.0f} %" for T in TEMPS) + " of samples).",
          f"Bootstrap: local-scale circular blocks ({bc['block_s']:g} s), {bc['n_boot']} TRF refits (TFO: best of two starts). "
          "TFO draws at a bound: " + "; ".join(
              f"{T} C " + (", ".join(f"{k} {100 * (v['frac_at_lower'] + v['frac_at_upper']):.0f} %"
                                     for k, v in PT(T)["bootstrap"]["TFO_full"]["stats"].items()
                                     if k in ID.FAMILY_FREE["TFO"] and v['frac_at_lower'] + v['frac_at_upper'] > 0) or "none")
              for T in TEMPS) + ". Refit RMSE 5/50/95 % vs fit: " + "; ".join(
              "/".join(f"{x:.1f}" for x in PT(T)["bootstrap"]["TFO_full"]["rmse_quantiles_mV"]) +
              f" vs {PT(T)['bootstrap']['TFO_full']['rmse_hat_mV']:.1f}" for T in TEMPS) +
          " (part of the resampled misfit is absorbable: intervals are indicative). alpha 95 % for blocks " + "/".join(f"{PT(0)['bootstrap'][k]['block_s']:g}" for k in ("TFO_full_L0", "TFO_full", "TFO_full_L1")) +
          " s: " + "; ".join(f"{T} C " + " ".join(_bci(PT(T)["bootstrap"][k]["stats"]["alpha"]) for k in ("TFO_full_L0", "TFO_full", "TFO_full_L1"))
                             for T in TEMPS) + ".",
          "Jacobian correlations on free parameters (> 1 % of the box from a bound): " + "; ".join(
              f"{T} C cond {dg[T]['jacobian']['cond_free']:.0e}, " + _topcorr(dg[T]["jacobian"], 2) for T in TEMPS) + ".", ""]
    L += [f"## 6. Knee-excluded fits (z >= {zmin:g}; RMSE on that window, mV)", "",
          "| T | TFO | FO | FO_alphaTFO | RCL | 2RC | best | TFO alpha, lambda |", "|---|---|---|---|---|---|---|---|"]
    for T in TEMPS:
        k = PT(T)["sensitivity"]["knee"]
        ff = k["fits"]
        L.append(f"| {T} | " + " | ".join(f"{ff[f]['rmse_mV']:.3f}" for f in FAMS) +
                 f" | {k['best_family']} | {ff['TFO']['theta']['alpha']:.3f}, {ff['TFO']['theta']['lam']:.3g} |")
    G = vmodel_groups(J)
    L += ["", f"## 7. Open-loop voltage accuracy ({tm}; RMSE mV averaged over 0/25/45 C, whole / z >= {zmin:g}; per T: tables/tab_vmodel.tex)", "",
          "| profile | " + " | ".join(FAMS) + " |", "|---|" + "---|" * len(FAMS)]
    for g, rows in G.items():
        L.append(f"| {g} | " + " | ".join(f"{np.mean([rows[T][f]['rmse_mV'] for T in TEMPS]):.1f} / "
                                          f"{np.mean([rows[T][f]['rmse_z_ge_knee_mV'] for T in TEMPS]):.1f}" for f in FAMS) + " |")
    lbp = {f: sum(a[f]["ljung_box_p"] < 0.05 for T in TEMPS for a in PT(T)["accuracy"].values()) for f in FAMS}
    L += ["", f"Test ({V['test']['n_files']} files) lowest-RMSE wins: " +
          ", ".join(f"{f} {n}" for f, n in V["test"]["rmse_wins"].items()) + "; median RMSE " +
          ", ".join(f"{f} {v:.1f}" for f, v in V["test"]["median_rmse_mV"].items()) + " mV. Wins with the other fit sets: " +
          "; ".join(f"{k}: " + ", ".join(f"{f} {n}" for f, n in q["rmse_wins"].items() if n) for k, q in V["test_sensitivity"].items()) +
          f". Ljung-Box p < 0.05 in {min(lbp.values())}-{max(lbp.values())}/{nfiles} files for every model.", ""]
    L += ["## 8. Verdicts", ""]
    for T in TEMPS:
        v, lv = V[str(T)], PT(T)["lambda_verdict"]
        bw = lv["LR_eff_by_bandwidth"]
        L.append(f"* **{T} C.** lambda: **{lv['status']}** ({lv['n_tests_rejecting_0']}/{lv['n_tests']} tests reject 0; "
                 "LR_eff whole/knee by HAC bandwidth " + ", ".join(f"{b} s {bw['full'][b]:.2f}/{bw['knee'][b]:.2f}"
                                                                   for b in sorted(bw['full'], key=float)) +
                 f"; lambda-hat {lv['lambda_hat_full']:.2g}). TFO - FO {v['TFO_minus_FO_mV']:+.3f}, TFO - FO(alpha_TFO) "
                 f"{v['TFO_minus_FOalpha_mV']:+.3f}, TFO - 2RC {v['TFO_minus_2RC_mV']:+.3f} mV. TFO at a bound: "
                 f"{', '.join(v['TFO_at_bound']) or 'none'}.")
    bf = V["0"]["best_family_by_set"]
    L.append("* Lowest identification RMSE by fit set (all T identical: " +
             str(all(V[str(T)]["best_family_by_set"] == bf for T in TEMPS)) + "): " + ", ".join(f"{k} {b}" for k, b in bf.items()) +
             f". TFO alpha-hat minus its lower bound {s['bounds']['alpha'][0]:g}: " +
             "/".join(f"{PT(T)['fits']['TFO']['theta']['alpha'] - s['bounds']['alpha'][0]:.3f}" for T in TEMPS) +
             "; 2RC tau1 at its 1 s bound at every T.")
    L += ["* RCL: a_p and lambda are exactly confounded at alpha = 1 (only a_p + lambda identified).",
          "* Caveats: end-of-CV state assumed; pseudo-OCV of other cells aligned per model; alpha(T) and lambda depend on "
          "the objective window and the input timing; HAC-based likelihood intervals are approximate. The eq:m4b observer "
          "drives V_p with I_{m,n} (implicit_forward): to match these parameters it must use I_{m,n-1}, or take the "
          "implicit_forward set (JSON per_T.<T>.sensitivity.implicit_forward).", ""]
    L += review_response(J)
    (rep / "identification_findings.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def review_response(J) -> list[str]:
    """Review response (decisions are the author's; every number is read from the JSON)."""
    s = J["settings"]
    PT = lambda T: J["per_T"][str(T)]  # noqa: E731
    dg = {T: PT(T)["diagnostics"]["full"] for T in TEMPS}
    tm = J["input_timing"]["primary"]
    zt = {T: PT(T)["lambda_verdict"]["zero_test"] for T in TEMPS}
    sens = {T: PT(T)["sensitivity"] for T in TEMPS}
    nunc = sum(PT(T)["profile"][w][p]["n_unconverged"] for T in TEMPS for w in ("full", "knee") for p in ("lam", "alpha"))
    ncold = sum(PT(T)["profile"][w][p]["n_best_from_cold_start"] for T in TEMPS for w in ("full", "knee") for p in ("lam", "alpha"))
    nrows = sum(len(PT(T)["profile"][w][p]["rows"]) for T in TEMPS for w in ("full", "knee") for p in ("lam", "alpha"))
    n2 = sum(PT(T)["bootstrap"]["TFO_full"]["n_best_from_second_start"] for T in TEMPS)
    nb = sum(PT(T)["bootstrap"]["TFO_full"]["n_boot"] for T in TEMPS)
    lm = "legacy_mixed"
    bw = {T: PT(T)["lambda_verdict"]["LR_eff_by_bandwidth"]["knee"] for T in TEMPS}
    R = ["## Review response (2026-09-27)", "",
         "All issues accepted (B1 partly). A = review 0, B = review 1. Evidence from this run.", "",
         "| issue | evidence | change |", "|---|---|---|",
         "| A1 block bootstrap invalid (major) | z < 0.1 holds " + "/".join(f"{dg[T]['share_SSE_below_knee'] * 100:.0f}" for T in TEMPS) +
         " % of the SSE; ACF(360 s) " + "/".join(f"{dg[T]['acf_at_lag_s']['360']:.2f}" for T in TEMPS) +
         "; median refit/fit RMSE " + ", ".join(f"{PT(T)['bootstrap']['TFO_full']['rmse_quantiles_mV'][1]:.1f}/{PT(T)['bootstrap']['TFO_full']['rmse_hat_mV']:.1f}" for T in TEMPS) +
         " | local-scale circular blocks of 2 DST periods; 360/1440 s and knee-window runs; noise model = misfit, stated |",
         "| A2 AR(1) n_eff (major) | tau AR(1)/HAC " + ", ".join(
             f"{dg[T]['dependence']['ar1']['tau_s_units']:.0f}/{dg[T]['dependence']['tau']:.0f}" for T in TEMPS) +
         "; 0 C knee LR_eff " + "/".join(f"{bw[0][b]:.2f}" for b in sorted(bw[0], key=float)) + " (720/1800/3600 s)"
         " | Bartlett HAC n_eff; bandwidth sensitivity; LR and intervals regenerated |",
         "| A3 knee drives alpha, lambda (major) | alpha whole/knee " + ", ".join(
             f"{PT(T)['fits']['TFO']['theta']['alpha']:.2f}/{sens[T]['knee']['fits']['TFO']['theta']['alpha']:.2f}" for T in TEMPS) +
         "; LR_eff(0) " + ", ".join(f"{zt[T]['full']['LR_eff']:.1f}/{zt[T]['knee']['LR_eff']:.1f}" for T in TEMPS) +
         " | knee-excluded fits (all families), profiles, bootstrap; lambda verdict primarily on that window |",
         "| A4 grid-extreme intervals, 2.706 everywhere (minor) | - | interpolated crossings; 2.706 only at lambda = 0; finer grid |",
         f"| A5 lambda = 0 trap (minor) | cold start best at {ncold}/{nrows} profile points; {nunc} unconverged "
         "| asinh coordinate; best of 4 starts; max_nfev 3000 |",
         "| A6 TFGD disclosure (minor) | Armijo trials/iteration " + "/".join(
             f"{PT(T)['TFO_optimizers']['tfgd']['mean_armijo_trials_per_iter']:.1f}" for T in TEMPS) +
         " | 'stopped' column, 0.01 mV/1 % counts, stalls labelled; restart/fallback and step scale disclosed |",
         f"| A7 bootstrap at bounds (minor) | second start better in {n2}/{nb} TFO draws | bound fractions; no interval if > 2.5 % at a bound; two starts |",
         "| A8 near-bound flags, correlations, R(1 s) (minor) | TFO at/near bound: " + "; ".join(
             f"{', '.join(PT(T)['fits']['TFO']['at_bound'] + PT(T)['fits']['TFO']['near_bound']) or 'none'}" for T in TEMPS) +
         " | 1 %-of-box flag; free-parameter correlations; intervals for R(1 s), R_dc |",
         f"| B1 input timing (major) | {lm}/{tm} TFO RMSE " + ", ".join(
             f"{sens[T][lm]['fits']['TFO']['rmse_mV']:.2f}/{sens[T][tm]['fits']['TFO']['rmse_mV']:.2f}" for T in TEMPS) +
         "; R0 " + ", ".join(f"{sens[T][lm]['fits']['TFO']['theta']['R0']:.3f}/{sens[T][tm]['fits']['TFO']['theta']['R0']:.3f}" for T in TEMPS) +
         f" | one convention for all branches, primary {tm} (chosen a priori: no anticipation); 3 alternatives reported. "
         "Partly: M4b and observer code are not mine; mismatch flagged |",
         "| B2 R(1 s) lags differ (minor) | - | step response at equal lag for all families |",
         "| B3, B4 | see A1, A5 | see A1, A5 |",
         f"| B5 narrow FFT check (minor) | {sum(len(PT(T)['unit_check_identified']['rows']) for T in TEMPS)} identified cases, "
         f"max {max(PT(T)['unit_check_identified']['max_err_V'] for T in TEMPS):.1e} V | identified sets, N_L 3600, test record, both timings |",
         "| B6 hand-typed text, caches (minor) | - | constants from settings; CPU column dropped; hashed caches; --from-results uses JSON + npz only |", ""]
    return R


def _bci(st):
    if st["ci_valid"]:
        return f"[{st['ci95'][0]:.3g}, {st['ci95'][1]:.3g}]"
    return f"(bound {100 * (st['frac_at_lower'] + st['frac_at_upper']):.0f} %)"


def _topcorr(jj, k=3):
    C, nm = np.array(jj["corr_free"]), jj["free"]
    pairs = sorted(((abs(C[a, b]), nm[a], nm[b], C[a, b]) for a in range(len(nm)) for b in range(a + 1, len(nm))),
                   reverse=True)[:k]
    return ", ".join(f"{a}-{b} {c:+.3f}" for _, a, b, c in pairs)


def make_all(J, A, fig, tab, rep):
    make_figures(J, A, fig)
    make_tables(J, tab)
    make_report(J, rep)


if __name__ == "__main__":
    main()
