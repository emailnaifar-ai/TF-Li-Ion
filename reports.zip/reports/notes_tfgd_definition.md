# Tempered fractional gradient descent (TFGD): definition used for parameter identification

Source (read on 2026-09-27): O. Naifar, "Theoretical Framework for Tempered Fractional Gradient Descent:
Application to Breast Cancer Classification", arXiv:2504.18849 (2025), pp. 2-8; journal version
"Tempered fractional gradient descent: Theory, algorithms, and robust learning applications",
Neural Networks 193 (2026) 108005, doi 10.1016/j.neunet.2025.108005 (bib keys naifar2025theoretical, naifar2026tempered).

Definition 2.2 (update rule, eq. (2) of the arXiv version):

    theta_{k+1} = theta_k - eta * sum_{j=0}^{k} |w_j| e^{-lambda_g j} grad J(theta_{k-j}),     |w_j| = |binom(nu, j)|,

with fractional order 0 < nu < 1, tempering parameter lambda_g > 0 (dimensionless, per iteration), step size eta.
The paper defines the alignment coefficient d_{nu,lambda_g} = (1 - e^{-lambda_g})^{-nu} (Lemma 4.1) and states an
O(1/K) average-suboptimality rate for convex, L-smooth losses with eta = 1/L (Theorem 4.1), an O(1/k^nu)+O(e^{-2 lambda_g k})
bound for the stochastic variant (Theorem 4.2), and a recursive approximation S_k = |w_0| grad J(theta_k) + e^{-lambda_g} S_{k-1}
(Lemma 5.1) with truncation error O(e^{-lambda_g k}/k^{1+nu}).

Implementation choices for the battery-model identification (to be stated in the manuscript):
- The exact finite-window sum with N_g stored gradients is used (not the one-term recursion); the tempered weights make
  the window truncation error O(e^{-lambda_g N_g}); N_g = ceil(8/lambda_g).
- The alignment coefficient is computed numerically as the actual sum of the retained weights and used to normalise the
  step so that eta has the meaning of a plain gradient step (nu -> 0 or lambda_g -> inf recovers gradient descent).
- Box constraints on the physical parameters are enforced by projection after each step; the gradient of the voltage
  RMSE objective is obtained by central finite differences on log-scaled parameters; an Armijo backtracking rule guards
  the step; stopping: relative objective decrease < 1e-6 over 10 iterations or max_iter.
- Hyper-parameters (nu, lambda_g, eta) are fixed a priori from the config and are NOT tuned on the test profiles.

CALCE page (https://calce.umd.edu/battery-data, read 2026-09-27): INR 18650-20R, 2000 mAh, LiNiMnCo/graphite,
18.33 mm x 64.85 mm; tests: low-current OCV (C/20), incremental-current OCV, dynamic profiles DST/FUDS/US06/BJDST at
80 % and 50 % starting levels at 0, 25, 45 C; samples SP1, SP2 (dynamic), SP3. Required citations: Zheng et al. 2016
Applied Energy 183:513-525 and Xing et al. 2014 Applied Energy 113:106-115. NOTE: the low-current (C/20) OCV files were
NOT supplied with this request; only the incremental-OCV, initial-capacity and dynamic files are available.
