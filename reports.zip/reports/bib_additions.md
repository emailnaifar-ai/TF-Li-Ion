
## Mathematical tools (added 2026-09-27)
| key | source URL | match status |
|---|---|---|
| gautschi1959inequality | https://api.crossref.org/works/10.1002/sapm195938177 | exact match (authors, title, journal, 1959, vol 38, issue 1-4, pp 77-81) |
| wendel1948note | https://api.crossref.org/works/10.2307/2304460 | match; Crossref lists first page only (563); JSTOR DOI used (a separate 10.1080/00029890.1948.11999304 record covers the whole "Mathematical Notes" section pp 558-566, not used) |
| pollard1948completely | https://api.crossref.org/works/10.1090/s0002-9904-1948-09132-7 | exact match (Bull. AMS 54(12), 1115-1116, 1948) |
| farina2000positive | https://api.crossref.org/works/10.1002/9781118033029 | match (Wiley monograph 2000, ISBN 9780471384564; Crossref title "Positive Linear Systems", subtitle "Theory and Applications" per the book cover) |
| berman1994nonnegative | https://api.crossref.org/works/10.1137/1.9781611971262 | match (SIAM 1994, ISBN 9780898713213); series vol 9 from publisher listing (AbeBooks/SIAM catalog, epubs.siam.org returned 403) |

## Estimators (added 2026-09-27, estimators review response)
| key | source URL | match status |
|---|---|---|
| sage1969algorithms | https://api.crossref.org/works/10.1109/sap.1969.269927 | match (title, authors Sage & Husa, 1969 IEEE Symposium on Adaptive Processes (8th) Decision and Control, University Park PA, Nov 1969, p. 61; middle initials P. and W. from the authors' standard citation form, not in the Crossref record). Cited for the Sage-Husa noise-statistics estimator used by AEKF2RC. |
