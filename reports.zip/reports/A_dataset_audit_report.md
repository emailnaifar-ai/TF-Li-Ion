# A. Dataset audit report: CALCE INR18650-20R (SP20-1/2/3) Arbin exports

Deliverable A of the manuscript project (tempered fractional SOC observer). Written 2026-09-27 from the machine-readable audit outputs only. Every number below is copied from one of the following files, cited as `file: key` (JSON) or `file, section` (Markdown); nothing is taken from CALCE documentation or from memory.

* `results/dataset_inventory.json` (generated 2026-09-27T07:39:20+00:00 by `scripts/01_audit.py`; `n_files` = 33) -- abbreviated **INV**
* `reports/dataset_audit.md` (same generator, sections 1-9) -- **AUD**
* `reports/dataset_audit_verification.md` (independent reconciliation, 13 850 field comparisons) -- **VER**
* `results/capacity.json` (generated 2026-09-27T07:39:12+00:00) -- **CAP**
* `config/config.yaml` -- **CFG**
* `src/tfso/data.py` (canonical data layer; all quantities computed there) -- **DATA**

Source (INV: `dataset`): "CALCE Battery Research Group, University of Maryland; INR18650-20R (Samsung), 2000 mAh nominal, samples SP1/SP2/SP3 (Arbin channel exports)". Voltage window in CFG `dataset.voltage_window_V` = [2.5, 4.2]; nominal capacity CFG `dataset.cell_nominal_capacity_Ah` = 2.0; chamber set points CFG `dataset.temperatures_C` = [0, 25, 45].

Independent verification status (VER, section 1): after two fixes to the canonical pipeline (Step_Time reset counting; Info-sheet channel selection), "13 850 field comparisons over 153 field families and all 33 logical ids agree except 79", all 79 being definitional (30 CV-step trapezoid, 45 sign-count) or errors in the independent audit (4 Info-channel labels). No physical quantity is in dispute (VER, section 6).

---

## 1. Provenance and files

21 zip archives -> 33 workbooks -> 33 logical ids (INV: `n_files` = 33; `files[*].source.zip`, `.workbook`, `.md5`, `.size_bytes`). The 12 dynamic-profile archives each hold two workbooks (50 % and 80 % start variants); the 6 incremental-OCV and 3 initial-capacity archives hold one workbook each. Raw rows over all data sheets: 1 304 495; rows after removal of the 12 chunk-boundary duplicates: 1 304 483 (VER, section 5; INV: sum of `files[*].source.n_rows_raw_sheets` and `files[*].n_rows`).

Logical-id convention (DATA `_build_catalog`): `SP{cell}_IC_OCV_{T}C`, `SP{cell}_INITCAP`, `SP2_{T}C_{profile}_{soc}SOC`. Cell names in INV `files[*].cell` are `SP20-1`, `SP20-2`, `SP20-3`.

| # | zip archive | workbook | logical id | cell | T (C) | type | md5 (source workbook) | size (bytes) | rows |
|---|---|---|---|---|---|---|---|---|---|
| 1 | SP1_0C_IC_OCV_02_26_2016.zip | 02_26_2016_SP20-1_0C_incrementalOCV.xls | SP1_IC_OCV_0C | SP20-1 | 0 | incremental_ocv | b96d54f3ae2fc72c9246498881f2a2a8 | 19249261 | 157569 |
| 2 | SP1_25C_IC_OCV_12_2_2015.zip | 12_2_2015_Incremental OCV test_SP20-1.xlsx | SP1_IC_OCV_25C | SP20-1 | 25 | incremental_ocv | da431ebbab1462c454e5273f71aafae6 | 17339012 | 142119 |
| 3 | SP1_45C_IC_OCV_12_09_2015.zip | 12_09_2015_Incremental OCV test_SP20-1.xlsx | SP1_IC_OCV_45C | SP20-1 | 45 | incremental_ocv | c5c6d0887ac8dd7d439c8fc251542716 | 19938726 | 159107 |
| 4 | SP3_0C_IC_OCV_03_09_2016.zip | 03_09_2016_SP20-3_0C_incrementalOCV.xls | SP3_IC_OCV_0C | SP20-3 | 0 | incremental_ocv | f9c5b9176613b2ef5afddf88b0882bb4 | 19920186 | 157729 |
| 5 | SP3_25C_IC_OCV_12_2_2015.zip | 12_2_2015_Incremental OCV test_SP20-3.xlsx | SP3_IC_OCV_25C | SP20-3 | 25 | incremental_ocv | 5e9f5537c1e5e60ac5d919cbb48d4180 | 20155824 | 165694 |
| 6 | SP3_45C_IC_OCV_12_09_2015.zip | 12_09_2015_Incremental OCV test_SP20-3.xlsx | SP3_IC_OCV_45C | SP20-3 | 45 | incremental_ocv | ef79b80b45c3ace28ed573264fa9ccba | 19458537 | 158247 |
| 7 | SP1_Initial capacity_10_16_2015.zip | 10_16_2015_Initial capacity_SP20-1.xlsx | SP1_INITCAP | SP20-1 | 25 | initial_capacity | 8512e93a9cc4fa97dba7fce65b0e8b29 | 3927323 | 27602 |
| 8 | SP2_Initial_capacity_10_16_2015.zip | 10_16_2015_Initial capacity_SP20-2.xls | SP2_INITCAP | SP20-2 | 25 | initial_capacity | e5777abdfeae57d0866fe4a266f44a77 | 3738806 | 26322 |
| 9 | SP3_Initial capacity_10_16_2015.zip | 10_16_2015_Initial capacity_SP20-3.xls | SP3_INITCAP | SP20-3 | 25 | initial_capacity | 0faa14cf8b92663279b0cdbf8559b321 | 4142560 | 29110 |
| 10 | SP2_0C_DST.zip | 02_24_2016_SP20-2_0C_DST_50SOC.xls | SP2_0C_DST_50SOC | SP20-2 | 0 | dynamic DST 50 % | e6839c55aa8845034ad28ea3c9bf6327 | 1653235 | 8084 |
| 10 | SP2_0C_DST.zip | 02_24_2016_SP20-2_0C_DST_80SOC.xls | SP2_0C_DST_80SOC | SP20-2 | 0 | dynamic DST 80 % | a1eac43728b4bdbb9c2fa1721e13e02a | 1634641 | 10311 |
| 11 | SP2_0C_FUDS.zip | 02_25_2016_SP20-2_0C_FUDS_50SOC.xls | SP2_0C_FUDS_50SOC | SP20-2 | 0 | dynamic FUDS 50 % | 69ddf10d44a6ad23999308387a99cd97 | 1533871 | 9057 |
| 11 | SP2_0C_FUDS.zip | 02_25_2016_SP20-2_0C_FUDS_80SOC.xls | SP2_0C_FUDS_80SOC | SP20-2 | 0 | dynamic FUDS 80 % | 6f4f7b0608cf42c206360bc980f43c96 | 1989587 | 11614 |
| 12 | SP2_0C_US06.zip | 02_26_2016_SP20-2_0C_US06_50SOC.xls | SP2_0C_US06_50SOC | SP20-2 | 0 | dynamic US06 50 % | b4dd64043c511a64ccba46f25fb863d3 | 1343178 | 8056 |
| 12 | SP2_0C_US06.zip | 02_26_2016_SP20-2_0C_US06_80SOC.xls | SP2_0C_US06_80SOC | SP20-2 | 0 | dynamic US06 80 % | 1a800915d92925b72c237ceeeac8865e | 1987465 | 11445 |
| 13 | SP2_0C_BJDST.zip | 02_29_2016_SP20-2_0C_BJDST_50SOC.xls | SP2_0C_BJDST_50SOC | SP20-2 | 0 | dynamic BJDST 50 % | 6b3ce63ffb9fdadb044e6e240d7ee20b | 2041802 | 14564 |
| 13 | SP2_0C_BJDST.zip | 02_27_2016_SP20-2_0C_BJDST_80SOC.xls | SP2_0C_BJDST_80SOC | SP20-2 | 0 | dynamic BJDST 80 % | 7df1e0de295ec2b64ab9e66541189c17 | 2678627 | 18513 |
| 14 | SP2_25C_DST.zip | 11_05_2015_SP20-2_DST_50SOC.xls | SP2_25C_DST_50SOC | SP20-2 | 25 | dynamic DST 50 % | 3831073181fcfdf2f39ab374eb0474c7 | 1574141 | 9501 |
| 14 | SP2_25C_DST.zip | 11_05_2015_SP20-2_DST_80SOC.xls | SP2_25C_DST_80SOC | SP20-2 | 25 | dynamic DST 80 % | 85822528c7e9c0d521bd55672f0f5871 | 1927603 | 12561 |
| 15 | SP2_25C_FUDS.zip | 11_09_2015_SP20-2_FUDS_50SOC.xls | SP2_25C_FUDS_50SOC | SP20-2 | 25 | dynamic FUDS 50 % | 507cd7359f91d2a38974e3ef0c6fe1e7 | 1504507 | 9308 |
| 15 | SP2_25C_FUDS.zip | 11_06_2015_SP20-2_FUDS_80SOC.xls | SP2_25C_FUDS_80SOC | SP20-2 | 25 | dynamic FUDS 80 % | 66883a54b220c440cda43bd1bcc7118f | 2254539 | 13681 |
| 16 | SP2_25C_US06.zip | 11_11_2015_SP20-2_US06_50SOC.xls | SP2_25C_US06_50SOC | SP20-2 | 25 | dynamic US06 50 % | 03ac504c41712e57c81854b1b4783ffc | 1437275 | 8321 |
| 16 | SP2_25C_US06.zip | 11_11_2015_SP20-2_US06_80SOC.xls | SP2_25C_US06_80SOC | SP20-2 | 25 | dynamic US06 80 % | d38cb3038ee9be69537797115a1b4659 | 2222473 | 11898 |
| 17 | SP2_25C_BJDST.zip | 11_13_2015_SP20-2_BJDST_50SOC.xls | SP2_25C_BJDST_50SOC | SP20-2 | 25 | dynamic BJDST 50 % | 0c53e90d159b1ec563a3f12f2a5505ef | 1355663 | 8385 |
| 17 | SP2_25C_BJDST.zip | 11_12_2015_SP20-2_BJDST_80SOC.xls | SP2_25C_BJDST_80SOC | SP20-2 | 25 | dynamic BJDST 80 % | 6f886ecc97bd45eeccaaa4c012c733a0 | 1950650 | 12437 |
| 18 | SP2_45C_DST.zip | 12_11_2015_SP20-2_45C_DST_50SOC.xls | SP2_45C_DST_50SOC | SP20-2 | 45 | dynamic DST 50 % | 83d668e221e35e7e02c2894b17c2fd5c | 1523335 | 9089 |
| 18 | SP2_45C_DST.zip | 12_11_2015_SP20-2_45C_DST_80SOC.xls | SP2_45C_DST_80SOC | SP20-2 | 45 | dynamic DST 80 % | 57a5085f9fc3bdede2d6d206c4f40295 | 2312072 | 13621 |
| 19 | SP2_45C_FUDS.zip | 12_15_2015_SP20-2_45C_FUDS_50SOC.xls | SP2_45C_FUDS_50SOC | SP20-2 | 45 | dynamic FUDS 50 % | 41d8f9d7ec938dc34ef54f0403b7cf54 | 1801523 | 9593 |
| 19 | SP2_45C_FUDS.zip | 12_15_2015_SP20-2_45C_FUDS_80SOC.xls | SP2_45C_FUDS_80SOC | SP20-2 | 45 | dynamic FUDS 80 % | cfc8f0ef604da03ce274641eed7390e8 | 2583010 | 13520 |
| 20 | SP2_45C_US06.zip | 12_16_2015_SP20-2_45C_US06_50SOC.xls | SP2_45C_US06_50SOC | SP20-2 | 45 | dynamic US06 50 % | 3e2be0f2b0ae7e31a79feb6a16530303 | 1757106 | 9105 |
| 20 | SP2_45C_US06.zip | 12_16_2015_SP20-2_45C_US06_80SOC.xls | SP2_45C_US06_80SOC | SP20-2 | 45 | dynamic US06 80 % | 882b442c19cf955db5e4b35bed3a47db | 2514475 | 12786 |
| 21 | SP2_45C_BJDST.zip | 12_17_2015_SP20-2_45C_BJDST_50SOC.xls | SP2_45C_BJDST_50SOC | SP20-2 | 45 | dynamic BJDST 50 % | 21ebc7a01f5be2aa975d889c0aa73a20 | 2411685 | 15840 |
| 21 | SP2_45C_BJDST.zip | 12_17_2015_SP20-2_45C_BJDST_80SOC.xls | SP2_45C_BJDST_80SOC | SP20-2 | 45 | dynamic BJDST 80 % | 0c91d079cccf457e692ce33b127860c0 | 3086373 | 19694 |

(INV: `files[id].source.zip`, `.workbook`, `.md5`, `.size_bytes`; `files[id].n_rows`. The md5 of every source workbook matches `data_manifest.json`, INV: `files[*].verification.md5_matches_manifest` = true for all 33; the processed-CSV md5s (`files[*].source.csv_md5`) also match, `csv_md5_matches_manifest` = true, and were byte-identical between the two independent audits, VER section 4.9.)

Workbook layout (AUD, section 2, second table; INV `files[*].source.data_sheets`, `.rows_per_sheet`): the 6 incremental-OCV workbooks are chunked into three data sheets of 63990 rows (`Channel_1-005_1/_2/_3` for SP1, `Channel_1-006_1/_2/_3` for SP3; DATA `CHUNK_ROWS` = 63990) whose boundary rows are repeated (2 duplicates per file, rows [63990, 127980] of the concatenation, dropped by DATA `_drop_chunk_duplicates`); the SP1 initial-capacity `.xlsx` holds its data in `Sheet1` with empty `Sheet2`/`Sheet3` and no `Info` sheet (VER, section 4.8); every other workbook has one `Info` sheet and one data sheet (`Channel_1-006` at 0 C, `Channel_1-008` at 25 C, `Channel_1-005` at 45 C for SP2; `Channel_1-015`/`Channel_1-016` for SP2/SP3 initial capacity). Info-sheet schedule files (INV `files[*].source.info_schedule_file`): `SP20_0.1SOC_0.5C.sdu` for all six OCV tests, `SG_Ch_Dch_Ch.sdu` for SP2/SP3 initial capacity (none for SP1), and `SP20_{DST,FUDS,US06,BJDST}_Current_Sim.sdu` for the dynamic files. Test dates (from workbook names and `Date_Time`): initial capacity 2015-10-16; 25 C dynamic 2015-11-05 to 11-13; 45 C OCV 2015-12-09 and 45 C dynamic 2015-12-11 to 12-17; 25 C OCV 2015-12-02; 0 C dynamic 2016-02-24 to 02-29; 0 C OCV 2016-02-26 (SP1) and 2016-03-09 (SP3).

Processed CSV naming (DATA `_csv_name`): workbook stem with every non-alphanumeric run replaced by `_`, under `data_processed/` (CFG `paths.data_processed`).

## 2. Channels, units and sign convention

Columns (INV: `columns`; identical in all 33 workbooks, AUD section 1): `Data_Point`, `Test_Time(s)`, `Date_Time`, `Step_Time(s)`, `Step_Index`, `Cycle_Index`, `Current(A)`, `Voltage(V)`, `Charge_Capacity(Ah)`, `Discharge_Capacity(Ah)`, `Charge_Energy(Wh)`, `Discharge_Energy(Wh)`, `dV/dt(V/s)`, `Internal_Resistance(Ohm)`, `Is_FC_Data`, `AC_Impedance(Ohm)`, `ACI_Phase_Angle(Deg)` (17 columns).

Channel mapping and units (INV: `channels`, `units`; DATA `CHANNELS`, `UNITS`):

| quantity | column | unit | note |
|---|---|---|---|
| current | `Current(A)` | A | > 0 charge, < 0 discharge (verified, below) |
| voltage | `Voltage(V)` | V | terminal voltage |
| time | `Test_Time(s)` | s | the clock used everywhere (DATA module docstring) |
| wall clock | `Date_Time` | 1 s resolution | drifts relative to `Test_Time(s)` (section 5) |
| step time / index / cycle | `Step_Time(s)`, `Step_Index`, `Cycle_Index` | s, -, - | schedule bookkeeping |
| capacity | `Charge_Capacity(Ah)`, `Discharge_Capacity(Ah)` | Ah | cumulative over the test, used as cross-check for our trapezoidal integration |
| energy | `Charge_Energy(Wh)`, `Discharge_Energy(Wh)` | Wh | not used |
| temperature | none | degC (chamber set point only; not a logged channel) | INV `channels.temperature` = null |

Constant-zero columns (INV `files[*].channels.constant_zero_columns`): `Internal_Resistance(Ohm)`, `Is_FC_Data`, `AC_Impedance(Ohm)`, `ACI_Phase_Angle(Deg)` are identically zero in all 30 dynamic and OCV files. `Internal_Resistance(Ohm)` is non-zero only in the three initial-capacity files (VER, section 4.7: 16405 / 15555 / 17425 non-zero samples, 4 unique values, max 0.1230 / 0.0637 / 0.1521 Ohm for SP1/SP2/SP3, first non-zero at `Data_Point` 11198 / 10683 / 11686); it is a tester-side estimate, not an EIS measurement, and is not used. No AC impedance data exist in any file.

Temperature (INV: `temperature_note`): "Chamber set point taken from the file name / Info-sheet test name. No temperature channel exists in any export (the Info sheet reports Temp = 0 auxiliary channels)."

Sign convention (INV: `sign_convention`; per file `files[*].sign_convention`): "Arbin: Current(A) > 0 charge, < 0 discharge (verified against Charge_/Discharge_Capacity columns in the audit)". Numerical evidence (DATA `sign_convention_check`: sample pairs with midpoint |I| > 0.05 A):

* fraction of pairs with `I > 0` for which `Charge_Capacity(Ah)` increases: minimum over the 33 files 0.9987 (INV `files[*].sign_convention.frac_charge_capacity_increasing_when_I_positive`; AUD section 3 column `P(dQc>0 | I>0)`, all >= 0.9987, 1.0000 in most dynamic files);
* fraction of pairs with `I < 0` for which `Discharge_Capacity(Ah)` increases: minimum 0.9985 (`frac_discharge_capacity_increasing_when_I_negative`; AUD section 3, all >= 0.9985);
* example SP2_25C_DST_80SOC: 1211 positive and 7304 negative pairs, fractions 1.0000 and 0.99986; the wrong-direction fractions are 0.0974 (`frac_discharge_capacity_increasing_when_I_positive`) and 0.0122 (`frac_charge_capacity_increasing_when_I_negative`) (INV `files[SP2_25C_DST_80SOC].sign_convention`);
* `verified` = true in all 33 files (INV `files[*].verification.sign_convention_verified`). The independent audit reproduces the same conclusion with a different pair definition (VER, section 4.5: "fractions >= 0.998 in every file").

Current and voltage ranges (INV `files[*].verification.I_abs_max_A`, `V_min_V`, `V_max_V`; AUD section 3): |I| max 1.000-1.002 A in the OCV and capacity files; 3.996-4.002 A in the DST/FUDS/US06 dynamic files and 1.667-1.668 A in the BJDST files; V min 2.403-3.198 V, V max 4.200-4.376 V (the values outside [2.5, 4.2] are listed in section 5). All 33 files pass `current_within_5A` and `voltage_within_2p3_4p4` (INV `files[*].verification`).

Missing values: 0 in every column of every file (INV `files[*].missing_values_per_column`, all zeros; `verification.no_missing_values` = true).

## 3. Test protocols

### 3.1 Dynamic profiles (24 files, cell SP20-2 only)

Step table observed (AUD, section 5; INV `files[*].sampling.per_step`, `segments_charge_discharge`, `segments_rest`):

| Step_Index | content | logging | example SP2_25C_DST_80SOC (INV `files[SP2_25C_DST_80SOC]`) |
|---|---|---|---|
| 1 | one rest sample | -- | n = 1, t = 60.0 s, V = 3.9382 V |
| 2 | CC 1 A charge to 4.2 V | 10 s | n = 102, 0.2827 Ah, 4.0201 -> 4.2001 V, 1007.9 s |
| 3 | CV 4.2 V to ~0.02 A | 10 s | n = 229, 0.1405 Ah, I end 0.0198 A, 2275.5 s |
| 4 | rest 2 h | 10 s | n = 720, 7190.0 s, dV = -4.7 mV |
| 5 | CC 1 A discharge of (1 - label) x schedule capacity | 10 s | n = 144, 0.4001 Ah, 1430.0 s, 4.1130 -> 3.8472 V |
| 6 | rest 2 h | 10 s | n = 720, 7190.0 s, 3.9291 -> 3.9534 V (+24.3 mV) |
| 7 | dynamic current profile until 2.5 V | ~1 s | n = 10621, 10710.2 s, 29 profile repetitions, net -1.5963 Ah (Arbin) / -1.5991 Ah (trapezoid) |
| 8 | interleaved logger rows (360 s / 1372 s cadence; `Current` written as 0; `Test_Time` coincides with a step-7 row) | -- | n = 24, dropped |

Pre-profile discharge (step 5) measured per temperature (AUD section 5; INV `files[*].dynamic.pre_profile_discharge.Ah_arbin`): 0 C 0.3614-0.3615 Ah (80 %) / 0.9034-0.9035 Ah (50 %); 25 C 0.4001 Ah / 1.0001-1.0002 Ah; 45 C 0.3999-0.4000 Ah / 0.9998-0.9999 Ah. Implied schedule capacity (INV `files[*].reference_soc.schedule_reference_capacity_Ah`): 1.8069-1.8073 Ah at 0 C, 2.0002-2.0004 Ah at 25 C, 1.9997-1.9998 Ah at 45 C, i.e. the 0 C schedules define the 50/80 % labels relative to 1.8 Ah, the 25/45 C schedules relative to 2.0 Ah.

Profiles (INV `files[*].dynamic.current_levels_step7`, AUD section 5): DST is an 8-level staircase (-0.50, 0.00, -1.00, -2.50, +0.50, -4.00, +1.00, +2.00 A; e.g. 4522 / 2578 / 1619 / 717 / 480 / 240 / 232 / 232 samples in SP2_25C_DST_80SOC), BJDST a 19-level staircase between -1.67 and +0.44 A, FUDS and US06 continuous-valued drive cycles with peaks -4.00 A / +2.14 A (FUDS) and -3.996 A / +0.859 A (US06) (INV `files[*].dynamic.I_min`, `.I_max`). Profile durations 5977-11746 s (INV `files[*].dynamic.profile_duration_s`); step-7 samples 5918-11626 per file, 208 888 in total over the 24 files; step-8 rows 4-25 per file, 246 in total (INV `files[*].dynamic.n_samples_step7`, `.n_step8_logger_rows_dropped`). The profile step is scheduled as a loop: `Step_Time(s)` resets 5-31 times per file (INV `files[*].discontinuities.n_step_time_resets_within_step`; VER section 4.1 lists all 24 counts: 16, 26, 5, 7, 9, 15, 6, 11, 18, 29, 5, 8, 11, 17, 7, 12, 19, 31, 5, 8, 11, 18, 8, 12).

### 3.2 Incremental OCV (6 files, cells SP20-1 and SP20-3, one per temperature)

Step table observed (AUD, section 6; INV `files[*].incremental_ocv`):

| cycle / step | content | logging | notes |
|---|---|---|---|
| 1 / 1 | 6 rest samples | 10 s | cell already at 4.052-4.179 V (INV `incremental_ocv.initial_state.V_first`) |
| 1 / 2 | CC 1 A to 4.2 V | -- | only 1-4 samples (`initial_state.cc_step2_n`); first sample overshoots to 4.201-4.376 V |
| 1 / 3 | CV 4.2 V to 0.1 A | 10 s | adds 0.0140-0.1697 Ah (`initial_state.cv_step3_Ah`); cutoff 0.100 A (`cv_end_current_A`), not 0.02 A |
| 1 / 4 | rest 2 h | 10 s | 7190 s; SOC = 1 anchor |
| k / 5 then k / 6, k = 1..10 | 1 A discharge pulse of 0.1 x schedule capacity, then rest 2 h at ~1 s | 1 s | pulses 0.2000 Ah at 25/45 C, 0.1806 Ah (SP1) / 0.1831 Ah (SP3) at 0 C (`incremental_ocv.discharge_pulse_Ah`); rest 7199 s (`relaxation_durations_s`); the rest after a pulse terminated by the 2.5 V cutoff is numbered step 8 |
| k / 9 then k / 10, k = 11..18(19) | 1 A charge pulse (time-limited) then rest 2 h | 1 s | 8-10 charge pulses of 0.1999-0.2000 Ah (0.1805 / 0.1830 Ah at 0 C) |
| 19 / 12 or 14, 13, 15, 16 | CC to 4.2 V, rest 2 h, CV to 0.1 A, rest 2 h | 1 s | absent in SP1_IC_OCV_25C (truncated, section 5) |

Per file (AUD section 6 table): 10 discharge pulses in every file; charge pulses 9 / 8 / 9 / 9 / 10 / 9 (SP1 0/25/45 C, SP3 0/25/45 C); relaxations after 1 A pulses 19 / 18 / 19 / 19 / 20 / 19 (INV `incremental_ocv.n_relaxations_after_1A_pulses`); relaxed OCV points (rests >= 3600 s) 21 / 19 / 21 / 21 / 22 / 21 (INV `incremental_ocv.ocv_points`, DATA `get_ocv_points`). The SOC label of every relaxed point is `1 - net_Ah / Q_total` with `Q_total` this file's own total discharged Ah after the initial full charge (INV `files[*].reference_soc.anchoring` for OCV files). Relaxed voltages at the 0.5 SOC discharge point, for illustration: 3.6878 (SP1 0 C), 3.6648 (SP1 25 C), 3.6716 (SP1 45 C), 3.6710 (SP3 0 C, label 0.4814), 3.6710 (SP3 25 C), 3.6778 V (SP3 45 C) (AUD section 6 tables, column `V end`).

### 3.3 Initial capacity (3 files, one per cell, 25 C)

Step table observed (AUD, section 9, `SP1_INITCAP` / `SP2_INITCAP` / `SP3_INITCAP`; INV `files[*].initial_capacity`):

| Step_Index | content | logging | SP1 | SP2 | SP3 |
|---|---|---|---|---|---|
| 1 | rest 60 samples | 1 s | 3.4343 V | 3.4414 V | 3.4475 V |
| 2 | CC 1 A to 4.2 V | 1 s | 1.7199 Ah, 6190.9 s | 1.7992 Ah, 6475.7 s | 1.6567 Ah, 5964.9 s |
| 3 | CV 4.2 V to 0.02 A | 1 s | 0.2764 Ah, I end 0.0198 A | 0.1984 Ah, 0.0199 A | 0.3128 Ah, 0.0199 A |
| 4, 5 | rest (1 sample + 1799 s) | 1 s | dV -5.2 mV | -5.2 mV | -4.4 mV |
| 6 | CC 1 A discharge to 2.5 V | 1 s | 2.0094 Ah, 7232.2 s, V end 2.4999 | 2.0283 Ah, 7299.2 s, 2.5000 (208 s unlogged pause) | 1.9775 Ah, 7116.4 s, 2.4999 |
| 7, 8 | rest (1 sample + 1799 s) | 1 s | 2.8205 -> 3.3881 V | 2.7653 -> 3.3407 V | 2.8636 -> 3.4034 V |
| 9 | CC 1 A to 4.2 V | 10 s | 1.7404 Ah | 1.8452 Ah | 1.6451 Ah |
| 10 | CV to 0.02 A | 1 s | 0.2688 Ah | 0.1889 Ah | 0.3422 Ah |
| 11, 12 | rest (1 sample + 299 s) | 1 s | end 4.1959 V | 4.1972 V | 4.1958 V |

## 4. Sampling: nominal vs observed, and the resampling decision

### 4.1 Nominal and observed intervals

Nominal (CFG `dataset.nominal_sampling_s`): dynamic 1.0 s, rest after pulse 1.0 s, CC/CV charge 10.0 s.

Observed (INV `files[*].sampling.per_step`, `.overall`; AUD section 7):

| segment type | observed median dt | min / max inside segments | files |
|---|---|---|---|
| dynamic profile (step 7) | 1.0155-1.0156 s in 22 files; 1.0030 s (SP2_25C_US06_50SOC) and 1.0029 s (SP2_25C_BJDST_80SOC) | min 0.013 s (SP2_25C_US06_50SOC) to 0.625 s; max 1.017-1.035 s, with 1.469 s (SP2_25C_FUDS_50SOC), 1.559 s (SP2_25C_US06_50SOC), 1.616 s (SP2_45C_DST_80SOC); p5 = 1.0000 s, p95 = 1.0157 s in 22 files (INV `files[*].dynamic.dt_observed_step7`) | 24 dynamic |
| CC charge, CV, discharge, rests in dynamic files | 10.015-10.016 s (10.004-10.008 s in the two 25 C files above) | rests: 0.22-10.14 s; CV: 1.4-10.4 s | 24 dynamic |
| 1 A pulses and 2 h rests in OCV files | 1.0155-1.0156 s | 0.015-10.02 s (isolated short intervals at segment starts) | 6 OCV |
| initial CV, first rests in OCV files; CC charge in capacity files | 5.5-10.02 s (mixed 1 s / 10 s cadence) | 0.03-10.02 s | 6 OCV + 3 capacity |
| capacity discharge (step 6) | 1.0155-1.0156 s | 0.17-1.02 s | 3 capacity |
| whole file | 1.0155-1.0156 s (1.0030 / 1.0029 s in the two 25 C files) | overall min 0.00003-0.14 s, overall max 10.016-10.417 s | 33 |

The logging clock therefore runs about 1.55 % slow relative to the 1 s nominal in 31 files (median 1.0155 s) and 0.3 % slow in the two 25 C files (1.0030 / 1.0029 s) (AUD section 8, "Logging clock"). Step-8 logger rows in the dynamic files have their own cadence (e.g. INV `files[SP2_25C_DST_80SOC].sampling.per_step[step 8]`: dt median 360.0 s, max 720.0 s; `files[SP2_0C_BJDST_50SOC]`: 916.0 s / 1832.0 s) and sit within 0.0171 s of a step-7 sample (INV `files[*].dynamic.logger_rows.max_gap_to_step7_sample_s`, maximum over the 24 files 0.01714 s) with `max_abs_current_A` = 0.0 in every file.

Integrity of the time base (INV `files[*].verification`, `files[*].discontinuities`; AUD section 8): after removal of the 12 chunk-boundary duplicates, 0 repeated `Test_Time` values, 0 negative dt, `Data_Point` strictly increasing, and 0 intervals larger than 3x the segment median (`n_dt_gt_3x_segment_median` = 0) in all 33 files. `Date_Time` drifts by -0.8 to +9.2 s over a test relative to `Test_Time(s)` (INV `files[*].date_time.drift_min_s`, `.drift_max_s`; maximum 9.19 s in SP2_45C_DST_80SOC), apart from the 209.8 s jump in SP2_INITCAP (section 5). `Test_Time(s)` is the only clock used (INV `files[*].date_time.statement`).

### 4.2 Resampling decision

Decision (CFG `dataset.resample_h_s` = 1.0; implemented in DATA `get_dynamic_profile`; INV `files[*].dynamic.resampling` = "V: linear interpolation; I: charge-conserving mean of the piecewise-linear irregular current over each grid interval"):

1. keep only `Step_Index` = 7 rows (CFG `dataset.dynamic_profile_step_index` = 7) and drop `Step_Index` = 8 rows (CFG `dataset.logger_step_index_to_drop` = 8) -- they are never merged;
2. remove duplicate timestamps keeping the first (INV `files[*].dynamic.n_duplicate_timestamps_removed` = 0 in all 24 files after the step-8 drop);
3. re-base time to 0 at the first step-7 sample; build the uniform grid `t_u = 0, h, 2h, ...` up to the last irregular sample (`n_uniform_grid` = 5978-11746 points, 210 773 in total over the 24 files, INV `files[*].dynamic.n_uniform_grid`);
4. voltage: `V_u = interp(t_u, t_raw, V_raw)` (linear);
5. current: `I_u[k] = (Q(t_k + h) - Q(t_k)) / h` with `Q` the trapezoidal cumulative charge of the irregular record (mean of the piecewise-linear current over each grid interval; charge-conserving at every grid point).

Consequences for a Grünwald-Letnikov (GL) memory computation:

* The tempered GL weights `w_k^{(alpha,lambda)} = (-1)^k C(alpha, k) e^{-lambda k h}` and the discrete operator `h^{-alpha} sum_k w_k x(t - k h)` presuppose a **uniform step h**. The raw step-7 record is not uniform (median 1.0155 s, p5 1.0000 s, p95 1.0157 s, extremes 0.013-1.616 s, INV `files[*].dynamic.dt_observed_step7`), so the operator cannot be applied to the raw samples without either a variable-step GL scheme or resampling; the project resamples. The same uniform grid is what the observer sweeps in CFG `observer.h_s` = [1, 2, 5, 10] and what the identification objective is defined on (CFG `identification.objective` = "voltage RMSE on identification profile (uniform 1 s grid)").
* Because the logged interval is 1.0155 s and the grid is 1.0 s, the grid slides past the logged samples by 15.5 ms per step, so almost every grid point lies strictly between two logged samples; linear interpolation of `V` there acts as a **mild low-pass on V only** (a two-point weighted average whose support never exceeds one logged interval; the offset cycles through a full logged interval every ~65 grid points, where interpolation returns exactly a logged value again). The attenuation is negligible for the voltage dynamics of interest (time constants of tens of seconds and longer) and no filtering at all is applied to `I`.
* **Current resampling and charge.** The grid current is the interval mean of the piecewise-linear logged current, so the net step-7 Ah on the grid equals the trapezoidal net Ah of the raw record to within 0.057 % in every file (INV `files[*].dynamic.net_Ah_step7_grid` vs `net_Ah_step7_trapz`; the residual is the < h tail after the last grid point). The gross throughput per direction is NOT preserved where a grid interval straddles a charge/discharge reversal: the grid charge-direction Ah is 6.5-15.3 % and the discharge-direction Ah 0.3-1.6 % below the raw values (INV `files[*].dynamic.throughput_step7`). This is immaterial for SOC with `eta` = 1 (only the net charge enters) but must be revisited before a direction-dependent efficiency is applied on the grid.
* Memory truncation is studied separately (CFG `observer.memory_L_s` = [50, 100, 200, 400, 800, 1600, 3200, full]); the profile lengths 5977-11746 s (INV `files[*].dynamic.profile_duration_s`) set the meaning of "full".

## 5. Data-quality findings

All 33 files pass every mandatory check (INV `files[*].verification.passed` = true; AUD section 3 "all checks passed for all files"). Findings, with numbers (INV `files[*].anomalies`, AUD section 8 unless stated):

1. **No temperature channel** in any of the 33 files (INV `channels.temperature` = null). Temperatures are the chamber set points 0 / 25 / 45 C from the file names.
2. **Chunked exports** (6 OCV workbooks, three sheets of 63990 rows): the last row of each sheet is repeated as the first row of the next; 2 exact duplicates per file (rows [63990, 127980] of the concatenation), 12 in total, dropped at conversion (INV `files[*].source.chunk_duplicate_rows_dropped`; VER section 4.9 confirms the same rows). After this, 0 repeated timestamps and 0 negative dt remain in all files.
3. **Step-8 logger rows** in all 24 dynamic files: 246 rows in total, 4-25 per file, each within 0.0171 s of a step-7 sample, `Current(A)` written as 0 (max |I| 0.0000 A); dropped, never merged (INV `files[*].dynamic.logger_rows`). Their presence hid 24 / 21 / 12 of the loop-boundary `Step_Time` resets in the first version of the audit (VER section 4.1, fixed).
4. **Unlogged pause in SP2_INITCAP**: `Date_Time` jumps by 208 s relative to `Test_Time` at row 19603 during the 1 A discharge (CAP `initial_capacity_1A_25C_Ah.SP2.unlogged_pause`: `pause_s` = 208.16, `V_before_pause` = 2.5573 V, `V_after_pause` = 3.2902 V, `Q_before_pause_Ah` = 2.0048); the discharge resumed and the logged total is 2.0283 Ah. This is the only "unexplained voltage jump" (|dV| > 0.3 V with |dI| < 0.05 A) in the whole dataset (INV `files[SP2_INITCAP].discontinuities.unexplained_voltage_jumps`: V 2.5573 -> 3.2902 V, I = -1.0002 A, dt = 0.844 s). The independent audit measured the same event (VER section 4.10: wall gap 209 s minus the 0.844 s `Test_Time` step).
5. **Date_Time drift** of up to 9.2 s per test relative to `Test_Time(s)` (INV `files[*].date_time.drift_max_s`, max 9.19 s in SP2_45C_DST_80SOC; min -0.76 s in SP2_25C_FUDS_50SOC).
6. **Truncated file**: SP1_IC_OCV_25C ends in cycle 18 step 9 (a charge pulse of 274 samples); the final CC/CV recharge and rest are missing (INV `files[SP1_IC_OCV_25C].incremental_ocv.last_step`; AUD section 6: `Step_Index` set [1, 2, 3, 4, 5, 6, 8, 9, 10]). It still carries 10 discharge and 8 charge relaxations.
7. **Discharge branches that did not reach 2.5 V** (schedule-limited, so the totals are lower bounds of the capacity): SP1_IC_OCV_0C last pulse ends at 2.5770 V (total 1.8056 Ah); SP1_IC_OCV_45C at 3.0339 V (1.9996 Ah); SP3_IC_OCV_45C at 3.1985 V (2.0002 Ah) (CAP `incremental_ocv_total_discharge_Ah[*].last_discharge_end_V`, `.cutoff_2p5V_reached` = false; CAP `notes`). SP1_IC_OCV_25C, SP3_IC_OCV_0C and SP3_IC_OCV_25C reached 2.4999 / 2.4999 / 2.5000 V.
8. **0 C schedule capacity 1.8 Ah**: OCV pulses of 0.1806 Ah (SP1) / 0.1831 Ah (SP3) instead of 0.2 Ah; dynamic pre-profile discharges 0.3614-0.3615 / 0.9034-0.9035 Ah instead of 0.40 / 1.00 Ah (INV anomalies of the eight 0 C dynamic files: "the 50 % label is defined relative to a schedule capacity of 1.807 Ah"). The nominal start-SOC labels 50 / 80 % are therefore schedule labels; the reconstructed SOC at profile start is 0 C: 0.5019-0.5026 / 0.8007-0.8014 (Q_ref = 1.8138 Ah), 25 C: 0.5057-0.5063 / 0.8023-0.8029 (Q_ref = 2.0233 Ah), 45 C: 0.5196-0.5202 / 0.8078-0.8084 (Q_ref = 2.0812 Ah) for the 50 / 80 % files (INV `files[*].reference_soc.soc_at_profile_start`).
9. **Initial state of the OCV files**: the CC step has 1-4 samples because the cells were already at 4.052-4.179 V (charged in an unexported preceding step); its first sample overshoots to 4.2516-4.3758 V (SP1: 4.2621 / 4.3758 / 4.3286 V; SP3: -- / 4.2733 / 4.2516 V, row 6 of each file); the CV cutoff is 0.100 A rather than 0.02 A and adds 0.0140-0.1697 Ah (0.1697 Ah in SP3_IC_OCV_0C, which started at 4.052 V).
10. **Charge pulses above 4.2 V** (time-limited 1 A pulses at the top of the charge branch): SP1_IC_OCV_25C up to 4.2498 V in cycles 17-18; SP3_IC_OCV_25C up to 4.2208 V in cycle 18 (AUD section 8; also the cycle-1 overshoots above).
11. **Test_Time offsets**: SP2_25C_FUDS_50SOC starts at `Test_Time` 1005.9 s and SP2_25C_FUDS_80SOC at 7200.0 s (all other files at 1.0, 10.0 or 60.0 s; INV `files[*].test_time_first_s`); the capacity columns start at 0, so an initial period was not exported. The pre-profile charge differs in depth between files: SP2_45C_DST_80SOC begins its CC charge from 3.3457 V (1.9133 Ah CC + 0.1762 Ah CV, INV `files[SP2_45C_DST_80SOC].dynamic.pre_profile_charge`), SP2_25C_DST_80SOC from 4.0201 V (0.2827 + 0.1405 Ah), whereas SP2_0C_DST_80SOC has no CC step at all (cc Ah = 7e-10; the CV step alone adds 0.0487 Ah, `pre_profile_charge.Ah_cc_arbin`, `.Ah_cv_arbin`); the CV-end anchor is nevertheless present in every dynamic file (INV `files[*].reference_soc.anchor`).
12. **Profiles ending below 2.5 V** on their last transient sample: SP2_25C_DST_80SOC 2.4034 V; SP2_0C_US06_50SOC 2.4595 V; all other dynamic files end at 2.4955-2.5000 V (INV `files[*].dynamic.V_end`). One voltage sample above 4.25 V in SP2_45C_DST_50SOC (4.3459 V, row 1, step 2).
13. **Logging clock**: step-7 median 1.0155 s in 22 dynamic files, 1.0030 / 1.0029 s in SP2_25C_US06_50SOC / SP2_25C_BJDST_80SOC (section 4.1).
14. **Definitional differences only** between the canonical and independent audits: the cycle-1 CV-step trapezoid Ah differs by up to 2.7 mAh depending on whether the 10 s link from the last CC sample is included (VER section 4.4: 0.140495 vs 0.137752 Ah in SP2_25C_DST_80SOC; Arbin 0.140482 Ah); the canonical convention (include the link, DATA `segments`) matches the Arbin delta to 0.01 %.

Nothing in the list above alters a physical quantity used downstream: Q_ref(T) is now taken from the SP2 dynamic files themselves (section 6.2), so items 4, 7 and 8 no longer enter it.

## 6. Reference SOC construction and its uncertainty

All numbers in this section are regenerated by `scripts/01_audit.py` (function `update_report_A`) from CAP (generated 2026-09-27T07:39:12+00:00) and INV (generated 2026-09-27T07:39:20+00:00).

### 6.1 Formula (DATA `reference_soc`; INV `files[*].reference_soc` for dynamic files)

Anchor (INV `reference_soc.anchoring`): "SOC = 1 at the last sample of the CV step (Step_Index 3) at this chamber temperature; Coulomb counting from there through steps 4-7 (step-8 logger rows excluded)". Anchors of the identification files: SP2_0C_DST_80SOC row 202, t = 2066.8 s, V = 4.1997 V, I = 0.0199 A; SP2_25C_DST_80SOC row 331, t = 3363.4 s, V = 4.1997 V, I = 0.0198 A; SP2_45C_DST_80SOC row 1012, t = 10186.6 s, V = 4.2004 V, I = 0.0199 A (INV `files[*].reference_soc.anchor`).

With `eta` = CFG `dataset.coulombic_efficiency` = 1.0 and `I_eff = eta I` for `I > 0`, `I` otherwise:

    q(t)     = (1/3600) * trapz_{t_anchor}^{t} I_eff(tau) dtau        [Ah, charge > 0]
    SOC(t)   = 1 + q(t) / Q_ref(T)

evaluated on the irregular samples of steps 3-7 (duplicate timestamps and step-8 rows removed) and interpolated onto the uniform profile grid (section 4.2). Cross-check against the Arbin cumulative columns, `q_arbin = (Qc - Qc_anchor) - (Qd - Qd_anchor)`: max |q - q_arbin| on the profile = 1.0-10.2 mAh over the 24 files (max SOC difference 0.0049; INV `reference_soc.cross_check`).

### 6.2 Reference capacity Q_ref(T) (ground truth) and identification capacity Q_id(T) (CAP; CFG `dataset.reference_capacity`)

Method (CAP `method` = `sp2_dynamic_cv_end_to_cutoff_throughput_median`): Q_ref(T) for SP2 = median over the 8 SP2 dynamic files at T of the net charge throughput from the end of the CV step (step 3) to the end of the profile (step 7, 2.5 V cutoff), Arbin Charge_/Discharge_Capacity columns (trapezoidal integration of Current(A) as cross-check); u_Q(T) = half-range over the 8 files; Q_id(T) = throughput of SP2_<T>C_DST_80SOC (the only capacity an estimator may use). Also: 1 A CC discharge capacity to 2.5 V at 25 C of SP1/SP2/SP3 (initial-capacity tests) and total discharged Ah of the incremental-OCV files after the initial full charge.

    Q(file)   = -[(Qc(end of step 7) - Qc(end of step 3)) - (Qd(end of step 7) - Qd(end of step 3))]     [Arbin columns]
    Q_ref(T)  = median over the 8 SP2 dynamic files at T of Q(file)
    u_Q(T)    = (max - min) / 2 over the same 8 files
    Q_id(T)   = Q(SP2_<T>C_DST_80SOC)

**Leakage statement (CAP `leakage_statement`).** Q_ref(T) is the median over all 8 SP2 dynamic files at T (identification, validation and test) and is used ONLY to define the reference (ground-truth) SOC; it is never passed to any estimator. Estimators may use Q_id(T) (throughput of the identification file SP2_<T>C_DST_80SOC) and nothing derived from validation or test files.

Per-file throughput (CAP `dynamic_throughput_SP2`; the trapezoid of `Current(A)` over the same rows is the cross-check):

| file | T (C) | split | Q Arbin (Ah) | Q trapz (Ah) | Arbin - trapz (mAh) | V at end | ends at cutoff |
|---|---|---|---|---|---|---|---|
| SP2_0C_DST_50SOC | 0 | validation | 1.7893 | 1.7920 | -2.7 | 2.5000 | yes |
| SP2_0C_DST_80SOC | 0 | identification | 1.7830 | 1.7874 | -4.4 | 2.4990 | yes |
| SP2_0C_FUDS_50SOC | 0 | test | 1.8934 | 1.8931 | +0.3 | 2.5000 | yes |
| SP2_0C_FUDS_80SOC | 0 | test | 1.7529 | 1.7540 | -1.1 | 2.4995 | yes |
| SP2_0C_US06_50SOC | 0 | test | 1.8191 | 1.8197 | -0.5 | 2.4595 | yes |
| SP2_0C_US06_80SOC | 0 | test | 1.8278 | 1.8301 | -2.4 | 2.4995 | yes |
| SP2_0C_BJDST_50SOC | 0 | test | 1.8084 | 1.8076 | +0.8 | 2.5000 | yes |
| SP2_0C_BJDST_80SOC | 0 | test | 1.8708 | 1.8702 | +0.6 | 2.5000 | yes |
| SP2_25C_DST_50SOC | 25 | validation | 2.0027 | 2.0068 | -4.2 | 2.4997 | yes |
| SP2_25C_DST_80SOC | 25 | identification | 1.9964 | 1.9991 | -2.7 | 2.4034 | yes |
| SP2_25C_FUDS_50SOC | 25 | test | 2.0044 | 2.0054 | -1.0 | 2.4989 | yes |
| SP2_25C_FUDS_80SOC | 25 | test | 2.0002 | 1.9975 | +2.8 | 2.4968 | yes |
| SP2_25C_US06_50SOC | 25 | test | 2.0577 | 2.0546 | +3.1 | 2.4987 | yes |
| SP2_25C_US06_80SOC | 25 | test | 2.0487 | 2.0534 | -4.7 | 2.4982 | yes |
| SP2_25C_BJDST_50SOC | 25 | test | 2.0422 | 2.0437 | -1.5 | 2.4994 | yes |
| SP2_25C_BJDST_80SOC | 25 | test | 2.0538 | 2.0526 | +1.2 | 2.4999 | yes |
| SP2_45C_DST_50SOC | 45 | validation | 2.0611 | 2.0626 | -1.4 | 2.4999 | yes |
| SP2_45C_DST_80SOC | 45 | identification | 2.0790 | 2.0888 | -9.8 | 2.4955 | yes |
| SP2_45C_FUDS_50SOC | 45 | test | 2.0889 | 2.0871 | +1.8 | 2.4988 | yes |
| SP2_45C_FUDS_80SOC | 45 | test | 2.0813 | 2.0790 | +2.3 | 2.4984 | yes |
| SP2_45C_US06_50SOC | 45 | test | 2.0887 | 2.0907 | -2.0 | 2.4997 | yes |
| SP2_45C_US06_80SOC | 45 | test | 2.0807 | 2.0816 | -1.0 | 2.4993 | yes |
| SP2_45C_BJDST_50SOC | 45 | test | 2.0859 | 2.0865 | -0.6 | 2.4997 | yes |
| SP2_45C_BJDST_80SOC | 45 | test | 2.0811 | 2.0843 | -3.2 | 2.4988 | yes |

| T (C) | Q_ref (Ah), Arbin median | u_Q (Ah) = half-range | u_Q / Q_ref | range (Ah) | Q_ref trapz (Ah) | u_Q trapz (Ah) | Q_id (Ah) (file) | Q_id / Q_ref - 1 |
|---|---|---|---|---|---|---|---|---|
| 0 | **1.8138** | 0.0702 | 3.87 % | 1.7529-1.8934 | 1.8137 | 0.0696 | 1.7830 (SP2_0C_DST_80SOC) | -1.70 % |
| 25 | **2.0233** | 0.0307 | 1.51 % | 1.9964-2.0577 | 2.0253 | 0.0286 | 1.9964 (SP2_25C_DST_80SOC) | -1.33 % |
| 45 | **2.0812** | 0.0139 | 0.67 % | 2.0611-2.0889 | 2.0854 | 0.0141 | 2.0790 (SP2_45C_DST_80SOC) | -0.11 % |

Arithmetic (CAP `Q_ref_T_SP2[T].arithmetic`):

* Q_ref(0 C) = median of 8 Arbin throughputs = mean(1.8084, 1.8191) = 1.8138 Ah; u_Q = (1.8934 - 1.7529)/2 = 0.0702 Ah (3.87 %)
* Q_ref(25 C) = median of 8 Arbin throughputs = mean(2.0044, 2.0422) = 2.0233 Ah; u_Q = (2.0577 - 1.9964)/2 = 0.0307 Ah (1.51 %)
* Q_ref(45 C) = median of 8 Arbin throughputs = mean(2.0811, 2.0813) = 2.0812 Ah; u_Q = (2.0889 - 2.0611)/2 = 0.0139 Ah (0.67 %)

Arbin vs trapezoid: the largest per-file difference is 0.47 % of the throughput (CAP `Q_ref_T_SP2[T].max_rel_arbin_minus_trapz`); the medians differ by +0.1 mAh at 0 C, -2.0 mAh at 25 C, -4.2 mAh at 45 C. The Arbin columns are primary because the logger integrates at a higher internal rate than the ~1 s export.

All 24 of 24 dynamic files end at the 2.5 V cutoff (last-sample V <= 2.5 + 0.005 V), so every throughput is a full-to-cutoff capacity at the profile's own rate; u_Q therefore contains the rate/profile dependence of the charge extractable before the cutoff, not only noise.

Per-cell 1 A capacities at 25 C from the initial-capacity tests (CAP `cell_capacity_25C_initial_Ah`): SP1 2.0094 Ah, SP2 2.0283 Ah, SP3 1.9775 Ah; the SP2 value includes an unlogged 208 s pause near the cutoff (2.0048 Ah before the pause). These cross-cell numbers are reported only; they do not enter Q_ref or Q_id.

**Superseded method** (`sp2_25C_initial_capacity_scaled_by_sp1_sp3_temperature_ratio`; CAP `superseded_ocv_ratio_method`): Q_ref(T) = Q_SP2(25 C) x mean SP1/SP3 OCV-test ratio Q_ocv(T)/Q_ocv(25 C) gave 1.8183 Ah at 0 C, 2.0283 Ah at 25 C, 2.0368 Ah at 45 C. It is invalid at 0 C and 45 C because the OCV discharge branches did not reach the cutoff: SP1_IC_OCV_0C last pulse ends at 2.577 V; SP1_IC_OCV_45C last pulse ends at 3.034 V; SP3_IC_OCV_45C last pulse ends at 3.198 V (CAP `incremental_ocv_total_discharge_Ah[*].cutoff_2p5V_reached` = false), so the ratios were built from lower bounds.

### 6.3 Uncertainty band

Formula (DATA `reference_soc` docstring; INV `reference_soc.uncertainty.formula`):

    band(t) = (|q(t)| / Q_ref) * (u_Q / Q_ref)  +  I_off * (t - t_anchor) / (3600 * Q_ref)        [SOC units, summed linearly]

The first term is the relative capacity uncertainty u_Q/Q_ref applied to the removed charge (dSOC/dQ_ref = -q/Q_ref^2); the second is a constant current-sensor offset integrated from the anchor (it includes the two 2 h rests and the pre-profile discharge). I_off = CFG `dataset.reference_soc_band.current_offset_A` = 0.005 A. u_Q/Q_ref per temperature: 3.87 % at 0 C, 1.51 % at 25 C, 0.67 % at 45 C.

Band at the end of the profile (INV `files[*].reference_soc.uncertainty.at_profile_end`):

| file | T (C) | profile (s) | u_Q/Q_ref | Q_ref term | offset term | linear band (+/-) |
|---|---|---|---|---|---|---|
| SP2_45C_FUDS_80SOC (longest profile) | 45 | 11746.0 | 0.67 % | 0.0067 | 0.0136 | 0.0203 |
| SP2_0C_BJDST_80SOC (largest band) | 0 | 10279.5 | 3.87 % | 0.0399 | 0.0144 | 0.0544 |
| SP2_45C_US06_50SOC (smallest band) | 45 | 7064.8 | 0.67 % | 0.0067 | 0.0120 | 0.0187 |
| SP2_0C_DST_80SOC (identification) | 0 | 9608.0 | 3.87 % | 0.0382 | 0.0116 | 0.0498 |
| SP2_25C_DST_80SOC (identification) | 25 | 10710.2 | 1.51 % | 0.0150 | 0.0182 | 0.0332 |
| SP2_45C_DST_80SOC (identification) | 45 | 11400.5 | 0.67 % | 0.0067 | 0.0162 | 0.0229 |

Over the 24 dynamic files the linear band at profile end is 0.0187-0.0544 (1.9-5.4 % SOC); per temperature: 0.0498-0.0544 at 0 C, 0.0230-0.0335 at 25 C, 0.0187-0.0234 at 45 C. The RSS combination (DATA `reference_soc`, key `unc_total_rss`) is smaller.

Consistency evidence: the reconstructed SOC at the end of the profile (nominally 0 at the 2.5 V cutoff) is -0.0029 on average at 0 C (range -0.0435 to +0.0334; 8 of 8 files within their band); -0.0015 on average at 25 C (range -0.0154 to +0.0129; 8 of 8 files within their band); -0.0005 on average at 45 C (range -0.0045 to +0.0091; 8 of 8 files within their band) (INV `files[*].reference_soc.soc_at_profile_end`). By construction the end-of-profile SOC is 1 - Q(file)/Q_ref(T) up to the trapezoid-vs-Arbin difference, so its spread is the per-file throughput spread of section 6.2 and is bounded by u_Q/Q_ref; the systematic 45 C offset of the superseded OCV-ratio method has disappeared.

## 7. Train / validation / test assignment and the leakage argument

Assignment (CFG `splits`; INV `files[*].split`; 33 ids, no overlap enforced by DATA `_split_map`, which raises on a duplicate):

| split | role | files | ids |
|---|---|---|---|
| `ocv_and_relaxation` | OCV(z, T) curve, relaxation fits (CFG `relaxation`) | 6 | SP1_IC_OCV_0C, SP1_IC_OCV_25C, SP1_IC_OCV_45C, SP3_IC_OCV_0C, SP3_IC_OCV_25C, SP3_IC_OCV_45C |
| `capacity` | cross-cell 25 C capacity spread (reported only; not used by Q_ref or Q_id) | 3 | SP1_INITCAP, SP2_INITCAP, SP3_INITCAP |
| `identification_dynamic` | parameter identification (alpha, lambda, R0, Rp, Cp, Qn; CFG `bounds`) | 3 | SP2_0C_DST_80SOC, SP2_25C_DST_80SOC, SP2_45C_DST_80SOC |
| `validation_dynamic` | hyper-parameters (memory L, h, gain design) | 3 | SP2_0C_DST_50SOC, SP2_25C_DST_50SOC, SP2_45C_DST_50SOC |
| `test_dynamic` | held-out evaluation | 18 | the FUDS, US06 and BJDST files at 50 and 80 % start, 0 / 25 / 45 C |

Leakage argument:

1. **Profile-level separation.** Identification and validation use the DST profile only; the 18 test files are FUDS, US06 and BJDST, which are different current sequences (INV `files[*].dynamic.current_levels_step7`: DST is an 8-level staircase with peaks -4.00 / +2.00 A; BJDST a 19-level staircase between -1.67 and +0.44 A; FUDS and US06 continuous with peaks -4.00 / +2.14 A and -3.996 / +0.859 A). No test file shares its excitation with an identification file.
2. **Run-level separation within DST.** The 80 % start files (identification) and the 50 % start files (validation) are distinct physical runs on different dates or channels (INV `files[*].source.workbook`: 02_24_2016 both at 0 C, 11_05_2015 both at 25 C, 12_11_2015 both at 45 C, each in its own workbook with its own md5), with different pre-profile discharges (0.3615 vs 0.9034 Ah at 0 C, 0.4001 vs 1.0002 Ah at 25 C, 0.4000 vs 0.9999 Ah at 45 C) and therefore different SOC windows (0.80 -> 0 vs 0.50 -> 0). Validation covers only the lower half of the SOC range seen in identification, so validation performance cannot be inflated by memorised high-SOC segments.
3. **No sample is shared between splits.** Each logical id maps to exactly one workbook and one split (`_split_map`); there is no cross-file concatenation before splitting. Both start variants of the same profile at the same temperature are in the same split only inside the test set (e.g. SP2_25C_FUDS_50SOC and SP2_25C_FUDS_80SOC are both test), where no fitting happens.
4. **OCV information comes from other cells; the estimator capacity comes from the identification file only.** The OCV(z, T) curve and relaxation models are fitted on SP1 and SP3 (6 files, 125 relaxed OCV points and 114 relaxations in total: 21 + 19 + 21 + 21 + 22 + 21 points, 19 + 18 + 19 + 19 + 20 + 19 relaxations, INV `files[*].incremental_ocv`), never on SP2. The only capacity an estimator may use is Q_id(T) = 1.7830 Ah at 0 C (SP2_0C_DST_80SOC), 1.9964 Ah at 25 C (SP2_25C_DST_80SOC), 2.0790 Ah at 45 C (SP2_45C_DST_80SOC) (CAP `Q_id_T_SP2`), the CV-end-to-cutoff throughput of the identification file itself.
5. **Reference SOC is computed per file** from that file's own CV anchor (section 6.1); no label is derived from a test file and used in identification or vice versa.
6. **Residual, declared dependency.** All 24 dynamic files are the same cell (SP20-2), so identification, validation and test share the cell; generalisation claims are therefore across profiles, start SOC and temperature, not across cells (section 8). The ground-truth capacity Q_ref(T) (1.8138 / 2.0233 / 2.0812 Ah at 0 / 25 / 45 C) is the median over all 8 files at T, including validation and test files: it only DEFINES the reference SOC against which every estimator is scored and is never given to any estimator (CAP `leakage_statement`). Scoring against a label that uses the test files does not leak information into the estimator; the price is that the label of each file carries the +/- u_Q(T) band of section 6.3.

## 8. What cannot be done with these files, and the closest valid alternatives

| limitation | evidence | closest valid alternative |
|---|---|---|
| **No cell-temperature channel.** Temperature is the chamber set point (0 / 25 / 45 C); self-heating under the 4 A pulses is not observable. | INV `channels.temperature` = null; `temperature_note`; every file's anomaly list. | Treat T as a per-file constant equal to the set point (CFG `dataset.temperatures_C`); report results per chamber temperature; state that the isothermal assumption is untested. Any thermal-coupling claim must be phrased as "not testable here". The 1 A OCV pulses (0.2 Ah, ~720 s) minimise self-heating on the OCV/relaxation side. |
| **No EIS / impedance spectra.** `AC_Impedance(Ohm)` and `ACI_Phase_Angle(Deg)` are identically zero; `Internal_Resistance(Ohm)` is non-zero only in the 3 capacity files (4 unique values). | INV `files[*].channels.constant_zero_columns`; VER section 4.7. | The fractional order alpha and the tempering rate lambda must be identified in the time domain: (a) from the 2 h voltage relaxations after 1 A interruption (114 relaxations, 7199 s each, at ~1 s; CFG `relaxation.fit_window_s` = [60, 7150], 6 candidate models incl. tempered power law and tempered Mittag-Leffler), and (b) from the DST identification files. A frequency-domain CPE fit is not possible; the constant-phase interpretation of Cp (CFG comment "Cp is a CPE coefficient with units F s^(alpha-1)") is a modelling choice, not a measured spectrum. |
| **No repeated runs** of the same profile on the same cell at the same temperature, except the 50 % / 80 % start variants. | Inventory (section 1): exactly one workbook per (T, profile, start-SOC). | Use the two start variants as the only repeatability check (same profile, same day at 0 C DST/FUDS/US06 and 25 C DST/US06, different SOC window); quantify run-to-run scatter through the CFG `validation` perturbation study (initial SOC errors [0, +0.20, -0.20], current bias [0, 0.02, 0.05] A, voltage noise [0, 5, 10] mV, current noise [0, 10, 50] mA, 20 Monte-Carlo runs with the 20 listed seeds) rather than through experimental replicates. Confidence intervals on identified parameters come from multistart (CFG `identification.multistart` = 10) and bootstrap of the relaxation fits (CFG `relaxation.bootstrap`: 200 resamples, 120 s blocks), not from replicate tests. |
| **Only one cell (SP2) carries dynamic profiles**, and SP2 has no incremental-OCV test; the OCV(z, T) curve must be transferred from SP1 / SP3. | Inventory: 24 dynamic files all `cell` = SP20-2; 6 OCV files all SP20-1 / SP20-3. | (a) Transfer OCV(z) from SP1/SP3 with z defined on each file's own capacity (INV OCV `reference_soc.anchoring`), which removes the capacity offset between cells; (b) take SP2's capacity from SP2's own dynamic files: Q_ref(T) for the ground truth and Q_id(T) for the estimator (section 6.2); (c) carry the cross-cell spread explicitly: at 25 C the three 1 A capacities are 2.0094 / 2.0283 / 1.9775 Ah (CAP `cell_capacity_25C_initial_Ah`); (d) the observer's capacity-mismatch study (CFG `validation.capacity_mismatch_frac`) covers the Q_id-vs-Q_ref difference (-1.70 % at 0 C, -1.33 % at 25 C, -0.11 % at 45 C). Cross-cell generalisation of the observer itself cannot be claimed. |
| **No aged cells.** All tests are on fresh cells within a 5-month window (2015-10-16 to 2016-03-09). | Workbook dates (section 1); capacities 1.9775-2.0283 Ah, close to the 2.0 Ah nominal. | Ageing robustness can only be emulated: the CFG `validation.capacity_mismatch_frac` = [0.95, 1.05] and `param_perturbation_frac` = 0.20 studies stand in for capacity fade and resistance growth. Claims must be limited to beginning-of-life behaviour. |
| **OCV-test capacities are lower bounds where the discharge branch stopped before 2.5 V** (SP1_IC_OCV_0C, SP1_IC_OCV_45C, SP3_IC_OCV_45C). | CAP `incremental_ocv_total_discharge_Ah[*].cutoff_2p5V_reached` = false. | Use those totals only as the files' own SOC axis for OCV/relaxation labels, never as a capacity; SP2's capacity comes from its dynamic files, all of which end at the cutoff (section 6.2: Q_ref = 1.8138 / 2.0233 / 2.0812 Ah, u_Q = 0.0702 / 0.0307 / 0.0139 Ah at 0 / 25 / 45 C). |
| **Low-SOC OCV branch at 45 C is incomplete** (last discharge pulse ends at 3.03 / 3.20 V, so the relaxed OCV at "0 %" is 3.2771 / 3.3392 V, not a 2.5 V-terminated point). | AUD section 6 tables (SP1_IC_OCV_45C cycle 10, SP3_IC_OCV_45C cycle 10). | Restrict the OCV-slope polytope for the LMI gain design to the empirically valid interval CFG `model.soc_interval` = [0.10, 1.00] and state that below 10 % SOC the 45 C OCV is extrapolated. |
| **SP1_IC_OCV_25C is truncated** (no final CC/CV/rest). | Finding 6. | The discharge and charge branches (10 + 8 pulses) are complete; only the end-of-test full-SOC point is missing, and SP3_IC_OCV_25C supplies it (22 points). |

---

### Summary of numbers most likely to be quoted in the manuscript

* 21 archives, 33 workbooks, 33 logical ids, 1 304 483 samples; 24 dynamic profiles on SP20-2 (208 888 step-7 samples, 58.5 h of profile), 6 incremental-OCV tests on SP20-1/SP20-3 (125 relaxed OCV points, 114 two-hour relaxations), 3 capacity tests.
* Channels: I [A], V [V], Test_Time [s]; I > 0 = charge (verified, fractions >= 0.9985); no temperature, no EIS.
* Sampling: nominal 1 s, observed median 1.0155 s in most files (section 4.1); resampled to a uniform 1 s grid, V linear, I charge-conserving interval mean (net Ah preserved; gross per-direction Ah not, section 4.2).
* Q_ref(T) for SP2 (ground truth only): 1.8138 / 2.0233 / 2.0812 Ah at 0 / 25 / 45 C, u_Q = 0.0702 / 0.0307 / 0.0139 Ah (half-range of 8 files); estimator capacity Q_id(T) = 1.7830 / 1.9964 / 2.0790 Ah (DST 80 % files); reference SOC by trapezoidal Coulomb counting from the CV-end anchor; band at profile end +/-1.9-5.4 % SOC over all 24 files.
* Splits: 3 DST-80 % identification, 3 DST-50 % validation, 18 FUDS/US06/BJDST test, disjoint by file and by profile.
