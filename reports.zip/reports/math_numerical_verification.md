# Numerical verification of the tempered fractional calculus core (Blocks M1-M4b)

Date: 2026-09-27. Code: `src/tfso/tempered.py`. Tests: `tests/test_tempered.py`. LaTeX block: `manuscript_parts/math/numerics.tex` (parts `numerics_p01.tex` ... `numerics_p05.tex`, labels prefixed `num`). Number collection script: `scratch/numerics_report_numbers.py` (log `scratch/numerics_report_numbers.log`). Compile check: `scratch/numerics_build.py` (M1..M4b + numerics, 0 errors, 0 overfull boxes from numerics.tex).

**Result:** `python -m pytest tests/test_tempered.py -q` gives `52 passed in 70.23s`. No test is marked xfail. No numerical result contradicts a theorem.

## Machine and software

| Item | Value |
|---|---|
| CPU | Intel Core Ultra 9 288V, 8 logical cores |
| RAM | 31.5 GB |
| OS | Windows 11 (10.0.26200) |
| Python | 3.12.10 |
| Libraries | NumPy 2.4.6, SciPy 1.17.1, mpmath 1.3.0, CVXPY 1.9.1, Clarabel 0.11.1 |
| Arithmetic | IEEE binary64. mpmath is used at 30 digits, or with precision adapted to the series cancellation. |

## 1. Discrepancies and corrections

1. **The M2 summary quotes a wrong untempered remainder.** This affects `M2_summary.md` only, not `M2.tex`.
   - The summary gives the untempered worst-case remainder with the same 508-sample window as `2.086e-3`, ratio 79.
   - The exact value is `B W_508 = 0.2 W_508 = 2.14495e-3` (mpmath, 30 digits). The ratio to the tempered remainder is 81.43. This agrees with `1/rho_0.6(2.5395) = 81.15`.
   - The value 2.0855e-3 is what you get when the tail is cut off at j = 2e5.
   - `M2.tex` (rem:m2:example) states "2.1e-3, eighty times larger", which is correct. The test asserts the exact value.
2. **The M2 summary wording "equality only at j = 1" for the weight bound is misleading.** The bound `|omega_j| <= C_alpha j^{-1-alpha}` is strict for every j >= 1, including j = 1, where `|omega_1| = alpha < alpha/Gamma(2-alpha)`. The equality at j = 1 in `M2.tex` concerns only the intermediate step `j/(j-alpha) <= 1/(1-alpha)`. M1 states strictness correctly. Verified for j <= 1e5.
3. **Two labels assumed in M3c do not exist.** `thm:m3a:comparison` and `thm:m3b:discrete` are undefined in the full compile. They correspond to `thm:m3a:convergence` and `thm:m4b:certificate`. `numerics.tex` (rem:num:certificates) states this mapping. M3c.tex still needs to be edited by the integrator.
4. **Two citation keys used in numerics.tex are not in References.bib:**
   - `trefethen2014exponentially`: L. N. Trefethen, J. A. C. Weideman, "The exponentially convergent trapezoidal rule", SIAM Review 56(3), 385-458, 2014.
   - `olver2010nist`: F. W. J. Olver et al., NIST Handbook of Mathematical Functions, Cambridge UP, 2010 (DLMF Section 8.9).

   Please verify these references and add them. The other keys (`gorenflo2020mittag`, `diamond2016cvxpy`, `goulart2026clarabel`) are present.
5. **The discrete comparison theorem was not re-derived.** The task asked to "derive and prove" it, but it is already proved in M4b (def:m4b:damping, lem:m4b:damping, lem:m4b:comparison, thm:m4b:certificate). The algebra of the error recursion was re-derived independently in `scratch/numerics_notes.md` and agrees with eq:m4b:ez-rec / eq:m4b:ep-rec. It was also confirmed numerically to 1e-12 (Section 7). The code implements exactly the M4b quantities.

## 2. New formal results in numerics.tex (all proved)

- **`prop:num:ring` (with `alg:num:ring`).** The doubled ring buffer computes eq:m2:implicit-scheme exactly. Cost is N_L multiply-adds per sample. Storage is 3 N_L + O(1) numbers, or N_L + O(1) at minimum.
- **`lem:num:worst`.** The exact supremum of `|R_L|` over `|f| <= B` is attained by the constant sequence. For lambda = 0 it equals `B h^-alpha W_{N_L}`.
- **`prop:num:hlimit`.** Two-sided bound: `(alpha/Gamma(1-alpha)) B I(L+2h) <= R*_h(L) <= C_sharp(N_L) B I(L)`.
  - Its limit as h -> 0 is `(alpha/Gamma(1-alpha)) B I(L)`, which is `(1-alpha)` times the Gamma bound.
  - This makes the "asymptotically exact" claim for C_sharp quantitative. It addresses M2 caveat 5.
- **`prop:num:mlspectral`.** Spectral representation of `E_{alpha,beta}(-x)` for `0 < beta < 1+alpha`, obtained by collapsing the Bromwich contour onto the cut. It also gives the tempered step integral `S_lambda(t)` and the beta-reduction recurrence.
- **`lem:num:incgamma`.** Computation of Gamma(-alpha, x) by the recurrence (x <= 2) or the Legendre continued fraction (x > 2). It also shows that the bisection for L*_Gamma is well-posed.

## 3. Weights and partial sums (lem:m1:glweights, lem:m2:weights)

| Claim | Test | Result |
|---|---|---|
| Recursion = `(-1)^j binom(alpha,j)` = Gamma form, N = 2000 | alpha in {0.3,0.5,0.6,0.7,0.9} | max relative deviation 6.7e-12 |
| Tempered weights = untempered times `e^{-lambda j h}`; `omega_j < 0` | same | rel 1e-12, all negative |
| `sum_{j>=1} abs(omega_j^{(alpha,lambda)}) = 1 - (1-e^{-lambda h})^alpha` | (lambda,h) in {(0.005,1),(0.02,2),(0.1,0.5)} | abs error < 1e-12 |
| `W_n` recursion = cumulative sum = Gamma form | N = 2000 | rel 1e-11 |
| Gautschi bounds, j <= 1e5 | alpha in {0.3,0.5,0.7,0.9} | min abs(omega)/lower = 1.0000150 / 1.0000188 / 1.0000230 / 1.0000276; max abs(omega)/upper = 0.909 / 0.886 / 0.897 / 0.951. Strict everywhere, and abs(omega_j) is strictly decreasing |
| `sum_{j<=N} abs(omega_j) = 1 - W_N` | N = 1e5 | < 1e-12 |

## 4. Truncation bounds (thm:m2:truncation, cor:m2:memory-rule)

**Gamma(-alpha, x) against mpmath.** alpha in {0.3,0.5,0.6,0.7,0.9} and x in {1e-6, 1e-3, 0.05, 0.5, 1, 1.999, 2, 2.001, 5, 20, 64, 300}. The max relative error is 8.1e-14. The recurrence/continued-fraction switch at x = 2 is seamless.

**Domination.** Grid: alpha in {0.3,0.5,0.7,0.9}, lambda in {1e-4,1e-3,5e-3,2e-2}, L in {50,200,800,3200}, h in {0.5,1,2}, giving 192 cases. The exact worst case is `h^-alpha sum_{j>N_L} abs(omega_j^{(alpha,lambda)})`. It is summed directly, not as total minus partial sum, because that subtraction cancels catastrophically for lambda L = 64.

| Bound | Max of exact / bound | Attained at (alpha, lambda, L, h) |
|---|---|---|
| Gamma `C_a lambda^a Gamma(-a, lambda L)` | 0.69995 | (0.3, 1e-4, 3200, 0.5) |
| (a) `C_a e^{-lambda L}/(lambda L^{1+a})` | 0.6828 | (0.3, 2e-2, 3200, 0.5) |
| (b) `e^{-lambda L} L^-a/Gamma(2-a)` | 0.5180 | (0.3, 1e-4, 50, 0.5) |
| sharp `C_sharp(N_L) I(L)` | 0.99989 | (0.3, 1e-4, 3200, 0.5) |

In every case the Gamma bound is at most min(a, b). The ratio Gamma/untempered equals `rho_alpha(lambda L)` to 1e-12.

**Untempered.** For lambda = 0, the exact worst case `B h^-alpha W_{N_L}` is at most `L^-alpha/Gamma(2-alpha)` in all 48 cases.

**h-independence.** The bound values are identical for all h.
- The exact worst case varies by at most 2.44 % over h in {0.5, 1, 2}.
- At h = 0.25 it lies within 0.41 % of the h -> 0 limit `(alpha/Gamma(1-alpha)) I(L)` (prop:num:hlimit).
- The two-sided bound (eq:num:twosided) holds in all 320 cases, which add lambda = 0 and h = 0.25. The observed ratios to the two sides are 1.0000387 (lower) and 0.9999684 (upper).

**M2 worked example** (alpha 0.6, lambda 0.005, B 0.2, eps 1e-4, h 1):
- Horizons: `L* = 507.906` s, `L*_b = 749.736` s, `L*_Gamma = 454.082` s, sharp root `342.387` s, `L*_0 = 3.87521e5` s, `N_L = 508`.
- Lambert and bisection agree to 3e-14 relative.
- Remainders at N_L = 508: exact `2.63414e-5`, sharp bound `2.64521e-5`, Gamma bound `6.60523e-5`, bound (a) `9.99237e-5`, untempered `2.14495e-3`; see Section 1, item 1.
- `rho_0.6` at x = 0.01, 0.1, 1, 2.54, 5 and the lambda -> 0 values at L = 100 are reproduced to 2e-3 and 2e-4 respectively.

## 5. Mittag-Leffler functions and kernels (lem:m1:solution, rem:m1:spectral, prop:num:mlspectral)

- **Automatic method against the mpmath series.** The mpmath series uses exact binary alpha and working precision adapted to the cancellation. Tested on alpha in {0.3,0.6,0.9,0.999}, beta in {1, alpha, alpha+0.5, 2}, and x in {1e-3, 0.5, 2, 5, 20, 100} with `x^{1/alpha} <= 1000`. The max relative error is below 1.2e-13 for alpha <= 0.9 and 2.9e-12 for alpha = 0.999. The spectral method alone meets the same tolerances.
- **Pitfall found and fixed.** Forming the gamma argument `alpha k + beta` in double precision inside a high-precision series gives errors of order `eps E_alpha(x)` (1e48 at x = 20, alpha = 0.6). The argument must be formed in mpmath.
- **Asymptotics (eq:m1:mlasym, two terms).** Relative error at x = 1e3 is 1.4e-7 (alpha 0.3), 3.9e-7 (0.6), 3.8e-6 (0.9). This is below 5/x^2 at x in {1e2, 1e3, 1e4}.
- **`norm(g_lambda)_1 = 1/(a + lambda^alpha)`.** Checked by time-domain quadrature after the substitution u = t^alpha, and by the spectral integral:

| (alpha, lambda, a) | closed form | time-domain | spectral |
|---|---|---|---|
| (0.6, 0.05, 0.5) | 1.502126934679645 | 1.502126934679659 | 1.502126934679645 |
| (0.3, 0, 0.2) | 5 | 5.00000000000005 | 4.9999999999999964 |
| (0.9, 0.01, 2) | 0.496068918738499 | 0.4960689187384996 | 0.4960689187384992 |
| (0.6, 0.005, 0.05) | 10.913734956899432 | 10.913734956899463 | 10.91373495689943 |
| (0.5, 0.02, 1) | 0.8761006569007046 | 0.8761006569007047 | 0.8761006569007045 |

The task tolerance was 1e-4 relative; the agreement is about 1e-14.
- **Kernel ranges.** `0 < e_lambda <= e^{-lambda t}` and `g_lambda > 0` hold on t in [0.01, 1000].
- **Step integral.** At lambda = 0, `S_0 = (1 - E_alpha(-a t^alpha))/a` to 1e-12. Also `S_lambda(inf)(a + lambda^alpha) = 1` to 1e-12.

## 6. GL scheme (prop:m1:consistency, lem:m1:schemeidentity, lem:m2:apriori, limits)

- **First-order convergence to the exact step response.** Parameters: alpha 0.6, lambda 0.05, a 0.5, b 0.15, x0 = 0.02 (the Caputo correction is active), T = 20 s. The max error on [1, 20] s for h = 0.4, 0.2, 0.1, 0.05, 0.025 is 5.48e-3, 3.14e-3, 1.59e-3, 7.96e-4, 3.99e-4. The log-log slope is **0.954**.
- **Ring buffer against direct summation.** N_L = 50, N = 400, sinusoidal input: difference 5.6e-17.
- **Scheme identity.** `D_{h,L} x + a x - b I = 0` to 8e-17. The a priori bound `max(abs(x0), b norm(I)/a)` holds.
- **Constants.** `D_h 1 -> h^-a (1-e^{-lambda h})^a` holds at n = 6000 to 1e-12. Also `mu_h(0) -> lambda^alpha`.
- **lambda = 0 (Cole-Cole) against `(1 - E_alpha(-a t^alpha))/a`.** Errors 2.53e-2, 1.28e-2, 6.42e-3 at h = 0.2, 0.1, 0.05; slope **0.989**.
- **alpha -> 1 against the RC-with-leakage ODE `V' = -(a+lambda)V + bI`.** The ODE is solved by scipy `solve_ivp` (rtol 1e-11) with a square-wave current, lambda 0.02, a 0.1, b 0.05. Relative max deviation:

| h \ alpha | 0.99 | 0.999 | 0.9999 |
|---|---|---|---|
| 0.1 | 1.46e-2 | 2.75e-3 | 2.07e-3 |
| 0.05 | 1.42e-2 | 1.96e-3 | 1.07e-3 |
| 0.025 | 1.41e-2 | 1.61e-3 | 5.63e-4 |

The deviation behaves as O(1-alpha) + O(h). This confirms the M1 erratum: the limit is `f' + lambda f` with no extra term.
- **Timing.** 1e5 samples with N_L = 508 take 0.23 s (ring-buffer dot product).

## 7. Certificates, design and error system (M3a, M3c, M4a, M4b)

- **Certificate equivalence (prop:m3c:equivalence).** 600 random continuous parameter sets gave 100+ certified cases. The explicit inequalities, the HiGHS LP `M^T d < 0`, the Hurwitz test and the closed-form P, d and xi agree in every non-degenerate case. The same holds for 600 discrete sets with mu_{h,L}, sigma above lambda allowed, and positivity.
- **sigma_bar_L (prop:m3c:rates-discrete).** 9.657253e-3 (lambda 0.005) and 4.657253e-3 (lambda 0), with alpha 0.6, a_p 0.05, h 1, N_L 508. These match M3c.
- **LMI design (CVXPY + Clarabel, bisection).** Case alpha 0.6, lambda 0.005, a_p 0.05, kappa in [0.1, 1.5]:
  - continuous: sigma_cert = lambda;
  - discrete, full memory: sigma_cert = lambda, with l1 at the positivity bound 1/(h k2) = 0.667;
  - N_L = 508: sigma_cert = 9.6572e-3.

  The recovered gains pass the explicit test at sigma_d = 0.9 sigma_cert. All three designs take 2.5 s in total.
- **Theorem m4b:certificate (i), disturbance-free.** Setup: alpha 0.6, lambda 0.005, a_p 0.1, kappa_n switching between 0.3 and 1.2 every 20 s, h 1, 5000 s, l1 0.05, l2 0.02. The certified sigma* is 0.005 (full memory) and 5.52e-3 (N_L 500); sigma = 0.9 min(sigma*, lambda) is used.
  - Four initial errors, (e_z0, e_p0) in {(0.3,0), (0.3,0.02), (-0.2,0.05), (0,0.02)}.
  - `max abs(e_z)/bound = 1.000`, attained at n = 0.
  - `max abs(e_p)/bound <= 0.0763`.
  - `max e^{sigma t}(abs(e_z) + abs(e_p)) = abs(e_z0) + abs(e_p0)`, and it decays to 1e-4 or less at 5000 s.
  - With the violating gain l1 = 0.003 (l1 k2 < sigma) the certificate fails and `e^{sigma t} abs(e)` grows from 0.32 to 6.4e4.
- **Theorem m3a:convergence (i), continuous limit.** Setup: alpha 0.6, lambda 0.05, a_p 0.5, kappa switching between 0.3 and 1.2 every 0.5 s, l = (1, 0.08), h = 0.05 (refine 20), T = 300 s.
  - C = 2.959 and theta = 0.662, as in M3a.
  - `sup e^{lambda t} abs(e)_v/abs(e(0))_v = 1.000` for three initial errors, with final values 0.031, 5e-5, 0.031, consistent with part (ii).
- **Error recursion (prop:m4b:errorrec).** Setup: plant with affine OCV (kappa 0.5), V_p(0) = 0.01 V, piecewise-constant current in [-3, 3] A, bias 0.05 A, uniform noise of 1 mV, implemented observer with N_L = 300.
  - The error recursion driven by w_z and w_p - R_L reproduces `z - zhat` and `V_p - Vhat_p` to 1e-12.
  - `max abs(V_p) <= B_p`.
  - `max abs(R_L)` is below the Gamma bound with B_p.
- **Constant bias (rem:m3c:bias, cor:m4a:bias).** Setup: implemented full-memory recursion, l = (0.2, 0.004), kappa 0.5, dI 0.05 A.
  - `e_z(12000 s) = 6.580193e-3`, equal to the mu_h(0) formula to 1e-15.
  - The continuous formula gives 6.579079e-3, an O(h) difference.
  - The Coulomb drift of 6.7e-2 is 10 times larger.
- **Cost (rem:m4b:cost).** N_L = 508 needs 520 multiply-adds and one OCV evaluation per sample. Memory is 12.3 kB (doubled ring buffer plus weights), or 4.1 kB at minimum.

## 8. Items not verified or only partially verified

- **Consistency (prop:m1:consistency) is checked only on examples** (step responses, alpha 0.6, lambda in {0, 0.05}). It is not a proof. The order observed at current jumps (plant residual r_n, rem:m4b:residual) was not re-tested here, since M4b documents it.
- **The mpmath Mittag-Leffler fallback refuses `x^{1/alpha} > 3000`** because it is too expensive. The spectral method covers that range for 0 < beta < 1 + alpha, and the beta-reduction recurrence covers beta >= 1 + alpha. beta <= 0 is supported only through mpmath.
- **alpha -> 1: the spectral quadrature step shrinks like (1-alpha).** It uses about 1e5 nodes at alpha = 0.999; it is accurate (3e-12) but slower.
- **The test for "a violating l1 fails" is one-sided evidence.** It shows growth of the weighted error when `l1 kappa_2 < sigma`. Since the certificate is only sufficient, failure of the certificate alone does not imply instability, and the test does not claim that.
- **Process note.** During development a hung verification command was stopped with `taskkill /IM python.exe`. That command ended every python.exe process on the machine at that moment (two PIDs). If another job was running Python during this session, it may have been interrupted and should be checked.
