# Literature search report

**Manuscript topic:** tempered-fractional equivalent-circuit model with a finite-memory Grünwald-Letnikov (GL) implementation and an LMI-based observer for lithium-ion SOC estimation, validated on the CALCE INR 18650-20R dataset.

**Search window closed:** 2026-09-27 (all Crossref checks and the CALCE page check were made on this date).
**Companion files:** `References.bib` (verified bibliography), `reports/bib_verification.json` (per-record verification), `reports/literature_comparison.json` (structured comparison of 2023-2026 estimators).

---

## 1. Databases, APIs and access conditions

| Source | Use | Availability during the search |
|---|---|---|
| Crossref REST API (`query.bibliographic`, `query.title`/`query.author`, `/works/<DOI>`) | Discovery of candidates and authoritative bibliographic verification (title, authors, venue, year, volume, issue, pages, DOI, ISBN) | Available, but repeatedly returned HTTP 429 on parallel bursts; every failing request was retried sequentially (polite-pool `mailto` parameter). All verifications below come from successful Crossref responses unless stated otherwise. |
| Semantic Scholar Graph API (`/paper/search`, `/paper/DOI:`) | Cross-check, abstracts, discovery | Search endpoint returned HTTP 429 on essentially every attempt in every topic (one success in `fo-stability-observers`, one in `ecm-ocv-foundations`, one in `mixed-order-tempered-stability`, one in `tempered-foundations`). The per-DOI endpoint worked for IEEE/Wiley/MDPI items; Elsevier abstracts were null. **Semantic Scholar-based discovery is therefore incomplete.** |
| OpenAlex API (`/works/doi:`) | Fallback for abstracts | Available; abstracts present only for a minority of Elsevier items. |
| Web search (general engine) | Discovery of 2023-2026 items, confirmation of volume/issue/ISBN for items with incomplete Crossref records | Available. |
| Publisher pages (ScienceDirect, MDPI, Wiley, Springer Link, IEEE Xplore, Artech House, AGU, ESAIM, nature.com) | Abstract reading and metadata confirmation | ScienceDirect, MDPI, Wiley, Artech House, AGU and ESAIM returned HTTP 403 to automated fetches; Springer Link redirected to an identity-provider login; IEEE Xplore returned empty content; nature.com redirected to a login gateway. IOP (JES/ECS), Project Euclid, JMLR, arXiv, PMC, IDEAS/RePEc and the CALCE data page were readable. |
| CALCE battery data page (`https://calce.umd.edu/battery-data`) | Mandatory dataset citations and test descriptions | Readable (three fetches). |

## 2. Inclusion criteria

A candidate was kept as a record only if **all** of the following held:

1. It is a peer-reviewed journal article, peer-reviewed conference paper, or a book/monograph (arXiv preprints were kept only as explicitly flagged companions of a published item, e.g. `naifar2025theoretical`).
2. Its bibliographic metadata was verified on Crossref (`/works/<DOI>` or an unambiguous `query.bibliographic` hit), or, for items without a Crossref record (books, one 1996 conference paper, one JMLR paper), on the publisher page plus at least one independent listing (ISBN/edition confirmed). Items that could not be verified this way were **not** included (Section 7).
3. It supports a specific statement in the manuscript (the `supports` field of each record), in one of twelve topics (Section 3).
4. For the 2023-2026 comparison set, it concerns lithium-ion SOC (or closely related state) estimation, fractional-order battery modelling/identification, or tempered/finite-memory fractional theory.

Records whose `verification.match` was `exact`, `minor_fix` or `no_doi_book_verified` were written to `References.bib`. No record had status `mismatch` or `unresolved`; items that failed verification were dropped **before** the record stage and are listed in Section 7.

## 3. Per-topic counts

| Topic | Records kept | exact | minor_fix | no_doi_book_verified | Queries logged |
|---|---|---|---|---|---|
| tempered-foundations | 16 | 14 | 2 | 0 | 32 |
| tempered-battery | 13 | 7 | 6 | 0 | 31 |
| fo-battery-models | 19 | 18 | 1 | 0 | 30 |
| finite-memory | 13 | 12 | 0 | 1 | 30 |
| fo-stability-observers | 22 | 18 | 2 | 2 | 35 |
| calce-required | 4 | 4 | 0 | 0 | 29 |
| diffusion-physics | 16 | 16 | 0 | 0 | 29 |
| recent-soc-estimators | 13 | 13 | 0 | 0 | 20 |
| ecm-ocv-foundations | 21 | 16 | 4 | 1 | 44 |
| identification-methods | 19 | 13 | 4 | 2 | 28 |
| mixed-order-tempered-stability | 15 | 12 | 3 | 0 | 21 |
| battery-fractional-recent | 11 | 9 | 2 | 0 | 33 |
| **Total** | **182** | **152** | **24** | **6** | **362** |

`References.bib` contains these 182 entries plus one `@misc` entry for the CALCE data page (183 entries in total). All keys are unique; no key had to be renamed.

## 4. Query log

Columns: query (as issued), engine, number of hits returned (`n`), number judged relevant (`rel`), outcome. "429" means the request was refused by rate limiting and returned no data.

### 4.1 tempered-foundations (32 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| Tempered fractional calculus Sabzikar Meerschaert Chen | Crossref query.bibliographic | 10 | 7 | Sabzikar 2015 JCP, Meerschaert & Sabzikar 2013/2014/2016, Lischke 2019, Meerschaert & Sikorskii book |
| Tempered stable Levy motion and transient super-diffusion Baeumer Meerschaert | Crossref | 10 | 3 | Baeumer & Meerschaert 2010; Meerschaert-Zhang-Baeumer 2008 GRL |
| Fluid limit of the CTRW with general Levy jump distribution functions Cartea | Crossref | 8 | 1 | Cartea & del-Castillo-Negrete 2007 verified by DOI |
| Well-posedness and numerical algorithm for the tempered FDEs Li Deng Zhao | Crossref | 5 | 2 | 429 then success; Li-Deng-Zhao 2019 |
| On some analytic properties of tempered fractional calculus Fernandez Ustaoglu | Crossref | 5 | 1 | 429 then success; vol 366, 112400 |
| Tempered anomalous diffusion in heterogeneous systems (DOI endpoint) | Crossref /works/DOI | 1 | 1 | L17403 confirmed by web search (Wiley 403) |
| Boundary problems for the fractional and tempered fractional operators Deng Li Tian Zhang | Crossref | 5 | 2 | MMS 16(1) 2018; Deng 2020 MPE surfaced |
| Tempered fractional Brownian motion Meerschaert Sabzikar | Crossref | 10 | 1 | First call 429; verified via earlier listing |
| tempered Grünwald-Letnikov approximation convergence order weights recursion | WebSearch | 10 | 4 | Li & Deng 2016, quasi-compact tempered schemes (arXiv), Gao 2025 |
| tempered Mittag-Leffler function Laplace transform tempered Caputo derivative | WebSearch | 9 | 3 | Deng 2020 MPE, arXiv 1501.00376, Prabhakar-kernel papers |
| well-posedness numerical algorithm tempered fractional ODEs | Semantic Scholar | 0 | 0 | 429 |
| analytic properties of tempered fractional calculus Fernandez Ustaoglu | Semantic Scholar | 0 | 0 | 429 |
| boundary problems fractional and tempered fractional operators | Semantic Scholar | 0 | 0 | 429 |
| tempered Mittag-Leffler stability tempered fractional dynamical systems | Semantic Scholar | 0 | 0 | 429 |
| "tempered fractional" derivative definition RL Caputo review 2023-2025 | WebSearch | 9 | 3 | Gao 2025; adaptive tempered Caputo (unverified); **no dedicated review found** |
| Li Deng "High order schemes for the tempered fractional diffusion equations" | WebSearch | 9 | 4 | vol 42(3) 543-572 (2016) confirmed |
| 10.1007/s10444-015-9434-z | Crossref /works/DOI | 1 | 1 | issued 2015 online, print 2016 |
| Tempering stable processes Rosinski | Crossref | 5 | 1 | SPA 117(6) 2007 |
| Discretized fractional substantial calculus Chen Deng | Crossref + DOI | 5 | 2 | Crossref lacks vol/pages; ESAIM 49(2) 373-394 from web listing |
| Second-order numerical methods for the tempered fractional diffusion equations | Crossref | 5 | 2 | Qiu & Cao 2019, Lei 2018 (verified, not included) |
| 10.1155/admp/5518224 | Crossref /works/DOI | 1 | 1 | 429 then success; Gao 2025 |
| tempered fractional-order system GL discretization short memory observer estimation 2024-2026 | WebSearch | 9 | 0 | **NEGATIVE**: only non-tempered GL papers |
| New theories and applications of tempered FDEs Obeidat Bentil | Crossref | 5 | 2 | ND 105(2) + Correction |
| AGU page 10.1029/2008GL034899 | WebFetch publisher | 0 | 0 | 403 |
| tempered Grunwald Letnikov shifted difference tempered fractional derivative | Semantic Scholar | 15 | 5 | Succeeded once; Gao 2025, Qiu 2024, Guan & Cao 2020, Feng 2021 |
| "tempered fractional" Laplace transform "(s+λ)^α" tempered Mittag-Leffler | WebSearch | 10 | 2 | Deng 2020; Lamrani-Zitane-Torres CNSNS 2025 |
| Controllability and observability of tempered fractional differential systems | Crossref | 5 | 1 | CNSNS 142, 108501 |
| ESAIM M2AN page m2an140037 | WebFetch publisher | 0 | 0 | 403 |
| Meerschaert Zhang Baeumer 2008 GRL 35 L17403 | WebSearch | 10 | 1 | Article number confirmed |
| 10.1016/j.cam.2019.112400 | Crossref /works/DOI | 1 | 1 | Fernandez & Ustaoğlu verified |
| tempered fractional calculus review survey 2024 2025 journal | WebSearch | 9 | 1 | **NEGATIVE** for a dedicated 2023-2026 review |
| Chen Deng "Discretized fractional substantial calculus" ESAIM 49 373-394 | WebSearch | 9 | 2 | Confirmed from ESAIM listing and arXiv 1310.3086 |
| 10.1109/mesa.2014.6935561 | Crossref /works/DOI | 1 | 1 | Cao-Li-Chen 2014 verified |

### 4.2 tempered-battery (31 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| "tempered fractional" battery lithium-ion state of charge | WebSearch | 9 | 1 | Only Kahouli et al. 2026 (SOH); rest are non-tempered FO SOC papers |
| "tempered fractional" "equivalent circuit" OR "constant phase element" OR impedance electrochemistry | WebSearch | 9 | 0 | **NEGATIVE** |
| "tempered fractional" observer OR estimator OR "state estimation" | WebSearch | 9 | 5 | Alzahrani & Boulaaras, Alkhrijah & Louhichi, Alanzi et al., Ben Makhlouf et al., Kahouli et al.; all observer papers simulation-only |
| "tempered fractional gradient descent" OR "tempered fractional gradient" | WebSearch | 9 | 3 | Naifar 2026, arXiv 2504.18849, Alaerjan 2026 |
| tempered fractional battery lithium-ion | Crossref | 7 | 0 | **NEGATIVE**: no title containing "tempered" |
| tempered fractional battery lithium-ion state of charge (+4 variants) | Semantic Scholar | 0 | 0 | 429 on all five attempts |
| tempered fractional gradient descent | Crossref | 20 | 2 | Naifar 2026, Alaerjan 2026 |
| tempered fractional observer Mittag-Leffler stability | Crossref | 12 | 4 | Alanzi 2026, Deng 2020, Gu 2021, Almeida 2022/2023 (not relevant) |
| tempered fractional supercapacitor electrochemical impedance | Crossref | 0 | 0 | 429 twice |
| "tempered" fractional supercapacitor OR electrochemistry OR electrode diffusion "exponentially tempered" | WebSearch | 9 | 0 | **NEGATIVE** (one false positive: temperature-dependent pseudo-capacitor) |
| "tempered Mittag-Leffler" battery OR electrochemical OR impedance | WebSearch | 10 | 0 | **NEGATIVE** |
| "tempered fractional" "parameter identification" OR "system identification" OR "equivalent circuit model" | WebSearch | 9 | 0 | **NEGATIVE** |
| "tempered fractional" lithium OR battery OR "state-of-charge" 2024 2025 2026 | WebSearch | 9 | 0 | **NEGATIVE** |
| tempered fractional state of charge estimation battery (from 2020) | Crossref | 0 | 0 | 429 |
| tempered fractional diffusion electrode electrochemical | Crossref | 0 | 0 | 429 |
| tempered fractional Grunwald-Letnikov short memory numerical | Crossref | 9 | 0 | Pure-mathematics tempered FDE papers only |
| "tempered fractional" Kalman filter OR "neural network" battery SOH OR SOC | WebSearch | 9 | 0 | **NEGATIVE** |
| "tempered fractional-order" "linear matrix inequality" OR LMI observer Lipschitz | WebSearch | 9 | 4 | Alzahrani, Alkhrijah, Ben Makhlouf, Tuan 2026; numerical examples only |
| "tempered fractional" "Grünwald-Letnikov" discretization implementation | WebSearch | 9 | 0 | PDE numerics only; no battery/observer implementation |
| Naifar "tempered fractional" 2025 OR 2026 | WebSearch | 9 | 4 | Rguigui & Elghribi, Alzahrani, Bouteraa et al., Naifar TFGD |
| "tempered fractional" supercapacitor OR "fractional capacitor" OR "RC circuit" model | WebSearch | 9 | 0 | **NEGATIVE** |
| Bouteraa Benjeddou Naifar tempered fractional Takagi-Sugeno fault unknown input 2026 | WebSearch | 10 | 1 | Existence confirmed; DOI found on Crossref |
| tempered fractional-order Takagi-Sugeno fuzzy simultaneous state fault unknown input (from 2025) | Crossref | 10 | 1 | Bouteraa et al. 2026 |
| "tempered" anomalous diffusion "porous electrode" OR "lithium intercalation" OR "solid-phase diffusion" fractional | WebSearch | 9 | 0 | **NEGATIVE** |
| "tempered fractional" "electrochemical" OR "electrochemistry" OR "impedance spectroscopy" | WebSearch | 9 | 0 | **NEGATIVE** |
| "tempered fractional" arxiv battery OR "lithium-ion" OR "energy storage" model | WebSearch | 9 | 1 | Only Kahouli 2026 again |
| fast algorithm tempered Caputo derivative sum-of-exponentials finite memory | WebSearch | 10 | 1 | Feng et al. 2022 ND |
| "tempered" "fractional" "lithium-ion" OR "Li-ion" observer OR "state of charge" -"temperature" | WebSearch | 9 | 0 | **NEGATIVE** |
| "tempered fractional" neural network stability short memory Gu 2021 Fractals | WebSearch | 9 | 3 | Gu 2021, Zhang 2024 FCAA, Lamrani 2025 |
| "tempered fractional" "Kalman" OR "extended Kalman" OR "unscented Kalman" | WebSearch | 9 | 0 | **NEGATIVE**: no tempered fractional Kalman filter of any kind |
| "tempered fractional" "supercapacitor" OR "ultracapacitor" OR "fuel cell" | WebSearch | 9 | 0 | **NEGATIVE** |
| controllability observability tempered fractional differential systems | Crossref | 10 | 1 | Lamrani et al. 2025 metadata from listing |

### 4.3 fo-battery-models (30 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| Sabatier fractional system identification lead acid battery SOC | Crossref | 5 | 1 | 429 then success; Signal Processing 2006 |
| Fractional-order modeling and parameter identification for lithium-ion batteries Wang Li Ni | Crossref | 5 | 1 | Authors are Wang, Li, Peng, Liu (no "Ni") |
| Zou Zhang Hu Manzie review of fractional-order techniques ... supercapacitors | Crossref | 5 | 2 | Review found (no Manzie); Zou TIE estimator surfaced |
| Alavi Birkl Howey Time-domain fitting of battery electrochemical impedance models | Crossref | 5 | 1 | Hit; Ospina Agudelo 2021 Energies also surfaced |
| Hu Yuan Zou co-estimation SOC SOH fractional-order calculus IEEE TVT | Crossref | 4 | 3 | Hu 2018 TVT; Xiong 2019 TVT; Guo 2023 TITS (not included) |
| Xiong novel fractional order model based SOC estimation Applied Energy | Crossref | 4 | 3 | Two 429s; first author is Mu; Zhang 2021 Energies and Liu 2019 surfaced |
| Freeborn Maundy Elwakil fractional-order models supercapacitors batteries fuel cells survey | Crossref + WebSearch | 8 | 1 | 2015 survey verified; 2013 items are ISCAS papers |
| SOC estimation of lithium-ion batteries using fractional order sliding mode observer ISA Transactions | Crossref | 4 | 1 | Zhong 2017 |
| fractional-order SOC estimation lithium-ion battery observer (from 2023) | Crossref | 0 | 0 | 429 |
| fractional-order sliding mode observer SOC lithium-ion battery (from 2023) | Crossref | 0 | 0 | 429; narrower query later found Zhou 2023 Batteries, Gaufan 2025, Ma 2023 (not included here) |
| Fractional variable-order observer-based method for SOC estimation Applied Energy (from 2024) | Crossref | 4 | 2 | Wu 2025; Murakami & Ohmori 2024 |
| adaptive fractional-order EKF approach SOC Journal of Energy Storage (from 2024) | Crossref | 5 | 2 | 429 then success; Song 2024; Guha 2024 (not included) |
| SOC estimation ... fractional-order modeling and adaptive square-root CKF Energy (from 2022) | Crossref | 4 | 1 | Chen 2023 Energy |
| comprehensive review fractional-order mathematical models lithium-ion batteries (from 2025) | Crossref | 4 | 1 | Manivannan & Vigneswar 2025 |
| dual fractional-order EKF accurate SOC estimation JES 2026 | Crossref | 4 | 1 | Cheng 2026 verified (validation type unconfirmed at that stage) |
| incommensurate fractional-order observer SOC lithium-ion CNSNS (from 2022) | Crossref | 4 | 3 | Chen 2023 CNSNS; complex-order model 2023 (not included); Guo 2024 TMECH |
| Six DOI lookups (TIE 2017, TMECH 2023, Ionics 2025, JES 2024, CNSNS 2022, JES 2025) | Crossref /works/DOI | 6 | 6 | All resolved; TIE record early-access only |
| fractional-order SOC estimation lithium-ion observer (six variants) | Semantic Scholar search | 0 | 0 | 429 on all attempts; only /paper/DOI endpoint worked |
| fractional-order SOC estimation lithium-ion battery observer 2024 2025 JES | WebSearch | 9 | 5 | Machines 2024, Applied Energy 2025, CNSNS 2023, Mu 2017, Xiong 2019 |
| fractional-order H-infinity observer OR sliding mode observer lithium-ion SOC 2023-2025 | WebSearch | 9 | 3 | Ionics 2025, Batteries 2023, Energies 2024 review; no 2023-2026 FO H-infinity SOC observer |
| "fractional-order" EKF SOC estimation 2024 2025 IEEE Transactions | WebSearch | 10 | 4 | JES 2024, JES 2026, Ionics 2025; no IEEE TIE/TPEL/TTE FO-EKF 2024-2026 |
| fractional-order battery SOC GL short memory truncation error bound 2023-2025 | WebSearch | 10 | 0 | **NEGATIVE**: no FO SOC estimator with a certified truncation bound |
| fractional-order UKF lithium-ion SOC 2024 2025 Energy OR eTransportation OR Applied Energy | WebSearch | 10 | 2 | Ionics 2025; JES 2025 AFOUPF; no eTransportation item |
| fractional-order H-infinity observer lithium-ion SOC LMI 2023-2025 | WebSearch | 9 | 2 | Only pre-2023 (Energies 2021) and JES 2025 review; **NEGATIVE** for 2023-2026 |
| fractional-order SOC observer IEEE TTE OR TPEL OR TIE 2024 2025 | WebSearch | 9 | 0 | **NEGATIVE** |
| fractional-order lithium-ion SOC observer Nonlinear Dynamics OR ISA Transactions 2023-2025 Lyapunov | WebSearch | 9 | 2 | No Nonlinear Dynamics item; JES 2020 IIR approximation (pre-2023, not verified) |
| Zhang Xu fractional-order ECM lithium-ion SOC JPS / Applied Energy 2016-2018 | WebSearch | 9 | 0 | **NEGATIVE**: incomplete brief item could not be identified |
| Nonlinear Fractional-Order Estimator ... TIE volume issue pages | WebSearch | 9 | 1 | IEEE Xplore 8187681: 65(7) 5951-5961 |
| Abstract retrieval for five Elsevier items | WebFetch publisher | 0 | 0 | All 403; IDEAS/RePEc mirrors and snippets used instead |

### 4.4 finite-memory (30 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| Short memory principle and a predictor-corrector approach for FDEs Deng | Crossref | 5 | 1 | Deng 2007 JCAM 206(1) (not JCP) |
| A note on short memory principle of fractional calculus | Crossref | 5 | 3 | 429 then success; Wei 2017, Gong 2017, Stark 2021 |
| Discretized fractional calculus Lubich | Crossref | 5 | 1 | 429 then success; SIAM JMA 17(3) |
| Finite difference approximations for fractional advection-dispersion flow equations | Crossref | 5 | 1 | JCAM 172(1) 2004 |
| Frequency-band complex noninteger differentiator characterization and synthesis | Crossref | 5 | 1 | 429 then success; TCAS-I 47(1) 2000 |
| A predictor-corrector approach for the numerical solution of FDEs | Crossref | 5 | 1 | Diethelm-Ford-Freed 2002 |
| Numerical solution of FDEs a survey and a software tutorial | Crossref | 5 | 1 | Garrappa 2018; Podlubny chapter DOI surfaced |
| Some approximations of fractional order operators used in control theory (Vinagre et al.) | Crossref | 5 | 0 | **NEGATIVE**: FCAA 2000 not indexed on Crossref |
| Podlubny Fractional Differential Equations Academic Press 1999 (type:book) | Crossref | 5 | 0 | No whole-book DOI; verified via chapter record |
| 10.1016/s0076-5392(99)80027-7 | Crossref /works/DOI | 1 | 1 | Chapter record confirms ISBN 9780125588409, 1999 (two 429s first) |
| fractional-order Kalman filter short memory principle lithium-ion SOC 2023-2025 | WebSearch | 9 | 3 | Solomon 2022 JES; dual FO-EKF 2025; Fractal Fract 2026 |
| "fixed memory" OR "finite memory" fractional-order observer battery SOC GL truncation error | WebSearch | 9 | 4 | Rauh & Lahme 2025; Tian 2020 CJME; arXiv 1304.0616; arXiv 2603.16851 |
| "short memory" fractional order model lithium-ion SOC memory length truncation error 2024-2026 | WebSearch | 9 | 1 | Only Tian 2020 evaluates memory length; no 2024-2026 battery finite-memory error-bound paper |
| Stark Hohmann "short-memory principle" fractional models convergence analysis | WebSearch | 9 | 3 | Stark 2021 ECC; Hai 2022 FCAA |
| fractional-order battery model "memory length" truncated GL error analysis 2023-2025 | WebSearch | 9 | 1 | Only preprints and Tian 2020 |
| SOC estimation ... improved fractional-order EKF | Crossref | 3 | 1 | Solomon 2022 JES 49 |
| Observer-based error correction in finite memory approaches ... | Crossref | 3 | 2 | Rauh & Lahme 2025 ARC and 2024 IFAC-PapersOnLine |
| 10.23919/ecc54610.2021.9654853 | Crossref /works/DOI | 1 | 1 | Stark 2021 |
| 10.1007/s13540-022-00049-9 | Crossref /works/DOI | 1 | 1 | Hai 2022 |
| 10.1186/s10033-020-00467-x | Crossref /works/DOI | 1 | 1 | Tian 2020 CJME verified, not included |
| fixed memory FO Kalman filter lithium-ion SOC (from 2023) | Crossref | 0 | 0 | 429 twice |
| short memory principle fractional GL truncation error bound (from 2023) | Crossref | 10 | 2 | Coccolo 2026 CSF, Dong 2026 Mathematics (non-battery, not included) |
| short memory principle fractional order battery SOC estimation (from 2019) | Crossref | 0 | 0 | 429 |
| short memory principle fractional order battery SOC estimation | Semantic Scholar | 0 | 0 | 429 |
| finite memory fractional order observer battery SOC | Semantic Scholar | 0 | 0 | 429 (two attempts) |
| Some approximations of fractional order operators (Vinagre Podlubny) | Semantic Scholar | 0 | 0 | 429 (four attempts) |
| Vinagre Podlubny Hernández Feliu 2000 ... FCAA 3(3) 231-248 | WebSearch | 10 | 1 | Citation confirmed only via secondary sources; no DOI |
| Solomon Zheng Chen Qiao 2022 improved FO-EKF short memory principle abstract | WebSearch | 9 | 1 | Confirms JES 2022; validation type unconfirmed |
| Rauh Lahme 2025 Observer-based error correction abstract | WebSearch | 10 | 1 | Open-access ARC paper confirmed |
| arXiv 1304.0616 | WebFetch arXiv | 1 | 1 | Preprint only; excluded |

### 4.5 fo-stability-observers (35 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| 18 parallel Crossref queries (all foundational titles) | Crossref via WebFetch | 0 | 0 | All 429; re-issued sequentially |
| Mittag-Leffler stability of fractional order nonlinear dynamic systems Li Chen Podlubny | Crossref | 4 | 2 | Automatica 2009; CAMWA 2010; 2017 Reply to Comments seen |
| Stability of fractional-order nonlinear dynamic systems Lyapunov direct method ... | Crossref | 4 | 1 | CAMWA 2010 confirmed |
| Lyapunov functions for fractional order systems Aguila-Camacho ... | Crossref | 4 | 2 | CNSNS 2014 and CNSNS 2015 |
| Using general quadratic Lyapunov functions ... fractional order systems | Crossref | 4 | 1 | DOI confirmed |
| A Lyapunov approach to the stability of FDEs Trigeassou ... | Crossref | 4 | 1 | Signal Processing 91(3) 2011 |
| LMI stability conditions for fractional order systems Sabatier Moze Farges | Crossref | 4 | 1 | CAMWA 59(5) |
| How to impose physically coherent initial conditions to a fractional system | Crossref | 4 | 1 | CNSNS 15(5) 2010 |
| LMI-based robust control of fractional-order uncertain linear systems Lan Zhou | Crossref | 4 | 1 | CAMWA 62(3) 2011 |
| Observer-based robust control of a (1<=a<2) fractional-order uncertain systems | Crossref | 4 | 1 | IET CTA 6(2) 2012 |
| Robust stabilization of uncertain descriptor fractional-order systems N'Doye ... | Crossref | 4 | 1 | Automatica 49(6) 2013 |
| Non-fractional and fractional-order observers for fractional systems Boroujeni Momeni | Crossref | 4 | 0 | **NEGATIVE** for the requested title; only the non-fragile observer paper exists |
| query.author=Boroujeni Momeni + fractional order observer | Crossref (author filter) | 10 | 3 | Exhaustive listing; no such title; ND 2015 paper seen |
| Observers for Lipschitz nonlinear systems Rajamani | Crossref | 4 | 1 | TAC 43(3) 1998 |
| On LMI conditions to design observers for Lipschitz nonlinear systems Zemouche Boutayeb | Crossref | 4 | 1 | Automatica 49(2) 2013 |
| Nonlinear observers: a circle criterion design and robustness analysis Arcak Kokotovic | Crossref | 4 | 2 | Automatica 37(12); 1999 CDC precursor |
| Linear Matrix Inequalities in System and Control Theory Boyd ... | Crossref | 4 | 1 | SIAM monograph DOI/ISBN |
| The Analysis of Fractional Differential Equations Diethelm (type:book) | Crossref | 4 | 1 | Springer LNM 2010 |
| Theory and Applications of FDEs North-Holland 204 (type:book) | Crossref | 4 | 1 | Edited-book DOI, no author field |
| Kilbas Srivastava Trujillo book authors | Elsevier shop page | 1 | 1 | Authors, vol 204, 2006 confirmed (ScienceDirect 403) |
| Matignon Stability results for FDEs with applications to control processing (two phrasings) | Crossref | 8 | 0 | **NEGATIVE**: 1996 CESA paper not indexed; 1998 ESAIM Proc found |
| Matignon 1996 ... CESA IMACS Lille volume 2 pages 963-968 | WebSearch | 10 | 1 | Consistent citation snippets |
| "Matignon" "Stability results ..." "Computational Engineering in Systems Applications" 1996 | WebSearch | 10 | 1 | Semantic Scholar page located |
| Semantic Scholar paper/1e28a14195ff... (Matignon), 3 attempts | Semantic Scholar | 0 | 0 | 429 |
| Khalil Nonlinear Systems (type:book) | Crossref | 4 | 0 | **NEGATIVE**: no Crossref record |
| Khalil "Nonlinear Systems" third edition Prentice Hall 2002 ISBN | WebSearch + SCIRP page | 9 | 3 | 3rd ed., 2002, ISBN 9780130673893 |
| Non-fractional and fractional-order observers Boroujeni Momeni | WebSearch | 10 | 0 | **NEGATIVE** for exact title |
| Observer-based robust control fractional-order uncertain systems LMI Lan Huang Zhou | Semantic Scholar | 23 | 2 | Only successful SS query; Lan 2012, Lan & Zhou 2011/2013 |
| Matignon; Boroujeni; Lyapunov FO observer LMI 2024; tempered stability observer | Semantic Scholar | 0 | 0 | 429 after 4 retries each |
| Lyapunov stability fractional order systems observer LMI (from 2023) | Crossref | 8 | 2 | Marir & Chadli 2025 chapters; Alanzi 2026 |
| fractional-order observer design Lipschitz nonlinear LMI Mittag-Leffler (from 2023) | Crossref | 8 | 4 | Basdouri 2023, Jmal 2024, Jmal & Ahmed AJC, Mohite/Zemouche 2023 |
| tempered fractional derivative stability Lyapunov (from 2022) | Crossref | 8 | 4 | Wei 2023 AJC nabla tempered; Alanzi 2026 x2; Alawad 2025 |
| finite memory GL short memory principle fractional observer stability (from 2022) | Crossref | 8 | 2 | Mu 2025 AJC; Agarwal 2025; **no finite-memory GL + observer proof paper** |
| fractional-order observer LMI Lipschitz Mittag-Leffler stability 2024 2025 journal | WebSearch | 9 | 4 | Jmal & Ahmed; Alanzi 2026; IJSS 2026 fuzzy observer (unverified) |
| Nine direct DOI verifications | Crossref /works/DOI | 9 | 9 | All resolved |

### 4.6 calce-required (29 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| calce.umd.edu/battery-data (fetch 1) | WebFetch | 1 | 1 | INR 18650-20R section; three requested citations; citation policy |
| calce.umd.edu/battery-data (fetch 2) | WebFetch | 1 | 1 | Verbatim citation strings and cell spec table; no Samsung mention |
| calce.umd.edu/battery-data (fetch 3) | WebFetch | 1 | 1 | Verbatim OCV test procedures; dynamic tests listed |
| web.calce.umd.edu/batteries/data/ (legacy) | WebFetch | 1 | 0 | Does not list INR 18650-20R |
| Influence of different open circuit voltage tests ... | Crossref | 5 | 1 | Zheng 2016 |
| SOC estimation ... open-circuit voltage at various ambient temperatures | Crossref | 5 | 1 | Xing 2014 |
| SOC estimation for Li-ion batteries using neural network modeling and UKF-based error cancellation | Crossref | 5 | 1 | He 2014 |
| Lithium-ion battery data and where to find it | Crossref | 5 | 1 | dos Reis 2021 |
| CALCE INR 18650-20R battery dataset SOC estimation (from 2023) | Crossref | 20 | 0 | **NEGATIVE**: no title names CALCE/INR 18650-20R |
| works/10.1016/j.apenergy.2016.09.010 | Crossref /works/DOI | 1 | 1 | Verified |
| works/10.1016/j.apenergy.2013.07.008 | Crossref /works/DOI | 1 | 1 | 429 then success |
| works/10.1016/j.ijepes.2014.04.059 | Crossref /works/DOI | 1 | 1 | 429 then success |
| works/10.1016/j.egyai.2021.100081 | Crossref /works/DOI | 1 | 1 | Verified |
| Semantic Scholar search (seven query variants) | Semantic Scholar | 0 | 0 | 429 on all |
| paper/DOI lookups for the four DOIs | Semantic Scholar /paper/DOI | 4 | 4 | Metadata confirmed; abstracts elided |
| CALCE battery data INR 18650-20R Samsung dataset citation Zheng Xing | WebSearch | 9 | 3 | Batemo/aboutenergy datasheets confirm Samsung cell |
| calce.umd.edu "INR 18650-20R" incremental OCV DST FUDS US06 BJDST 0 25 45 C | WebSearch | 9 | 4 | Frontiers 2022 (Arbin BT2000), Batteries 2024 |
| fractional-order SOC observer CALCE INR18650-20R FUDS US06 2023-2025 | WebSearch | 9 | 5 | Context only; several FO SOC papers use CALCE data |
| "Lithium-ion battery data and where to find it" dos Reis CALCE INR 18650-20R | WebSearch | 9 | 2 | Confirms review and CALCE pages |
| doi.org/10.1016/j.apenergy.2016.09.010 -> ScienceDirect | WebFetch publisher | 0 | 0 | 403 |
| ScienceDirect S2666546821000355 (dos Reis) | WebFetch publisher | 0 | 0 | 403 |
| Frontiers 10.3389/fenrg.2022.938467 | WebFetch | 1 | 1 | Third-party description: Arbin BT2000, 1 s sampling |
| mdpi.com/2313-0105/10/6/208 | WebFetch publisher | 0 | 0 | 403 |

### 4.7 diffusion-physics (29 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| voltage relaxation power law lithium-ion battery after current interruption | WebSearch | 9 | 5 | Bharathraj 2025, Fernando 2024, Ko & Chen 2024, Kirk 2021, Theuerkauf & Swan 2022 |
| constant phase element physical origin lithium-ion electrode FO impedance 2023-2025 | WebSearch | 10 | 4 | Lasia 2022 JPCL; Wu 2025 JES |
| relaxation behavior lithium-ion battery rest OCV stretched exponential | WebSearch | 9 | 3 | Shkrob 2019; Bharathraj 2023 |
| Warburg diffusion impedance lithium-ion electrode physical origin FO model review 2024 2025 | WebSearch | 9 | 4 | Gabano 2017; Wu 2025 |
| Cole-Cole Havriliak-Negami fractional relaxation Mittag-Leffler physical interpretation | WebSearch | 9 | 3 | Mostly preprints; Hilfer 2002 / Metzler 2000 verified directly |
| Lasia "Electrochemical Impedance Spectroscopy and its Applications" Springer 2014 ISBN | WebSearch | 9 | 3 | ISBN confirmed |
| CPE analysis by local EIS Jorcin Orazem | Crossref | 5 | 1 | Verified |
| Theory of the electrochemical impedance of anomalous diffusion Bisquert Compte | Crossref | 5 | 2 | 429 then success |
| Tempered anomalous diffusion in heterogeneous systems | Crossref | 0 | 0 | 429; verified via DOI endpoint |
| Diffusion and relaxation controlled by tempered alpha-stable processes | Crossref | 5 | 2 | Stanislavsky 2008; 2015 CNSNS seen |
| The random walk's guide to anomalous diffusion Metzler Klafter | Crossref | 0 | 0 | 429; verified via DOI endpoint |
| Hilfer Experimental evidence for fractional time evolution ... | Crossref | 5 | 1 | DOI (02)00670-5 |
| Relaxation model of the open circuit voltage for SOC estimation | Crossref | 5 | 2 | 429 then success; Pei 2013; Theuerkauf & Swan 2022 |
| Lasia EIS book (book filter) | Crossref | 0 | 0 | 429 twice; verified via DOI endpoint |
| Impedance Spectroscopy Theory Experiment and Applications Barsoukov Macdonald | Crossref | 5 | 2 | 2005 and 2018 editions |
| exact solution for rest-period voltage relaxation in Li-ion batteries iScience | Crossref | 3 | 2 | Bharathraj 2025; 2023 iScience |
| Diffusion impedance in planar cylindrical and spherical symmetry Jacobsen West | Crossref | 5 | 1 | 429 then success |
| /works/10.1021/acs.jpclett.1c03782 | Crossref /works/DOI | 1 | 1 | Lasia 2022 |
| /works/10.1149/2.0511916jes | Crossref /works/DOI | 1 | 1 | Shkrob 2019 (also IOP page) |
| Low-frequency characteristics and fractional-order impedance model ... | Crossref | 5 | 1 | Wu 2025 JES 134 |
| Bounded diffusion impedance characterization of battery electrodes using fractional modeling | Crossref | 5 | 1 | Gabano 2017 |
| Physical modelling of the slow voltage relaxation phenomenon | Crossref | 4 | 1 | Kirk 2021 |
| Benchmark dataset for the study of the relaxation of commercial NMC-811 and LFP cells | Crossref | 5 | 1 | Fernando 2024 |
| Using tens of seconds of relaxation voltage to estimate OCV and SOH | Crossref | 3 | 1 | Ko & Chen 2024 verified, not included |
| voltage relaxation lithium-ion battery power law rest fractional | Semantic Scholar | 0 | 0 | 429 (two attempts) |
| constant phase element origin electrode heterogeneity impedance | Semantic Scholar | 0 | 0 | 429 |
| anomalous diffusion impedance lithium-ion electrode CPE origin | Semantic Scholar | 0 | 0 | 429 |
| stretched exponential voltage relaxation lithium-ion cell | Semantic Scholar | 0 | 0 | 429 |
| tempered fractional relaxation lithium-ion battery | Semantic Scholar | 0 | 0 | 429 |

### 4.8 recent-soc-estimators (20 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| lithium-ion SOC estimation observer 2024 2025 JES CALCE INR18650-20R DST FUDS US06 | WebSearch | 9 | 4 | Majeed 2026, Lin 2026, Murakami 2024, Xing 2024 |
| fractional-order SOC estimation lithium-ion observer (from 2023) | Crossref | 9 | 6 | Wu 2025, Chen 2023, Guo 2024, Murakami 2024 |
| lithium-ion SOC estimation CALCE INR18650-20R DST FUDS US06 | Semantic Scholar | 0 | 0 | 429 |
| sliding mode observer SOC lithium-ion battery (from 2023) | Crossref | 10 | 5 | He 2024, Qian 2024, Asadi 2026, Nohra 2026 |
| adaptive EKF SOC lithium-ion noise covariance (from 2023) | Crossref | 10 | 4 | Rout & Das 2024; Zhang 2024 JPS; Wang 2023 JES |
| H-infinity observer SOC lithium-ion LMI (from 2023) | Crossref | 15 | 4 | Hu & Hao 2025; Koopman LMI 2026 (no abstract); Nohra 2026; Asadi 2026 |
| transformer LSTM SOC estimation deep learning (from 2023) | Crossref | 10 | 2 | Mostly preprints; Menon 2026 excluded |
| nonlinear observer Lipschitz SOC LMI (from 2023) | Crossref | 0 | 0 | 429; re-issued -> 14 hits, 3 relevant; no 2023-2026 Lipschitz-LMI SOC observer |
| "state of charge" 2025 UKF/EKF JES INR18650-20R FUDS US06 BJDST RMSE | WebSearch | 9 | 3 | Majeed 2026; JES 2025 PINN+AKF (DOI unresolved) |
| fractional-order lithium-ion SOC 2024 2025 short memory GL observer JES OR Applied Energy | WebSearch | 9 | 2 | No short-memory certification found |
| transformer SOC estimation 2024 2025 JES/eTransportation/Applied Energy | WebSearch | 9 | 2 | Yi 2024; no eTransportation item |
| transformer SOC estimation (container eTransportation, from 2023) | Crossref | 5 | 0 | **NEGATIVE** |
| LMI-based nonlinear observer SOC Lipschitz 2023-2025 ISA Trans OR CEP OR IEEE Trans | WebSearch | 9 | 1 | Only pre-2023 items and Saeed 2025 |
| fractional-order Kalman filter short memory SOC (from 2023) | Crossref | 8 | 3 | Chai 2024, Jiao 2025, Yu 2025; none certifies finite memory |
| H-infinity filter SOC robust (from 2023) | Crossref | 0 | 0 | 429 twice |
| H-infinity filter SOC 2024 2025 JES OR IEEE Trans OR Energy | WebSearch | 9 | 2 | Milde & Kerle 2025; Batteries 2024 |
| tempered fractional SOC lithium-ion battery observer (from 2023) | Crossref | 10 | 0 | **NEGATIVE** |
| Exact-title lookups for 14 candidates | WebSearch | 9 | 1 | Used to read abstract snippets; Menon 2026 no match -> excluded |
| Crossref works/DOI verification for 20 candidate DOIs | Crossref | 17 | 17 | All included DOIs resolved |
| Semantic Scholar DOI lookups (13 DOIs) | Semantic Scholar /paper/DOI | 13 | 6 | Abstracts for 6 IEEE/Wiley items |
| OpenAlex DOI lookups (6 DOIs) | OpenAlex | 6 | 1 | Only CNSNS 2023 had an abstract |

### 4.9 ecm-ocv-foundations (44 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| Plett Extended Kalman filtering for BMS of LiPB-based HEV battery packs | Crossref | 8 | 3 | Three 2004 parts; Crossref titles lack Part subtitles |
| Hu Li Peng comparative study of ECMs for Li-ion batteries | Crossref | 5 | 1 | 429 then success |
| Weng Sun Peng unified OCV model ... | Crossref via WebFetch | 0 | 0 | 429; DOI via WebSearch then curl |
| "A unified open-circuit-voltage model ..." Weng Sun Peng JPS 2014 doi | WebSearch | 10 | 2 | DOI, vol 258 |
| Pattipati Balasingam Avvari Bar-Shalom OCV characterization | Crossref | 5 | 1 | vol 269 |
| Barai comparison of methodologies for non-invasive characterisation | Crossref via WebFetch | 0 | 0 | 429 |
| "A comparison of methodologies ..." Barai PECS 2019 | WebSearch | 9 | 4 | DOI confirmed; verified by curl |
| Ng Moo Chen Hsieh Enhanced coulomb counting method | Crossref | 5 | 1 | Applied Energy 86(9) |
| Waag Fleischer Sauer Critical review ... | Crossref (curl) | 6 | 1 | JPS 258 |
| Dey Ayalew Pisu Nonlinear robust observers ... | Crossref (curl) | 6 | 1 | TCST 23(5) |
| Kim nonlinear SOC estimator HEV battery sliding mode observer | Crossref (curl) | 6 | 1 | TPEL 23(4) 2008 (corrects "2006") |
| Kim technique for estimating SOH through a dual-sliding-mode observer | Crossref (curl) | 6 | 1 | TPEL 25(4) 2010 (SOH item) |
| Plett Battery Management Systems Volume II Artech House | Crossref (curl) | 6 | 0 | **NEGATIVE**: not indexed, no DOI |
| Plett "Battery Management Systems, Volume II" ISBN | WebSearch | 10 | 6 | ISBN 9781630810276 |
| polytopic observer SOC LPV | Crossref (curl) | 6 | 1 | Hu & Hao 2025 |
| linear parameter varying observer SOC | Crossref (curl) | 6 | 2 | Badie 2026 (in press); Li 2024 (not used) |
| LPV observer SOC estimation lithium-ion battery | Semantic Scholar | 0 | 0 | 429 (4 attempts) |
| embedded implementation SOC microcontroller BMS (from 2020) | Crossref (curl) | 6 | 1 | Mostly chapters; one 2025 conference paper (not used) |
| microcontroller implementation SOC estimator real-time | Semantic Scholar | 10 | 3 | Succeeded after two 429s; mostly conference papers |
| embedded microcontroller implementation SOC real-time execution time memory 2023-2025 | WebSearch | 9 | 5 | Oehler 2022, Wan 2024, Celikten 2022, Cheng 2026 |
| Embedded real-time state observer implementation ... EKF | Crossref (curl) | 6 | 1 | Oehler 2022 |
| Towards fast embedded moving horizon SOC estimation | Crossref (curl) | 6 | 1 | Wan 2024 |
| Embedded deployment and system-level validation ... resource-constrained BMS | Crossref (curl) | 6 | 1 | Cheng 2026 |
| An execution time optimized SOC estimation method | Crossref (curl) | 6 | 1 | Celikten 2022 verified, not included |
| Cheng 2026 JES "S32K" OR "STM32" RAM flash execution time | WebSearch | 9 | 2 | <512 KB RAM, ~43% RAM reduction confirmed |
| Wan Du Yan Wang "Towards fast embedded MHE" microcontroller execution time | WebSearch | 9 | 3 | Raspberry Pi 4B, fixed GN iterations, N=3 |
| current sensor offset bias effect on SOC estimation BMS | Crossref (curl) | 6 | 0 | **NEGATIVE** |
| current sensor bias offset SOC robustness | Semantic Scholar | 0 | 0 | 429 |
| voltage sensor noise current sensor accuracy automotive BMS SOC | Semantic Scholar | 0 | 0 | 429 |
| SOC robustness current sensor bias "mA" voltage noise "mV" 2022-2026 | WebSearch | 9 | 6 | Shi 2023 (0.2 A, 5 mA/5 mV), POLISOC 2025, Zhao 2017, He 2019 |
| Lin Theoretical analysis of battery SOC estimation errors under sensor bias and variance | Crossref (curl) | 6 | 2 | TIE 65(9) 2018 |
| Observability analysis and state estimation ... sensor biases | Crossref (curl) | 6 | 1 | TCST 25(1) 2017 |
| Lin Stefanopoulou analytic bound on accuracy of battery state and parameter estimation | Crossref (curl) | 6 | 2 | JES 2015 found, not included |
| automotive BMS current sensor accuracy "offset" shunt Hall ... | WebSearch | 9 | 3 | Vendor pages (not recorded); Hatano 2023 Phil Trans A |
| POLISOC hybrid SOC estimation algorithm ... | Crossref (curl) | 6 | 1 | Clerici 2025 verified; not included |
| Robust Estimation of SOC in LFP cells ... DNN | Crossref (curl) | 6 | 1 | Shi 2023 IFAC |
| wide dynamic range diamond quantum sensor EV battery monitor | Crossref (curl) | 6 | 2 | Hatano 2023 and 2022 |
| OCV hysteresis model lithium-ion SOC estimation | Crossref (curl) | 6 | 2 | Schmitt 2024; Gagneur 2013 conf |
| OCV hysteresis lithium-ion battery model SOC Lin Tang | Semantic Scholar | 10 | 0 | **NEGATIVE** for "Lin, Tang, Zhang" |
| Knap Stroe effects of OCV tests and models on SOC estimation for batteries with hysteresis | Crossref (curl) | 6 | 2 | Actual title differs; not included |
| Baronti hysteresis modeling in Li-ion batteries | Crossref (curl) | 6 | 1 | IEEE Trans Magn 2014 verified (alternative) |
| 16 DOI lookups | Crossref /works/DOI | 16 | 16 | All resolved |
| Abstract retrieval by DOI for 12 items | Semantic Scholar + OpenAlex | 12 | 7 | Part subtitles and several abstracts obtained |
| Publisher pages (IEEE Xplore, Wiley, ScienceDirect, Artech, nature.com) | WebFetch | 0 | 0 | **NEGATIVE**: empty/403/login |

### 4.10 identification-methods (28 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| Coleman Li interior trust region approach ... bounds | Crossref | 5 | 1 | SIAM J Optim 6(2) |
| Storn Price Differential Evolution ... | Crossref | 3 | 1 | 429 then success |
| Kennedy Eberhart Particle swarm optimization 1995 ICNN | Crossref + DOI | 5 | 1 | vol 4 pp 1942-1948 |
| Hansen Ostermeier Completely Derandomized Self-Adaptation | Crossref | 3 | 1 | Evol Comput 9(2) |
| Pu Fractional Extreme Value Adaptive Training Method | Crossref | 3 | 2 | Author list has Huang not Wang; 2020 Comment exists |
| Wei Kang Yin Wang Generalization of the gradient method with fractional order gradient direction | Crossref | 3 | 2 | J. Franklin Inst. 357(4), not Signal Processing |
| Wei Kang Yin Wang 2020 'fractional order gradient' Signal Processing | WebSearch | 9 | 2 | Confirms JFI venue |
| Chen Gao Wei Wang Study on fractional order gradient methods | Crossref | 3 | 2 | AMC 314; ACC 2018 follow-up |
| Sheng Wei Chen Wang CNNs with fractional order gradient method | Crossref | 3 | 1 | Neurocomputing 408, not CSF |
| Akaike A new look at the statistical model identification 1974 | Crossref | 5 | 1 | TAC 19(6) |
| Schwarz Estimating the Dimension of a Model 1978 | Crossref + Project Euclid | 3 | 1 | Pages from Project Euclid |
| Hurvich Tsai Regression and time series model selection in small samples | Crossref | 3 | 1 | Biometrika 76(2) |
| Burnham Anderson Model Selection and Multimodel Inference (type:book) | Crossref + DOI | 5 | 2 | Book DOI issued 2004; 1998 1st ed. also listed |
| Burnham Anderson second edition 2002 Springer ISBN 0-387-95364-7 | WebSearch | 10 | 4 | 2002 print 2nd ed. confirmed |
| Efron Tibshirani An Introduction to the Bootstrap (type:book) | Crossref | 5 | 2 | 1993 Springer US; 1994 CRC |
| Ljung System Identification Theory for the User | Crossref | 5 | 1 | **NEGATIVE** for a book DOI (review only) |
| Ljung 2nd edition 1999 Prentice Hall ISBN | WebSearch | 10 | 5 | ISBN 0-13-656695-2 |
| Ljung Box On a measure of lack of fit in time series models | Crossref | 3 | 1 | Biometrika 65(2) |
| Virtanen SciPy 1.0 Nature Methods | Crossref (title+author) | 3 | 1 | Bibliographic query returned a review; title+author query found the paper |
| Diamond Boyd CVXPY | Crossref + JMLR page | 3 | 0 | Not on Crossref; verified on JMLR |
| Goulart Chen Clarabel | Crossref + DOI | 3 | 2 | MPC 2026 online-first, no volume |
| Goulart Chen Clarabel arXiv 2024 journal | WebSearch | 10 | 4 | arXiv 2405.12762; Springer page blocked |
| tempered fractional gradient descent method | Crossref | 0 | 0 | 429 twice |
| Tempered fractional gradient descent Theory algorithms ... (from 2024) | Crossref + DOI | 5 | 1 | Naifar 2026 Neural Networks 193 |
| 'tempered fractional' gradient descent optimization method | WebSearch | 9 | 2 | Only Naifar article and arXiv precursor |
| 'tempered fractional gradient' 2025 OR 2026 journal Neural Networks Naifar | WebSearch | 9 | 2 | Same two items; no other group |
| tempered fractional gradient descent | Semantic Scholar | 0 | 0 | 429 (three attempts) |
| fractional order gradient method convergence | Semantic Scholar | 0 | 0 | 429 |

### 4.11 mixed-order-tempered-stability (21 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| Stability analysis of linear fractional differential system with multiple time delays Deng Li Lu | Crossref | 5 | 1 | Verified by DOI |
| Brandibur Kaslik stability two-dimensional incommensurate fractional-order systems | Crossref | 8 | 3 | 2018 MMAS, 2021 FCAA, 2017 ND |
| Fractional systems state space description some wrong ideas ... | Crossref | 5 | 2 | JVC 2014; Syst. Control Lett. 2013 (verified, not included) |
| Initial conditions and initialization of linear FDEs Trigeassou Maamri | Crossref | 5 | 1 | 429 then success |
| A generalized Gronwall inequality ... Ye Gao Ding | Crossref | 5 | 1 | 429 then success |
| Petras Fractional-Order Nonlinear Systems (type:book) | Crossref | 5 | 1 | Unfiltered 429 twice; book-filter succeeded |
| Gorenflo Kilbas Mainardi Rogosin Mittag-Leffler Functions | Crossref | 2 | 2 | Chapter records; 2020 book DOI verified directly |
| Doetsch Introduction to the Theory and Application of the Laplace Transformation | Crossref | 5 | 1 | 1974 book record |
| tempered fractional Lyapunov stability "tempered Mittag-Leffler" ... | WebSearch | 9 | 5 | Deng 2020, Alanzi 2026, Zitane & Torres, Ahmed 2025 |
| tempered fractional systems stability Lyapunov Naifar Ben Makhlouf 2023-2025 | WebSearch | 9 | 6 | Lemnaouar, Alanzi x2, Alzahrani, Rguigui, IJSS 2026 |
| tempered fractional Lyapunov stability | Semantic Scholar | 20 | 12 | 429 then success; confirmed the same cluster; Wei 2023 nabla tempered |
| tempered FDE stability Lyapunov (from 2020) | Crossref | 0 | 0 | 429 twice |
| tempered fractional systems stability Lyapunov Mittag-Leffler (from 2023) | Crossref (curl) | 20 | 4 | Alanzi 2026 x2, Alawad 2025, Lenka 2025 |
| Zitane Torres Finite time stability of tempered fractional systems with time delays | Crossref | 3 | 2 | CSF 177 (2023); Tuan 2025 (not included) |
| "Finite time stability of tempered fractional systems with time delays" journal published | WebSearch | 9 | 3 | Confirmed CSF article |
| Gronwall inequality tempered FDEs comparison principle exponential kernel 2023-2025 | WebSearch | 9 | 2 | Ye 2007 canonical; Fractal Fract 2023 tempered Henry-Gronwall (unverified) |
| stability multi-order mixed-order FDE systems integer and fractional | Semantic Scholar | 0 | 0 | 429 (three attempts) |
| tempered fractional Mittag-Leffler stability Medved Pospisil | Semantic Scholar | 0 | 0 | 429; **NEGATIVE** by every engine |
| stability of mixed-order fractional systems combining integer-order and fractional-order states | WebSearch | 9 | 3 | Gallegos 2019; Diethelm-type multi-order |
| tempered Ψ-Caputo derivative stability Mittag-Leffler exponential kernel 2023-2025 | WebSearch | 9 | 2 | Mostly CF/AB non-tempered; Alanzi 2026, Deng 2020 |
| Smooth solutions to mixed-order fractional differential systems ... | Crossref | 3 | 1 | Gallegos 2019 (pages from Project Euclid) |
| Diethelm Siegmund Tuan asymptotic behavior ... multi-order | Crossref | 3 | 3 | FCAA 2017 verified; 2022 and 2024 follow-ups (not verified) |

### 4.12 battery-fractional-recent (33 queries)

| Query | Engine | n | rel | Outcome |
|---|---|---|---|---|
| fractional-order lithium-ion battery model identification relaxation EIS 2024 2025 | WebSearch | 9 | 6 | Adel 2025, AbdelAty 2024, Wei 2025, Wu 2025, Manivannan |
| fractional-order observer lithium-ion SOC LMI 2024 | WebSearch | 9 | 4 | No explicit 2023-2026 LMI FO SOC observer located |
| short memory principle GL fractional-order battery model embedded implementation 2023 2024 | WebSearch | 9 | 1 | **NEGATIVE** for 2023-2026 embedded finite-memory GL battery paper |
| fractional-order model lithium-ion SOC observer LMI (from 2023) | Crossref | 11 | 5 | Murakami 2024, Ma 2023 conf, Wang 2023, Ye 2023, Zhang 2023; no LMI-specific |
| fractional-order lithium-ion model temperature dependence fractional order CPE | Semantic Scholar | 0 | 0 | 429 (all 7 calls in this topic failed) |
| fractional-order ECM lithium-ion temperature dependence (from 2023) | Crossref | 7 | 4 | Wang 2023, Miao 2024, Mao 2023, Yang 2023 |
| Grunwald-Letnikov short memory fractional-order battery model implementation (from 2023) | Crossref | 10 | 0 | **NEGATIVE**: non-battery hits only |
| fractional-order sliding mode observer SOC (from 2023) | Crossref | 11 | 3 | Gaufan 2025, Ma 2023, Murakami 2024 |
| time-domain identification fractional-order battery model relaxation (from 2023) | Crossref | 0 | 0 | 429 |
| fractional-order battery model temperature dependence CPE parameters 2023-2025 | WebSearch | 9 | 4 | Zeng 2024, Miao 2024, Energy 2025, JES-ECS 2026 (unverified) |
| fractional-order model versus 2RC model comparison CALCE NASA 2023 2024 | WebSearch | 10 | 3 | Xu 2025, Cheng 2026; **no dedicated NASA FOM-vs-2RC benchmark** |
| fractional-order H-infinity observer SOC | WebSearch | 9 | 1 | Only 2022 CCC conference item; **NEGATIVE** for 2023-2026 |
| fractional-order unknown input observer SOC LMI convergence | WebSearch | 9 | 2 | "FOUIO with LMI" not traceable; **NEGATIVE** |
| DOI verification: est.2023.108043; apenergy.2023.120977; machines12100738 | Crossref | 3 | 3 | Verified |
| DOI verification: ad4a09; fractalfract9070429 | Crossref | 0 | 0 | 429 first; both later verified |
| Time-domain system identification using fractional models from non-zero initial conditions | Crossref | 2 | 2 | ARC 2025 + IFAC 2023 |
| SOC estimation ... incommensurate fractional-order observer | Crossref | 3 | 3 | Chen 2023, Murakami 2024, Wei & Ling 2022 |
| A Control Oriented Fractional-Order Model ... Caputo Definition | Crossref | 3 | 2 | Xu 2025 (author list differs from arXiv); Tu 2022 CCC |
| "fractional-order" lithium-ion model microcontroller real-time truncated memory GL BMS 2024 2025 | WebSearch | 9 | 4 | Xu 2025, Liu 2026, Putri 2025, Energies 2021 |
| arxiv 2505.12725 control oriented FO model Caputo | WebSearch | 9 | 1 | Preprint details confirmed |
| Publisher pages (MDPI x4, ScienceDirect x7, Wiley, Springer) | WebFetch | 0 | 0 | 403 / login |
| fractional-order model CALCE INR18650 dataset FO Kalman filter 2024 2025 | WebSearch | 9 | 4 | Cheng 2026, Xing 2024 |
| Malti Adel Briat fractional model identification Li-ion relaxation initial conditions | WebSearch | 9 | 2 | ARC 2025 + IFAC 2023 confirmed |
| DOI verification: fractalfract9070429; 10070500; batteries11120452; fractalfract8120695 | Crossref (polite pool) | 4 | 4 | Verified with abstracts |
| Crossref title searches: Zeng 2024; Manivannan; Cheng; Wu; ese3.1674; trpro | Crossref | 6 | 6 | All verified |
| OpenAlex abstract retrieval for 7 DOIs | OpenAlex | 7 | 3 | Abstracts for Chen 2023, Gaufan 2025, Adel 2025 only |
| Zeng "asynchronous fractional-order" thermoelectric coupling Energy 2024 doi | WebSearch | 9 | 2 | Confirmed |
| "incommensurate fractional-order observer" Chen Lopes LMI Lyapunov | WebSearch | 9 | 2 | Content confirmed; Wu 2025 surfaced |
| fractional-order lithium-ion FPGA OR microcontroller OR HIL SOC 2024 2025 | WebSearch | 9 | 1 | **NEGATIVE**: no FO SOC estimator with FPGA/MCU/HIL deployment 2023-2026 |
| Fractional variable-order observer-based method ... (from 2025) | Crossref | 3 | 2 | Wu 2025 verified |
| DOI verification: arcontrol 101017; est 118871; cnsns 107059; est 119937 | Crossref | 4 | 4 | Verified |
| "fractional-order" battery "memory length" OR "short memory" truncation accuracy SOC 2023-2025 | WebSearch | 9 | 2 | Only Liu 2026 and Tian 2020 address truncation; no certified bound |
| fractional variable-order observer SOC Applied Energy 2025 Chen Lopes | WebSearch | 9 | 2 | Confirmed |

## 5. Verification outcome

All 182 records were checked against Crossref (or, for the six no-DOI items, against publisher/retailer/index pages). Summary of `bib_verification.json`:

- `exact`: 152 records (all fields agree with Crossref; cosmetic changes only, e.g. `--` page ranges, DOI case, LaTeX accents).
- `minor_fix`: 24 records, each with a documented change (author diacritics: `fernandez2020analytic`, `alanzi2026lyapunov`; volume/issue/pages missing on Crossref and taken from the publisher page: `chen2015discretized`, `zou2018nonlinear`, `schwarz1978estimating`, `gallegos2019smooth`; online-first vs print year: `alkhrijah2025unknown`, `rguigui2025practical`, `deng2007stability`; Early-View/in-press items without volume: `alzahrani2026practical`, `bouteraa2026observer`, `benmakhlouf2026practical`, `badie2026lpv`; Greek letters and math in titles: `lan2012observer`; subtitle/series additions: `plett2004background/modeling/estimation`, `petras2011fractional`, `burnham2002model`, `kilbas2006theory`; author-list truncation: `virtanen2020scipy`; preprint typed as `@misc`: `naifar2025theoretical`; formatting only: `gaufan2025enhanced`, `wei2022temperature`).
- `no_doi_book_verified`: 6 records (`podlubny1999fractional`, `matignon1996stability`, `khalil2002nonlinear`, `plett2015bms2`, `ljung1999system`, `diamond2016cvxpy`).
- `mismatch` / `unresolved`: 0 records at the record stage (see Section 7 for candidates dropped earlier).

Year conventions to decide at proof stage: `alkhrijah2025unknown` and `rguigui2025practical` are cited with the print-issue year 2026 (vol. 28, no. 1) while their keys carry the online-first year 2025; `wei2023lyapunov`, `sabatier2014fractional`, `lemnaouar2026lyapunov`, `li2016high`, `chen2015discretized`, `deng2007stability` and `trigeassou2011lyapunov` use the print-volume year.

## 6. Metadata corrections relative to the original task briefs

| Item | Correction |
|---|---|
| Wang et al. 2015 (J. Power Sources) | Authors are Wang, Li, Peng, Liu; there is no "Ni" co-author. |
| Applied Energy 2017 FO SOC paper | First author is Mu (Mu, Xiong, Zheng, Chang, Chen), not Xiong-Tian-Mu-Wang (a different SOH paper). |
| Zou et al. 2018 review | Authors are Zou, Zhang, Hu, Wang, Wik, Pecht; Manzie is not a co-author. |
| Hu et al. 2018 (IEEE TVT) | Authors are Hu, Yuan, Zou, Li, Zhang, not "Huang, Mo". |
| Freeborn et al. "2013" | Resolves only to ISCAS 2013 conference papers; the 2015 journal survey is used. |
| Deng 2007 short-memory paper | Journal is J. Comput. Appl. Math. 206(1), not J. Comput. Phys. |
| Boroujeni & Momeni 2012 | Requested title "Non-fractional and fractional-order observers for fractional systems" does not exist; the actual 2012 Signal Processing paper is the non-fragile FO observer. |
| Kim "2006/2010" sliding-mode SOC | The SOC sliding-mode paper is 2008 (IEEE TPEL 23(4)); the 2010 paper is a dual-sliding-mode SOH observer. |
| Pei et al. relaxation model | 2013, IET Electr. Syst. Transp. 3(4), authors Pei, Lu, Zhu (not 2014 / "Pei, Zhu, Wang"). |
| Hilfer 2002; Bisquert & Compte 2001 | Correct DOIs are 10.1016/S0301-0104(02)00670-5 and 10.1016/S0022-0728(00)00497-6. |
| Pu et al. 2015 (IEEE TNNLS) | Author list contains Huang, not Wang. |
| Wei et al. 2020 fractional gradient | Journal of the Franklin Institute 357(4), not Signal Processing. |
| Sheng et al. 2020 | Neurocomputing 408, not Chaos, Solitons & Fractals. |
| Xu et al. 2025 (JES) | Journal author list (Xu, Liao, Wang, Wang) differs from the arXiv preprint; Crossref list used. |
| CALCE INR 18650-20R citations | The data page requests three citations (Zheng 2016, Xing 2014, He 2014), not two. |
| Li & Deng "High order schemes" | Crossref issued 2015 (online), print vol. 42(3) is 2016. |
| Clarabel (Goulart & Chen) | Now a Mathematical Programming Computation article (online 21 May 2026), no volume yet; arXiv:2405.12762 is the preprint. |

## 7. Candidates dropped or not included

No record reached the verification stage with status `mismatch` or `unresolved`. The following candidates were dropped **before** the record stage, or verified but deliberately not included:

| Candidate | Status | Reason |
|---|---|---|
| Vinagre, Podlubny, Hernández, Feliu 2000, FCAA 3(3) 231-248 | no_doi_unverified | Not indexed on Crossref (pre-2011 FCAA); Semantic Scholar rate-limited; confirmed only by secondary citations. Cite without DOI only if indispensable. |
| "Lin, Tang, Zhang" OCV hysteresis paper (brief item) | unresolved | No paper with this author combination found on Crossref or Semantic Scholar; replaced by `schmitt2024hysteresis` (and Baronti et al. 2014, verified, available). |
| "Zhang, Xu, ..." FO ECM SOC item (brief item) | unresolved | Incomplete brief entry could not be identified. |
| Boroujeni & Momeni, "Non-fractional and fractional-order observers for fractional systems" | mismatch (title does not exist) | Replaced by `boroujeni2012nonfragile`. |
| Medveď / Pospíšil tempered-stability papers | not found | No such tempered Lyapunov/Mittag-Leffler stability paper located by any engine. |
| "FOUIO with LMI" mentioned in web summaries | unresolved | Could not be traced to a Crossref record. |
| Menon et al., Sci. Rep. 2026 (10.1038/s41598-026-67204-7) | dropped | No readable abstract; Crossref 429; exact-title search returned no match. |
| Hwang et al., Koopman LMI observer, ASME Letters 2026 (10.1115/1.4072730) | dropped | No abstract obtainable (Semantic Scholar 404). |
| Lin et al., JES 2026 observer-guided DL (10.1016/j.est.2026.122923); Chai et al., JES 2024 AFCKF (10.1016/j.est.2024.110728); JES 2025 PINN + adaptive KF (DOI unresolved) | dropped | Abstract not (or only partially) retrievable. |
| Zhang et al., JPS 2024 (10.1016/j.jpowsour.2023.233758); Wang et al., JES 2023 (10.1016/j.est.2023.106831) | verified, not included | Partial abstracts only; record count already at target. |
| Tian, Xiong, Shen, Wang 2020, CJME 33:51 (10.1186/s10033-020-00467-x) | verified, not included | Memory-length sensitivity study; available if wanted. |
| arXiv 1304.0616 (fixed-memory GL), arXiv 2603.16851 (Koopman finite-memory GL), arXiv 2512.12285 (FDE-PINN), arXiv 2605.28901, arXiv 2601.03318 | preprints | Not peer-reviewed. |
| Coccolo 2026 CSF; Dong 2026 Mathematics | verified, not included | Finite-memory GL in non-battery systems. |
| Jmal & Ahmed, Asian J. Control 28(1) 424-430 (10.1002/asjc.3754); Marir & Chadli 2025 Springer chapter (10.1007/978-3-031-87382-9_2) | verified, not included | Optional FO observer/stability citations. |
| Sabatier et al., Syst. Control Lett. 62(9) 739-746 (2013) | verified, not included | Optional non-commensurate stability test. |
| Lischke-Kelly-Meerschaert 2019; Qiu & Cao 2019; Meerschaert & Sabzikar 2014, 2016 | verified, not included | Additional tempered-calculus items, available. |
| Theuerkauf & Swan 2022 Batteries; Ko & Chen 2024 Applied Energy | verified, not included | Optional relaxation-characterisation citations. |
| Celikten et al. 2022 JES; Clerici et al. 2025 (POLISOC); Knap & Stroe 2021; Baronti et al. 2014; Lin & Stefanopoulou 2015 | verified, not included | Lower priority or abstract not retrievable. |
| Miao 2024 Ionics; Wu 2024 Fractal Fract; Putri 2025 Batteries; JES-ECS 2026 (10.1149/1945-7111/ae4898); Zeng 2025 IJCTA; Tu 2022 CCC | seen, not verified/included | Lower relevance or conference/unverified. |
| Vendor sensor-accuracy pages (Melexis, TI, LEM) | excluded | Not peer-reviewed. |

## 8. Novelty assessment

The statements below are limited to what the search described in Sections 1-4 could establish. They should be read with the limitations of Section 9 in mind (Semantic Scholar was essentially unavailable, and several publisher sites blocked automated access).

**(i) Tempered fractional battery models.** To the best of the authors' knowledge, the literature search described in Section 4.2 (20 web-search queries and 8 completed Crossref queries with the terms "tempered fractional" combined with battery, lithium-ion, equivalent circuit, constant phase element, Warburg, impedance, supercapacitor, fuel cell, porous electrode and solid-phase diffusion) did not identify any peer-reviewed publication that applies a tempered fractional derivative (exponentially tempered Riemann-Liouville, Caputo or Grünwald-Letnikov operator) to a lithium-ion equivalent-circuit model, to a constant-phase or diffusion element, or to an electrochemical impedance model. The only located application of tempered fractional calculus to lithium-ion batteries is Kahouli et al. (2026, `kahouli2026tempered`), which uses a tempered fractional weight-adaptation law inside an RBF deterministic-learning scheme for state-of-health estimation on NASA cycle-level data; it contains no circuit model, no observer and no SOC estimator. The physical rationale for tempering (power-law memory that crosses over to exponential decay) is documented only in the generic tempered-diffusion literature (`meerschaert2008tempered`, `stanislavsky2008diffusion`, `baeumer2010tempered`), not in any battery-specific paper; the manuscript's link between tempered kernels and cell relaxation is therefore a claim to be argued, not a cited fact.

**(ii) Tempered fractional SOC estimators.** To the best of the authors' knowledge, the searches in Sections 4.2, 4.3 and 4.8 (including a Crossref query restricted to 2023-2026 and web-search queries combining "tempered fractional" with observer, estimator, Kalman, extended/unscented Kalman and state of charge) did not identify any model-based SOC estimator (Luenberger/LMI, sliding-mode, or Kalman-type) built on a tempered fractional model, nor any tempered fractional Kalman filter of any kind. Tempered fractional observer theory exists only as general systems theory validated on numerical examples (`alzahrani2026practical`, `alkhrijah2025unknown`, `alanzi2026lyapunov`, `bouteraa2026observer`, `lamrani2025controllability`), without physical or experimental application. The manuscript's tempered-fractional LMI observer validated on measured CALCE data therefore appears to be without direct precedent in the indexed literature.

**(iii) Finite-memory fractional observers with truncation certificates.** To the best of the authors' knowledge, the searches in Sections 4.4, 4.5 and 4.12 did not identify a 2023-2026 peer-reviewed SOC estimator that (a) implements a finite-memory (short-memory) Grünwald-Letnikov recursion and (b) provides a certified bound on the resulting truncation error inside the observer convergence proof. The closest prior work is Rauh & Lahme (`rauh2024finite`, `rauh2025observer`), who quantify and correct finite-memory truncation errors with interval/set-based methods for fractional battery pseudo-state estimation, but without an LMI design, without tempering, and (as far as could be established) without experimental validation. Recent battery estimators that use a finite GL window (`liu2026fractional`, 3600 s horizon; `solomon2022state`, improved short-memory principle) discuss the trade-off qualitatively but give no error bound. General short-memory theory (`deng2007short`, `wei2017note`, `stark2021convergence`, `hai2022stability`, `mu2025asymptotic`) does not treat observers. No paper combining a tempered GL discretisation with observer design was found at all.

**(iv) Fractional battery ECMs.** This is an established field and no novelty is claimed for the use of fractional-order ECMs as such: foundational work (`sabatier2006fractional`, `wang2015fractional`, `alavi2015timedomain`, `freeborn2015fractional`, `zou2018review`) and a large 2023-2026 body of FO models, identification methods and estimators were found (Sections 4.3 and 4.12; see `literature_comparison.json`). What the search did **not** find among 2023-2026 FO battery papers is: an LMI-based or H-infinity FO SOC observer in the surveyed journals (the closest is the 2021 Energies non-fragile H-infinity FO observer, `zhang2021nonfragile`); a FO SOC estimator that reports embedded (MCU/FPGA/HIL) computational cost; or a dedicated FOM-versus-1RC/2RC benchmark on the NASA data. Only three recent FO observers state a theoretical convergence guarantee (`guo2024selfadaptive`, `wu2025fractional`, `murakami2024state`), and none certifies memory truncation.

**(v) Tempered fractional gradient descent.** To the best of the authors' knowledge, the searches in Sections 4.2 and 4.10 identified exactly one peer-reviewed paper introducing tempered fractional gradient descent (`naifar2026tempered`, Neural Networks 2026, with the arXiv precursor `naifar2025theoretical`) and one further application (`alaerjan2026tempered`, smart-grid stability prediction). No use of tempered fractional gradient descent for battery-model parameter identification was found, and no work by any other group on a "tempered fractional gradient" method was located. This statement carries the caveat that Semantic Scholar could not be queried.

Suggested manuscript wording: "To the best of the authors' knowledge, and based on a documented search of Crossref and the open web carried out in September 2026 (Semantic Scholar being unavailable at search time), no prior work applies a tempered fractional-order equivalent-circuit model, a tempered fractional observer, or a finite-memory tempered Grünwald-Letnikov implementation with a certified truncation bound to lithium-ion SOC estimation; the only tempered-fractional battery paper located addresses data-driven SOH learning [kahouli2026tempered]."

## 9. Limitations of the search

1. **Semantic Scholar** returned HTTP 429 on nearly all search calls in all twelve topics; its coverage is therefore missing, and negative results rely on Crossref and web search only.
2. **Crossref rate limiting** caused several queries to fail without data (listed as 429 in Section 4); most were re-issued, but three tempered-battery queries, two finite-memory queries and one mixed-order query could not be completed and were covered only by web search.
3. **Publisher access**: ScienceDirect, MDPI, Wiley, AGU, ESAIM and Artech House returned HTTP 403, Springer required login and IEEE Xplore returned empty pages. Abstracts of many Elsevier items were read from search-engine snippets or mirrors; `validation_type`, RMSE and cost fields marked "inferred" or "not stated" in `literature_comparison.json` should be checked against full texts before being quoted.
4. **Items with incomplete Crossref records**: `zou2018nonlinear` (IEEE Xplore), `chen2015discretized` (ESAIM listing), `schwarz1978estimating` and `gallegos2019smooth` (Project Euclid), `meerschaert2008tempered` (L17403 from indexed listings) take volume/page data from non-Crossref sources.
5. **In-press / online-first items** without volume: `badie2026lpv`, `bouteraa2026observer`, `alzahrani2026practical`, `benmakhlouf2026practical`, `goulart2026clarabel`; re-check before submission.
6. **Self-citations**: `naifar2026tempered`, `naifar2025theoretical`, `alanzi2026lyapunov`, `alanzi2026practical` and `bouteraa2026observer` share an author with the presumed manuscript authors.
7. **Record counts** exceed the per-topic targets in `fo-battery-models` (19), `fo-stability-observers` (22), `ecm-ocv-foundations` (21) and `mixed-order-tempered-stability` (15) because the briefs enumerated many mandatory items; candidates for trimming are named in the per-topic gap notes (e.g. `zhang2021nonfragile`, `wang2025improved`, `chen2023stateofcharge`, `badie2026lpv`, `wan2024embedded`, `zhao2017observability`, `hatano2022highprecision`, `schmitt2024hysteresis`, `plett2004background`, `gallegos2019smooth`, `diethelm2017asymptotic`).
8. **CALCE dataset details** (sampling interval, test equipment, sample-to-test mapping) are not on the CALCE page; the 1 s sampling and Arbin BT2000 platform come from a third-party paper and should be confirmed against Zheng et al. 2016. The CALCE page does not name Samsung as the manufacturer.
