# Conservatism of the certified truncation bound at L = 400 s

Generated 2026-09-28T05:04:38+00:00 by `scripts/11_conservatism.py` (code hash bb910ddccece6aab); all numbers from `results/conservatism.json` (keys `summary.<method>.<T>.<key>` with median, min, max over runs; per-run values in `files[*].runs`).

**Status: post-hoc diagnostic on the 18 test records x 3 initial-SOC scenarios.** Nothing is tuned or selected here: the frozen TFO (lambda = 1e-4 1/s, N_L = 400) and, as the untempered counterpart, the frozen FOO (lambda = 0, N_L = 400) are run with their frozen parameters and gains, once with N_L = 400 and once with full memory. Test records are used only because nothing is fitted.

## Definitions

* Certified bound B = gamma_zp^(h,L)(kappa1, kappa2) x h^-alpha sum_{j>N_L} |omega_j| x B_p (Corollary S1.7.9(i); equals `gain_design.json` post_certificates ez_bound_exact, checked per temperature).
* Actual truncation-induced deviation d_n = zhat_400,n - zhat_full,n (same parameters, gains, z0 and data). A = max |d_n| on the admissible window (t - t0 >= 600 s, reference SOC in [0.10, 0.95]).
* gap = B / A = F_a F_b1 F_b2 F_c1 F_c2 F_d1 F_d2 F_w, exactly per run (largest relative error of the product 6.7e-16). The median of the gap is not the product of the median factors (both are given).
* d obeys exactly the linear error recursion of prop:m4b:errorrec with secant slopes and input R_n = h^-alpha sum_{N_L<j<=n} omega_j Vhat_p,n-j of the full-memory estimate: largest relative closure error 6.4e-14. Record maxima are taken before the first SOC-clip sample of either run (clipping occurs only after the admissible window).
* gamma_dc(kappa) = 1/(kappa (a_p + mu_{h,L}(0))) is the DC gain of that recursion at a constant slope; its impulse response was one-signed in every run (l1 norm equal to the DC gain).
* (e) r_n is the consistency residual of eq:m4b:residuals for the continuous-time element with the same parameters (exact response to the piecewise-constant current); it does not depend on L and does not enter d.

## TFO (lambda = 1e-4 1/s)

Median [min, max] over 6 records x 3 scenarios per temperature.

| quantity | 0 C | 25 C | 45 C |
|---|---|---|---|
| certified bound B (% SOC) | 49.0 | 48.5 | 15.5 |
| actual max abs d on window (% SOC) | 3.78 [2.99, 4.55] | 3.86 [3.05, 4.82] | 1.33 [1.06, 1.65] |
| actual RMS d on window (% SOC) | 2.14 [1.8, 2.35] | 2.41 [2.16, 2.73] | 0.747 [0.671, 0.853] |
| mean d on window (% SOC) | -1.87 [-1.97, -1.63] | -2.1 [-2.29, -1.97] | -0.663 [-0.723, -0.625] |
| total gap B / A | 13.4 [10.8, 16.4] | 13 [10.1, 15.9] | 12.1 [9.36, 14.6] |
| (a) B_p / max abs Vhat_p | 2 [1.73, 3.29] | 2.56 [2.15, 3.73] | 1.69 [1.49, 3] |
| (b1) tail sum x max abs Vhat_p / max_n sum abs(omega_j) abs(Vhat_p) | 4.23 [2.44, 4.94] | 3.22 [2.14, 4.04] | 4.53 [2.53, 5] |
| - of which: tail beyond the record length | 1.1 [1.06, 1.16] | 1.08 [1.05, 1.12] | 1.09 [1.05, 1.13] |
| - of which: Vhat_p below its peak under the tail | 3.78 [2.29, 4.39] | 2.96 [2.04, 3.62] | 4.2 [2.4, 4.48] |
| (b2) sign cancellation in R_L | 1 [1, 1.08] | 1 [1, 1.02] | 1.02 [1, 1.13] |
| (c1) l2 kappa2 coupling in gamma_zp | 1.02 [1.02, 1.02] | 1 [1, 1] | 1.01 [1.01, 1.01] |
| (c2) median slope visited / kappa1 | 2.3 [1.42, 3.25] | 2.05 [1.34, 2.8] | 2.3 [1.62, 3.05] |
| (d1) static gain x max abs R vs LTI response at median slope | 1.06 [1.03, 1.1] | 1.05 [1.03, 1.07] | 1.04 [1.01, 1.06] |
| (d2) LTI at median slope vs actual transmission | 0.693 [0.386, 1.17] | 0.833 [0.447, 1.25] | 0.703 [0.387, 1.07] |
| (w) whole record vs admissible window | 1 [1, 1] | 1 [1, 1] | 1 [1, 1] |
| a x b: a-priori residual size B_p W_tail / max abs R | 8.44 [7.87, 9.25] | 8.35 [7.79, 8.91] | 7.95 [7.58, 8.43] |
| c x d: gamma_zp / actual peak transmission | 1.56 [1.35, 1.85] | 1.55 [1.29, 1.78] | 1.5 [1.23, 1.77] |
| product of the median factors | 14.7 | 14.9 | 13.2 |
| B_p (V) / max abs Vhat_p (V) | 0.532 / 0.267 | 0.411 / 0.161 | 0.266 / 0.157 |
| kappa1 / median kappa visited (V) | 0.229 / 0.527 | 0.239 / 0.49 | 0.259 / 0.596 |
| gamma_zp / gamma_dc(median kappa) / max abs d / max abs R (V^-1 s^alpha) | 7.67 / 3.47 / 4.99 | 10.2 / 5.54 / 6.71 | 4.92 / 2.32 / 3.35 |
| max abs R_L[Vhat_p] (mV s^-alpha) | 7.59 [6.91, 8.12] | 5.72 [5.35, 6.11] | 3.96 [3.73, 4.15] |
| admissible post RMSE vs reference, N_L = 400 / full (% SOC) | 1.83 / 1.66 | 1.21 / 1.84 | 1.01 / 0.512 |

Plant-model variant and consistency residual (6 records per temperature):

| quantity | 0 C | 25 C | 45 C |
|---|---|---|---|
| (a) B_p / max abs V_p of the identified plant model | 2 [1.73, 3.29] | 2.56 [2.15, 3.73] | 1.69 [1.49, 3] |
| (b) tail sum x max abs V_p / max abs R_L[V_p] | 4.17 [2.4, 5] | 3.2 [2.14, 4.13] | 4.68 [2.54, 5.42] |
| max abs difference, discrete model - continuous element (mV) | 5.19 [2.77, 5.82] | 3.73 [1.96, 4.03] | 2.67 [1.42, 3.17] |
| (e) sup abs r_n (mV s^-alpha) | 5.92 [2.92, 6.63] | 3.86 [1.9, 4.22] | 3.45 [1.72, 4.14] |
| (e) RMS r_n (mV s^-alpha) | 1.19 [0.49, 1.39] | 0.78 [0.315, 0.903] | 0.682 [0.279, 0.801] |
| (e) sup abs r_n / max abs R_L[V_p] | 0.779 [0.385, 0.818] | 0.673 [0.338, 0.763] | 0.878 [0.414, 1] |
| (e) gamma_zp x sup abs r_n (% SOC) | 4.54 [2.24, 5.09] | 3.93 [1.94, 4.29] | 1.7 [0.844, 2.04] |

## FOO (lambda = 0, untempered counterpart)

Median [min, max] over 6 records x 3 scenarios per temperature.

| quantity | 0 C | 25 C | 45 C |
|---|---|---|---|
| certified bound B (% SOC) | 774.8 | 754.3 | 180.7 |
| actual max abs d on window (% SOC) | 4.45 [3.34, 5.59] | 4.65 [3.5, 6.03] | 1.57 [1.16, 2.02] |
| actual RMS d on window (% SOC) | 2.52 [2.03, 2.89] | 2.91 [2.48, 3.41] | 0.885 [0.758, 1.04] |
| mean d on window (% SOC) | -2.17 [-2.4, -1.84] | -2.51 [-2.83, -2.27] | -0.783 [-0.877, -0.708] |
| total gap B / A | 183 [139, 232] | 171 [125, 216] | 123 [89.6, 156] |
| (a) B_p / max abs Vhat_p | 7.43 [6.34, 12] | 12.1 [10.1, 17.6] | 4.09 [3.58, 7.15] |
| (b1) tail sum x max abs Vhat_p / max_n sum abs(omega_j) abs(Vhat_p) | 12.6 [7.44, 16.3] | 7.75 [5.06, 10.4] | 15.3 [8.51, 18.1] |
| - of which: tail beyond the record length | 3.37 [3.17, 3.69] | 2.64 [2.47, 2.8] | 3.74 [3.49, 4.01] |
| - of which: Vhat_p below its peak under the tail | 3.78 [2.35, 4.65] | 2.92 [2.05, 3.73] | 4.19 [2.43, 4.62] |
| (b2) sign cancellation in R_L | 1 [1, 1.09] | 1 [1, 1.02] | 1.02 [1, 1.13] |
| (c1) l2 kappa2 coupling in gamma_zp | 1.12 [1.12, 1.12] | 1.06 [1.06, 1.06] | 1.11 [1.11, 1.11] |
| (c2) median slope visited / kappa1 | 2.28 [1.4, 3.21] | 2.02 [1.34, 2.77] | 2.29 [1.6, 3.03] |
| (d1) static gain x max abs R vs LTI response at median slope | 1.05 [1.03, 1.1] | 1.05 [1.02, 1.06] | 1.03 [1.01, 1.05] |
| (d2) LTI at median slope vs actual transmission | 0.75 [0.417, 1.27] | 0.915 [0.491, 1.36] | 0.776 [0.416, 1.21] |
| (w) whole record vs admissible window | 1 [1, 1] | 1 [1, 1] | 1 [1, 1] |
| a x b: a-priori residual size B_p W_tail / max abs R | 97.5 [86.5, 113] | 95.7 [85.5, 108] | 66.6 [60.7, 74] |
| c x d: gamma_zp / actual peak transmission | 1.82 [1.55, 2.2] | 1.75 [1.46, 2.05] | 1.8 [1.45, 2.2] |
| product of the median factors | 190 | 191 | 129 |
| B_p (V) / max abs Vhat_p (V) | 2 / 0.27 | 2 / 0.165 | 0.648 / 0.159 |
| kappa1 / median kappa visited (V) | 0.229 / 0.521 | 0.239 / 0.481 | 0.259 / 0.592 |
| gamma_zp / gamma_dc(median kappa) / max abs d / max abs R (V^-1 s^alpha) | 8.45 / 3.52 / 4.69 | 10.7 / 5.6 / 6.21 | 5.43 / 2.33 / 3.09 |
| max abs R_L[Vhat_p] (mV s^-alpha) | 9.46 [8.14, 10.6] | 7.4 [6.56, 8.25] | 5.02 [4.5, 5.49] |
| admissible post RMSE vs reference, N_L = 400 / full (% SOC) | 1.83 / 1.8 | 1.21 / 2.27 | 1 / 0.516 |

Plant-model variant and consistency residual (6 records per temperature):

| quantity | 0 C | 25 C | 45 C |
|---|---|---|---|
| (a) B_p / max abs V_p of the identified plant model | 7.46 [6.46, 12.2] | 12.2 [10.2, 17.6] | 4.1 [3.59, 7.2] |
| (b) tail sum x max abs V_p / max abs R_L[V_p] | 12.8 [7.14, 15.8] | 7.69 [5.02, 10.4] | 15.9 [8.5, 19.1] |
| max abs difference, discrete model - continuous element (mV) | 5.18 [2.76, 5.81] | 3.72 [1.96, 4.02] | 2.66 [1.42, 3.17] |
| (e) sup abs r_n (mV s^-alpha) | 5.9 [2.91, 6.61] | 3.86 [1.9, 4.21] | 3.46 [1.72, 4.15] |
| (e) RMS r_n (mV s^-alpha) | 1.19 [0.489, 1.38] | 0.779 [0.315, 0.903] | 0.683 [0.28, 0.803] |
| (e) sup abs r_n / max abs R_L[V_p] | 0.606 [0.292, 0.673] | 0.501 [0.249, 0.607] | 0.687 [0.313, 0.754] |
| (e) gamma_zp x sup abs r_n (% SOC) | 4.99 [2.46, 5.59] | 4.12 [2.03, 4.51] | 1.88 [0.933, 2.25] |

## Tempered versus untempered at L = 400 s

| T | bound FOO / TFO | actual max abs d, FOO / TFO (medians) | gap FOO / TFO (medians) |
|---|---|---|---|
| 0 C | 15.8 | 1.18 | 13.6 |
| 25 C | 15.6 | 1.21 | 13.1 |
| 45 C | 11.7 | 1.18 | 10.2 |

## Interpretation

For the frozen TFO the certified bound exceeds the actual truncation-induced deviation by a median factor of 12-13 per temperature (single runs 9.36 to 16.4). The actual deviation is not small: its maximum on the admissible window has medians of 3.8, 3.9, 1.3 % SOC at 0, 25 and 45 C, with window means of -1.9, -2.1, -0.66 % SOC (a slowly varying offset), so the 400 s memory would not meet a 0.5 % truncation target even without any conservatism. (The paper's factor of 15 to 39 compares the bound with the measured SOC error, a different quantity.) Because the parameters were identified at L = 400 s, this deviation is the difference between two implementations of the same fitted model, not an error with respect to the cell. Most of the gap is in the a-priori size of the residual (a x b, medians 7.95-8.44): B_p, the steady state at the largest current, is 1.69-2.56 times the largest polarisation reached, and the absolute tail sum weights that peak over the whole infinite tail, whereas the discarded window sees a polarisation averaged over thousands of seconds (b1, 3.22-4.53; the part of the tail beyond the record length is only 1.08-1.10). Sign cancellation plays no role (b2, 1.00-1.02): the discarded memory averages the polarisation over long stretches dominated by the net discharge, so the remainder keeps one sign and is close to its absolute sum. The gain chain is tight (c x d, 1.50-1.56): the worst slope kappa1 costs a factor 2.05-2.30 against the median slope visited, but the transmission actually realised exceeds the LTI gain at the median slope, presumably because the deviation accumulates in low-slope stretches (d2, 0.69-0.83); the l2 kappa2 coupling (c1) and the dynamic attenuation (d1) each stay within 10 %. The consistency residual r_n reaches 0.67-0.88 of the peak truncation remainder but is spiky (RMS about one fifth of its sup); it does not enter d. For the untempered FOO the gap is 123-183, and almost all of the extra conservatism is in the input chain (a x b, 67-98): B_p = b_p I_max / a_p is a DC level the slow untempered element never approaches, and much of the untempered tail lies beyond the record lengths (b1_len 2.64-3.74). Tempering lowers the certified bound by a factor 11.7-15.8 but the actual deviation only by a factor 1.18-1.21 on these records: at 400 s the certified advantage of tempering is mostly an advantage of the bound, not of the implemented recursion.

Runtime 37 s wall with 2 workers.
