# Claims-to-evidence map (Integrate phase, 2026-09-27)

Each claim of the abstract (`manuscript_parts/abstract.tex`), the contributions (`manuscript_parts/sec1_introduction.tex`,
list "Its contributions are the following") and the conclusions (`manuscript_parts/sec7_conclusions.tex`) is listed with
its type, its evidence and its status. The manuscript version is Tables `tab:claims` and `tab:claims_cont`
(`tables/tab_claims.tex`, input at the end of Section 6.7). Numbers are copied from the cited files; nothing is recomputed here.

Types: **A** analytical guarantee; **I** identified parameter or data analysis; **P** observed performance (offline
validation on the CALCE dataset); **E** engineering interpretation.
Status: **supported**; **partially** (qualification stated); **not supported** (removed or stated as a limitation).

## A. Analytical guarantees

| # | Claim | Evidence (manuscript) | Evidence (files) | Status |
|---|---|---|---|---|
| 1 | LP/LMI certificate gives exponential stability of the continuous full-memory error system, any rate sigma in (0, lambda], uniformly over slope histories in [kappa1, kappa2] | Thm `thm:fullmemory`, Prop `prop:lplmi` (Sec. 3-4); proofs App. B | `manuscript_parts/math/M3a.tex`, `supplementary/S1_M3a.tex`; `reports/F_theory_status.md` | supported |
| 2 | No gains give a rate above lambda; constant slope: e^{-lambda t} times an algebraic factor (t^{-alpha} if e_p(0) != 0) | Props `prop:meaning`, `prop:feasible`(iii); Thm `thm:asymptotic` | `supplementary/S1_M3a.tex`, `S1_M3b.tex` | supported |
| 3 | Without tempering, exponential stability of the observer error is ruled out (no exponential bound for e_p(0) != 0; for l2 = 0, e_p(0) = 0 the SOC error still decays exponentially) | Cor `cor:untempered` | `supplementary/S1_M3b.tex` | supported (abstract wording corrected from "rules out exponential observer convergence") |
| 4 | Truncation error ~ e^{-lambda L} L^{-1-alpha} vs L^{-alpha}; closed-form inversion | Thm `thm:truncation`, Cor `cor:memoryrule` | `supplementary/S1_M2.tex` | supported |
| 5 | Implemented finite-memory observer certified at grid points; for lambda > 0 practical exponential convergence at rate min{sigma, lambda} (V_p(0) part at lambda); for lambda = 0 the V_p(0) part decays algebraically | Thm `thm:sampled`, Rem `rem:res:fir`, Cor `cor:memorysoc` | `supplementary/S1_M4b.tex` (regenerated, causal timing) | partially: r_n only shown bounded, its size observed (Rem `rem:res:residual`); clip handled by a projection argument (Sec. 5.4) |
| 6 | For lambda > 0, bias/noise/mismatch/residuals give practical exponential convergence with explicit ultimate gains | Thm `thm:robust` | `supplementary/S1_M4a.tex` | supported (continuous time only) |
| 7 | Continuous-time gains do not certify the implemented recursion | Cor `cor:memorysoc`(v) | `supplementary/S1_M4b.tex` | supported |
| 8 | Frozen gains satisfy (DC) at sigma = 0 at every T; certificate not binding at the tuned optimum | Sec. 5.4 "Observer hyper-parameters"; Tables `tab:hyper`, `tab:ablation` | `results/gain_design.json`: `post_certificates[TFO/FOO, L=400]` (`dc_sigma0.lp_margin` 1.353e-3 / 1.710e-3 / 5.657e-3; `lmi_fixed_sigma0.status` optimal, `max_eig` -2.24e-3 / -2.66e-3 / -8.40e-3; `envelope_sensitivity.certified` true; `certified_on_clip_range` true); `reports/tuning_findings.md` decision 5 | supported (floating point; no exact-arithmetic check) |

## I. Identified parameters and data analyses

| # | Claim | Evidence (manuscript) | Evidence (files) | Status |
|---|---|---|---|---|
| 9 | Relaxation tails do not support a tempered law as a physical law (TPL preferred by BIC in 50/104 rests; window-dependent rate; synthetic untempered rests show the same cut-off) | Sec. `sec:relax`; Tables `tab:relax_params`, `tab:relax_design`; Fig. `fig:relax` | `reports/relaxation_findings.md` verdicts 1, 2, 5; `results/relaxation_phenomenological.json`, `results/relaxation_mechanistic.json` | supported (negative) |
| 10 | lambda not identifiable from dynamic data (lambda = 0 rejected by 6/10 tests at 0 C only, 0/10 at 25 and 45 C) | Sec. `sec:dynident`; Table `tab:params` | `reports/identification_findings.md` section 8; `results/identification.json` | supported (negative; abstract corrected, it previously limited the statement to 25/45 C) |
| 11 | TFO, FO and 2RC practically equivalent in open-loop voltage accuracy (median test RMSE 42.5 / 42.5 / 42.9 mV) | Table `tab:vmodel`; Fig. `fig:vmodel` | `reports/identification_findings.md` section 7 | supported |
| 12 | Identified R0 is not the ohmic resistance (R_edge 1.7-1.8 x R0; 0.89-0.97 x R(1 s)) | Sec. `sec:dynident` | `reports/identification_refined_findings.md` section 1 | supported |
| 13 | TRF and CMA-ES best from all starts; TFGD slower and less converged | Fig. `fig:optimizers` | `reports/identification_findings.md` section 3 | supported |
| 14 | kappa1 0.229-0.259 V, kappa2 1.193-1.695 V per unit SOC (aligned OCV, reference SOC [0.10, 0.95]) | Table `tab:hyper`; Sec. `sec:ocv` (corrected: the envelope bounds are a sensitivity check only) | `results/frozen_config.json` `methods.TFO.per_T.*.kappa1/kappa2`; `reports/tuning_findings.md` section 1 | supported (modelling assumption) |

## P. Observed performance

| # | Claim | Evidence (manuscript) | Evidence (files) | Status |
|---|---|---|---|---|
| 15 | At 400 s no gain from tempering (TFO 1.375 %, FOO 1.368 %); the three Kalman filters more accurate (0.899-1.236 %) | Table `tab:soc_results`; Fig. `fig:soc`; Sec. `sec:mainresults` | `reports/validation_main_findings.md` key findings 1, 3, 4; `results/validation_main.json` | supported (negative for TFO) |
| 16 | Tempering lowers the error only at long/full memory (median 0.049 % SOC, 17/18 records; re-identified full-memory model 1.477 %, frozen FOO at full memory 1.497 %) | Table `tab:ablation`; Fig. `fig:rmse_memory` | `reports/ablation_findings.md` (Answer in brief, row "full"); `results/ablation.json` | supported |
| 17 | TFO no run above 3 %; removes +-0.20 initial errors; slow first entry (median 238 s) | Fig. `fig:envelopes`; Sec. `sec:mainresults` | `reports/validation_main_findings.md` key findings 1, 7 | supported |
| 18 | Bounded SOC shift under current bias matching the implemented steady state (observed/predicted 0.95; 0.76 with the continuous value) | Table `tab:robustness`; Fig. `fig:robustness`; Rem `rem:res:residual` | `reports/robustness_findings.md` key finding 4, section (b) | supported |
| 19 | TFO more sensitive to model mismatch (3.63 % vs 2.13-3.03 %) | Table `tab:robustness` | `reports/robustness_findings.md` key findings 3, 6 | supported (negative; sensitivity analysis) |
| 20 | CC with nominal z0 better than TFO on 14/18; tuned EKF-2RC worse than untuned textbook EKF-2RC (0.765 vs 1.019 %) | Table `tab:soc_results`; Sec. `sec:mainresults` | `reports/validation_main_findings.md` key findings 2, 4 | supported (textbook EKF-2RC post hoc) |
| 21 | All settings frozen before any closed-loop run on the 18 test records | Sec. `sec:protocol` | `reports/validation_main_findings.md` header and section 6 (disclosure) | partially: open-loop voltage checks and Q_ref used test records before the freeze (abstract and contribution 4 corrected) |

## E. Engineering interpretation

| # | Claim | Evidence (manuscript) | Evidence (files) | Status |
|---|---|---|---|---|
| 22 | Tempering shortens the certified horizon (0.5 % SOC) from 10^30-10^38 s to 187-26809 s; at the selected lambda 47-67 x the 400 s budget (447-644 kB) | Cor `cor:memorysoc`; Sec. 5.4; Table `tab:cost` | `reports/tuning_findings.md` section 2; `reports/cost_findings.md` section 5; `results/gain_design.json` `memory_requirement` | supported (wording "makes the horizon finite" removed: the untempered horizon is finite too) |
| 23 | L = 400 s is not memory-certified (bound 49.0 / 48.5 / 15.5 % SOC) | Sec. 5.4 | `reports/tuning_findings.md` section 2, decision 6 | supported (negative) |
| 24 | Same per-sample operation count and storage for TFO and FOO, about half those of FOEKF (CPU-time ratio about 0.73) | Table `tab:cost`; Fig. `fig:cost` | `reports/cost_findings.md` conclusions 1-2, section 3; `results/cost.json` | supported (contribution 5 corrected from "per-sample cost") |
| 25 | lambda acts as a memory regularisation, not a material rate | Sec. `sec:discussion` | items 9, 10, 16 | partially (interpretation of negative results) |
| 26 | Earlier wording: certified memory "of implementable size", "can be stored", tempering "makes the horizon finite" | Sec. `sec:cost`; Cor `cor:memorysoc`(iii) | `reports/cost_findings.md` conclusion 4 | not supported: removed; BMS real-time feasibility and memory fit not demonstrated |
