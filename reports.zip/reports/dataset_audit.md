# Dataset audit: CALCE INR18650-20R (SP20-1/2/3) Arbin exports

Generated 2026-09-27T07:39:20+00:00 by `scripts/01_audit.py` from `data_manifest.json` and `data_processed/*.csv`. Every number below is computed by `src/tfso/data.py`; nothing is copied from documentation.

Source: CALCE Battery Research Group, University of Maryland; INR18650-20R (Samsung), 2000 mAh nominal, samples SP1/SP2/SP3 (Arbin channel exports).

## 1. Channels, units, sign convention, temperature

* Columns (17, identical in all 33 workbooks): `Data_Point`, `Test_Time(s)`, `Date_Time`, `Step_Time(s)`, `Step_Index`, `Cycle_Index`, `Current(A)`, `Voltage(V)`, `Charge_Capacity(Ah)`, `Discharge_Capacity(Ah)`, `Charge_Energy(Wh)`, `Discharge_Energy(Wh)`, `dV/dt(V/s)`, `Internal_Resistance(Ohm)`, `Is_FC_Data`, `AC_Impedance(Ohm)`, `ACI_Phase_Angle(Deg)`.
* Channels used: current `Current(A)` [A], voltage `Voltage(V)` [V], time `Test_Time(s)` [s], wall clock `Date_Time` (1 s resolution), capacity `Charge_Capacity(Ah)` / `Discharge_Capacity(Ah)` [Ah] (cumulative over the test), energy `Charge_Energy(Wh)` / `Discharge_Energy(Wh)` [Wh].
* **Temperature channel: none.** Chamber set point taken from the file name / Info-sheet test name. No temperature channel exists in any export (the Info sheet reports Temp = 0 auxiliary channels).
* Columns that are identically zero in all dynamic and OCV files: `Internal_Resistance(Ohm)`, `Is_FC_Data`, `AC_Impedance(Ohm)`, `ACI_Phase_Angle(Deg)` (`Internal_Resistance(Ohm)` is non-zero only in the three initial-capacity files; see per-file `constant_zero_columns`).
* Sign convention verified numerically in every file: `Current(A) > 0` increases `Charge_Capacity(Ah)`, `Current(A) < 0` increases `Discharge_Capacity(Ah)` (fractions of samples with |I| > 0.05 A obeying this are listed in section 3; all >= 0.998).
* `Test_Time(s)` is the clock used everywhere; `Date_Time` is rounded to 1 s and drifts (section 7).

## 2. Inventory

| id | cell | T (C) | type | profile | start SOC | n rows | dur (h) | t first (s) | t last (s) | n step7 / rest | dt med (s) | net Ah | split | md5 | Info test name |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SP1_IC_OCV_0C | SP20-1 | 0 | incremental_ocv | -- | -- | 157569 | 46.21 | 10.0 | 166380.0 | -- / 143047 | 1.0156 | -1.8056 | ocv_relaxation | b96d54f3... | 02_26_2016_SP20-1_0C_IncrementalOCV |
| SP1_IC_OCV_25C | SP20-1 | 25 | incremental_ocv | -- | -- | 142119 | 41.80 | 10.0 | 150507.8 | -- / 129008 | 1.0156 | -1.9873 | ocv_relaxation | da431ebb... | 12_2_SP20-13_OCV-SOC_PULSE |
| SP1_IC_OCV_45C | SP20-1 | 45 | incremental_ocv | -- | -- | 159107 | 46.58 | 10.0 | 167715.0 | -- / 143167 | 1.0156 | -1.9996 | ocv_relaxation | c5c6d088... | 12_09_2015_SP20_45C_PULSE_OCV |
| SP3_IC_OCV_0C | SP20-3 | 0 | incremental_ocv | -- | -- | 157729 | 46.63 | 10.0 | 167873.0 | -- / 143232 | 1.0155 | -1.7652 | ocv_relaxation | f9c5b917... | 03_09_2016_SP20-3_0C_IncrementalOCV |
| SP3_IC_OCV_25C | SP20-3 | 25 | incremental_ocv | -- | -- | 165694 | 48.41 | 10.0 | 174278.4 | -- / 150402 | 1.0155 | -1.9960 | ocv_relaxation | 5e9f5537... | 12_2_SP20-13_OCV-SOC_PULSE |
| SP3_IC_OCV_45C | SP20-3 | 45 | incremental_ocv | -- | -- | 158247 | 46.33 | 10.0 | 166814.0 | -- / 143150 | 1.0156 | -2.0002 | ocv_relaxation | ef79b80b... | 12_09_2015_SP20_45C_PULSE_OCV |
| SP1_INITCAP | SP20-1 | 25 | initial_capacity | -- | -- | 27602 | 9.31 | 1.0 | 33521.3 | -- / 3922 | 1.0155 | -2.0094 | capacity | 8512e93a... | None |
| SP2_INITCAP | SP20-2 | 25 | initial_capacity | -- | -- | 26322 | 9.05 | 1.0 | 32565.6 | -- / 3922 | 1.0155 | -2.0283 | capacity | e5777abd... | 10_16_2015_SP20_chdchch |
| SP3_INITCAP | SP20-3 | 25 | initial_capacity | -- | -- | 29110 | 9.65 | 1.0 | 34739.4 | -- / 3922 | 1.0155 | -1.9775 | capacity | 0faa14cf... | 10_16_2015_SP20_chdchch |
| SP2_0C_DST_50SOC | SP20-2 | 0 | dynamic | DST | 50 | 8084 | 7.55 | 60.0 | 27224.8 | 5957 / 727 | 1.0155 | -0.8858 | validation | e6839c55... | 02_24_2016_SP20-2_0C_DST_50SOC |
| SP2_0C_DST_80SOC | SP20-2 | 0 | dynamic | DST | 80 | 10311 | 4.77 | 60.0 | 17236.9 | 9527 / 427 | 1.0155 | -1.4215 | identification | a1eac437... | 02_24_2016_SP20-2_0C_DST_80SOC |
| SP2_0C_FUDS_50SOC | SP20-2 | 0 | dynamic | FUDS | 50 | 9057 | 7.77 | 60.0 | 28020.6 | 6961 / 726 | 1.0155 | -0.9900 | test | 69ddf10d... | 02_25_2016_SP20-2_0C_FUDS_50SOC |
| SP2_0C_FUDS_80SOC | SP20-2 | 0 | dynamic | FUDS | 80 | 11614 | 8.00 | 60.0 | 28871.9 | 9707 / 727 | 1.0155 | -1.3915 | test | 6f4f7b06... | 02_25_2016_SP20-2_0C_FUDS_80SOC |
| SP2_0C_US06_50SOC | SP20-2 | 0 | dynamic | US06 | 50 | 8056 | 7.58 | 60.0 | 27359.4 | 5918 / 726 | 1.0156 | -0.9157 | test | b4dd6404... | 02_26_2016_SP20-2_0C_US06_50SOC |
| SP2_0C_US06_80SOC | SP20-2 | 0 | dynamic | US06 | 80 | 11445 | 8.08 | 60.0 | 29165.8 | 9482 / 726 | 1.0155 | -1.4663 | test | 1a800915... | 02_26_2016_SP20-2_0C_US06_80SOC |
| SP2_0C_BJDST_50SOC | SP20-2 | 0 | dynamic | BJDST | 50 | 14564 | 7.66 | 60.0 | 27649.1 | 6018 / 7119 | 1.0156 | -0.9049 | test | 6b3ce63f... | 02_29_2016_SP20-2_0C_BJDST_50SOC |
| SP2_0C_BJDST_80SOC | SP20-2 | 0 | dynamic | BJDST | 80 | 18513 | 8.23 | 60.0 | 29680.5 | 10172 / 7128 | 1.0156 | -1.5094 | test | 7df1e0de... | 02_27_2016_SP20-2_0C_BJDST_80SOC |
| SP2_25C_DST_50SOC | SP20-2 | 25 | dynamic | DST | 50 | 9501 | 9.65 | 60.0 | 34816.1 | 6685 / 1441 | 1.0154 | -1.0025 | validation | 38310731... | 11_05_2015_SP20-2_DST_50SOC |
| SP2_25C_DST_80SOC | SP20-2 | 25 | dynamic | DST | 80 | 12561 | 8.29 | 60.0 | 29914.7 | 10621 / 1441 | 1.0155 | -1.5963 | identification | 85822528... | 11_05_2015_SP20-2_DST_80SOC |
| SP2_25C_FUDS_50SOC | SP20-2 | 25 | dynamic | FUDS | 50 | 9308 | 8.37 | 1005.9 | 31148.1 | 6995 / 1441 | 1.0154 | -1.0043 | test | 507cd735... | 11_09_2015_SP20-2_FUDS_50SOC |
| SP2_25C_FUDS_80SOC | SP20-2 | 25 | dynamic | FUDS | 80 | 13681 | 10.29 | 7200.0 | 44240.7 | 11092 / 1440 | 1.0155 | -1.6002 | test | 66883a54... | 11_06_2015_SP20-2_FUDS_80SOC |
| SP2_25C_US06_50SOC | SP20-2 | 25 | dynamic | US06 | 50 | 8321 | 5.91 | 60.0 | 21319.0 | 6874 / 62 | 1.0030 | -1.0575 | test | 03ac504c... | 11_11_2015_SP20-2_US06_50SOC |
| SP2_25C_US06_80SOC | SP20-2 | 25 | dynamic | US06 | 80 | 11898 | 6.33 | 60.0 | 22863.2 | 10680 / 62 | 1.0154 | -1.6486 | test | d38cb303... | 11_11_2015_SP20-2_US06_80SOC |
| SP2_25C_BJDST_50SOC | SP20-2 | 25 | dynamic | BJDST | 50 | 8385 | 5.94 | 60.0 | 21438.7 | 6940 / 62 | 1.0155 | -1.0419 | test | 0c53e90d... | 11_13_2015_SP20-2_BJDST_50SOC |
| SP2_25C_BJDST_80SOC | SP20-2 | 25 | dynamic | BJDST | 80 | 12437 | 6.51 | 60.0 | 23493.6 | 11205 / 62 | 1.0029 | -1.6537 | test | 6f886ecc... | 11_12_2015_SP20-2_BJDST_80SOC |
| SP2_45C_DST_50SOC | SP20-2 | 45 | dynamic | DST | 50 | 9089 | 7.61 | 60.0 | 27445.9 | 7046 / 1440 | 1.0156 | -1.0613 | validation | 83d668e2... | 12_11_2015_SP20-2_45C_DST_50SOC |
| SP2_45C_DST_80SOC | SP20-2 | 45 | dynamic | DST | 80 | 13621 | 9.55 | 60.0 | 34428.1 | 11304 / 1140 | 1.0155 | -1.6790 | identification | 57a5085f... | 12_11_2015_SP20-2_45C_DST_80SOC |
| SP2_45C_FUDS_50SOC | SP20-2 | 45 | dynamic | FUDS | 50 | 9593 | 7.94 | 60.0 | 28655.1 | 7484 / 727 | 1.0156 | -1.0890 | test | 41d8f9d7... | 12_15_2015_SP20-2_45C_FUDS_50SOC |
| SP2_45C_FUDS_80SOC | SP20-2 | 45 | dynamic | FUDS | 80 | 13520 | 8.51 | 60.0 | 30680.3 | 11626 / 727 | 1.0156 | -1.6814 | test | cfc8f0ef... | 12_15_2015_SP20-2_45C_FUDS_80SOC |
| SP2_45C_US06_50SOC | SP20-2 | 45 | dynamic | US06 | 50 | 9105 | 7.80 | 60.0 | 28138.1 | 6995 / 727 | 1.0156 | -1.0888 | test | 3e2be0f2... | 12_16_2015_SP20-2_45C_US06_50SOC |
| SP2_45C_US06_80SOC | SP20-2 | 45 | dynamic | US06 | 80 | 12786 | 8.29 | 60.0 | 29910.2 | 10884 / 727 | 1.0156 | -1.6807 | test | 882b442c... | 12_16_2015_SP20-2_45C_US06_80SOC |
| SP2_45C_BJDST_50SOC | SP20-2 | 45 | dynamic | BJDST | 50 | 15840 | 7.89 | 60.0 | 28474.9 | 7325 / 7133 | 1.0155 | -1.0860 | test | 21ebc7a0... | 12_17_2015_SP20-2_45C_BJDST_50SOC |
| SP2_45C_BJDST_80SOC | SP20-2 | 45 | dynamic | BJDST | 80 | 19694 | 8.43 | 60.0 | 30411.3 | 11390 / 7134 | 1.0156 | -1.6812 | test | 0c91d079... | 12_17_2015_SP20-2_45C_BJDST_80SOC |

Source workbooks and processed CSVs:

| id | zip | workbook | data sheets | raw rows | dup rows dropped | rows | csv |
|---|---|---|---|---|---|---|---|
| SP1_IC_OCV_0C | SP1_0C_IC_OCV_02_26_2016.zip | 02_26_2016_SP20-1_0C_incrementalOCV.xls | Channel_1-005_1, Channel_1-005_2, Channel_1-005_3 | 157571 | 2 | 157569 | data_processed\02_26_2016_SP20-1_0C_incrementalOCV.csv |
| SP1_IC_OCV_25C | SP1_25C_IC_OCV_12_2_2015.zip | 12_2_2015_Incremental OCV test_SP20-1.xlsx | Channel_1-005_1, Channel_1-005_2, Channel_1-005_3 | 142121 | 2 | 142119 | data_processed\12_2_2015_Incremental_OCV_test_SP20-1.csv |
| SP1_IC_OCV_45C | SP1_45C_IC_OCV_12_09_2015.zip | 12_09_2015_Incremental OCV test_SP20-1.xlsx | Channel_1-005_1, Channel_1-005_2, Channel_1-005_3 | 159109 | 2 | 159107 | data_processed\12_09_2015_Incremental_OCV_test_SP20-1.csv |
| SP3_IC_OCV_0C | SP3_0C_IC_OCV_03_09_2016.zip | 03_09_2016_SP20-3_0C_incrementalOCV.xls | Channel_1-005_1, Channel_1-005_2, Channel_1-005_3 | 157731 | 2 | 157729 | data_processed\03_09_2016_SP20-3_0C_incrementalOCV.csv |
| SP3_IC_OCV_25C | SP3_25C_IC_OCV_12_2_2015.zip | 12_2_2015_Incremental OCV test_SP20-3.xlsx | Channel_1-006_1, Channel_1-006_2, Channel_1-006_3 | 165696 | 2 | 165694 | data_processed\12_2_2015_Incremental_OCV_test_SP20-3.csv |
| SP3_IC_OCV_45C | SP3_45C_IC_OCV_12_09_2015.zip | 12_09_2015_Incremental OCV test_SP20-3.xlsx | Channel_1-006_1, Channel_1-006_2, Channel_1-006_3 | 158249 | 2 | 158247 | data_processed\12_09_2015_Incremental_OCV_test_SP20-3.csv |
| SP1_INITCAP | SP1_Initial capacity_10_16_2015.zip | 10_16_2015_Initial capacity_SP20-1.xlsx | Sheet1, Sheet2, Sheet3 | 27602 | 0 | 27602 | data_processed\10_16_2015_Initial_capacity_SP20-1.csv |
| SP2_INITCAP | SP2_Initial_capacity_10_16_2015.zip | 10_16_2015_Initial capacity_SP20-2.xls | Channel_1-015 | 26322 | 0 | 26322 | data_processed\10_16_2015_Initial_capacity_SP20-2.csv |
| SP3_INITCAP | SP3_Initial capacity_10_16_2015.zip | 10_16_2015_Initial capacity_SP20-3.xls | Channel_1-016 | 29110 | 0 | 29110 | data_processed\10_16_2015_Initial_capacity_SP20-3.csv |
| SP2_0C_DST_50SOC | SP2_0C_DST.zip | 02_24_2016_SP20-2_0C_DST_50SOC.xls | Channel_1-006 | 8084 | 0 | 8084 | data_processed\02_24_2016_SP20-2_0C_DST_50SOC.csv |
| SP2_0C_DST_80SOC | SP2_0C_DST.zip | 02_24_2016_SP20-2_0C_DST_80SOC.xls | Channel_1-006 | 10311 | 0 | 10311 | data_processed\02_24_2016_SP20-2_0C_DST_80SOC.csv |
| SP2_0C_FUDS_50SOC | SP2_0C_FUDS.zip | 02_25_2016_SP20-2_0C_FUDS_50SOC.xls | Channel_1-006 | 9057 | 0 | 9057 | data_processed\02_25_2016_SP20-2_0C_FUDS_50SOC.csv |
| SP2_0C_FUDS_80SOC | SP2_0C_FUDS.zip | 02_25_2016_SP20-2_0C_FUDS_80SOC.xls | Channel_1-006 | 11614 | 0 | 11614 | data_processed\02_25_2016_SP20-2_0C_FUDS_80SOC.csv |
| SP2_0C_US06_50SOC | SP2_0C_US06.zip | 02_26_2016_SP20-2_0C_US06_50SOC.xls | Channel_1-006 | 8056 | 0 | 8056 | data_processed\02_26_2016_SP20-2_0C_US06_50SOC.csv |
| SP2_0C_US06_80SOC | SP2_0C_US06.zip | 02_26_2016_SP20-2_0C_US06_80SOC.xls | Channel_1-006 | 11445 | 0 | 11445 | data_processed\02_26_2016_SP20-2_0C_US06_80SOC.csv |
| SP2_0C_BJDST_50SOC | SP2_0C_BJDST.zip | 02_29_2016_SP20-2_0C_BJDST_50SOC.xls | Channel_1-006 | 14564 | 0 | 14564 | data_processed\02_29_2016_SP20-2_0C_BJDST_50SOC.csv |
| SP2_0C_BJDST_80SOC | SP2_0C_BJDST.zip | 02_27_2016_SP20-2_0C_BJDST_80SOC.xls | Channel_1-006 | 18513 | 0 | 18513 | data_processed\02_27_2016_SP20-2_0C_BJDST_80SOC.csv |
| SP2_25C_DST_50SOC | SP2_25C_DST.zip | 11_05_2015_SP20-2_DST_50SOC.xls | Channel_1-008 | 9501 | 0 | 9501 | data_processed\11_05_2015_SP20-2_DST_50SOC.csv |
| SP2_25C_DST_80SOC | SP2_25C_DST.zip | 11_05_2015_SP20-2_DST_80SOC.xls | Channel_1-008 | 12561 | 0 | 12561 | data_processed\11_05_2015_SP20-2_DST_80SOC.csv |
| SP2_25C_FUDS_50SOC | SP2_25C_FUDS.zip | 11_09_2015_SP20-2_FUDS_50SOC.xls | Channel_1-008 | 9308 | 0 | 9308 | data_processed\11_09_2015_SP20-2_FUDS_50SOC.csv |
| SP2_25C_FUDS_80SOC | SP2_25C_FUDS.zip | 11_06_2015_SP20-2_FUDS_80SOC.xls | Channel_1-008 | 13681 | 0 | 13681 | data_processed\11_06_2015_SP20-2_FUDS_80SOC.csv |
| SP2_25C_US06_50SOC | SP2_25C_US06.zip | 11_11_2015_SP20-2_US06_50SOC.xls | Channel_1-008 | 8321 | 0 | 8321 | data_processed\11_11_2015_SP20-2_US06_50SOC.csv |
| SP2_25C_US06_80SOC | SP2_25C_US06.zip | 11_11_2015_SP20-2_US06_80SOC.xls | Channel_1-008 | 11898 | 0 | 11898 | data_processed\11_11_2015_SP20-2_US06_80SOC.csv |
| SP2_25C_BJDST_50SOC | SP2_25C_BJDST.zip | 11_13_2015_SP20-2_BJDST_50SOC.xls | Channel_1-008 | 8385 | 0 | 8385 | data_processed\11_13_2015_SP20-2_BJDST_50SOC.csv |
| SP2_25C_BJDST_80SOC | SP2_25C_BJDST.zip | 11_12_2015_SP20-2_BJDST_80SOC.xls | Channel_1-008 | 12437 | 0 | 12437 | data_processed\11_12_2015_SP20-2_BJDST_80SOC.csv |
| SP2_45C_DST_50SOC | SP2_45C_DST.zip | 12_11_2015_SP20-2_45C_DST_50SOC.xls | Channel_1-005 | 9089 | 0 | 9089 | data_processed\12_11_2015_SP20-2_45C_DST_50SOC.csv |
| SP2_45C_DST_80SOC | SP2_45C_DST.zip | 12_11_2015_SP20-2_45C_DST_80SOC.xls | Channel_1-005 | 13621 | 0 | 13621 | data_processed\12_11_2015_SP20-2_45C_DST_80SOC.csv |
| SP2_45C_FUDS_50SOC | SP2_45C_FUDS.zip | 12_15_2015_SP20-2_45C_FUDS_50SOC.xls | Channel_1-005 | 9593 | 0 | 9593 | data_processed\12_15_2015_SP20-2_45C_FUDS_50SOC.csv |
| SP2_45C_FUDS_80SOC | SP2_45C_FUDS.zip | 12_15_2015_SP20-2_45C_FUDS_80SOC.xls | Channel_1-005 | 13520 | 0 | 13520 | data_processed\12_15_2015_SP20-2_45C_FUDS_80SOC.csv |
| SP2_45C_US06_50SOC | SP2_45C_US06.zip | 12_16_2015_SP20-2_45C_US06_50SOC.xls | Channel_1-005 | 9105 | 0 | 9105 | data_processed\12_16_2015_SP20-2_45C_US06_50SOC.csv |
| SP2_45C_US06_80SOC | SP2_45C_US06.zip | 12_16_2015_SP20-2_45C_US06_80SOC.xls | Channel_1-005 | 12786 | 0 | 12786 | data_processed\12_16_2015_SP20-2_45C_US06_80SOC.csv |
| SP2_45C_BJDST_50SOC | SP2_45C_BJDST.zip | 12_17_2015_SP20-2_45C_BJDST_50SOC.xls | Channel_1-005 | 15840 | 0 | 15840 | data_processed\12_17_2015_SP20-2_45C_BJDST_50SOC.csv |
| SP2_45C_BJDST_80SOC | SP2_45C_BJDST.zip | 12_17_2015_SP20-2_45C_BJDST_80SOC.xls | Channel_1-005 | 19694 | 0 | 19694 | data_processed\12_17_2015_SP20-2_45C_BJDST_80SOC.csv |

## 3. Verification (all checks passed for all files)

| id | md5 ok | |I| max (A) | V min | V max | t monotone | repeated t | Step_Index set | P(dQc>0 | I>0) | P(dQd>0 | I<0) | NaN |
|---|---|---|---|---|---|---|---|---|---|---|
| SP1_IC_OCV_0C | yes | 1.000 | 2.577 | 4.262 | yes | 0 | [1, 2, 3, 4, 5, 6, 9, 10, 12, 13, 14, 15, 16] | 0.9990 | 0.9991 | 0 |
| SP1_IC_OCV_25C | yes | 1.000 | 2.500 | 4.376 | yes | 0 | [1, 2, 3, 4, 5, 6, 8, 9, 10] | 0.9988 | 0.9986 | 0 |
| SP1_IC_OCV_45C | yes | 1.002 | 3.034 | 4.329 | yes | 0 | [1, 2, 3, 4, 5, 6, 9, 10, 12, 13, 14, 15, 16] | 0.9990 | 0.9987 | 0 |
| SP3_IC_OCV_0C | yes | 1.000 | 2.500 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15, 16] | 0.9990 | 0.9986 | 0 |
| SP3_IC_OCV_25C | yes | 1.001 | 2.500 | 4.273 | yes | 0 | [1, 2, 3, 4, 5, 6, 8, 9, 10, 12, 13, 14, 15, 16] | 0.9988 | 0.9986 | 0 |
| SP3_IC_OCV_45C | yes | 1.001 | 3.198 | 4.252 | yes | 0 | [1, 2, 3, 4, 5, 6, 9, 10, 12, 13, 14, 15, 16] | 0.9987 | 0.9985 | 0 |
| SP1_INITCAP | yes | 1.001 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] | 1.0000 | 0.9999 | 0 |
| SP2_INITCAP | yes | 1.001 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] | 1.0000 | 0.9999 | 0 |
| SP3_INITCAP | yes | 1.001 | 2.500 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] | 1.0000 | 1.0000 | 0 |
| SP2_0C_DST_50SOC | yes | 4.000 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_0C_DST_80SOC | yes | 4.000 | 2.499 | 4.247 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_0C_FUDS_50SOC | yes | 4.000 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_0C_FUDS_80SOC | yes | 4.000 | 2.499 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_0C_US06_50SOC | yes | 3.996 | 2.459 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_0C_US06_80SOC | yes | 3.996 | 2.499 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9997 | 0 |
| SP2_0C_BJDST_50SOC | yes | 1.668 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9992 | 0 |
| SP2_0C_BJDST_80SOC | yes | 1.668 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9999 | 0 |
| SP2_25C_DST_50SOC | yes | 4.000 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_25C_DST_80SOC | yes | 4.002 | 2.403 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9999 | 0 |
| SP2_25C_FUDS_50SOC | yes | 4.001 | 2.499 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_25C_FUDS_80SOC | yes | 4.000 | 2.497 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_25C_US06_50SOC | yes | 3.997 | 2.499 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 0.9995 | 0.9998 | 0 |
| SP2_25C_US06_80SOC | yes | 3.997 | 2.498 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 0.9997 | 0.9999 | 0 |
| SP2_25C_BJDST_50SOC | yes | 1.667 | 2.499 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9990 | 0 |
| SP2_25C_BJDST_80SOC | yes | 1.667 | 2.500 | 4.200 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9991 | 0 |
| SP2_45C_DST_50SOC | yes | 4.000 | 2.500 | 4.346 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_45C_DST_80SOC | yes | 4.000 | 2.496 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9999 | 0 |
| SP2_45C_FUDS_50SOC | yes | 4.000 | 2.499 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9998 | 0 |
| SP2_45C_FUDS_80SOC | yes | 4.000 | 2.498 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 0.9997 | 0.9999 | 0 |
| SP2_45C_US06_50SOC | yes | 3.996 | 2.500 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 0.9995 | 0.9998 | 0 |
| SP2_45C_US06_80SOC | yes | 3.996 | 2.499 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9999 | 0 |
| SP2_45C_BJDST_50SOC | yes | 1.667 | 2.500 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9990 | 0 |
| SP2_45C_BJDST_80SOC | yes | 1.667 | 2.499 | 4.201 | yes | 0 | [1, 2, 3, 4, 5, 6, 7, 8] | 1.0000 | 0.9988 | 0 |

## 4. Measured capacities and reference capacity Q_ref(T)

Method (config `dataset.reference_capacity.method` = `sp2_dynamic_cv_end_to_cutoff_throughput_median`): Q_ref(T) for SP2 = median over the 8 SP2 dynamic files at T of the net charge throughput from the end of the CV step (step 3) to the end of the profile (step 7, 2.5 V cutoff), Arbin Charge_/Discharge_Capacity columns (trapezoidal integration of Current(A) as cross-check); u_Q(T) = half-range over the 8 files; Q_id(T) = throughput of SP2_<T>C_DST_80SOC (the only capacity an estimator may use). Also: 1 A CC discharge capacity to 2.5 V at 25 C of SP1/SP2/SP3 (initial-capacity tests) and total discharged Ah of the incremental-OCV files after the initial full charge.

Initial-capacity tests (25 C, 1 A CC discharge to 2.5 V after CC/CV 4.2 V / 0.02 A):

| cell | id | Q Arbin (Ah) | Q trapz (Ah) | I mean (A) | duration (s) | V end | note |
|---|---|---|---|---|---|---|---|
| SP1 | SP1_INITCAP | 2.0094 | 2.0093 | -1.0001 | 7232 | 2.4999 | -- |
| SP2 | SP2_INITCAP | 2.0283 | 2.0282 | -1.0003 | 7299 | 2.5000 | 208 s pause at 2.557 V; Q before pause 2.0048 Ah |
| SP3 | SP3_INITCAP | 1.9775 | 1.9774 | -1.0002 | 7116 | 2.4999 | -- |

Incremental-OCV tests (total discharged after the initial full charge):

| id | Q total dis. Arbin (Ah) | Q trapz (Ah) | pulses | V end of last pulse | 2.5 V cutoff reached | Q charged after (Ah) |
|---|---|---|---|---|---|---|
| SP1_IC_OCV_0C | 1.8056 | 1.8042 | 10 | 2.5770 | **no** (schedule-limited, lower bound) | 1.7981 |
| SP1_IC_OCV_25C | 1.9873 | 1.9860 | 10 | 2.4999 | yes | 1.6762 |
| SP1_IC_OCV_45C | 1.9996 | 1.9982 | 10 | 3.0339 | **no** (schedule-limited, lower bound) | 2.0148 |
| SP3_IC_OCV_0C | 1.7652 | 1.7638 | 10 | 2.4999 | yes | 1.7884 |
| SP3_IC_OCV_25C | 1.9960 | 1.9946 | 10 | 2.5000 | yes | 1.9718 |
| SP3_IC_OCV_45C | 2.0002 | 1.9988 | 10 | 3.1985 | **no** (schedule-limited, lower bound) | 1.9856 |

SP2 dynamic files: net charge removed from the end of the CV step (last sample of step 3, SOC = 1) to the end of the profile (last sample of step 7, 2.5 V cutoff):

| id | T (C) | profile | start SOC | split | Q Arbin (Ah) | Q trapz (Ah) | Arbin - trapz (mAh) | V end | ends at cutoff |
|---|---|---|---|---|---|---|---|---|---|
| SP2_0C_DST_50SOC | 0 | DST | 50 | validation | 1.7893 | 1.7920 | -2.7 | 2.5000 | yes |
| SP2_0C_DST_80SOC | 0 | DST | 80 | identification | 1.7830 | 1.7874 | -4.4 | 2.4990 | yes |
| SP2_0C_FUDS_50SOC | 0 | FUDS | 50 | test | 1.8934 | 1.8931 | +0.3 | 2.5000 | yes |
| SP2_0C_FUDS_80SOC | 0 | FUDS | 80 | test | 1.7529 | 1.7540 | -1.1 | 2.4995 | yes |
| SP2_0C_US06_50SOC | 0 | US06 | 50 | test | 1.8191 | 1.8197 | -0.5 | 2.4595 | yes |
| SP2_0C_US06_80SOC | 0 | US06 | 80 | test | 1.8278 | 1.8301 | -2.4 | 2.4995 | yes |
| SP2_0C_BJDST_50SOC | 0 | BJDST | 50 | test | 1.8084 | 1.8076 | +0.8 | 2.5000 | yes |
| SP2_0C_BJDST_80SOC | 0 | BJDST | 80 | test | 1.8708 | 1.8702 | +0.6 | 2.5000 | yes |
| SP2_25C_DST_50SOC | 25 | DST | 50 | validation | 2.0027 | 2.0068 | -4.2 | 2.4997 | yes |
| SP2_25C_DST_80SOC | 25 | DST | 80 | identification | 1.9964 | 1.9991 | -2.7 | 2.4034 | yes |
| SP2_25C_FUDS_50SOC | 25 | FUDS | 50 | test | 2.0044 | 2.0054 | -1.0 | 2.4989 | yes |
| SP2_25C_FUDS_80SOC | 25 | FUDS | 80 | test | 2.0002 | 1.9975 | +2.8 | 2.4968 | yes |
| SP2_25C_US06_50SOC | 25 | US06 | 50 | test | 2.0577 | 2.0546 | +3.1 | 2.4987 | yes |
| SP2_25C_US06_80SOC | 25 | US06 | 80 | test | 2.0487 | 2.0534 | -4.7 | 2.4982 | yes |
| SP2_25C_BJDST_50SOC | 25 | BJDST | 50 | test | 2.0422 | 2.0437 | -1.5 | 2.4994 | yes |
| SP2_25C_BJDST_80SOC | 25 | BJDST | 80 | test | 2.0538 | 2.0526 | +1.2 | 2.4999 | yes |
| SP2_45C_DST_50SOC | 45 | DST | 50 | validation | 2.0611 | 2.0626 | -1.4 | 2.4999 | yes |
| SP2_45C_DST_80SOC | 45 | DST | 80 | identification | 2.0790 | 2.0888 | -9.8 | 2.4955 | yes |
| SP2_45C_FUDS_50SOC | 45 | FUDS | 50 | test | 2.0889 | 2.0871 | +1.8 | 2.4988 | yes |
| SP2_45C_FUDS_80SOC | 45 | FUDS | 80 | test | 2.0813 | 2.0790 | +2.3 | 2.4984 | yes |
| SP2_45C_US06_50SOC | 45 | US06 | 50 | test | 2.0887 | 2.0907 | -2.0 | 2.4997 | yes |
| SP2_45C_US06_80SOC | 45 | US06 | 80 | test | 2.0807 | 2.0816 | -1.0 | 2.4993 | yes |
| SP2_45C_BJDST_50SOC | 45 | BJDST | 50 | test | 2.0859 | 2.0865 | -0.6 | 2.4997 | yes |
| SP2_45C_BJDST_80SOC | 45 | BJDST | 80 | test | 2.0811 | 2.0843 | -3.2 | 2.4988 | yes |

Ground-truth reference capacity Q_ref(T) (median, Arbin) with u_Q(T) = half-range, and the identification capacity Q_id(T):

| T (C) | files | Q_ref (Ah) | u_Q (Ah) | range (Ah) | Q_ref trapz (Ah) | max |Arbin-trapz| (%) | identification file | Q_id (Ah) | Q_id/Q_ref - 1 (%) |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 8 | **1.8138** | 0.0702 (3.87 %) | 1.7529 - 1.8934 | 1.8137 | 0.25 | SP2_0C_DST_80SOC | 1.7830 | -1.70 |
| 25 | 8 | **2.0233** | 0.0307 (1.51 %) | 1.9964 - 2.0577 | 2.0253 | 0.23 | SP2_25C_DST_80SOC | 1.9964 | -1.33 |
| 45 | 8 | **2.0812** | 0.0139 (0.67 %) | 2.0611 - 2.0889 | 2.0854 | 0.47 | SP2_45C_DST_80SOC | 2.0790 | -0.11 |

* Q_ref(0 C) = median of 8 Arbin throughputs = mean(1.8084, 1.8191) = 1.8138 Ah; u_Q = (1.8934 - 1.7529)/2 = 0.0702 Ah (3.87 %)
* Q_ref(25 C) = median of 8 Arbin throughputs = mean(2.0044, 2.0422) = 2.0233 Ah; u_Q = (2.0577 - 1.9964)/2 = 0.0307 Ah (1.51 %)
* Q_ref(45 C) = median of 8 Arbin throughputs = mean(2.0811, 2.0813) = 2.0812 Ah; u_Q = (2.0889 - 2.0611)/2 = 0.0139 Ah (0.67 %)

**Leakage statement.** Q_ref(T) is the median over all 8 SP2 dynamic files at T (identification, validation and test) and is used ONLY to define the reference (ground-truth) SOC; it is never passed to any estimator. Estimators may use Q_id(T) (throughput of the identification file SP2_<T>C_DST_80SOC) and nothing derived from validation or test files.

Uncertainty note: u_Q(T) = half-range of the CV-end-to-cutoff throughput over the 8 SP2 dynamic files at T (it contains the rate/profile dependence of the charge extractable before the 2.5 V cutoff and the run-to-run scatter). Reference-SOC band: band(t) = (|q(t)|/Q_ref)(u_Q/Q_ref) + I_off (t - t_anchor)/(3600 Q_ref) with I_off = 5 mA, summed linearly.

Superseded method (`sp2_25C_initial_capacity_scaled_by_sp1_sp3_temperature_ratio`, SUPERSEDED - invalid at 0 C and 45 C (OCV tests did not reach the 2.5 V cutoff); not used anywhere): Q_ref = 1.8183 Ah at 0 C, 2.0283 Ah at 25 C, 2.0368 Ah at 45 C.

* SP2_INITCAP: 1 A discharge interrupted for 208 s (wall clock) at 2.557 V; Q before pause 2.0048 Ah, total 2.0283 Ah
* SP1_IC_OCV_0C: discharge branch ended by the pulse schedule at 2.577 V (2.5 V cutoff not reached): total 1.8056 Ah is a lower bound of the capacity at 0 C
* SP1_IC_OCV_45C: discharge branch ended by the pulse schedule at 3.034 V (2.5 V cutoff not reached): total 1.9996 Ah is a lower bound of the capacity at 45 C
* SP3_IC_OCV_45C: discharge branch ended by the pulse schedule at 3.198 V (2.5 V cutoff not reached): total 2.0002 Ah is a lower bound of the capacity at 45 C

## 5. Dynamic-profile files (SP2): protocol, sampling, reference SOC

Protocol (Step_Index): 1 one rest sample; 2 CC 1 A to 4.2 V (10 s logging); 3 CV 4.2 V to ~0.02 A; 4 rest 2 h (10 s); 5 CC 1 A discharge of (1 - label) x schedule capacity (measured: 0 C: 0.3614 Ah (80 %) / 0.9035 Ah (50 %), 25 C: 0.4001 Ah (80 %) / 1.0002 Ah (50 %), 45 C: 0.3999 Ah (80 %) / 0.9998 Ah (50 %); i.e. the schedules use 2.0 Ah at 25/45 C and 1.8 Ah at 0 C); 6 rest 2 h (10 s); 7 the dynamic profile at ~1 s until 2.5 V; 8 interleaved 360 s / 1372 s logger rows (timestamps coincide with step-7 rows, Current written as 0) which are dropped.

Reference SOC: anchored at SOC = 1 at the last sample of step 3 (end of CV) at the chamber temperature, trapezoidal Coulomb counting of `Current(A)` over `Test_Time(s)` through steps 4-7 (step-8 rows excluded), cross-checked against the Arbin `Charge_/Discharge_Capacity` differences from the same anchor (column `max |dAh|`). Q_ref = Q_ref(T) from section 4 (ground truth only). Uncertainty band: band(t) = (|q(t)|/Q_ref)(u_Q/Q_ref) + I_off (t - t_anchor)/(3600 Q_ref) with u_Q(T) from section 4 and I_off = 5 mA (current-sensor offset), summed linearly.

| id | n step7 | n step8 dropped | profile (s) | dt med | dt min | dt max | dt p5 | dt p95 | I min/max (A) | V start | V end | net Ah | pre-dis. Ah | V rest | Q_ref | SOC start | SOC end | max |dAh| (mAh) | SOC unc. end |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SP2_0C_DST_50SOC | 5957 | 11 | 6006 | 1.0155 | 0.172 | 1.019 | 1.0000 | 1.0157 | -4.000/2.000 | 3.6948 | 2.5000 | -0.8858 | 0.9034 | 3.6948 | 1.8138 | 0.5019 | 0.0121 | 2.95 | 0.0509 |
| SP2_0C_DST_80SOC | 9527 | 25 | 9608 | 1.0155 | 0.125 | 1.018 | 1.0000 | 1.0157 | -4.000/2.000 | 3.9674 | 2.4990 | -1.4215 | 0.3615 | 3.9676 | 1.8138 | 0.8007 | 0.0146 | 4.46 | 0.0498 |
| SP2_0C_FUDS_50SOC | 6961 | 4 | 7029 | 1.0155 | 0.078 | 1.026 | 1.0000 | 1.0157 | -4.000/2.141 | 3.6956 | 2.5000 | -0.9900 | 0.9035 | 3.6956 | 1.8138 | 0.5019 | -0.0435 | 1.90 | 0.0538 |
| SP2_0C_FUDS_80SOC | 9707 | 6 | 9804 | 1.0155 | 0.141 | 1.018 | 1.0000 | 1.0157 | -4.000/2.141 | 3.9661 | 2.4995 | -1.3915 | 0.3614 | 3.9661 | 1.8138 | 0.8007 | 0.0334 | 1.57 | 0.0515 |
| SP2_0C_US06_50SOC | 5918 | 6 | 5977 | 1.0156 | 0.125 | 1.017 | 1.0000 | 1.0157 | -3.996/0.859 | 3.6958 | 2.4595 | -0.9157 | 0.9035 | 3.6958 | 1.8138 | 0.5019 | -0.0032 | 1.42 | 0.0515 |
| SP2_0C_US06_80SOC | 9482 | 11 | 9577 | 1.0155 | 0.094 | 1.018 | 1.0000 | 1.0157 | -3.996/0.859 | 3.9663 | 2.4995 | -1.4663 | 0.3614 | 3.9663 | 1.8138 | 0.8007 | -0.0090 | 2.51 | 0.0530 |
| SP2_0C_BJDST_50SOC | 6018 | 4 | 6084 | 1.0156 | 0.016 | 1.019 | 1.0000 | 1.0157 | -1.668/0.444 | 3.6833 | 2.5000 | -0.9049 | 0.9035 | 3.6963 | 1.8138 | 0.5026 | 0.0034 | 1.57 | 0.0513 |
| SP2_0C_BJDST_80SOC | 10172 | 6 | 10279 | 1.0156 | 0.063 | 1.018 | 1.0000 | 1.0157 | -1.668/0.444 | 3.9543 | 2.5000 | -1.5094 | 0.3615 | 3.9663 | 1.8138 | 0.8014 | -0.0310 | 1.66 | 0.0544 |
| SP2_25C_DST_50SOC | 6685 | 13 | 6740 | 1.0154 | 0.344 | 1.034 | 1.0000 | 1.0157 | -4.000/2.005 | 3.6847 | 2.4997 | -1.0025 | 1.0002 | 3.6845 | 2.0233 | 0.5057 | 0.0083 | 4.48 | 0.0320 |
| SP2_25C_DST_80SOC | 10621 | 24 | 10710 | 1.0155 | 0.156 | 1.032 | 1.0000 | 1.0157 | -4.002/2.001 | 3.9534 | 2.4034 | -1.5963 | 0.4001 | 3.9534 | 2.0233 | 0.8023 | 0.0120 | 2.91 | 0.0332 |
| SP2_25C_FUDS_50SOC | 6995 | 4 | 7061 | 1.0154 | 0.328 | 1.469 | 1.0000 | 1.0158 | -4.001/2.142 | 3.6831 | 2.4989 | -1.0043 | 1.0001 | 3.6831 | 2.0233 | 0.5057 | 0.0089 | 2.97 | 0.0322 |
| SP2_25C_FUDS_80SOC | 11092 | 6 | 11200 | 1.0155 | 0.078 | 1.035 | 1.0000 | 1.0157 | -4.000/2.142 | 3.9537 | 2.4968 | -1.6002 | 0.4001 | 3.9539 | 2.0233 | 0.8023 | 0.0129 | 4.22 | 0.0335 |
| SP2_25C_US06_50SOC | 6874 | 9 | 6897 | 1.0030 | 0.013 | 1.559 | 1.0028 | 1.0103 | -3.997/0.859 | 3.6505 | 2.4987 | -1.0575 | 1.0002 | 3.6496 | 2.0233 | 0.5063 | -0.0154 | 3.76 | 0.0230 |
| SP2_25C_US06_80SOC | 10680 | 14 | 10777 | 1.0154 | 0.062 | 1.032 | 1.0000 | 1.0158 | -3.997/0.859 | 3.9293 | 2.4982 | -1.6486 | 0.4001 | 3.9277 | 2.0233 | 0.8029 | -0.0146 | 5.60 | 0.0242 |
| SP2_25C_BJDST_50SOC | 6940 | 6 | 7008 | 1.0155 | 0.297 | 1.018 | 1.0000 | 1.0157 | -1.667/0.444 | 3.6424 | 2.4994 | -1.0419 | 1.0002 | 3.6494 | 2.0233 | 0.5063 | -0.0101 | 1.57 | 0.0230 |
| SP2_25C_BJDST_80SOC | 11205 | 9 | 11228 | 1.0029 | 0.127 | 1.017 | 1.0029 | 1.0030 | -1.667/0.444 | 3.9207 | 2.4999 | -1.6537 | 0.4001 | 3.9274 | 2.0233 | 0.8029 | -0.0144 | 1.73 | 0.0245 |
| SP2_45C_DST_50SOC | 7046 | 14 | 7107 | 1.0156 | 0.063 | 1.018 | 1.0000 | 1.0157 | -4.000/2.000 | 3.6813 | 2.4999 | -1.0613 | 0.9999 | 3.6821 | 2.0812 | 0.5196 | 0.0091 | 1.90 | 0.0234 |
| SP2_45C_DST_80SOC | 11304 | 21 | 11400 | 1.0155 | 0.031 | 1.616 | 1.0000 | 1.0157 | -4.000/2.000 | 3.9573 | 2.4955 | -1.6790 | 0.4000 | 3.9578 | 2.0812 | 0.8078 | -0.0036 | 10.18 | 0.0229 |
| SP2_45C_FUDS_50SOC | 7484 | 5 | 7562 | 1.0156 | 0.141 | 1.019 | 1.0000 | 1.0157 | -4.000/2.142 | 3.6829 | 2.4988 | -1.0890 | 0.9998 | 3.6834 | 2.0812 | 0.5196 | -0.0027 | 2.82 | 0.0190 |
| SP2_45C_FUDS_80SOC | 11626 | 6 | 11746 | 1.0156 | 0.015 | 1.033 | 1.0000 | 1.0157 | -4.000/2.142 | 3.9597 | 2.4984 | -1.6814 | 0.3999 | 3.9602 | 2.0812 | 0.8078 | 0.0014 | 3.69 | 0.0203 |
| SP2_45C_US06_50SOC | 6995 | 8 | 7065 | 1.0156 | 0.172 | 1.030 | 1.0000 | 1.0157 | -3.996/0.859 | 3.6820 | 2.4997 | -1.0888 | 0.9998 | 3.6823 | 2.0812 | 0.5196 | -0.0045 | 2.17 | 0.0187 |
| SP2_45C_US06_80SOC | 10884 | 16 | 10993 | 1.0156 | 0.047 | 1.031 | 1.0000 | 1.0157 | -3.996/0.859 | 3.9602 | 2.4993 | -1.6807 | 0.3999 | 3.9607 | 2.0812 | 0.8079 | -0.0002 | 2.33 | 0.0198 |
| SP2_45C_BJDST_50SOC | 7325 | 6 | 7397 | 1.0155 | 0.625 | 1.032 | 1.0000 | 1.0157 | -1.667/0.444 | 3.6726 | 2.4997 | -1.0860 | 0.9998 | 3.6813 | 2.0812 | 0.5202 | -0.0025 | 1.42 | 0.0189 |
| SP2_45C_BJDST_80SOC | 11390 | 12 | 11502 | 1.0156 | 0.094 | 1.032 | 1.0000 | 1.0157 | -1.667/0.444 | 3.9516 | 2.4988 | -1.6812 | 0.3999 | 3.9606 | 2.0812 | 0.8084 | -0.0014 | 3.20 | 0.0202 |

Current levels of step 7 (rounded to 0.01 A; levels with >= 0.2 % of samples):

* SP2_0C_DST_50SOC: -0.50 A (2565), -0.00 A (1442), -1.00 A (905), -2.50 A (384), +0.50 A (270), -4.00 A (135), +1.00 A (128), +2.00 A (128)
* SP2_0C_DST_80SOC: -0.50 A (4068), -0.00 A (2320), -1.00 A (1458), -2.50 A (622), +0.50 A (428), -4.00 A (217), +1.00 A (208), +2.00 A (205)
* SP2_0C_FUDS_50SOC: -0.00 A (1726), -0.63 A (108), +0.13 A (102), +0.08 A (101), +0.02 A (77), +0.14 A (77), -0.42 A (76), -4.00 A (71), -0.66 A (64), -0.40 A (57), -0.39 A (54), -0.90 A (49), -0.33 A (47), -1.05 A (45), -1.07 A (44), +0.03 A (43), -0.22 A (42), -0.05 A (40), -1.15 A (39), -0.46 A (37), -1.03 A (36), -0.41 A (36), -1.45 A (35), -0.25 A (35), -0.32 A (34), -1.39 A (34), -0.28 A (34), -0.64 A (31), -0.44 A (31), -0.36 A (30), -1.61 A (30), -0.96 A (29), -1.53 A (28), -0.77 A (27), -1.08 A (27), -0.55 A (26), -1.02 A (26), -0.86 A (26), -0.91 A (26), -0.23 A (26), -1.26 A (26), -1.21 A (26), -2.18 A (26), -0.48 A (26), -0.62 A (25), -1.09 A (25), -0.12 A (25), -1.19 A (25), -1.69 A (25), +0.21 A (25), -0.06 A (25), -0.75 A (25), -0.45 A (25), -0.35 A (24), -0.08 A (24), -1.31 A (24), -0.65 A (24), -0.24 A (23), -0.53 A (23), -0.82 A (23), +0.17 A (22), -1.24 A (22), +0.18 A (22), -0.84 A (22), -1.87 A (21), -0.16 A (21), -0.37 A (21), -0.67 A (21), -0.61 A (21), -2.06 A (21), -0.54 A (21), -0.49 A (20), -1.18 A (20), +0.38 A (20), -0.83 A (20), -0.78 A (20), -1.16 A (20), -0.80 A (20), -0.58 A (20), -0.26 A (20), -0.30 A (20), -2.08 A (20), -1.66 A (20), -1.76 A (20), -1.63 A (20), +0.53 A (20), +0.90 A (20), -1.11 A (19), -0.97 A (19), -1.57 A (18), -0.93 A (18), +0.48 A (17), -1.32 A (17), -0.47 A (16), -1.04 A (16), -0.60 A (16), +0.73 A (16), -2.28 A (16), -0.74 A (16), -0.51 A (16), -1.84 A (16), -1.78 A (16), +0.09 A (16), -1.17 A (16), +1.07 A (16), -1.01 A (15), -0.92 A (15), -0.04 A (15), +0.01 A (15), +0.27 A (15), +1.32 A (15), -2.53 A (15), +0.62 A (15), +0.60 A (15), -1.89 A (15), +0.42 A (15), -2.21 A (15), +0.37 A (15), +1.06 A (15), -1.40 A (15), -1.67 A (15), -1.64 A (15), -1.34 A (15), -1.22 A (15), -0.11 A (15), -0.71 A (15), -0.59 A (15), -0.87 A (15), -1.06 A (15), -0.29 A (15), -0.70 A (15), +1.33 A (14), -0.81 A (14), -1.59 A (14), +0.52 A (14), -2.85 A (14), -1.10 A (14)
* SP2_0C_FUDS_80SOC: -0.00 A (2386), -0.63 A (151), +0.13 A (141), +0.08 A (140), -0.42 A (112), -4.00 A (109), +0.02 A (108), +0.14 A (105), -0.66 A (90), -0.39 A (78), -0.40 A (74), -0.90 A (74), -1.05 A (64), -0.33 A (64), +0.03 A (64), -1.07 A (62), -0.22 A (58), -1.15 A (57), -0.05 A (55), -1.45 A (50), -0.41 A (49), -0.28 A (49), -0.32 A (49), -1.03 A (48), -0.46 A (48), -0.25 A (47), -1.39 A (44), -0.96 A (43), -1.61 A (42), -0.64 A (42), -0.44 A (40), -0.36 A (40), -1.08 A (38), -1.02 A (38), -0.91 A (37), -0.06 A (37), -1.53 A (37), -0.86 A (36), -1.21 A (36), -0.77 A (36), -0.62 A (36), -0.55 A (36), -1.19 A (35), -0.45 A (35), -0.65 A (35), -0.75 A (35), -0.23 A (35), -2.18 A (35), -0.48 A (35), -1.69 A (34), -0.82 A (34), -1.09 A (34), -0.08 A (34), -0.12 A (34), -0.24 A (34), -0.35 A (34), -1.26 A (34), +0.21 A (34), -1.31 A (34), -0.53 A (31), +0.18 A (31), -0.54 A (30), -1.87 A (30), -0.67 A (30), -1.66 A (29), +0.17 A (29), -0.37 A (29), -0.16 A (29), -1.11 A (29), -0.80 A (29), -0.97 A (29), -2.06 A (29), -0.30 A (28), -0.26 A (28), +0.38 A (28), -1.63 A (28), -2.08 A (28), -0.84 A (28), -0.78 A (28), -0.61 A (28), -1.24 A (28), -1.76 A (28), +0.53 A (28), +0.48 A (27), -0.83 A (27), +0.90 A (27), -0.58 A (27), -0.49 A (27), -1.18 A (27), -1.16 A (26), -0.93 A (24), +1.06 A (23), -0.74 A (23), -2.28 A (22), +0.27 A (22), -1.32 A (22), -1.22 A (22), -1.84 A (22), -1.78 A (22), +0.42 A (22), -0.81 A (22), -1.06 A (22), -0.47 A (22), +0.73 A (22), -1.04 A (22), -1.01 A (22), -1.17 A (22), +0.09 A (22), -1.57 A (21), -1.64 A (21), +0.37 A (21), -1.67 A (21), -0.60 A (21), -0.59 A (21), -0.04 A (21), -1.10 A (21), -0.51 A (21), -0.71 A (21), -0.92 A (21), -0.87 A (21), -1.59 A (21), -2.21 A (21), +1.33 A (21), +1.32 A (21), +1.07 A (21), -2.53 A (21), -1.40 A (21), -1.34 A (21), -2.85 A (21), -0.29 A (21), +0.01 A (20), -0.11 A (20), -0.70 A (20), +0.62 A (20), +0.52 A (20), -1.89 A (20)
* SP2_0C_US06_50SOC: -0.00 A (535), -0.48 A (100), -0.01 A (86), -0.86 A (80), +0.04 A (78), -0.75 A (78), -0.11 A (73), +0.21 A (63), -0.87 A (61), +0.29 A (60), -0.85 A (60), -0.49 A (59), -0.41 A (59), -0.67 A (58), +0.01 A (58), +0.05 A (57), +0.38 A (51), -0.71 A (50), +0.07 A (49), -0.29 A (49), -0.20 A (49), +0.09 A (49), -0.61 A (49), -1.22 A (48), +0.35 A (48), +0.17 A (43), -0.59 A (41), -1.33 A (40), -0.35 A (40), -0.72 A (40), -0.92 A (40), -0.15 A (40), -0.58 A (39), +0.16 A (39), +0.14 A (39), -1.69 A (39), -0.97 A (39), +0.18 A (39), +0.50 A (39), +0.61 A (38), +0.42 A (38), -0.88 A (38), -1.09 A (38), -1.01 A (37), -0.30 A (36), -0.45 A (32), +0.02 A (32), -0.31 A (31), -1.02 A (31), -0.77 A (31), -0.76 A (31), -0.51 A (31), +0.30 A (31), +0.31 A (31), -0.25 A (31), -1.58 A (30), -1.35 A (30), -1.26 A (30), -0.90 A (30), -0.83 A (30), -0.96 A (30), -1.08 A (30), -1.45 A (30), -1.52 A (30), -0.22 A (30), +0.08 A (30), -0.56 A (30), -0.19 A (30), -0.84 A (30), -0.74 A (30), -1.05 A (30), -0.43 A (30), -1.20 A (30), -0.79 A (29), -1.07 A (29), -0.93 A (29), -0.24 A (29), -0.14 A (29), -0.05 A (29), +0.56 A (29), +0.37 A (29), -0.10 A (29), +0.03 A (28), -1.10 A (28), -0.39 A (28), +0.15 A (28), +0.19 A (25), -0.02 A (22), -2.12 A (21), +0.54 A (21), -0.17 A (21), -0.40 A (21), -0.69 A (21), -0.68 A (21), +0.11 A (20), +0.10 A (20), -0.32 A (20), -0.33 A (20), -0.12 A (20), -0.42 A (20), -0.57 A (20), -0.60 A (20), -0.36 A (20), -2.20 A (20), -1.73 A (20), -1.71 A (20), -1.75 A (20), -1.42 A (20), -1.43 A (20), -1.25 A (20), -1.91 A (20), -1.50 A (20), -0.78 A (20), -0.63 A (20), -0.65 A (20), -0.81 A (20), -1.29 A (20), -0.95 A (20), -1.30 A (20), +0.41 A (20), +0.32 A (20), +0.26 A (20), -0.09 A (20), -0.03 A (20), +0.59 A (20), -1.65 A (19), -2.08 A (19), -0.70 A (19), +0.23 A (19), +0.71 A (19), +0.25 A (18), +0.46 A (18), -2.43 A (18), -1.47 A (18), +0.39 A (18), -0.47 A (18), -0.99 A (17), -1.56 A (13), -1.11 A (12)
* SP2_0C_US06_80SOC: -0.00 A (859), -0.48 A (156), -0.01 A (139), -0.86 A (130), +0.04 A (126), -0.75 A (126), -0.11 A (110), -0.87 A (106), +0.21 A (102), -0.49 A (97), -0.41 A (96), +0.29 A (96), +0.05 A (95), -0.85 A (94), -0.67 A (94), +0.01 A (93), +0.38 A (82), -0.29 A (81), -0.71 A (80), -0.61 A (79), +0.09 A (79), -0.20 A (79), -1.22 A (78), +0.07 A (78), +0.35 A (77), +0.17 A (71), -1.69 A (66), -0.92 A (65), +0.50 A (64), -0.97 A (64), -1.33 A (64), -0.72 A (64), -0.35 A (64), +0.14 A (64), +0.16 A (64), -0.15 A (64), +0.18 A (64), -0.58 A (63), +0.42 A (62), +0.61 A (62), -1.01 A (62), -0.88 A (62), -0.59 A (61), -0.30 A (59), -1.09 A (59), -0.84 A (53), -1.08 A (52), +0.02 A (49), -0.56 A (49), -1.02 A (49), -0.79 A (49), -1.20 A (49), +0.15 A (49), -1.05 A (48), -0.96 A (48), -0.74 A (48), -0.10 A (48), -0.19 A (48), +0.08 A (48), +0.30 A (48), -0.25 A (48), -0.24 A (48), -0.45 A (48), -0.39 A (48), -0.77 A (47), -0.93 A (47), -1.07 A (47), -0.05 A (47), -0.43 A (47), -0.31 A (47), -0.14 A (47), -1.45 A (47), -1.35 A (47), -1.10 A (47), -1.26 A (47), +0.03 A (46), -0.76 A (46), -0.51 A (46), +0.56 A (46), +0.31 A (46), -0.22 A (46), +0.37 A (46), -1.52 A (46), -0.90 A (46), -1.58 A (45), +0.19 A (40), -0.83 A (38), -2.12 A (34), -0.78 A (33), +0.10 A (33), -0.42 A (33), -0.02 A (33), -1.29 A (33), -2.43 A (33), -1.47 A (33), -0.69 A (33), -0.32 A (32), -0.17 A (32), -0.03 A (32), -0.40 A (32), -0.60 A (32), -0.47 A (32), -0.36 A (32), -0.33 A (32), -0.12 A (32), -1.73 A (32), -1.71 A (32), -1.91 A (32), -1.50 A (32), -1.43 A (32), -1.75 A (32), -2.20 A (32), -1.25 A (32), -0.65 A (32), -0.63 A (32), -0.68 A (32), -0.81 A (32), +0.54 A (32), +0.26 A (32), +0.41 A (32), +0.23 A (32), +0.59 A (32), +0.32 A (31), -0.09 A (31), -2.08 A (31), -1.30 A (31), -0.95 A (31), -0.70 A (31), +0.11 A (31), -0.57 A (30), -1.65 A (30), -1.42 A (30), +0.25 A (29), +0.46 A (29), +0.39 A (28), -0.99 A (27), +0.71 A (26)
* SP2_0C_BJDST_50SOC: -0.17 A (945), -1.11 A (760), -0.06 A (690), -0.22 A (664), -0.67 A (438), -0.83 A (425), -1.00 A (415), -1.39 A (304), -0.28 A (263), -1.67 A (232), -0.11 A (167), +0.22 A (165), -0.08 A (153), -0.56 A (70), +0.39 A (70), -1.33 A (70), -0.33 A (68), +0.44 A (60), +0.11 A (59)
* SP2_0C_BJDST_80SOC: -0.17 A (1708), -1.11 A (1268), -0.22 A (1148), -0.06 A (1108), -0.67 A (732), -0.83 A (719), -1.00 A (675), -1.39 A (495), -0.28 A (433), -1.67 A (387), -0.11 A (294), +0.22 A (273), -0.08 A (264), -1.33 A (116), -0.56 A (116), -0.33 A (110), +0.11 A (110), +0.44 A (109), +0.39 A (105)
* SP2_25C_DST_50SOC: -0.50 A (2857), -0.00 A (1621), -1.00 A (1023), -2.50 A (443), +0.50 A (304), -4.00 A (151), +1.00 A (144), +2.00 A (140)
* SP2_25C_DST_80SOC: -0.50 A (4522), -0.00 A (2578), -1.00 A (1619), -2.50 A (717), +0.50 A (480), -4.00 A (240), +1.00 A (232), +2.00 A (232)
* SP2_25C_FUDS_50SOC: -0.00 A (1727), -0.63 A (107), +0.08 A (103), +0.13 A (102), -4.00 A (81), +0.14 A (76), -0.42 A (68), -0.66 A (66), -0.40 A (53), -0.90 A (52), +0.02 A (51), -0.38 A (50), -0.33 A (46), +0.03 A (45), -1.05 A (45), -1.07 A (45), -0.22 A (42), -1.15 A (42), -0.05 A (40), +0.01 A (39), -0.46 A (37), -1.45 A (36), -0.28 A (36), -0.32 A (35), -0.25 A (35), -1.03 A (33), -0.41 A (32), -1.39 A (31), -0.44 A (30), -0.96 A (30), -0.64 A (30), -0.36 A (29), -1.21 A (28), -0.91 A (27), -0.62 A (27), -1.08 A (27), -1.18 A (27), -1.53 A (26), -1.26 A (26), -1.02 A (26), -2.18 A (26), -0.86 A (26), -0.82 A (26), -0.06 A (26), -0.77 A (26), -0.55 A (26), -0.23 A (26), -0.78 A (25), -1.09 A (25), -1.61 A (25), -0.75 A (25), +0.21 A (25), -0.12 A (25), -0.65 A (25), -0.35 A (25), -0.45 A (25), -0.08 A (25), -0.24 A (24), -1.69 A (24), -1.31 A (24), -0.53 A (23), -0.48 A (23), +0.18 A (22), -0.37 A (21), -0.39 A (21), -0.16 A (21), -1.24 A (21), -1.57 A (21), -1.87 A (21), -0.84 A (21), -0.67 A (21), -0.61 A (21), +0.17 A (20), +0.53 A (20), +0.38 A (20), +0.90 A (20), +0.48 A (20), -0.26 A (20), -2.08 A (20), -2.06 A (20), -0.97 A (20), -1.76 A (20), -1.66 A (20), -1.63 A (20), -0.83 A (20), -1.11 A (20), -0.30 A (19), -0.58 A (19), -1.16 A (19), -0.49 A (19), -0.54 A (19), -0.93 A (18), -0.74 A (17), -1.19 A (17), -1.17 A (17), +0.73 A (16), +1.32 A (16), +1.07 A (16), -1.32 A (16), -2.53 A (16), +0.42 A (16), -1.06 A (16), -1.20 A (16), +0.09 A (16), -1.04 A (16), -0.60 A (16), -0.51 A (16), -0.47 A (16), -2.28 A (16), -1.78 A (16), -1.84 A (16), +0.62 A (15), -1.10 A (15), -1.01 A (15), -1.67 A (15), +0.60 A (15), -1.64 A (15), -0.29 A (15), -0.11 A (15), +0.27 A (15), -0.92 A (15), +0.80 A (15), -1.60 A (15), +1.06 A (15), -1.40 A (15), -1.34 A (15), +1.33 A (15), -0.87 A (15), -0.70 A (15), -1.89 A (15), -2.21 A (15), -0.71 A (14), -0.79 A (14), +0.37 A (14), +0.52 A (14), -0.04 A (14), -0.59 A (14), -0.81 A (14)
* SP2_25C_FUDS_80SOC: -0.00 A (2728), -0.63 A (174), +0.08 A (160), +0.13 A (158), -4.00 A (124), +0.14 A (120), -0.42 A (110), -0.66 A (106), -0.90 A (82), +0.02 A (82), -0.40 A (80), -0.38 A (78), +0.03 A (76), -0.33 A (75), -1.05 A (73), -1.07 A (72), -1.15 A (65), -0.22 A (63), +0.01 A (63), -0.05 A (62), -1.03 A (59), -0.46 A (57), -1.45 A (57), -0.32 A (56), -0.28 A (56), -0.25 A (55), -0.41 A (51), -0.64 A (50), -1.39 A (50), -0.36 A (48), -0.96 A (48), -0.44 A (47), -1.21 A (46), -1.18 A (45), -0.23 A (42), -0.91 A (42), -2.18 A (42), -1.53 A (42), -1.31 A (41), -0.06 A (41), -0.86 A (41), -0.62 A (41), -0.39 A (41), -1.26 A (40), -0.55 A (40), -0.08 A (40), -0.45 A (40), -1.61 A (40), -1.02 A (40), -0.77 A (40), -1.09 A (40), -1.08 A (40), -0.12 A (39), -0.78 A (39), -0.75 A (39), -0.82 A (39), -1.69 A (39), -0.65 A (39), +0.21 A (39), -0.35 A (38), -0.24 A (37), -0.48 A (36), -0.53 A (35), -1.87 A (34), +0.18 A (34), -1.16 A (33), -0.16 A (33), +0.17 A (33), -1.63 A (33), -1.57 A (33), -0.61 A (33), -0.54 A (33), -0.26 A (32), -1.76 A (32), -0.49 A (32), -1.11 A (32), +0.38 A (32), -0.97 A (32), -0.84 A (32), -0.83 A (32), -0.67 A (32), -1.66 A (32), -0.58 A (32), -0.37 A (32), -2.08 A (32), +0.53 A (32), +0.90 A (32), -2.06 A (31), -0.30 A (31), +0.48 A (31), -1.24 A (30), -0.93 A (27), -1.19 A (26), -0.74 A (26), +0.42 A (25), +0.27 A (25), -1.32 A (25), -1.84 A (25), -1.78 A (25), -0.11 A (25), +1.07 A (25), +0.09 A (25), -0.47 A (25), -1.17 A (25), +0.73 A (25), -1.04 A (25), -1.06 A (25), -2.28 A (25), -0.60 A (25), -1.01 A (24), -0.70 A (24), -0.87 A (24), -1.60 A (24), -1.67 A (24), -0.59 A (24), -2.21 A (24), -0.92 A (24), -0.79 A (24), -0.51 A (24), -1.34 A (24), +1.33 A (24), -2.53 A (24), +1.32 A (24), -0.04 A (24), +0.52 A (24), +0.62 A (24), -1.89 A (24), +0.60 A (23), -1.40 A (23), -1.64 A (23), +0.37 A (23), +1.06 A (23), -0.81 A (23), -1.10 A (23), -0.29 A (23)
* SP2_25C_US06_50SOC: -0.00 A (625), -0.48 A (115), +0.04 A (99), -0.01 A (99), -0.86 A (98), -0.75 A (90), -0.85 A (79), +0.21 A (79), -0.11 A (78), -0.41 A (75), +0.09 A (71), -0.67 A (71), +0.01 A (70), -0.49 A (69), +0.29 A (69), -0.29 A (68), -0.71 A (60), -0.20 A (60), -0.87 A (59), +0.07 A (58), +0.38 A (57), +0.35 A (57), +0.05 A (56), -0.61 A (56), -1.22 A (52), -1.08 A (47), -0.72 A (47), -0.97 A (46), +0.18 A (46), +0.50 A (46), -1.33 A (46), +0.17 A (46), +0.14 A (46), -0.59 A (46), +0.42 A (45), -0.88 A (45), -1.01 A (45), -0.58 A (45), -0.15 A (44), +0.61 A (44), -1.69 A (44), -0.35 A (43), -0.92 A (43), +0.16 A (42), -0.25 A (38), +0.31 A (36), -0.77 A (36), -0.83 A (36), -0.51 A (35), -1.52 A (35), -1.02 A (35), -0.93 A (35), -0.96 A (35), +0.37 A (35), +0.02 A (35), -0.22 A (35), +0.15 A (35), +0.03 A (35), -0.05 A (35), -1.26 A (34), -1.20 A (34), -0.90 A (34), -0.76 A (34), -0.74 A (34), +0.30 A (34), -0.43 A (34), -1.07 A (34), -1.09 A (34), -0.31 A (34), -0.30 A (34), -0.19 A (34), -0.56 A (34), -0.79 A (34), -1.05 A (33), -0.10 A (33), -0.45 A (33), -1.45 A (33), -0.84 A (33), -1.10 A (32), -1.58 A (32), -0.39 A (32), -0.24 A (31), +0.19 A (31), -0.40 A (30), -1.35 A (28), -2.12 A (25), -1.73 A (25), -1.25 A (24), +0.26 A (24), -0.60 A (24), -0.36 A (24), -0.32 A (24), -0.12 A (24), -0.13 A (24), -1.42 A (24), -2.43 A (24), -1.29 A (24), -0.81 A (24), -0.69 A (24), +0.54 A (23), -0.03 A (23), -0.09 A (23), +0.08 A (23), +0.10 A (23), -0.02 A (23), +0.23 A (23), +0.41 A (23), -1.65 A (23), -1.30 A (23), -1.43 A (23), -2.08 A (23), -1.56 A (23), -0.99 A (23), -0.70 A (23), -0.78 A (23), -0.68 A (23), +0.59 A (23), +0.32 A (23), +0.56 A (23), -1.47 A (22), -1.50 A (22), -2.20 A (22), -0.63 A (22), -0.17 A (22), -0.47 A (22), -1.91 A (22), -0.95 A (22), -0.65 A (22), +0.25 A (22), +0.11 A (22), -0.57 A (22), +0.46 A (22), -1.75 A (21), -1.83 A (21), -0.33 A (21), -1.27 A (21), +0.39 A (21), -0.42 A (20), -1.34 A (19), -1.71 A (15), -1.70 A (15), -2.05 A (14)
* SP2_25C_US06_80SOC: -0.00 A (957), -0.48 A (180), -0.86 A (159), -0.01 A (155), +0.04 A (155), -0.75 A (143), -0.85 A (126), -0.11 A (125), +0.21 A (123), -0.41 A (113), +0.01 A (108), -0.67 A (108), -0.29 A (107), -0.49 A (106), +0.09 A (104), +0.29 A (102), -0.87 A (93), +0.38 A (93), -0.71 A (92), -0.20 A (90), +0.05 A (90), +0.07 A (89), -0.61 A (89), +0.35 A (88), -1.22 A (84), -0.88 A (73), +0.18 A (73), -1.69 A (72), -1.08 A (72), -0.72 A (72), -1.33 A (72), -1.01 A (72), -0.35 A (72), -0.58 A (72), -0.15 A (72), +0.14 A (72), +0.16 A (71), +0.17 A (71), -0.97 A (71), +0.42 A (70), -0.59 A (69), +0.50 A (69), +0.61 A (68), -0.92 A (65), -0.25 A (62), -1.09 A (55), -0.22 A (55), -1.58 A (55), -1.02 A (55), -0.84 A (55), -0.93 A (55), -0.10 A (54), +0.02 A (54), -0.76 A (54), -1.52 A (54), -0.96 A (54), -1.20 A (54), -0.74 A (54), -0.79 A (54), -1.26 A (54), -0.45 A (54), -0.31 A (54), -0.56 A (54), -0.51 A (54), -0.05 A (54), -0.19 A (54), +0.37 A (53), +0.31 A (53), -1.07 A (53), -0.30 A (53), +0.03 A (53), +0.15 A (53), -0.90 A (52), -0.83 A (52), -1.10 A (52), -1.45 A (52), +0.30 A (51), -1.05 A (51), -0.77 A (51), -0.43 A (50), -1.35 A (49), -0.40 A (48), -0.24 A (46), +0.19 A (45), -0.39 A (42), +0.08 A (39), -1.91 A (37), -0.95 A (37), +0.41 A (37), -0.02 A (37), -0.99 A (37), +0.25 A (36), +0.11 A (36), -0.12 A (36), -0.13 A (36), -0.36 A (36), +0.59 A (36), +0.54 A (36), -0.03 A (36), -0.17 A (36), -0.47 A (36), -0.60 A (36), -0.32 A (36), -2.43 A (36), -1.43 A (36), -1.73 A (36), -1.75 A (36), -1.42 A (36), -0.70 A (36), -0.65 A (36), -2.08 A (36), -1.56 A (36), -1.30 A (36), -1.29 A (36), -0.78 A (36), -0.69 A (36), -1.27 A (36), -2.12 A (35), -0.81 A (35), -2.20 A (35), -1.65 A (35), +0.23 A (35), +0.56 A (35), +0.26 A (35), +0.32 A (35), +0.46 A (35), +0.10 A (35), -0.09 A (35), -0.63 A (34), -0.57 A (34), +0.39 A (33), -1.50 A (33), -1.25 A (33), -1.47 A (33), -1.71 A (33), -0.68 A (33), -0.33 A (32), -1.83 A (29), -0.42 A (29), -1.34 A (24), -1.70 A (22)
* SP2_25C_BJDST_50SOC: -0.17 A (1094), -1.11 A (875), -0.06 A (784), -0.22 A (767), -0.67 A (509), -0.83 A (488), -1.00 A (479), -1.39 A (354), -0.28 A (310), -1.67 A (272), -0.11 A (193), +0.22 A (189), -0.08 A (176), -0.33 A (80), +0.39 A (79), -0.56 A (78), -1.33 A (76), +0.44 A (69), +0.11 A (68)
* SP2_25C_BJDST_80SOC: -0.17 A (1884), -1.11 A (1418), -0.22 A (1260), -0.06 A (1230), -0.67 A (803), -0.83 A (790), -1.00 A (732), -1.39 A (550), -0.28 A (475), -1.67 A (425), -0.11 A (325), +0.22 A (300), -0.08 A (286), -0.56 A (130), -1.33 A (130), +0.11 A (120), +0.39 A (120), +0.44 A (114), -0.33 A (113)
* SP2_45C_DST_50SOC: -0.50 A (3019), -0.00 A (1705), -1.00 A (1071), -2.50 A (472), +0.50 A (316), -4.00 A (160), +2.00 A (152), +1.00 A (151)
* SP2_45C_DST_80SOC: -0.50 A (4827), -0.00 A (2758), -1.00 A (1739), -2.50 A (741), +0.50 A (505), -4.00 A (249), +2.00 A (244), +1.00 A (241)
* SP2_45C_FUDS_50SOC: -0.00 A (1844), -0.63 A (119), +0.08 A (104), +0.13 A (103), -4.00 A (87), +0.14 A (77), +0.02 A (77), -0.66 A (76), -0.42 A (74), -0.90 A (53), -1.05 A (51), -0.33 A (48), +0.03 A (47), -1.07 A (46), -0.22 A (46), -0.39 A (43), -0.40 A (43), -0.38 A (43), -1.15 A (42), -1.03 A (42), -0.41 A (41), -0.05 A (41), -0.32 A (40), -0.46 A (39), -1.45 A (39), -0.25 A (38), -0.28 A (34), -1.39 A (33), -1.18 A (33), -0.64 A (33), -0.96 A (31), -1.61 A (30), -0.44 A (30), -0.78 A (30), -0.36 A (30), -1.53 A (29), -0.62 A (29), -1.08 A (28), -1.02 A (28), -0.24 A (28), -1.26 A (28), -0.75 A (28), -0.45 A (27), -0.12 A (27), -0.82 A (27), -1.69 A (27), -1.31 A (27), -2.18 A (26), +0.21 A (26), -1.21 A (26), -0.06 A (26), -0.08 A (26), -0.91 A (26), -0.86 A (26), -0.55 A (26), -1.09 A (26), -0.35 A (25), -0.65 A (25), -0.23 A (25), -1.76 A (24), -0.53 A (24), -0.48 A (24), -1.63 A (24), +0.18 A (23), -0.80 A (23), -1.87 A (23), -1.16 A (23), -0.54 A (22), -0.67 A (22), -0.77 A (22), -2.06 A (22), +0.90 A (22), +0.38 A (22), -1.57 A (22), -1.24 A (22), +0.17 A (22), -2.08 A (22), +0.48 A (22), -0.84 A (22), -1.11 A (22), +0.53 A (22), -0.83 A (21), -0.37 A (21), -0.61 A (21), -0.58 A (21), -1.66 A (21), -0.49 A (20), -0.97 A (20), -0.30 A (20), -0.26 A (20), -0.16 A (20), -0.93 A (19), +1.07 A (18), -1.17 A (18), -0.70 A (18), -0.87 A (18), -1.84 A (18), -2.28 A (18), +1.33 A (18), -1.40 A (18), -0.47 A (17), +0.01 A (17), -1.34 A (17), -1.60 A (17), +0.80 A (17), +0.60 A (17), -1.89 A (17), +0.62 A (17), -1.06 A (17), -1.10 A (17), -1.67 A (16), -1.78 A (16), -2.53 A (16), +0.52 A (16), -2.21 A (16), +0.73 A (16), +0.41 A (16), +1.06 A (16), +0.37 A (16), +0.09 A (16), -1.32 A (16), -0.74 A (16), -1.19 A (16), -0.60 A (16), -0.92 A (16), -1.04 A (16), -1.64 A (16), +1.32 A (16), -0.11 A (16), -2.85 A (16), -0.71 A (16), -0.29 A (15), -1.01 A (15), -0.04 A (15), -1.22 A (15), -0.51 A (15), -0.59 A (15)
* SP2_45C_FUDS_80SOC: -0.00 A (2858), -0.63 A (182), +0.08 A (166), +0.13 A (163), -4.00 A (130), +0.14 A (125), +0.02 A (124), -0.42 A (121), -0.66 A (111), -0.90 A (83), -1.05 A (77), -1.07 A (76), -0.33 A (75), +0.03 A (74), -0.22 A (70), -0.40 A (70), -0.05 A (68), -1.15 A (67), -0.39 A (65), -0.38 A (64), -0.32 A (62), -1.03 A (61), -0.46 A (60), -1.45 A (58), -0.25 A (58), -0.41 A (57), -0.28 A (56), -0.64 A (52), -0.78 A (51), -1.39 A (51), -1.18 A (51), -0.96 A (49), -0.36 A (48), -0.44 A (47), -1.61 A (46), -2.18 A (46), -1.02 A (44), -1.69 A (44), -1.53 A (44), -0.62 A (44), -0.75 A (43), -1.08 A (43), -0.82 A (43), -1.26 A (43), -1.21 A (43), -0.45 A (43), -0.24 A (43), -0.12 A (43), -0.86 A (42), +0.21 A (42), -0.65 A (42), -0.06 A (42), -1.31 A (42), -1.09 A (41), -0.91 A (41), -0.23 A (41), -0.08 A (40), -0.48 A (40), -0.55 A (40), -0.35 A (40), -0.53 A (36), -1.63 A (36), -1.16 A (35), +0.18 A (35), -1.87 A (35), -0.37 A (35), -0.83 A (34), -2.08 A (34), +0.90 A (34), -1.24 A (34), +0.38 A (34), -1.76 A (34), -1.11 A (34), -0.54 A (34), +0.53 A (33), -0.61 A (33), -0.16 A (33), -0.58 A (33), -0.80 A (33), -0.84 A (33), -2.06 A (33), -0.67 A (32), +0.48 A (32), -1.57 A (32), +0.17 A (32), -0.30 A (32), -0.49 A (32), -0.26 A (32), -1.66 A (32), -0.77 A (30), -0.97 A (30), -0.87 A (27), -0.70 A (27), -0.93 A (27), -1.89 A (27), +1.33 A (27), -1.19 A (27), -2.28 A (27), -1.84 A (27), -1.40 A (27), -0.47 A (27), +0.41 A (26), -1.67 A (26), -1.34 A (26), +0.62 A (26), +0.60 A (26), +0.52 A (26), +1.07 A (26), -2.85 A (26), +0.09 A (26), +0.01 A (26), +0.80 A (26), -1.10 A (26), -1.06 A (26), +1.32 A (25), -2.53 A (25), -0.74 A (25), -0.71 A (25), -0.60 A (25), -0.51 A (25), -1.04 A (25), -0.92 A (25), -2.21 A (25), -1.17 A (25), -1.78 A (25), -1.64 A (25), -1.32 A (25), +0.37 A (25), -0.11 A (25), +0.27 A (24), -1.60 A (24), -1.22 A (24), -0.29 A (24), -1.01 A (24), -0.59 A (24), -0.04 A (24), +0.73 A (24)
* SP2_45C_US06_50SOC: +0.00 A (616), -0.48 A (119), -0.01 A (103), -0.86 A (95), -0.75 A (94), +0.04 A (91), -0.85 A (84), -0.11 A (83), +0.21 A (79), -0.41 A (74), -0.67 A (72), -0.49 A (71), -0.87 A (71), +0.09 A (71), -0.29 A (71), +0.01 A (70), +0.05 A (69), +0.29 A (68), -0.71 A (60), +0.07 A (58), -0.61 A (58), -0.20 A (58), +0.38 A (57), +0.35 A (56), -1.22 A (49), -1.08 A (48), -0.35 A (48), -1.01 A (48), +0.18 A (48), +0.50 A (47), -1.33 A (47), -0.72 A (47), -0.59 A (47), -0.58 A (47), +0.14 A (47), +0.16 A (46), -1.69 A (46), -0.96 A (46), -0.88 A (46), +0.61 A (46), -0.15 A (45), +0.17 A (44), +0.42 A (43), -0.05 A (37), -0.97 A (37), -0.45 A (36), -0.19 A (36), -0.56 A (36), -1.26 A (36), -1.45 A (36), -0.74 A (36), -1.07 A (36), -0.90 A (36), -0.92 A (36), -0.84 A (36), -0.43 A (36), -0.25 A (36), -0.10 A (36), -0.79 A (35), -1.09 A (35), -0.76 A (35), -0.83 A (35), -0.93 A (35), -1.58 A (35), +0.02 A (35), -1.02 A (35), -0.31 A (35), +0.31 A (35), -1.10 A (35), -0.77 A (34), -1.20 A (34), +0.15 A (34), +0.30 A (34), +0.37 A (34), -0.24 A (34), -0.22 A (34), -0.30 A (34), -0.51 A (34), +0.03 A (34), -1.52 A (34), -1.05 A (33), +0.19 A (32), -0.39 A (31), -1.35 A (28), -0.40 A (28), -0.13 A (26), -0.02 A (25), +0.26 A (25), -0.17 A (24), +0.08 A (24), +0.59 A (24), +0.41 A (24), -0.57 A (24), -0.60 A (24), -0.36 A (24), -0.47 A (24), -1.42 A (24), -0.68 A (24), -0.32 A (24), -0.12 A (24), -2.12 A (24), -2.08 A (24), -2.20 A (24), -1.50 A (24), -0.69 A (24), -0.65 A (24), -0.78 A (24), -0.81 A (24), -0.99 A (24), -1.27 A (24), -0.03 A (23), -0.33 A (23), -0.70 A (23), -1.75 A (23), -1.91 A (23), -1.73 A (23), -1.30 A (23), -1.29 A (23), -1.25 A (23), -0.63 A (23), -1.83 A (23), -1.47 A (23), -1.65 A (23), -1.43 A (23), +0.39 A (23), +0.54 A (23), +0.23 A (23), +0.32 A (23), +0.10 A (23), -0.09 A (23), -1.56 A (22), -1.71 A (22), -0.95 A (22), -2.43 A (22), +0.56 A (22), +0.46 A (22), -0.42 A (22), +0.11 A (22), +0.25 A (20), -1.34 A (19)
* SP2_45C_US06_80SOC: -0.00 A (992), -0.48 A (178), -0.01 A (160), +0.04 A (146), -0.86 A (142), -0.75 A (141), +0.21 A (128), -0.11 A (125), -0.85 A (124), -0.41 A (114), +0.01 A (110), +0.09 A (110), +0.05 A (109), -0.67 A (108), +0.29 A (107), -0.87 A (106), -0.49 A (106), -0.29 A (106), +0.07 A (93), -0.20 A (93), +0.38 A (91), -0.61 A (90), -0.71 A (90), +0.35 A (89), +0.14 A (75), +0.18 A (74), -0.58 A (74), -1.33 A (74), -1.22 A (73), -0.59 A (73), +0.61 A (73), +0.50 A (73), +0.17 A (72), -0.35 A (72), -1.08 A (72), -1.01 A (72), -0.72 A (72), -0.88 A (72), +0.42 A (72), +0.16 A (71), -1.69 A (71), -0.15 A (68), -0.96 A (63), -0.97 A (60), +0.31 A (57), -0.05 A (56), -0.25 A (56), -0.51 A (56), +0.30 A (56), -1.26 A (56), -0.90 A (56), -1.58 A (55), -1.20 A (55), -1.10 A (55), -1.07 A (55), -0.92 A (55), -0.93 A (55), +0.37 A (55), -0.10 A (55), -0.56 A (55), -0.19 A (55), -0.24 A (55), +0.02 A (55), +0.03 A (55), -0.31 A (54), -0.76 A (54), -1.45 A (54), -1.52 A (54), -0.43 A (54), -0.45 A (54), -0.30 A (54), +0.15 A (54), -1.09 A (54), -0.74 A (54), -0.83 A (54), -1.05 A (54), -0.77 A (53), -0.84 A (52), -0.22 A (52), -1.02 A (51), +0.19 A (51), -0.79 A (51), -0.39 A (48), -0.40 A (39), -0.13 A (39), -2.43 A (38), -1.29 A (38), -2.12 A (38), -0.36 A (38), -0.02 A (38), +0.26 A (38), +0.59 A (37), +0.41 A (37), +0.32 A (37), +0.23 A (37), -0.47 A (37), -1.42 A (37), -1.73 A (37), -1.83 A (37), -1.43 A (37), -1.30 A (37), -0.69 A (37), -0.12 A (37), -2.20 A (37), -0.17 A (36), -0.32 A (36), -0.09 A (36), +0.08 A (36), -0.57 A (36), -0.33 A (36), -1.50 A (36), -2.08 A (36), -0.65 A (36), -0.70 A (36), -0.68 A (36), -0.99 A (36), -1.25 A (36), -1.27 A (36), -0.95 A (36), -0.60 A (36), -0.63 A (36), -1.35 A (36), -1.56 A (36), -0.81 A (36), +0.39 A (36), +0.56 A (36), +0.54 A (36), +0.25 A (36), +0.46 A (36), -1.34 A (35), -1.65 A (35), -1.75 A (35), -1.91 A (35), +0.10 A (35), -0.03 A (34), +0.11 A (34), -1.47 A (34), -0.78 A (34), -1.71 A (33), -0.42 A (31), +0.71 A (23), -1.70 A (22), -1.48 A (22)
* SP2_45C_BJDST_50SOC: -0.17 A (1236), -1.11 A (916), -0.22 A (826), -0.06 A (784), -0.83 A (532), -0.67 A (525), -1.00 A (500), -1.39 A (357), -0.28 A (318), -1.67 A (275), -0.11 A (208), +0.22 A (198), -0.08 A (176), -0.33 A (80), +0.11 A (80), +0.39 A (80), +0.44 A (80), -0.56 A (78), -1.33 A (75)
* SP2_45C_BJDST_80SOC: -0.17 A (1867), -1.11 A (1433), -0.22 A (1282), -0.06 A (1274), -0.67 A (831), -0.83 A (796), -1.00 A (780), -1.39 A (544), -0.28 A (500), -1.67 A (420), -0.11 A (319), +0.22 A (311), -0.08 A (286), -0.33 A (130), +0.39 A (130), -1.33 A (128), -0.56 A (121), +0.11 A (119), +0.44 A (119)

## 6. Incremental-OCV files (SP1, SP3): protocol, pulses, relaxations

Protocol observed: cycle 1 step 1 = 6 rest samples (10 s); step 2 = CC 1 A (1-4 samples: the cell was already near 4.2 V); step 3 = CV 4.2 V to 0.1 A (10 s logging); step 4 = rest 2 h (10 s). Then [step 5: 1 A discharge pulse; step 6: rest 2 h at ~1 s] x 10 (the rest after a pulse terminated by the 2.5 V cutoff is numbered 8); then [step 9: 1 A charge pulse (time-limited); step 10: rest 2 h] x 8-9; then step 12/14 CC to 4.2 V, 13 rest 2 h, 15 CV to 0.1 A, 16 rest 2 h. SOC labels use the file's own total discharged capacity (section 4).

| id | V first | n step2 | CV Ah | CV end I (A) | dis. pulses | median dis. pulse Ah | ch. pulses | median ch. pulse Ah | Q total dis. (Ah) | V end last dis. | 2.5 V reached | last cycle/step | Step_Index set |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SP1_IC_OCV_0C | 4.1638 | 1 | 0.0212 | 0.100 | 10 | 0.1806 | 9 | 0.1805 | 1.8056 | 2.5770 | **no** | 19/16 (rest) | [1, 2, 3, 4, 5, 6, 9, 10, 12, 13, 14, 15, 16] |
| SP1_IC_OCV_25C | 4.1662 | 1 | 0.0161 | 0.100 | 10 | 0.2000 | 8 | 0.1999 | 1.9873 | 2.4999 | yes | 18/9 (charge) | [1, 2, 3, 4, 5, 6, 8, 9, 10] |
| SP1_IC_OCV_45C | 4.1737 | 1 | 0.0140 | 0.100 | 10 | 0.2000 | 9 | 0.1999 | 1.9996 | 3.0339 | **no** | 19/16 (rest) | [1, 2, 3, 4, 5, 6, 9, 10, 12, 13, 14, 15, 16] |
| SP3_IC_OCV_0C | 4.0523 | 4 | 0.1697 | 0.100 | 10 | 0.1831 | 9 | 0.1830 | 1.7652 | 2.4999 | yes | 18/16 (rest) | [1, 2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15, 16] |
| SP3_IC_OCV_25C | 4.1717 | 1 | 0.0184 | 0.100 | 10 | 0.2000 | 10 | 0.2000 | 1.9960 | 2.5000 | yes | 19/16 (rest) | [1, 2, 3, 4, 5, 6, 8, 9, 10, 12, 13, 14, 15, 16] |
| SP3_IC_OCV_45C | 4.1792 | 1 | 0.0151 | 0.100 | 10 | 0.2000 | 9 | 0.2000 | 2.0002 | 3.1985 | **no** | 19/16 (rest) | [1, 2, 3, 4, 5, 6, 9, 10, 12, 13, 14, 15, 16] |

Relaxed voltages at the end of each long rest (own-capacity SOC):

**SP1_IC_OCV_0C** (Q_total = 1.8056 Ah)

| cycle | step | branch | rest (s) | net dis. Ah | SOC | V first | V 1 h | V end | dV rest (mV) | dV last 10 min (mV) |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 4 | full_after_cv | 7190 | -0.0000 | 1.0000 | 4.1878 | 4.1791 | 4.1777 | -10.0 | +0.00 |
| 1 | 6 | discharge | 7199 | 0.1806 | 0.9000 | 4.0090 | 4.0554 | 4.0565 | +47.5 | -0.14 |
| 2 | 6 | discharge | 7199 | 0.3611 | 0.8000 | 3.8949 | 3.9525 | 3.9537 | +58.8 | +0.00 |
| 3 | 6 | discharge | 7199 | 0.5416 | 0.7000 | 3.7918 | 3.8597 | 3.8614 | +69.5 | +0.16 |
| 4 | 6 | discharge | 7199 | 0.7222 | 0.6000 | 3.7027 | 3.7735 | 3.7778 | +75.0 | +0.50 |
| 5 | 6 | discharge | 7199 | 0.9028 | 0.5000 | 3.6322 | 3.6844 | 3.6878 | +55.6 | +0.07 |
| 6 | 6 | discharge | 7199 | 1.0833 | 0.4000 | 3.5872 | 3.6343 | 3.6356 | +48.5 | -0.32 |
| 7 | 6 | discharge | 7199 | 1.2639 | 0.3000 | 3.5504 | 3.6056 | 3.6077 | +57.4 | +0.27 |
| 8 | 6 | discharge | 7199 | 1.4444 | 0.2000 | 3.5091 | 3.5808 | 3.5836 | +74.5 | +0.32 |
| 9 | 6 | discharge | 7199 | 1.6250 | 0.1000 | 3.4408 | 3.5284 | 3.5309 | +90.1 | +0.16 |
| 10 | 6 | discharge | 7199 | 1.8056 | 0.0000 | 2.8302 | 3.4535 | 3.4561 | +625.9 | +0.29 |
| 11 | 10 | charge | 7199 | 1.6251 | 0.0999 | 3.5877 | 3.5403 | 3.5402 | -47.5 | +0.00 |
| 12 | 10 | charge | 7199 | 1.4446 | 0.1999 | 3.6400 | 3.5980 | 3.5966 | -43.4 | -0.16 |
| 13 | 10 | charge | 7199 | 1.2642 | 0.2998 | 3.6654 | 3.6222 | 3.6207 | -44.7 | -0.13 |
| 14 | 10 | charge | 7199 | 1.0837 | 0.3998 | 3.7076 | 3.6497 | 3.6483 | -59.3 | -0.42 |
| 15 | 10 | charge | 7199 | 0.9032 | 0.4998 | 3.7615 | 3.6956 | 3.6927 | -68.9 | -0.32 |
| 16 | 10 | charge | 7199 | 0.7228 | 0.5997 | 3.8293 | 3.7879 | 3.7865 | -42.8 | -0.07 |
| 17 | 10 | charge | 7199 | 0.5423 | 0.6997 | 3.9174 | 3.8711 | 3.8695 | -48.0 | -0.19 |
| 18 | 10 | charge | 7199 | 0.3618 | 0.7996 | 4.0278 | 3.9624 | 3.9604 | -67.4 | -0.32 |
| 19 | 13 | charge | 7199 | 0.2672 | 0.8520 | 4.0832 | 4.0134 | 4.0111 | -72.1 | -0.24 |
| 19 | 16 | full_after_cv | 7199 | 0.0075 | 0.9958 | 4.1892 | 4.1671 | 4.1636 | -25.6 | -0.49 |

**SP1_IC_OCV_25C** (Q_total = 1.9873 Ah)

| cycle | step | branch | rest (s) | net dis. Ah | SOC | V first | V 1 h | V end | dV rest (mV) | dV last 10 min (mV) |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 4 | full_after_cv | 7190 | 0.0000 | 1.0000 | 4.1805 | 4.1764 | 4.1758 | -4.7 | +0.00 |
| 1 | 6 | discharge | 7199 | 0.2000 | 0.8994 | 4.0275 | 4.0495 | 4.0502 | +22.7 | +0.09 |
| 2 | 6 | discharge | 7199 | 0.3999 | 0.7988 | 3.9110 | 3.9392 | 3.9400 | +29.0 | +0.00 |
| 3 | 6 | discharge | 7199 | 0.5999 | 0.6982 | 3.8004 | 3.8387 | 3.8400 | +39.5 | +0.32 |
| 4 | 6 | discharge | 7199 | 0.7998 | 0.5975 | 3.7017 | 3.7523 | 3.7536 | +51.9 | +0.16 |
| 5 | 6 | discharge | 7199 | 0.9998 | 0.4969 | 3.6394 | 3.6640 | 3.6648 | +25.4 | +0.16 |
| 6 | 6 | discharge | 7199 | 1.1998 | 0.3963 | 3.5996 | 3.6249 | 3.6261 | +26.4 | +0.34 |
| 7 | 6 | discharge | 7199 | 1.3997 | 0.2957 | 3.5646 | 3.5983 | 3.5995 | +34.8 | +0.00 |
| 8 | 6 | discharge | 7199 | 1.5997 | 0.1950 | 3.5197 | 3.5543 | 3.5556 | +35.8 | +0.00 |
| 9 | 6 | discharge | 7199 | 1.7997 | 0.0944 | 3.4368 | 3.4659 | 3.4677 | +31.0 | +0.27 |
| 10 | 8 | discharge | 7199 | 1.9873 | 0.0000 | 2.8169 | 3.2489 | 3.2642 | +447.3 | +2.09 |
| 10 | 10 | charge | 7199 | 1.7874 | 0.1006 | 3.5149 | 3.4826 | 3.4828 | -32.1 | +0.16 |
| 11 | 10 | charge | 7199 | 1.5875 | 0.2012 | 3.5993 | 3.5774 | 3.5770 | -22.4 | +0.01 |
| 12 | 10 | charge | 7199 | 1.3876 | 0.3018 | 3.6343 | 3.6112 | 3.6107 | -23.7 | +0.05 |
| 13 | 10 | charge | 7199 | 1.1877 | 0.4024 | 3.6656 | 3.6378 | 3.6369 | -28.7 | -0.16 |
| 14 | 10 | charge | 7199 | 0.9878 | 0.5030 | 3.7128 | 3.6746 | 3.6737 | -39.1 | +0.00 |
| 15 | 10 | charge | 7199 | 0.7879 | 0.6036 | 3.7857 | 3.7638 | 3.7630 | -22.7 | +0.16 |
| 16 | 10 | charge | 7199 | 0.5879 | 0.7042 | 3.8750 | 3.8498 | 3.8487 | -26.3 | -0.14 |
| 17 | 10 | charge | 7199 | 0.3880 | 0.8047 | 3.9802 | 3.9484 | 3.9471 | -33.1 | -0.16 |

**SP1_IC_OCV_45C** (Q_total = 1.9996 Ah)

| cycle | step | branch | rest (s) | net dis. Ah | SOC | V first | V 1 h | V end | dV rest (mV) | dV last 10 min (mV) |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 4 | full_after_cv | 7190 | 0.0000 | 1.0000 | 4.1852 | 4.1828 | 4.1821 | -3.1 | +0.00 |
| 1 | 6 | discharge | 7199 | 0.2000 | 0.9000 | 4.0447 | 4.0581 | 4.0584 | +13.8 | +0.26 |
| 2 | 6 | discharge | 7199 | 0.3999 | 0.8000 | 3.9312 | 3.9478 | 3.9484 | +17.2 | +0.16 |
| 3 | 6 | discharge | 7199 | 0.5999 | 0.7000 | 3.8260 | 3.8475 | 3.8481 | +22.0 | +0.05 |
| 4 | 6 | discharge | 7199 | 0.7998 | 0.6000 | 3.7262 | 3.7598 | 3.7601 | +33.9 | +0.02 |
| 5 | 6 | discharge | 7199 | 0.9998 | 0.5000 | 3.6557 | 3.6711 | 3.6716 | +15.9 | +0.16 |
| 6 | 6 | discharge | 7199 | 1.1998 | 0.4000 | 3.6149 | 3.6324 | 3.6327 | +17.8 | -0.02 |
| 7 | 6 | discharge | 7199 | 1.3997 | 0.3000 | 3.5807 | 3.6050 | 3.6056 | +25.0 | +0.11 |
| 8 | 6 | discharge | 7199 | 1.5997 | 0.2000 | 3.5360 | 3.5541 | 3.5551 | +19.1 | +0.11 |
| 9 | 6 | discharge | 7199 | 1.7996 | 0.1000 | 3.4540 | 3.4702 | 3.4718 | +17.8 | +0.32 |
| 10 | 6 | discharge | 7199 | 1.9996 | 0.0000 | 3.2039 | 3.2616 | 3.2771 | +73.3 | +2.18 |
| 11 | 10 | charge | 7199 | 1.7997 | 0.1000 | 3.5018 | 3.4839 | 3.4836 | -18.2 | -0.10 |
| 12 | 10 | charge | 7199 | 1.5998 | 0.2000 | 3.5904 | 3.5763 | 3.5757 | -14.7 | -0.11 |
| 13 | 10 | charge | 7199 | 1.3998 | 0.2999 | 3.6301 | 3.6144 | 3.6139 | -16.2 | +0.07 |
| 14 | 10 | charge | 7199 | 1.1999 | 0.3999 | 3.6601 | 3.6415 | 3.6408 | -19.3 | -0.16 |
| 15 | 10 | charge | 7199 | 1.0000 | 0.4999 | 3.7026 | 3.6791 | 3.6786 | -24.0 | -0.16 |
| 16 | 10 | charge | 7199 | 0.8001 | 0.5999 | 3.7784 | 3.7640 | 3.7633 | -15.1 | +0.00 |
| 17 | 10 | charge | 7199 | 0.6002 | 0.6998 | 3.8667 | 3.8498 | 3.8491 | -17.7 | +0.10 |
| 18 | 10 | charge | 7199 | 0.4003 | 0.7998 | 3.9688 | 3.9482 | 3.9474 | -21.4 | -0.32 |
| 19 | 13 | charge | 7199 | 0.2673 | 0.8663 | 4.0414 | 4.0182 | 4.0171 | -24.3 | -0.16 |
| 19 | 16 | full_after_cv | 7199 | -0.0152 | 1.0076 | 4.1855 | 4.1780 | 4.1766 | -8.9 | -0.15 |

**SP3_IC_OCV_0C** (Q_total = 1.7652 Ah)

| cycle | step | branch | rest (s) | net dis. Ah | SOC | V first | V 1 h | V end | dV rest (mV) | dV last 10 min (mV) |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 4 | full_after_cv | 7190 | -0.0000 | 1.0000 | 4.1887 | 4.1666 | 4.1635 | -25.3 | -0.32 |
| 1 | 6 | discharge | 7199 | 0.1831 | 0.8963 | 3.9933 | 4.0395 | 4.0405 | +47.2 | +0.04 |
| 2 | 6 | discharge | 7199 | 0.3661 | 0.7926 | 3.8706 | 3.9358 | 3.9374 | +66.8 | +0.23 |
| 3 | 6 | discharge | 7199 | 0.5492 | 0.6889 | 3.7682 | 3.8423 | 3.8440 | +75.8 | +0.32 |
| 4 | 6 | discharge | 7199 | 0.7323 | 0.5852 | 3.6821 | 3.7520 | 3.7590 | +76.8 | +0.46 |
| 5 | 6 | discharge | 7199 | 0.9153 | 0.4814 | 3.6206 | 3.6689 | 3.6710 | +50.4 | +0.32 |
| 6 | 6 | discharge | 7199 | 1.0984 | 0.3777 | 3.5789 | 3.6263 | 3.6282 | +49.3 | +0.32 |
| 7 | 6 | discharge | 7199 | 1.2815 | 0.2740 | 3.5350 | 3.5987 | 3.6009 | +66.0 | +0.16 |
| 8 | 6 | discharge | 7199 | 1.4646 | 0.1703 | 3.4828 | 3.5702 | 3.5742 | +91.4 | +0.32 |
| 9 | 6 | discharge | 7199 | 1.6476 | 0.0666 | 3.3533 | 3.4930 | 3.4954 | +142.1 | +0.20 |
| 10 | 8 | discharge | 7199 | 1.7652 | 0.0000 | 2.7534 | 3.4532 | 3.4556 | +702.2 | +0.45 |
| 10 | 10 | charge | 7199 | 1.5822 | 0.1037 | 3.5954 | 3.5418 | 3.5413 | -54.1 | -0.16 |
| 11 | 10 | charge | 7199 | 1.3992 | 0.2073 | 3.6423 | 3.5995 | 3.5980 | -44.2 | -0.32 |
| 12 | 10 | charge | 7199 | 1.2163 | 0.3110 | 3.6735 | 3.6243 | 3.6230 | -50.6 | -0.46 |
| 13 | 10 | charge | 7199 | 1.0333 | 0.4146 | 3.7165 | 3.6539 | 3.6526 | -63.9 | -0.16 |
| 14 | 10 | charge | 7199 | 0.8503 | 0.5183 | 3.7708 | 3.7065 | 3.7026 | -68.2 | -0.16 |
| 15 | 10 | charge | 7199 | 0.6673 | 0.6220 | 3.8408 | 3.7995 | 3.7975 | -43.3 | -0.16 |
| 16 | 10 | charge | 7199 | 0.4843 | 0.7256 | 3.9375 | 3.8861 | 3.8842 | -53.3 | -0.23 |
| 17 | 10 | charge | 7199 | 0.3014 | 0.8293 | 4.0477 | 3.9796 | 3.9777 | -70.0 | -0.23 |
| 18 | 13 | charge | 7199 | 0.1997 | 0.8869 | 4.1006 | 4.0359 | 4.0333 | -67.3 | -0.27 |
| 18 | 16 | full_after_cv | 7199 | -0.0232 | 1.0132 | 4.1907 | 4.1688 | 4.1654 | -25.3 | -0.32 |

**SP3_IC_OCV_25C** (Q_total = 1.9960 Ah)

| cycle | step | branch | rest (s) | net dis. Ah | SOC | V first | V 1 h | V end | dV rest (mV) | dV last 10 min (mV) |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 4 | full_after_cv | 7190 | 0.0000 | 1.0000 | 4.1889 | 4.1844 | 4.1835 | -5.3 | -0.16 |
| 1 | 6 | discharge | 7199 | 0.2000 | 0.8998 | 4.0337 | 4.0570 | 4.0580 | +24.3 | +0.32 |
| 2 | 6 | discharge | 7199 | 0.4000 | 0.7996 | 3.9158 | 3.9464 | 3.9475 | +31.8 | +0.05 |
| 3 | 6 | discharge | 7199 | 0.6001 | 0.6994 | 3.8038 | 3.8461 | 3.8471 | +43.3 | +0.10 |
| 4 | 6 | discharge | 7199 | 0.8001 | 0.5991 | 3.7063 | 3.7577 | 3.7591 | +52.8 | +0.00 |
| 5 | 6 | discharge | 7199 | 1.0001 | 0.4989 | 3.6425 | 3.6695 | 3.6710 | +28.5 | +0.15 |
| 6 | 6 | discharge | 7199 | 1.2001 | 0.3987 | 3.6012 | 3.6275 | 3.6287 | +27.5 | +0.19 |
| 7 | 6 | discharge | 7199 | 1.4002 | 0.2985 | 3.5655 | 3.6002 | 3.6013 | +35.8 | -0.11 |
| 8 | 6 | discharge | 7199 | 1.6002 | 0.1983 | 3.5216 | 3.5605 | 3.5621 | +40.5 | +0.26 |
| 9 | 6 | discharge | 7199 | 1.8002 | 0.0981 | 3.4392 | 3.4695 | 3.4714 | +32.2 | +0.16 |
| 10 | 8 | discharge | 7199 | 1.9960 | 0.0000 | 2.7266 | 3.2839 | 3.2976 | +571.0 | +2.01 |
| 10 | 10 | charge | 7199 | 1.7960 | 0.1002 | 3.5215 | 3.4873 | 3.4875 | -34.0 | +0.16 |
| 11 | 10 | charge | 7199 | 1.5960 | 0.2004 | 3.6056 | 3.5815 | 3.5809 | -24.6 | -0.16 |
| 12 | 10 | charge | 7199 | 1.3960 | 0.3006 | 3.6383 | 3.6135 | 3.6124 | -25.9 | -0.16 |
| 13 | 10 | charge | 7199 | 1.1960 | 0.4008 | 3.6710 | 3.6409 | 3.6401 | -30.9 | -0.10 |
| 14 | 10 | charge | 7199 | 0.9960 | 0.5010 | 3.7228 | 3.6811 | 3.6801 | -42.8 | +0.00 |
| 15 | 10 | charge | 7199 | 0.7961 | 0.6012 | 3.7975 | 3.7731 | 3.7722 | -25.3 | -0.06 |
| 16 | 10 | charge | 7199 | 0.5961 | 0.7014 | 3.8908 | 3.8626 | 3.8613 | -29.5 | -0.23 |
| 17 | 10 | charge | 7199 | 0.3961 | 0.8016 | 3.9979 | 3.9628 | 3.9613 | -36.6 | -0.32 |
| 18 | 10 | charge | 7199 | 0.1961 | 0.9018 | 4.1165 | 4.0723 | 4.0705 | -46.0 | -0.18 |
| 19 | 13 | charge | 7199 | 0.1818 | 0.9089 | 4.0956 | 4.0786 | 4.0778 | -17.8 | -0.16 |
| 19 | 16 | full_after_cv | 7199 | 0.0242 | 0.9879 | 4.1894 | 4.1753 | 4.1732 | -16.2 | -0.16 |

**SP3_IC_OCV_45C** (Q_total = 2.0002 Ah)

| cycle | step | branch | rest (s) | net dis. Ah | SOC | V first | V 1 h | V end | dV rest (mV) | dV last 10 min (mV) |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 4 | full_after_cv | 7190 | 0.0000 | 1.0000 | 4.1920 | 4.1894 | 4.1887 | -3.2 | -0.03 |
| 1 | 6 | discharge | 7199 | 0.2000 | 0.9000 | 4.0505 | 4.0642 | 4.0648 | +14.3 | +0.10 |
| 2 | 6 | discharge | 7199 | 0.4000 | 0.8000 | 3.9373 | 3.9548 | 3.9556 | +18.3 | +0.27 |
| 3 | 6 | discharge | 7199 | 0.6001 | 0.7000 | 3.8320 | 3.8545 | 3.8552 | +23.2 | -0.01 |
| 4 | 6 | discharge | 7199 | 0.8001 | 0.6000 | 3.7306 | 3.7655 | 3.7659 | +35.3 | -0.16 |
| 5 | 6 | discharge | 7199 | 1.0001 | 0.5000 | 3.6592 | 3.6773 | 3.6778 | +18.6 | +0.11 |
| 6 | 6 | discharge | 7199 | 1.2001 | 0.4000 | 3.6171 | 3.6350 | 3.6355 | +18.5 | +0.00 |
| 7 | 6 | discharge | 7199 | 1.4002 | 0.3000 | 3.5827 | 3.6072 | 3.6080 | +25.3 | +0.15 |
| 8 | 6 | discharge | 7199 | 1.6002 | 0.2000 | 3.5401 | 3.5604 | 3.5612 | +21.1 | -0.16 |
| 9 | 6 | discharge | 7199 | 1.8002 | 0.1000 | 3.4577 | 3.4752 | 3.4771 | +19.4 | +0.16 |
| 10 | 6 | discharge | 7199 | 2.0002 | 0.0000 | 3.2825 | 3.3286 | 3.3392 | +56.7 | +1.46 |
| 11 | 10 | charge | 7199 | 1.8002 | 0.1000 | 3.5098 | 3.4918 | 3.4918 | -18.0 | +0.04 |
| 12 | 10 | charge | 7199 | 1.6003 | 0.2000 | 3.5979 | 3.5808 | 3.5803 | -17.7 | +0.00 |
| 13 | 10 | charge | 7199 | 1.4003 | 0.3000 | 3.6341 | 3.6172 | 3.6166 | -17.5 | -0.16 |
| 14 | 10 | charge | 7199 | 1.2003 | 0.3999 | 3.6658 | 3.6459 | 3.6452 | -20.6 | +0.00 |
| 15 | 10 | charge | 7199 | 1.0003 | 0.4999 | 3.7126 | 3.6874 | 3.6866 | -26.1 | -0.49 |
| 16 | 10 | charge | 7199 | 0.8003 | 0.5999 | 3.7917 | 3.7763 | 3.7753 | -16.4 | -0.32 |
| 17 | 10 | charge | 7199 | 0.6003 | 0.6999 | 3.8843 | 3.8659 | 3.8651 | -19.3 | +0.00 |
| 18 | 10 | charge | 7199 | 0.4003 | 0.7999 | 3.9883 | 3.9660 | 3.9652 | -23.2 | -0.16 |
| 19 | 13 | charge | 7199 | 0.2003 | 0.8998 | 4.1013 | 4.0748 | 4.0737 | -27.5 | +0.00 |
| 19 | 16 | full_after_cv | 7199 | 0.0147 | 0.9927 | 4.1925 | 4.1838 | 4.1822 | -10.2 | -0.16 |

## 7. Sampling intervals, clocks and discontinuities

Nominal (config): {'dynamic': 1.0, 'rest_after_pulse': 1.0, 'cc_cv_charge': 10.0}. Observed per step type (median of the per-segment medians, min and max over all segments of that type):

| id | charge dt | cv dt | rest dt | discharge dt | dynamic dt | Date_Time drift min/max (s) | largest clock jump (s) | repeated t | negative dt | dt > 3x median | Step_Time resets | unexplained V jumps |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SP1_IC_OCV_0C | 1.016 [0.062, 1.016] | 5.516 [0.391, 10.016] | 1.016 [0.016, 10.016] | 1.016 [0.125, 1.016] | -- | -0.1 / 8.2 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP1_IC_OCV_25C | 1.016 [0.422, 1.016] | 10.016 [4.094, 10.016] | 1.016 [0.016, 10.016] | 1.016 [0.516, 1.016] | -- | -0.1 / 7.5 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP1_IC_OCV_45C | 1.016 [0.125, 1.016] | 5.516 [0.219, 10.016] | 1.016 [0.015, 10.016] | 1.016 [0.047, 1.016] | -- | -0.1 / 7.4 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP3_IC_OCV_0C | 1.015 [0.063, 10.016] | 5.515 [0.687, 10.018] | 1.015 [0.078, 10.016] | 1.015 [0.015, 1.017] | -- | -0.6 / 7.4 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP3_IC_OCV_25C | 1.015 [0.422, 1.016] | 5.516 [0.609, 10.016] | 1.016 [0.063, 10.016] | 1.016 [0.250, 1.016] | -- | -0.1 / 7.4 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP3_IC_OCV_45C | 1.016 [0.015, 1.016] | 5.516 [0.234, 10.016] | 1.016 [0.016, 10.016] | 1.016 [0.015, 1.016] | -- | -0.1 / 7.0 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP1_INITCAP | 5.516 [0.031, 10.016] | 1.016 [0.719, 1.017] | 1.016 [0.125, 1.017] | 1.016 [1.000, 1.017] | -- | -0.5 / 1.9 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP2_INITCAP | 5.516 [0.937, 10.016] | 1.016 [0.031, 1.017] | 1.015 [0.376, 1.018] | 1.016 [0.172, 1.017] | -- | -0.4 / 209.8 | 208 | 0 | 0 | 0 | 0 | 1 |
| SP3_INITCAP | 5.515 [0.579, 10.017] | 1.016 [0.234, 1.017] | 1.016 [0.141, 1.017] | 1.016 [0.859, 1.017] | -- | -0.4 / 2.1 | 1 | 0 | 0 | 0 | 0 | 0 |
| SP2_0C_DST_50SOC | 10.015 [5.156, 10.016] | 10.015 [6.219, 10.016] | 10.008 [0.750, 10.017] | 10.015 [7.906, 10.016] | 1.015 [0.172, 1.019] | 0.0 / 5.8 | 1 | 0 | 0 | 0 | 16 | 0 |
| SP2_0C_DST_80SOC | -- | 10.015 [3.938, 10.016] | 10.015 [4.125, 10.016] | 10.015 [9.125, 10.016] | 1.016 [0.125, 1.018] | -0.1 / 7.9 | 1 | 0 | 0 | 0 | 26 | 0 |
| SP2_0C_FUDS_50SOC | 10.015 [8.141, 10.016] | 10.015 [6.047, 10.016] | 10.015 [9.875, 10.017] | 10.015 [7.594, 10.016] | 1.015 [0.078, 1.026] | -0.7 / 2.4 | 1 | 0 | 0 | 0 | 5 | 0 |
| SP2_0C_FUDS_80SOC | 10.015 [2.000, 10.017] | 10.015 [10.000, 10.016] | 10.015 [0.469, 10.016] | 10.015 [9.109, 10.016] | 1.015 [0.141, 1.018] | -0.6 / 3.1 | 1 | 0 | 0 | 0 | 7 | 0 |
| SP2_0C_US06_50SOC | 10.015 [1.937, 10.016] | 10.015 [1.719, 10.016] | 10.015 [9.609, 10.016] | 10.015 [7.312, 10.016] | 1.016 [0.125, 1.017] | 0.0 / 4.4 | 1 | 0 | 0 | 0 | 9 | 0 |
| SP2_0C_US06_80SOC | 10.015 [6.703, 10.016] | 10.015 [4.625, 10.016] | 10.015 [9.859, 10.016] | 10.015 [9.219, 10.016] | 1.016 [0.094, 1.018] | -0.1 / 5.6 | 1 | 0 | 0 | 0 | 15 | 0 |
| SP2_0C_BJDST_50SOC | 10.015 [8.500, 10.016] | 10.015 [6.703, 10.016] | 5.516 [0.219, 10.016] | 10.015 [7.000, 10.016] | 1.016 [0.016, 1.019] | 0.0 / 3.5 | 1 | 0 | 0 | 0 | 6 | 0 |
| SP2_0C_BJDST_80SOC | 10.015 [4.594, 10.016] | 10.015 [9.062, 10.017] | 5.516 [0.906, 10.016] | 10.015 [9.187, 10.016] | 1.016 [0.063, 1.018] | 0.0 / 5.0 | 1 | 0 | 0 | 0 | 11 | 0 |
| SP2_25C_DST_50SOC | 10.016 [0.234, 10.016] | 10.016 [1.688, 10.016] | 10.016 [0.453, 10.138] | 10.016 [5.296, 10.016] | 1.015 [0.344, 1.034] | -0.4 / 5.7 | 1 | 0 | 0 | 0 | 18 | 0 |
| SP2_25C_DST_80SOC | 10.016 [6.656, 10.016] | 10.016 [2.484, 10.016] | 10.016 [0.703, 10.017] | 10.016 [8.172, 10.016] | 1.016 [0.156, 1.032] | -0.2 / 8.4 | 1 | 0 | 0 | 0 | 29 | 0 |
| SP2_25C_FUDS_50SOC | 10.015 [5.500, 10.016] | 10.015 [8.188, 10.016] | 10.015 [1.375, 10.016] | 10.015 [5.750, 10.016] | 1.015 [0.328, 1.469] | -0.8 / 2.1 | 1 | 0 | 0 | 0 | 5 | 0 |
| SP2_25C_FUDS_80SOC | 10.016 [7.984, 10.016] | 10.016 [8.891, 10.016] | 10.016 [0.453, 10.417] | 10.016 [8.219, 10.016] | 1.016 [0.078, 1.035] | -0.3 / 3.4 | 1 | 0 | 0 | 0 | 8 | 0 |
| SP2_25C_US06_50SOC | 10.006 [7.753, 10.013] | 10.006 [5.301, 10.013] | 10.007 [9.624, 10.013] | 10.007 [7.565, 10.013] | 1.003 [0.013, 1.559] | -0.0 / 4.0 | 1 | 0 | 0 | 0 | 11 | 0 |
| SP2_25C_US06_80SOC | 10.015 [2.499, 10.016] | 10.015 [8.625, 10.016] | 10.015 [9.296, 10.016] | 10.015 [8.125, 10.016] | 1.015 [0.062, 1.032] | -0.6 / 5.1 | 1 | 0 | 0 | 0 | 17 | 0 |
| SP2_25C_BJDST_50SOC | 10.006 [4.000, 10.016] | 10.015 [6.391, 10.016] | 10.015 [9.265, 10.016] | 10.015 [5.453, 10.016] | 1.015 [0.297, 1.018] | 0.0 / 3.6 | 1 | 0 | 0 | 0 | 7 | 0 |
| SP2_25C_BJDST_80SOC | 10.005 [2.171, 10.013] | 10.004 [4.684, 10.013] | 10.008 [9.572, 10.013] | 10.004 [9.153, 10.013] | 1.003 [0.127, 1.017] | -0.5 / 3.7 | 1 | 0 | 0 | 0 | 12 | 0 |
| SP2_45C_DST_50SOC | -- | 10.016 [4.219, 10.016] | 10.016 [0.391, 10.016] | 10.016 [4.984, 10.016] | 1.016 [0.063, 1.018] | -0.5 / 5.9 | 1 | 0 | 0 | 0 | 19 | 0 |
| SP2_45C_DST_80SOC | 10.016 [1.437, 10.016] | 10.016 [9.734, 10.016] | 10.016 [4.109, 10.016] | 10.016 [8.000, 10.016] | 1.016 [0.031, 1.616] | -0.1 / 9.2 | 1 | 0 | 0 | 0 | 31 | 0 |
| SP2_45C_FUDS_50SOC | 10.016 [6.016, 10.016] | 10.015 [3.797, 10.016] | 10.015 [1.094, 10.016] | 10.016 [5.453, 10.016] | 1.016 [0.141, 1.019] | -0.4 / 2.5 | 1 | 0 | 0 | 0 | 5 | 0 |
| SP2_45C_FUDS_80SOC | 10.016 [2.781, 10.016] | 10.016 [7.937, 10.016] | 10.015 [1.187, 10.016] | 10.016 [8.250, 10.016] | 1.016 [0.015, 1.033] | -0.1 / 3.7 | 1 | 0 | 0 | 0 | 8 | 0 |
| SP2_45C_US06_50SOC | 10.015 [0.297, 10.016] | 10.016 [9.609, 10.016] | 10.016 [1.063, 10.016] | 10.016 [5.562, 10.016] | 1.016 [0.172, 1.030] | -0.5 / 3.8 | 1 | 0 | 0 | 0 | 11 | 0 |
| SP2_45C_US06_80SOC | 10.016 [8.406, 10.016] | 10.016 [4.734, 10.016] | 10.016 [1.000, 10.016] | 10.016 [8.187, 10.016] | 1.016 [0.047, 1.031] | 0.0 / 6.3 | 1 | 0 | 0 | 0 | 18 | 0 |
| SP2_45C_BJDST_50SOC | 10.016 [1.328, 10.016] | 10.016 [2.469, 10.016] | 5.515 [0.797, 10.016] | 10.016 [5.344, 10.016] | 1.016 [0.625, 1.032] | -0.1 / 3.6 | 1 | 0 | 0 | 0 | 8 | 0 |
| SP2_45C_BJDST_80SOC | 10.016 [6.203, 10.016] | 10.016 [9.469, 10.016] | 5.508 [0.625, 10.016] | 10.016 [8.047, 10.016] | 1.016 [0.094, 1.032] | -0.4 / 4.4 | 1 | 0 | 0 | 0 | 12 | 0 |

Notes: `dt > 3x median` counts gaps inside a (cycle, step) segment larger than three times that segment's median interval; `Step_Time resets` are resets of `Step_Time(s)` between consecutive samples of the same (cycle, step) group, evaluated on the group's own rows so that an interleaved step-8 logger row does not hide a reset (the dynamic profiles are scheduled as a loop, so `Step_Time` restarts every loop iteration: the count equals the number of completed profile repetitions); `unexplained V jumps` are |dV| > 0.3 V between consecutive samples with |dI| < 0.05 A.

## 8. Anomalies and findings

Global findings (all values computed from the inventory):

* **No temperature channel** in any of the 33 files: temperatures are chamber set points from the file names (0, 25, 45 C).
* **Chunked exports** (6 incremental-OCV workbooks, three sheets of 63990 rows): the last row of each sheet is repeated as the first row of the next sheet (identical `Data_Point` and `Test_Time`); 12 duplicate rows in total (rows [63990, 127980] of each concatenation) were dropped at conversion. This removes the zero-dt rows: after de-duplication 0 repeated timestamps and 0 negative dt remain over all files, and `Data_Point` is strictly increasing everywhere.
* **Step-8 logger rows** in all 24 dynamic files (246 rows in total): `Step_Index` 8 rows whose `Test_Time` coincides with a step-7 row (max gap 0.0171 s) and whose `Current(A)` is written as 0 (max |I| = 0.0000 A); they are dropped, never merged (per-file counts in section 5).
* **Date_Time drift**: `Date_Time` (1 s resolution) drifts by up to 9.2 s over a test relative to `Test_Time(s)`; SP2_INITCAP has a 208 s wall-clock jump at row 19603 (unlogged pause, section 4).
* **Truncation**: SP1_IC_OCV_25C ends in cycle 18 step 9 (charge, 274 samples): the final CC/CV recharge and rest are missing.
* **0 C pulse size**: at 0 C the OCV schedule uses 0.1 x 1.8 Ah pulses (median 0.1819 Ah, 649-658 s at 1 A for the full pulses) instead of 0.2 Ah; likewise the 0 C dynamic schedules pre-discharge (1 - label) x 1.81 Ah versus 2.00 Ah at 25 C and 2.00 Ah at 45 C.
* **Discharge branches not reaching 2.5 V**: SP1_IC_OCV_0C ends its last pulse at 2.577 V; SP1_IC_OCV_45C ends its last pulse at 3.034 V; SP3_IC_OCV_45C ends its last pulse at 3.198 V (schedule-limited: these totals are lower bounds of the capacity; consistently, the reference SOC at the end of the 45 C profiles is -0.0005 on average (range -0.0045 to +0.0091) versus -0.0015 at 25 C (-0.0154 to +0.0129) and -0.0029 at 0 C (-0.0435 to +0.0334)).
* **Initial CC charge in OCV files** lasts 1-4 sample(s) (cells already at 4.052-4.179 V at the start, charged in an unexported preceding step); its first sample overshoots to 4.201-4.376 V; the CV cutoff in these files is 0.100 A (not 0.02 A as in the capacity and dynamic tests).
* **Charge pulses above 4.2 V** (time-limited 1 A pulses in the last cycles of the charge branch): SP1_IC_OCV_25C up to 4.2498 V; SP3_IC_OCV_25C up to 4.2208 V.
* **Test_Time offset**: SP2_25C_FUDS_50SOC starts at Test_Time 1005.9 s; SP2_25C_FUDS_80SOC starts at Test_Time 7200.0 s (an unexported initial period; the capacity columns start at 0).
* **Logging clock**: the step-7 median interval is 1.0155 s in all dynamic files except SP2_25C_US06_50SOC (1.0030 s), SP2_25C_BJDST_80SOC (1.0029 s).

Per-file anomalies (from `results/dataset_inventory.json`):

* **SP1_IC_OCV_0C**
  * chunked export: 2 exact duplicate rows at sheet boundaries (rows [63990, 127980] of the concatenation) dropped; they were repeated timestamps / repeated Data_Point
  * voltage above 4.25 V in 1 sample(s), max 4.2621 V (row 6, step 2)
  * no temperature channel: temperature is the chamber set point from the file name only
  * discharge branch ended at 2.577 V by the pulse schedule, not at the 2.5 V cutoff: total 1.8056 Ah is a lower bound of the capacity at this temperature
  * discharge pulses of 0.1806 Ah (schedule step of 0.1 x 1.8 Ah at 0 C) instead of 0.2 Ah
  * initial CC charge (step 2) has only 1 sample(s) (cell already at 4.164 V at start); the CV step reached 0.100 A and added 0.0212 Ah
  * 1 time-limited 1 A charge pulse(s) exceeded 4.2 V (max 4.2621 V, cycles [1])
* **SP1_IC_OCV_25C**
  * chunked export: 2 exact duplicate rows at sheet boundaries (rows [63990, 127980] of the concatenation) dropped; they were repeated timestamps / repeated Data_Point
  * voltage above 4.25 V in 1 sample(s), max 4.3758 V (row 6, step 2)
  * voltage below 2.5 V: min 2.4999 V (row 71992, step 5)
  * no temperature channel: temperature is the chamber set point from the file name only
  * file truncated: ends in cycle 18 step 9 (charge, 274 samples); steps present [1, 2, 3, 4, 5, 6, 8, 9, 10]
  * initial CC charge (step 2) has only 1 sample(s) (cell already at 4.166 V at start); the CV step reached 0.100 A and added 0.0161 Ah
  * 3 time-limited 1 A charge pulse(s) exceeded 4.2 V (max 4.3758 V, cycles [1, 17, 18])
* **SP1_IC_OCV_45C**
  * chunked export: 2 exact duplicate rows at sheet boundaries (rows [63990, 127980] of the concatenation) dropped; they were repeated timestamps / repeated Data_Point
  * voltage above 4.25 V in 1 sample(s), max 4.3286 V (row 6, step 2)
  * no temperature channel: temperature is the chamber set point from the file name only
  * discharge branch ended at 3.034 V by the pulse schedule, not at the 2.5 V cutoff: total 1.9996 Ah is a lower bound of the capacity at this temperature
  * initial CC charge (step 2) has only 1 sample(s) (cell already at 4.174 V at start); the CV step reached 0.100 A and added 0.0140 Ah
  * 1 time-limited 1 A charge pulse(s) exceeded 4.2 V (max 4.3286 V, cycles [1])
* **SP3_IC_OCV_0C**
  * chunked export: 2 exact duplicate rows at sheet boundaries (rows [63990, 127980] of the concatenation) dropped; they were repeated timestamps / repeated Data_Point
  * voltage below 2.5 V: min 2.4999 V (row 71360, step 5)
  * no temperature channel: temperature is the chamber set point from the file name only
  * discharge pulses of 0.1831 Ah (schedule step of 0.1 x 1.8 Ah at 0 C) instead of 0.2 Ah
  * initial CC charge (step 2) has only 4 sample(s) (cell already at 4.052 V at start); the CV step reached 0.100 A and added 0.1697 Ah
* **SP3_IC_OCV_25C**
  * chunked export: 2 exact duplicate rows at sheet boundaries (rows [63990, 127980] of the concatenation) dropped; they were repeated timestamps / repeated Data_Point
  * voltage above 4.25 V in 1 sample(s), max 4.2733 V (row 6, step 2)
  * voltage below 2.5 V: min 2.5000 V (row 72023, step 5)
  * no temperature channel: temperature is the chamber set point from the file name only
  * initial CC charge (step 2) has only 1 sample(s) (cell already at 4.172 V at start); the CV step reached 0.100 A and added 0.0184 Ah
  * 2 time-limited 1 A charge pulse(s) exceeded 4.2 V (max 4.2733 V, cycles [1, 18])
* **SP3_IC_OCV_45C**
  * chunked export: 2 exact duplicate rows at sheet boundaries (rows [63990, 127980] of the concatenation) dropped; they were repeated timestamps / repeated Data_Point
  * voltage above 4.25 V in 1 sample(s), max 4.2516 V (row 6, step 2)
  * no temperature channel: temperature is the chamber set point from the file name only
  * discharge branch ended at 3.198 V by the pulse schedule, not at the 2.5 V cutoff: total 2.0002 Ah is a lower bound of the capacity at this temperature
  * initial CC charge (step 2) has only 1 sample(s) (cell already at 4.179 V at start); the CV step reached 0.100 A and added 0.0151 Ah
  * 1 time-limited 1 A charge pulse(s) exceeded 4.2 V (max 4.2516 V, cycles [1])
* **SP1_INITCAP**
  * voltage below 2.5 V: min 2.4999 V (row 20136, step 6)
  * no temperature channel: temperature is the chamber set point from the file name only
* **SP2_INITCAP**
  * voltage below 2.5 V: min 2.5000 V (row 19688, step 6)
  * Date_Time jumps by 208 s relative to Test_Time at row 19603 (unlogged pause)
  * 1 voltage jump(s) > 0.3 V without a current step: [{'row': 19603, 'V_before': 2.5572831630706787, 'V_after': 3.2901535034179688, 'I_A': -1.00024151802063, 'dt_s': 0.8442746465007076}]
  * no temperature channel: temperature is the chamber set point from the file name only
* **SP3_INITCAP**
  * voltage below 2.5 V: min 2.4999 V (row 20510, step 6)
  * no temperature channel: temperature is the chamber set point from the file name only
* **SP2_0C_DST_50SOC**
  * voltage below 2.5 V: min 2.5000 V (row 8083, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.9034 Ah instead of 1.00 Ah: the 50 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 11 step-8 logger rows interleaved in step 7 (timestamps within 0.0159 s of a step-7 sample, Current written as 0) dropped
* **SP2_0C_DST_80SOC**
  * voltage below 2.5 V: min 2.4990 V (row 10310, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.3615 Ah instead of 0.40 Ah: the 80 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 25 step-8 logger rows interleaved in step 7 (timestamps within 0.0010 s of a step-7 sample, Current written as 0) dropped
* **SP2_0C_FUDS_50SOC**
  * voltage below 2.5 V: min 2.5000 V (row 9056, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.9035 Ah instead of 1.00 Ah: the 50 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 4 step-8 logger rows interleaved in step 7 (timestamps within 0.0013 s of a step-7 sample, Current written as 0) dropped
* **SP2_0C_FUDS_80SOC**
  * voltage below 2.5 V: min 2.4995 V (row 11613, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.3614 Ah instead of 0.40 Ah: the 80 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0013 s of a step-7 sample, Current written as 0) dropped
* **SP2_0C_US06_50SOC**
  * voltage below 2.5 V: min 2.4595 V (row 8055, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.9035 Ah instead of 1.00 Ah: the 50 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0014 s of a step-7 sample, Current written as 0) dropped
  * profile ended at 2.4595 V (below the 2.5 V cutoff: last transient sample)
* **SP2_0C_US06_80SOC**
  * voltage below 2.5 V: min 2.4995 V (row 11444, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.3614 Ah instead of 0.40 Ah: the 80 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 11 step-8 logger rows interleaved in step 7 (timestamps within 0.0014 s of a step-7 sample, Current written as 0) dropped
* **SP2_0C_BJDST_50SOC**
  * voltage below 2.5 V: min 2.5000 V (row 14563, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.9035 Ah instead of 1.00 Ah: the 50 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 4 step-8 logger rows interleaved in step 7 (timestamps within 0.0015 s of a step-7 sample, Current written as 0) dropped
* **SP2_0C_BJDST_80SOC**
  * voltage below 2.5 V: min 2.5000 V (row 18512, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * pre-profile discharge 0.3615 Ah instead of 0.40 Ah: the 80 % label is defined relative to a schedule capacity of 1.807 Ah (0 C schedules use 1.8 Ah), not 2.0 Ah
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0013 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_DST_50SOC**
  * voltage below 2.5 V: min 2.4997 V (row 9500, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 13 step-8 logger rows interleaved in step 7 (timestamps within 0.0171 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_DST_80SOC**
  * voltage below 2.5 V: min 2.4034 V (row 12560, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 24 step-8 logger rows interleaved in step 7 (timestamps within 0.0160 s of a step-7 sample, Current written as 0) dropped
  * profile ended at 2.4034 V (below the 2.5 V cutoff: last transient sample)
* **SP2_25C_FUDS_50SOC**
  * voltage below 2.5 V: min 2.4989 V (row 9307, step 7)
  * Test_Time starts at 1005.9 s (not ~0): the exported record begins after an unexported initial period
  * no temperature channel: temperature is the chamber set point from the file name only
  * 4 step-8 logger rows interleaved in step 7 (timestamps within 0.0148 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_FUDS_80SOC**
  * voltage below 2.5 V: min 2.4968 V (row 13680, step 7)
  * Test_Time starts at 7200.0 s (not ~0): the exported record begins after an unexported initial period
  * no temperature channel: temperature is the chamber set point from the file name only
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0171 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_US06_50SOC**
  * voltage below 2.5 V: min 2.4987 V (row 8320, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 9 step-8 logger rows interleaved in step 7 (timestamps within 0.0137 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_US06_80SOC**
  * voltage below 2.5 V: min 2.4982 V (row 11897, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 14 step-8 logger rows interleaved in step 7 (timestamps within 0.0160 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_BJDST_50SOC**
  * voltage below 2.5 V: min 2.4994 V (row 8384, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0012 s of a step-7 sample, Current written as 0) dropped
* **SP2_25C_BJDST_80SOC**
  * voltage below 2.5 V: min 2.4999 V (row 12436, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 9 step-8 logger rows interleaved in step 7 (timestamps within 0.0134 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_DST_50SOC**
  * voltage above 4.25 V in 1 sample(s), max 4.3459 V (row 1, step 2)
  * voltage below 2.5 V: min 2.4999 V (row 9088, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 14 step-8 logger rows interleaved in step 7 (timestamps within 0.0013 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_DST_80SOC**
  * voltage below 2.5 V: min 2.4955 V (row 13620, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 21 step-8 logger rows interleaved in step 7 (timestamps within 0.0152 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_FUDS_50SOC**
  * voltage below 2.5 V: min 2.4988 V (row 9592, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 5 step-8 logger rows interleaved in step 7 (timestamps within 0.0014 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_FUDS_80SOC**
  * voltage below 2.5 V: min 2.4984 V (row 13519, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0165 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_US06_50SOC**
  * voltage below 2.5 V: min 2.4997 V (row 9104, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 8 step-8 logger rows interleaved in step 7 (timestamps within 0.0147 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_US06_80SOC**
  * voltage below 2.5 V: min 2.4993 V (row 12785, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 16 step-8 logger rows interleaved in step 7 (timestamps within 0.0150 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_BJDST_50SOC**
  * voltage below 2.5 V: min 2.4997 V (row 15839, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 6 step-8 logger rows interleaved in step 7 (timestamps within 0.0158 s of a step-7 sample, Current written as 0) dropped
* **SP2_45C_BJDST_80SOC**
  * voltage below 2.5 V: min 2.4988 V (row 19693, step 7)
  * no temperature channel: temperature is the chamber set point from the file name only
  * 12 step-8 logger rows interleaved in step 7 (timestamps within 0.0157 s of a step-7 sample, Current written as 0) dropped

## 9. Appendix: charge / discharge / rest segments per file

Ah columns: Arbin cumulative-column differences over the segment; `Ah trapz` = our trapezoidal integral of `Current(A)` (signed, charge > 0). For rests, `V initial`/`V final` are the first and last voltage of the rest and `dV` their difference.

### SP1_IC_OCV_0C

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 6 | 10.0 | 60.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1638 | 4.1638 | +0.0 | 10.0155 | 9.953 | 10.015 |
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9988 | 4.2621 | 4.2621 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 49 | 70.0 | 547.8 | 477.7 | 0.0212 | 0.0000 | +0.0222 | +0.1543 | 4.2004 | 4.2002 | -0.2 | 10.0155 | 7.094 | 10.016 |
| 1 | 4 | rest | 719 | 557.8 | 7747.8 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1878 | 4.1777 | -10.0 | 10.0155 | 9.734 | 10.016 |
| 1 | 5 | discharge | 643 | 7748.8 | 8397.8 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 4.0534 | 3.8974 | -156.1 | 1.0156 | 0.594 | 1.016 |
| 1 | 6 | rest | 7121 | 8398.8 | 15597.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0090 | 4.0565 | +47.5 | 1.0156 | 0.234 | 1.016 |
| 2 | 5 | discharge | 643 | 15598.8 | 16247.8 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.9359 | 3.7847 | -151.2 | 1.0155 | 0.922 | 1.016 |
| 2 | 6 | rest | 7122 | 16248.8 | 23447.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8949 | 3.9537 | +58.8 | 1.0155 | 0.969 | 1.016 |
| 3 | 5 | discharge | 643 | 23448.9 | 24097.9 | 649.0 | 0.0000 | 0.1805 | -0.1804 | -0.9999 | 3.8366 | 3.6839 | -152.7 | 1.0156 | 0.969 | 1.016 |
| 3 | 6 | rest | 7118 | 24098.9 | 31297.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7918 | 3.8614 | +69.5 | 1.0156 | 0.406 | 1.335 |
| 4 | 5 | discharge | 643 | 31298.9 | 31947.9 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.7455 | 3.5943 | -151.2 | 1.0156 | 0.266 | 1.016 |
| 4 | 6 | rest | 7115 | 31948.9 | 39147.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7027 | 3.7778 | +75.0 | 1.0156 | 0.906 | 1.238 |
| 5 | 5 | discharge | 643 | 39149.0 | 39797.9 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.6630 | 3.5162 | -146.8 | 1.0156 | 0.438 | 1.016 |
| 5 | 6 | rest | 7116 | 39798.9 | 46998.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6322 | 3.6878 | +55.6 | 1.0156 | 0.531 | 1.016 |
| 6 | 5 | discharge | 643 | 46999.0 | 47648.0 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.5677 | 3.4692 | -98.5 | 1.0156 | 0.187 | 1.016 |
| 6 | 6 | rest | 7117 | 47649.0 | 54848.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5872 | 3.6356 | +48.5 | 1.0156 | 0.328 | 1.017 |
| 7 | 5 | discharge | 643 | 54849.0 | 55498.0 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.5126 | 3.4280 | -84.6 | 1.0156 | 0.328 | 1.016 |
| 7 | 6 | rest | 7115 | 55499.0 | 62698.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5504 | 3.6077 | +57.4 | 1.0156 | 0.141 | 1.016 |
| 8 | 5 | discharge | 643 | 62699.0 | 63348.0 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.4822 | 3.3801 | -102.1 | 1.0156 | 0.406 | 1.016 |
| 8 | 6 | rest | 7116 | 63349.1 | 70548.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5091 | 3.5836 | +74.5 | 1.0156 | 0.016 | 1.016 |
| 9 | 5 | discharge | 643 | 70549.1 | 71198.1 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.4536 | 3.2840 | -169.7 | 1.0156 | 0.125 | 1.016 |
| 9 | 6 | rest | 7114 | 71199.1 | 78398.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4408 | 3.5309 | +90.1 | 1.0156 | 0.828 | 1.016 |
| 10 | 5 | discharge | 643 | 78399.1 | 79048.1 | 649.0 | 0.0000 | 0.1806 | -0.1804 | -1.0000 | 3.3848 | 2.5770 | -807.7 | 1.0156 | 0.453 | 1.016 |
| 10 | 6 | rest | 7114 | 79049.1 | 86248.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.8302 | 3.4561 | +625.9 | 1.0156 | 0.625 | 1.017 |
| 11 | 9 | charge | 643 | 86249.2 | 86898.2 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9995 | 3.6094 | 3.7042 | +94.8 | 1.0156 | 0.391 | 1.016 |
| 11 | 10 | rest | 7114 | 86899.2 | 94098.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5877 | 3.5402 | -47.5 | 1.0156 | 0.688 | 1.016 |
| 12 | 9 | charge | 643 | 94099.2 | 94748.2 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9995 | 3.6732 | 3.7520 | +78.8 | 1.0156 | 0.250 | 1.016 |
| 12 | 10 | rest | 7115 | 94749.2 | 101948.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6400 | 3.5966 | -43.4 | 1.0156 | 0.344 | 1.016 |
| 13 | 9 | charge | 643 | 101949.2 | 102598.2 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9995 | 3.7176 | 3.7727 | +55.1 | 1.0156 | 0.297 | 1.016 |
| 13 | 10 | rest | 7115 | 102599.2 | 109798.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6654 | 3.6207 | -44.7 | 1.0156 | 0.750 | 1.016 |
| 14 | 9 | charge | 643 | 109799.3 | 110448.3 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9995 | 3.7359 | 3.8181 | +82.2 | 1.0156 | 0.125 | 1.016 |
| 14 | 10 | rest | 7115 | 110449.3 | 117648.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7076 | 3.6483 | -59.3 | 1.0156 | 0.516 | 1.016 |
| 15 | 9 | charge | 643 | 117649.3 | 118298.3 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9995 | 3.7679 | 3.8706 | +102.7 | 1.0156 | 0.641 | 1.016 |
| 15 | 10 | rest | 7117 | 118299.3 | 125498.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7615 | 3.6927 | -68.9 | 1.0156 | 0.906 | 1.168 |
| 16 | 9 | charge | 643 | 125499.3 | 126148.3 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9996 | 3.8128 | 3.9362 | +123.5 | 1.0156 | 0.438 | 1.016 |
| 16 | 10 | rest | 7117 | 126149.3 | 133348.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8293 | 3.7865 | -42.8 | 1.0156 | 0.641 | 1.016 |
| 17 | 9 | charge | 643 | 133349.3 | 133998.3 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9995 | 3.8991 | 4.0228 | +123.7 | 1.0156 | 0.547 | 1.016 |
| 17 | 10 | rest | 7117 | 133999.4 | 141198.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9174 | 3.8695 | -48.0 | 1.0156 | 0.250 | 1.016 |
| 18 | 9 | charge | 643 | 141199.4 | 141848.4 | 649.0 | 0.1805 | 0.0000 | +0.1803 | +0.9996 | 3.9832 | 4.1401 | +156.9 | 1.0156 | 0.328 | 1.016 |
| 18 | 10 | rest | 7116 | 141849.4 | 149048.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0278 | 3.9604 | -67.4 | 1.0156 | 0.797 | 1.016 |
| 19 | 12 | charge | 337 | 149049.4 | 149389.3 | 339.9 | 0.0946 | 0.0000 | +0.0945 | +0.9995 | 4.0805 | 4.2001 | +119.6 | 1.0156 | 0.875 | 1.016 |
| 19 | 13 | rest | 7114 | 149390.3 | 156589.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0832 | 4.0111 | -72.1 | 1.0156 | 0.328 | 1.016 |
| 19 | 14 | charge | 132 | 156590.3 | 156721.9 | 131.6 | 0.0368 | 0.0000 | +0.0367 | +0.9995 | 4.1307 | 4.2001 | +69.4 | 1.0156 | 0.062 | 1.016 |
| 19 | 15 | cv | 2429 | 156722.9 | 159180.0 | 2457.0 | 0.2228 | 0.0000 | +0.2228 | +0.3261 | 4.2004 | 4.2002 | -0.2 | 1.0156 | 0.391 | 1.016 |
| 19 | 16 | rest | 7114 | 159181.0 | 166380.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1892 | 4.1636 | -25.6 | 1.0156 | 0.406 | 1.016 |

### SP1_IC_OCV_25C

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 6 | 10.0 | 60.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1662 | 4.1660 | -0.2 | 10.0155 | 9.953 | 10.016 |
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9994 | 4.3758 | 4.3758 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 46 | 70.0 | 514.7 | 444.7 | 0.0161 | 0.0000 | +0.0173 | +0.1267 | 4.2007 | 4.2006 | -0.2 | 10.0155 | 4.094 | 10.016 |
| 1 | 4 | rest | 719 | 524.7 | 7714.7 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1805 | 4.1758 | -4.7 | 10.0155 | 9.781 | 10.016 |
| 1 | 5 | discharge | 713 | 7715.7 | 8434.7 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.9563 | 3.8081 | -148.3 | 1.0156 | 0.812 | 1.016 |
| 1 | 6 | rest | 7126 | 8435.7 | 15634.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0275 | 4.0502 | +22.7 | 1.0156 | 0.250 | 1.016 |
| 2 | 5 | discharge | 713 | 15635.8 | 16354.8 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.8301 | 3.6910 | -139.0 | 1.0156 | 0.516 | 1.016 |
| 2 | 6 | rest | 7126 | 16355.8 | 23554.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9110 | 3.9400 | +29.0 | 1.0156 | 0.844 | 1.016 |
| 3 | 5 | discharge | 713 | 23555.8 | 24274.8 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.7196 | 3.5805 | -139.0 | 1.0156 | 0.641 | 1.016 |
| 3 | 6 | rest | 7126 | 24275.8 | 31474.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8004 | 3.8400 | +39.5 | 1.0156 | 0.890 | 1.016 |
| 4 | 5 | discharge | 713 | 31475.8 | 32194.8 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.6188 | 3.4823 | -136.5 | 1.0156 | 0.844 | 1.016 |
| 4 | 6 | rest | 7127 | 32195.8 | 39394.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7017 | 3.7536 | +51.9 | 1.0156 | 0.312 | 1.016 |
| 5 | 5 | discharge | 713 | 39395.9 | 40114.9 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.5321 | 3.4199 | -112.1 | 1.0156 | 0.609 | 1.016 |
| 5 | 6 | rest | 7127 | 40115.9 | 47314.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6394 | 3.6648 | +25.4 | 1.0156 | 0.250 | 1.018 |
| 6 | 5 | discharge | 713 | 47315.9 | 48034.9 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.4442 | 3.3791 | -65.1 | 1.0155 | 1.000 | 1.016 |
| 6 | 6 | rest | 7126 | 48035.9 | 55234.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5996 | 3.6261 | +26.4 | 1.0156 | 0.594 | 1.016 |
| 7 | 5 | discharge | 713 | 55236.0 | 55955.0 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9999 | 3.4053 | 3.3436 | -61.7 | 1.0156 | 0.594 | 1.016 |
| 7 | 6 | rest | 7126 | 55956.0 | 63155.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5646 | 3.5995 | +34.8 | 1.0156 | 0.359 | 1.016 |
| 8 | 5 | discharge | 713 | 63156.0 | 63875.0 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9999 | 3.3779 | 3.2968 | -81.2 | 1.0156 | 0.609 | 1.016 |
| 8 | 6 | rest | 7125 | 63876.0 | 71075.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5197 | 3.5556 | +35.8 | 1.0156 | 0.703 | 1.016 |
| 9 | 5 | discharge | 713 | 71076.0 | 71795.1 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9999 | 3.3319 | 3.2076 | -124.3 | 1.0156 | 0.703 | 1.016 |
| 9 | 6 | rest | 7126 | 71796.1 | 78995.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4368 | 3.4677 | +31.0 | 1.0156 | 0.063 | 1.016 |
| 10 | 5 | discharge | 669 | 78996.1 | 79670.7 | 674.6 | 0.0000 | 0.1876 | -0.1875 | -0.9999 | 3.2379 | 2.4999 | -738.0 | 1.0156 | 0.641 | 1.016 |
| 10 | 8 | rest | 7127 | 79671.7 | 86870.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.8169 | 3.2642 | +447.3 | 1.0156 | 0.328 | 1.018 |
| 10 | 9 | charge | 713 | 86871.7 | 87590.7 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9995 | 3.5014 | 3.7329 | +231.4 | 1.0155 | 0.766 | 1.016 |
| 10 | 10 | rest | 7128 | 87591.7 | 94790.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5149 | 3.4828 | -32.1 | 1.0155 | 0.985 | 1.016 |
| 11 | 9 | charge | 713 | 94791.7 | 95510.7 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9995 | 3.7042 | 3.8149 | +110.7 | 1.0155 | 0.656 | 1.016 |
| 11 | 10 | rest | 7129 | 95511.8 | 102710.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5993 | 3.5770 | -22.4 | 1.0155 | 0.016 | 1.016 |
| 12 | 9 | charge | 713 | 102711.8 | 103430.8 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9995 | 3.7940 | 3.8486 | +54.6 | 1.0156 | 0.641 | 1.016 |
| 12 | 10 | rest | 7127 | 103431.8 | 110630.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6343 | 3.6107 | -23.7 | 1.0155 | 0.109 | 1.016 |
| 13 | 9 | charge | 713 | 110631.8 | 111350.8 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.8768 | 3.9038 | +27.1 | 1.0155 | 0.734 | 1.016 |
| 13 | 10 | rest | 7127 | 111351.8 | 118550.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6656 | 3.6369 | -28.7 | 1.0155 | 0.844 | 1.016 |
| 14 | 9 | charge | 713 | 118551.8 | 119270.8 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.8763 | 3.9482 | +72.0 | 1.0156 | 0.594 | 1.016 |
| 14 | 10 | rest | 7127 | 119271.8 | 126470.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7128 | 3.6737 | -39.1 | 1.0155 | 0.766 | 1.022 |
| 15 | 9 | charge | 713 | 126471.9 | 127190.9 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.9103 | 4.0184 | +108.1 | 1.0155 | 0.422 | 1.016 |
| 15 | 10 | rest | 7128 | 127191.9 | 134390.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7857 | 3.7630 | -22.7 | 1.0155 | 0.375 | 1.016 |
| 16 | 9 | charge | 713 | 134391.9 | 135110.9 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.9972 | 4.1064 | +109.2 | 1.0155 | 0.765 | 1.016 |
| 16 | 10 | rest | 7127 | 135111.9 | 142310.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8750 | 3.8487 | -26.3 | 1.0155 | 0.922 | 1.021 |
| 17 | 9 | charge | 713 | 142312.0 | 143031.0 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 4.0810 | 4.2103 | +129.3 | 1.0155 | 0.656 | 1.016 |
| 17 | 10 | rest | 7128 | 143032.0 | 150231.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9802 | 3.9471 | -33.1 | 1.0155 | 0.266 | 1.577 |
| 18 | 9 | charge | 274 | 150232.0 | 150507.8 | 275.8 | 0.0769 | 0.0000 | +0.0767 | +0.9996 | 4.1782 | 4.2498 | +71.6 | 1.0155 | 1.000 | 1.016 |

### SP1_IC_OCV_45C

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 6 | 10.0 | 60.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1737 | 4.1738 | +0.2 | 10.0155 | 9.937 | 10.016 |
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9988 | 4.3286 | 4.3286 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 39 | 70.0 | 448.8 | 378.8 | 0.0140 | 0.0000 | +0.0152 | +0.1288 | 4.2006 | 4.2004 | -0.2 | 10.0155 | 8.312 | 10.016 |
| 1 | 4 | rest | 720 | 458.8 | 7648.8 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1852 | 4.1821 | -3.1 | 10.0155 | 1.156 | 10.016 |
| 1 | 5 | discharge | 712 | 7649.8 | 8368.8 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 4.0218 | 3.8837 | -138.1 | 1.0156 | 0.750 | 1.016 |
| 1 | 6 | rest | 7124 | 8369.8 | 15568.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0447 | 4.0584 | +13.8 | 1.0156 | 0.328 | 1.016 |
| 2 | 5 | discharge | 713 | 15569.9 | 16288.9 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.8977 | 3.7701 | -127.5 | 1.0156 | 0.172 | 1.016 |
| 2 | 6 | rest | 7119 | 16289.9 | 23488.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9312 | 3.9484 | +17.2 | 1.0156 | 0.281 | 1.016 |
| 3 | 5 | discharge | 712 | 23489.9 | 24208.9 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.7871 | 3.6650 | -122.2 | 1.0156 | 0.562 | 1.016 |
| 3 | 6 | rest | 7118 | 24209.9 | 31408.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8260 | 3.8481 | +22.0 | 1.0156 | 0.797 | 1.016 |
| 4 | 5 | discharge | 712 | 31409.9 | 32128.9 | 719.0 | 0.0000 | 0.1999 | -0.1998 | -0.9997 | 3.6872 | 3.5651 | -122.0 | 1.0156 | 0.984 | 1.016 |
| 4 | 6 | rest | 7120 | 32129.9 | 39329.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7262 | 3.7601 | +33.9 | 1.0156 | 0.047 | 1.016 |
| 5 | 5 | discharge | 712 | 39330.0 | 40049.0 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.5990 | 3.4951 | -103.9 | 1.0156 | 0.469 | 1.016 |
| 5 | 6 | rest | 7122 | 40050.0 | 47249.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6557 | 3.6716 | +15.9 | 1.0156 | 0.906 | 1.016 |
| 6 | 5 | discharge | 713 | 47250.0 | 47969.0 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.5112 | 3.4543 | -56.9 | 1.0155 | 0.546 | 1.016 |
| 6 | 6 | rest | 7123 | 47970.0 | 55169.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6149 | 3.6327 | +17.8 | 1.0156 | 0.750 | 1.016 |
| 7 | 5 | discharge | 713 | 55170.1 | 55889.1 | 719.0 | 0.0000 | 0.1999 | -0.1998 | -0.9998 | 3.4724 | 3.4201 | -52.3 | 1.0156 | 0.187 | 1.016 |
| 7 | 6 | rest | 7123 | 55890.1 | 63089.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5807 | 3.6056 | +25.0 | 1.0156 | 0.844 | 1.016 |
| 8 | 5 | discharge | 712 | 63090.1 | 63809.1 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.4452 | 3.3744 | -70.8 | 1.0156 | 0.969 | 1.016 |
| 8 | 6 | rest | 7124 | 63810.1 | 71009.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5360 | 3.5551 | +19.1 | 1.0156 | 0.344 | 1.016 |
| 9 | 5 | discharge | 713 | 71010.1 | 71729.1 | 719.0 | 0.0000 | 0.2000 | -0.1998 | -0.9998 | 3.3933 | 3.2904 | -102.9 | 1.0156 | 0.484 | 1.016 |
| 9 | 6 | rest | 7124 | 71730.1 | 78929.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4540 | 3.4718 | +17.8 | 1.0156 | 0.765 | 1.016 |
| 10 | 5 | discharge | 713 | 78930.2 | 79649.2 | 719.0 | 0.0000 | 0.1999 | -0.1998 | -0.9997 | 3.3078 | 3.0339 | -273.9 | 1.0156 | 0.047 | 1.016 |
| 10 | 6 | rest | 7123 | 79650.2 | 86849.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.2039 | 3.2771 | +73.3 | 1.0156 | 0.906 | 1.016 |
| 11 | 9 | charge | 712 | 86850.2 | 87569.2 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.4460 | 3.6637 | +217.6 | 1.0156 | 0.875 | 1.016 |
| 11 | 10 | rest | 7125 | 87570.2 | 94769.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5018 | 3.4836 | -18.2 | 1.0155 | 0.062 | 1.018 |
| 12 | 9 | charge | 713 | 94770.2 | 95489.2 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.6458 | 3.7508 | +105.0 | 1.0155 | 0.734 | 1.016 |
| 12 | 10 | rest | 7124 | 95490.2 | 102689.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5904 | 3.5757 | -14.7 | 1.0156 | 0.594 | 1.016 |
| 13 | 9 | charge | 713 | 102690.3 | 103409.3 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.7363 | 3.7897 | +53.5 | 1.0156 | 0.125 | 1.016 |
| 13 | 10 | rest | 7125 | 103410.3 | 110609.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6301 | 3.6139 | -16.2 | 1.0155 | 0.031 | 1.016 |
| 14 | 9 | charge | 713 | 110610.3 | 111329.3 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9995 | 3.7735 | 3.8197 | +46.2 | 1.0156 | 0.453 | 1.016 |
| 14 | 10 | rest | 7124 | 111330.3 | 118529.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6601 | 3.6408 | -19.3 | 1.0156 | 0.015 | 1.016 |
| 15 | 9 | charge | 713 | 118530.4 | 119249.4 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.8004 | 3.8622 | +61.7 | 1.0155 | 0.672 | 1.016 |
| 15 | 10 | rest | 7123 | 119250.4 | 126449.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7026 | 3.6786 | -24.0 | 1.0156 | 0.390 | 1.016 |
| 16 | 9 | charge | 713 | 126450.4 | 127169.4 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9996 | 3.8382 | 3.9369 | +98.7 | 1.0156 | 0.156 | 1.016 |
| 16 | 10 | rest | 7119 | 127170.4 | 134369.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7784 | 3.7633 | -15.1 | 1.0156 | 0.297 | 1.016 |
| 17 | 9 | charge | 713 | 134370.4 | 135089.5 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9995 | 3.9220 | 4.0251 | +103.1 | 1.0156 | 0.469 | 1.016 |
| 17 | 10 | rest | 7119 | 135090.4 | 142289.5 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8667 | 3.8491 | -17.7 | 1.0156 | 0.782 | 1.016 |
| 18 | 9 | charge | 712 | 142290.5 | 143009.5 | 719.0 | 0.1999 | 0.0000 | +0.1998 | +0.9995 | 4.0072 | 4.1273 | +120.1 | 1.0156 | 0.625 | 1.016 |
| 18 | 10 | rest | 7119 | 143010.5 | 150209.5 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9688 | 3.9474 | -21.4 | 1.0156 | 0.609 | 1.016 |
| 19 | 12 | charge | 474 | 150210.5 | 150688.3 | 477.8 | 0.1329 | 0.0000 | +0.1328 | +0.9996 | 4.1056 | 4.2001 | +94.5 | 1.0156 | 0.703 | 1.016 |
| 19 | 13 | rest | 7121 | 150689.3 | 157888.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0414 | 4.0171 | -24.3 | 1.0156 | 0.328 | 1.016 |
| 19 | 14 | charge | 74 | 157889.3 | 157962.8 | 73.5 | 0.0207 | 0.0000 | +0.0205 | +0.9994 | 4.1753 | 4.2001 | +24.8 | 1.0156 | 0.625 | 1.016 |
| 19 | 15 | cv | 2525 | 157963.8 | 160515.0 | 2551.2 | 0.2619 | 0.0000 | +0.2619 | +0.3692 | 4.2006 | 4.2006 | +0.0 | 1.0156 | 0.219 | 1.016 |
| 19 | 16 | rest | 7122 | 160516.0 | 167715.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1855 | 4.1766 | -8.9 | 1.0156 | 0.719 | 1.016 |

### SP3_IC_OCV_0C

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 6 | 10.0 | 60.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0523 | 4.0524 | +0.2 | 10.0154 | 9.937 | 10.016 |
| 1 | 2 | charge | 4 | 70.0 | 92.8 | 22.8 | 0.0091 | 0.0000 | +0.0077 | +0.9994 | 4.1821 | 4.2001 | +18.0 | 10.0155 | 2.734 | 10.016 |
| 1 | 3 | cv | 217 | 102.8 | 2258.9 | 2156.1 | 0.1697 | 0.0000 | +0.1697 | +0.2793 | 4.2002 | 4.2002 | +0.0 | 10.0155 | 3.016 | 10.018 |
| 1 | 4 | rest | 719 | 2268.9 | 9458.9 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1887 | 4.1635 | -25.3 | 10.0155 | 9.672 | 10.016 |
| 1 | 5 | discharge | 653 | 9459.9 | 10117.9 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 4.0528 | 3.8920 | -160.8 | 1.0155 | 0.281 | 1.017 |
| 1 | 6 | rest | 7122 | 10118.9 | 17317.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9933 | 4.0405 | +47.2 | 1.0156 | 0.078 | 1.016 |
| 2 | 5 | discharge | 652 | 17319.0 | 17977.0 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.9315 | 3.7627 | -168.9 | 1.0156 | 0.781 | 1.017 |
| 2 | 6 | rest | 7125 | 17978.0 | 25177.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8706 | 3.9374 | +66.8 | 1.0155 | 0.531 | 1.016 |
| 3 | 5 | discharge | 653 | 25178.0 | 25836.0 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.8218 | 3.6633 | -158.5 | 1.0155 | 0.094 | 1.016 |
| 3 | 6 | rest | 7126 | 25837.0 | 33036.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7682 | 3.8440 | +75.8 | 1.0155 | 0.172 | 1.329 |
| 4 | 5 | discharge | 653 | 33037.0 | 33695.0 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.7270 | 3.5778 | -149.3 | 1.0155 | 0.015 | 1.017 |
| 4 | 6 | rest | 7125 | 33696.0 | 40895.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6821 | 3.7590 | +76.8 | 1.0155 | 1.000 | 1.017 |
| 5 | 5 | discharge | 653 | 40896.0 | 41554.0 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.6436 | 3.5154 | -128.2 | 1.0155 | 0.031 | 1.016 |
| 5 | 6 | rest | 7125 | 41555.0 | 48754.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6206 | 3.6710 | +50.4 | 1.0155 | 0.922 | 1.243 |
| 6 | 5 | discharge | 652 | 48755.1 | 49413.1 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.5622 | 3.4747 | -87.5 | 1.0155 | 0.984 | 1.016 |
| 6 | 6 | rest | 7125 | 49414.1 | 56613.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5789 | 3.6282 | +49.3 | 1.0155 | 0.234 | 1.016 |
| 7 | 5 | discharge | 653 | 56614.1 | 57272.1 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.5212 | 3.4173 | -103.9 | 1.0155 | 0.219 | 1.016 |
| 7 | 6 | rest | 7125 | 57273.1 | 64472.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5350 | 3.6009 | +66.0 | 1.0155 | 0.422 | 1.018 |
| 8 | 5 | discharge | 653 | 64473.1 | 65131.1 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.4783 | 3.3491 | -129.2 | 1.0155 | 0.172 | 1.016 |
| 8 | 6 | rest | 7124 | 65132.1 | 72331.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4828 | 3.5742 | +91.4 | 1.0155 | 0.297 | 1.019 |
| 9 | 5 | discharge | 653 | 72332.1 | 72990.1 | 658.0 | 0.0000 | 0.1831 | -0.1829 | -1.0001 | 3.4421 | 3.1645 | -277.6 | 1.0155 | 0.187 | 1.016 |
| 9 | 6 | rest | 7124 | 72991.1 | 80190.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.3533 | 3.4954 | +142.1 | 1.0155 | 0.906 | 1.016 |
| 10 | 5 | discharge | 419 | 80191.2 | 80613.2 | 422.0 | 0.0000 | 0.1175 | -0.1174 | -1.0001 | 3.3460 | 2.4999 | -846.1 | 1.0155 | 0.703 | 1.016 |
| 10 | 8 | rest | 7126 | 80614.2 | 87813.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.7534 | 3.4556 | +702.2 | 1.0155 | 0.203 | 1.018 |
| 10 | 9 | charge | 652 | 87814.2 | 88472.2 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9995 | 3.5933 | 3.7089 | +115.5 | 1.0155 | 0.953 | 1.016 |
| 10 | 10 | rest | 7126 | 88473.2 | 95672.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5954 | 3.5413 | -54.1 | 1.0155 | 0.687 | 1.017 |
| 11 | 9 | charge | 653 | 95673.3 | 96331.3 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9995 | 3.6625 | 3.7426 | +80.1 | 1.0155 | 0.219 | 1.016 |
| 11 | 10 | rest | 7126 | 96332.3 | 103531.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6423 | 3.5980 | -44.2 | 1.0155 | 0.703 | 1.016 |
| 12 | 9 | charge | 653 | 103532.3 | 104190.3 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9995 | 3.7189 | 3.7761 | +57.2 | 1.0155 | 0.234 | 1.016 |
| 12 | 10 | rest | 7126 | 104191.3 | 111390.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6735 | 3.6230 | -50.6 | 1.0155 | 0.281 | 1.078 |
| 13 | 9 | charge | 653 | 111391.3 | 112049.3 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9996 | 3.7356 | 3.8189 | +83.3 | 1.0154 | 0.359 | 1.016 |
| 13 | 10 | rest | 7127 | 112050.3 | 119249.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7165 | 3.6526 | -63.9 | 1.0154 | 0.328 | 1.299 |
| 14 | 9 | charge | 653 | 119250.3 | 119908.3 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9996 | 3.7564 | 3.8695 | +113.1 | 1.0154 | 0.187 | 1.016 |
| 14 | 10 | rest | 7124 | 119909.3 | 127108.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7708 | 3.7026 | -68.2 | 1.0154 | 1.000 | 1.018 |
| 15 | 9 | charge | 653 | 127109.4 | 127767.4 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9996 | 3.8079 | 3.9348 | +126.9 | 1.0154 | 0.391 | 1.016 |
| 15 | 10 | rest | 7126 | 127768.4 | 134967.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8408 | 3.7975 | -43.3 | 1.0154 | 0.563 | 1.056 |
| 16 | 9 | charge | 653 | 134968.4 | 135626.4 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9995 | 3.9055 | 4.0353 | +129.8 | 1.0154 | 0.063 | 1.018 |
| 16 | 10 | rest | 7126 | 135627.4 | 142826.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9375 | 3.8842 | -53.3 | 1.0154 | 0.219 | 1.024 |
| 17 | 9 | charge | 652 | 142827.4 | 143485.4 | 658.0 | 0.1830 | 0.0000 | +0.1828 | +0.9996 | 3.9868 | 4.1497 | +162.9 | 1.0155 | 0.984 | 1.017 |
| 17 | 10 | rest | 7126 | 143486.4 | 150685.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0477 | 3.9777 | -70.0 | 1.0154 | 0.312 | 1.018 |
| 18 | 9 | charge | 363 | 150686.4 | 151051.6 | 365.2 | 0.1017 | 0.0000 | +0.1015 | +0.9995 | 4.0795 | 4.2001 | +120.6 | 1.0154 | 0.313 | 1.016 |
| 18 | 13 | rest | 7126 | 151052.6 | 158251.6 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1006 | 4.0333 | -67.3 | 1.0154 | 0.250 | 1.024 |
| 18 | 14 | charge | 90 | 158252.6 | 158342.4 | 89.8 | 0.0252 | 0.0000 | +0.0251 | +0.9995 | 4.1440 | 4.2001 | +56.1 | 1.0154 | 0.938 | 1.016 |
| 18 | 15 | cv | 2307 | 158343.4 | 160673.0 | 2329.6 | 0.1977 | 0.0000 | +0.1977 | +0.3052 | 4.2002 | 4.2001 | -0.2 | 1.0154 | 0.687 | 1.016 |
| 18 | 16 | rest | 7127 | 160674.1 | 167873.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1907 | 4.1654 | -25.3 | 1.0154 | 0.937 | 1.018 |

### SP3_IC_OCV_25C

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 6 | 10.0 | 60.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1717 | 4.1719 | +0.2 | 10.0155 | 9.953 | 10.016 |
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9995 | 4.2733 | 4.2733 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 42 | 70.0 | 480.2 | 410.2 | 0.0184 | 0.0000 | +0.0194 | +0.1555 | 4.2001 | 4.2001 | +0.0 | 10.0155 | 9.578 | 10.016 |
| 1 | 4 | rest | 720 | 490.2 | 7680.2 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1889 | 4.1835 | -5.3 | 10.0155 | 0.250 | 10.016 |
| 1 | 5 | discharge | 713 | 7681.2 | 8400.2 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 4.0794 | 3.9300 | -149.4 | 1.0155 | 0.687 | 1.016 |
| 1 | 6 | rest | 7127 | 8401.2 | 15600.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0337 | 4.0580 | +24.3 | 1.0155 | 0.687 | 1.016 |
| 2 | 5 | discharge | 713 | 15601.3 | 16320.3 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.9534 | 3.8123 | -141.1 | 1.0155 | 0.625 | 1.016 |
| 2 | 6 | rest | 7127 | 16321.3 | 23520.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9158 | 3.9475 | +31.8 | 1.0155 | 0.219 | 1.016 |
| 3 | 5 | discharge | 713 | 23521.3 | 24240.3 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.8435 | 3.7005 | -143.0 | 1.0155 | 0.672 | 1.016 |
| 3 | 6 | rest | 7127 | 24241.3 | 31440.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8038 | 3.8471 | +43.3 | 1.0155 | 0.391 | 1.016 |
| 4 | 5 | discharge | 713 | 31441.3 | 32160.3 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.7428 | 3.6034 | -139.3 | 1.0156 | 0.469 | 1.016 |
| 4 | 6 | rest | 7127 | 32161.4 | 39360.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7063 | 3.7591 | +52.8 | 1.0155 | 0.672 | 1.016 |
| 5 | 5 | discharge | 713 | 39361.4 | 40080.4 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.6550 | 3.5398 | -115.2 | 1.0156 | 0.547 | 1.016 |
| 5 | 6 | rest | 7127 | 40081.4 | 47280.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6425 | 3.6710 | +28.5 | 1.0155 | 0.125 | 1.016 |
| 6 | 5 | discharge | 713 | 47281.4 | 48000.4 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.5676 | 3.4980 | -69.7 | 1.0156 | 0.423 | 1.016 |
| 6 | 6 | rest | 7126 | 48001.4 | 55200.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6012 | 3.6287 | +27.5 | 1.0156 | 0.469 | 1.016 |
| 7 | 5 | discharge | 713 | 55201.5 | 55920.5 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0002 | 3.5255 | 3.4619 | -63.7 | 1.0156 | 0.547 | 1.016 |
| 7 | 6 | rest | 7126 | 55921.5 | 63120.5 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5655 | 3.6013 | +35.8 | 1.0156 | 0.266 | 1.054 |
| 8 | 5 | discharge | 713 | 63121.5 | 63840.5 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0002 | 3.4978 | 3.4163 | -81.5 | 1.0156 | 0.453 | 1.016 |
| 8 | 6 | rest | 7126 | 63841.5 | 71040.5 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5216 | 3.5621 | +40.5 | 1.0156 | 0.266 | 1.016 |
| 9 | 5 | discharge | 713 | 71041.5 | 71760.5 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0002 | 3.4565 | 3.3284 | -128.1 | 1.0156 | 0.531 | 1.016 |
| 9 | 6 | rest | 7127 | 71761.6 | 78960.6 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4392 | 3.4714 | +32.2 | 1.0156 | 0.219 | 1.053 |
| 10 | 5 | discharge | 698 | 78961.6 | 79665.1 | 703.5 | 0.0000 | 0.1957 | -0.1956 | -1.0002 | 3.3609 | 2.5000 | -861.0 | 1.0156 | 0.250 | 1.016 |
| 10 | 8 | rest | 7127 | 79666.1 | 86865.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.7266 | 3.2976 | +571.0 | 1.0155 | 0.875 | 1.016 |
| 10 | 9 | charge | 713 | 86866.1 | 87585.1 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.4215 | 3.6277 | +206.2 | 1.0155 | 0.750 | 1.016 |
| 10 | 10 | rest | 7129 | 87586.1 | 94785.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5215 | 3.4875 | -34.0 | 1.0155 | 0.156 | 1.016 |
| 11 | 9 | charge | 713 | 94786.1 | 95505.1 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.5966 | 3.7092 | +112.6 | 1.0155 | 0.922 | 1.016 |
| 11 | 10 | rest | 7129 | 95506.1 | 102705.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6056 | 3.5809 | -24.6 | 1.0155 | 0.594 | 1.016 |
| 12 | 9 | charge | 713 | 102706.2 | 103425.2 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.6859 | 3.7410 | +55.1 | 1.0155 | 0.859 | 1.016 |
| 12 | 10 | rest | 7127 | 103426.2 | 110625.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6383 | 3.6124 | -25.9 | 1.0155 | 1.000 | 1.016 |
| 13 | 9 | charge | 713 | 110626.2 | 111345.2 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.7211 | 3.7774 | +56.4 | 1.0155 | 0.766 | 1.016 |
| 13 | 10 | rest | 7128 | 111346.2 | 118545.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6710 | 3.6401 | -30.9 | 1.0155 | 0.266 | 1.016 |
| 14 | 9 | charge | 713 | 118546.2 | 119265.2 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +0.9999 | 3.7462 | 3.8281 | +82.0 | 1.0155 | 0.594 | 1.016 |
| 14 | 10 | rest | 7127 | 119266.2 | 126465.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7228 | 3.6801 | -42.8 | 1.0155 | 1.000 | 1.017 |
| 15 | 9 | charge | 713 | 126466.3 | 127185.3 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +0.9999 | 3.7862 | 3.9015 | +115.3 | 1.0155 | 0.766 | 1.016 |
| 15 | 10 | rest | 7128 | 127186.3 | 134385.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7975 | 3.7722 | -25.3 | 1.0155 | 0.219 | 1.016 |
| 16 | 9 | charge | 713 | 134386.3 | 135105.3 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +0.9999 | 3.8774 | 3.9947 | +117.3 | 1.0155 | 0.656 | 1.016 |
| 16 | 10 | rest | 7127 | 135106.3 | 142305.3 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8908 | 3.8613 | -29.5 | 1.0155 | 0.453 | 1.021 |
| 17 | 9 | charge | 713 | 142306.4 | 143025.4 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +0.9999 | 3.9660 | 4.1016 | +135.6 | 1.0155 | 0.797 | 1.016 |
| 17 | 10 | rest | 7129 | 143026.4 | 150225.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9979 | 3.9613 | -36.6 | 1.0155 | 0.063 | 1.546 |
| 18 | 9 | charge | 713 | 150226.4 | 150945.4 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 4.0658 | 4.2208 | +155.0 | 1.0155 | 0.984 | 1.016 |
| 18 | 10 | rest | 7129 | 150946.4 | 158145.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1165 | 4.0705 | -46.0 | 1.0155 | 0.969 | 1.016 |
| 19 | 12 | charge | 51 | 158146.4 | 158196.8 | 50.4 | 0.0143 | 0.0000 | +0.0141 | +0.9999 | 4.1751 | 4.2001 | +24.9 | 1.0156 | 0.844 | 1.016 |
| 19 | 13 | rest | 7128 | 158197.8 | 165396.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0956 | 4.0778 | -17.8 | 1.0155 | 0.672 | 1.016 |
| 19 | 14 | charge | 30 | 165397.8 | 165426.6 | 28.7 | 0.0083 | 0.0000 | +0.0081 | +0.9999 | 4.1824 | 4.2001 | +17.7 | 1.0155 | 0.422 | 1.016 |
| 19 | 15 | cv | 1636 | 165427.6 | 167078.4 | 1650.8 | 0.1493 | 0.0000 | +0.1494 | +0.3252 | 4.1999 | 4.2001 | +0.2 | 1.0155 | 0.609 | 1.017 |
| 19 | 16 | rest | 7128 | 167079.4 | 174278.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1894 | 4.1732 | -16.2 | 1.0155 | 0.750 | 1.016 |

### SP3_IC_OCV_45C

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 6 | 10.0 | 60.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1792 | 4.1790 | -0.2 | 10.0154 | 9.937 | 10.016 |
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9995 | 4.2516 | 4.2516 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 34 | 70.0 | 395.4 | 325.4 | 0.0151 | 0.0000 | +0.0161 | +0.1590 | 4.2001 | 4.1999 | -0.2 | 10.0155 | 4.984 | 10.016 |
| 1 | 4 | rest | 720 | 405.4 | 7595.4 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1920 | 4.1887 | -3.2 | 10.0155 | 1.125 | 10.016 |
| 1 | 5 | discharge | 712 | 7596.4 | 8315.4 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 4.1137 | 3.9751 | -138.7 | 1.0156 | 0.641 | 1.016 |
| 1 | 6 | rest | 7124 | 8316.4 | 15515.4 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.0505 | 4.0648 | +14.3 | 1.0156 | 0.250 | 1.016 |
| 2 | 5 | discharge | 713 | 15516.5 | 16235.5 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.9893 | 3.8617 | -127.6 | 1.0156 | 0.250 | 1.016 |
| 2 | 6 | rest | 7118 | 16236.5 | 23435.5 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9373 | 3.9556 | +18.3 | 1.0156 | 0.187 | 1.016 |
| 3 | 5 | discharge | 712 | 23436.5 | 24155.5 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0002 | 3.8782 | 3.7543 | -123.9 | 1.0156 | 0.484 | 1.016 |
| 3 | 6 | rest | 7117 | 24156.5 | 31355.5 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8320 | 3.8552 | +23.2 | 1.0156 | 0.922 | 1.016 |
| 4 | 5 | discharge | 712 | 31356.6 | 32075.5 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.7781 | 3.6537 | -124.4 | 1.0156 | 0.641 | 1.016 |
| 4 | 6 | rest | 7118 | 32076.5 | 39275.6 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7306 | 3.7659 | +35.3 | 1.0156 | 0.375 | 1.016 |
| 5 | 5 | discharge | 712 | 39276.6 | 39995.6 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.6888 | 3.5829 | -105.9 | 1.0156 | 0.594 | 1.016 |
| 5 | 6 | rest | 7122 | 39996.6 | 47195.6 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6592 | 3.6778 | +18.6 | 1.0156 | 0.938 | 1.016 |
| 6 | 5 | discharge | 713 | 47196.6 | 47915.6 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.6012 | 3.5406 | -60.6 | 1.0156 | 0.281 | 1.016 |
| 6 | 6 | rest | 7123 | 47916.6 | 55115.6 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6171 | 3.6355 | +18.5 | 1.0156 | 0.703 | 1.016 |
| 7 | 5 | discharge | 713 | 55116.7 | 55835.7 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.5592 | 3.5063 | -53.0 | 1.0155 | 0.688 | 1.016 |
| 7 | 6 | rest | 7122 | 55836.7 | 63035.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5827 | 3.6080 | +25.3 | 1.0156 | 0.734 | 1.016 |
| 8 | 5 | discharge | 712 | 63036.7 | 63755.7 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.5315 | 3.4630 | -68.5 | 1.0156 | 0.875 | 1.016 |
| 8 | 6 | rest | 7124 | 63756.7 | 70955.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5401 | 3.5612 | +21.1 | 1.0156 | 0.109 | 1.016 |
| 9 | 5 | discharge | 713 | 70956.7 | 71675.7 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.4842 | 3.3793 | -105.0 | 1.0155 | 0.437 | 1.016 |
| 9 | 6 | rest | 7123 | 71676.8 | 78875.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4577 | 3.4771 | +19.4 | 1.0156 | 0.969 | 1.016 |
| 10 | 5 | discharge | 713 | 78876.8 | 79595.8 | 719.0 | 0.0000 | 0.2000 | -0.1999 | -1.0001 | 3.3985 | 3.1985 | -200.1 | 1.0156 | 0.015 | 1.016 |
| 10 | 6 | rest | 7123 | 79596.8 | 86795.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.2825 | 3.3392 | +56.7 | 1.0156 | 0.906 | 1.016 |
| 11 | 9 | charge | 712 | 86796.8 | 87515.8 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +0.9999 | 3.4228 | 3.5876 | +164.7 | 1.0156 | 0.719 | 1.016 |
| 11 | 10 | rest | 7124 | 87516.8 | 94715.8 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5098 | 3.4918 | -18.0 | 1.0155 | 0.016 | 1.019 |
| 12 | 9 | charge | 713 | 94716.9 | 95435.8 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.5701 | 3.6747 | +104.6 | 1.0155 | 0.484 | 1.016 |
| 12 | 10 | rest | 7123 | 95436.9 | 102635.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.5979 | 3.5803 | -17.7 | 1.0156 | 0.578 | 1.016 |
| 13 | 9 | charge | 713 | 102636.9 | 103355.9 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +1.0000 | 3.6571 | 3.7105 | +53.5 | 1.0156 | 0.125 | 1.016 |
| 13 | 10 | rest | 7124 | 103356.9 | 110555.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6341 | 3.6166 | -17.5 | 1.0156 | 0.250 | 1.016 |
| 14 | 9 | charge | 713 | 110556.9 | 111275.9 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.6930 | 3.7421 | +49.1 | 1.0156 | 0.390 | 1.016 |
| 14 | 10 | rest | 7123 | 111276.9 | 118475.9 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6658 | 3.6452 | -20.6 | 1.0156 | 0.282 | 1.016 |
| 15 | 9 | charge | 713 | 118477.0 | 119196.0 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +1.0000 | 3.7220 | 3.7894 | +67.4 | 1.0155 | 0.562 | 1.016 |
| 15 | 10 | rest | 7122 | 119197.0 | 126396.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7126 | 3.6866 | -26.1 | 1.0156 | 0.453 | 1.016 |
| 16 | 9 | charge | 713 | 126397.0 | 127116.0 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +1.0000 | 3.7637 | 3.8678 | +104.2 | 1.0156 | 0.062 | 1.016 |
| 16 | 10 | rest | 7117 | 127117.0 | 134316.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7917 | 3.7753 | -16.4 | 1.0156 | 0.312 | 1.016 |
| 17 | 9 | charge | 713 | 134317.1 | 135036.1 | 719.0 | 0.2000 | 0.0000 | +0.1998 | +0.9999 | 3.8518 | 3.9602 | +108.4 | 1.0156 | 0.344 | 1.016 |
| 17 | 10 | rest | 7119 | 135037.1 | 142236.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.8843 | 3.8651 | -19.3 | 1.0156 | 0.734 | 1.016 |
| 18 | 9 | charge | 712 | 142237.1 | 142956.1 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +0.9999 | 3.9409 | 4.0643 | +123.4 | 1.0156 | 0.812 | 1.016 |
| 18 | 10 | rest | 7119 | 142957.1 | 150156.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9883 | 3.9652 | -23.2 | 1.0156 | 0.703 | 1.016 |
| 19 | 12 | charge | 713 | 150157.1 | 150876.1 | 719.0 | 0.2000 | 0.0000 | +0.1999 | +1.0000 | 4.0412 | 4.1774 | +136.2 | 1.0156 | 0.015 | 1.016 |
| 19 | 13 | rest | 7117 | 150877.1 | 158076.1 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1013 | 4.0737 | -27.5 | 1.0156 | 0.812 | 1.062 |
| 19 | 14 | charge | 182 | 158077.2 | 158259.6 | 182.5 | 0.0510 | 0.0000 | +0.0508 | +0.9998 | 4.1498 | 4.2001 | +50.2 | 1.0156 | 0.469 | 1.016 |
| 19 | 15 | cv | 1340 | 158260.7 | 159614.0 | 1353.3 | 0.1347 | 0.0000 | +0.1347 | +0.3576 | 4.2001 | 4.2001 | +0.0 | 1.0156 | 0.234 | 1.016 |
| 19 | 16 | rest | 7122 | 159615.0 | 166814.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1925 | 4.1822 | -10.2 | 1.0156 | 0.594 | 1.016 |

### SP1_INITCAP

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 60 | 1.0 | 60.0 | 59.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4343 | 3.4346 | +0.3 | 1.0151 | 0.423 | 1.016 |
| 1 | 2 | charge | 6128 | 61.0 | 6251.9 | 6190.9 | 1.7199 | 0.0000 | +1.7198 | +1.0000 | 3.5830 | 4.2001 | +617.1 | 1.0155 | 0.031 | 1.017 |
| 1 | 3 | cv | 5009 | 6252.9 | 11312.3 | 5059.4 | 0.2764 | 0.0000 | +0.2764 | +0.1965 | 4.1999 | 4.1996 | -0.3 | 1.0155 | 0.859 | 1.017 |
| 1 | 4 | rest | 1 | 11312.5 | 11312.5 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0001 | 4.1972 | 4.1972 | +0.0 | -- | -- | -- |
| 1 | 5 | rest | 1782 | 11313.5 | 13112.5 | 1799.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1973 | 4.1922 | -5.2 | 1.0155 | 0.125 | 1.016 |
| 1 | 6 | discharge | 7157 | 13113.6 | 20345.8 | 7232.2 | 0.0000 | 2.0094 | -2.0093 | -1.0001 | 4.0666 | 2.4999 | -1566.7 | 1.0155 | 1.000 | 1.017 |
| 1 | 7 | rest | 1 | 20346.0 | 20346.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0001 | 2.6321 | 2.6321 | +0.0 | -- | -- | -- |
| 1 | 8 | rest | 1780 | 20347.0 | 22146.0 | 1799.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.8205 | 3.3881 | +567.5 | 1.0156 | 0.734 | 1.017 |
| 1 | 9 | charge | 626 | 22156.0 | 28411.9 | 6255.9 | 1.7404 | 0.0000 | +1.7390 | +1.0000 | 3.5457 | 4.2001 | +654.4 | 10.0155 | 7.656 | 10.016 |
| 1 | 10 | cv | 4760 | 28412.9 | 33221.1 | 4808.2 | 0.2688 | 0.0000 | +0.2688 | +0.2010 | 4.1999 | 4.1996 | -0.3 | 1.0155 | 0.719 | 1.016 |
| 1 | 11 | rest | 1 | 33221.3 | 33221.3 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0003 | 4.1975 | 4.1975 | +0.0 | -- | -- | -- |
| 1 | 12 | rest | 297 | 33222.3 | 33521.3 | 299.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1975 | 4.1959 | -1.6 | 1.0156 | 0.797 | 1.017 |

### SP2_INITCAP

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 60 | 1.0 | 60.0 | 59.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4414 | 3.4412 | -0.2 | 1.0155 | 0.376 | 1.016 |
| 1 | 2 | charge | 6409 | 61.0 | 6536.7 | 6475.7 | 1.7992 | 0.0000 | +1.7991 | +1.0001 | 3.5246 | 4.2001 | +675.6 | 1.0155 | 0.937 | 1.017 |
| 1 | 3 | cv | 4213 | 6537.7 | 10792.9 | 4255.2 | 0.1984 | 0.0000 | +0.1984 | +0.1677 | 4.2000 | 4.1998 | -0.2 | 1.0155 | 0.031 | 1.017 |
| 1 | 4 | rest | 1 | 10793.1 | 10793.1 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0002 | 4.1985 | 4.1985 | +0.0 | -- | -- | -- |
| 1 | 5 | rest | 1782 | 10794.2 | 12593.1 | 1799.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1988 | 4.1937 | -5.2 | 1.0155 | 0.641 | 1.017 |
| 1 | 6 | discharge | 7224 | 12594.2 | 19893.3 | 7299.2 | 0.0000 | 2.0283 | -2.0282 | -1.0003 | 4.1242 | 2.5000 | -1624.2 | 1.0155 | 0.172 | 1.017 |
| 1 | 7 | rest | 1 | 19893.5 | 19893.5 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0002 | 2.5740 | 2.5740 | +0.0 | -- | -- | -- |
| 1 | 8 | rest | 1780 | 19894.6 | 21693.5 | 1799.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.7653 | 3.3407 | +575.4 | 1.0156 | 0.609 | 1.018 |
| 1 | 9 | charge | 664 | 21703.6 | 28335.9 | 6632.3 | 1.8452 | 0.0000 | +1.8438 | +1.0000 | 3.4472 | 4.2001 | +752.9 | 10.0155 | 3.406 | 10.016 |
| 1 | 10 | cv | 3890 | 28336.9 | 32265.3 | 3928.5 | 0.1889 | 0.0000 | +0.1889 | +0.1729 | 4.2000 | 4.1998 | -0.2 | 1.0155 | 0.172 | 1.016 |
| 1 | 11 | rest | 1 | 32265.5 | 32265.5 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0025 | 4.1990 | 4.1990 | +0.0 | -- | -- | -- |
| 1 | 12 | rest | 297 | 32266.6 | 32565.6 | 299.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1988 | 4.1972 | -1.6 | 1.0155 | 0.969 | 1.017 |

### SP3_INITCAP

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 60 | 1.0 | 60.0 | 59.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4475 | 3.4477 | +0.2 | 1.0156 | 0.312 | 1.017 |
| 1 | 2 | charge | 5904 | 61.0 | 6025.9 | 5964.9 | 1.6567 | 0.0000 | +1.6566 | +0.9997 | 3.6140 | 4.2000 | +586.0 | 1.0155 | 0.579 | 1.018 |
| 1 | 3 | cv | 5721 | 6026.9 | 11806.2 | 5779.3 | 0.3128 | 0.0000 | +0.3128 | +0.1947 | 4.2002 | 4.1997 | -0.5 | 1.0155 | 0.578 | 1.017 |
| 1 | 4 | rest | 1 | 11806.4 | 11806.4 | 0.0 | 0.0000 | 0.0000 | +0.0000 | -0.0002 | 4.1973 | 4.1973 | +0.0 | -- | -- | -- |
| 1 | 5 | rest | 1782 | 11807.5 | 13606.4 | 1799.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1974 | 4.1930 | -4.4 | 1.0155 | 0.141 | 1.017 |
| 1 | 6 | discharge | 7043 | 13607.5 | 20723.9 | 7116.4 | 0.0000 | 1.9775 | -1.9774 | -1.0002 | 4.0419 | 2.4999 | -1542.0 | 1.0155 | 0.859 | 1.017 |
| 1 | 7 | rest | 1 | 20724.1 | 20724.1 | 0.0 | 0.0000 | 0.0000 | +0.0000 | -0.0004 | 2.6731 | 2.6731 | +0.0 | -- | -- | -- |
| 1 | 8 | rest | 1780 | 20725.1 | 22524.1 | 1799.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.8636 | 3.4034 | +539.8 | 1.0156 | 0.813 | 1.017 |
| 1 | 9 | charge | 592 | 22534.1 | 28448.3 | 5914.3 | 1.6451 | 0.0000 | +1.6438 | +0.9997 | 3.6202 | 4.2000 | +579.8 | 10.0155 | 6.328 | 10.017 |
| 1 | 10 | cv | 5928 | 28449.4 | 34439.2 | 5989.8 | 0.3422 | 0.0000 | +0.3422 | +0.2056 | 4.2002 | 4.1998 | -0.3 | 1.0155 | 0.234 | 1.017 |
| 1 | 11 | rest | 1 | 34439.4 | 34439.4 | 0.0 | 0.0000 | 0.0000 | +0.0000 | -0.0004 | 4.1969 | 4.1969 | +0.0 | -- | -- | -- |
| 1 | 12 | rest | 297 | 34440.4 | 34739.4 | 299.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1971 | 4.1958 | -1.3 | 1.0155 | 0.828 | 1.016 |

### SP2_0C_DST_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4669 | 3.4669 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 543 | 70.0 | 5492.5 | 5422.5 | 1.5087 | 0.0000 | +1.5073 | +0.9998 | 3.6140 | 4.2001 | +586.1 | 10.0155 | 5.156 | 10.016 |
| 1 | 3 | cv | 521 | 5502.5 | 10705.6 | 5203.0 | 0.2591 | 0.0000 | +0.2591 | +0.1778 | 4.1997 | 4.1997 | +0.0 | 10.0154 | 6.219 | 10.016 |
| 1 | 4 | rest | 6 | 10715.6 | 10765.6 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1970 | 4.1965 | -0.5 | 10.0001 | 9.984 | 10.015 |
| 1 | 5 | discharge | 325 | 10775.6 | 14017.6 | 3242.0 | 0.0000 | 0.9034 | -0.9021 | -1.0001 | 4.0648 | 3.5367 | -528.1 | 10.0154 | 7.906 | 10.016 |
| 1 | 6 | rest | 720 | 14027.6 | 21217.6 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6478 | 3.6948 | +47.0 | 10.0154 | 0.750 | 10.017 |
| 1 | 7 | dynamic | 5957 | 21218.6 | 27224.8 | 6006.2 | 0.1442 | 1.0301 | -0.8886 | -0.5322 | 3.6948 | 2.5000 | -1194.9 | 1.0155 | 0.172 | 1.019 |

### SP2_0C_DST_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9994 | 4.2470 | 4.2470 | +0.0 | -- | -- | -- |
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1541 | 4.1541 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 201 | 70.0 | 2066.8 | 1996.8 | 0.0487 | 0.0000 | +0.0496 | +0.0862 | 4.1997 | 4.1997 | +0.0 | 10.0155 | 3.938 | 10.016 |
| 1 | 4 | rest | 6 | 2076.8 | 2126.8 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1970 | 4.1963 | -0.6 | 10.0155 | 9.937 | 10.016 |
| 1 | 5 | discharge | 130 | 2136.8 | 3427.8 | 1291.0 | 0.0000 | 0.3615 | -0.3601 | -1.0002 | 4.0599 | 3.8087 | -251.2 | 10.0155 | 9.125 | 10.016 |
| 1 | 6 | rest | 420 | 3437.8 | 7627.8 | 4190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9235 | 3.9676 | +44.1 | 10.0155 | 4.125 | 10.016 |
| 1 | 7 | dynamic | 9527 | 7628.9 | 17236.9 | 9608.0 | 0.2330 | 1.6545 | -1.4260 | -0.5338 | 3.9674 | 2.4990 | -1468.5 | 1.0155 | 0.125 | 1.018 |

### SP2_0C_FUDS_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4761 | 3.4761 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 540 | 70.0 | 5466.0 | 5396.0 | 1.5013 | 0.0000 | +1.4999 | +0.9998 | 3.6248 | 4.2001 | +575.2 | 10.0155 | 8.141 | 10.016 |
| 1 | 3 | cv | 501 | 5476.1 | 10479.1 | 5003.0 | 0.2447 | 0.0000 | +0.2447 | +0.1746 | 4.2001 | 4.1996 | -0.5 | 10.0155 | 6.047 | 10.016 |
| 1 | 4 | rest | 6 | 10489.1 | 10539.1 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1971 | 4.1963 | -0.8 | 10.0151 | 9.953 | 10.016 |
| 1 | 5 | discharge | 325 | 10549.1 | 13791.1 | 3242.0 | 0.0000 | 0.9035 | -0.9021 | -1.0001 | 4.0661 | 3.5406 | -525.5 | 10.0155 | 7.594 | 10.016 |
| 1 | 6 | rest | 719 | 13801.1 | 20991.1 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6495 | 3.6956 | +46.2 | 10.0155 | 9.875 | 10.017 |
| 1 | 7 | dynamic | 6961 | 20992.1 | 28020.6 | 7028.5 | 0.2291 | 1.2191 | -0.9897 | -0.5069 | 3.6956 | 2.5000 | -1195.7 | 1.0155 | 0.078 | 1.026 |

### SP2_0C_FUDS_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4713 | 3.4713 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 546 | 70.0 | 5519.4 | 5449.4 | 1.5162 | 0.0000 | +1.5148 | +0.9998 | 3.6196 | 4.2001 | +580.4 | 10.0155 | 2.000 | 10.017 |
| 1 | 3 | cv | 498 | 5529.4 | 10506.0 | 4976.6 | 0.2637 | 0.0000 | +0.2637 | +0.1894 | 4.1999 | 4.1997 | -0.2 | 10.0155 | 10.000 | 10.016 |
| 1 | 4 | rest | 6 | 10516.1 | 10566.1 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1968 | 4.1962 | -0.6 | 10.0155 | 9.937 | 10.016 |
| 1 | 5 | discharge | 130 | 10576.1 | 11867.1 | 1291.0 | 0.0000 | 0.3614 | -0.3600 | -1.0001 | 4.0633 | 3.8087 | -254.7 | 10.0155 | 9.109 | 10.016 |
| 1 | 6 | rest | 720 | 11877.1 | 19067.1 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9232 | 3.9661 | +42.9 | 10.0155 | 0.469 | 10.016 |
| 1 | 7 | dynamic | 9707 | 19068.1 | 28871.9 | 9803.7 | 0.3205 | 1.7120 | -1.3926 | -0.5115 | 3.9661 | 2.4995 | -1466.7 | 1.0155 | 0.141 | 1.018 |

### SP2_0C_US06_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4337 | 3.4337 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 565 | 70.0 | 5710.1 | 5640.1 | 1.5691 | 0.0000 | +1.5677 | +0.9997 | 3.5908 | 4.2001 | +609.3 | 10.0155 | 1.937 | 10.016 |
| 1 | 3 | cv | 516 | 5720.1 | 10869.3 | 5149.1 | 0.2515 | 0.0000 | +0.2515 | +0.1743 | 4.1999 | 4.1997 | -0.2 | 10.0155 | 1.719 | 10.016 |
| 1 | 4 | rest | 6 | 10879.3 | 10929.3 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1970 | 4.1963 | -0.6 | 10.0154 | 9.937 | 10.016 |
| 1 | 5 | discharge | 325 | 10939.3 | 14181.3 | 3242.0 | 0.0000 | 0.9035 | -0.9021 | -1.0002 | 4.0658 | 3.5484 | -517.4 | 10.0155 | 7.312 | 10.016 |
| 1 | 6 | rest | 719 | 14191.3 | 21381.3 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6524 | 3.6958 | +43.4 | 10.0155 | 9.609 | 10.016 |
| 1 | 7 | dynamic | 5918 | 21382.3 | 27359.4 | 5977.1 | 0.1089 | 1.0245 | -0.9162 | -0.5517 | 3.6958 | 2.4595 | -1236.3 | 1.0156 | 0.125 | 1.017 |

### SP2_0C_US06_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4463 | 3.4463 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 589 | 70.0 | 5954.9 | 5884.8 | 1.6371 | 0.0000 | +1.6357 | +0.9998 | 3.6276 | 4.2001 | +572.5 | 10.0155 | 6.703 | 10.016 |
| 1 | 3 | cv | 507 | 5964.9 | 11026.7 | 5061.8 | 0.2475 | 0.0000 | +0.2475 | +0.1745 | 4.1999 | 4.1997 | -0.2 | 10.0155 | 4.625 | 10.016 |
| 1 | 4 | rest | 6 | 11036.7 | 11086.7 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1970 | 4.1963 | -0.6 | 10.0155 | 9.938 | 10.016 |
| 1 | 5 | discharge | 130 | 11096.7 | 12387.7 | 1291.0 | 0.0000 | 0.3614 | -0.3600 | -1.0001 | 4.0635 | 3.8087 | -254.8 | 10.0155 | 9.219 | 10.016 |
| 1 | 6 | rest | 719 | 12397.7 | 19587.7 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9232 | 3.9663 | +43.1 | 10.0155 | 9.859 | 10.016 |
| 1 | 7 | dynamic | 9482 | 19588.8 | 29165.8 | 9577.0 | 0.1749 | 1.6412 | -1.4687 | -0.5519 | 3.9663 | 2.4995 | -1466.8 | 1.0155 | 0.094 | 1.018 |

### SP2_0C_BJDST_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4578 | 3.4578 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 581 | 70.0 | 5877.3 | 5807.3 | 1.6155 | 0.0000 | +1.6141 | +0.9997 | 3.6349 | 4.2001 | +565.2 | 10.0155 | 8.500 | 10.016 |
| 1 | 3 | cv | 517 | 5887.3 | 11052.0 | 5164.7 | 0.2455 | 0.0000 | +0.2455 | +0.1697 | 4.1997 | 4.1999 | +0.2 | 10.0155 | 6.703 | 10.016 |
| 1 | 4 | rest | 6 | 11062.0 | 11112.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1973 | 4.1965 | -0.8 | 10.0155 | 9.937 | 10.016 |
| 1 | 5 | discharge | 325 | 11122.0 | 14364.0 | 3242.0 | 0.0000 | 0.9035 | -0.9021 | -1.0002 | 4.0672 | 3.5399 | -527.3 | 10.0155 | 7.000 | 10.016 |
| 1 | 6 | rest | 7112 | 14365.0 | 21564.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6402 | 3.6963 | +56.0 | 1.0156 | 0.219 | 1.016 |
| 1 | 7 | dynamic | 6018 | 21565.0 | 27649.1 | 6084.1 | 0.0269 | 0.9319 | -0.9054 | -0.5355 | 3.6833 | 2.5000 | -1183.3 | 1.0156 | 0.016 | 1.019 |

### SP2_0C_BJDST_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4671 | 3.4671 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 563 | 70.0 | 5692.6 | 5622.6 | 1.5642 | 0.0000 | +1.5628 | +0.9997 | 3.6349 | 4.2001 | +565.2 | 10.0155 | 4.594 | 10.016 |
| 1 | 3 | cv | 514 | 5702.6 | 10838.9 | 5136.4 | 0.2457 | 0.0000 | +0.2457 | +0.1709 | 4.2001 | 4.1996 | -0.5 | 10.0155 | 9.062 | 10.017 |
| 1 | 4 | rest | 6 | 10849.0 | 10899.0 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1971 | 4.1965 | -0.6 | 10.0155 | 9.937 | 10.016 |
| 1 | 5 | discharge | 130 | 10909.0 | 12200.0 | 1291.0 | 0.0000 | 0.3615 | -0.3601 | -1.0002 | 4.0682 | 3.8163 | -251.9 | 10.0155 | 9.187 | 10.016 |
| 1 | 6 | rest | 7121 | 12201.0 | 19400.0 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9150 | 3.9663 | +51.4 | 1.0155 | 0.906 | 1.016 |
| 1 | 7 | dynamic | 10172 | 19401.0 | 29680.5 | 10279.5 | 0.0457 | 1.5551 | -1.5100 | -0.5288 | 3.9543 | 2.5000 | -1454.4 | 1.0156 | 0.063 | 1.018 |

### SP2_25C_DST_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4351 | 3.4351 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 649 | 70.0 | 6548.4 | 6478.4 | 1.8020 | 0.0000 | +1.8007 | +0.9998 | 3.5364 | 4.2001 | +663.7 | 10.0155 | 0.234 | 10.016 |
| 1 | 3 | cv | 353 | 6558.4 | 10074.6 | 3516.2 | 0.1822 | 0.0000 | +0.1822 | +0.1842 | 4.1997 | 4.1997 | +0.0 | 10.0155 | 1.688 | 10.016 |
| 1 | 4 | rest | 720 | 10084.7 | 17274.7 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1982 | 4.1893 | -8.9 | 10.0155 | 0.453 | 10.138 |
| 1 | 5 | discharge | 360 | 17284.7 | 20874.7 | 3590.0 | 0.0000 | 1.0002 | -0.9988 | -1.0002 | 4.1096 | 3.5777 | -532.0 | 10.0155 | 5.296 | 10.016 |
| 1 | 6 | rest | 720 | 20884.7 | 28074.7 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6544 | 3.6845 | +30.1 | 10.0155 | 0.906 | 10.016 |
| 1 | 7 | dynamic | 6685 | 28075.7 | 34816.1 | 6740.4 | 0.1620 | 1.1645 | -1.0067 | -0.5373 | 3.6847 | 2.4997 | -1185.0 | 1.0154 | 0.344 | 1.034 |

### SP2_25C_DST_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9382 | 3.9382 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 102 | 70.0 | 1077.9 | 1007.9 | 0.2827 | 0.0000 | +0.2813 | +0.9998 | 4.0201 | 4.2001 | +180.0 | 10.0155 | 6.656 | 10.016 |
| 1 | 3 | cv | 229 | 1087.9 | 3363.4 | 2275.5 | 0.1405 | 0.0000 | +0.1405 | +0.2185 | 4.1998 | 4.1997 | -0.2 | 10.0155 | 2.484 | 10.016 |
| 1 | 4 | rest | 720 | 3373.4 | 10563.4 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1980 | 4.1933 | -4.7 | 10.0155 | 1.016 | 10.016 |
| 1 | 5 | discharge | 144 | 10573.4 | 12003.4 | 1430.0 | 0.0000 | 0.4001 | -0.3987 | -1.0001 | 4.1130 | 3.8472 | -265.8 | 10.0155 | 8.172 | 10.016 |
| 1 | 6 | rest | 720 | 12013.4 | 19203.4 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9291 | 3.9534 | +24.3 | 10.0155 | 0.703 | 10.017 |
| 1 | 7 | dynamic | 10621 | 19204.5 | 29914.7 | 10710.2 | 0.2595 | 1.8559 | -1.5991 | -0.5365 | 3.9534 | 2.4034 | -1550.1 | 1.0155 | 0.156 | 1.032 |

### SP2_25C_FUDS_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 1005.9 | 1005.9 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.7773 | 3.7773 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 221 | 1015.9 | 3214.1 | 2198.1 | 0.6133 | 0.0000 | +0.6120 | +1.0000 | 3.8620 | 4.2001 | +338.2 | 10.0154 | 5.500 | 10.016 |
| 1 | 3 | cv | 287 | 3224.1 | 6085.8 | 2861.7 | 0.1687 | 0.0000 | +0.1687 | +0.2097 | 4.1998 | 4.1995 | -0.3 | 10.0155 | 8.188 | 10.016 |
| 1 | 4 | rest | 720 | 6095.8 | 13285.8 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1980 | 4.1916 | -6.5 | 10.0154 | 1.719 | 10.016 |
| 1 | 5 | discharge | 360 | 13295.8 | 16885.8 | 3590.0 | 0.0000 | 1.0001 | -0.9987 | -1.0001 | 4.1095 | 3.5749 | -534.5 | 10.0154 | 5.750 | 10.016 |
| 1 | 6 | rest | 720 | 16895.8 | 24085.8 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6539 | 3.6831 | +29.1 | 10.0155 | 1.375 | 10.016 |
| 1 | 7 | dynamic | 6995 | 24086.9 | 31148.1 | 7061.2 | 0.2307 | 1.2349 | -1.0053 | -0.5128 | 3.6831 | 2.4989 | -1184.2 | 1.0154 | 0.328 | 1.469 |

### SP2_25C_FUDS_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 7200.0 | 7200.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4118 | 3.4118 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 655 | 7210.0 | 13756.3 | 6546.2 | 1.8209 | 0.0000 | +1.8195 | +0.9998 | 3.5173 | 4.2001 | +682.8 | 10.0155 | 7.984 | 10.016 |
| 1 | 3 | cv | 344 | 13766.3 | 17199.4 | 3433.1 | 0.1802 | 0.0000 | +0.1802 | +0.1869 | 4.1998 | 4.1995 | -0.3 | 10.0155 | 8.891 | 10.016 |
| 1 | 4 | rest | 720 | 17209.4 | 24399.4 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1980 | 4.1891 | -8.9 | 10.0155 | 0.453 | 10.016 |
| 1 | 5 | discharge | 144 | 24409.4 | 25839.4 | 1430.0 | 0.0000 | 0.4001 | -0.3987 | -1.0001 | 4.1096 | 3.8519 | -257.7 | 10.0155 | 8.219 | 10.016 |
| 1 | 6 | rest | 719 | 25849.4 | 33039.4 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9329 | 3.9539 | +21.0 | 10.0155 | 10.000 | 10.417 |
| 1 | 7 | dynamic | 11092 | 33040.4 | 44240.7 | 11200.3 | 0.3656 | 1.9658 | -1.5974 | -0.5134 | 3.9537 | 2.4968 | -1457.0 | 1.0155 | 0.078 | 1.035 |

### SP2_25C_US06_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.3289 | 3.3289 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 669 | 70.0 | 6752.0 | 6682.0 | 1.8587 | 0.0000 | +1.8573 | +0.9999 | 3.4492 | 4.2001 | +751.0 | 10.0058 | 7.753 | 10.013 |
| 1 | 3 | cv | 347 | 6762.0 | 10219.6 | 3457.6 | 0.1831 | 0.0000 | +0.1831 | +0.1885 | 4.1997 | 4.1997 | +0.0 | 10.0058 | 5.301 | 10.013 |
| 1 | 4 | rest | 60 | 10229.6 | 10819.6 | 590.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1982 | 4.1956 | -2.6 | 10.0067 | 9.624 | 10.013 |
| 1 | 5 | discharge | 360 | 10829.6 | 14419.6 | 3590.0 | 0.0000 | 1.0002 | -0.9988 | -1.0002 | 4.1137 | 3.5759 | -537.8 | 10.0067 | 7.565 | 10.013 |
| 1 | 6 | rest | 1 | 14420.6 | 14420.6 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6496 | 3.6496 | +0.0 | -- | -- | -- |
| 1 | 7 | dynamic | 6874 | 14421.7 | 21319.0 | 6897.4 | 0.1257 | 1.1832 | -1.0557 | -0.5506 | 3.6505 | 2.4987 | -1151.8 | 1.0030 | 0.013 | 1.559 |

### SP2_25C_US06_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.4320 | 3.4320 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 653 | 70.0 | 6591.1 | 6521.1 | 1.8139 | 0.0000 | +1.8125 | +0.9998 | 3.5403 | 4.2001 | +659.8 | 10.0155 | 2.499 | 10.016 |
| 1 | 3 | cv | 345 | 6601.1 | 10044.3 | 3443.1 | 0.1830 | 0.0000 | +0.1830 | +0.1893 | 4.1998 | 4.1995 | -0.3 | 10.0155 | 8.625 | 10.016 |
| 1 | 4 | rest | 60 | 10054.3 | 10644.3 | 590.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1980 | 4.1956 | -2.4 | 10.0154 | 9.296 | 10.016 |
| 1 | 5 | discharge | 144 | 10654.3 | 12084.3 | 1430.0 | 0.0000 | 0.4001 | -0.3987 | -1.0001 | 4.1135 | 3.8532 | -260.3 | 10.0155 | 8.125 | 10.016 |
| 1 | 6 | rest | 1 | 12085.3 | 12085.3 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9277 | 3.9277 | +0.0 | -- | -- | -- |
| 1 | 7 | dynamic | 10680 | 12086.3 | 22863.2 | 10776.9 | 0.1970 | 1.8456 | -1.6546 | -0.5526 | 3.9293 | 2.4982 | -1431.1 | 1.0154 | 0.062 | 1.032 |

### SP2_25C_BJDST_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.3033 | 3.3033 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 672 | 70.0 | 6778.1 | 6708.1 | 1.8658 | 0.0000 | +1.8644 | +0.9998 | 3.4255 | 4.2001 | +774.6 | 10.0057 | 4.000 | 10.016 |
| 1 | 3 | cv | 345 | 6788.1 | 10228.6 | 3440.5 | 0.1819 | 0.0000 | +0.1820 | +0.1882 | 4.1997 | 4.1995 | -0.2 | 10.0154 | 6.391 | 10.016 |
| 1 | 4 | rest | 60 | 10238.7 | 10828.6 | 590.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1979 | 4.1956 | -2.3 | 10.0155 | 9.265 | 10.016 |
| 1 | 5 | discharge | 360 | 10838.7 | 14428.7 | 3590.0 | 0.0000 | 1.0002 | -0.9988 | -1.0002 | 4.1139 | 3.5762 | -537.6 | 10.0154 | 5.453 | 10.016 |
| 1 | 6 | rest | 1 | 14429.7 | 14429.7 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6494 | 3.6494 | +0.0 | -- | -- | -- |
| 1 | 7 | dynamic | 6940 | 14430.7 | 21438.7 | 7008.1 | 0.0311 | 1.0731 | -1.0448 | -0.5366 | 3.6424 | 2.4994 | -1143.1 | 1.0155 | 0.297 | 1.018 |

### SP2_25C_BJDST_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.2633 | 3.2633 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 674 | 70.0 | 6796.4 | 6726.4 | 1.8710 | 0.0000 | +1.8696 | +0.9999 | 3.3855 | 4.2001 | +814.6 | 10.0048 | 2.171 | 10.013 |
| 1 | 3 | cv | 343 | 6806.4 | 10223.1 | 3416.7 | 0.1818 | 0.0000 | +0.1818 | +0.1893 | 4.1998 | 4.1998 | +0.0 | 10.0038 | 4.684 | 10.013 |
| 1 | 4 | rest | 60 | 10233.1 | 10823.1 | 590.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1979 | 4.1956 | -2.3 | 10.0077 | 9.572 | 10.013 |
| 1 | 5 | discharge | 144 | 10833.1 | 12263.2 | 1430.0 | 0.0000 | 0.4001 | -0.3987 | -1.0002 | 4.1137 | 3.8532 | -260.5 | 10.0038 | 9.153 | 10.013 |
| 1 | 6 | rest | 1 | 12264.2 | 12264.2 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9274 | 3.9274 | +0.0 | -- | -- | -- |
| 1 | 7 | dynamic | 11205 | 12265.2 | 23493.6 | 11228.4 | 0.0499 | 1.7036 | -1.6537 | -0.5299 | 3.9207 | 2.4999 | -1420.9 | 1.0029 | 0.127 | 1.017 |

### SP2_45C_DST_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2 | charge | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.9988 | 4.3459 | 4.3459 | +0.0 | -- | -- | -- |
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1810 | 4.1810 | +0.0 | -- | -- | -- |
| 1 | 3 | cv | 228 | 70.0 | 2337.3 | 2267.3 | 0.0311 | 0.0000 | +0.0324 | +0.0489 | 4.2004 | 4.2004 | +0.0 | 10.0155 | 4.219 | 10.016 |
| 1 | 4 | rest | 720 | 2347.3 | 9537.3 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1980 | 4.1939 | -4.1 | 10.0155 | 0.391 | 10.016 |
| 1 | 5 | discharge | 360 | 9547.3 | 13137.3 | 3590.0 | 0.0000 | 0.9999 | -0.9985 | -0.9998 | 4.0163 | 3.4956 | -520.7 | 10.0155 | 4.984 | 10.016 |
| 1 | 6 | rest | 719 | 13147.3 | 20337.3 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6667 | 3.6821 | +15.4 | 10.0155 | 9.875 | 10.016 |
| 1 | 7 | dynamic | 7046 | 20338.4 | 27445.9 | 7107.4 | 0.1708 | 1.2321 | -1.0627 | -0.5376 | 3.6813 | 2.4999 | -1181.4 | 1.0156 | 0.063 | 1.018 |

### SP2_45C_DST_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.2339 | 3.2339 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 689 | 70.0 | 6952.0 | 6881.9 | 1.9133 | 0.0000 | +1.9119 | +0.9994 | 3.3457 | 4.2001 | +854.4 | 10.0156 | 1.437 | 10.016 |
| 1 | 3 | cv | 323 | 6962.0 | 10186.6 | 3224.6 | 0.1762 | 0.0000 | +0.1762 | +0.1945 | 4.2004 | 4.2004 | +0.0 | 10.0156 | 9.734 | 10.016 |
| 1 | 4 | rest | 719 | 10196.6 | 17386.6 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1993 | 4.1934 | -5.8 | 10.0156 | 9.109 | 10.016 |
| 1 | 5 | discharge | 144 | 17396.6 | 18826.6 | 1430.0 | 0.0000 | 0.4000 | -0.3986 | -0.9999 | 4.1074 | 3.8604 | -247.0 | 10.0156 | 8.000 | 10.016 |
| 1 | 6 | rest | 420 | 18836.6 | 23026.6 | 4190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9471 | 3.9578 | +10.7 | 10.0156 | 4.109 | 10.016 |
| 1 | 7 | dynamic | 11304 | 23027.6 | 34428.1 | 11400.5 | 0.2773 | 1.9563 | -1.6889 | -0.5326 | 3.9573 | 2.4955 | -1461.8 | 1.0155 | 0.031 | 1.616 |

### SP2_45C_FUDS_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.0872 | 3.0872 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 699 | 70.0 | 7054.6 | 6984.6 | 1.9419 | 0.0000 | +1.9406 | +0.9995 | 3.2086 | 4.2001 | +991.5 | 10.0155 | 6.016 | 10.016 |
| 1 | 3 | cv | 318 | 7064.6 | 10232.1 | 3167.5 | 0.1721 | 0.0000 | +0.1721 | +0.1931 | 4.2002 | 4.2004 | +0.2 | 10.0155 | 3.797 | 10.016 |
| 1 | 4 | rest | 6 | 10242.2 | 10292.2 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1993 | 4.1993 | +0.0 | 10.0154 | 9.953 | 10.016 |
| 1 | 5 | discharge | 360 | 10302.2 | 13892.2 | 3590.0 | 0.0000 | 0.9998 | -0.9984 | -0.9998 | 4.1148 | 3.5854 | -529.5 | 10.0155 | 5.453 | 10.016 |
| 1 | 6 | rest | 720 | 13902.2 | 21092.2 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6672 | 3.6834 | +16.2 | 10.0155 | 1.094 | 10.016 |
| 1 | 7 | dynamic | 7484 | 21093.2 | 28655.1 | 7561.9 | 0.2509 | 1.3400 | -1.0873 | -0.5178 | 3.6829 | 2.4988 | -1184.2 | 1.0156 | 0.141 | 1.019 |

### SP2_45C_FUDS_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.9684 | 2.9684 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 702 | 70.0 | 7081.4 | 7011.4 | 1.9494 | 0.0000 | +1.9480 | +0.9995 | 3.1024 | 4.2001 | +1097.6 | 10.0155 | 2.781 | 10.016 |
| 1 | 3 | cv | 315 | 7091.4 | 10233.3 | 3141.9 | 0.1715 | 0.0000 | +0.1715 | +0.1942 | 4.2004 | 4.2004 | +0.0 | 10.0155 | 7.937 | 10.016 |
| 1 | 4 | rest | 6 | 10243.3 | 10293.3 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1993 | 4.1991 | -0.2 | 10.0151 | 9.969 | 10.016 |
| 1 | 5 | discharge | 144 | 10303.3 | 11733.3 | 1430.0 | 0.0000 | 0.3999 | -0.3986 | -0.9999 | 4.1153 | 3.8661 | -249.2 | 10.0155 | 8.250 | 10.016 |
| 1 | 6 | rest | 720 | 11743.3 | 18933.3 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9497 | 3.9602 | +10.5 | 10.0155 | 1.187 | 10.016 |
| 1 | 7 | dynamic | 11626 | 18934.3 | 30680.3 | 11746.0 | 0.3888 | 2.0702 | -1.6791 | -0.5145 | 3.9597 | 2.4984 | -1461.3 | 1.0156 | 0.015 | 1.033 |

### SP2_45C_US06_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.0530 | 3.0530 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 700 | 70.0 | 7058.8 | 6988.7 | 1.9431 | 0.0000 | +1.9417 | +0.9995 | 3.1772 | 4.2001 | +1022.9 | 10.0155 | 0.297 | 10.016 |
| 1 | 3 | cv | 315 | 7068.8 | 10212.2 | 3143.5 | 0.1720 | 0.0000 | +0.1720 | +0.1948 | 4.2006 | 4.2004 | -0.2 | 10.0155 | 9.609 | 10.016 |
| 1 | 4 | rest | 6 | 10222.2 | 10272.3 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1994 | 4.1989 | -0.5 | 10.0155 | 9.953 | 10.016 |
| 1 | 5 | discharge | 360 | 10282.3 | 13872.3 | 3590.0 | 0.0000 | 0.9998 | -0.9985 | -0.9998 | 4.1152 | 3.5855 | -529.6 | 10.0155 | 5.562 | 10.016 |
| 1 | 6 | rest | 720 | 13882.3 | 21072.3 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6669 | 3.6823 | +15.4 | 10.0155 | 1.063 | 10.016 |
| 1 | 7 | dynamic | 6995 | 21073.3 | 28138.1 | 7064.8 | 0.1271 | 1.2159 | -1.0909 | -0.5556 | 3.6820 | 2.4997 | -1182.2 | 1.0156 | 0.172 | 1.030 |

### SP2_45C_US06_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.8585 | 2.8585 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 701 | 70.0 | 7077.3 | 7007.3 | 1.9483 | 0.0000 | +1.9469 | +0.9995 | 3.0274 | 4.2001 | +1172.7 | 10.0155 | 8.406 | 10.016 |
| 1 | 3 | cv | 314 | 7087.3 | 10216.1 | 3128.7 | 0.1716 | 0.0000 | +0.1716 | +0.1949 | 4.2006 | 4.2006 | +0.0 | 10.0155 | 4.734 | 10.016 |
| 1 | 4 | rest | 6 | 10226.1 | 10276.1 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1993 | 4.1991 | -0.2 | 10.0156 | 9.953 | 10.016 |
| 1 | 5 | discharge | 144 | 10286.1 | 11716.1 | 1430.0 | 0.0000 | 0.3999 | -0.3985 | -0.9998 | 4.1155 | 3.8664 | -249.1 | 10.0155 | 8.187 | 10.016 |
| 1 | 6 | rest | 720 | 11726.1 | 18916.1 | 7190.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9499 | 3.9607 | +10.9 | 10.0155 | 1.000 | 10.016 |
| 1 | 7 | dynamic | 10884 | 18917.1 | 29910.2 | 10993.1 | 0.2023 | 1.8831 | -1.6817 | -0.5502 | 3.9602 | 2.4993 | -1461.0 | 1.0156 | 0.047 | 1.031 |

### SP2_45C_BJDST_50SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.0529 | 3.0529 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 699 | 70.0 | 7050.7 | 6980.7 | 1.9409 | 0.0000 | +1.9395 | +0.9995 | 3.1772 | 4.2001 | +1022.9 | 10.0155 | 1.328 | 10.016 |
| 1 | 3 | cv | 317 | 7060.7 | 10217.1 | 3156.4 | 0.1724 | 0.0000 | +0.1723 | +0.1940 | 4.2006 | 4.2006 | +0.0 | 10.0155 | 2.469 | 10.016 |
| 1 | 4 | rest | 6 | 10227.1 | 10277.1 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1994 | 4.1991 | -0.3 | 10.0154 | 9.953 | 10.016 |
| 1 | 5 | discharge | 360 | 10287.2 | 13877.2 | 3590.0 | 0.0000 | 0.9998 | -0.9985 | -0.9998 | 4.1153 | 3.5854 | -529.9 | 10.0155 | 5.344 | 10.016 |
| 1 | 6 | rest | 7126 | 13878.2 | 21077.2 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.6622 | 3.6813 | +19.1 | 1.0155 | 0.797 | 1.016 |
| 1 | 7 | dynamic | 7325 | 21078.2 | 28474.9 | 7396.7 | 0.0333 | 1.1193 | -1.0879 | -0.5294 | 3.6726 | 2.4997 | -1172.8 | 1.0155 | 0.625 | 1.032 |

### SP2_45C_BJDST_80SOC

| cycle | step | type | n | t start | t end | dur (s) | Ah ch. | Ah dis. | Ah trapz | I mean | V start | V end | dV (mV) | dt med | dt min | dt max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | rest | 1 | 60.0 | 60.0 | 0.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 2.9718 | 2.9718 | +0.0 | -- | -- | -- |
| 1 | 2 | charge | 700 | 70.0 | 7065.2 | 6995.2 | 1.9449 | 0.0000 | +1.9435 | +0.9995 | 3.1057 | 4.2001 | +1094.4 | 10.0155 | 6.203 | 10.016 |
| 1 | 3 | cv | 314 | 7075.2 | 10208.7 | 3133.5 | 0.1723 | 0.0000 | +0.1723 | +0.1957 | 4.2006 | 4.2004 | -0.2 | 10.0155 | 9.469 | 10.016 |
| 1 | 4 | rest | 6 | 10218.7 | 10268.7 | 50.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 4.1993 | 4.1993 | +0.0 | 10.0002 | 9.969 | 10.016 |
| 1 | 5 | discharge | 144 | 10278.7 | 11708.7 | 1430.0 | 0.0000 | 0.3999 | -0.3985 | -0.9998 | 4.1153 | 3.8664 | -248.9 | 10.0155 | 8.047 | 10.016 |
| 1 | 6 | rest | 7127 | 11709.7 | 18908.7 | 7199.0 | 0.0000 | 0.0000 | +0.0000 | +0.0000 | 3.9442 | 3.9606 | +16.4 | 1.0155 | 0.625 | 1.016 |
| 1 | 7 | dynamic | 11390 | 18909.7 | 30411.3 | 11501.5 | 0.0519 | 1.7331 | -1.6857 | -0.5275 | 3.9516 | 2.4988 | -1452.9 | 1.0156 | 0.094 | 1.032 |
