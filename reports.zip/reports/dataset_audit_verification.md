# Dataset audit verification: reconciliation of the two independent CALCE audits

Date: 2026-09-27. Reconciliation agent output.

Two audits of the 33 CALCE workbooks were compared field by field:

* **A (canonical)** `results/dataset_inventory.json`, produced by `scripts/01_audit.py` through `src/tfso/data.py`
  (re-generated after the fixes listed in section 5).
* **B (independent)** `scratch/audit_independent.json`, produced by `scratch/audit_independent.py` (reads only the
  processed CSVs, `data_processed/manifest_raw.json`, and two raw workbooks for the chunk check).

Tools written for this verification (all in `scratch/`):

* `scratch/reconcile.py` loads both JSONs, maps the two schemas onto each other and prints every numerical
  disagreement above tolerance (0.5 % relative, or absolute 1 sample / 0.02 s / 1 mV; Ah 0.5 % with a 0.1 mAh floor;
  currents 0.5 % with a 1 mA floor). It writes `scratch/reconcile_out.json` (every compared field with both values and
  the verdict) and `scratch/reconcile_stdout.txt`.
* `scratch/adjudicate.py` re-computes every disputed quantity directly from the CSVs in `data_processed/` (and, for
  the sheet/Info questions, from the raw workbooks) and prints the evidence quoted in section 4.

## 1. Result in one paragraph

After the fixes, **13 850 field comparisons over 153 field families and all 33 logical ids agree except 79**, and all
79 residual disagreements are either definitional (both audits are right under their own stated definition: 30 CV-step
trapezoid values, 45 sign-convention sample counts) or errors in B (4 Info-sheet channel labels). Before the fixes the
canonical audit A was wrong in two respects, both confirmed against the CSVs / workbooks and both corrected in
`src/tfso/data.py` (plus the manifest writer and one report footnote): (i) `Step_Time` resets inside the dynamic
profile step were under-counted because interleaved step-8 logger rows hid the loop boundaries (e.g. 5 instead of 29
in `SP2_25C_DST_80SOC`, all 24 dynamic files affected); (ii) the Info-sheet channel was taken from the last channel row
of a multi-channel Info sheet instead of the row of the channel that the workbook actually holds (3 files wrong:
`SP1_IC_OCV_25C`, `SP1_IC_OCV_45C`, `SP2_INITCAP`). All physical quantities (sample counts, sampling intervals, missing
values, repeated timestamps, discontinuities, segment tables with Ah throughputs and durations, rest voltages,
capacities, sign convention, step-8 handling, net Ah of the dynamic profiles) agreed between A and B from the start.

## 2. Fields compared (153 families, 13 850 comparisons)

The mapping A-field <-> B-field is in `scratch/reconcile.py`; the families and the number of comparisons per family
(after the fixes; "dis." = residual disagreements) are:

| family (A side) | B side | n | dis. |
|---|---|---|---|
| n_files, logical_ids | summary.n_files, logical_ids | 2 | 0 |
| cell, temperature_C, test_type, profile, start_soc_label | cell, temperature_C_setpoint, test_type, profile, start_soc_pct_nominal | 165 | 0 |
| source.workbook / folder / processed_csv / md5 / csv_md5 | source_workbook, source_folder, processed_csv, md5_source_workbook, csv_md5 | 165 | 0 |
| source.data_sheets | source_sheets (manifest_raw) | 33 | 0 |
| source.info_test_name / info_schedule_file | info_test_name, info_schedule | 66 | 0 |
| source.info_channel | info_channel | 33 | 4 (B wrong, section 4.3) |
| source.n_rows_raw_sheets | n_rows_manifest_raw | 33 | 0 |
| columns (17), channel names, units | columns, channels.*, units | 330 | 0 |
| channels.constant_zero_columns, Internal_Resistance all-zero flag | constant_columns, internal_resistance_column | 66 | 0 |
| missing_values_per_column (17 columns) | missing_values_per_column | 561 | 0 |
| n_rows, verification.n_rows | n_rows | 66 | 0 |
| test_time_first_s / last_s / duration_s | same | 99 | 0 |
| date_time first / last / span, drift min / max / at end | same | 198 | 0 |
| date_time.largest_step_change (pause) vs wall-clock gaps | wall_clock_gaps_gt_5s | 35 | 0 |
| verification.data_point_strictly_increasing | data_point_strictly_increasing | 33 | 0 |
| verification V_min / V_max / I_abs_max | ranges | 99 | 0 |
| verification.step_indices | step_indices_present | 33 | 0 |
| sampling.overall (median/min/max/p5/p95/n) | dt_overall | 198 | 0 |
| rows per step (sum of per-(cycle,step) n) | rows_per_step | 303 | 0 |
| per-step dt (n, min, max, median) | sampling_interval_per_step | 940 | 0 |
| discontinuities: negative dt, repeated timestamps, dt > 3x median, Step_Time resets, V jumps total / unexplained | discontinuities.* | 198 | 0 |
| remaining fully duplicated rows | duplicate_rows_fully_identical | 33 | 0 |
| sign convention: verified flag, fractions | convention, frac_* | 99 | 0 |
| sign convention: sample counts | n_rows_I_pos / n_rows_I_neg | 66 | 45 (definitional, section 4.5) |
| segment count | charge+discharge+rest segments | 33 | 0 |
| segments keyed by (cycle, step): type, n, t_start, t_end, duration, Ah charge / discharge (Arbin), Ah net (trapezoid), I mean / min / max, V start / end / min / max, dt median, dV over rest | charge_segments, discharge_segments, rest_periods | 7 776 | 30 (definitional, section 4.4) |
| OCV files: n pulses, Q_total (Arbin, trapezoid, final cumulative), last V, cutoff flag, last cycle/step, initial V, cycle-1 CC samples, per-pulse Ah (discharge 60, charge 54), pulse-list lengths | incremental_ocv.*, summary.* | 174 | 0 |
| OCV relaxed points keyed by (cycle, step): V_relaxed, V_1h, V_first, n, rest duration | rest_ocv_table, rest_periods | 625 | 0 |
| OCV own-capacity SOC labels and cumulative Ah after each discharge pulse | soc_after_each_discharge_pulse | 120 | 0 |
| capacity.json OCV totals | incremental_ocv.total_discharged_ah_arbin | 6 | 0 |
| initial-capacity files: Q (Arbin, trapezoid), step, V_end, duration, first charge CC+CV, pause flag, pause row / Q before / V before / V after / duration | initial_capacity.*, pause_inside_discharge | 32 | 0 |
| capacity.json initial capacities, summary.initial_capacity_ah, initial voltages | summary.* | 33 | 0 |
| dynamic files: n step-7 samples, n step-8 rows, step-8 max gap / all twinned / max current, duplicate timestamps, profile duration, dt step 7 (6 stats), net Ah step 7 (Arbin, trapezoid), Ah charge / discharge step 7, V start / end / min, I min / max | dynamic_profile.*, step8_artifact.* | 528 | 0 |
| dynamic: dominant current levels (>= 5 % of samples) and most frequent level | current_levels_rounded_0p05A | 110 | 0 |
| dynamic: Step_Time resets in step 7 | profile_loop_boundaries.n_step_time_resets_in_step7 | 24 | 0 |
| dynamic: rest before profile (duration, V_end, dV, n), pre-profile discharge (Ah Arbin / trapezoid, I mean, duration), pre-profile charge (CC+CV Ah, CV end I and V), V after 2 h rest | rest_periods, soc_reference.pre_profile_discharge_step5, full_charge_step3 | 288 | 0 |
| reference SOC: pre-profile Ah, expected Ah, in-file net discharged Ah (trapezoid and Arbin, derived from A's SOC x Q_ref), SOC at profile start with nominal 2 Ah and with in-file capacity | soc_reference.* | 168 | 0 |
| summary tables (step-8 rows, pre-profile Ah, cycle-1 CC samples, drift at end) | summary.* | 96 | 0 |
| chunk-concatenation checks (rows per sheet, recomputed md5) | chunk_concatenation_checks | 4 | 0 |

Quantities that are not directly comparable because the two audits define them differently were converted to a common
definition before comparison (e.g. B's segment durations "including the gap from the previous sample" were compared
with the same-definition B field, A's SOC values were converted back to Ah with A's Q_ref, A's 0.01 A current bins were
re-binned to B's 0.05 A bins, A's row indices were compared with B's Data_Point - 2 for the "row before the jump").

## 3. Disagreements found (first run, before any fix)

The first run of `reconcile.py` reported 14 569 comparisons and 692 disagreements:

| # | field | files | A | B | verdict |
|---|---|---|---|---|---|
| D1 | `discontinuities.n_step_time_resets_within_step` and `dyn.n_step_time_resets_in_step7` | all 24 dynamic files | 0-10 | 5-31 | **A wrong** (fixed) |
| D2 | `source.info_channel` | SP1_IC_OCV_25C, SP1_IC_OCV_45C, SP2_INITCAP | 1-006, 1-006, 1-016 | 1-005, 1-005, 1-014 | **A wrong** (fixed); B right for the two SP1 files, wrong for SP2_INITCAP |
| D3 | `source.info_channel` | SP3_IC_OCV_25C, SP3_IC_OCV_45C, SP3_INITCAP | 1-006, 1-006, 1-016 | 1-005, 1-005, 1-014 | **B wrong** (noted) |
| D4 | `seg[c1,s3].Ah_net_trapz` (cycle-1 CV step) | 30 files (all 6 OCV + 24 dynamic) | e.g. 0.140495 | [0.137752, 0.140457] | definitional, both right (section 4.4) |
| D5 | `sign.n_samples_I_positive` / `_negative` | 27 / 18 files | e.g. 13315 | 16523 | definitional, both right (section 4.5) |
| D6 | `dyn.current_level[...]` (563 entries) | 24 dynamic files | truncated list | full histogram | artefact of the first comparison (A lists only 0.01 A bins holding >= 0.2 % of the samples, B lists 0.05 A bins); replaced by a comparison of the dominant levels, which agree in every file (section 4.6) |

Additional B-only claims that contradict A's builder summary were also checked (section 4.7-4.9).

## 4. Adjudication evidence (`scratch/adjudicate.py`, direct CSV / workbook inspection)

### 4.1 D1: Step_Time resets inside step 7 (A wrong, fixed)

For every dynamic file the number of `Step_Time(s)` decreases was counted (a) between consecutive rows of the file with
the same `Step_Index` (A's former method) and (b) between consecutive step-7 rows after removing the step-8 rows (B's
method). The difference is exactly the number of resets where a step-8 logger row sits between the two step-7 samples:

```
SP2_25C_DST_80SOC   A-method= 5  B-method(step7 only)=29  step8 rows=24  resets hidden by an interleaved step-8 row=24
SP2_45C_DST_80SOC   A-method=10  B-method(step7 only)=31  step8 rows=21  hidden=21
SP2_45C_BJDST_80SOC A-method= 0  B-method(step7 only)=12  step8 rows=12  hidden=12
(all 24 files: hidden == step-8 rows; B-method == A-method + step-8 rows)
```

The schedule loops the profile step, so every loop boundary is a physical reset; A's consecutive-row test missed all
boundaries that carry a step-8 row. Fix: `data._discontinuities` now evaluates resets on the rows of each (cycle, step)
group (logger-artifact groups skipped). After the fix A = B in all 24 files (16, 26, 5, 7, 9, 15, 6, 11, 18, 29, 5, 8,
11, 17, 7, 12, 19, 31, 5, 8, 11, 18, 8, 12).

### 4.2 D2: Info-sheet channel (A wrong in 3 files, fixed)

The Info sheet of a multi-channel test lists one row per channel of the test, not only the channel of the workbook
(`12_2_2015_Incremental OCV test_SP20-1.xlsx`: rows `1-005` and `1-006`, creator comment "ch5_sp20-1 / ch6_sp20-3";
`10_16_2015_Initial capacity_SP20-2.xls`: rows `1-014`, `1-015`, `1-016`, comment "CH14-SP20-1 / CH15-SP20-2 /
CH16-SP20-3"). The channel of the workbook is the one in its data-sheet name (`Channel_1-005_1` -> `1-005`). A took
the last channel row, B the first (row 4 of `manifest_raw.json`):

```
SP1_IC_OCV_25C  data sheet=Channel_1-005_1 -> 1-005 | A=1-006 WRONG | B=1-005 OK
SP1_IC_OCV_45C  data sheet=Channel_1-005_1 -> 1-005 | A=1-006 WRONG | B=1-005 OK
SP3_IC_OCV_25C  data sheet=Channel_1-006_1 -> 1-006 | A=1-006 OK    | B=1-005 WRONG
SP3_IC_OCV_45C  data sheet=Channel_1-006_1 -> 1-006 | A=1-006 OK    | B=1-005 WRONG
SP2_INITCAP     data sheet=Channel_1-015   -> 1-015 | A=1-016 WRONG | B=1-014 WRONG
SP3_INITCAP     data sheet=Channel_1-016   -> 1-016 | A=1-016 OK    | B=1-014 WRONG
```

Fix: `data.read_workbook` selects the Info row whose channel equals the data-sheet channel (fallback: first channel
row) and records `info_channels_listed` and `data_sheet_channel`; `scripts/00_convert_raw.py` writes both to
`data_manifest.json`; `data.audit_file` exposes them in `source`. After the rebuild A's `info_channel` equals the
data-sheet channel in all 33 files.

### 4.3 D3: B's Info channel (B wrong, not fixed)

Same evidence as 4.2: B reports `1-005` for the two SP3 OCV workbooks whose sheets are `Channel_1-006_*` and `1-014`
for both SP2_INITCAP (`Channel_1-015`) and SP3_INITCAP (`Channel_1-016`). B's `info_creator_comment` even states the
mapping. This is a metadata label only; no numerical quantity depends on it.

### 4.4 D4: cycle-1 CV step Ah by trapezoid (definitional; both right)

```
SP2_25C_DST_80SOC  prev sample: I=0.9998 A, gap=10.016 s | pure trapz=0.137752  trapz incl link=0.140495  rect incl gap=0.140457
                   | Arbin dQc from prev sample=0.140482  within segment=0.137745 | A.json=0.140495  B.json=0.137752
SP1_IC_OCV_25C     prev: I=0.9994 A, gap=10.017 s | pure=0.015676  incl link=0.017298  rect=0.016139 | Arbin prev=0.016146 within=0.015675
SP3_IC_OCV_0C      prev: I=0.9995 A, gap=10.016 s | pure=0.166944  incl link=0.169659  rect=0.169594 | Arbin prev=0.169655 within=0.166940
```

A integrates each non-rest segment from the last sample of the previous segment (so the charge passed during the 10 s
between the last 1 A CC sample and the first CV sample is attributed to the CV step, consistently with A's Arbin delta,
which is also taken from the previous sample); B's `ah_trapz_signed` integrates the segment's own samples only, while
B's Arbin delta is taken from the previous sample. Both are correct under their definitions. The CV step is the only
segment where the difference exceeds 0.5 % because the current drops from 1 A to ~0.1-0.2 A within the unsampled
10 s gap (2.7 mAh); for the 1 A pulses the difference is 0.14 mAh (0.07 %), inside tolerance. A slightly overestimates
the Arbin value on this step (0.140495 vs 0.140482 Ah, 0.01 %) because the trapezoid across the gap assumes a linear
current decay; this is negligible. No change made; the convention is documented in `data.segments`.

### 4.5 D5: sign-convention sample counts (definitional; both right)

```
SP1_INITCAP        A-def: pos=13315 neg=7158 fracC=1.0000 fracD=0.9999 | B-def: pos=16523 neg=7157 fracC=1.0000 fracD=1.0000
SP2_25C_DST_80SOC  A-def: pos=1211  neg=7304 fracC=1.0000 fracD=0.9999 | B-def: pos=1275  neg=7243 fracC=1.0000 fracD=1.0000
SP1_IC_OCV_25C     A-def: pos=6033  neg=7096 fracC=0.9988 fracD=0.9986 | B-def: pos=6025  neg=7086 fracC=1.0000 fracD=1.0000
```

A classifies a sample pair by the midpoint current with a 0.05 A threshold; B uses the current of the second sample
with a 0.01 A threshold and drops pairs where an Arbin column decreases. The CSV reproduces both counts exactly. The
conclusion (I > 0 = charge, fractions >= 0.998 in every file) is the same in both.

### 4.6 D6: current levels of the dynamic profiles (comparison artefact)

```
SP2_0C_FUDS_50SOC   n7=6961   level +0.00 A: CSV=1833  A(rebinned)=1818  B=1833 ; -0.65 A: CSV=248 A=248 B=248 ; -0.40 A: 223/223/223
SP2_25C_DST_80SOC   n7=10621  level -0.50 A: CSV=4522  A=4522  B=4522 ; -0.00 A: 2578/2578/2578 ; -1.00 A: 1619/1619/1619 ; -2.50 A: 718/717/718
```

A's list is a truncated histogram (0.01 A bins holding >= 0.2 % of the samples: 5 329 of 6 961 samples listed for the
FUDS file); B's is a 0.05 A histogram. Re-binning A's list cannot reproduce B's small bins by construction. The dominant
levels (>= 5 % of the samples) agree within 1 sample in every file. `reconcile.py` now compares only those.

### 4.7 B claim: `Internal_Resistance(Ohm)` is non-zero in the three initial-capacity files (B right; A consistent)

```
SP1_INITCAP nonzero=16405 unique=4 max=0.1230 first Data_Point=11198 | A constant_zero has IR: False | B n_nonzero=16405
SP2_INITCAP nonzero=15555 unique=4 max=0.0637 first Data_Point=10683 | A: False | B: 15555
SP3_INITCAP nonzero=17425 unique=4 max=0.1521 first Data_Point=11686 | A: False | B: 17425
SP1_IC_OCV_25C / SP2_25C_DST_80SOC: nonzero=0 | A constant_zero has IR: True | B: 0
```

A's inventory already excludes the column from `constant_zero_columns` for these three files (A's builder summary said
the same). No disagreement.

### 4.8 B claim: `SP1_INITCAP` workbook lists only `Sheet1` (B's manifest incomplete; A right)

Opening `data_raw/SP1_Initial capacity_10_16_2015/10_16_2015_Initial capacity_SP20-1.xlsx`: sheet names
`['Sheet1', 'Sheet2', 'Sheet3']`, rows `{Sheet1: 27602, Sheet2: 0, Sheet3: 0}`, no `Info` sheet. A records all three
sheets (two empty); B's `source_sheets` come from `manifest_raw.json`, which lists only data-bearing sheets. Both agree
that no Info text (test name, channel, schedule) exists for this file.

### 4.9 Chunk-boundary duplicates and the manifest row counts (both right)

B: raw concatenation has identical rows at Data_Point 63990 and 127979 (raw rows 63990 and 127980, 0-based);
A: dropped rows `[63990, 127980]` of the concatenation. Same rows, two indexings. After de-duplication both report
`n_rows` = raw - 2 for the six OCV files and identical CSV md5s (`source.csv_md5`: 33/33 agree, also after the rebuild
in section 5, so the CSVs are byte-identical to the ones B audited). B's remark that `manifest_raw.json` still lists the
raw counts is correct and harmless (that manifest is B's scratch input; the canonical `data_manifest.json` carries both
`n_rows_raw` and `n_rows`).

### 4.10 Other cross-checks that agreed without adjustment

SP2_INITCAP pause: A row 19603 (0-based, before the jump) = B Data_Point 19605 - 2; A pause 208.16 s = B wall gap
209 s minus the 0.844 s Test_Time step; Q before pause 2.004759 Ah in both; V 2.5573 -> 3.2902 V in both. Initial
capacities 2.009444 / 2.028345 / 1.977507 Ah, OCV totals 1.805571 / 1.987336 / 1.999575 / 1.765162 / 1.995968 /
2.000236 Ah (B's per-pulse sums differ by <= 2 uAh from A's end-point differences). Pre-profile discharges 0.3615 /
0.9035 Ah at 0 C and 0.4000 / 1.0002 Ah at 25 / 45 C in both. Step-8 rows 246 in total, all within 0.0172 s of a step-7
sample with zero current in both. Net Ah of step 7 (Arbin and trapezoid) agree to < 0.1 mAh in all 24 files. Every
relaxed rest voltage (625 comparisons) agrees to < 1 mV; every segment boundary time to < 0.02 s.

## 5. Fixes applied to the canonical pipeline

1. `src/tfso/data.py::_discontinuities`: `Step_Time` resets are now counted within each (cycle, step) group on the
   group's own rows (logger-artifact groups skipped), so interleaved step-8 rows no longer hide the loop boundaries.
   Effect: `discontinuities.n_step_time_resets_within_step` in the 24 dynamic files changed from 0-10 to the true
   5-31 (equal to B and to the direct CSV count); `step_time_reset_rows` now lists the row before each reset.
2. `src/tfso/data.py::read_workbook`: the Info-sheet channel row is selected by matching the data-sheet channel; new
   metadata `info_channels_listed`, `data_sheet_channel`. `scripts/00_convert_raw.py` writes them to
   `data_manifest.json`; `data.audit_file` copies them into `source`. Effect: `source.info_channel` corrected in
   `SP1_IC_OCV_25C`, `SP1_IC_OCV_45C` (1-006 -> 1-005) and `SP2_INITCAP` (1-016 -> 1-015).
3. `scripts/01_audit.py`: footnote of the sampling/discontinuity table (section 7 of `reports/dataset_audit.md`)
   updated to the new definition of `Step_Time resets`.

Re-run: `python scripts/00_convert_raw.py --force` (33 workbooks rebuilt, 1 304 495 raw rows -> 1 304 483; CSV md5s
unchanged) and `python scripts/01_audit.py` (exit 0, 8.8 s, all 33 files pass every check), then
`python scratch/reconcile.py` (13 850 comparisons, 79 residual disagreements, all classified above) and
`python tests/test_data.py` (3/3 ok). Regenerated: `data_manifest.json`, `results/capacity.json`,
`results/dataset_inventory.json`, `reports/dataset_audit.md`, `tables/tab_dataset_inventory.tex`,
`tables/tab_split_assignment.tex`. No numerical value other than the two fixed fields changed.

## 6. Residual open issues

* None that affect a physical quantity. The 79 residual reconcile disagreements are the definitional CV-step
  trapezoid (30) and sign-count (45) differences and B's 4 wrong Info-channel labels; B's `scratch/audit_independent.py`
  was not modified (it is scratch material) and its `info_channel`, `source_sheets` (SP1_INITCAP) fields should be
  read with sections 4.3 and 4.8 in mind.
* Both audits agree that the 45 C OCV discharge branches (SP1 3.034 V, SP3 3.198 V) and the SP1 0 C branch (2.577 V)
  did not reach 2.5 V, so those totals remain lower bounds of the capacity at those temperatures, and that the
  SP2_INITCAP capacity (2.0283 Ah) contains 0.0236 Ah extracted after an unlogged 209 s pause; A keeps the logged total
  and flags it, B recommends the pre-pause value (2.0048 Ah). This is a modelling choice, not a data disagreement, and
  is left to the capacity/Q_ref decision documented in `results/capacity.json`.
